/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: SURVEYING handbook, Chapters 9–12
   Tacheometry · Areas and volumes · Curves · Modern surveying
   Includes three animated figures — see dia-anim1.js for the
   authoring contract they follow.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 9.2 STADIA PRINCIPLE */
  "hb-sv-stadia": {
    label: "Why a staff intercept measures distance",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A telescope with two stadia hairs a fixed distance apart in the diaphragm, producing a cone of sight that widens with distance, so the length of staff cut off between the two hairs is directly proportional to how far away the staff is.">
      ${hbmk("st2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE FURTHER THE STAFF, THE MORE OF IT FITS BETWEEN THE HAIRS</text>
      <rect class="steel" x="60" y="132" width="48" height="26" rx="4"/>
      <text class="lb" x="84" y="180" text-anchor="middle">telescope</text>
      <line class="thin" x1="106" y1="138" x2="106" y2="152"/>
      <text class="lb" x="106" y="128" text-anchor="middle">i</text>
      <path class="hi" d="M108 145 L600 84"/>
      <path class="hi" d="M108 145 L600 206"/>
      <path class="thin dash" d="M108 145 L600 145"/>

      ${[[268, 125, 165, "s₁"], [430, 105, 185, "s₂"], [592, 85, 205, "s₃"]].map(([x, y1, y2, lbl]) => `
        <rect class="conc" x="${x - 8}" y="${y1 - 26}" width="16" height="${y2 - y1 + 52}"/>
        <line class="ac" x1="${x + 18}" y1="${y1}" x2="${x + 18}" y2="${y2}" marker-end="url(#st2-c)" marker-start="url(#st2-c)"/>
        <text class="ea" x="${x + 26}" y="${(y1 + y2) / 2 + 4}">${lbl}</text>`).join("")}

      <text class="lb" x="350" y="240" text-anchor="middle">s grows in exactly the same proportion as D, so their ratio is a constant of the instrument</text>
      <text class="em" x="350" y="266" text-anchor="middle">D = (f/i) s + (f + d)   =   k s + C   ·   normally k = 100 and C = 0</text>
    </svg>`,
    caption: "No tape touches the ground. The two stadia hairs are a fixed distance <em>i</em> apart and the telescope's focal length <em>f</em> is fixed, so the cone of sight widens at a fixed rate — and the staff intercept is a direct measure of distance. <strong>An intercept of 1.2 m at k = 100 means 120 m</strong>, read in a few seconds.",
  },

  /* ------------------------------------------- 10.2 TRAPEZOIDAL vs SIMPSON */
  "hb-sv-simpson": {
    label: "Trapezoidal against Simpson's rule",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="An irregular boundary with offsets taken at equal intervals, approximated first by straight chords between successive offsets giving the trapezoidal rule, and then by parabolic arcs through each group of three offsets giving Simpson's rule, which follows a curved boundary more closely.">
      ${hbmk("sp2")}
      <text class="em" x="168" y="26" text-anchor="middle">TRAPEZOIDAL — straight between offsets</text>
      <line class="s" x1="46" y1="196" x2="298" y2="196"/>
      ${[[46, 150], [88, 122], [130, 106], [172, 96], [214, 104], [256, 124], [298, 148]].map(([x, y], i, a) =>
        `<line class="thin" x1="${x}" y1="196" x2="${x}" y2="${y}"/>${i ? `<line class="hi" x1="${a[i - 1][0]}" y1="${a[i - 1][1]}" x2="${x}" y2="${y}"/>` : ""}`).join("")}
      <path class="thin dash" d="M46 150 C110 96 200 92 298 148"/>
      <text class="lb" x="168" y="226" text-anchor="middle">chords cut the corners off a curve</text>
      <text class="em" x="168" y="250" text-anchor="middle">works for any number of offsets</text>
      <text class="lb" x="168" y="272" text-anchor="middle">A = d[ (O₁+Oₙ)/2 + ΣO(middle) ]</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="280"/>

      <text class="em" x="524" y="26" text-anchor="middle">SIMPSON — a parabola through each three</text>
      <line class="s" x1="402" y1="196" x2="654" y2="196"/>
      ${[[402, 150], [444, 122], [486, 106], [528, 96], [570, 104], [612, 124], [654, 148]].map(([x, y]) =>
        `<line class="thin" x1="${x}" y1="196" x2="${x}" y2="${y}"/>`).join("")}
      <path class="hi" d="M402 150 Q444 112 486 106 Q528 92 570 104 Q612 128 654 148"/>
      <text class="lb" x="524" y="226" text-anchor="middle">a curve follows a curve</text>
      <text class="em" x="524" y="250" text-anchor="middle">needs an ODD number of offsets</text>
      <text class="lb" x="524" y="272" text-anchor="middle">A = (d/3)[ O₁+Oₙ + 4ΣO(odd) + 2ΣO(even) ]</text>
    </svg>`,
    caption: "Simpson's rule is more accurate whenever the boundary genuinely curves, which is most of the time. Its one condition is real and is where marks are lost: <strong>an even number of intervals, so an odd number of offsets</strong>. With an even count, apply Simpson to all but the last strip and finish that one trapezoidally.",
  },

  /* ------------------------------------------- 11.2 CURVE ELEMENTS */
  "hb-sv-curve": {
    label: "The parts of a simple circular curve",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two straights meeting at a point of intersection with a deflection angle between them, joined by a circular arc, showing the tangent length from the point of intersection to each tangent point, the length of the arc, the long chord joining the tangent points, the apex distance and the mid ordinate.">
      ${hbmk("cv2")}
      <text class="em" x="350" y="24" text-anchor="middle">SIX QUANTITIES — AND ALL OF THEM COME FROM R AND Δ</text>
      <line class="s" x1="70" y1="238" x2="350" y2="98"/>
      <line class="s" x1="350" y1="98" x2="630" y2="238"/>
      <circle class="hif" cx="350" cy="98" r="6"/>
      <text class="em" x="350" y="88" text-anchor="middle">PI</text>
      <path class="hi" d="M196 160 A186 186 0 0 0 504 160"/>
      <circle class="acf" cx="196" cy="160" r="5"/>
      <circle class="acf" cx="504" cy="160" r="5"/>
      <text class="ea" x="176" y="154" text-anchor="end">T₁</text>
      <text class="ea" x="524" y="154">T₂</text>
      <line class="ac dash" x1="196" y1="160" x2="504" y2="160"/>
      <text class="lb" x="350" y="152" text-anchor="middle">long chord = 2R sin(Δ/2)</text>
      <line class="ac" x1="350" y1="98" x2="350" y2="160" marker-end="url(#cv2-c)" marker-start="url(#cv2-c)"/>
      <text class="ea" x="360" y="120">E</text>
      <line class="ac" x1="350" y1="160" x2="350" y2="192" marker-end="url(#cv2-c)" marker-start="url(#cv2-c)"/>
      <text class="ea" x="360" y="182">M</text>
      <line class="thin dash" x1="196" y1="160" x2="350" y2="330"/>
      <line class="thin dash" x1="504" y1="160" x2="350" y2="330"/>
      <text class="lb" x="262" y="122" text-anchor="middle">T = R tan(Δ/2)</text>
      <text class="em" x="350" y="214" text-anchor="middle">L = πRΔ/180</text>
      <text class="lb" x="70" y="266">E = R[sec(Δ/2) − 1]   ·   M = R[1 − cos(Δ/2)]</text>
      <text class="lb" x="70" y="288">degree of curve, 30 m arc:  D = 1718.9 / R</text>
      <text class="em" x="630" y="266" text-anchor="end">chainage of T₁ = chainage of PI − T</text>
      <text class="em" x="630" y="288" text-anchor="end">chainage of T₂ = chainage of T₁ + L</text>
    </svg>`,
    caption: "The last two lines are where real mistakes happen. <strong>The chainage of the second tangent point is reached along the ARC, not by adding the second tangent length</strong> — the curve is shorter than going out to the intersection and back. Getting that wrong shifts every peg beyond the curve.",
  },

  /* ------------------------------------------- 12.2 GNSS */
  "hb-sv-gnss": {
    label: "How a receiver finds itself",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Four satellites each broadcasting its position and time, with a ground receiver measuring the travel time of each signal to obtain a range, three ranges intersecting at the receiver's position and the fourth solving the receiver clock error.">
      ${hbmk("gn")}
      <text class="em" x="350" y="24" text-anchor="middle">RESECTION AGAIN — ONLY THE KNOWN POINTS ARE MOVING</text>
      ${[[130, 72], [300, 56], [470, 74], [612, 104]].map(([x, y], i) => `
        <rect class="steel" x="${x - 14}" y="${y - 8}" width="28" height="16" rx="3"/>
        <line class="thin" x1="${x - 24}" y1="${y}" x2="${x - 14}" y2="${y}"/>
        <line class="thin" x1="${x + 14}" y1="${y}" x2="${x + 24}" y2="${y}"/>
        <line class="hi" x1="${x}" y1="${y + 10}" x2="350" y2="216"/>
        <text class="lb" x="${x}" y="${y - 18}" text-anchor="middle">SV${i + 1}</text>`).join("")}
      <path class="s" d="M60 246 C200 232 500 232 640 246"/>
      <rect class="conc" x="338" y="216" width="24" height="30"/>
      <text class="em" x="350" y="270" text-anchor="middle">receiver</text>
      <text class="lb" x="60" y="140">each satellite broadcasts</text>
      <text class="lb" x="60" y="158">WHERE it is and WHEN</text>
      <text class="lb" x="60" y="176">it sent the signal</text>
      <text class="ea" x="60" y="200">range = travel time × c</text>
      <text class="lb" x="640" y="140" text-anchor="end">3 ranges fix x, y, z</text>
      <text class="em" x="640" y="160" text-anchor="end">the 4th solves the</text>
      <text class="em" x="640" y="178" text-anchor="end">receiver's CLOCK error</text>
      <text class="lb" x="640" y="202" text-anchor="end">— which is why you need four</text>
      <text class="lb" x="350" y="294" text-anchor="middle">errors: satellite geometry (DOP), ionosphere, troposphere, multipath — and DGPS/RTK remove most of them</text>
    </svg>`,
    caption: "The fourth satellite is the part worth understanding. Three ranges would be enough if the receiver had an atomic clock; it does not, so its clock error is a fourth unknown and needs a fourth equation. <strong>A receiver is not measuring distance — it is measuring time, and solving for position and for its own clock at once.</strong>",
  },

  /* ============================================== ANIMATED ============== */

  /* ------------------------------------------- 7.1 HOW CONTOURS ARE MADE */
  "an-sv-contour": {
    label: "Slicing a hill into contours",
    anim: true,
    svg: `<svg viewBox="0 0 700 310" role="img" aria-label="A hill shown in section being cut by a series of equally spaced horizontal planes, with each cut producing one closed contour line, and the resulting set of rings shown in plan beside it, closer together where the hillside is steep.">
      ${hbmk("ac2")}
      <text class="em" x="350" y="24" text-anchor="middle">A CONTOUR IS WHERE A LEVEL PLANE CUTS THE GROUND</text>

      <text class="lb" x="60" y="58">SECTION</text>
      <path class="conc" d="M50 240 C110 238 140 176 196 132 C240 98 268 96 300 124 C330 150 340 216 300 240 Z"/>
      ${[0, 1, 2, 3].map(i => `
        <line class="hi an-step" style="--dur:5.2s;--del:${i * 1.1}s" x1="44" y1="${218 - i * 28}" x2="316" y2="${218 - i * 28}"/>
        <text class="ea an-step" style="--dur:5.2s;--del:${i * 1.1}s" x="328" y="${222 - i * 28}">${100 + i * 5}</text>`).join("")}
      <line class="ac" x1="36" y1="218" x2="36" y2="190" marker-end="url(#ac2-c)" marker-start="url(#ac2-c)"/>
      <text class="ea" x="28" y="208" text-anchor="end">CI</text>
      <text class="lb" x="60" y="268">each plane is 5 m above the last —</text>
      <text class="lb" x="60" y="288">that spacing is the contour interval</text>

      <line class="gl" x1="378" y1="44" x2="378" y2="300"/>

      <text class="lb" x="410" y="58">PLAN</text>
      ${[[92, 62], [70, 48], [48, 34], [26, 20]].map(([rx, ry], i) => `
        <ellipse class="hi an-step" style="--dur:5.2s;--del:${i * 1.1}s" cx="528" cy="160" rx="${rx}" ry="${ry}" fill="none"/>`).join("")}
      <text class="ea" x="528" y="164" text-anchor="middle">115</text>
      <text class="lb" x="528" y="252" text-anchor="middle">the steep left side gives closely</text>
      <text class="lb" x="528" y="272" text-anchor="middle">spaced rings; the gentle right side</text>
      <text class="lb" x="528" y="292" text-anchor="middle">gives widely spaced ones</text>
    </svg>`,
    caption: "Watch each plane arrive and produce its ring. That is literally all a contour is — the line of intersection between the ground and a level surface at a stated height. <strong>Once you have seen it happen, the spacing rule needs no memorising</strong>: a steep slope is cut by many planes over a short horizontal distance, so the rings crowd together.",
  },

  /* ------------------------------------------- 6.6 EQUAL SIGHTS */
  "an-sv-collim": {
    label: "Why equal sight lengths cancel a collimation error",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A level whose line of sight tilts slightly upward instead of being horizontal, set up first midway between two staves so that the same error affects both readings equally and cancels in the difference, and then set up close to one staff so that the error affects the far reading much more and does not cancel.">
      ${hbmk("acl")}
      <text class="em" x="350" y="24" text-anchor="middle">THE INSTRUMENT IS OUT OF ADJUSTMENT IN BOTH CASES</text>

      <text class="em" x="168" y="58" text-anchor="middle">SIGHTS EQUAL — error cancels</text>
      <line class="thin dash" x1="56" y1="124" x2="286" y2="124"/>
      <line class="hi an-sway" style="--amp:0;--dur:4s" x1="56" y1="132" x2="286" y2="108"/>
      <rect class="steel" x="158" y="128" width="26" height="10"/>
      <rect class="conc" x="52" y="132" width="12" height="80"/>
      <rect class="conc" x="278" y="108" width="12" height="104"/>
      <line class="ac an-pulse" style="--dur:4s" x1="70" y1="124" x2="70" y2="132" />
      <line class="ac an-pulse" style="--dur:4s" x1="272" y1="116" x2="272" y2="124"/>
      <text class="lb" x="168" y="164" text-anchor="middle">both readings too big by the SAME amount</text>
      <text class="em" x="168" y="192" text-anchor="middle">difference is correct → RL is correct</text>
      <text class="lb" x="168" y="220" text-anchor="middle">d — d, and the error is gone</text>

      <line class="gl" x1="348" y1="46" x2="348" y2="286"/>

      <text class="em" x="524" y="58" text-anchor="middle">SIGHTS UNEQUAL — error survives</text>
      <line class="thin dash" x1="410" y1="124" x2="648" y2="124"/>
      <line class="hi" x1="410" y1="128" x2="648" y2="96"/>
      <rect class="steel" x="424" y="122" width="26" height="10"/>
      <rect class="conc" x="406" y="128" width="12" height="84"/>
      <rect class="conc" x="640" y="96" width="12" height="116"/>
      <line class="ac an-pulse" style="--dur:4s" x1="420" y1="123" x2="420" y2="126"/>
      <line class="ac an-pulse" style="--dur:4s;--del:.5s" x1="634" y1="100" x2="634" y2="124"/>
      <text class="lb" x="524" y="164" text-anchor="middle">the near reading is barely affected,</text>
      <text class="lb" x="524" y="186" text-anchor="middle">the far one a great deal</text>
      <text class="em" x="524" y="216" text-anchor="middle">the difference carries the error straight</text>
      <text class="em" x="524" y="238" text-anchor="middle">into the reduced level</text>

      <text class="lb" x="350" y="282" text-anchor="middle">which is why "balance your sights" is the first thing anyone is taught about levelling</text>
    </svg>`,
    caption: "A collimation error is a <em>systematic</em> error — the second target in Chapter 2 — and it is invisible in the readings themselves. Equalising the sight distances makes it affect both readings identically so it drops out of the subtraction, and it removes curvature and refraction at the same time. <strong>One field habit, three errors gone.</strong>",
  },

  /* ------------------------------------------- 11.4 SETTING OUT A CURVE */
  "an-sv-setout": {
    label: "Setting out a curve by deflection angles",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A theodolite at the first tangent point turning off successive deflection angles from the tangent, with the chainman measuring a chord from the last peg to find each new point on the curve, so the curve is pegged out peg by peg.">
      ${hbmk("aso")}
      <text class="em" x="350" y="24" text-anchor="middle">ANGLE FROM THE INSTRUMENT · CHORD FROM THE LAST PEG</text>
      <line class="s" x1="80" y1="232" x2="420" y2="76"/>
      <text class="lb" x="250" y="132" transform="rotate(-24 250 132)">tangent</text>
      <circle class="hif" cx="80" cy="232" r="7"/>
      <text class="em" x="66" y="250">T₁</text>
      <path class="hi" d="M80 232 C180 216 300 214 420 244"/>
      ${[[150, 224], [222, 217], [294, 216], [366, 224], [420, 244]].map(([x, y], i) => `
        <line class="ac an-step" style="--dur:6s;--del:${i * 1.1}s" x1="80" y1="232" x2="${x}" y2="${y}"/>
        <circle class="acf an-step" style="--dur:6s;--del:${i * 1.1}s" cx="${x}" cy="${y}" r="5"/>
        <text class="lb an-step" style="--dur:6s;--del:${i * 1.1}s" x="${x}" y="${y + 22}" text-anchor="middle">${i + 1}</text>`).join("")}
      <path class="thin" d="M110 216 A40 40 0 0 1 116 226" fill="none"/>
      <text class="ea" x="126" y="208">δ₁</text>
      <text class="lb" x="470" y="96">δ₁ = 1718.9 C / R  minutes</text>
      <text class="lb" x="470" y="118">(C = chord length, R = radius)</text>
      <text class="em" x="470" y="152">the angles ACCUMULATE:</text>
      <text class="lb" x="470" y="174">Δ₁ = δ₁,  Δ₂ = Δ₁ + δ₂,  …</text>
      <text class="em" x="470" y="212">final Δ must equal Δ/2</text>
      <text class="lb" x="470" y="234">— the check that catches</text>
      <text class="lb" x="470" y="254">an arithmetic slip before</text>
      <text class="lb" x="470" y="274">the pegs go in the ground</text>
    </svg>`,
    caption: "Rankine's method, and the one used on site because the instrument never has to move. Each peg is found by turning the total deflection angle from the tangent and swinging a chord from the previous peg — <strong>two people, one setup, and a curve of any length</strong>. The final angle must come to half the deflection angle, which is the check that saves you.",
  },

});
