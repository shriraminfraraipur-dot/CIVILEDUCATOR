/* ============================================================
   CIVIL EDUCATOR — Code guides, part 4
   The remaining codes: loads, seismic, masonry, soil,
   foundations, pavements, water supply, testing, measurement
   and fire grading. Our own explanations — not code text.
   ============================================================ */

window.DB = window.DB || {};
DB.guides = DB.guides || {};

Object.assign(DB.guides, {

  /* ---------------------------------------------- LOADS */
  "is875-1": {
    what: "The dead load part of the loading code — the permanent weight of the structure itself and of everything fixed to it. It is a book of unit weights: how much a cubic metre of brickwork, concrete, stone, timber, soil or water weighs, and how much a square metre of roofing sheet, flooring, plaster or partition weighs. Dead load is the one load a designer is expected to compute rather than look up from a hazard map.",
    use: "The first calculation of every structural design, and the input to seismic weight, foundation load and quantity estimation alike.",
    inside: [
      "Unit weights of building materials — masonry, concrete, metals, timber, stone, soil and liquids",
      "Weights of walls and partitions by material and thickness",
      "Weights of floor and roof finishes, ceilings and waterproofing treatments",
      "Weights of roof coverings, sheeting and false ceilings",
      "Weights of fixed services and equipment",
    ],
    key: [
      ["Reinforced concrete", "25 kN/m³"],
      ["Plain concrete", "24 kN/m³"],
      ["Brick masonry", "Of the order of 19–20 kN/m³ depending on the brick"],
      ["Water", "10 kN/m³ (9.81 in full)"],
      ["Steel", "78.5 kN/m³"],
    ],
    watch: [
      "Floor finishes and partitions are dead loads and are routinely forgotten. On a typical slab they add 1.5 to 2.5 kN/m² — comparable with the imposed load itself.",
      "Dead load is also seismic weight, so under-estimating it under-estimates the earthquake force on the whole building.",
    ],
  },

  "is875-2": {
    what: "The imposed load part of the loading code — the load from people, furniture, stored goods and movable equipment. It is essentially a table of uniformly distributed loads and concentrated loads by occupancy, plus the loads for roofs, balconies and staircases and the rules for reducing the load on columns carrying many floors.",
    use: "Every floor and roof design, and every column and foundation load take-down.",
    inside: [
      "Uniformly distributed and concentrated imposed loads by occupancy class",
      "Residential, office, educational, assembly, industrial and storage occupancies",
      "Loads on roofs — accessible and inaccessible, flat and sloping",
      "Loads on balconies, staircases, corridors and parapets",
      "Reduction in imposed load for columns, piers, walls and foundations carrying several floors",
      "Loads from partitions where their position is not fixed",
    ],
    key: [
      ["Residential rooms", "2.0 kN/m²"],
      ["Office floors (above ground)", "2.5 kN/m² for general areas"],
      ["Balconies and corridors in public buildings", "3.0 to 5.0 kN/m² depending on occupancy"],
      ["Inaccessible flat roof", "0.75 kN/m²"],
      ["Load reduction", "Permitted on columns supporting several floors, because all floors are not fully loaded at once"],
    ],
    watch: [
      "Storage and library floors carry far more than office floors, and a change of use after handover is how floors get overloaded.",
      "The imposed load reduction applies to columns and foundations, never to the beam or slab of the floor itself.",
    ],
  },

  "is875-3": {
    dia: "g-wind",
    what: "The wind load part of the loading code, and the most calculation-heavy of the five. It converts a basic wind speed for the location into a design wind pressure through a chain of factors — for risk, for terrain and height, for topography and, in the 2015 revision, for the importance of the structure — and then into forces through pressure coefficients that depend on the shape of the building and on the openings in it.",
    use: "Any structure where wind governs — tall buildings, sheds, roofs, hoardings, chimneys, towers — and any light roof, where uplift rather than downward pressure is the problem.",
    inside: [
      "Basic wind speed map of India and the six wind speed zones",
      "Risk coefficient k1, terrain and height factor k2, topography factor k3, and the importance factor introduced in the 2015 revision",
      "Design wind speed and design wind pressure",
      "External and internal pressure coefficients for a wide range of building shapes and roof forms",
      "Force coefficients for clad and unclad structures, lattice towers and chimneys",
      "Dynamic effects and the gust factor method for flexible structures",
    ],
    key: [
      ["Design wind pressure", "pz = 0.6 Vz², with Vz in m/s giving pz in N/m²"],
      ["Design wind speed", "Vz = Vb · k1 · k2 · k3 · k4"],
      ["Internal pressure", "Depends on the permeability of the building — a large opening on the windward side is the worst case"],
      ["Uplift", "Wind is mostly a suction problem on roofs, not a downward pressure problem"],
    ],
    watch: [
      "Light roofs fail by uplift, and the critical load case is dead load minus wind, not dead load plus wind. The holding-down detail is what matters.",
      "A large door left open on the windward face converts a building into a pressurised box and can lift the roof off — internal pressure coefficient is not a formality.",
    ],
  },

  "is875-5": {
    what: "The part of the loading code that covers special loads and, crucially, the load combinations. Its subject is everything the other four parts do not cover — temperature, hydrostatic and soil pressure, erection loads, accidental loads — and then the combinations in which dead, imposed, wind, snow and other loads are to be considered together.",
    use: "Setting up the load cases and combinations for a structural analysis.",
    inside: [
      "Temperature effects and the movement they cause",
      "Hydrostatic pressure, soil pressure and surcharge",
      "Erection and construction loads",
      "Accidental loads, including impact and explosion",
      "Load combinations for working stress and for limit state design",
      "Combination of imposed load with wind and with snow",
    ],
    key: [
      ["Purpose", "Not every load reaches its maximum at the same moment, so combinations reduce the total accordingly"],
      ["Seismic", "Earthquake load comes from IS 1893, not from IS 875 — the title of the series says 'other than earthquake'"],
      ["Erection loads", "A partially built structure can be in its worst condition of its life"],
    ],
    watch: [
      "The governing combination is often not the one with the most loads in it. The uplift case, with reduced dead load, is frequently worse for anchorage and foundations.",
      "Temperature and shrinkage effects are routinely ignored in long buildings and then appear as cracks at the stiff cores.",
    ],
  },

  /* ---------------------------------------------- SEISMIC */
  is4326: {
    what: "The code for the earthquake resistant design and construction of buildings — the practical detailing companion to IS 1893. Where IS 1893 gives the force and IS 13920 gives the ductile detailing of reinforced concrete frames, IS 4326 covers the building as a whole: its configuration, its masonry, and the seismic bands, vertical bars and connections that turn a set of walls into a box.",
    use: "Masonry and low-rise construction in seismic zones, and the general configuration rules for any building.",
    inside: [
      "General principles of earthquake resistant building configuration — symmetry, regularity, and simple load paths",
      "Categories of construction based on seismic zone and importance",
      "Seismic bands — plinth, lintel, roof and gable bands — and their reinforcement",
      "Vertical reinforcement at corners and at jambs of openings",
      "Requirements for openings in load bearing walls — size, position and spacing",
      "Roof and floor connections to walls, and the treatment of gable ends and projections",
    ],
    key: [
      ["Bands", "Continuous reinforced concrete bands at plinth, sill, lintel, eaves and gable level that tie the walls together"],
      ["Vertical bars", "At every corner and at the jambs of openings, tied into the bands"],
      ["Openings", "Limited in size and kept away from corners — an opening near a corner destroys the box action"],
    ],
    watch: [
      "The box action is the whole idea. A wall that is not tied to the walls beside it and to the roof above it will fall outwards, whatever its own strength.",
      "Heavy roofs on weak walls are the classic Indian earthquake casualty. A lighter roof reduces the force at source.",
    ],
  },

  /* ---------------------------------------------- MASONRY */
  is1905: {
    what: "The code for the structural use of unreinforced masonry — designing a wall to carry load rather than simply to divide space. It works with the basic compressive stress of the masonry, modified by a stress reduction factor for slenderness and eccentricity, by an area reduction factor for small walls and by a shape modification factor for the units.",
    use: "Load bearing masonry buildings, and checking the capacity of an existing masonry wall.",
    inside: [
      "Materials — units, mortar grades and their combinations",
      "Basic compressive stress of masonry from the unit strength and the mortar grade",
      "Slenderness ratio, effective height and effective thickness of walls",
      "Stress reduction factor for slenderness and eccentricity",
      "Area and shape modification factors",
      "Design of walls, piers, walls with openings and walls subject to lateral load",
      "Bonding, junctions and the lateral support of walls",
    ],
    key: [
      ["Slenderness ratio", "Effective height or length divided by effective thickness — the main variable"],
      ["Mortar grade", "A stronger mortar raises the masonry strength, but a mortar stronger than the unit is wasteful and cracks the units"],
      ["Eccentricity", "A load applied off-centre on a wall reduces its capacity sharply"],
    ],
    watch: [
      "Masonry is strong in compression and almost useless in tension. Everything in the code is arranged to keep the wall in compression.",
      "Cement-rich mortar is not better. A mortar stronger than the brick forces cracks through the bricks instead of through the joints, where they could be repointed.",
    ],
  },

  is2212: {
    what: "The code of practice for brickwork — how a brick wall is actually to be built. It covers the preparation and soaking of bricks, the mortar, the bonds, the laying, the joints, the raising of walls and the curing, together with the workmanship tolerances that decide whether the wall is plumb, level and true.",
    use: "Supervising or specifying brickwork on any building.",
    inside: [
      "Bricks, mortar and their selection for the situation",
      "Soaking of bricks before laying",
      "Bonds — English bond, Flemish bond and their variants, and where each is appropriate",
      "Laying, joint thickness, raking of joints and the height a wall may be raised in a day",
      "Junctions, toothing, corners and the closing of walls against existing work",
      "Curing, protection and tolerances on plumb, line and level",
    ],
    key: [
      ["Soaking", "Bricks are soaked so that they do not draw the water out of the mortar before it can hydrate"],
      ["Joint thickness", "Kept to about 10 mm; thick joints are weak joints"],
      ["Daily height", "Limited so that the green mortar in the courses below is not overloaded"],
      ["English bond", "Stronger; Flemish bond is better looking — the usual trade-off"],
    ],
    watch: [
      "Raising a wall too fast squeezes the fresh mortar in the lower courses and leaves the wall out of plumb and understrength.",
      "Vertical joints must be properly filled. A wall with hollow perpends is far weaker and leaks water straight through.",
    ],
  },

  is2250: {
    what: "The code of practice for the preparation and use of masonry mortars — the material that holds masonry together and, just as importantly, distributes the load evenly between units that are never perfectly flat. It covers cement, lime and composite mortars, their proportions, mixing, consistency and use.",
    use: "Specifying the mortar for any masonry or plastering work, and deciding the mix for a given situation.",
    inside: [
      "Types of mortar — cement, lime, cement-lime composite and mud mortars",
      "Mix proportions and the mortar grades they correspond to",
      "Materials — cement, lime, sand and water requirements",
      "Mixing, consistency and the period within which mortar must be used",
      "Selection of mortar for different classes of masonry and exposure",
      "Curing and protection of masonry mortar",
    ],
    key: [
      ["Common mixes", "1:6 and 1:4 cement-sand for general brickwork; 1:3 for load bearing and for exposed work"],
      ["Composite mortar", "Cement with added lime gives much better workability and water retention than cement alone"],
      ["Use within", "Cement mortar must be used within about half an hour of mixing; retempering with water is not permitted"],
    ],
    watch: [
      "A mortar stronger than the masonry unit is a design error, not a safety margin — it moves the cracks into the units.",
      "Lime in a mortar is not an old-fashioned habit. It improves workability, water retention and the ability of the joint to accommodate movement without cracking.",
    ],
  },

  is1077: {
    what: "The specification for common burnt clay building bricks — the standard that defines what a brick is in India. It classifies bricks by their average compressive strength, fixes the modular and conventional sizes and their tolerances, and limits water absorption, efflorescence and warpage.",
    use: "Ordering bricks, accepting a delivery and specifying a class for load bearing masonry.",
    inside: [
      "Classification by average compressive strength class",
      "Modular and non-modular brick sizes, and dimensional tolerances measured over a group of bricks",
      "Compressive strength, water absorption, efflorescence and warpage requirements",
      "General quality — shape, soundness, freedom from cracks, lumps and nodules of lime",
      "Sampling and criteria for conformity",
    ],
    key: [
      ["Strength classes", "Designated by average compressive strength — 3.5, 5, 7.5, 10 N/mm² and upwards"],
      ["Modular brick", "190 × 90 × 90 mm, laid with a 10 mm joint to give a 200 × 100 × 100 module"],
      ["Conventional brick", "Commonly around 230 × 110 × 70 mm in Indian practice"],
      ["Water absorption", "Limited, because a thirsty brick starves the mortar of water"],
    ],
    watch: [
      "Dimensional tolerance is checked over a group of twenty bricks laid end to end, not on one brick — that is how a consistently undersized consignment is caught.",
      "A brick that rings when struck is well burnt; a dull thud means under-burnt. It is a crude test but a fast one, and it is the one a site engineer uses.",
    ],
  },

  is1661: {
    what: "The code of practice for applying cement and cement-lime plaster finishes — the standard behind the most common finish on Indian walls. It covers surface preparation, the number and thickness of coats, the mortar for each coat, the application and finishing, and the curing that decides whether the plaster cracks.",
    use: "Specifying and supervising internal and external plastering.",
    inside: [
      "Preparation of the background — raking joints, cleaning, wetting and the use of a spatter dash where needed",
      "Number of coats and their thickness for different backgrounds and exposures",
      "Mortar mix for the undercoat and the finishing coat",
      "Application, levelling, floating and finishing",
      "Curing, and the interval between coats",
      "Defects — cracking, crazing, debonding, blistering and their causes",
    ],
    key: [
      ["Internal plaster", "Commonly 12 mm in a single coat on brickwork"],
      ["External plaster", "Commonly 15 to 20 mm in two coats, the second weaker than the first"],
      ["Rule of coats", "Each successive coat is weaker than the one below it, never stronger"],
      ["Curing", "Plaster is cured like concrete — usually for at least seven days"],
    ],
    watch: [
      "A finishing coat richer than the undercoat will craze and peel. Strength must decrease outwards.",
      "Most external plaster cracking is shrinkage from a rich mix and poor curing, not structural movement.",
    ],
  },

  /* ---------------------------------------------- SOIL & FOUNDATION */
  is1498: {
    what: "The standard for classifying and identifying soils for engineering purposes — the Indian version of the Unified Soil Classification System. It sorts soils into coarse grained and fine grained, uses grain size distribution for the coarse ones and the plasticity chart for the fine ones, and gives each a two-letter symbol such as SW, CL or MH that carries a great deal of engineering meaning in two characters.",
    use: "Reading any borehole log or soil report, and communicating soil behaviour unambiguously.",
    inside: [
      "Division into coarse grained, fine grained and highly organic soils",
      "Grain size limits for gravel, sand, silt and clay",
      "Classification of coarse soils by gradation — uniformity coefficient and coefficient of curvature",
      "The plasticity chart and the A-line for classifying fine grained soils",
      "Two-letter group symbols and group names",
      "Field identification procedures where laboratory data is not available",
    ],
    key: [
      ["First letter", "G gravel, S sand, M silt, C clay, O organic, Pt peat"],
      ["Second letter", "W well graded, P poorly graded, L low plasticity, H high plasticity"],
      ["A-line", "Ip = 0.73 (wL − 20) — above it the soil is a clay, below it a silt"],
      ["Fines cut-off", "Coarse grained if more than half is retained on the 75 micron sieve"],
    ],
    watch: [
      "CH soils — high plasticity clays — are the black cotton soils that swell and shrink and wreck light foundations. The symbol is a warning.",
      "Classification tells you how a soil will behave qualitatively; it is not a substitute for strength and consolidation testing.",
    ],
  },

  is6403: {
    what: "The code for determining the bearing capacity of shallow foundations by calculation — the bearing capacity equation with its bearing capacity factors, and the shape, depth and inclination factors that adjust it for a real footing rather than an idealised strip. It is the theoretical counterpart to the field plate load test of IS 1888.",
    use: "Computing the net ultimate and net safe bearing capacity of a footing from soil strength parameters.",
    inside: [
      "General bearing capacity equation and the bearing capacity factors Nc, Nq and Nγ",
      "Shape factors, depth factors and load inclination factors",
      "Effect of the water table on bearing capacity",
      "Net ultimate, net safe and allowable bearing pressure, and the factor of safety applied",
      "Local and general shear failure, and which applies to which soil",
      "Bearing capacity of footings on layered soils and on slopes",
    ],
    key: [
      ["Factor of safety", "Commonly 2.5 to 3 on the net ultimate bearing capacity"],
      ["Water table", "Raises the effective unit weight problem — a high water table can nearly halve the bearing capacity in sand"],
      ["Local shear", "Applies to loose sands and soft clays, and uses reduced strength parameters"],
      ["Allowable pressure", "The lesser of the value from bearing capacity and the value from permissible settlement"],
    ],
    watch: [
      "A bearing capacity figure means nothing without the footing width and depth it was computed for — the factors depend on both.",
      "In sands the answer from this calculation is almost always larger than the settlement-controlled value, so settlement governs.",
    ],
  },

  is1904: {
    what: "The general requirements code for the design and construction of foundations in soils — the umbrella document that sits above the individual foundation codes. It covers the information needed before design, the selection of foundation type and depth, permissible settlements, and the general construction requirements common to all foundations.",
    use: "The starting point of any foundation design, before you go to IS 1080 for shallow footings or IS 2911 for piles.",
    inside: [
      "Data required before foundation design — site, soil, groundwater and adjacent structures",
      "Choice of foundation type and depth",
      "Permissible total and differential settlement for different types of structure",
      "Foundations on problematic soils — expansive, collapsible, made-up ground",
      "Protection of adjacent structures and of the excavation",
      "General construction requirements, inspection and dewatering",
    ],
    key: [
      ["Permissible settlement", "Tabulated by structure type and soil — isolated footings are allowed more than a raft"],
      ["Differential settlement", "The criterion that actually damages buildings, expressed as an angular distortion"],
      ["Depth", "Set below the zone of seasonal moisture change, scour and the influence of adjacent foundations"],
    ],
    watch: [
      "A new foundation next to an existing one can undermine it. The relationship between the two founding levels is a design decision, not a site decision.",
      "Different foundation types under one building — say footings and piles — almost guarantee differential settlement and should be avoided or explicitly designed for.",
    ],
  },

  is2911: {
    what: "The code for the design and construction of pile foundations, in parts by pile type. Piles carry load by a combination of skin friction along the shaft and end bearing at the toe, and the code covers how the capacity is estimated, how piles are installed, how groups behave, and how the result is verified by load test.",
    use: "Any site where the shallow soil cannot carry the load — soft clays, loose fills, high water table, or heavy concentrated loads.",
    inside: [
      "Part 1 — concrete piles, in sections for driven cast in-situ, bored cast in-situ, driven precast and bored precast",
      "Part 2 — timber piles; Part 3 — under-reamed piles, used in expansive soils",
      "Part 4 — load test on piles, including initial and routine tests",
      "Static formulae for capacity from soil parameters, and dynamic formulae for driven piles",
      "Pile groups — spacing, efficiency, group settlement and the pile cap",
      "Negative skin friction, lateral capacity and structural design of the pile",
    ],
    key: [
      ["Capacity", "Skin friction along the shaft plus end bearing at the toe, each with its own factor of safety"],
      ["Under-reamed piles", "A bulb at the base anchors the pile against uplift — the standard answer to black cotton soil"],
      ["Load test", "The only direct verification; initial tests to establish capacity, routine tests to check production piles"],
      ["Negative skin friction", "Settling soil hanging on the pile and adding load rather than supporting it"],
    ],
    watch: [
      "A pile group does not carry the sum of its individual piles. Group efficiency and group settlement are separate checks and are often what governs.",
      "Integrity testing finds defects in a bored pile that no design calculation can. On any significant job it is not optional.",
    ],
  },

  is2720: {
    what: "The complete family of soil test methods — over forty parts, one per test. It is the reference behind every number in a geotechnical report: water content, specific gravity, grain size, Atterberg limits, compaction, permeability, shear strength, consolidation, CBR, swelling pressure and much more.",
    use: "Running, specifying or interpreting any soil test. When a report quotes a value, this is where its method lives.",
    inside: [
      "Preparation of samples, water content, specific gravity and density",
      "Grain size analysis by sieving and by hydrometer",
      "Atterberg limits — liquid limit, plastic limit and shrinkage limit",
      "Compaction — standard and modified Proctor, and field density by core cutter and sand replacement",
      "Permeability by constant head and variable head",
      "Shear strength — direct shear, unconfined compression, triaxial and vane shear",
      "Consolidation, swelling pressure, free swell index and California Bearing Ratio",
    ],
    key: [
      ["Liquid limit (Part 5)", "By Casagrande apparatus or cone penetrometer"],
      ["Compaction (Part 7 and 8)", "Standard Proctor and modified Proctor — modified uses much greater energy"],
      ["CBR (Part 16)", "Soaked CBR is the value used in Indian pavement design"],
      ["Field density", "Core cutter for cohesive soils, sand replacement for granular ones"],
    ],
    watch: [
      "Quote the part number with the result. 'Compaction 95%' means nothing until you say whether it is against standard or modified Proctor — the two differ substantially.",
      "Sample disturbance destroys shear strength and consolidation results. The care taken during sampling decides whether the test was worth running.",
    ],
  },

  /* ---------------------------------------------- HIGHWAY */
  irc37: {
    dia: "g-pavement",
    what: "The guidelines for the design of flexible pavements — the bituminous pavements that carry most Indian traffic. The current edition uses a mechanistic-empirical approach: the pavement is modelled as elastic layers, and the thickness is chosen so that the tensile strain at the bottom of the bituminous layer and the vertical strain on top of the subgrade both stay within limits for the design traffic.",
    use: "Designing a new flexible pavement or an overlay, and understanding a pavement composition on a drawing.",
    inside: [
      "Design traffic in million standard axles, from commercial vehicle counts, growth rate, design life, lane distribution and vehicle damage factor",
      "Subgrade characterisation by CBR and resilient modulus",
      "Pavement composition — subgrade, sub-base, base and bituminous layers",
      "Failure criteria — fatigue cracking from horizontal tensile strain, and rutting from vertical subgrade strain",
      "Design catalogues and charts for common combinations",
      "Design of overlays on existing pavements",
    ],
    key: [
      ["Design traffic", "Expressed in msa — million standard axles of 80 kN over the design life"],
      ["Subgrade", "Characterised by soaked CBR; the whole pavement thickness scales with it"],
      ["Two failure modes", "Fatigue cracking, controlled by the bituminous layer; rutting, controlled by total thickness"],
      ["Publisher", "Indian Roads Congress — this is not an Indian Standard"],
    ],
    watch: [
      "Vehicle damage factor dominates the design traffic. Overloaded trucks damage a pavement roughly as the fourth power of axle load, so a modest overload assumption changes the thickness a lot.",
      "Subgrade CBR must be the soaked value at the compaction and moisture the pavement will actually see, not a dry laboratory best case.",
    ],
  },

  irc58: {
    what: "The guidelines for the design of plain jointed rigid pavements — concrete roads. A concrete slab is stiff, so it spreads the wheel load over a wide area and the subgrade stress is small; the slab itself is then designed against the combined stresses from wheel load and from temperature warping, and against fatigue over the design life.",
    use: "Designing a concrete road or a concrete overlay, and setting out the joint layout.",
    inside: [
      "Design traffic, axle load spectrum and the design period",
      "Characterisation of the subgrade and sub-base by modulus of subgrade reaction",
      "Wheel load stress and temperature differential stress, and their critical combinations",
      "Cumulative fatigue damage analysis for bottom-up and top-down cracking",
      "Slab thickness design",
      "Joints — contraction, expansion, longitudinal and construction; dowel bars and tie bars",
      "Dry lean concrete sub-base and the separation layer",
    ],
    key: [
      ["Modulus of subgrade reaction k", "The subgrade parameter, from a plate load test rather than a CBR"],
      ["Critical stress", "Wheel load plus temperature warping, at the edge or at the corner depending on the time of day"],
      ["Dowel bars", "Transfer load across a contraction joint without restraining the slab from moving"],
      ["Tie bars", "Hold longitudinal joints together — they restrain movement, unlike dowels"],
    ],
    watch: [
      "Dowel bars must be smooth, greased at one end and perfectly aligned. A misaligned dowel locks the joint and cracks the slab beside it.",
      "The joint layout is part of the design. Cracking in a concrete pavement is inevitable; the joints decide where it happens.",
    ],
  },

  /* ---------------------------------------------- WATER & BUILDING SERVICES */
  is1172: {
    what: "The code of basic requirements for water supply, drainage and sanitation — the standard that answers the planning questions: how much water does this building need, how many water closets, urinals, wash basins and baths does it need, and how much storage. It is the sizing basis before any pipe is drawn.",
    use: "Planning the services of any building, and checking sanitary fixture counts for a building approval.",
    inside: [
      "Water requirement per head per day for different building types",
      "Minimum sanitary fixture requirements by occupancy — residential, office, school, factory, hospital, assembly",
      "Separate provision for men and women, and for staff and public",
      "Storage requirements and the split between underground and overhead storage",
      "Basic drainage and sanitation requirements",
      "Requirements for water quality and for the protection of the supply",
    ],
    key: [
      ["Domestic demand", "Of the order of 135 litres per head per day for residences with full flushing"],
      ["Fixture counts", "Tabulated by occupancy and by the number of persons — this is what a building approval checks"],
      ["Storage", "Sized for the hours of supply available, not for the daily demand alone"],
    ],
    watch: [
      "Fixture counts are a statutory matter in most building bye-laws. Getting them wrong at the planning stage is expensive to fix later.",
      "Demand figures assume a supply pattern. In a city with two hours of supply a day, storage rather than demand is the binding constraint.",
    ],
  },

  is1742: {
    what: "The code of practice for building drainage — the below-ground and external side of drainage, from the building's outlets to the public sewer or the disposal system. It covers the layout of the drainage system, pipe sizing and gradients, manholes and inspection chambers, traps, ventilation and the testing of the completed system.",
    use: "Designing or checking the external drainage of a building and its connection to the sewer.",
    inside: [
      "Layout of a building drainage system and the principles of a self-cleansing design",
      "Sizes and gradients of drains, and the self-cleansing velocity",
      "Manholes, inspection chambers and their spacing",
      "Intercepting traps, gully traps and ventilation of the system",
      "Materials for drain pipes and their jointing and bedding",
      "Testing of drains — water test, air test and smoke test",
    ],
    key: [
      ["Self-cleansing velocity", "The drain must run fast enough to carry solids — usually taken as of the order of 0.6 to 0.9 m/s"],
      ["Gradient", "Set so the drain is self-cleansing at its likely flow, not steeper"],
      ["Manholes", "At every change of direction, gradient or size, and at regular intervals on straight runs"],
    ],
    watch: [
      "Too steep a drain is a real problem, not a safe margin — the water outruns the solids and the drain blocks.",
      "Every change of direction needs access. A buried bend with no manhole will be dug up sooner or later.",
    ],
  },

  /* ---------------------------------------------- TESTING */
  is516: {
    what: "The methods of test for hardened concrete — compressive strength on cubes, flexural strength on beams and split tensile strength on cylinders. It is the standard behind the cube test that every Indian site runs, covering the moulds, the casting, the curing, the capping, the rate of loading and the interpretation of results.",
    use: "Every concrete cube test, and every argument about whether a batch was acceptable.",
    inside: [
      "Moulds, compaction and casting of test specimens",
      "Curing of specimens — temperature and the requirement for full water immersion",
      "Compressive strength test on cubes, including the rate of loading",
      "Flexural strength test on beams — the modulus of rupture",
      "Split tensile strength on cylinders",
      "Reporting, and the treatment of an obviously defective specimen",
    ],
    key: [
      ["Standard cube", "150 mm; a 100 mm cube may be used for smaller aggregate sizes, with a size correction"],
      ["Compaction", "Filled in layers and compacted by rod or vibration, as the method directs"],
      ["Curing", "Fully immersed in water at a controlled temperature until testing — not sprinkled, not covered"],
      ["Acceptance", "Judged against IS 456 Cl. 16, not against a single cube result"],
    ],
    watch: [
      "Cubes cured on site under a wet gunny bag are not cured to the standard and will read low. Most 'failed cube' investigations end here.",
      "A cube is compacted far better than the concrete in the member. It reports the potential of the mix, not the concrete in the structure — which is what IS 456 Cl. 17 core tests are for.",
    ],
  },

  is4031: {
    what: "The family of methods for the physical testing of hydraulic cement — one part per test. It is what a cement test certificate is built from: fineness, soundness, setting times, compressive strength, heat of hydration and consistency, each with its own part and its own apparatus.",
    use: "Testing a cement consignment, and reading a manufacturer's test certificate.",
    inside: [
      "Determination of fineness by sieving and by Blaine air permeability",
      "Standard consistency of cement paste by Vicat apparatus",
      "Initial and final setting time",
      "Soundness by Le Chatelier and by autoclave",
      "Compressive strength of cement mortar cubes using standard sand",
      "Heat of hydration, specific gravity, and chemical resistance parts",
    ],
    key: [
      ["Fineness", "By Blaine, as specific surface in m²/kg — finer cement hydrates faster"],
      ["Setting time", "Initial not less than 30 minutes, final not more than 600 minutes for OPC"],
      ["Soundness", "Detects free lime or magnesia that would expand later and crack the concrete"],
      ["Strength cubes", "70.6 mm cubes of 1:3 cement to standard sand mortar"],
    ],
    watch: [
      "The strength test uses standard sand to IS 650. Ordinary sand gives a result that cannot be compared with the specification.",
      "A cement that passes soundness today can fail later if it has absorbed moisture in storage — test on receipt, not on purchase date.",
    ],
  },

  is2386: {
    what: "The family of test methods for aggregates — one part per property. It covers everything from particle size and shape to mechanical strength, absorption, soundness, organic impurities and alkali-aggregate reactivity, and it is the reference behind every aggregate test report.",
    use: "Testing an aggregate source, accepting a delivery, and checking a mix design input.",
    inside: [
      "Part 1 — particle size and shape, including flakiness and elongation indices",
      "Part 2 — deleterious materials and organic impurities",
      "Part 3 — specific gravity, density, voids, absorption and bulking",
      "Part 4 — mechanical properties: aggregate crushing value, impact value, abrasion value and ten percent fines",
      "Part 5 — soundness by sodium or magnesium sulphate",
      "Parts 6 to 8 — measuring mortar making properties, alkali-aggregate reactivity and petrographic examination",
    ],
    key: [
      ["Flakiness index", "Percentage by mass of particles whose thickness is less than 0.6 of their mean dimension"],
      ["Crushing and impact value", "Lower is stronger; both are limited for concrete and more tightly for road surfacing"],
      ["Bulking of sand", "Part 3 — the volume increase of damp sand, essential if batching by volume"],
      ["Alkali-aggregate reactivity", "A slow, destructive reaction; screening the source is the only defence"],
    ],
    watch: [
      "Flaky and elongated particles break easily, need more water, and pack badly. They matter more in a road base than most people expect.",
      "Aggregate is usually the largest ingredient by mass in concrete. Testing the cement and not the aggregate tests the wrong thing.",
    ],
  },

  is13311: {
    what: "The methods for non-destructive testing of concrete — testing a structure without damaging it. Part 1 covers ultrasonic pulse velocity, where the speed of a sound pulse through the concrete indicates its quality and reveals voids and cracks; Part 2 covers the rebound hammer, which relates surface hardness to strength.",
    use: "Assessing an existing structure, checking uniformity across a pour, locating defects, and screening before deciding where to take cores.",
    inside: [
      "Part 1 — ultrasonic pulse velocity: apparatus, transducer arrangements, direct, semi-direct and indirect transmission",
      "Interpretation of pulse velocity as an indicator of concrete quality",
      "Detection of cracks, voids and honeycombing, and estimation of crack depth",
      "Part 2 — rebound hammer: calibration, surface preparation, direction of impact and the number of readings",
      "Correlation of rebound number with compressive strength, and its limitations",
    ],
    key: [
      ["Pulse velocity", "Higher velocity means denser, sounder concrete; a sharp drop indicates a void or a crack"],
      ["Rebound hammer", "Measures surface hardness only — the top few tens of millimetres"],
      ["Both are comparative", "They are excellent for comparing areas and finding defects, and poor at giving an absolute strength"],
    ],
    watch: [
      "A rebound number converted to a strength without a site-specific correlation is a guess. Carbonation, surface moisture and the direction of the hammer all shift it.",
      "NDT screens the structure and tells you where to take cores. The core test of IS 456 Cl. 17 is what settles acceptance.",
    ],
  },

  /* ---------------------------------------------- MEASUREMENT */
  "is1200-1": {
    what: "The measurement rules for earthwork — excavation, filling, cutting, banking and disposal. Earthwork is measured in cubic metres, classified by the material excavated and often by the depth of the lift, and the classification of the material is where almost every earthwork dispute begins.",
    use: "Billing excavation and filling, and settling a claim about hard strata.",
    inside: [
      "Classification of excavation by material — soft or loose soil, hard or dense soil, soft rock, hard rock",
      "Measurement of excavation for foundations, trenches, basements and site levelling",
      "Lifts and leads — the depth of excavation and the distance material is carried",
      "Filling, backfilling, compaction and the treatment of surplus spoil",
      "Deductions, and items deemed included in the rate",
    ],
    key: [
      ["Unit", "Cubic metres, measured on the authorised dimensions, not on what was actually dug"],
      ["Classification", "By material — and hard rock requiring blasting is a different rate from soft rock"],
      ["Lead and lift", "Extra payment for carrying material further, or lifting it higher, than the base rate covers"],
    ],
    watch: [
      "Over-excavation beyond the authorised dimensions is not paid for, and the backfilling of it usually is not either.",
      "The line between hard soil, soft rock and hard rock is a contractual definition, not a geological one. Read the classification clause before pricing.",
    ],
  },

  "is1200-2": {
    what: "The measurement rules for concrete works — plain and reinforced concrete, and reinforcement itself. Concrete is measured in cubic metres of the finished member, with no deduction for reinforcement, and with specific rules for what small openings and embedded items are deducted.",
    use: "Billing concrete and steel on any building or structure, and checking a running bill.",
    inside: [
      "Classification of concrete by grade, by member and by position in the structure",
      "Measurement of concrete in foundations, columns, walls, beams, slabs, stairs and lintels",
      "Deductions for openings, embedded items and the volume occupied by other members",
      "Measurement of reinforcement by mass, from the bar bending schedule",
      "Items deemed included — mixing, placing, compaction, curing, and finishing of formed surfaces",
    ],
    key: [
      ["Concrete", "Measured in cubic metres; no deduction is made for the volume of the reinforcement"],
      ["Reinforcement", "Measured in kilograms or tonnes from the authorised bar bending schedule"],
      ["Overlaps", "Where members meet, the rules say which one takes the shared volume so it is not paid twice"],
    ],
    watch: [
      "Laps, chairs, spacers and wastage are handled by the contract, not by the measurement of the schedule. Know which convention applies before pricing steel.",
      "The junction of a beam and a column is measured once. Pricing it in both is the commonest overstatement in a concrete bill.",
    ],
  },

  /* ---------------------------------------------- FIRE & GENERAL */
  is1641: {
    what: "The code that establishes the general principles of fire grading and the classification of buildings — the foundation on which the rest of the fire safety codes rest. It classifies buildings by occupancy, grades construction by fire resistance, and sets out the general principles of fire safety: prevent ignition, limit spread, protect the structure, and get people out.",
    use: "Establishing the occupancy classification and the fire grading of a building before applying any of the detailed fire codes.",
    inside: [
      "Classification of buildings by occupancy — residential, educational, institutional, assembly, business, mercantile, industrial, storage and hazardous",
      "Grading of structural elements by fire resistance period",
      "General principles of fire prevention, containment and escape",
      "Fire load and its relationship to the grading",
      "The relationship between occupancy, height, area and the requirements that follow",
    ],
    key: [
      ["Occupancy class", "Decides almost every other fire requirement — exits, compartment size, sprinklers"],
      ["Fire grading", "Expressed as the fire resistance period required of structural elements"],
      ["Fire load", "The heat energy per unit area available to burn — the basis of the grading"],
    ],
    watch: [
      "A change of occupancy changes the fire requirements. Converting a residential floor to a commercial one is a fire safety change, not just a licensing one.",
      "Mixed occupancy buildings are governed by the most demanding occupancy present unless they are properly separated.",
    ],
  },

  nbc2016: {
    what: "Part 4 of the National Building Code of India, covering fire and life safety — the umbrella document that the IS 1641 to 1644 family sits under and that most Indian building bye-laws adopt by reference. It brings occupancy classification, construction requirements, exit design, fire detection and suppression, and the provisions for high-rise buildings into a single mandatory framework.",
    use: "Any building approval, fire NOC or fire safety audit in India. It is usually the document the authority actually applies.",
    inside: [
      "Occupancy classification and types of construction",
      "General fire safety requirements by occupancy, height and area",
      "Means of egress — exits, travel distance, staircases, ramps and refuge areas",
      "Compartmentation, fire stopping and protection of openings and shafts",
      "Fire detection and alarm systems",
      "Fire fighting installations — wet risers, hydrants, sprinklers, water storage and pump capacity",
      "Special requirements for high-rise buildings, basements, atria and assembly occupancies",
    ],
    key: [
      ["Status", "Part of the National Building Code, published as SP 7, adopted by most state bye-laws"],
      ["High-rise", "Triggers additional requirements — refuge areas, fire lifts, pressurised staircases, wet risers"],
      ["Fire water storage", "Static tank capacity and pump ratings are prescribed by occupancy and height"],
      ["Refuge area", "Required at prescribed intervals in a high-rise, and it must be kept free"],
    ],
    watch: [
      "The NBC is a recommendatory document that becomes mandatory when a state adopts it. Always check the local bye-law as well — it may be stricter.",
      "Refuge areas and fire staircases being converted into storage or enclosed balconies is the single most common post-occupancy violation in Indian high-rises.",
    ],
  },

  "surv-ref": {
    what: "Surveying in the app is collected under one reference rather than a single standard, because Indian surveying practice draws on several sources — Survey of India manuals, IS standards for individual instruments and methods, and long-established professional practice. This guide sets out what that body of practice covers and where the reliable references sit.",
    use: "Any levelling, traversing, contouring or setting-out task, and any quantity computed from survey data.",
    inside: [
      "Linear measurement — chain, tape and electronic distance measurement, with corrections for slope, temperature, sag and standardisation",
      "Levelling — differential levelling, the height of instrument and rise and fall methods, and the arithmetic checks on each",
      "Angular measurement — theodolite and total station, temporary and permanent adjustments",
      "Traversing — bearings, latitudes and departures, closing error and Bowditch adjustment",
      "Contouring, area and volume computation by trapezoidal, Simpson's and prismoidal methods",
      "Setting out of buildings, roads and curves, and modern total station and GNSS practice",
    ],
    key: [
      ["Levelling check", "The sum of back sights minus the sum of fore sights equals the last reduced level minus the first"],
      ["Closing error", "Never zero in practice; it is distributed by an accepted rule, commonly Bowditch"],
      ["Volume", "Prismoidal formula is more accurate than the trapezoidal one and should be used for earthwork of any value"],
      ["Benchmark", "Every job needs a permanent, protected benchmark that survives the whole project"],
    ],
    watch: [
      "An unadjusted traverse is not a survey. Compute the closing error, check it against the permissible limit, and only then distribute it.",
      "A total station removes arithmetic errors, not blunders. Wrong instrument height or wrong prism constant produces a beautifully consistent wrong answer.",
    ],
  },

});

/* ---- The four codes that already have full topic sets get a short overview ---- */
Object.assign(DB.guides, {

  is456: {
    what: "The master code for plain and reinforced concrete in India — the single most used civil engineering standard in the country. It runs from what cement and aggregate are acceptable, through mix proportioning, workmanship, curing and acceptance testing, to the full limit state design of every ordinary concrete member and the detailing rules that make the design buildable.",
    use: "Every concrete design and every concrete pour. If you learn one code properly, learn this one.",
    inside: [
      "Section 1 — scope, terminology and symbols",
      "Section 2 — materials, workmanship, inspection and testing (Cl. 5–17)",
      "Section 3 — general design consideration: loads, stability, analysis, beams, slabs, columns (Cl. 18–27)",
      "Section 4 — special design requirements for members: detailing, deep beams, flat slabs, walls, stairs, footings (Cl. 26, 28–34)",
      "Section 5 — structural design by the limit state method (Cl. 35–43)",
      "Annexes — working stress method, deflection, two-way slabs, column effective length, crack width",
    ],
    key: [
      ["Stress block", "0.36 fck b xu for the compression, acting at 0.42 xu from the extreme fibre"],
      ["xu,max / d", "0.53 for Fe 250, 0.48 for Fe 415, 0.46 for Fe 500"],
      ["Mu,lim", "0.148 fck bd² for Fe 250, 0.138 for Fe 415, 0.133 for Fe 500"],
      ["Development length", "Ld = φ σs / (4 τbd)"],
      ["Partial safety factors", "1.5 on concrete, 1.15 on steel — giving 0.446 fck and 0.87 fy"],
    ],
    watch: [
      "Durability beats strength. The minimum grade, minimum cement content and maximum w/c ratio for the exposure condition override whatever the strength calculation allows.",
      "The code is not a design manual. It tells you what must be satisfied; SP 16 and SP 34 tell you how to satisfy it efficiently.",
    ],
  },

  is800: {
    what: "The general construction code for structural steel. The 2007 revision changed its whole basis from working stress to limit state design and brought in section classification, block shear, buckling curves and lateral torsional buckling by the modern method. It covers materials, analysis, every member type, connections, earthquake detailing, fatigue, durability, fire and fabrication.",
    use: "Every steel building, shed, tower and platform designed in India.",
    inside: [
      "Sections 1–5 — materials, general design requirements, methods of analysis and limit state design",
      "Section 6 — tension members: yielding, rupture and block shear",
      "Section 7 — compression members, effective length and built-up columns",
      "Section 8 — members in bending, lateral torsional buckling and shear",
      "Section 9 — combined forces; Section 10 — bolted and welded connections",
      "Sections 11–17 — working stress design, earthquake, fatigue, durability, fire and fabrication",
    ],
    key: [
      ["γm0 = 1.10", "Resistance governed by yielding of the gross section"],
      ["γm1 = 1.25", "Resistance governed by ultimate stress — rupture, block shear, bolts and welds"],
      ["ε = √(250/fy)", "Scales every plate slenderness limit in Table 2"],
      ["Section class", "Class 1 plastic, 2 compact, 3 semi-compact, 4 slender — decided before any strength calculation"],
    ],
    watch: [
      "Anything written to IS 800:1984 is working stress and does not belong in a 2007 calculation. Permissible stresses and limit state strengths must never be mixed.",
      "Higher grade steel is stronger but no stiffer — deflection and buckling do not improve with grade.",
    ],
  },

  "is1893-1": {
    what: "Part 1 of the earthquake code — general provisions and buildings. It gives the seismic zone map, the design spectrum, the design horizontal seismic coefficient, the base shear and its distribution up the building, the rules on irregularity and the limits on drift. It is the force half of earthquake design; IS 13920 and IS 4326 are the detailing half.",
    use: "Any building anywhere in India — every zone including Zone II requires seismic design.",
    inside: [
      "Seismic zones II to V and their zone factors",
      "Design spectrum, and the response of soft, medium and hard soil sites",
      "Design horizontal seismic coefficient and the response reduction factor",
      "Fundamental natural period and the design base shear",
      "Distribution of the base shear along the height of the building",
      "Plan and vertical irregularity, torsion, storey drift and separation between units",
    ],
    key: [
      ["Ah", "= (Z/2) · (Sa/g) / (R/I) — the design horizontal seismic coefficient"],
      ["Base shear", "VB = Ah · W, with W the seismic weight"],
      ["Storey drift", "Limited to 0.004 times the storey height under the unfactored design force"],
      ["R", "The response reduction factor — a promise of ductility that IS 13920 detailing must deliver"],
    ],
    watch: [
      "R is earned by detailing. Taking a high R and then skipping the ductile detailing designs the building for a fraction of its real demand.",
      "Soft storeys, floating columns and plan irregularity are what actually bring buildings down. The clause on irregularity matters more than the arithmetic.",
    ],
  },

  is13920: {
    what: "The ductile detailing code for reinforced concrete structures designed to resist earthquake forces. IS 1893 reduces the design force on the promise that the frame will yield in a controlled way; this is the code that makes that promise real, through confinement, minimum reinforcement, hoop spacing, anchorage, the strong-column weak-beam rule and joint design.",
    use: "Every reinforced concrete frame in a seismic zone that claims the reduced design force of a ductile system.",
    inside: [
      "General specifications — minimum concrete grade and permitted reinforcement grades",
      "Beams — geometry limits, longitudinal and transverse reinforcement, hoop spacing in the end zones",
      "Columns — geometry limits and special confining reinforcement, and its length lo",
      "The strong column – weak beam requirement",
      "Beam-column joints — joint shear and confinement",
      "Structural walls — thickness, reinforcement and boundary elements",
    ],
    key: [
      ["Confining hoops", "Closely spaced hoops over a length lo at each end of a column, where the plastic hinge will form"],
      ["Strong column – weak beam", "The columns at a joint must be stronger than the beams, so hinges form in beams"],
      ["Joint shear", "Computed from the beam bars at 1.25 fy — an overstrength value"],
      ["Wall boundary elements", "Required where the extreme fibre compressive stress exceeds 0.2 fck"],
    ],
    watch: [
      "Congestion is the enemy. If the confining hoops and the beam bars cannot physically fit at the joint, the detail will be changed on site and the ductility lost — draw the joint at full size before issuing it.",
      "Detailing is not a finishing touch on a strength design; it is the condition on which the reduced seismic force was allowed in the first place.",
    ],
  },

});
