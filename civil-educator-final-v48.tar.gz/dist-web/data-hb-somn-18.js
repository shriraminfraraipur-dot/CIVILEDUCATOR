/* MACE Academy SOM notes — Strain energy method (bending, Castigliano's theorems of deflection and slope), M p.183–189 — inserted into som chapter 8 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 8; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------- M p.183–184 */
    {
      n: "",
      title: "MACE notes — Strain energy due to bending: U = ∫M²dx/2EI (derivation)",
      hi: "बंकन के कारण विकृति ऊर्जा — व्युत्पत्ति",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.183–184" },
        { k: "p", t: "<b>LV-9 · 3) Strain Energy method</b> (M p.183)" },
        { k: "def", term: "Strain energy", t: "Strain energy is nothing but the <b>internal work done</b> due to external loading or moment or a combination. This strain energy can be used to find out the beam displacements, or displacements in any structure — but more suitably for <b>cantilevers, frames &amp; arches</b>. (M p.183)" },
        { k: "p", t: "★ Strain energy due to bending is very important when we want to find the <b>slopes &amp; deflections</b>. (M p.183)" },
        { k: "h", t: "★ Strain energy due to bending (M p.183)" },
        { k: "p", t: "Consider a beam of total length 'L' subjected to simple bending as shown below. (M p.183)" },
        { k: "list", items: [
          "Figure (M p.183), beam: simply supported beam (hinge at left, roller at right), span L, with end moments M at both ends (left end anticlockwise, right end clockwise — the beam bends in sagging). A hatched 'Element' of length dx is marked in the middle. Below it the BMD is a rectangle of height M over the whole span, sign +.",
          "Figure (M p.183), bent element: the element after bending is drawn as an arc of a circle — angle dθ at the centre, radius R, neutral axis NA (dashed) through the arc, arc length ds along the bottom. Alongside: a narrow sector with apex angle dθ, side R and base ds; below it the original straight element of length dx.",
        ] },
        { k: "steps", items: [
          "Let the element dx be plotted again after bending of the beam. After bending, the beam converts into an <b>arc of a circle</b>.",
          "Let ds = length of the arc formed by the straight beam element dx; dθ = angle subtended at the centre of the circle; R = radius of curvature.",
          "We know that ds = R·dθ &nbsp;∴ <b>dθ = ds·(1/R)</b> ——①",
          "From the flexural formula, M/I = E/R &nbsp;∴ 1/R = M/(EI). Substitute in eqⁿ ①:",
          "∴ <b>dθ = ds·(M/EI)</b> ——②",
          "Due to a moment 'M', a rotation dθ is seen. Thus we can plot the moment–rotation diagram.",
        ] },
        { k: "p", t: "Figure (M p.183), moment–rotation diagram: vertical axis Moment (M), horizontal axis θ. A straight line rises from the origin to the point (dθ, M); dashed lines from that point to the axes mark M and dθ. A narrow hatched strip under the line is labelled 'small amount of internal work (strain energy)', and the triangle area is boxed as <b>U = ½·M·dθ</b>." },
        { k: "steps", items: [
          "From the moment–rotation diagram, the small amount of strain energy stored in element dx is: <b>du = ½·M·dθ</b> ——③ (M p.184)",
          "From ② &amp; ③: du = ½·M·(ds·M/EI) &nbsp;∴ du = ½·(M²/EI)·ds",
          "But since the deformations are very small and dx is very small, <b>ds ≈ dx</b>",
          "∴ ∫du = ∫M²dx/(2EI). For total strain energy we integrate over the required length.",
        ] },
        { k: "eq", expr: "(★★)  U = ∫ Mx² · dx / (2EI)", where: [
          ["Mx", "bending moment equation for any given span/portion; the limits of that portion are used for the integration"],
          ["E I", "flexural rigidity of that portion"],
          ["U", "total strain energy stored in bending"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Logic simple hai: moment M dheere-dheere lagta hai, isliye rotation bhi 0 se dθ tak linearly badhta hai. Work = graph ke neeche ka area = triangle = ½·M·dθ. Ab dθ ko curvature se badlo (dθ = M·ds/EI) aur ds ≈ dx rakho — mil gaya du = M²dx/2EI. Poore beam ke liye bas integrate karo. Yeh wahi formula hai jo is chapter ke pehle section (strain energy — bending case) mein diya hai; notes isko step-by-step derive karte hain." },
        { k: "p", t: "Pattern yaad rakho: axial mein P²L/2AE, bending mein M²L/2EI (jab M constant ho). Har jagah '(load)² × length ÷ 2 × stiffness'." },
        { k: "trap", t: "½ factor bhoolna sabse common galti hai. Load gradually lagta hai, isliye work = ½·M·dθ hai, M·dθ nahi. Doosri galti: Mx ko alag-alag portions mein alag likhna padta hai (jahan load/EI badle) — ek hi equation poore span ke liye mat laga do." },
      ],
    },

    /* ---------------------------------------------------- M p.184–185 */
    {
      n: "",
      title: "MACE notes — Strain energy of a cantilever under end moment (prismatic and non-prismatic)",
      hi: "सिरे पर आघूर्ण वाले कैंटिलीवर की विकृति ऊर्जा",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.184–185" },
        { k: "p", t: "Sign convention used in the notes (M p.184): <b>sagging (+)</b>, <b>hogging (−)</b>." },
        { k: "p", t: "Figure (M p.184), Que 1: cantilever fixed at A (left), free end B (right), length L; clockwise moment M applied at B; a section (dashed) at distance x measured from B." },
        { k: "eg", title: "MACE notes example — Que 1: strain energy of a cantilever with end moment M", given: "Find out the strain energy stored in the beam shown: cantilever AB of length L, fixed at A, moment M applied at the free end B.", steps: [
          { t: "Formula", w: "U = ∫ Mx²·dx / (2EI)" },
          { t: "Bending moment at section x from B (hogging)", w: "Mx = −M" },
          { t: "Substitute", w: "U = ∫ (−M)²·dx / (2EI)" },
          { t: "Integrate for 0 → L", w: "U = ∫₀ᴸ M²dx/(2EI) = (M²/2EI)[x]₀ᴸ" },
        ], ans: "U = M²L/(2EI) (M p.184)" },
        { k: "p", t: "Figure (M p.184), Que 2 — <b>Non-prismatic beam</b>: cantilever fixed at the left; the left half (length L/2) has rigidity <b>2EI</b> (deeper section), the right half (length L/2) has rigidity <b>EI</b> (shallower section); clockwise moment M at the free right end. Portion ① (right, EI) has moment Mx₁; portion ② (left, 2EI) has moment Mx₂." },
        { k: "eg", title: "MACE notes example — Que 2: strain energy of a non-prismatic cantilever", given: "Find out the strain energy for the given beam: cantilever of length L, fixed at left, moment M at the free end; the free-end half (L/2) has flexural rigidity EI and the fixed-end half (L/2) has 2EI.", steps: [
          { t: "Formula", w: "U = ∫ Mx²·dx / (2EI)" },
          { t: "EI is not constant over the entire length, but is constant over each half", w: "∴ find strain energy separately for both portions and then add: U = U₁ + U₂\n(possible for different length combinations, not for load combinations, since U ∝ L (linear) and U ∝ (load)² (non-linear))" },
          { t: "Write both integrals", w: "U = ∫₀^(L/2) Mx₁²·dx/(2(EI)) + ∫₀^(L/2) Mx₂²·dx/(2(2EI))" },
          { t: "Mx₁ = Mx₂ = −M", w: "= ∫₀^(L/2) (−M)²·dx/(2EI) + ∫₀^(L/2) (−M)²·dx/(4EI)" },
          { t: "Integrate", w: "= (M²/2EI)[x]₀^(L/2) + (M²/4EI)[x]₀^(L/2)" },
          { t: "Put limits", w: "= (M²L/2EI)[1/2] + (M²/4EI)[L/2]\n= (M²L/EI)[(2×1)/(2×4) + 1/8]" },
        ], ans: "U = 3M²L/(8EI) (M p.185)" },
        { k: "h", t: "NOTE (M p.185)" },
        { k: "cmp", t: "Adding strain energies — when U₁ + U₂ = U and when not (M p.185)", cols: ["Relation", "Illustration in the notes"], rows: [
          ["① Length", "U ∝ L (linear)", "L₁ → U₁ ; L₂ → U₂ ; L → U = P²L/(2AE) ⇒ <b>U₁ + U₂ = U</b>"],
          ["② Load", "U ∝ P² (quadratic) i.e. non-linear", "P₁ → U₁ ; P₂ → U₂ ; (P₁ + P₂) = P → U = (P₁ + P₂)²L/(2AE) ⇒ <b>U₁ + U₂ &lt; U</b>"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Non-prismatic beam se ghabrao mat — jahan EI badalta hai wahan beam ko tukdon mein todo, har tukde ka integral uske apne EI ke saath likho, aur add kar do. Lengths ke tukde add ho sakte hain kyunki har tukde ki energy apni length ke proportional hai. Check: agar poora beam EI hota to U = M²L/2EI = 4M²L/8EI; aadha hissa 2EI (zyada stiff) hone se energy kam ho kar 3M²L/8EI aayi — sense banta hai." },
        { k: "p", t: "Loads ke saath superposition kyun fail hota hai? Kyunki U ∝ P². (P₁ + P₂)² = P₁² + P₂² + 2P₁P₂ — woh 2P₁P₂ wala cross term alag-alag energies jodne par chhoot jaata hai." },
        { k: "trap", t: "Do loads ki strain energy alag-alag nikal kar jodna galat hai (U₁ + U₂ &lt; U). Pehle dono loads ka combined Mx likho, phir square karke integrate karo. Length-wise tukde jodna theek hai, load-wise nahi." },
      ],
    },

    /* ---------------------------------------------------- M p.185–186 */
    {
      n: "",
      title: "MACE notes — Strain energy method for deflection: Castigliano's theorems of deflection and slope",
      hi: "विक्षेप हेतु विकृति ऊर्जा विधि — कैस्टिग्लियानो के विक्षेप एवं ढलान प्रमेय",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.185–186" },
        { k: "p", t: "<b>V-10 · ★ Strain energy method for finding deflection</b> (M p.185)" },
        { k: "list", items: [
          "This method is suitable for <b>prismatic and non-prismatic</b> beams/members. (M p.185)",
          "(★) This method can be used in case of beams containing <b>internal hinges</b> (discontinuity) — i.e. it is applicable in case of span discontinuity due to load or releases. (M p.185)",
          "This method is very suitable in case of <b>cantilevers, frames, arches</b> etc. (M p.185)",
          "★ This method is based upon the <b>law of conservation of energy</b>, which gives us <b>Castigliano's theorem</b>. Here we look at two theorems: 1) Theorem of deflection, 2) Theorem of slope. (M p.185)",
        ] },
        { k: "h", t: "1) Theorem of deflection (M p.185)" },
        { k: "def", term: "Theorem of deflection", t: "Partial derivative of strain energy with respect to load = deflection at the point where the load P acts. (M p.185)" },
        { k: "eq", expr: "∂U/∂P_B = y_B   (deflection at the point where P acts)" },
        { k: "p", t: "Figure (M p.185): cantilever fixed at A, free end B; load P at B; a fictitious load P′ = 0 at an intermediate point C; deflected curve with deflection Δc at C, Δ_B at B, and slope θc marked." },
        { k: "p", t: "If we want to find the deflection at point 'C' (where no load acts), it is made possible by applying a <b>fictitious (imaginary) load P′</b> at the location where we want the deflection. (M p.185)" },
        { k: "eq", expr: "Δc = ∂U/∂P′c   and at the very end substitute P′ = 0" },
        { k: "h", t: "2) Theorem of slope (M p.186)" },
        { k: "def", term: "Theorem of slope", t: "Partial derivative of strain energy with respect to the moment at the location where we want to find the slope = slope at the location where the external moment acts. (M p.186)" },
        { k: "eq", expr: "∂U/∂M_B = θ_B   (slope at the location where the external moment acts)" },
        { k: "p", t: "Figure (M p.186): cantilever fixed at A, free end B, point C between; clockwise moment M_B at B; deflected curve drooping downward; slope θc at C and θ_B at B marked against horizontal dashed lines." },
        { k: "p", t: "If at any location there is <b>no external moment</b> and we want the slope there, simply apply a <b>fictitious moment (M′)</b>: the partial derivative of strain energy with respect to the fictitious moment applied at that location gives the slope there. (M p.186)" },
        { k: "eq", expr: "∂U/∂M′c = θc   and at the very end substitute M′ = 0" },
        { k: "note", t: "<b>Source difference:</b> the MACE notes simply call these Castigliano's 'theorem of deflection' (∂U/∂P = y) and 'theorem of slope' (∂U/∂M = θ). This chapter's earlier Castigliano section records that textbooks number the theorems differently (some call δ = ∂U/∂P the first theorem, others the second). Both say the same thing mathematically — derivative of U with respect to a force gives the deflection under it, with respect to a moment gives the rotation under it — so in an exam write the equation along with the name." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Castigliano ka idea: energy U loads ka function hai. Kisi load ko thoda sa badhao to energy kitni badhti hai — woh rate (∂U/∂P) us load ke neeche ka deflection hai. Moment ke liye wahi baat rotation ke saath. Agar jis point par answer chahiye wahan koi load/moment hai hi nahi, to ek <b>fictitious</b> P′ ya M′ laga do, U nikaalo, differentiate karo, phir P′ = 0 ya M′ = 0 rakh do." },
        { k: "trap", t: "Fictitious load ko <b>differentiate karne se pehle</b> zero mat karo — tab uska term hi U se gayab ho jaayega aur ∂U/∂P′ = 0 aayega. Order hamesha: U likho (P′ ke saath) → ∂/∂P′ → phir P′ = 0." },
        { k: "real", t: "Internal hinge wale beams, frames aur arches mein jahan moment-area method kaam nahi karta, energy method se seedha deflection milta hai — isliye notes ise cantilevers, frames aur arches ke liye 'very suitable' kehte hain." },
      ],
    },

    /* ---------------------------------------------------- M p.186–188 */
    {
      n: "",
      title: "MACE notes — Cantilever with load at C: Δc, Δ_B, θ_B and θc by Castigliano",
      hi: "C पर भार वाला कैंटिलीवर — Δc, Δ_B, θ_B, θc",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.186–188" },
        { k: "p", t: "<b>Que 1)</b> Find slope &amp; deflection for the following beam at points B &amp; C. Figure (M p.186): cantilever fixed at A, free end B; point load P at C, at distance a from A; distance b from C to B. Required: ① Δc = ? ② Δ_B = ? ③ θ_B = ? ④ θc = ?" },
        { k: "p", t: "Figure (M p.186), sections: section ① (dashed) in portion CB with x measured from B (limits 0 at B to b at C); section ② (dashed) in portion AC with x measured from C (limits 0 at C to a at A). For ②, with a fictitious load at B, the distance of the section from B is shown as (b + x)." },
        { k: "eg", title: "MACE notes example — Que 1 ①: deflection at C (load P at C)", given: "Cantilever fixed at A, free at B; point load P at C; AC = a, CB = b; EI constant. Find Δc.", steps: [
          { t: "Strain energy in the two portions", w: "U = ∫₀ᵇ Mx²dx/(2EI) + ∫₀ᵃ Mx²·dx/(2EI)\n(in CB there is no load, so Mx = 0)" },
          { t: "Substitute Mx = −P·x in AC", w: "= ∫₀ᵇ 0 + ∫₀ᵃ (−Px)²·dx/(2EI)" },
          { t: "Integrate", w: "= ∫₀ᵃ P²x²·dx/(2EI) = (P²/2EI)(x³/3)₀ᵃ\n∴ U = P²a³/(6EI)" },
          { t: "Theorem of deflection", w: "Δc = ∂U/∂P = ∂/∂P (P²a³/6EI) = (a³/6EI) × (2P)" },
        ], ans: "(★) Δc = Pa³/(3EI) (M p.186)" },
        { k: "eg", title: "MACE notes example — Que 1 ②: deflection at B (fictitious load P′ at B)", given: "Same cantilever (P at C, AC = a, CB = b). Find Δ_B by applying a fictitious load P′ at B.", steps: [
          { t: "Strain energy", w: "U = ∫₀ᵇ Mx²·dx/(2EI) + ∫₀ᵃ Mx²·dx/(2EI)" },
          { t: "Moments: in CB, Mx = −P′x; in AC, Mx = −P′(b + x) − P·x", w: "= ∫₀ᵇ (−P′·x)²dx/(2EI) + ∫₀ᵃ [−P′(b + x) − P·x]²·dx/(2EI)\n= (P′²/2EI)(x³/3)₀ᵇ + ∫₀ᵃ [−P′·b − P′x − P·x]²·dx/(2EI)" },
          { t: "★ Use (a + b)² = a² + 2ab + b² and (−a − b)² = (a + b)²", w: "= P′²b³/(6EI) + ∫₀ᵃ [P′·b + x(P′ + P)]²·dx/(2EI)\n= P′²b³/(6EI) + ∫₀ᵃ (P′²b² + 2P′bx(P′ + P) + x²(P′ + P)²)dx/(2EI)  (M p.187)" },
          { t: "Integrate term by term", w: "U = P′²b³/(6EI) + (P′²b²/2EI)(x)₀ᵃ + [2P′b(P′ + P)/2EI](x²/2) + [(P′ + P)²/2EI](x³/3)" },
          { t: "Put limits", w: "U = P′²b³/(6EI) + P′²b²a/(2EI) + [2P′²ba²/(4EI) + 2P′·Pb·a²/(4EI)] + [(P′² + 2P′P + P²)/(2EI)](a³/3)" },
          { t: "Partially differentiate w.r.t. P′ (fictitious load at B)", w: "∂U/∂P′ = 2P′b³/(6EI) [→0] + 2P′b²a/(2EI) [→0] + 4P′b·a²/(4EI) [→0] + 2(1)Pba²/(4EI) + 2P′a³/(6EI) [→0] + 2(1)P·a³/(6EI) + 0" },
          { t: "Substitute P′ = 0", w: "Δ_B = Pa²b/(2EI) + Pa³/(3EI)" },
        ], ans: "(★) Δ_B = Pa²b/(2EI) + Pa³/(3EI) = Pa²b/(2EI) + Δc, i.e. Δ_B = θc·b + Δc and (★) θ_B = θc (M p.187)" },
        { k: "p", t: "Figure (M p.187), ③: cantilever fixed at A, free at B; load P at C; clockwise (fictitious) moment M_B at B. Section ① in CB with x from B (0 at B to b at C); section ② in AC with x from C (0 at C to a at A)." },
        { k: "eg", title: "MACE notes example — Que 1 ③: slope at B (fictitious moment M_B at B)", given: "Same cantilever (P at C, AC = a, CB = b). Find θ_B by applying a fictitious moment M_B at B.", steps: [
          { t: "Moments: in CB, Mx = −M_B; in AC, Mx = −M_B − P·x", w: "U = ∫₀ᵇ M_B²·dx/(2EI) + ∫₀ᵃ (−M_B − P·x)²·dx/(2EI)" },
          { t: "Expand", w: "= M_B²·b/(2EI) + ∫₀ᵃ (M_B² + 2P·x·M_B + P²x²)·dx/(2EI)" },
          { t: "Integrate", w: "= M_B²·b/(2EI) + (1/2EI)[M_B²a + 2P·M_B·a²/2 + P²a³/3]" },
          { t: "Strain energy", w: "∴ U = M_B²b/(2EI) + M_B²a/(2EI) + PM_B·a²/(2EI) + P²a³/(6EI)" },
          { t: "Partially differentiate w.r.t. M_B (fictitious moment at B)", w: "θ_B = ∂U/∂M_B = 2M_B·b/(2EI) [→0] + 2M_B·a/(2EI) [→0] + P·a²/(2EI) + 0" },
          { t: "Substitute M_B = 0", w: "θ_B = P·a²/(2EI)" },
        ], ans: "(★) θ_B = Pa²/(2EI) (M p.187)" },
        { k: "note", t: "<b>Check:</b> in the boxed U of part ③ (M p.187) the last denominator is written with a 6 over an 8. The correct value is <b>P²a³/(6EI)</b>, since (1/2EI) × (P²a³/3) = P²a³/6EI — the same as U in part ①. This term has no M_B, so it does not affect θ_B." },
        { k: "p", t: "Figure (M p.187), ④: cantilever fixed at A, free at B; load P and a clockwise (fictitious) moment Mc both at C; AC = a, CB = b; section in AC with x measured from C." },
        { k: "eg", title: "MACE notes example — Que 1 ④: slope at C (fictitious moment Mc at C)", given: "Same cantilever (P at C, AC = a, CB = b). Find θc by applying a fictitious moment Mc at C.", steps: [
          { t: "In CB there is no moment, so that integral is zero; in AC, Mx = −P·x − Mc", w: "U = ∫₀ᵇ Mx²·dx/(2EI) [→0] + ∫₀ᵃ (−P·x − Mc)²·dx/(2EI)" },
          { t: "Expand", w: "= ∫₀ᵃ (P²x² + 2P·x·Mc + Mc²)·dx/(2EI)" },
          { t: "Integrate", w: "U = P²a³/(6EI) + 2P·Mc·a²/(4EI) + Mc²·a/(2EI)" },
          { t: "Partially differentiate w.r.t. Mc, then substitute Mc = 0", w: "θc = ∂U/∂Mc = 0 + Pa²/(2EI) + 2Mc·a/(2EI) [→0]" },
        ], ans: "(★) θc = Pa²/(2EI) = θ_B, i.e. (★) θ_B = θc (M p.187)" },
        { k: "h", t: "Conclusions (M p.188)" },
        { k: "p", t: "Figure (M p.188): cantilever fixed at A, free at B; load P at C, AC = a, CB = b. Deflected shape: <b>curved</b> from A to C′ (labelled 'curved (AC′)'), slope at C′ = Pa²/(2EI) = θc; <b>straight line</b> from C′ to B′ (labelled 'straight line (B′C′)'), slope at B′ = Pa²/(2EI) = θ_B. Δc = vertical drop C to C′; a horizontal dashed line from C′ to C″ (vertically below B); C″B′ = b·θc; total Δ_B = BB′ = Δc + b·θc." },
        { k: "steps", items: [
          "In triangle C′C″B′: θc = opposite/adjacent = C″B′/b (M p.188)",
          "(★) <b>C″B′ = b·θc</b> (M p.188)",
          "(★) <b>Δ_B = Δc + b·θc</b> &nbsp;&amp;&nbsp; (★) <b>θ_B = θc</b> (M p.188)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "C ke aage (CB portion) koi moment nahi hai, isliye wahan curvature zero — beam ka woh hissa <b>seedhi line</b> ki tarah girta hai. Isliye B ka slope wahi hai jo C ka (θ_B = θc), aur B ka deflection = C ka deflection + seedhi line ka extra girna (b × θc). Castigliano ka lamba algebra yahi simple geometry confirm karta hai." },
        { k: "p", t: "Δ_B ke liye P′ wala calculation lamba hai, par 2–3 lines ka shortcut yaad rakho: Δ_B = Pa³/3EI + (Pa²/2EI)·b." },
        { k: "trap", t: "Load ke aage wale hisse ko curved maan kar Δ_B = P·L³/3EI (L = a + b) lagana galat hai — load C par hai, B par nahi. Sahi: Δ_B = Pa³/3EI + Pa²b/2EI." },
        { k: "real", t: "Balcony ya chhajja jahan load free end se pehle kisi point par ho (jaise railing post), wahan tip deflection isi Δc + b·θc rule se jaldi check hota hai." },
      ],
    },

    /* ---------------------------------------------------- M p.188–189 */
    {
      n: "",
      title: "MACE notes — Standard results by Castigliano's theorem (Q.2 to Q.7)",
      hi: "कैस्टिग्लियानो प्रमेय से मानक परिणाम (Q.2–Q.7)",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.188–189" },
        { k: "p", t: "<b>V-11</b> (M p.188). Figure, Q.2: cantilever fixed at A, free end B, length L; fictitious load P₁ and clockwise moment M at B; section at distance x from B; deflected curve with Δ_B and θ_B at B." },
        { k: "eg", title: "MACE notes example — Q.2: cantilever with end moment M — slope and deflection at B", given: "Find slope & deflection of the given beam: cantilever of length L, moment M at the free end B (fictitious load P₁ applied at B).", steps: [
          { t: "Formula", w: "U = ∫ Mx²·dx/(2EI)" },
          { t: "Mx = −M − P₁·x", w: "= ∫₀ᴸ (−M − P₁·x)²·dx/(2EI)\n= ∫₀ᴸ (M² + 2P₁·M·x + P₁²x²)·dx/(2EI)" },
          { t: "Integrate", w: "= (1/2EI)[M²·L + 2P₁·M·(L²/2) + P₁²L³/3]\n∴ U = M²L/(2EI) + P₁ML²/(2EI) + P₁²L³/(6EI)" },
          { t: "Deflection", w: "Δ = ∂U/∂P₁ = 0 + ML²/(2EI) + 2P₁·L³/(6EI); now put P₁ = 0" },
          { t: "Slope", w: "θ = ∂U/∂M = 2ML/(2EI) + P₁L²/(2EI) + 0; since P₁ = 0" },
        ], ans: "(★) Δ_B = ML²/(2EI) ; (★) θ_B = ML/(EI) (M p.188)" },
        { k: "p", t: "Figure (M p.188), Q.3: cantilever fixed at A, free end B; point load P at B; section at distance x from B; deflection at B marked 'Δ = ?'." },
        { k: "eg", title: "MACE notes example — Q.3: cantilever with point load P at the free end", given: "Cantilever of length L with point load P at the free end B. Find Δ_B.", steps: [
          { t: "Mx = −P·x", w: "U = ∫₀ᴸ (−P·x)²dx/(2EI) = (P²/2EI)[x³/3]₀ᴸ" },
          { t: "Strain energy", w: "(★) U = P²L³/(6EI)" },
          { t: "Theorem of deflection", w: "Δ_B = ∂U/∂P = 2PL³/(6EI) = PL³/(3EI)" },
        ], ans: "(★) Δ_B = PL³/(3EI) (M p.188)" },
        { k: "p", t: "Figure (M p.188), Q.4: cantilever fixed at A, free end B, length L, UDL W over the full length; fictitious load P₁ at B; section at distance x from B." },
        { k: "eg", title: "MACE notes example — Q.4: cantilever with UDL over the full length — deflection at B", given: "Cantilever of length L carrying UDL W (per unit length) over the whole length. Find Δ_B using a fictitious load P₁ at B.", steps: [
          { t: "Formula", w: "U = ∫₀ᴸ Mx²·dx/(2EI)" },
          { t: "Mx = −P₁·x − W·x·(x/2)", w: "= ∫₀ᴸ (−P₁·x − W·x·(x/2))²·dx/(2EI)\n= (1/2EI)∫₀ᴸ (P₁²x² + 2P₁W·x³/2 + W²x⁴/4)·dx" },
          { t: "Integrate", w: "∴ U = (1/2EI)[P₁²L³/3 + P₁·W·L⁴/4 + W²L⁵/20]" },
          { t: "Differentiate w.r.t. P₁", w: "Δ_B = ∂U/∂P₁ = (1/2EI)[2P₁L³/3 + WL⁴/4 + 0]" },
          { t: "Now put P₁ = 0", w: "Δ_B = (1/2EI)(WL⁴/4)" },
        ], ans: "(★) Δ_B = WL⁴/(8EI) (M p.188)" },
        { k: "p", t: "Figure (M p.189), Q.5: cantilever fixed at A, free end B; AC = L/2, CB = L/2; UDL W over AC only (the fixed-end half); fictitious load P₁ at C; section in AC at distance x measured from C." },
        { k: "eg", title: "MACE notes example — Q.5: cantilever with UDL on the fixed-end half — deflection at C", given: "Calculate deflection at point C: cantilever AB of length L, UDL W over AC (AC = L/2, from the fixed end A), C at mid-length; fictitious load P₁ at C.", steps: [
          { t: "Only AC is stressed; Mx = −P₁·x − W·x²/2", w: "U = ∫₀^(L/2) (−P₁·x − W·x²/2)²·dx/(2EI)\n= (1/2EI)∫₀^(L/2) (P₁²·x² + P₁x·W·x² + W²x⁴/4)·dx" },
          { t: "Integrate", w: "= (1/2EI)[P₁²(x³/3)₀^(L/2) + P₁·W(x⁴/4)₀^(L/2) + (W²/4)(x⁵/5)₀^(L/2)]" },
          { t: "Put limits", w: "∴ U = (1/2EI)[P₁²L³/24 + P₁W·L⁴/64 + W²L⁵/640]" },
          { t: "Differentiate w.r.t. P₁ and put P₁ = 0", w: "Δc = ∂U/∂P₁ = (1/2EI)[WL⁴/64]" },
        ], ans: "(★) Δc = WL⁴/(128EI) (M p.189)" },
        { k: "p", t: "Figure (M p.189), Q.6: simply supported beam A (hinge) – B (roller), span L, point load P at mid-span C (AC = CB = L/2); reactions P/2 upward at A and at B; a section in AC with x from A and a section in CB with x from B." },
        { k: "eg", title: "MACE notes example — Q.6: simply supported beam with central point load — deflection at C", given: "Simply supported beam of span L with point load P at mid-span C. Find Δc.", steps: [
          { t: "Strain energy of the two halves", w: "U = ∫₀^(L/2) Mx²·dx/(2EI) + ∫₀ Mx²·dx/(2EI)  (upper limit L/2, as for the first)" },
          { t: "Mx = (P/2)·x in each half", w: "= (1/2EI)[∫₀^(L/2) ((P/2)x)²dx + ∫₀^(L/2) ((P/2)·x)²·dx]\n= (1/EI)·(P²/4)[x³/3]₀^(L/2)" },
          { t: "Strain energy", w: "∴ (★) U = P²L³/(96EI)" },
          { t: "Theorem of deflection", w: "Δc = ∂U/∂Pc = 2PL³/(96EI)" },
        ], ans: "(★) Δc = PL³/(48EI) (M p.189)" },
        { k: "p", t: "Figure (M p.189), Q.7: simply supported beam A (hinge) – B (roller); moment M at mid-span C (AC = CB = L/2); the reaction at A is marked M/2 downward and the reaction at B M/2 upward (as written); a section in AC with x from A and a section in CB with x from B." },
        { k: "eg", title: "MACE notes example — Q.7: simply supported beam with a moment M at mid-span — slope at C", given: "Simply supported beam of span L with a couple M applied at mid-span C. Find θc.", steps: [
          { t: "Strain energy of the two halves", w: "U = ∫₀^(L/2) Mx²·dx/(2EI) + ∫₀^(L/2) Mx²·dx/(2EI)" },
          { t: "Mx = −(M/L)·x in AC and (M/L)·x in CB", w: "= (1/2EI)[∫₀^(L/2) (−(M/L)·x)²dx + ∫₀^(L/2) ((M/L)·x)²·dx]\n= (1/EI)∫₀^(L/2) (M²x²/L²)·dx" },
          { t: "Integrate", w: "= (1/EI)·(M²/L²)(x³/3)₀^(L/2)\n= (M²/(3EI·L²)) × (L³/8)" },
          { t: "Strain energy", w: "U = M²L/(24EI)" },
          { t: "Theorem of slope", w: "θc = ∂U/∂Mc = 2ML/(24EI)" },
        ], ans: "(★) θc = ML/(12EI) (M p.189)" },
        { k: "note", t: "<b>Check:</b> in the Q.7 figure (M p.189) the support reactions are labelled <b>M/2</b>. For a couple M on a simply supported span L, the reactions are <b>M/L</b> (equal and opposite: taking moments about A, R_B × L = M). The notes' working correctly uses Mx = (M/L)·x, so U = M²L/(24EI) and θc = ML/(12EI) are right; only the figure label should read M/L." },
        { k: "note", t: "<b>Source difference:</b> the MACE notes write moments with the sagging (+) / hogging (−) convention — e.g. Mx = −P·x for a cantilever — and differentiate U after integrating. This chapter's earlier worked example takes M(x) = P·x and uses δ = ∫(∂M/∂P)(M/EI)dx. Both are right and give the same PL³/(3EI): U contains M², so the sign of M drops out, and differentiating under the integral sign before integrating gives the same result as integrating first. The ∂M/∂P route is shorter for long problems such as Que 1 ②." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Yeh sab woh standard results hain jo pehle double integration se aate the — PL³/3EI, ML²/2EI, ML/EI, WL⁴/8EI, PL³/48EI. Castigliano se same answers aana confirm karta hai ki method sahi hai. Har question mein steps same hain: Mx likho (fictitious load/moment ke saath) → square → integrate → differentiate → fictitious = 0." },
        { k: "p", t: "Q.5 mein trick: C ke aage (CB) koi load nahi, aur C ka deflection sirf AC hisse ke bending se aata hai — isliye L/2 lambe cantilever par UDL wala result: W(L/2)⁴/8EI = WL⁴/128EI." },
        { k: "trap", t: "Q.6 mein Δc = ∂U/∂P sirf isliye kaam karta hai kyunki P khud C par hai. Agar load kahin aur ho aur deflection C par chahiye, to C par fictitious P′ lagana zaroori hai — actual P se differentiate karne par P ke neeche ka deflection milega, C ka nahi." },
        { k: "real", t: "Frames aur curved members (arches, rings) mein yahi energy approach direct use hoti hai, jahan formula table available nahi hoti." },
      ],
    },

    /* ---------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Strain energy method (M p.183–189)",
      hi: "पुनरावृत्ति — विकृति ऊर्जा विधि",
      blocks: [
        { k: "h", t: "✅ Key points from the MACE notes" },
        { k: "list", items: [
          "Strain energy = internal work done by external loading/moment; most suitable for cantilevers, frames &amp; arches. (M p.183)",
          "Derivation chain: ds = R·dθ → dθ = ds/R; M/I = E/R → dθ = ds·M/EI; du = ½·M·dθ; ds ≈ dx. (M p.183–184)",
          "(★★) <b>U = ∫Mx²dx/(2EI)</b>, Mx = BM equation of each portion with its own limits. (M p.184)",
          "Cantilever, end moment M: <b>U = M²L/(2EI)</b>. (M p.184)",
          "Non-prismatic cantilever (EI on free half, 2EI on fixed half), end moment M: <b>U = 3M²L/(8EI)</b>. (M p.185)",
          "U ∝ L (linear) ⇒ U₁ + U₂ = U for length pieces; U ∝ P² (non-linear) ⇒ U₁ + U₂ &lt; U for load pieces. (M p.185)",
          "Strain energy method: prismatic &amp; non-prismatic members; works with internal hinges (discontinuity); based on conservation of energy → Castigliano's theorem. (M p.185)",
          "Theorem of deflection: <b>∂U/∂P = y</b> under the load; fictitious load P′ where there is none, set P′ = 0 at the very end. (M p.185)",
          "Theorem of slope: <b>∂U/∂M = θ</b> under the moment; fictitious moment M′ where there is none, set M′ = 0 at the end. (M p.186)",
          "Cantilever, P at C (AC = a, CB = b): <b>Δc = Pa³/(3EI)</b>, <b>θc = θ_B = Pa²/(2EI)</b>, <b>Δ_B = Pa³/(3EI) + Pa²b/(2EI) = Δc + b·θc</b>. (M p.186–188)",
          "Beyond the load (CB) the elastic curve is a straight line; C″B′ = b·θc. (M p.188)",
          "Cantilever, end moment M: <b>Δ_B = ML²/(2EI)</b>, <b>θ_B = ML/(EI)</b>. (M p.188)",
          "Cantilever, end load P: <b>U = P²L³/(6EI)</b>, <b>Δ_B = PL³/(3EI)</b>. (M p.188)",
          "Cantilever, UDL W full length: U = (1/2EI)[P₁²L³/3 + P₁WL⁴/4 + W²L⁵/20]; <b>Δ_B = WL⁴/(8EI)</b>. (M p.188)",
          "Cantilever, UDL W on fixed-end half: <b>Δc = WL⁴/(128EI)</b> at mid-length. (M p.189)",
          "SSB, central load P: <b>U = P²L³/(96EI)</b>, <b>Δc = PL³/(48EI)</b>. (M p.189)",
          "SSB, couple M at mid-span: <b>U = M²L/(24EI)</b>, <b>θc = ML/(12EI)</b> (reactions are M/L; figure label M/2 is a slip). (M p.189)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
