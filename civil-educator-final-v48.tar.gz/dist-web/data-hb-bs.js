/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING SERVICES & SAFETY
   ------------------------------------------------------------
   The twelfth handbook. It covers the invisible half of a
   building — water in, waste out, and the fire-safety systems —
   as a civil engineer designs them, mostly to the National
   Building Code (NBC).

   One idea runs through it: services are judged not by how they
   look but by what happens when they fail — a dry trap lets the
   sewer in, a blocked exit traps people in a fire. So the whole
   subject is about designing for the bad day.

   Values follow the National Building Code (NBC 2016, an SP-7
   BIS publication) and related IS codes, named at the point of
   use. Confirm against the current code before using a value on
   real work.

   Chapters 1–2 here; later chapters follow in data-hb-bs2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "bs",
  subject: "building-services",
  name: "Building Services & Safety",
  hi: "भवन सेवाएँ एवं सुरक्षा",
  icon: "🚰",
  blurb: "Paani andar, waste bahar, aur aag se surakcha — building ka wo aadha hissa jo dikhta nahi par jiske bina rehna mumkin nahi. NBC ke hisaab se.",
  note: "Values follow the National Building Code (NBC 2016) and related IS codes, named where they apply. They are quoted for learning; confirm against the current code before using one on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "bs-1",
      n: 1,
      title: "The Invisible Half of a Building",
      hi: "भवन का अदृश्य आधा",
      blurb: "What building services are, why they are judged by how they fail rather than how they look, and where the National Building Code fits.",
      mins: 16,
      sections: [
        {
          n: "1.1",
          title: "Structure keeps it standing; services keep it livable",
          hi: "सेवाएँ भवन को रहने योग्य बनाती हैं",
          blocks: [
            { k: "p", t: "A building is roughly half structure and half services, and the services are the half you do not see: the water piped in and stored, the waste carried out, the air moved, the power and light, and the fire-safety systems protecting all of it. A structurally perfect building with no water, no drainage and no fire escape is uninhabitable — the services are what make the space fit to occupy." },
            { k: "dia", id: "hb-bs-services", cap: "The services that make a building livable and safe." },
            { k: "p", t: "This handbook covers the services a civil engineer designs into a building — water supply, drainage and sanitation, and fire safety — as opposed to the deep process theory of treating water and sewage, which is a subject of its own. The focus is the building: getting clean water to every tap, foul water safely away, and everyone out alive in a fire." },
            { k: "note", t: "The governing document for most of this is the National Building Code (NBC) — a BIS publication (SP 7) — which sets the rules for water demand, drainage, means of escape, fire resistance and much more. Where a structural handbook leans on IS 456 or IS 800, this one leans on the NBC. It is a BIS code, not a foreign or IRC document." },
          ],
        },
        {
          n: "1.2",
          title: "Designed for the bad day",
          hi: "बुरे दिन के लिए डिज़ाइन",
          blocks: [
            { k: "p", t: "The thread running through every chapter is that services are judged by what happens when things go wrong, not by how they look on a normal day. A drainage system looks the same whether or not its traps are sealed — until the day sewer gas fills the bathroom. An exit corridor looks fine — until the day it is full of smoke and people. Good services design is imagining the bad day and building for it." },
            { k: "list", items: [
              "<strong>Water</strong> — designed for the day the mains fails, which is why buildings store water rather than rely on continuous supply.",
              "<strong>Drainage</strong> — designed so foul gas can never enter the building, even when a trap is siphoned or a pipe surges.",
              "<strong>Fire safety</strong> — the whole discipline is about one bad day, engineered so people escape before the building is lost.",
            ] },
            { k: "real", t: "Nobody notices services when they work — a tap runs, a drain empties, an exit sign glows unremarked for years. They become visible only in failure: the dry tank, the smelling drain, the locked fire door found blocked after a tragedy. <strong>The measure of services design is the disaster that did not happen</strong>, which makes it easy to under-value and dangerous to skimp." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "bs-2",
      n: 2,
      title: "Water Demand and Storage",
      hi: "जल माँग और भंडारण",
      blurb: "How much water a building needs, why it is stored high on the roof, and a worked demand-and-tank calculation.",
      mins: 20,
      sections: [
        {
          n: "2.1",
          title: "How much, and why store it high",
          hi: "कितना, और ऊँचाई पर क्यों",
          blocks: [
            { k: "p", t: "Sizing a building's water supply starts with the demand — how much water the occupants will use in a day — and then arranges to store and deliver it despite an intermittent, low-pressure mains. The universal answer is to store high and feed by gravity." },
            { k: "dia", id: "hb-bs-water", cap: "The underground-tank, pump, overhead-tank down-feed system." },
            { k: "def", term: "Per-capita demand", t: "The water one person uses per day, the basis of the whole calculation. The NBC gives figures by building type — of the order of 135 litres per person per day for residential buildings (more for hospitals, less for schools). Multiply by the number of occupants for the daily demand." },
            { k: "def", term: "Down-feed system", t: "Water is pumped once from an underground tank (filled by the mains) up to an overhead tank on the roof, and then feeds every tap below by gravity. The height of the overhead tank provides the pressure, so the pump only fills the tank rather than running continuously — steady pressure with a small pump." },
            { k: "eg", title: "Example 2.1 — Demand and overhead tank for a housing block",
              given: "A residential block houses 200 people. Using a per-capita demand of 135 litres/person/day, find the daily water demand and a reasonable overhead-tank size (take the overhead tank as half a day's storage).",
              steps: [
                { t: "Daily demand", w: "200 × 135 = 27 000 litres/day = 27 m³/day" },
                { t: "Overhead tank (½ day)", w: "27 000 / 2 = 13 500 litres = 13.5 m³" },
              ],
              ans: "About 27 m³ of water a day, with an overhead tank of roughly 13.5 m³. The underground tank is usually larger (a full day or more, to ride out longer mains outages), and where the building needs a fire reserve, that is added on top. Every figure traces to the per-capita demand and the number of occupants." },
          ],
        },
        {
          n: "2.2",
          title: "Keeping the stored water clean",
          hi: "संग्रहित जल स्वच्छ रखना",
          blocks: [
            { k: "p", t: "Storing water introduces its own risk: standing water can become contaminated, and a poorly designed tank or plumbing layout can let foul water back into the clean supply. Two ideas guard against it." },
            { k: "def", term: "Cross-connection and back-flow", t: "A cross-connection is any point where the clean supply could be contaminated by used or foul water — for example a hose left submerged in a tank, or a tap below the flood level of a fixture. Back-flow is when a drop in supply pressure sucks that foul water back into the clean pipes. Air gaps and non-return valves prevent it." },
            { k: "trap", t: "The classic cross-connection is a tap or inlet pipe whose outlet sits below the water level of the tank or basin it fills. If the supply pressure drops, the contaminated water is siphoned back into the clean main. The rule is a physical air gap between any outlet and the highest possible water level below it — clean water must always fall into foul, never be able to be sucked back. It is a plumbing detail with public-health consequences." },
            { k: "note", t: "Tanks must also be covered, cleaned periodically, and made of non-toxic material, and overflow and vent pipes must be screened against insects and vermin. Stored water is only as safe as the tank keeping it — which is why the NBC and local plumbing codes are strict about tank construction and layout, not just capacity." },
          ],
        },
      ],
    },

  ],
});
