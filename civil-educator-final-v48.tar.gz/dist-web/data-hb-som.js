/* ============================================================
   STRENGTH OF MATERIALS · COMPLETE NOTES — Chapters 1–4
   Properties of materials, stress & strain · Elastic constants
   & compound stresses · Centroid, MOI & SFD/BMD · Theory of
   bending & shear stress in beams
   Source: condensed handwritten class notes (17 pp); Ch.1 deepened
   in v27 via web research (see claude/research-log-som.md)
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];
DB.handbooks.push({
  id: "som", subject: "strength-of-materials",
  name: "Strength of Materials — Complete Notes",
  hi: "पदार्थ सामर्थ्य — सम्पूर्ण नोट्स", icon: "📏",
  blurb: "SOM ke saare core concepts — material properties aur stress-strain, elastic constants aur compound stresses, theories of failure, centroid/MOI aur SFD-BMD, bending aur shear, deflection aur columns, torsion aur springs, cylinders aur dams, strain energy methods — 8 chapters, 56 worked examples, 21 diagrams. Original 17-page class notes ke har fact par page number (p.N); web research se juda har naya fact source-linked; notes ki galtiyan Note boxes mein khule taur par theek ki gayi hain.",
  note: "Source: condensed class notes (17 pages) — page numbers (p.N) on note-derived blocks — deepened chapter by chapter in Phase 1 (v26–v33) with web-researched, cross-checked material and linked sources. Full audit trail: claude/research-log-som.md. v48: the complete MACE Academy SOM class notes (226 pages) are added chapter by chapter in 📘 MACE notes sections, cited as M p.N; every numerical re-worked, slips shown in Check notes, and differences from the older notes shown in Source-difference notes.",
  chapters: []
});
(DB.handbooks || []).find(function (h) { return h.id === "som"; }).chapters.push(

  /* ============================================================ CH 1
     v27 — rebuilt through the Phase 1 chapter quality gate. Every
     block from the original class notes is kept and still cited
     (p.N); errors in those notes are corrected openly in "note"
     blocks rather than silently; new material is web-researched
     and cited with links. Research log: claude/research-log-som.md */
  {
    id: "som-1",
    n: 1,
    title: "Properties of Materials, Stress and Strain",
    hi: "पदार्थों के गुण, प्रतिबल एवं विकृति",
    blurb: "The foundation chapter: basic assumptions and units, material classification, every type of stress (direct, shear — single/double/punching — bearing, bending) and strain, the full tensile test with the mild-steel and TMT stress-strain curves, true vs engineering stress, ductility measures, IS 1786 bar grades, hardness/impact/fatigue/creep, and factor of safety vs IS partial safety factors — with 7 worked examples.",
    mins: 45,
    sections: [
      /* ------------------------------------------------ 1.1 */
      {
        n: "1.1",
        title: "What Strength of Materials studies — assumptions and units",
        hi: "पदार्थ सामर्थ्य क्या पढ़ता है — मान्यताएँ और इकाइयाँ",
        blocks: [
          { k: "h", t: "📘 Notes — p.1" },
          { k: "p", t: "In Statics we study the behaviour of a rigid body, but in practice no material is rigid — all materials deform. Study of such materials is known as <b>mechanics of deformable body</b> or <b>Strength of Materials</b>. (or) The resistance by which the material of a body opposes the deformation is called Strength of Materials. (p.1)" },
          { k: "h", t: "📘 The three questions every SOM problem answers" },
          { k: "list", items: [
            "<b>Strength</b> — will the member break or yield? (compare the stress with the material's yield/ultimate stress)",
            "<b>Stiffness</b> — will it deform too much? (compare elongation/deflection with an allowable limit)",
            "<b>Stability</b> — will it buckle suddenly even though stress is low? (slender columns — <a href=\"#/read/som/5\">Chapter 5.4</a>)",
          ] },
          { k: "h", t: "📘 Basic assumptions of elementary SOM" },
          { k: "p", t: "All the formulas in Chapters 1–8 rest on a few simplifying assumptions. Knowing them tells you <i>when a formula stops being valid</i>. (General engineering knowledge — stated in every standard SOM text.)" },
          { k: "list", items: [
            "<b>Continuous</b> — no voids or cracks; stress can be defined at every point.",
            "<b>Homogeneous</b> — same properties at every point (steel ✔; concrete only approximately, because it is aggregate + paste).",
            "<b>Isotropic</b> — same properties in every direction (steel ✔; timber ✘ — strong along the grain, weak across it).",
            "<b>Linear elastic</b> — stress ∝ strain (Hooke's law) and fully recoverable, i.e. we stay below the proportional limit (§1.5).",
            "<b>Small deformations</b> — geometry hardly changes under load, so equilibrium is written on the <i>original</i> shape and areas.",
            "<b>Saint-Venant's principle</b> — away from the point of loading the stress spreads out evenly, so a concentrated end load can be treated as uniform stress over the section (§1.3).",
          ] },
          { k: "h", t: "📘 Units you will meet" },
          { k: "cmp", t: "Stress units (stress = force ÷ area)", cols: ["Equivalent", "Typical use"], rows: [
            ["1 N/mm²", "= 1 MPa = 10⁶ N/m²", "Design codes (IS 456, IS 800) — the working unit in India"],
            ["1 kN/m²", "= 1 kPa = 0.001 N/mm²", "Soil pressure, floor loads"],
            ["1 GPa", "= 1000 N/mm² = 1 kN/mm²", "Modulus of elasticity (steel E = 200 GPa)"],
            ["1 kgf/cm²", "≈ 0.0981 N/mm²", "Older books, gauges and lab machines"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Statics mein beam ko 'rigid' maan ke reactions nikaale. SOM ek step aage jaata hai — ab poochta hai ki un forces se <b>andar</b> kya ho raha hai: har mm² par kitna load (stress), aur member kitna khincha/daba (strain). Assumptions isliye important hain kyunki har formula unpar tika hai — jaise timber par isotropic formula lagaoge to grain ke across wrong answer aayega." },
          { k: "trap", t: "Stress aur pressure dono ki unit N/mm² hai, par woh ek cheez nahi. Pressure ek <b>external</b> load hai jo surface par lagta hai; stress body ke <b>andar</b> ka resisting force per unit area hai. Ek hi external load se andar alag-alag planes par alag stress hota hai (<a href=\"#/read/som/2\">Chapter 2.3</a> — inclined planes)." },
        ],
      },

      /* ------------------------------------------------ 1.2 */
      {
        n: "1.2",
        title: "Classification of materials by how they deform",
        hi: "विरूपण के आधार पर पदार्थों का वर्गीकरण",
        blocks: [
          { k: "h", t: "📘 Notes — p.1" },
          { k: "def", term: "Rigid Material", t: "Does not undergo any deformation when subjected to an external loading. Example: glass, cast iron. (p.1)" },
          { k: "note", t: "<b>Correction to the notes:</b> no real material is rigid — 'rigid body' is an <i>idealisation</i> used in Statics (that is exactly why SOM exists, per §1.1). Glass and cast iron deform very little before breaking, which makes them <b>brittle</b> (see below), not rigid. Read 'rigid' as 'deformation negligible for the purpose at hand'." },
          { k: "def", term: "Elastic Material", t: "Undergoes deformation under external loading such that the deformation disappears on removal of the load. Example: rubber. (p.1)" },
          { k: "def", term: "Plastic Material", t: "Undergoes continuous deformation during the period of loading, and the deformation is <b>permanent</b> — it does not regain its original dimensions on removal of the load. Example: aluminium. (p.1)" },
          { k: "note", t: "Aluminium (like steel) is elastic at low stress and plastic only beyond yield — so it is better described as <i>elasto-plastic</i>. Materials that are plastic at almost any stress at room temperature are clay, putty, wet mortar and lead. Every metal shows both behaviours; which one you see depends on whether the stress is below or above the elastic limit (§1.5). (General engineering knowledge.)" },
          { k: "def", term: "Ductile Material", t: "Undergoes a large amount of deformation without rupture; must possess a high degree of plasticity and strength (large diameter drawn into a thin wire). Example: mild steel. (p.1)" },
          { k: "def", term: "Brittle Material", t: "Exhibits negligible deformation before it fractures — lack of ductility, rupture with little or no plastic deformation. Example: glass, cast iron, concrete. (p.1)" },
          { k: "def", term: "Malleability", t: "A material's ability to be hammered out into thin sheets. Example: lead, slate. (p.1)" },
          { k: "note", t: "<b>Correction to the notes:</b> <i>slate</i> is a metamorphic rock — it splits along its cleavage planes but shatters if hammered, so it is brittle, not malleable. Correct examples of malleable materials: gold, silver, copper, aluminium, lead, wrought iron. (General engineering knowledge.)" },
          { k: "h", t: "📘 By direction and uniformity of properties" },
          { k: "cmp", t: "Homogeneous, isotropic, anisotropic, orthotropic", cols: ["Meaning", "Civil example"], rows: [
            ["Homogeneous", "Same composition and properties at every point", "Structural steel"],
            ["Isotropic", "Same elastic properties in every direction", "Steel; concrete treated as isotropic in design"],
            ["Anisotropic", "Properties differ with direction", "Rock with bedding, fibre composites"],
            ["Orthotropic", "Different properties along three mutually perpendicular axes", "Timber (along grain / radial / tangential), plywood"],
          ] },
          { k: "p", t: "This matters because an isotropic material needs only <b>two</b> independent elastic constants (E and μ), while an orthotropic one like timber needs nine — which is why <a href=\"#/read/som/2\">Chapter 2</a>'s E–G–K–μ relations apply to steel but not to timber across the grain. (General engineering knowledge.)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh saari properties ek hi spectrum par baithti hain — kitna deformation aur kitna permanent hai. Elastic material deform hota hai par wapas 100% original shape mein aa jaata hai. Plastic material deform hoke wahin ruk jaata hai (permanent). Ductile aur brittle dono fracture tak jaate hain, par ductile bahut zyada deform hoke (large strain) fracture hota hai jabki brittle bina zyada warning ke, kam deformation mein hi tut jaata hai." },
          { k: "real", t: "Isi liye RCC mein ductile steel ko brittle concrete ke saath lagaya jaata hai — beam fail ho to steel pehle yield kare aur badi cracks/deflection se warning de ('under-reinforced' design). IS 13920 ka poora seismic detailing isi ductility par tika hai." },
          { k: "trap", t: "Ductile ≠ Malleable — dono alag tests hain. Ductility wire mein khinchne ki (tension) ability hai, malleability sheet mein peetne ki (compression/hammering) ability. Mild steel dono mein achha hai, lekin lead malleable hai par bahut ductile nahi." },
        ],
      },

      /* ------------------------------------------------ 1.3 */
      {
        n: "1.3",
        title: "Stress — direct, shear (single, double, punching), bearing and bending",
        hi: "प्रतिबल — प्रत्यक्ष, अपरूपण, धारण और बंकन",
        blocks: [
          { k: "h", t: "📘 Notes — p.3" },
          { k: "def", term: "Stress", t: "The force of resistance per unit area offered by a body against deformation — also called intensity of stress. (p.3)" },
          { k: "def", term: "Direct (Normal) Stress (σ)", t: "Stress that acts normal to the surface (load acting perpendicular to the c/s plane); can be either <b>tensile</b> or <b>compressive</b>. σ = (Applied load)/(Original c/s area resisting the force). Tensile stress lengthens the object, compressive stress shortens it. (p.3)" },
          { k: "eq", expr: "σ = P / A", where: [
            ["P", "axial load (N) — acting through the centroid of the section"],
            ["A", "cross-sectional area perpendicular to P (mm²)"],
            ["sign", "tension +, compression − (the convention used throughout this handbook)"],
          ] },
          { k: "def", term: "Shear Stress (τ)", t: "Results when a member is subjected to a force (shear force) that is parallel or tangential to the surface. (p.3)" },
          { k: "eq", expr: "Average shear stress  τ = V / A_shear", where: [
            ["V", "shear force on the plane (N)"],
            ["A_shear", "area of the plane being sheared — NOT the area perpendicular to the load"],
          ] },
          { k: "h", t: "📘 Single shear, double shear and punching shear" },
          { k: "p", t: "In a bolted or pinned joint the key question is: <b>across how many planes is the bolt being cut?</b> In a lap joint the bolt is cut across one plane (single shear); in a butt joint with two cover plates, or a clevis/fork joint, it is cut across two (double shear), so each plane carries only half the load (<a href=\"https://www.purdue.edu/freeform/me323/wp-content/uploads/sites/2/2022/01/03_shear_stress_strain.pdf\" target=\"_blank\" rel=\"noopener\">Purdue ME 323 notes</a>)." },
          { k: "dia", id: "hb-som-shear" },
          { k: "eq", expr: "Single shear: τ = P / (πd²/4)   ;   Double shear: τ = P / (2 · πd²/4)   ;   Punching: P = τ_u · (π·d·t)", where: [
            ["d", "bolt/pin diameter — or, for punching, the hole diameter (mm)"],
            ["t", "plate thickness (mm)"],
            ["π·d·t", "the curved cylindrical surface that is sheared out when a punch makes a hole"],
            ["τ_u", "ultimate shear strength of the plate material (N/mm²)"],
          ] },
          { k: "def", term: "Bearing Stress (σ_b)", t: "The contact compressive pressure between separated bodies when they are connected by bolts, pins or rivets. σ_b = F/A_b = F/(t·d), where A_b = projected contact area = plate thickness × bolt diameter. (p.3)" },
          { k: "def", term: "Bending Stress (f)", t: "The stress developed to resist the bending moment — a combination of both tensile and compressive stress. f = M/Z = (Bending moment)/(Section modulus). (p.3) — derived fully in <a href=\"#/read/som/4\">Chapter 4</a>." },
          { k: "h", t: "📘 Where σ = P/A is not the whole story — stress concentration" },
          { k: "p", t: "σ = P/A gives the <i>average</i> stress. Near a hole, notch or sudden change of section the stress peaks well above that average. The <b>stress concentration factor</b> K_t = σ_max / σ_nominal (nominal = load ÷ net area). For a small circular hole in a wide plate under tension K_t ≈ 3 — the stress at the edge of the hole is three times the average (<a href=\"https://medesign.seas.upenn.edu/index.php/Courses.MEAM247-10C-P3-background\" target=\"_blank\" rel=\"noopener\">UPenn MEAM 247</a>). By <b>Saint-Venant's principle</b> the disturbance dies out within roughly one member-width of the hole or load point, after which P/A is accurate again (same source)." },
          { k: "note", t: "For ductile steel under static load, local yielding at the hole edge redistributes stress, so codes design bolted members on net-area average stress. Stress concentrations matter most for <b>brittle</b> materials and for <b>fatigue</b> (§1.6), where cracks start exactly at these peaks. (General engineering knowledge.)" },
          { k: "eg", title: "Worked example 1.1 — bolt in double shear, and bearing", given: "A 16 mm bolt joins a 12 mm main plate between two 8 mm cover plates (double cover butt joint). Pull P = 60 kN. Find: (a) shear stress in the bolt, (b) bearing stress on main plate and on each cover plate.", steps: [
            { t: "Concept — count shear planes: main plate is sandwiched by two covers, so the bolt is cut across 2 planes → double shear.", w: "Area of one shear plane = π·16²/4 = 201.06 mm²" },
            { t: "(a) Shear stress", w: "τ = P / (2 × 201.06) = 60 000 / 402.12 = 149.2 N/mm²\n(If it were wrongly taken as single shear: 298.4 N/mm² — double!)" },
            { t: "(b) Bearing on the main plate — it carries the full P over thickness 12 mm", w: "σ_b = P / (d·t) = 60 000 / (16 × 12) = 312.5 N/mm²" },
            { t: "Bearing on each cover plate — each carries P/2 over thickness 8 mm", w: "σ_b = 30 000 / (16 × 8) = 234.4 N/mm²" },
          ], ans: "τ = 149.2 N/mm²; bearing governs on the main plate at 312.5 N/mm² (covers 234.4 N/mm²). Interpretation: bearing is checked on the thinner of 't_main' and 'sum of cover thicknesses' (12 < 16 mm here) — that is where the hole edge is most likely to crush or elongate." },
          { k: "eg", title: "Worked example 1.2 — punching a hole", given: "A 20 mm diameter hole is punched in a 10 mm thick steel plate of ultimate shear strength 300 N/mm². Find: the punching force, and the compressive stress in the punch.", steps: [
            { t: "Concept — the punch shears out a cylinder; the sheared surface is its curved side.", w: "A_shear = π·d·t = π × 20 × 10 = 628.3 mm²" },
            { t: "Punching force", w: "P = τ_u · A_shear = 300 × 628.3 = 188 496 N ≈ 188.5 kN" },
            { t: "Compressive stress in the punch (load ÷ punch cross-section)", w: "σ_c = 188 496 / (π·20²/4) = 188 496 / 314.16 = 600 N/mm²" },
          ], ans: "P ≈ 188.5 kN; punch stress = 600 N/mm². Interpretation: the punch must be hardened tool steel — 600 N/mm² is well beyond mild steel's ~250 N/mm² yield. For a thicker plate the force rises in direct proportion to t." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Shear area ko hamesha 'woh surface jo kategi' socho. Bolt mein woh bolt ka circle hai (πd²/4) — har plane ke liye ek baar. Punching mein plate ka cylinder-shaped tukda nikalta hai, to kategi uski <b>side wall</b> — π·d·t. Bearing mein bolt plate ke hole ko dabata hai, aur area ko simple rakhne ke liye curved surface ki jagah uska projection (d × t) lete hain." },
          { k: "real", t: "Bearing stress ka formula (σ_b = F/(t·d)) site par bolt/pin connections ke design mein directly use hota hai — plate ki thickness (t) aur bolt diameter (d) ka product hi projected contact area maana jaata hai, actual curved contact area nahi. (p.3) Steel truss ke gusset joints, crane hooks ke pin aur formwork ke tie-rods — sab mein shear + bearing dono check hote hain." },
          { k: "trap", t: "Sabse common galti: double-shear joint mein P ko seedha πd²/4 se divide kar dena (answer double aata hai), ya punching mein plate ka cross-section area (πd²/4) le lena jabki kat'ta hai π·d·t. Pehle diagram banao, shear planes gino, phir formula lagao." },
        ],
      },

      /* ------------------------------------------------ 1.4 */
      {
        n: "1.4",
        title: "Strain — linear, lateral, shear, volumetric and superficial",
        hi: "विकृति — रेखीय, पार्श्व, अपरूपण, आयतनिक और सतही",
        blocks: [
          { k: "h", t: "📘 Notes — p.4" },
          { k: "def", term: "Strain", t: "The rate of change of dimension — an amount of deformation an object experiences compared to its original size & shape due to simple stresses. (p.4)" },
          { k: "def", term: "Direct or Normal Strain (e)", t: "Strain caused due to direct tensile/compressive stress or force. e = (Change in dimension)/(Original dimension). (p.4)" },
          { k: "eq", expr: "Longitudinal strain  ex = ΔL/L  (strain in the direction of force)  ;  Lateral strain  ey = ΔD/D  (strain perpendicular to the direction of force)", where: [
            ["unit", "strain is a ratio of two lengths — dimensionless (often quoted as mm/mm, %, or 'microstrain' = 10⁻⁶)"],
          ] },
          { k: "p", t: "A bar pulled in tension gets longer <i>and</i> thinner. The ratio of these two strains is a material constant, <b>Poisson's ratio</b> μ = −(lateral strain)/(longitudinal strain); for structural steel μ = 0.3 (<a href=\"https://www.brainkart.com/article/Properties-Of-Structural-Steel_3414/\" target=\"_blank\" rel=\"noopener\">IS 800 cl. 2.2.4.1, via BrainKart</a>). Full treatment with E, G and K in <a href=\"#/read/som/2\">Chapter 2.1</a>." },
          { k: "def", term: "Shear Strain (∅)", t: "The angle through which the body distorts (twist or out of shape) under the application of a shear load. ∅ = BB'/AB. (p.4)" },
          { k: "note", t: "Most textbooks and codes write shear strain as <b>γ</b> (gamma) and use φ for the angle of twist in torsion (<a href=\"#/read/som/6\">Chapter 6.2</a>). The notes' ∅ means the same thing — the change in the original right angle, in radians. Shear strain is the only strain measured as an <i>angle</i>, not a length ratio." },
          { k: "eq", expr: "Volumetric strain  ev = ΔV/V = (3σ/E)(1 − 2μ) = σ/k  ;  ev = ex + ey + ez", where: [
            ["ΔV/V", "change in volume / initial volume"],
          ] },
          { k: "note", t: "<b>Correction to the notes — which loading the formula is for:</b> ev = (3σ/E)(1 − 2μ) holds only when the <i>same</i> stress σ acts in <b>all three</b> directions (hydrostatic stress) — confirmed by <a href=\"https://lkouniv.ac.in/site/writereaddata/siteContent/202004261258145148brijesh_engg_Elastic_Constants.pdf\" target=\"_blank\" rel=\"noopener\">Lucknow University engineering notes</a>. For an ordinary bar under a <b>single axial stress</b> σ, the three strains are σ/E, −μσ/E, −μσ/E, so <b>ev = (σ/E)(1 − 2μ)</b> — one-third of the hydrostatic value. Derived here from first principles; both reduce to ev = ex + ey + ez." },
          { k: "cmp", t: "Volumetric strain — pick the formula by the loading", cols: ["Formula", "Why"], rows: [
            ["Bar, one axial stress σ", "ev = (σ/E)(1 − 2μ)", "ex = σ/E, ey = ez = −μσ/E"],
            ["Cylindrical rod, axial load", "ev = eL + 2·eD = eL(1 − 2μ)", "eD = −μ·eL is negative; diameter strain counted twice because area ∝ D²"],
            ["Equal σ on all three faces", "ev = (3σ/E)(1 − 2μ) = σ/K", "hydrostatic — defines the bulk modulus K"],
            ["General σx, σy, σz", "ev = (σx + σy + σz)(1 − 2μ)/E", "sum the three generalised-Hooke strains"],
          ] },
          { k: "eq", expr: "Superficial (area) strain  eA = ΔA/A = ex + ey", where: [
            ["derivation", "since A = LD, dA = D(dL) + L(dD) ⇒ dA/A = D(dL)/A + L(dD)/A = ΔL/L + ΔD/D = ex + ey (p.4)"],
          ] },
          { k: "note", t: "★ <b>ec = eA = ex + ey</b> — Superficial strain = lateral strain (ey) + longitudinal strain (ex). (p.4)" },
          { k: "eq", expr: "Stretch or Extension ratio (λ) = (Final dimension)/(Initial dimension)  ;  λ = Lf/L = Elongation ratio = 1 − e  ;  λ = Df/D = Stretch ratio = 1 + e", where: [] },
          { k: "note", t: "<b>Correction to the notes — sign of the stretch ratio:</b> since e = (Lf − L)/L, it follows directly that <b>λ = Lf/L = 1 + e</b> for <i>any</i> dimension, with e taken positive for extension and negative for contraction. So in a tension test the length ratio is 1 + e (> 1) and the diameter ratio is 1 − μe (< 1). The notes' '1 − e' for length and '1 + e' for depth swap the signs; use λ = 1 + e with the correct sign of e instead of memorising two formulas." },
          { k: "eg", title: "Worked example 1.3 — stress, strain and volume change of a steel rod", given: "A steel rod 20 mm diameter, 2 m long carries an axial pull of 50 kN. E = 2 × 10⁵ N/mm², μ = 0.3. Find: stress, longitudinal strain, elongation, change in diameter, and change in volume.", steps: [
            { t: "Area", w: "A = π × 20² / 4 = 314.16 mm²" },
            { t: "Stress (σ = P/A)", w: "σ = 50 000 / 314.16 = 159.15 N/mm²  (tension; well below ~250 yield — Hooke's law applies)" },
            { t: "Longitudinal strain (Hooke's law e = σ/E) and elongation", w: "ex = 159.15 / 200 000 = 7.958 × 10⁻⁴\nΔL = ex · L = 7.958 × 10⁻⁴ × 2000 = 1.59 mm" },
            { t: "Lateral strain and change in diameter", w: "ey = −μ·ex = −0.3 × 7.958 × 10⁻⁴ = −2.387 × 10⁻⁴\nΔD = ey · D = −2.387 × 10⁻⁴ × 20 = −0.0048 mm" },
            { t: "Volumetric strain — single axial stress, so use (σ/E)(1 − 2μ)", w: "ev = 7.958 × 10⁻⁴ × (1 − 0.6) = 3.183 × 10⁻⁴\nCheck: ex + 2ey = 7.958 − 4.775 = 3.183 × 10⁻⁴ ✔" },
            { t: "Change in volume", w: "V = A·L = 314.16 × 2000 = 628 319 mm³\nΔV = ev · V = 3.183 × 10⁻⁴ × 628 319 = 200 mm³ (increase)" },
          ], ans: "σ = 159.15 N/mm², ex = 7.96 × 10⁻⁴, ΔL = 1.59 mm, ΔD = −0.0048 mm, ΔV = +200 mm³. Interpretation: the rod gets 1.6 mm longer but only 5 microns thinner — and its volume still increases, because μ < 0.5. Using the hydrostatic formula 3σ(1 − 2μ)/E here would have given 600 mm³ — three times too much." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Superficial strain ka derivation dhyaan se dekho — A = L×D hai, to dono dimensions change honge to area bhi change hoga. Calculus se (product rule) nikalta hai ki area strain lagbhag longitudinal aur lateral strain ka simple sum hai (higher-order term dL·dD negligible maan liya jaata hai). Yeh wahi logic volumetric strain mein teen dimensions (ex+ey+ez) ke liye extend hota hai." },
          { k: "trap", t: "Volumetric strain mein sabse badi galti: single axial load wale bar par hydrostatic formula (3σ/E)(1−2μ) laga dena — answer 3 guna aata hai. Pehle dekho kitni directions mein stress hai, phir ev = ex + ey + ez se khud banao. Doosri galti: stretch ratio ke liye do alag formule ratna — λ = 1 + e hamesha sahi hai, bas e ka sign (extension +, contraction −) sahi lagao." },
        ],
      },

      /* ------------------------------------------------ 1.5 */
      {
        n: "1.5",
        title: "The tensile test and the stress-strain curve",
        hi: "तनन परीक्षण और प्रतिबल-विकृति वक्र",
        blocks: [
          { k: "h", t: "📘 The test itself" },
          { k: "p", t: "A machined bar is gripped in a Universal Testing Machine (UTM) and pulled slowly to fracture while load and extension over a marked <b>gauge length</b> are recorded. Indian practice follows <a href=\"#/code/is1608\">IS 1608 (Part 1)</a> (aligned with ISO 6892-1). Results are only comparable between bars of different sizes if the gauge length is <b>proportional</b> to the bar size: L₀ = 5.65√S₀, where S₀ is the original cross-sectional area (<a href=\"https://infralens.in/code/IS-1608\" target=\"_blank\" rel=\"noopener\">InfraLens — IS 1608</a>). For a round bar this is just L₀ = 5d, since 5.65√(πd²/4) = 5.65 × 0.886 d ≈ 5d (checked; also explained in <a href=\"https://prepp.in/question/gauge-length-of-steel-specimen-as-per-codal-provis-645d2cefe8610180957e0c99\" target=\"_blank\" rel=\"noopener\">Prepp</a>)." },
          { k: "h", t: "📘 Notes — p.2" },
          { k: "def", term: "Hooke's Law", t: "Stress is directly proportional to strain, up to the proportional limit (point A). If the load is removed within this range, the material comes back to its original position 100%. (p.2)" },
          { k: "eq", expr: "σ = E · e     (valid only from O to A)", where: [
            ["E", "modulus of elasticity = slope of the straight part OA; for structural steel E = 2.0 × 10⁵ N/mm² (IS 800 cl. 2.2.4.1)"],
          ] },
          { k: "p", t: "The notes describe the stress (y-axis) vs strain (x-axis) curve for a ductile material like mild steel: O rises straight to A, curves on to a peak at B, dips slightly to C, a flat/wavy segment C–D–E, then rises again through the plastic region to a peak at F, and finally descends to G where the specimen fractures. (p.2)" },
          { k: "dia", id: "hb-som-ss-mild" },
          { k: "list", items: [
            "<b>Point A — Proportional limit:</b> up to A, Hooke's law is obeyed, so OA is a straight line. Also called the Hooke's limit. (p.2)",
            "<b>Point B — Elastic limit:</b> from A to B the material still behaves elastically, but it is <b>not perfectly</b> elastic (95–98%). (p.2)",
            "<b>Point C — Upper yielding point:</b> from B to C the material is in a plastic state (may not come back to its original position). From C it starts yielding — c/s decreases at constant/less load. (p.2)",
            "<b>Point D — Lower yielding point:</b> from C to D the material keeps yielding and the resisting stress decreases; from D the stress does not decrease further but stays constant. (p.2)",
            "<b>Point E — Strain hardening region:</b> the material shows some hardening, so stress must be increased to elongate it further, up to F. (p.2)",
            "<b>Point F — Ultimate point:</b> the corresponding load/stress is the <b>ultimate strength/stress</b>. From F the material will not resist any more load and yields continuously. (p.2)",
            "<b>Point G — Breaking point (point of fracture):</b> the body splits into two parts here. ★ The fracture of a ductile material is of the <b>cup and cone</b> type. (p.2)",
          ] },
          { k: "note", t: "<b>Two clarifications to the notes.</b> (1) <i>A to B:</i> by definition the elastic limit is the highest stress from which the bar <b>fully</b> recovers — so between A and B the behaviour is fully elastic but <b>non-linear</b>; it is not '95–98% elastic'. Any permanent set appears only <i>beyond</i> B (<a href=\"https://www.ae.msstate.edu/vlsm/materials/strength_chars/\" target=\"_blank\" rel=\"noopener\">Mississippi State VLSM</a>). In mild steel A and B are so close that most problems treat them as one point. (2) <i>After F:</i> the bar has not stopped resisting load — it starts <b>necking</b> (a local waist forms), so the load falls because the area at the neck shrinks. Stress on the actual necked area keeps rising to fracture; the curve dips only because engineering stress keeps dividing by the original area." },
          { k: "h", t: "📘 Engineering vs true stress and strain" },
          { k: "eq", expr: "σ_true = σ(1 + e)   ;   ε_true = ln(1 + e)     (valid up to F, i.e. before necking)", where: [
            ["σ, e", "engineering stress (load ÷ original area) and engineering strain"],
            ["basis", "volume stays constant during plastic flow, so A·L = A₀·L₀ ⇒ A = A₀/(1 + e)"],
            ["source", "Government College of Engineering lecture notes (linked below); derivation checked from constant volume"],
          ] },
          { k: "eq", expr: "Max/Ultimate stress = (Load at ultimate point) / (Original c/s area before test)  ;  Yield stress = (Load at yield) / (Original c/s)", where: [] },
          { k: "eq", expr: "Nominal stress = (Load at any point) / (Original c/s area before test)  ;  True (actual) stress = (Load at any point) / (c/s area at that point/load)", where: [] },
          { k: "h", t: "📘 Measures of ductility" },
          { k: "eq", expr: "% Elongation = (L_u − L₀)/L₀ × 100   ;   % Reduction in area = (S₀ − S_u)/S₀ × 100", where: [
            ["L_u", "final gauge length, measured after fitting the two broken halves together"],
            ["S_u", "minimum cross-section at the fracture (the neck)"],
            ["source", "IS 1608 symbols, via InfraLens; same formulas in the GCE notes"],
          ] },
          { k: "h", t: "📘 Steel without a yield point — proof stress" },
          { k: "def", term: "Proof Stress", t: "The stress at a given specified strain (i.e. for proof). Generally, Proof stress = Stress at 0.2% strain (i.e. 0.002 strain). (p.2)" },
          { k: "note", t: "<b>Correction to the notes — how 0.2% proof stress is actually found:</b> it is <i>not</i> the stress read off the curve at 0.002 total strain. A line is drawn <b>parallel to the straight elastic part</b>, starting from 0.002 on the strain axis; the stress where this line cuts the curve is the 0.2% proof stress — i.e. the stress that leaves a <b>permanent</b> (non-proportional) strain of 0.2% after unloading (<a href=\"https://www.ae.msstate.edu/vlsm/materials/strength_chars/\" target=\"_blank\" rel=\"noopener\">Mississippi State VLSM</a>; <a href=\"https://www.brainkart.com/article/Properties-Of-Structural-Steel_3414/\" target=\"_blank\" rel=\"noopener\">BrainKart</a>). For Fe 500 at fy = 500 N/mm², the elastic strain is already 500/200 000 = 0.0025, so reading the curve at 0.002 total strain would land <i>inside</i> the elastic zone and give the wrong answer." },
          { k: "dia", id: "hb-som-ss-proof" },
          { k: "p", t: "High-strength deformed (HYSD/TMT) bars yield gradually — there is no sharp C–D drop — so their 'yield stress' fy in <a href=\"#/code/is1786\">IS 1786</a> is the 0.2% proof stress (<a href=\"https://services.bis.gov.in/tmp/SR1786.pdf\" target=\"_blank\" rel=\"noopener\">BIS — IS 1786 scope</a>). Brittle materials (cast iron, concrete in tension) show almost no plastic zone and break near the peak; concrete in compression is non-linear from the start and IS 456 cl. 38.1 caps its strain at 0.0035 in bending (<a href=\"https://infralens.in/code/IS-456-2000/clause/38-1\" target=\"_blank\" rel=\"noopener\">InfraLens — IS 456 cl. 38.1</a>)." },
          { k: "cmp", t: "IS 1786 reinforcement grades — minimum mechanical properties", cols: ["Min fy (0.2% proof) N/mm²", "Min fu N/mm²", "Min elongation %"], rows: [
            ["Fe 415", "415", "485", "14.5"],
            ["Fe 415D", "415", "500", "18.0"],
            ["Fe 500", "500", "545", "12.0"],
            ["Fe 500D", "500", "565", "16.0"],
            ["Fe 550", "550", "585", "10.0"],
            ["Fe 550D", "550", "600", "14.5"],
            ["Fe 600", "600", "660", "10.0"],
          ] },
          { k: "note", t: "Values above match in two independent summaries of IS 1786:2008 Table 3 (<a href=\"https://infralens.in/handbook/rebar-grades\" target=\"_blank\" rel=\"noopener\">InfraLens</a>; <a href=\"https://engineeringhulk.com/civil/construction-materials/steel-reinforcement-materials/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>). 'D' grades keep the same strength but guarantee higher elongation (BIS scope text above). The standard <i>also</i> requires the actual tensile strength to exceed the actual proof stress by a grade-specific margin (roughly 6–12%); <b>the two summaries disagree on that margin for some grades</b> (e.g. Fe 415: 10% vs 8%), so take the exact figure from Table 3 of the current IS 1786 rather than from either summary. Elongation is measured on the 5.65√S₀ gauge length." },
          { k: "eg", title: "Worked example 1.4 — reducing tensile-test data for a TMT bar", given: "A 12 mm TMT bar is tested. 0.2% proof load = 57 kN, maximum load = 66 kN, gauge length after fracture = 70.2 mm, diameter at the neck = 8.4 mm. Find: gauge length, proof stress, tensile strength, fu/fy, % elongation, % reduction in area — and check against IS 1786 Fe 500D.", steps: [
            { t: "Original area and proportional gauge length", w: "S₀ = π × 12²/4 = 113.10 mm²\nL₀ = 5.65 × √113.10 = 5.65 × 10.635 = 60.1 ≈ 60 mm (= 5d ✔)" },
            { t: "0.2% proof stress (taken as fy) and tensile strength", w: "fy = 57 000 / 113.10 = 504.0 N/mm²\nfu = 66 000 / 113.10 = 583.6 N/mm²\nfu/fy = 583.6 / 504.0 = 1.158" },
            { t: "% elongation", w: "(70.2 − 60) / 60 × 100 = 17.0 %" },
            { t: "% reduction in area", w: "S_u = π × 8.4²/4 = 55.42 mm²\n(113.10 − 55.42) / 113.10 × 100 = 51.0 %" },
            { t: "Check against Fe 500D minimums (table above)", w: "fy 504 ≥ 500 ✔   fu 583.6 ≥ 565 ✔   elongation 17.0 ≥ 16.0 ✔\nfu/fy 1.158 — above both summaries' margins (1.08 / 1.10) ✔" },
          ], ans: "fy = 504 N/mm², fu = 583.6 N/mm², fu/fy = 1.16, elongation 17.0%, reduction in area 51%. The bar meets Fe 500D. Interpretation: a high fu/fy ratio and elongation mean the bar can strain-harden and stretch a long way after yield — exactly the reserve capacity seismic design (IS 13920) relies on." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "C aur D dono ko 'yield point' bola jaata hai par woh same nahi hain — C <b>upper</b> yield point hai (jahan se yielding shuru hoti hai) aur D <b>lower</b> yield point (jahan stress constant ho jaata hai). Isi tarah A (proportional limit, jahan tak Hooke's law linear hai) aur B (elastic limit, jahan tak material wapas original shape le sakta hai) bhi do alag points hain — dono ke beech mein material 'elastic hai magar linear nahi'." },
          { k: "p", t: "TMT bar mein C–D wala 'jhatka' dikhta hi nahi — curve smoothly mud jaata hai. Isliye yield ko ek <b>rule</b> se define karna padta hai: 0.2% permanent set. Offset line elastic part ke parallel isliye kheenchte hain kyunki load hataane par bar isi slope se wapas aata hai — jo strain bachta hai woh permanent hai." },
          { k: "real", t: "Site par TMT bars ka lot aata hai to mill test certificate (MTC) mein yahi numbers hote hain — 0.2% proof stress, UTS, elongation. Third-party lab mein UTM par sample test karke inhe IS 1786 table se compare kiya jaata hai; fail ho to lot reject. Bend/rebend test bhi ductility check ke liye hota hai." },
          { k: "trap", t: "Elastic limit (B) aur proportional limit (A) ko ek mat samjho — inke beech A-B region mein material elastic to hai (load hatane par wapas aata hai) par ab stress-strain linear nahi raha, Hooke's law wahan apply nahi hota. (p.2) Aur 0.2% proof stress ko '0.002 strain par curve ka stress' mat padho — offset line ke saath padho." },
        ],
      },

      /* ------------------------------------------------ 1.6 */
      {
        n: "1.6",
        title: "Mechanical properties — strength, stiffness, hardness, toughness, fatigue and creep",
        hi: "यांत्रिक गुण — सामर्थ्य, दृढ़ता, कठोरता, चीमड़पन, थकान और विसर्पण",
        blocks: [
          { k: "h", t: "📘 Notes — p.1–2" },
          { k: "def", term: "Strength", t: "The power of resisting loads. This is the maximum stress that a material can take, equal to Max load/Area. (p.1)" },
          { k: "def", term: "Stiffness", t: "The power of resisting deformation/deflection. The minimum strain that a material can have, equal to span/deflection. (p.1)" },
          { k: "eq", expr: "Strength = Max load / Area ;  Stiffness = Span / Deflection", where: [
            ["Strength", "maximum stress the material can take (p.1)"],
            ["Stiffness", "resistance to deformation — depends also on EI for a member (p.1)"],
          ] },
          { k: "note", t: "<b>Clarifying the notes' stiffness formula:</b> span/deflection (e.g. 'L/250') is a <i>serviceability ratio</i> used to set deflection limits, not the definition of stiffness. Stiffness is <b>load per unit deformation</b>: k = P/δ. For an axially loaded bar δ = PL/AE (<a href=\"#/read/som/2\">Chapter 2.2</a>), so <b>k = AE/L</b>; for a beam it is proportional to EI/L³ (<a href=\"#/read/som/5\">Chapter 5</a>). At material level, stiffness is measured by E alone. Derived from first principles." },
          { k: "def", term: "Hardness", t: "The ability of a material to resist against surface rupture/abrasion. Diamond has high hardness, whereas chalk-piece has the least hardness. (p.1)" },
          { k: "def", term: "Toughness", t: "The maximum resistance offered by a body up to fracture — the property which enables it to absorb energy without fracture. (p.2)" },
          { k: "def", term: "Fatigue", t: "Structural damage that occurs when a material is subjected to cyclic loading or repeated loading and unloading. The resistance to fatigue is called <b>fatigueness</b>. (p.2)" },
          { k: "note", t: "'Fatigueness' is not a standard term. The resistance to fatigue is expressed as <b>fatigue strength</b> (stress survived for a stated number of cycles) or, for steels, the <b>endurance limit</b> (see below)." },
          { k: "h", t: "📘 Resilience vs toughness — areas under the curve" },
          { k: "eq", expr: "Modulus of resilience u_r = σ_e²/(2E)   ;   Modulus of toughness = total area under the σ–ε curve up to fracture", where: [
            ["σ_e", "stress at the elastic limit"],
            ["u_r", "strain energy per unit volume stored up to the elastic limit — fully recoverable"],
            ["source", "Mississippi State VLSM; full strain-energy treatment in Chapter 6.4 and Chapter 8"],
          ] },
          { k: "p", t: "Resilience = energy a material can absorb and <i>give back</i> (the small triangle under OA/OB). Toughness = energy absorbed <i>until fracture</i> (the whole area). Mild steel is tough because its curve is long; cast iron can be strong yet has low toughness because its curve is short. See <a href=\"#/read/som/6\">Chapter 6.4 (Resilience)</a> and <a href=\"#/read/som/8\">Chapter 8 (Strain energy methods)</a>." },
          { k: "h", t: "📘 Measuring hardness and toughness — standard tests" },
          { k: "cmp", t: "Common mechanical tests and their Indian Standards", cols: ["What it measures", "Indian Standard"], rows: [
            ["Tensile test", "fy / proof stress, fu, elongation, reduction of area", "IS 1608"],
            ["Brinell hardness", "Diameter of a ball indentation → BHN", "IS 1500"],
            ["Rockwell hardness", "Depth of indentation (scales A–K, N, T)", "IS 1586"],
            ["Vickers hardness", "Diagonal of a diamond-pyramid indentation → HV", "IS 1501"],
            ["Izod impact", "Energy to break a notched cantilever specimen", "IS 1598"],
            ["Charpy impact (V-notch)", "Energy to break a notched simply-supported specimen", "IS 1757"],
            ["Fatigue (axial / rotating bending)", "Cycles to failure at a stress amplitude", "IS 5074 / IS 5075"],
            ["Creep (tensile)", "Strain vs time at constant load and temperature", "IS 3407"],
          ] },
          { k: "note", t: "Standard numbers from the BIS Mechanical Testing (MTD 3) list at <a href=\"https://law.resource.org/pub/in/bis/manifest.mtd.3.html\" target=\"_blank\" rel=\"noopener\">Public.Resource.Org</a>. Several of these have since been revised and split into parts — check the current edition before quoting a year." },
          { k: "eq", expr: "BHN = 2P / [ πD ( D − √(D² − d²) ) ]", where: [
            ["P", "test load (kgf)"],
            ["D", "ball diameter (mm) — commonly 10 mm"],
            ["d", "diameter of the indentation (mm)"],
            ["meaning", "load ÷ curved surface area of the dent (kgf/mm²); source: Engineering ToolBox"],
          ] },
          { k: "eg", title: "Worked example 1.5 — Brinell hardness number", given: "A 10 mm ball under 3000 kgf leaves an impression 4.0 mm in diameter on a steel sample. Find: BHN.", steps: [
            { t: "Bracket term (note: this is twice the dent depth)", w: "√(D² − d²) = √(100 − 16) = √84 = 9.165 mm\nD − √(D² − d²) = 10 − 9.165 = 0.835 mm" },
            { t: "BHN", w: "BHN = 2 × 3000 / (π × 10 × 0.835) = 6000 / 26.23 = 228.8" },
          ], ans: "BHN ≈ 229. Interpretation: a smaller dent means a harder surface. Hardness correlates roughly with tensile strength for steels (tables in Engineering ToolBox), which is why a quick hardness check is used to screen steel in the field — but it is a correlation, not a substitute for the tensile test." },
          { k: "h", t: "📘 Fatigue — failure under repeated stress" },
          { k: "p", t: "Fatigue is failure under repeated or cyclic stress, often at stresses <b>below the yield strength</b> (<a href=\"https://www.engr.colostate.edu/laboratories/ceramics/wp-content/uploads/sites/29/2026/05/MECH331A_Ch07_Mechanical-failures.pdf\" target=\"_blank\" rel=\"noopener\">Colorado State MECH 331 notes</a>). A crack starts at a stress concentration (§1.3) — a weld toe, bolt hole or surface scratch — and grows a little with every cycle until the remaining section breaks suddenly. Test results are plotted as an <b>S–N curve</b> (stress amplitude vs number of cycles to failure, N on a log scale)." },
          { k: "def", term: "Endurance limit", t: "For steels the S–N curve flattens out: below a certain stress amplitude the material survives an effectively unlimited number of cycles. Aluminium alloys show no such limit — their fatigue strength keeps falling with more cycles, so it is quoted at a stated number of cycles (Colorado State notes, above)." },
          { k: "h", t: "📘 Creep — deformation that grows with time" },
          { k: "def", term: "Creep", t: "Increase of strain with time under a constant (sustained) stress. Three stages: <b>primary</b> — creep rate decreasing; <b>secondary</b> — steady, constant creep rate (the stage used in design); <b>tertiary</b> — creep rate accelerating until rupture. In metals it becomes significant above roughly 0.4 × melting temperature (in kelvin) (Colorado State notes, above)." },
          { k: "p", t: "For a civil engineer the creep that matters most is in <b>concrete</b>, at ordinary temperature. IS 456 cl. 6.2.5.1 gives the <b>creep coefficient</b> θ = creep strain ÷ elastic strain as <b>2.2</b> (loaded at 7 days), <b>1.6</b> (28 days) and <b>1.1</b> (1 year) — the earlier concrete is loaded, the more it creeps (<a href=\"https://infralens.in/term/creep-coefficient-concrete\" target=\"_blank\" rel=\"noopener\">InfraLens</a>; the 28-day value also confirmed by <a href=\"https://testbook.com/question-answer/as-per-is456-2000-for-28-days-age-at-loading-wh--69eb8a8527e735f92cdf1ab1\" target=\"_blank\" rel=\"noopener\">Testbook</a>). Long-term deflection uses an effective modulus E_ce = E_c/(1 + θ)." },
          { k: "eg", title: "Worked example 1.6 — long-term strain of a concrete column due to creep", given: "An M25 column is loaded at 28 days to a sustained stress of 8 N/mm². E_c = 5000√fck (IS 456 cl. 6.2.3.1). Find: elastic strain, creep strain and effective modulus.", steps: [
            { t: "Short-term modulus", w: "E_c = 5000 × √25 = 25 000 N/mm²" },
            { t: "Elastic (instantaneous) strain", w: "ε_el = 8 / 25 000 = 3.2 × 10⁻⁴" },
            { t: "Creep strain (θ = 1.6 at 28 days)", w: "ε_cr = θ · ε_el = 1.6 × 3.2 × 10⁻⁴ = 5.12 × 10⁻⁴" },
            { t: "Effective long-term modulus", w: "E_ce = 25 000 / (1 + 1.6) = 9615 N/mm²" },
          ], ans: "Elastic 3.2 × 10⁻⁴, creep 5.12 × 10⁻⁴ — total 8.3 × 10⁻⁴, i.e. 2.6 times the day-one shortening. Interpretation: in a 3 m storey column that is about 2.5 mm, and in a tall building the difference between columns and cores adds up floor by floor — why long-term deflections and differential shortening are checked separately." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Strength aur stiffness ko confuse mat karo — ek material strong ho sakta hai (bahut load le sakta hai fracture hone se pehle) par stiff nahi (bahut zyada deflect kar jaata hai). Toughness strength se alag hai — woh energy absorption ki baat karta hai, area under the stress-strain curve, na ki sirf peak stress ki." },
          { k: "p", t: "Fatigue aur creep dono 'time-dependent' failures hain par ulte: fatigue mein load <b>baar-baar badalta</b> hai (cycles), creep mein load <b>constant rehta</b> hai aur strain samay ke saath badhta hai. Dono mein stress yield se kam ho sakta hai — isliye sirf 'stress < fy' check karna kaafi nahi hota." },
          { k: "real", t: "Site par fatigue ka matter cyclic-loaded members mein hota hai — jaise bridge girders, crane runway beams, machine foundations — jahan load baar baar apply/remove hota hai. Ek single overload se failure nahi, balki repeated cycles se microcrack grow karke failure hota hai. (Fatigue ki resistance ko notes mein 'fatigueness' kaha gaya hai, p.2.) Creep ka asar: prestressed concrete mein prestress loss, purane slabs ka dheere-dheere sag, aur early de-shuttering ke baad zyada long-term deflection." },
          { k: "trap", t: "Hardness ≠ toughness. Glass bahut hard hai (scratch nahi hota) par toughness kam hai (ek jhatke mein toot jaata hai). Aur 'strong' ≠ 'stiff' — high-strength steel ka E bhi mild steel jitna hi (≈ 2 × 10⁵) hai, isliye stronger steel use karne se deflection kam nahi hota." },
        ],
      },

      /* ------------------------------------------------ 1.7 */
      {
        n: "1.7",
        title: "Working stress, factor of safety and partial safety factors",
        hi: "कार्यकारी प्रतिबल, सुरक्षा गुणांक और आंशिक सुरक्षा गुणांक",
        blocks: [
          { k: "h", t: "📘 Notes — p.3" },
          { k: "def", term: "Working (or Safe) Stress", t: "The maximum stress to which any member is designed to resist deformation; it is much less than the yield stress, so a factor of safety is applied. (p.3)" },
          { k: "eq", expr: "Working Stress = Yield stress / Factor of Safety   (Ductile materials)  =  Ultimate stress / Factor of Safety   (Brittle materials)", where: [
            ["Brittle case", "used because for brittle materials, Yield stress = Ultimate stress — brittle materials do not possess any yielding (p.3)"],
          ] },
          { k: "list", items: ["Factor of Safety = <b>1.85</b> for Steel. (p.3)", "Factor of Safety = <b>3</b> for Concrete. (p.3)"] },
          { k: "note", t: "<b>Where these numbers come from, and what has replaced them.</b> They belong to the <b>Working Stress Method (WSM)</b>. IS 456 (Annex B) tabulates permissible stresses rather than a single FoS: σ_cbc = 7 N/mm² for M20 and σ_st = 230 N/mm² for Fe 415 (140 for Fe 250, 275 for Fe 500), which imply FoS ≈ 20/7 = 2.86 on concrete and 415/230 ≈ 1.80 on steel (<a href=\"https://engineeringhulk.com/civil/rcc-design/working-stress-vs-limit-state/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — WSM vs LSM</a>). So the notes' 1.85 and 3 are rounded classroom values, slightly different from what the IS tables give — use the tables for any real calculation. Current design uses the <b>Limit State Method</b> with partial safety factors instead (table below)." },
          { k: "cmp", t: "WSM factor of safety vs LSM partial safety factors", cols: ["Working Stress Method", "Limit State Method"], rows: [
            ["Philosophy", "Keep service stresses within the elastic range: permissible stress = strength ÷ FoS", "Separate factors on loads (γf) and on materials (γm); check collapse and serviceability separately"],
            ["Concrete", "σ_cbc ≈ fck/3 (FoS ≈ 3, e.g. 7 N/mm² for M20)", "γm = 1.5 → design flexural strength 0.67fck/1.5 ≈ 0.45 fck (IS 456 cl. 36.4.2)"],
            ["Reinforcing steel", "σ_st = 230 N/mm² for Fe 415 (FoS ≈ 1.8)", "γm = 1.15 → design strength 0.87 fy"],
            ["Structural steel (IS 800:2007)", "Older IS 800:1984 used permissible stresses", "γm0 = 1.10 (yielding), γm1 = 1.25 (ultimate/fracture) — cl. 5.4.1"],
            ["Loads", "Unfactored service loads", "γf = 1.5 for DL + LL; 1.2 for DL + LL + wind/EQ"],
          ] },
          { k: "note", t: "Partial safety factors from <a href=\"https://infralens.in/term/partial-safety-factor\" target=\"_blank\" rel=\"noopener\">InfraLens</a>, cross-checked against EngineeringHulk (0.87 fy, γm = 1.5/1.15). Code pages in this app: <a href=\"#/code/is456\">IS 456</a>, <a href=\"#/code/is800\">IS 800</a>." },
          { k: "eg", title: "Worked example 1.7 — safe tensile load on a bar by WSM and LSM", given: "A 16 mm Fe 415 bar carries pure tension. Find: (a) the permissible service load by WSM (σ_st = 230 N/mm²), (b) the design (factored) capacity by LSM and the service load it corresponds to.", steps: [
            { t: "Area", w: "A = π × 16²/4 = 201.06 mm²" },
            { t: "(a) WSM — permissible stress × area", w: "P_safe = 230 × 201.06 = 46 244 N ≈ 46.2 kN\nImplied FoS = 415/230 = 1.80" },
            { t: "(b) LSM — design strength 0.87 fy", w: "0.87 × 415 = 361.05 N/mm²\nP_d = 361.05 × 201.06 = 72 593 N ≈ 72.6 kN (factored)" },
            { t: "Convert the LSM capacity to a service load (γf = 1.5)", w: "72.6 / 1.5 = 48.4 kN" },
          ], ans: "WSM: 46.2 kN; LSM: 72.6 kN factored ≈ 48.4 kN service. Interpretation: the two methods land close for this simple case (overall safety ≈ 1.15 × 1.5 = 1.73 vs 1.80), but LSM puts the safety where the uncertainty is — more on variable loads, less on well-controlled steel — which gives more consistent reliability across different structures." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Working stress formula brittle materials ke liye ultimate stress use karta hai, ductile ke liye yield stress — kyunki brittle material (jaise concrete, cast iron) mein <b>yielding hoti hi nahi</b>, woh seedha fracture ho jaata hai, isliye unka yield stress = ultimate stress maana jaata hai. Isi wajah se dono formulas alag dikhte hain par concept ek hi hai: 'failure stress' ko FoS se divide karo." },
          { k: "p", t: "Concrete par FoS (≈3) steel (≈1.8) se zyada kyun? Kyunki concrete site par banta hai — mixing, compaction, curing sab mein variation — jabki steel factory mein controlled conditions mein banta hai. Zyada uncertainty = zyada safety factor. LSM mein bhi yahi logic hai: γm concrete 1.5, steel 1.15." },
          { k: "trap", t: "Exam mein 'FoS for steel' poocha jaaye to dekho kaunsa method hai — WSM context mein ≈1.8 (notes: 1.85), LSM context mein γm = 1.15 (RCC steel) ya 1.10 (IS 800 structural steel, yielding). Dono ko mix mat karo, aur LSM ke γm ko 'FoS' mat kaho — woh sirf material ka hissa hai, load factor alag lagta hai." },
        ],
      },

      /* ------------------------------------------------ 1.8 */
      {
        n: "1.8",
        title: "Quick revision — properties, stress and strain",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Assumptions: continuous, homogeneous, isotropic, linear-elastic, small deformation; Saint-Venant's principle (§1.1).",
            "Rigid / elastic / plastic / ductile / brittle / malleable — definitions and correct examples (p.1, with corrections, §1.2).",
            "Direct, shear (single / double / punching), bearing, bending stress formulas; stress concentration K_t ≈ 3 at a small hole (§1.3).",
            "Longitudinal, lateral, shear, volumetric (by loading case), superficial strain; λ = 1 + e (§1.4).",
            "Stress-strain curve: A (proportional limit), B (elastic limit), C (upper yield), D (lower yield), E (strain hardening), F (ultimate), G (fracture) (p.2); necking; true stress (§1.5).",
            "0.2% proof stress by the offset method; IS 1786 grade table; L₀ = 5.65√S₀ (§1.5).",
            "Strength, stiffness (k = AE/L), hardness tests, resilience vs toughness, fatigue & endurance limit, creep & IS 456 creep coefficients (§1.6).",
            "WSM FoS (≈1.8 steel, ≈3 concrete) vs LSM γm (1.5 / 1.15; IS 800: 1.10 / 1.25) (§1.7).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Working Stress = Yield stress/FoS (ductile) = Ultimate stress/FoS (brittle) — because brittle materials have Yield stress = Ultimate stress (p.3).",
            "eA (superficial strain) = ex + ey; ev = ex + ey + ez — which is (σ/E)(1−2μ) for one axial stress but (3σ/E)(1−2μ) = σ/k for equal stress on all three faces (p.4, corrected).",
            "Bending stress f = M/Z; Bearing stress σb = F/(t·d) (p.3); double shear halves the bolt shear stress.",
            "Ductile fracture is cup-and-cone type; brittle fracture has negligible plastic deformation (p.1–2).",
            "Engineering stress falls after F only because of necking — true stress σ(1+e) keeps rising.",
            "TMT/HYSD bars have no yield point: fy = 0.2% proof stress, found with a line parallel to the elastic slope.",
          ] },
          { k: "h", t: "🔗 Related in Civil Educator" },
          { k: "list", items: [
            "<a href=\"#/read/som/2\">Ch. 2 — Elastic constants, elongation of bars, stresses on inclined planes</a> (uses E, μ from this chapter)",
            "<a href=\"#/read/som/4\">Ch. 4 — Theory of bending</a> (f = M/Z derived)",
            "<a href=\"#/read/som/6\">Ch. 6 — Resilience</a> and <a href=\"#/read/som/8\">Ch. 8 — Strain energy methods</a> (area under the curve)",
            "Codes: <a href=\"#/code/is1786\">IS 1786</a> (rebar), <a href=\"#/code/is1608\">IS 1608</a> (tensile test), <a href=\"#/code/is2062\">IS 2062</a> (structural steel), <a href=\"#/code/is456\">IS 456</a>, <a href=\"#/code/is800\">IS 800</a>",
          ] },
        ],
      },
    ],
  },

  /* ============================================================ CH 2
     v28 — rebuilt through the Phase 1 chapter quality gate. Notes
     blocks kept with (p.N); notes errors corrected openly; new
     material web-researched and linked. Log: claude/research-log-som.md */
  {
    id: "som-2",
    n: 2,
    title: "Elastic Constants, Axial Deformation and Compound Stresses",
    hi: "प्रत्यास्थ स्थिरांक, अक्षीय विरूपण एवं संयुक्त प्रतिबल",
    blurb: "E, G, K and μ with derivations of their relations and the generalised Hooke's law; every axial-deformation case (stepped, self-weight, tapered circular and rectangular bars); statically indeterminate and composite bars; free, restrained and partly restrained thermal stress including composite bars; stresses on an inclined plane, principal stresses and Mohr's circle; principal strains and strain rosettes; and the five theories of failure — with 11 worked examples.",
    mins: 55,
    sections: [
      /* ------------------------------------------------ 2.1 */
      {
        n: "2.1",
        title: "Elastic constants — E, G, K, μ and the generalised Hooke's law",
        hi: "प्रत्यास्थ स्थिरांक और सामान्यीकृत हुक का नियम",
        blocks: [
          { k: "h", t: "📘 Notes — p.5" },
          { k: "eq", expr: "Hooke's law:  (a) Stress ∝ Strain ⇒ σ = E·e  ;  (b) Shear stress ∝ Shear strain ⇒ τ = G·∅", where: [] },
          { k: "def", term: "Young's Modulus (E)", t: "Used to characterize a material, also called the <b>Modulus of Elasticity</b>. E = Stress/Strain = σ/e. (p.5)" },
          { k: "def", term: "Shear Modulus (G)", t: "Used to measure the stiffness of the material, the <b>Modulus of Rigidity</b>. G = Shear stress/Shear strain = τ/∅. (p.5)" },
          { k: "def", term: "Bulk Modulus (k)", t: "Applies when a body is subjected to 'like and equal' normal stress (σ) along three mutually perpendicular directions. k = (Normal stress)/(Volumetric strain) = σn/ev. (p.5)" },
          { k: "def", term: "Poisson's Ratio (μ)", t: "μ = (Lateral strain)/(Longitudinal strain) = ey/ex. μ lies between 0 and 0.5. (p.5)" },
          { k: "note", t: "Lateral and longitudinal strains have <b>opposite signs</b> (a bar pulled longer gets thinner), so strictly μ = −ey/ex; the notes' ey/ex means the ratio of magnitudes. Some older Indian books write Poisson's ratio as 1/m, where m is 'Poisson's number' (≈ 3.33 for steel)." },
          { k: "eq", expr: "E = 2G(1 + μ)   ;   E = 3k(1 − 2μ)   ;   E = 9kG/(3k + G)   ;   μ = (3k − 2G)/(6k + 2G)", where: [] },
          { k: "h", t: "📘 Where the two key relations come from" },
          { k: "steps", items: [
            "<b>E = 3K(1 − 2μ):</b> put equal stress σ on all three faces. Each direction's strain is σ/E − μσ/E − μσ/E = (σ/E)(1 − 2μ). Volumetric strain = 3 × that = (3σ/E)(1 − 2μ) (<a href=\"#/read/som/1\">§1.4</a>). K = σ/ev ⇒ <b>E = 3K(1 − 2μ)</b>.",
            "<b>E = 2G(1 + μ):</b> pure shear τ on a square is equivalent to tension τ and compression τ on its diagonals (§2.6 — principal stresses of pure shear are ±τ). Strain along the tension diagonal = τ/E + μτ/E = (τ/E)(1 + μ). Geometry of the distorted square gives that diagonal strain = γ/2 = τ/(2G). Equating: <b>E = 2G(1 + μ)</b>.",
            "The other two relations follow by eliminating μ (E = 9KG/(3K + G)) or E (μ = (3K − 2G)/(6K + 2G)) between these two.",
          ] },
          { k: "p", t: "Both derivations are the standard textbook route (the relations themselves also listed in the <a href=\"https://www.iare.ac.in/sites/default/files/lecture_notes/SM_LECTURE_NOTES.pdf\" target=\"_blank\" rel=\"noopener\">IARE lecture notes</a>). Notice what the formulas say: μ → 0.5 makes K → ∞ (incompressible), and μ must stay below 0.5 for K to be positive — the physical reason behind the notes' 0–0.5 range." },
          { k: "h", t: "📘 Generalised Hooke's law — strains under σx, σy, σz together" },
          { k: "eq", expr: "εx = [σx − μ(σy + σz)] / E   ;   εy = [σy − μ(σz + σx)] / E   ;   εz = [σz − μ(σx + σy)] / E   ;   γxy = τxy / G", where: [
            ["idea", "superposition — each stress stretches its own direction by σ/E and shrinks the other two by μσ/E"],
            ["plane stress", "σz = 0 but εz = −μ(σx + σy)/E is NOT zero (thin plates still change thickness)"],
            ["sum", "εx + εy + εz = (σx + σy + σz)(1 − 2μ)/E = volumetric strain"],
          ] },
          { k: "cmp", t: "Number of independent elastic constants, by material type (p.5)", cols: ["Independent elastic constants"], rows: [
            ["Isotropic", "2 (E & μ)"],
            ["Orthotropic", "9"],
            ["Anisotropic", "21"],
          ] },
          { k: "cmp", t: "Typical elastic constants for civil materials", cols: ["E (N/mm²)", "μ"], rows: [
            ["Structural steel (IS 800 cl. 2.2.4.1)", "2.0 × 10⁵ (G = 0.769 × 10⁵)", "0.3"],
            ["Concrete (IS 456 cl. 6.2.3.1)", "E_c = 5000√fck (e.g. 25 000 for M25)", "≈ 0.2 (typical design value — see note)"],
          ] },
          { k: "note", t: "Steel values from IS 800 (<a href=\"https://www.brainkart.com/article/Properties-Of-Structural-Steel_3414/\" target=\"_blank\" rel=\"noopener\">BrainKart</a>); check: 2.0 × 10⁵ / [2(1 + 0.3)] = 0.769 × 10⁵ ✔ — the code's G is exactly E = 2G(1 + μ). μ ≈ 0.2 for concrete is the common design assumption (e.g. <a href=\"https://buildingclub.info/modulus-of-elasticity-and-poissons-ratio-of-concrete-definition-and-values\" target=\"_blank\" rel=\"noopener\">SP 63.13330 cl. 6.1.17, via BuildingClub</a>); an Indian code clause for it was not verified here, so treat it as general engineering knowledge." },
          { k: "eg", title: "Worked example 2.1 — finding G and K from E and μ", given: "Structural steel: E = 2.0 × 10⁵ N/mm², μ = 0.3. Find: G and K.", steps: [
            { t: "G from E = 2G(1 + μ)", w: "G = E / [2(1 + μ)] = 200 000 / 2.6 = 76 923 N/mm² ≈ 0.769 × 10⁵ (matches IS 800 ✔)" },
            { t: "K from E = 3K(1 − 2μ)", w: "K = E / [3(1 − 2μ)] = 200 000 / 1.2 = 166 667 N/mm²" },
          ], ans: "G ≈ 76.9 GPa, K ≈ 166.7 GPa. Interpretation: steel resists change of volume (K) more strongly than change of length (E), and change of shape (G) least — which is why torsion and shear govern so many thin steel members." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "E, G aur k teeno essentially 'stiffness' hi maapte hain, bas alag loading conditions mein — E direct/axial loading mein, G shear loading mein, k sab directions mein equal normal stress (hydrostatic jaisa) mein. In teeno ko connect karta hai Poisson's ratio μ — jo batata hai ki jab material ek direction mein khinchta hai to doosri direction mein kitna sikudta hai. Isliye E, G, k, μ mein sirf <b>do</b> independent hain (isotropic material ke liye), baaki formula se nikal sakte ho." },
          { k: "trap", t: "μ ki range 0 se 0.5 ke beech hai — 0.5 ka matlab material incompressible hai (volume change zero, jaise rubber ke close). Agar kisi problem mein μ ≥ 0.5 ya negative aaye (aur specifically negative-Poisson materials na ho), to calculation dobara check karo. (p.5) Aur plane stress mein σz = 0 hone ka matlab εz = 0 nahi hai — plate ki thickness badalti hai." },
        ],
      },

      /* ------------------------------------------------ 2.2 */
      {
        n: "2.2",
        title: "Axial deformation — uniform, stepped, self-weight and tapered bars",
        hi: "अक्षीय विरूपण — समान, सोपानी, स्व-भार और पतले होते दंड",
        blocks: [
          { k: "h", t: "📘 Notes — p.6" },
          { k: "eq", expr: "1) External load (self-weight ignored):  ΔL = PL/AE   [∵ E = σ/e = (P/A)/(ΔL/L)]   ;   2) Self-weight only:  ΔL = WL/2AE   ;   ΔL = γL²/2E (prismatic bar, W = ALγ)   ;   ΔL = γL²/6E (conical bar, W = ⅓ALγ)", where: [] },
          { k: "eq", expr: "3) Tapered body:  ΔL = 4PL/(πEd1d2)   ;   4) Due to temperature:  ΔL = LαΔT   ;   Thermal stress σT = EαΔT   ;   Thermal strain eT = αΔT", where: [["d1, d2", "diameters at the two ends of the tapered/conical bar"]] },
          { k: "h", t: "📘 Bars in series (stepped bars) and the principle of superposition" },
          { k: "p", t: "When the area, material or internal force changes along the bar, split it into segments where all three are constant, find each segment's <b>internal</b> force from a free-body diagram, and add the segment elongations:" },
          { k: "eq", expr: "ΔL = Σ (Pᵢ Lᵢ) / (Aᵢ Eᵢ)", where: [
            ["Pᵢ", "internal axial force in segment i (tension +) — from cutting the bar and balancing one side, NOT the applied load at that point"],
            ["superposition", "valid because the response is linear: the elongation from several loads = the sum of the elongations from each acting alone"],
          ] },
          { k: "h", t: "📘 Self-weight — why the factor ½ and ⅓" },
          { k: "p", t: "In a bar hanging from its top, a section at distance y from the free end carries only the weight of the bar below it. For a prismatic bar that is γAy, so the stress is γy (zero at the bottom, γL at the top) and dΔ = (γy/E)dy; integrating from 0 to L gives <b>γL²/2E</b>. For a cone (apex down) the weight below a section is ⅓ × (its area) × y × γ, so the stress is γy/3 and the integral gives <b>γL²/6E</b>. Written with the bar's total weight W, both happen to reduce to WL/2AE (A = area at the top). Derived from first principles." },
          { k: "h", t: "📘 Tapered bars — circular and rectangular" },
          { k: "eq", expr: "Circular, d1 → d2:  ΔL = 4PL / (π E d1 d2)   ;   Rectangular, width a → b, constant thickness t:  ΔL = PL · ln(a/b) / [E t (a − b)]", where: [
            ["why d1·d2", "integrating P dx/(A(x)E) with a linearly varying diameter gives the product of end diameters — not the square of the average"],
            ["rectangular", "the width varies linearly so 1/A integrates to a logarithm (IARE lecture notes)"],
          ] },
          { k: "eg", title: "Worked example 2.2 — stepped bar", given: "A steel bar has a 400 mm segment of area 600 mm² and a 600 mm segment of area 300 mm². An axial pull P = 60 kN acts at the ends. E = 2 × 10⁵ N/mm². Find: total elongation and the stress in each part.", steps: [
            { t: "Internal force is 60 kN in both segments (no load between them).", w: "σ₁ = 60 000/600 = 100 N/mm²;  σ₂ = 60 000/300 = 200 N/mm²" },
            { t: "Sum the segment elongations", w: "ΔL = (P/E)(L₁/A₁ + L₂/A₂) = (60 000/200 000)(400/600 + 600/300)\n   = 0.3 × (0.667 + 2.000) = 0.80 mm" },
          ], ans: "ΔL = 0.80 mm; σ = 100 and 200 N/mm². Interpretation: the thin segment, though only 60% of the length, produces 75% of the stretch — stiffness is governed by the weakest link." },
          { k: "eg", title: "Worked example 2.3 — elongation under self-weight", given: "A 50 m steel rod hangs vertically from its top. γ = 78.5 kN/m³ = 7.85 × 10⁻⁵ N/mm³, E = 2 × 10⁵ N/mm². Find: elongation due to self-weight, and for a conical rod of the same length.", steps: [
            { t: "Prismatic", w: "ΔL = γL²/2E = 7.85 × 10⁻⁵ × 50 000² / (2 × 200 000) = 0.49 mm" },
            { t: "Conical (one-third)", w: "ΔL = γL²/6E = 0.49 / 3 = 0.16 mm" },
          ], ans: "0.49 mm and 0.16 mm. Interpretation: self-weight effects are tiny for short members but matter for deep mine-shaft hoists, long suspension hangers and tall towers — note the area A cancels out for a prismatic bar." },
          { k: "eg", title: "Worked example 2.4 — tapered rod: why not use the average diameter", given: "A 1 m steel rod tapers uniformly from 40 mm to 20 mm diameter and carries P = 50 kN. E = 2 × 10⁵ N/mm². Find: elongation; compare with a uniform 30 mm rod.", steps: [
            { t: "Tapered formula", w: "ΔL = 4PL/(πE d1 d2) = 4 × 50 000 × 1000 / (π × 200 000 × 40 × 20) = 0.398 mm" },
            { t: "Uniform rod at the mean diameter (30 mm)", w: "ΔL = 4PL/(πE d²) = 4 × 50 000 × 1000 / (π × 200 000 × 900) = 0.354 mm" },
          ], ans: "0.398 mm. Using the mean diameter under-estimates the stretch by about 11%, because the thin end contributes disproportionately (1/A is not linear in d)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Self-weight wale case mein ΔL = WL/2AE hai — external load wale formula (PL/AE) se aadha, kyunki self-weight ka effect top se bottom tak <b>linearly badhta</b> hai (bottom fibre par zero force, top support par pura W), to average force W/2 kaam karta hai poori length par. Isi tarah conical bar ka ΔL = γL²/6E (prismatic ke γL²/2E se ⅓) hai kyunki conical bar ka weight bhi W=⅓ALγ hota hai — taper hone se area upar se neeche ghatta jaata hai." },
          { k: "trap", t: "Stepped bar mein har segment ka <b>internal</b> force alag-alag FBD se nikalo — jahan beech mein load laga ho wahan segment ka force applied load ke barabar nahi hota. Tapered bar mein average diameter mat lo — d1·d2 wala formula lagao." },
        ],
      },

      /* ------------------------------------------------ 2.3 */
      {
        n: "2.3",
        title: "Statically indeterminate bars and composite (compound) bars",
        hi: "अनिर्धार्य दंड और संयुक्त दंड",
        blocks: [
          { k: "p", t: "If equilibrium alone cannot give the forces — a bar fixed at both ends, or two materials sharing one load — the member is <b>statically indeterminate</b>. Every such problem is solved with the same three ingredients:" },
          { k: "steps", items: [
            "<b>Equilibrium</b> — ΣF = 0 (gives one equation, but there are two unknowns).",
            "<b>Compatibility</b> — a geometric condition on deformations (total length change = 0 for fixed ends; equal strain for bars joined side by side).",
            "<b>Force–deformation law</b> — δ = PL/AE for each part, which turns the geometric condition into an equation in the forces.",
          ] },
          { k: "h", t: "📘 Bar fixed at both ends with a load at an intermediate point" },
          { k: "p", t: "A load P at C splits the bar into AC (length a) and CB (length b). The part on one side stretches as much as the other side shortens (compatibility), which gives R_A = P·b/L and R_B = P·a/L — the <b>nearer</b> support takes the larger share. (Same superposition-and-compatibility approach as the <a href=\"https://www.iare.ac.in/sites/default/files/lecture_notes/SM_LECTURE_NOTES.pdf\" target=\"_blank\" rel=\"noopener\">IARE notes</a>; result derived here.)" },
          { k: "eq", expr: "R_A = P·b/L   ;   R_B = P·a/L   ;   δ_C = R_A·a / (AE)", where: [
            ["a, b", "distances of the load from supports A and B (a + b = L)"],
            ["assumes", "uniform A and E along the bar"],
          ] },
          { k: "h", t: "📘 Composite bars — two materials side by side" },
          { k: "p", t: "When two materials are bonded or clamped so they must deform together (a steel rod inside a copper tube, steel bars in a concrete column), their <b>strains are equal</b>. Since ε = σ/E, the stiffer material carries the higher stress: σ₁/E₁ = σ₂/E₂, i.e. σ_s = m·σ_c where <b>m = E_s/E_c is the modular ratio</b> (IARE notes)." },
          { k: "eq", expr: "P = σ_s A_s + σ_c A_c   ;   σ_s = m σ_c   ⇒   σ_c = P / (A_c + m A_s)", where: [
            ["A_c + m A_s", "the 'equivalent' or transformed area — steel area counted m times, as if it were concrete"],
          ] },
          { k: "eg", title: "Worked example 2.5 — RCC column as a composite bar", given: "A 300 × 300 mm short column has 4 bars of 16 mm. E_s = 2 × 10⁵, E_c = 25 000 N/mm² (M25). Axial load 1000 kN. Find: stresses in concrete and steel, and the load share of the steel (elastic analysis).", steps: [
            { t: "Areas", w: "A_s = 4 × π × 16²/4 = 804.2 mm²\nA_c = 300 × 300 − 804.2 = 89 195.8 mm²" },
            { t: "Modular ratio and transformed area", w: "m = 200 000 / 25 000 = 8\nA_c + m A_s = 89 195.8 + 8 × 804.2 = 95 629.8 mm²" },
            { t: "Stresses", w: "σ_c = 1 000 000 / 95 629.8 = 10.46 N/mm²\nσ_s = 8 × 10.46 = 83.7 N/mm²" },
            { t: "Load in steel", w: "P_s = 83.7 × 804.2 = 67.3 kN (6.7 % of the load from 0.9 % of the area)" },
          ], ans: "σ_c = 10.46 N/mm², σ_s = 83.7 N/mm²; steel carries 67.3 kN. Interpretation: with time, concrete creeps (§1.6) and sheds load to the steel, so the long-term steel stress is higher. That is why IS 456's working-stress annex uses m = 280/(3σ_cbc) — about 13.3 for M20 — rather than the short-term E_s/E_c (source in the note below)." },
          { k: "note", t: "IS 456 WSM modular ratio m = 280/(3σ_cbc), e.g. 13.33 for M20 — from <a href=\"https://engineeringhulk.com/civil/rcc-design/working-stress-vs-limit-state/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — WSM vs LSM</a>. The 280/3 form builds long-term creep into m, so it is deliberately larger than the instantaneous E_s/E_c = 8 used above." },
          { k: "eg", title: "Worked example 2.6 — bar fixed at both ends", given: "A 600 mm bar of area 500 mm² is fixed at both ends A and B. A 30 kN axial load acts at C, 200 mm from A. E = 2 × 10⁵ N/mm². Find: reactions, stresses, and the movement of C.", steps: [
            { t: "Reactions (nearer support takes more)", w: "R_A = P·b/L = 30 × 400/600 = 20 kN\nR_B = P·a/L = 30 × 200/600 = 10 kN   (check: 20 + 10 = 30 ✔)" },
            { t: "Stresses (load pushes towards B: AC in tension, CB in compression)", w: "σ_AC = 20 000/500 = 40 N/mm² (T)\nσ_CB = 10 000/500 = 20 N/mm² (C)" },
            { t: "Movement of C — compatibility check", w: "δ_AC = 20 000 × 200 /(500 × 200 000) = +0.040 mm\nδ_CB = −10 000 × 400 /(500 × 200 000) = −0.040 mm  → total 0 ✔" },
          ], ans: "R_A = 20 kN, R_B = 10 kN; 40 N/mm² tension and 20 N/mm² compression; C moves 0.04 mm. The zero-total check is the compatibility condition itself." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Indeterminate problem ka matlab: equations kam, unknowns zyada. Extra equation geometry deti hai — 'dono ends fixed hain to total length change zero' ya 'dono materials saath jude hain to strain same'. Isi wajah se composite column mein steel ko concrete se m guna stress milta hai — strain same, par steel m guna stiff." },
          { k: "trap", t: "Composite bar mein galti: load ko area ke ratio mein baant dena. Load <b>stiffness (A·E)</b> ke ratio mein bat'ta hai, sirf area mein nahi. Aur fixed-fixed bar mein yaad rakho — load ke <b>paas wala</b> support zyada reaction leta hai (R_A = Pb/L, b = doosri taraf ki length)." },
        ],
      },

      /* ------------------------------------------------ 2.4 */
      {
        n: "2.4",
        title: "Thermal stresses — free, restrained, partly restrained and composite bars",
        hi: "ताप प्रतिबल",
        blocks: [
          { k: "p", t: "A temperature change ΔT tries to change a bar's length by LαΔT. <b>Stress appears only to the extent that this movement is prevented.</b>" },
          { k: "cmp", t: "Three levels of restraint", cols: ["Thermal stress", "Condition"], rows: [
            ["Free bar", "0 (only strain αΔT)", "ends free to move"],
            ["Fully restrained", "σ = EαΔT", "ends held rigidly"],
            ["Partly restrained (gap δ)", "σ = E(LαΔT − δ)/L", "only after the gap closes, i.e. when LαΔT > δ"],
          ] },
          { k: "p", t: "In a <b>composite bar</b> of two materials with different α that are joined at the ends, the material that wants to expand more is held back (goes into compression) and the other is pulled along (tension). With no external load the two forces balance, and the compatibility condition is that the difference in free expansion is taken up by the two elastic strains (<a href=\"https://www.iare.ac.in/sites/default/files/lecture_notes/SM_LECTURE_NOTES.pdf\" target=\"_blank\" rel=\"noopener\">IARE notes</a>):" },
          { k: "eq", expr: "σ₁A₁ = σ₂A₂   ;   (α₁ − α₂)ΔT = σ₁/E₁ + σ₂/E₂", where: [
            ["material 1", "higher α → compression; material 2 (lower α) → tension"],
            ["note", "L cancels — thermal stress in a composite bar does not depend on length"],
          ] },
          { k: "eg", title: "Worked example 2.7 — rail with and without an expansion gap", given: "Steel rails 12 m long are laid at a temperature 40 °C below the maximum rail temperature. α = 12 × 10⁻⁶ /°C, E = 2 × 10⁵ N/mm². Find the stress at maximum temperature (a) if fully restrained, (b) with a 3 mm gap at each joint. Also the rise at which the gap closes.", steps: [
            { t: "(a) Fully restrained", w: "σ = EαΔT = 200 000 × 12 × 10⁻⁶ × 40 = 96 N/mm² (compression)" },
            { t: "(b) Free expansion vs gap", w: "LαΔT = 12 000 × 12 × 10⁻⁶ × 40 = 5.76 mm  > 3 mm, so the gap closes\nσ = E(5.76 − 3)/L = 200 000 × 2.76 / 12 000 = 46 N/mm²" },
            { t: "Temperature rise that just closes the gap", w: "ΔT = δ/(Lα) = 3 / (12 000 × 12 × 10⁻⁶) = 20.8 °C" },
          ], ans: "96 N/mm² fully restrained; 46 N/mm² with the gap, which closes after a 20.8 °C rise. Interpretation: the gap more than halves the stress — the reason for expansion joints in rails, bridges, long slabs and pipelines." },
          { k: "eg", title: "Worked example 2.8 — steel rod inside a copper tube, heated", given: "A 20 mm steel rod passes through a copper tube of area 600 mm²; they are joined at the ends and heated by 50 °C. E_s = 2 × 10⁵, E_c = 1 × 10⁵ N/mm²; α_s = 12 × 10⁻⁶, α_c = 17.5 × 10⁻⁶ /°C. Find: stresses in each.", steps: [
            { t: "Equilibrium (copper wants to expand more → compression; steel → tension)", w: "A_s = π × 20²/4 = 314.2 mm²\nσ_c × 600 = σ_s × 314.2  ⇒  σ_c = 0.5236 σ_s" },
            { t: "Compatibility", w: "(α_c − α_s)ΔT = σ_s/E_s + σ_c/E_c\n5.5 × 10⁻⁶ × 50 = 2.75 × 10⁻⁴ = σ_s (1/200 000 + 0.5236/100 000)" },
            { t: "Solve", w: "σ_s = 2.75 × 10⁻⁴ / 1.0236 × 10⁻⁵ = 26.9 N/mm² (T)\nσ_c = 0.5236 × 26.9 = 14.1 N/mm² (C)" },
          ], ans: "Steel 26.9 N/mm² tension, copper 14.1 N/mm² compression. Check equilibrium: 26.9 × 314.2 ≈ 14.1 × 600 ≈ 8.44 kN ✔." },
          { k: "h", t: "💡 Samjho" },
          { k: "real", t: "Thermal stress ka formula (σT = EαΔT) tab hi apply hota hai jab expansion/contraction <b>poori tarah restrained</b> ho (free expansion mein stress zero hoga, sirf strain hoga). Rails, long pipelines, aur bridge expansion joints ka design isi principle par based hota hai — agar movement allow nahi kiya to poora EαΔT stress develop ho jaata hai. RCC mein steel aur concrete ka α lagbhag barabar hona hi woh wajah hai ki dono saath kaam kar paate hain bina thermal stress ke." },
          { k: "trap", t: "Gap wale problem mein pehle check karo ki gap band hota bhi hai ya nahi (LαΔT > δ?). Agar nahi, to stress zero hai. Composite bar mein galti: dono materials mein EαΔT alag-alag laga dena — woh galat hai, kyunki dono ek-doosre ko partly restrain karte hain; equilibrium + compatibility dono lagao." },
        ],
      },

      /* ------------------------------------------------ 2.5 */
      {
        n: "2.5",
        title: "Compound stresses on an inclined plane",
        hi: "झुके हुए तल पर संयुक्त प्रतिबल",
        blocks: [
          { k: "h", t: "📘 Notes — p.6" },
          { k: "p", t: "When analysing compound (combined) stresses on planes, stresses and strains in the Z-direction are considered negligible. A rectangular element carries σx, τxy on its faces; the combined stress is examined on a plane inclined at angle θ, cutting diagonally through the element. (p.6)" },
          { k: "dia", id: "hb-som-incl" },
          { k: "def", term: "σx, σy", t: "Principal (direct) stresses acting in the two directions x and y. (p.6)" },
          { k: "note", t: "σx and σy are called <i>principal</i> stresses only when τxy = 0. In general they are just the normal stresses on the x and y faces; the principal stresses are found in §2.6." },
          { k: "def", term: "τxy", t: "Shear stress acting on the x-face and in the y-direction. (p.6)" },
          { k: "def", term: "σn — Normal stress", t: "The combined stress normal to the inclined surface. (p.6)" },
          { k: "def", term: "τ — Shear stress (combined)", t: "The combined stress, tangential to the inclined surface. (p.6)" },
          { k: "eq", expr: "Resultant stress  R = √(σn² + τ²), inclined at angle θ to the surface", where: [] },
          { k: "eq", expr: "σn = (σx + σy)/2 + (σx − σy)/2 · cos2θ + τxy sin2θ  ;  τ = (σx − σy)/2 · sin2θ + τxy cos2θ", where: [] },
          { k: "note", t: "<b>Correction to the notes — sign in the shear-stress formula.</b> With θ measured counter-clockwise from x to the plane's normal (figure above), the shear stress on the plane is <b>τ = −(σx − σy)/2 · sin2θ + τxy cos2θ</b>; the σn formula is correct as written. Two independent university sources give exactly this pair (<a href=\"https://courses.physics.illinois.edu/tam251/su2021/TAM251_Chapter9_StressTransformation_prelecture_Johnson.pdf\" target=\"_blank\" rel=\"noopener\">Univ. of Illinois TAM 251</a>; <a href=\"https://www.purdue.edu/freeform/me323/wp-content/uploads/sites/2/2022/11/stress_transformation01.pdf\" target=\"_blank\" rel=\"noopener\">Purdue ME 323</a>). Self-check that exposes the error: on a principal plane the shear must be zero. Using tan2θp = 2τxy/(σx − σy), the corrected formula gives τ = 0, but the notes' version (both terms +) gives τ = 2·[(σx−σy)/2]·τxy/R ≠ 0. Some Indian texts measure θ from a different reference and write τ = (σx−σy)/2 · sin2θ − τxy cos2θ — that is the same result with the opposite sign convention for τ; what is never correct is both terms carrying the same sign." },
          { k: "eq", expr: "Corrected:  τ = −(σx − σy)/2 · sin2θ + τxy cos2θ   ;   Invariant:  σn(θ) + σn(θ + 90°) = σx + σy", where: [
            ["θ", "angle from the x-axis to the normal of the plane, counter-clockwise positive"],
            ["invariant", "the sum of normal stresses on any two perpendicular planes never changes — a quick arithmetic check"],
          ] },
          { k: "list", items: [
            "<b>Uniaxial stress</b> — only σx acts (σy = 0 and τxy = 0). (p.6)",
            "<b>Biaxial stress</b> — σx and σy both act (τxy = 0). (p.6)",
            "<b>Pure shear</b> — only τxy acts (σx = σy = 0). (p.6)",
          ] },
          { k: "cmp", t: "Special cases at a glance (from the formulas above)", cols: ["On plane at θ", "Maximum shear"], rows: [
            ["Uniaxial σ", "σn = σcos²θ;  |τ| = (σ/2)sin2θ", "σ/2 on planes at 45° — why ductile bars yield along 45° slip lines"],
            ["Biaxial σx, σy", "σn = (σx+σy)/2 + (σx−σy)/2·cos2θ", "(σx − σy)/2 at 45°"],
            ["Pure shear τ", "σn = τ sin2θ", "principal stresses ±τ at 45° — why brittle shafts break on a 45° helix"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "θ ko ghumate jao 0° se 90° tak, aur σn/τ ki formula tumhe us plane par ka stress de degi — matlab yeh do formulas kisi bhi orientation ke plane par ka stress nikaal sakti hain, sirf σx, σy, τxy maalum hone chahiye. Agle section mein (principal stress) hum yeh puchte hain: kaunsa θ hai jahan σn maximum ho jaata hai — wahi principal plane hoga." },
          { k: "trap", t: "τxy ka sign convention yaad rakho — yeh x-face par y-direction mein act karta hai. Agar tum τyx use kar rahe ho (y-face par x-direction), to sign flip ho sakta hai — formula mein consistently ek hi convention use karo. (p.6) Formula sahi hai ya nahi, iska test: principal plane par τ zero aana chahiye." },
        ],
      },

      /* ------------------------------------------------ 2.6 */
      {
        n: "2.6",
        title: "Principal stresses, maximum shear stress and Mohr's circle",
        hi: "मुख्य प्रतिबल, अधिकतम अपरूपण प्रतिबल और मोर का वृत्त",
        blocks: [
          { k: "h", t: "📘 Notes — p.7" },
          { k: "def", term: "Condition for principal stress", t: "σn is maximum when dσn/dθ = 0, i.e. at Tan2θp = 2τxy/(σx − σy). θp is the angle between the normal stress plane and the vertical plane — a function of Tan. σn is max at 2θp or π + 2θp ⇒ θp1 − θp2 = π/2. θp1 gives the major principal stress plane (θp from vertical); θp2 the minor principal stress plane (π/2 + θp from vertical). The two principal planes differ by 90°. (p.7)" },
          { k: "eq", expr: "Major principal stress  σP1 = (σx + σy)/2 + √[((σx − σy)/2)² + τxy²]  ;  Minor principal stress  σP2 = (σx + σy)/2 − √[((σx − σy)/2)² + τxy²]", where: [] },
          { k: "def", term: "Condition for maximum shear stress", t: "τ is maximum when dτ/dθ = 0, i.e. at Tan2θs = (σx − σy)/2τxy. τmax occurs on perpendicular planes (θs and θs + 90°). (p.7)" },
          { k: "eq", expr: "τmax = (σP1 − σP2)/2 = √[((σx − σy)/2)² + τxy²]", where: [] },
          { k: "note", t: "Since Tan2θp × Tan2θs = 1 (i.e. Tan2θp = Cot2θs = Tan(90 ± 2θp)), it follows that 2θp − 2θs = ±90°, so θp = θs ± 45°. <b>The planes of principal stress (σP) and of maximum shear stress (τmax) are inclined at 45° to each other.</b> (p.7)" },
          { k: "note", t: "<b>Sign detail, following from the corrected τ formula in §2.5:</b> tan2θs = <b>−</b>(σx − σy)/(2τxy) (Illinois TAM 251, linked above), so tan2θp × tan2θs = <b>−1</b>, not +1. A product of −1 is exactly the condition for 2θp and 2θs to differ by 90° — so the notes' conclusion (principal and max-shear planes are 45° apart) is right; only the sign on the way was off. The planes of maximum shear are <b>not</b> shear-only: they carry normal stress (σx + σy)/2." },
          { k: "h", t: "Mohr's Circle (p.7)" },
          { k: "def", term: "Mohr's Circle", t: "The graphical representation of compound stresses — the underlying formulas are the same as the analytical ones above. σP is taken +ve, and τ is taken +ve in the clockwise (↻) direction. (p.7)" },
          { k: "list", items: [
            "Centre = ((σP1 + σP2)/2, 0) = ((σx + σy)/2, 0). (p.7)",
            "Radius = τmax. (p.7)",
            "A point P on the circle, at angle 2θ from the centre, gives the (σn, τ) on the plane inclined at θ. (p.7)",
          ] },
          { k: "h", t: "📘 Constructing the circle — step by step" },
          { k: "steps", items: [
            "Draw σ horizontally (tension to the right) and τ vertically. In this handbook τ is plotted <b>positive downward</b>, so that a counter-clockwise rotation θ of the element is also a counter-clockwise rotation 2θ on the circle.",
            "Plot <b>X = (σx, τxy)</b> — the x-face — and <b>Y = (σy, −τxy)</b> — the y-face (Illinois TAM 251 uses the same two points).",
            "Join X and Y; where XY crosses the σ-axis is the centre C = (σx + σy)/2. CX is the radius R = √[((σx − σy)/2)² + τxy²].",
            "The circle meets the σ-axis at σ1 = C + R and σ2 = C − R; its top and bottom points give τmax = R.",
            "The angle from CX to the σ1 point is 2θp; turn the element by θp in the same sense to reach the major principal plane.",
          ] },
          { k: "dia", id: "hb-som-mohr" },
          { k: "eg", title: "Worked example 2.9 — stresses on a plane, principal stresses, Mohr's circle", given: "At a point: σx = 80 N/mm² (T), σy = 40 N/mm² (C), τxy = 30 N/mm². Find: (a) σn and τ on the plane at θ = 30°, (b) principal stresses and planes, (c) τmax.", steps: [
            { t: "Centre and half-difference", w: "(σx + σy)/2 = (80 − 40)/2 = 20;   (σx − σy)/2 = 60" },
            { t: "(a) Plane at θ = 30° (2θ = 60°)", w: "σn = 20 + 60 cos60° + 30 sin60° = 20 + 30 + 25.98 = 75.98 N/mm²\nτ = −60 sin60° + 30 cos60° = −51.96 + 15 = −36.96 N/mm²" },
            { t: "Invariant check with the perpendicular plane (θ = 120°)", w: "σn(120°) = 20 + 60 cos240° + 30 sin240° = −35.98\n75.98 + (−35.98) = 40 = σx + σy ✔" },
            { t: "(b) Principal stresses", w: "R = √(60² + 30²) = 67.08\nσ1 = 20 + 67.08 = 87.08 N/mm² (T);  σ2 = 20 − 67.08 = −47.08 N/mm² (C)" },
            { t: "Principal planes", w: "tan2θp = 2 × 30 / 120 = 0.5  ⇒  2θp = 26.57°  ⇒  θp = 13.28° (σ1);  103.28° (σ2)\nCheck: τ at 13.28° = −60 sin26.57° + 30 cos26.57° = −26.83 + 26.83 = 0 ✔" },
            { t: "(c) Maximum shear", w: "τmax = R = 67.08 N/mm² on planes at 13.28° ± 45°, with normal stress 20 N/mm² on them" },
          ], ans: "(a) σn = 75.98, τ = −36.96 N/mm²; (b) σ1 = 87.08 (T) at 13.28°, σ2 = 47.08 (C) at 103.28°; (c) τmax = 67.08 N/mm². Every value can be read off the to-scale circle above." },
          { k: "h", t: "📘 Principal strains and strain rosettes — how stresses are measured on site" },
          { k: "p", t: "Stress cannot be measured directly; <b>strain</b> can, with electrical-resistance strain gauges. Strains transform exactly like stresses, with γxy/2 playing the role of τxy, so the same formulas and the same Mohr's circle apply (principal-strain form as in <a href=\"https://www.madeeasy.in/study/ce/strength-of-material/transformation-equations\" target=\"_blank\" rel=\"noopener\">MADE EASY study notes</a>). Because one gauge reads only one direction, three gauges are bonded at 0°, 45° and 90° — a <b>rectangular rosette</b>." },
          { k: "eq", expr: "ε1,2 = (εx + εy)/2 ± √[((εx − εy)/2)² + (γxy/2)²]   ;   tan2θp = γxy/(εx − εy)   ;   rosette: εx = ε0, εy = ε90, γxy = 2ε45 − ε0 − ε90", where: [
            ["rosette relation", "from εθ = (εx+εy)/2 + (εx−εy)/2·cos2θ + (γxy/2)·sin2θ at θ = 45° — derived here"],
            ["stresses (plane stress)", "σ1 = E(ε1 + με2)/(1 − μ²);  σ2 = E(ε2 + με1)/(1 − μ²) — from the generalised Hooke's law of §2.1"],
          ] },
          { k: "eg", title: "Worked example 2.11 — rectangular strain rosette on a steel girder", given: "A 0°/45°/90° rosette reads ε0 = 600, ε45 = 400, ε90 = −200 microstrain on a steel web. E = 2 × 10⁵ N/mm², μ = 0.3. Find: principal strains, their direction, and principal stresses.", steps: [
            { t: "Shear strain from the rosette", w: "γxy = 2(400) − 600 − (−200) = 400 µε" },
            { t: "Principal strains", w: "centre = (600 − 200)/2 = 200;  R = √(400² + 200²) = 447.2\nε1 = 647.2 µε;  ε2 = −247.2 µε" },
            { t: "Direction", w: "tan2θp = 400 / 800 = 0.5  ⇒  θp = 13.3° from the 0° gauge" },
            { t: "Principal stresses", w: "E/(1 − μ²) = 200 000/0.91 = 219 780\nσ1 = 219 780 × (647.2 + 0.3 × (−247.2)) × 10⁻⁶ = 125.9 N/mm²\nσ2 = 219 780 × (−247.2 + 0.3 × 647.2) × 10⁻⁶ = −11.7 N/mm²" },
          ], ans: "ε1 = 647 µε, ε2 = −247 µε at 13.3°; σ1 = 125.9 N/mm² (T), σ2 = 11.7 N/mm² (C). Interpretation: this is exactly how bridge load tests and structural health monitoring turn gauge readings into stresses, which are then checked against a theory of failure (§2.7)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Mohr's circle ko ek 'lookup chart' ki tarah socho — center hamesha (σx+σy)/2 par hai (yeh average stress hai, jo θ badalne se change nahi hota), aur radius τmax ke barabar hai. Circle ke sabse right point par σn = σP1 (aur τ=0), sabse left point par σn = σP2 — matlab principal planes par shear stress zero hota hai, yeh isi circle se seedha dikh jaata hai." },
          { k: "real", t: "Beam ke web mein bending stress aur shear stress saath hote hain — principal stress wahi hai jo diagonal (inclined) cracks banata hai RCC beams ke support ke paas. Isliye shear reinforcement (stirrups, bent-up bars) diagonal tension ko rokne ke liye diya jaata hai. Shaft mein bhi bending + torsion milke principal stress dete hain (<a href=\"#/read/som/6\">Chapter 6.3</a>)." },
          { k: "trap", t: "Circle par angle hamesha <b>2θ</b> hota hai, physical plane ka angle nahi — isliye do planes jo physically 90° apart hain, circle par 180° apart dikhte hain, aur principal stress se max-shear tak physically 45° ka fasla circle par 90° dikhta hai. Factor-of-2 yahin galti hoti hai. (p.7) Doosri galti: Y point ko (σy, +τxy) plot kar dena — Y hamesha (σy, −τxy) hota hai." },
        ],
      },

      /* ------------------------------------------------ 2.7 */
      {
        n: "2.7",
        title: "Theories of failure",
        hi: "विफलता के सिद्धांत",
        blocks: [
          { k: "p", t: "A tension test gives one number — the yield stress σy under <i>one</i> stress. A real point usually has two or three principal stresses at once. A <b>theory of failure</b> says which combination of σ1, σ2, σ3 is 'as dangerous as' σy in the tension test. Each theory picks a different quantity to compare." },
          { k: "cmp", t: "The five classical theories (σ1 ≥ σ2 ≥ σ3; σy from the tension test)", cols: ["Failure when…", "Best for"], rows: [
            ["Max principal stress — Rankine", "σ1 = σy (or |σ3| = compressive strength)", "Brittle materials (cast iron, concrete in tension)"],
            ["Max shear stress — Tresca / Guest", "σ1 − σ3 = σy  (i.e. τmax = σy/2)", "Ductile; simple and slightly conservative"],
            ["Max principal strain — St. Venant", "σ1 − μ(σ2 + σ3) = σy", "Historical; rarely used now"],
            ["Total strain energy — Haigh", "σ1² + σ2² + σ3² − 2μ(σ1σ2 + σ2σ3 + σ3σ1) = σy²", "Elastic analysis; over-predicts under hydrostatic stress"],
            ["Distortion energy — von Mises (Huber–Hencky)", "½[(σ1−σ2)² + (σ2−σ3)² + (σ3−σ1)²] = σy²", "Ductile; best agreement with tests"],
          ] },
          { k: "note", t: "Criteria cross-checked between <a href=\"https://web.iitd.ac.in/~ajeetk/smb/TheoryofFailure.html\" target=\"_blank\" rel=\"noopener\">IIT Delhi course notes</a> (Tresca and von Mises forms), <a href=\"https://web.mst.edu/~jthomas/classes/2211/lessons/failure/theories/index.html\" target=\"_blank\" rel=\"noopener\">Missouri S&amp;T</a> (envelope shapes, material suitability) and <a href=\"https://open-exam-prep.com/study-guides/in-cil-mt/paper-2-machine-design/static-fatigue-failure-theories\" target=\"_blank\" rel=\"noopener\">Open Exam Prep</a> (all five criteria and shear-yield ratios). For plane stress put σ3 = 0 — but for Tresca, if σ1 and σ2 have the same sign, the governing difference is with the zero third stress, so failure is max(|σ1|, |σ2|) = σy." },
          { k: "dia", id: "hb-som-failure" },
          { k: "cmp", t: "Shear yield stress τy predicted in pure shear (σ1 = τ, σ2 = −τ), μ = 0.3", cols: ["τy / σy", "Derivation"], rows: [
            ["Rankine", "1.00", "σ1 = τ = σy"],
            ["Tresca", "0.50", "σ1 − σ2 = 2τ = σy"],
            ["St. Venant", "1/(1 + μ) = 0.77", "τ + μτ = σy"],
            ["Haigh", "1/√(2(1 + μ)) = 0.62", "2τ² + 2μτ² = σy²"],
            ["von Mises", "1/√3 = 0.577", "τ² + τ² + τ² = σy²"],
          ] },
          { k: "note", t: "Ratios derived from first principles; they match Open Exam Prep's table, and the Tresca 0.5 and von Mises 0.577 values match IIT Delhi's. Torsion tests on ductile steel give τy close to 0.58σy — the evidence that von Mises fits ductile metals best. The same √3 runs through IS 800:2007's shear provisions — e.g. the fillet-weld design strength f_u/(√3·γ_mw), cl. 10.5.10.1.1 (<a href=\"https://www.ideastatica.com/support-center/theoretical-background/check-of-components-according-to-is-800\" target=\"_blank\" rel=\"noopener\">IDEA StatiCa — IS 800 checks</a>) — and the shear capacity of beam webs is likewise built on f_yw/√3 (general engineering knowledge; see IS 800 cl. 8.4)." },
          { k: "eg", title: "Worked example 2.10 — factor of safety by each theory", given: "At a point in a steel member (σy = 250 N/mm², μ = 0.3) the principal stresses are σ1 = 120 N/mm² (T) and σ2 = 80 N/mm² (C), σ3 = 0. Find: the factor of safety by each theory.", steps: [
            { t: "Rankine", w: "FoS = 250 / 120 = 2.08" },
            { t: "Tresca (opposite signs → difference governs)", w: "σ1 − σ2 = 120 − (−80) = 200  ⇒  FoS = 250/200 = 1.25" },
            { t: "St. Venant", w: "σ1 − μσ2 = 120 + 0.3 × 80 = 144  ⇒  FoS = 250/144 = 1.74" },
            { t: "Haigh", w: "120² + 80² − 2(0.3)(120)(−80) = 14 400 + 6 400 + 5 760 = 26 560\n√26 560 = 163.0  ⇒  FoS = 250/163.0 = 1.53" },
            { t: "von Mises", w: "120² + 80² − (120)(−80) = 14 400 + 6 400 + 9 600 = 30 400\n√30 400 = 174.4  ⇒  FoS = 250/174.4 = 1.43" },
          ], ans: "Rankine 2.08, St. Venant 1.74, Haigh 1.53, von Mises 1.43, Tresca 1.25. Interpretation: for a ductile steel with opposite-sign stresses, Rankine would claim a comfortable 2.08 while the realistic von Mises value is 1.43 — this is the case where using the brittle-material theory is unsafe. Tresca is the most conservative." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Brittle material tension mein toot'ta hai — isliye uske liye 'max principal stress' (Rankine) sahi hai. Ductile material shear se slip karke yield hota hai — isliye shear-based theories (Tresca, von Mises) uske liye sahi hain. Exam ka shortcut: <b>brittle → Rankine, ductile → Tresca/von Mises</b>, aur pure shear mein τy = 0.5σy (Tresca) ya 0.577σy (von Mises)." },
          { k: "trap", t: "Plane stress mein Tresca lagate waqt σ3 = 0 ko mat bhoolo. Agar σ1 = 100 aur σ2 = 60 (dono tension), to τmax = (100 − 0)/2 = 50 hai, (100 − 60)/2 = 20 nahi. Same-sign case mein bada principal stress hi govern karta hai." },
        ],
      },

      /* ------------------------------------------------ 2.8 */
      {
        n: "2.8",
        title: "Quick revision — elastic constants, axial deformation and compound stresses",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "E = σ/e, G = τ/∅, k = σn/ev, μ = ey/ex (0 to 0.5) (p.5); derivations of E = 2G(1+μ) and E = 3K(1−2μ); generalised Hooke's law (§2.1).",
            "E-G-k-μ relations; isotropic has only 2 independent constants (p.5).",
            "ΔL formulas: PL/AE, WL/2AE, 4PL/(πEd1d2), LαΔT (p.6); stepped bars ΣPL/AE; rectangular taper PL ln(a/b)/[Et(a−b)] (§2.2).",
            "Indeterminate bars: equilibrium + compatibility + δ = PL/AE; composite bars σs = mσc, σc = P/(Ac + mAs) (§2.3).",
            "Thermal: free 0, restrained EαΔT, gap E(LαΔT − δ)/L; composite (α₁ − α₂)ΔT = σ₁/E₁ + σ₂/E₂ (§2.4).",
            "σn and τ formulas on an inclined plane — τ = −(σx−σy)/2·sin2θ + τxy cos2θ (corrected); uniaxial/biaxial/pure shear special cases (p.6, §2.5).",
            "σP1, σP2, τmax formulas; principal and max-shear planes are 45° apart (p.7).",
            "Mohr's circle: centre (σx+σy)/2, radius τmax, angle on circle = 2θ; X(σx, τxy), Y(σy, −τxy) (p.7, §2.6).",
            "Principal strains; rectangular rosette γxy = 2ε45 − ε0 − ε90; σ1 = E(ε1 + με2)/(1 − μ²) (§2.6).",
            "Theories of failure: Rankine (brittle), Tresca and von Mises (ductile); τy = 0.5σy / 0.577σy (§2.7).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "τmax = (σP1 − σP2)/2 — same value whether computed analytically or read off Mohr's circle as the radius (p.7).",
            "Self-weight elongation is half the external-load elongation for a prismatic bar (WL/2AE vs PL/AE) (p.6).",
            "θp1 and θp2 (major/minor principal planes) are 90° apart; principal planes and max-shear planes are 45° apart (p.7).",
            "Number of independent elastic constants: 2 (isotropic), 9 (orthotropic), 21 (anisotropic) (p.5).",
            "In a composite bar the load divides in proportion to AE, not area; in a fixed-fixed bar the nearer support takes more load.",
            "On a principal plane shear stress is zero — use this to check any transformation formula.",
          ] },
          { k: "h", t: "🔗 Related in Civil Educator" },
          { k: "list", items: [
            "<a href=\"#/read/som/1\">Ch. 1 — Stress, strain, volumetric strain, creep</a> (prerequisite)",
            "<a href=\"#/read/som/4\">Ch. 4 — Bending and shear stress in beams</a> (where σ and τ combine)",
            "<a href=\"#/read/som/6\">Ch. 6 — Torsion, combined bending and torsion</a> (principal stresses in shafts)",
            "<a href=\"#/read/som/7\">Ch. 7 — Thin and thick cylinders</a> (biaxial stress states)",
            "Codes: <a href=\"#/code/is800\">IS 800</a> (steel constants, fy/√3), <a href=\"#/code/is456\">IS 456</a> (E_c, modular ratio)",
          ] },
        ],
      },
    ],
  },

  /* ============================================================ CH 3
     v29 — rebuilt through the Phase 1 chapter quality gate. Notes
     blocks kept with (p.N); errors corrected openly; new material
     web-researched and linked. Log: claude/research-log-som.md */
  {
    id: "som-3",
    n: 3,
    title: "Centroid, Moment of Inertia and SFD/BMD",
    hi: "केन्द्रक, जड़त्व आघूर्ण एवं SFD/BMD",
    blurb: "Centroid by first moments and by composite areas, centroids of all standard shapes (with the reference edge for each), moment of inertia with parallel- and perpendicular-axis theorems, radius of gyration and a full standard-section table; then beams, supports and reactions, and shear force and bending moment diagrams with the load–shear–moment rules — with 7 worked examples and 3 to-scale figures.",
    mins: 45,
    sections: [
      /* ------------------------------------------------ 3.1 */
      {
        n: "3.1",
        title: "Centroid and centre of gravity",
        hi: "केन्द्रक और गुरुत्व केंद्र",
        blocks: [
          { k: "h", t: "📘 Notes — p.8" },
          { k: "def", term: "Centroid", t: "The point where the whole area of the figure is assumed to be concentrated. (p.8)" },
          { k: "def", term: "Centre of Gravity (C.G)", t: "The point through which the whole weight of the body is assumed to act. (p.8)" },
          { k: "list", items: [
            "In a 2D view, the centroid and C.G are located at the same point. (p.8)",
            "The centroid may lie <b>outside</b> the section — e.g. in an L-shaped section or a C-shaped/channel section, the C.G marked point lies outside the material. (p.8)",
          ] },
          { k: "note", t: "Centroid and C.G coincide only when the body is <b>homogeneous</b> (same density throughout) and in a uniform gravity field. For a plane lamina of uniform thickness and material that is always true, which is what the notes mean by '2D view'. For a composite of steel and concrete, the C.G (weight-weighted) and the centroid of the concrete-equivalent section (§2.3, modular ratio) are different points." },
          { k: "h", t: "📘 Why the formula works — first moment of area" },
          { k: "p", t: "The <b>first moment of area</b> about an axis is ∫y dA — each bit of area times its distance from the axis. The centroid is the point at which the whole area, concentrated, would give the same first moment: ȳ·A = ∫y dA. For a shape made of simple parts the integral becomes a sum. A useful consequence: <b>the first moment about any axis through the centroid is zero</b> — which is exactly why the neutral axis of a beam passes through the centroid (<a href=\"#/read/som/4\">Chapter 4.1</a>)." },
          { k: "eq", expr: "Centroid of a lamina made of different sub-areas:  x̄ = ΣA·x̄ / ΣA   ;   ȳ = ΣA·ȳ / ΣA", where: [
            ["holes", "a hole or cut-out is entered as a NEGATIVE area at its own centroid"],
            ["reference axis", "any axis can be chosen; pick one through an edge so all distances are positive"],
            ["symmetry", "if the shape has an axis of symmetry, the centroid lies on it — only the other coordinate needs calculating"],
          ] },
          { k: "list", items: [
            "The C.G of a rectangle lies at the point where its two diagonals meet. (p.8)",
            "A body, whether regular or irregular, has only <b>one</b> C.G. (p.8)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Composite section ka centroid nikalne ka tareeka simple hai: section ko standard shapes (rectangle, triangle, circle...) mein todo, har shape ka apna area aur apna centroid nikalo, phir weighted average lo (ΣA·x̄/ΣA). Yeh wahi principle hai jo physics mein center-of-mass nikalne mein use hota hai." },
          { k: "trap", t: "L-shape ya channel-shape jaisi sections mein centroid section ke <b>material se bahar</b> bhi ho sakta hai (khali jagah mein) — yeh galat nahi hai, sirf iska matlab hai ki section symmetric nahi hai un axes ke around. (p.8) Hole wale section mein hole ka area <b>minus</b> karna mat bhoolo." },
        ],
      },

      /* ------------------------------------------------ 3.2 */
      {
        n: "3.2",
        title: "Centroids of standard sections",
        hi: "मानक परिच्छेदों के केन्द्रक",
        blocks: [
          { k: "h", t: "📘 Notes — p.9" },
          { k: "list", items: [
            "<b>Semicircle</b> (radius R, flat side as base): ȳ = 4R/3π, measured from the flat base. (p.9)",
            "<b>Quadrant circle</b> (radius R): ȳ = 4R/3π. (p.9)",
          ] },
          { k: "eq", expr: "Trapezoid (top width a, bottom width b, height h):  ȳ = (h/3) · [(b + 2a)/(b + a)]   ;   A = ½h(a + b)", where: [
            ["ȳ measured from", "the bottom (width b). Check: a = 0 gives a triangle, ȳ = h/3 ✔; a = b gives a rectangle, ȳ = h/2 ✔"],
          ] },
          { k: "eq", expr: "Parabolic Segment:  A = (2/3)bh  ;  centroid at (3b/8, 2h/5) from the least side", where: [] },
          { k: "eq", expr: "Parabolic Spandrel:  A = (1/3)bh  ;  centroid at (¼b, 3h/10) from the least side", where: [] },
          { k: "dia", id: "hb-som-parab" },
          { k: "note", t: "<b>Pinning down 'from the least side'.</b> With the parabola's vertex O at a corner of the b × h rectangle (figure), the segment's centroid is 3b/8 from the parabola's axis (the edge through O) and 2h/5 from the opposite edge (= 3h/5 from the edge through O); the spandrel's is b/4 from the far vertical edge (= 3b/4 from O) and 3h/10 from the edge through O. Same values as <a href=\"https://mathalino.com/node/1580\" target=\"_blank\" rel=\"noopener\">MATHalino's centroid table</a>, and re-derived here by integration (spandrel: x̄ = ∫x·y dx / A = 3b/4 with y = h(x/b)²; segment = rectangle − spandrel)." },
          { k: "cmp", t: "Centroids of standard shapes (verified against Engineering Statics, an open textbook)", cols: ["Area", "Centroid (reference)"], rows: [
            ["Rectangle b × h", "bh", "h/2 from base"],
            ["Triangle base b, height h", "bh/2", "h/3 from base (2h/3 from apex)"],
            ["Semicircle radius r", "πr²/2", "4r/3π ≈ 0.424r from the diameter"],
            ["Quarter circle radius r", "πr²/4", "4r/3π from each straight edge"],
            ["Trapezoid (a top, b bottom)", "h(a + b)/2", "(h/3)(b + 2a)/(b + a) from the b side"],
            ["Parabolic segment", "2bh/3", "see figure / note above"],
            ["Parabolic spandrel", "bh/3", "see figure / note above"],
          ] },
          { k: "note", t: "Semicircle, quarter circle and triangle rows from <a href=\"https://engineeringstatics.org/centroids-moi-tables-2.html\" target=\"_blank\" rel=\"noopener\">Engineering Statics: Open and Interactive</a> (Baker &amp; Haynes)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Parabolic segment aur parabolic spandrel ko ek hi bounding rectangle (b × h) mein socho — us rectangle ka area bh hai. Segment iska 2/3 hissa cover karta hai (A = ⅔bh), spandrel baaki 1/3 hissa (A = ⅓bh) — notes ke figure mein bhi rectangle ko curve se do regions '2/3' aur '1/3' mein baant kar dikhaya gaya hai. (p.9)" },
          { k: "real", t: "Parabolic spandrel ka area aur centroid seedha kaam aata hai cantilever ke BMD mein (UDL ka BMD ek parabolic spandrel hai) — moment-area method (<a href=\"#/read/som/5\">Chapter 5.2</a>) mein slope aur deflection isi area aur centroid se nikalte hain." },
          { k: "trap", t: "Semicircle aur quadrant circle dono ka ȳ formula same hai (4R/3π) — par yaad rakho yeh distance hamesha us shape ke <b>flat/straight base edge</b> se measure hota hai, diameter ya centre se nahi. (p.9) (Semicircle ke liye 'flat edge' hi diameter hai — distance centre-line se nahi, us straight edge se hai.)" },
        ],
      },

      /* ------------------------------------------------ 3.3 */
      {
        n: "3.3",
        title: "Moment of inertia — theorems, radius of gyration and standard sections",
        hi: "जड़त्व आघूर्ण — प्रमेय, परिभ्रमण त्रिज्या और मानक परिच्छेद",
        blocks: [
          { k: "h", t: "📘 Notes — p.8" },
          { k: "def", term: "Moment of Inertia (Second moment of area)", t: "Also known as the moment of inertia of a plane area, defined for a single known symmetrical geometric body. IxG = ∫y²da and IyG = ∫x²da, taken about the centroidal axes. (p.8)" },
          { k: "p", t: "Where the first moment (§3.1) locates the centroid, the <b>second moment</b> ∫y² dA measures how far the area is spread from an axis. Because distance is squared, material far from the axis counts much more — the reason I-sections and hollow tubes are efficient. Unit: mm⁴. It governs bending stiffness and stress (EI, M/I — <a href=\"#/read/som/4\">Chapter 4</a>) and buckling (<a href=\"#/read/som/5\">Chapter 5.4</a>). Not to be confused with mass moment of inertia (kg·m²) used in dynamics." },
          { k: "eq", expr: "Parallel Axes Theorem:  Ixx = IxG + Ay²  (Ixx relative to x-axis)   ;   Iyy = IyG + Ax²  (Iyy relative to y-axis)", where: [
            ["x, y", "distance of the reference axis from the centroidal axis"],
          ] },
          { k: "list", items: [
            "M.I is <b>minimum</b> if taken about the C.G (i.e. x = 0 & y = 0 ⇒ Ixx = IxG, Iyy = IyG). (p.8)",
            "M.I is <b>maximum</b> if taken about the major principal axis (Ixx if y &gt; x, = Iyy if x &gt; y). (p.8)",
          ] },
          { k: "note", t: "<b>Clarifying the two 'minimum/maximum' statements.</b> (1) Among a family of <i>parallel</i> axes, the one through the centroid gives the least I — the parallel-axis theorem only ever adds Ay². (2) Among all axes <i>through the centroid</i> in different directions, I is greatest about the <b>major principal axis</b> and least about the <b>minor principal axis</b>; for a section with an axis of symmetry these are the symmetry axis and the axis perpendicular to it. Example: a 230 × 450 beam has Imax about the horizontal axis (bending on its depth) and Imin about the vertical one. (General engineering knowledge.)" },
          { k: "cmp", t: "Standard sections — IxG about the centroid (p.8)", cols: ["IxG"], rows: [
            ["Rectangle (width b, depth d)", "bd³/12"],
            ["Triangle (base b, height h)", "bh³/36"],
            ["Circle (diameter d)", "πd⁴/64"],
          ] },
          { k: "eq", expr: "Polar moment of inertia  Ip = IxG + IyG   (sum of second moment of area about the x and y axes)", where: [
            ["name", "this is the perpendicular-axis theorem: I about an axis normal to the plane = Ix + Iy (any perpendicular pair meeting at that point)"],
            ["use", "circular shafts in torsion — J = πd⁴/32 = 2 × πd⁴/64 (Chapter 6.2)"],
          ] },
          { k: "list", items: [
            "Rectangle, origin at the corner: Ixx = bd³/3 (= bd³/12 + (bd)(d/2)²); Iyy = db³/3. (p.8)",
            "Triangle, origin at the vertex (apex): Ixx = bh³/12 (= bh³/36 + (½bh)(⅓h)²). (p.8)",
          ] },
          { k: "note", t: "<b>Correction to the notes — triangle:</b> bh³/12 = bh³/36 + (½bh)(⅓h)² is the moment of inertia about the <b>base</b>, because the centroid is h/3 from the base. About an axis through the <b>apex</b> parallel to the base the distance is 2h/3, giving bh³/36 + (½bh)(⅔h)² = <b>bh³/4</b>. The base value bh³/12 matches <a href=\"https://engineeringstatics.org/centroids-moi-tables-3.html\" target=\"_blank\" rel=\"noopener\">Engineering Statics' MOI table</a>; the apex value is derived (Worked example 3.3)." },
          { k: "def", term: "Radius of gyration (k)", t: "k = √(I/A) — the distance from the axis at which the whole area, concentrated in a thin strip, would give the same I. It packs 'how spread out' a section is into a length, and it is what appears in a column's slenderness ratio L/k (<a href=\"#/read/som/5\">Chapter 5.4</a>). Columns buckle about the axis with the <b>least</b> k." },
          { k: "cmp", t: "Moment of inertia of standard sections (centroidal unless stated)", cols: ["I", "Notes"], rows: [
            ["Rectangle b × d", "bd³/12;  about base bd³/3", "k = d/√12 = 0.289d"],
            ["Hollow rectangle B × D, hole b × d", "(BD³ − bd³)/12", "hole must share the centroid"],
            ["Triangle b × h", "bh³/36;  base bh³/12;  apex bh³/4", "apex value derived — see note"],
            ["Circle diameter d", "πd⁴/64", "k = d/4;  polar J = πd⁴/32"],
            ["Hollow circle D, d", "π(D⁴ − d⁴)/64", "J = π(D⁴ − d⁴)/32"],
            ["Semicircle radius r", "about diameter πr⁴/8;  centroidal ≈ 0.1098r⁴", "Engineering Statics table"],
            ["Quarter circle radius r", "about straight edge πr⁴/16;  centroidal ≈ 0.0549r⁴", "Engineering Statics table"],
          ] },
          { k: "real", t: "Steel designers rarely compute I for rolled sections by hand — the I, Z and r of every ISMB, ISMC, ISA section are tabulated in the steel tables (<a href=\"#/code/is808\">IS 808</a> dimensions; SP 6(1) handbook). Hand calculation is still needed for <b>built-up</b> sections (plates welded to an I-section, double angles), and for RCC T- and L-beams." },
          { k: "dia", id: "hb-som-tsec" },
          { k: "eg", title: "Worked example 3.1 — centroid and moments of inertia of a T-section", given: "Flange 150 × 20 mm on top of a web 20 × 180 mm (total depth 200 mm). Find: ȳ from the bottom, Ixx and Iyy about centroidal axes, and the section moduli (top and bottom).", steps: [
            { t: "Areas and centroids from the bottom", w: "Flange A1 = 3000 mm², y1 = 180 + 10 = 190 mm\nWeb A2 = 3600 mm², y2 = 90 mm\nA = 6600 mm²" },
            { t: "Centroid (symmetric about the vertical axis, so x̄ is on it)", w: "ȳ = (3000 × 190 + 3600 × 90) / 6600 = 894 000 / 6600 = 135.45 mm\n(64.55 mm below the top)" },
            { t: "Ixx — parallel axis theorem for each part", w: "Flange: 150 × 20³/12 + 3000 × (190 − 135.45)² = 100 000 + 8 925 620 = 9 025 620\nWeb: 20 × 180³/12 + 3600 × (135.45 − 90)² = 9 720 000 + 7 438 017 = 17 158 017\nIxx = 26 183 637 mm⁴ ≈ 2.618 × 10⁷ mm⁴" },
            { t: "Iyy — both centroids lie on the y-axis, so no Ax² terms", w: "Iyy = 20 × 150³/12 + 180 × 20³/12 = 5 625 000 + 120 000 = 5.745 × 10⁶ mm⁴" },
            { t: "Section moduli Z = I / (distance to extreme fibre)", w: "Z_top = 26 183 637 / 64.55 = 4.06 × 10⁵ mm³\nZ_bottom = 26 183 637 / 135.45 = 1.93 × 10⁵ mm³" },
          ], ans: "ȳ = 135.45 mm from the bottom; Ixx = 2.62 × 10⁷ mm⁴; Iyy = 5.75 × 10⁶ mm⁴; Z_top = 4.06 × 10⁵, Z_bot = 1.93 × 10⁵ mm³. Interpretation: in sagging, the bottom of the web (smaller Z) has twice the stress of the flange top — which is why T-beams in RCC put the wide flange (the slab) in compression and the steel at the bottom." },
          { k: "eg", title: "Worked example 3.2 — why hollow sections are efficient", given: "A solid round bar of 100 mm diameter is compared with a hollow tube of 150 mm outer diameter having the SAME area. Find: inner diameter, I and k for both.", steps: [
            { t: "Solid bar", w: "A = π × 100²/4 = 7854 mm²;  I = π × 100⁴/64 = 4.909 × 10⁶ mm⁴;  k = d/4 = 25 mm" },
            { t: "Tube with equal area", w: "π(150² − d²)/4 = 7854  ⇒  d² = 22 500 − 10 000 = 12 500  ⇒  d = 111.8 mm" },
            { t: "Tube I and k", w: "I = π(150⁴ − 111.8⁴)/64 = π(5.0625 − 1.5625) × 10⁸/64 = 1.718 × 10⁷ mm⁴\nk = √(1.718 × 10⁷ / 7854) = 46.8 mm" },
          ], ans: "Same steel weight, but the tube has 3.5 times the I and nearly double k. Interpretation: 3.5× bending stiffness, and a much lower slenderness L/k for buckling — why scaffolding, truss members and steel columns use tubes and I-sections rather than solid bars." },
          { k: "eg", title: "Worked example 3.3 — triangle about centroid, base and apex", given: "Triangle with base b = 120 mm, height h = 90 mm. Find: I about the centroidal axis, the base, and the apex (axes parallel to the base).", steps: [
            { t: "Centroidal", w: "I_G = bh³/36 = 120 × 90³/36 = 2.43 × 10⁶ mm⁴;  A = 5400 mm²" },
            { t: "Base (centroid h/3 = 30 mm away)", w: "I = 2.43 × 10⁶ + 5400 × 30² = 7.29 × 10⁶ = bh³/12 ✔" },
            { t: "Apex (centroid 2h/3 = 60 mm away)", w: "I = 2.43 × 10⁶ + 5400 × 60² = 2.187 × 10⁷ = bh³/4 ✔" },
          ], ans: "2.43 × 10⁶ (centroid) < 7.29 × 10⁶ (base) < 2.187 × 10⁷ mm⁴ (apex). Interpretation: the apex value is three times the base value because the apex is twice as far from the centroid (distance squared), and nine times the centroidal value." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Parallel axis theorem batata hai ki centroid se door jitna axis le jaoge, MOI utna hi <b>badhega</b> — kabhi kam nahi hoga, kyunki Ay² term hamesha positive add hota hai. Rectangle ka example dekho: corner se MOI (bd³/3) centroid se MOI (bd³/12) ka <b>4 guna</b> hai — kyunki y (=d/2) itna shift hua ki Ay² term hi (bd/12)³ ke barabar teen guna aa gaya." },
          { k: "note", t: "Clarifying the arithmetic in the line above: Ay² = (bd)(d/2)² = bd³/4, which is <b>3 × bd³/12</b>. Adding it to bd³/12 gives 4 × bd³/12 = bd³/3." },
          { k: "trap", t: "Ay² mein 'y' hamesha <b>centroid se naye axis tak ki distance</b> honi chahiye, kisi random axis se nahi — aur woh distance sahi axis (x ya y) ke perpendicular measure ki jaati hai, warna theorem galat result dega. (p.8) Ek do-step galti: kisi non-centroidal axis A se doosre non-centroidal axis B tak seedha Ad² mat lagao — pehle centroid par aao (I_G = I_A − A·d_A²), phir B par jao." },
        ],
      },

      /* ------------------------------------------------ 3.4 */
      {
        n: "3.4",
        title: "Beams, supports, loads and reactions",
        hi: "धरन, आधार, भार और प्रतिक्रियाएँ",
        blocks: [
          { k: "p", t: "Before a shear force or bending moment can be found, the reactions must be known — and that depends on how the beam is supported. (General engineering knowledge — standard in every SOM text.)" },
          { k: "cmp", t: "Supports — what each one can resist", cols: ["Reactions provided", "Example"], rows: [
            ["Roller", "1 — force perpendicular to the surface", "Bridge bearing that allows expansion"],
            ["Hinge / pin", "2 — horizontal + vertical force, no moment", "Truss joint, pinned base"],
            ["Fixed", "3 — horizontal, vertical force and moment", "Cantilever built into a wall, RCC column–beam joint"],
          ] },
          { k: "cmp", t: "Beam types", cols: ["Supports", "Determinate?"], rows: [
            ["Simply supported", "Pin + roller at the ends", "Yes — 3 reactions, 3 equations"],
            ["Cantilever", "One end fixed, other free", "Yes"],
            ["Overhanging", "Pin + roller with one or both ends extending past them", "Yes"],
            ["Propped cantilever / fixed / continuous", "More supports than needed", "No — need compatibility (Theory of Structures)"],
          ] },
          { k: "p", t: "<b>Loads:</b> point (concentrated) load; uniformly distributed load (UDL, w per metre — replace by wL acting at its middle when finding reactions); uniformly varying load (UVL, triangular — total wL/2 acting at L/3 from the larger end, using the triangle centroid of §3.2); and applied couples. Reactions come from ΣV = 0, ΣH = 0 and ΣM = 0 about a convenient point (usually a support, so that its unknown reaction drops out)." },
          { k: "trap", t: "UDL ko reaction nikalne ke liye resultant (wL at centre) se badal sakte ho, par <b>SF/BM nikalte waqt nahi</b> — section ke ek taraf jitna UDL hai sirf utna hi lena hai. UVL ka resultant L/3 par lagta hai (bade end se), L/2 par nahi." },
        ],
      },

      /* ------------------------------------------------ 3.5 */
      {
        n: "3.5",
        title: "Shear force and bending moment diagrams",
        hi: "कर्तन बल एवं बंकन आघूर्ण आरेख",
        blocks: [
          { k: "h", t: "📘 Notes — p.9" },
          { k: "def", term: "Shear Force (F)", t: "The algebraic sum of all the forces on either side of the section. (p.9)" },
          { k: "def", term: "Bending Moment (M)", t: "The algebraic sum of all the moments of the forces on either side of the section. (p.9)" },
          { k: "list", items: [
            "<b>Shear Force sign convention:</b> (+ve) is a clockwise rotation tendency; (−ve) is anticlockwise. (p.9)",
            "<b>Bending Moment sign convention:</b> (+ve) is sagging (smile-shaped curvature); (−ve) is hogging (sad-shaped curvature). (p.9)",
          ] },
          { k: "eq", expr: "W = dF/dx = d²M/dx²   (or)   F = dM/dx   ;   M = ∫F dx = ∫∫w dx   (F = ∫w dx)", where: [
            ["W", "intensity of the distributed load"],
          ] },
          { k: "note", t: "<b>The sign in dF/dx.</b> With the notes' conventions (shear + when the left part is pushed up, i.e. clockwise; sagging +) and a <b>downward</b> load w taken as positive, a downward load makes the shear fall from left to right, so <b>dF/dx = −w</b>; dM/dx = F holds as written. Open textbooks that take <i>upward</i> load as positive write dV/dx = +w (<a href=\"https://engineeringstatics.org/VM_relations.html\" target=\"_blank\" rel=\"noopener\">Engineering Statics — V–M relations</a>, which flags exactly this convention switch). Same physics; the sign follows the load convention." },
          { k: "h", t: "📘 Rules you can read straight off the relations" },
          { k: "list", items: [
            "<b>No load</b> on a stretch → shear constant, moment linear.",
            "<b>UDL</b> → shear linear, moment parabolic (second degree).",
            "<b>UVL</b> → shear parabolic, moment cubic.",
            "<b>Point load or reaction</b> → a vertical jump in the SFD equal to the load; a kink (change of slope) in the BMD.",
            "<b>Applied couple</b> → a jump in the BMD equal to the couple; no change in the SFD.",
            "<b>Change in M between two sections = area of the SFD between them</b>; maximum M where F = 0 (or changes sign).",
          ] },
          { k: "note", t: "Rules as summarised by <a href=\"https://mathalino.com/node/366\" target=\"_blank\" rel=\"noopener\">MATHalino — relation between load, shear and moment</a>, all of which follow from integrating the two relations above." },
          { k: "list", items: [
            "<b>Pure bending:</b> B.M is constant throughout the section — this happens for a cantilever with an applied couple. (p.9)",
            "<b>Position of contraflexure:</b> the point where B.M = 0, or where B.M changes sign. (p.9)",
            "<b>B.M is maximum</b> when S.F is zero, or where S.F changes sign. (p.9)",
          ] },
          { k: "p", t: "Pure bending also occurs in the <b>middle third of a simply supported beam loaded at its third points</b> — between the two loads the shear is zero and the moment constant. That is the set-up of the flexural-strength test on 150 × 150 mm concrete beams over a 600 mm span (<a href=\"https://cs-iitd.vlabs.ac.in/exp/flexural-strength-test/procedure.html\" target=\"_blank\" rel=\"noopener\">IIT Delhi Virtual Lab</a>; <a href=\"#/code/is516\">IS 516</a>), so the measured failure stress is a pure bending stress, f = PL/bd² (from M = PL/6 and Z = bd²/6 — derived here)." },
          { k: "h", t: "📘 Procedure for any statically determinate beam" },
          { k: "steps", items: [
            "Find all reactions (§3.4).",
            "Mark key points: supports, point loads, start/end of distributed loads, couples.",
            "SFD: start at zero at the left end, jump up/down at each point force, slope at −w along distributed loads; it must close at zero at the right end (check).",
            "Find where F = 0 inside each segment — that is where M is a local maximum.",
            "BMD: M = 0 at free ends and pinned/roller ends (unless a couple acts there); get M at each key point from the SFD area or by taking moments of forces on one side.",
            "Locate points of contraflexure by setting the M-expression of that segment to zero.",
          ] },
          { k: "dia", id: "hb-som-sfbm" },
          { k: "eg", title: "Worked example 3.4 — overhanging beam: SFD, BMD, maximum moment and contraflexure", given: "Beam ABC: pin at A, roller at B, AB = 6 m, overhang BC = 2 m. UDL 10 kN/m on AB; point load 20 kN at C. Find: reactions, SFD, BMD, maximum sagging and hogging moments, point of contraflexure.", steps: [
            { t: "Reactions (moments about A)", w: "R_B × 6 = 10 × 6 × 3 + 20 × 8 = 180 + 160  ⇒  R_B = 56.67 kN\nR_A = (60 + 20) − 56.67 = 23.33 kN" },
            { t: "Shear force", w: "Just right of A: +23.33\nJust left of B: 23.33 − 10 × 6 = −36.67\nJust right of B: −36.67 + 56.67 = +20.00 (constant to C)\nAt C: 20 − 20 = 0 ✔ closes" },
            { t: "Where F = 0 in AB", w: "23.33 − 10x = 0  ⇒  x = 2.333 m from A" },
            { t: "Maximum sagging moment", w: "M = 23.33 × 2.333 − 10 × 2.333²/2 = 54.44 − 27.22 = 27.22 kN·m" },
            { t: "Moment at B (take moments of the overhang)", w: "M_B = −20 × 2 = −40 kN·m (hogging)" },
            { t: "Point of contraflexure in AB", w: "M(x) = 23.33x − 5x² = 0  ⇒  x = 23.33/5 = 4.667 m from A" },
          ], ans: "R_A = 23.33 kN, R_B = 56.67 kN; M_max sagging = 27.22 kN·m at 2.33 m; M_max hogging = 40 kN·m at B; contraflexure at 4.67 m from A. Interpretation: the hogging moment over the support is larger than the span moment, so in an RCC overhang the main steel must go at the TOP over B and be extended past the contraflexure point." },
          { k: "eg", title: "Worked example 3.5 — cantilever with UDL and an end load", given: "A 3 m cantilever carries a UDL of 4 kN/m over its full length and 10 kN at the free end. Find: shear and moment at the fixed end, and the shape of each diagram.", steps: [
            { t: "Shear at the fixed end (sum of loads beyond it)", w: "F = 10 + 4 × 3 = 22 kN" },
            { t: "Moment at the fixed end", w: "M = −(10 × 3 + 4 × 3 × 1.5) = −(30 + 18) = −48 kN·m (hogging)" },
            { t: "Shapes", w: "SFD: 10 at the free end rising linearly to 22 at the support\nBMD: parabolic, 0 at the free end to −48 at the support" },
          ], ans: "F = 22 kN and M = 48 kN·m hogging at the support. Interpretation: in a cantilever the whole BMD is hogging, so a balcony or chajja slab needs its main steel at the TOP — a classic site mistake is placing it at the bottom." },
          { k: "eg", title: "Worked example 3.6 — modulus of rupture from a beam test", given: "A 150 × 150 mm concrete beam on a 600 mm span fails at a total load P = 25 kN under third-point loading, with the crack in the middle third. Find: the modulus of rupture.", steps: [
            { t: "Constant moment in the middle third", w: "Each load P/2 at L/3 from a support: M = (P/2)(L/3) = PL/6 = 25 000 × 600 / 6 = 2.5 × 10⁶ N·mm" },
            { t: "Bending stress", w: "Z = bd²/6 = 150 × 150²/6 = 562 500 mm³\nf = M/Z = 2.5 × 10⁶ / 562 500 = 4.44 N/mm²  (= PL/bd² ✔)" },
          ], ans: "Modulus of rupture ≈ 4.44 N/mm². Interpretation: this is the tensile strength of concrete in bending — roughly a tenth of its compressive strength, which is why concrete beams need steel in the tension zone." },
          { k: "eg", title: "Worked example 3.7 — simply supported beam with a triangular (UVL) load", given: "A 6 m simply supported beam AB carries a load varying from 0 at A to 12 kN/m at B. Find: reactions, position and value of the maximum moment.", steps: [
            { t: "Resultant and reactions", w: "Total load = wL/2 = 12 × 6/2 = 36 kN, acting L/3 = 2 m from B (4 m from A)\nR_A = 36 × 2/6 = 12 kN (= wL/6);  R_B = 24 kN (= wL/3)" },
            { t: "Shear at distance x from A (load intensity there = wx/L)", w: "F(x) = R_A − (w x²)/(2L) = 12 − x²  ⇒  F = 0 at x = √12 = 3.464 m (= L/√3)" },
            { t: "Maximum moment", w: "M(x) = R_A·x − w x³/(6L) = 12x − x³/3\nM_max = 12 × 3.464 − 3.464³/3 = 41.57 − 13.86 = 27.71 kN·m (= wL²/(9√3) ✔)" },
          ], ans: "R_A = 12 kN, R_B = 24 kN; M_max = 27.71 kN·m at 3.46 m from A. Interpretation: the maximum is NOT at mid-span, and NOT under the centroid of the load — it sits where the shear is zero, shifted towards the heavier end. Soil and water pressure on retaining walls and tank walls load members exactly this way." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "SF aur BM ke beech ka relation (F = dM/dx) hi woh reason hai jiski wajah se 'BM max jahan SF zero' rule kaam karta hai — jahan derivative (F) zero hota hai, wahin function (M) ka peak/trough hota hai, seedha calculus se. Isi wajah se practically kisi bhi beam mein sabse pehle SF=0 wala point dhoondte hain, phir wahan BM calculate karte hain — woh hi design ke liye critical section hota hai." },
          { k: "real", t: "BMD hi batata hai steel kahan lagega: sagging zone mein neeche, hogging zone mein upar (support ke upar, cantilever/chajja mein). Contraflexure point ke aage tak bars extend karke hi curtail kiye jaate hain — IS 456 ke development length/curtailment rules isi par based hain." },
          { k: "trap", t: "Yahan diya gaya sign convention (SF: +ve clockwise; BM: +ve sagging) universal nahi hai — kai textbooks isse ulta ya thoda alag convention use karte hain. Kisi bhi problem mein pehle apna convention fix karo aur poori solution mein consistent raho. (p.9) Aur 'BM max jahan SF zero' sirf <b>local</b> maximum deta hai — overhanging beam mein absolute maximum support par (jahan SF sign badalta hai, jump ke saath) bhi ho sakta hai, jaise Worked example 3.4 mein 40 > 27.22." },
        ],
      },

      /* ------------------------------------------------ 3.6 */
      {
        n: "3.6",
        title: "Quick revision — centroid, MOI and SFD/BMD",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Centroid vs C.G; centroid can lie outside an L/channel section (p.8); first moment ∫y dA, zero about a centroidal axis (§3.1).",
            "x̄ = ΣAx̄/ΣA composite centroid formula (p.8); holes as negative areas.",
            "Parallel axis theorem Ixx = IxG + Ay²; standard IxG for rectangle/triangle/circle (p.8); perpendicular axis theorem; radius of gyration k = √(I/A) (§3.3).",
            "Rectangle-at-corner (bd³/3) and triangle-at-base (bh³/12) / at-apex (bh³/4) MOI (p.8, corrected).",
            "Semicircle/quadrant ȳ = 4R/3π; trapezoid, parabolic segment and spandrel centroids with their reference edges (p.9, §3.2).",
            "Supports and reactions; UDL/UVL resultants (§3.4).",
            "SF and BM definitions, sign conventions, W-F-M calculus relation (dF/dx = −w for downward load), contraflexure (p.9); diagram-shape and jump rules (§3.5).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "M.I is minimum about the centroidal axis, maximum about the major principal axis (p.8).",
            "Parabolic segment area = ⅔bh; parabolic spandrel area = ⅓bh — together they fill the bounding rectangle bh (p.9).",
            "F = dM/dx ⇒ BM is maximum where SF = 0 or changes sign; contraflexure is where BM = 0 or changes sign (p.9).",
            "Pure bending (constant BM) occurs under a pure applied couple, e.g. cantilever with end moment (p.9) — and in the middle third of a third-point-loaded beam.",
            "Hollow sections give several times the I and k of a solid bar of the same weight.",
          ] },
          { k: "h", t: "🔗 Related in Civil Educator" },
          { k: "list", items: [
            "<a href=\"#/read/som/4\">Ch. 4 — Bending stress f = M/I·y and shear stress</a> (uses ȳ, I, Z from here)",
            "<a href=\"#/read/som/5\">Ch. 5 — Deflection (moment-area uses the BMD) and columns (uses k)</a>",
            "<a href=\"#/read/som/6\">Ch. 6 — Torsion (polar moment J)</a>",
            "Code: <a href=\"#/code/is516\">IS 516</a> (flexural strength test)",
          ] },
        ],
      },
    ],
  },

  /* ============================================================ CH 4
     v30 — rebuilt through the Phase 1 chapter quality gate. Notes
     blocks kept with (p.N); errors corrected openly; new material
     web-researched and linked. Log: claude/research-log-som.md */
  {
    id: "som-4",
    n: 4,
    title: "Theory of Bending and Shear Stress in Beams",
    hi: "बंकन सिद्धांत एवं शहतीर में कर्तन प्रतिबल",
    blurb: "Assumptions and full derivation of M/I = f/y = E/R, section modulus and moment of resistance, the strongest and stiffest beam from a log, beams of uniform strength, flitched (composite) beams, plastic moment and shape factor with the IS 800 link, and the shear-stress formula q = F·aȳ/(I·b) — derived, with every standard-section result and shear flow — with 8 worked examples.",
    mins: 50,
    sections: [
      /* ------------------------------------------------ 4.1 */
      {
        n: "4.1",
        title: "Simple bending, neutral layer and the bending equation",
        hi: "सरल बंकन, उदासीन परत और बंकन समीकरण",
        blocks: [
          { k: "h", t: "📘 Notes — p.10" },
          { k: "def", term: "Simple Bending", t: "Bending of a beam accompanied by pure bending only (i.e. S.F = 0 or negligible throughout the section). The stress induced due to pure/simple bending is called <b>bending stress</b>. (p.10)" },
          { k: "def", term: "Neutral Layer", t: "The layer which is neither compressed nor elongated due to bending (unchanged in length). Bending stress is zero (f = 0) in the neutral layer. (p.10)" },
          { k: "def", term: "Neutral Axis (N.A)", t: "The line of intersection of the neutral layer with the plane of cross-section. It passes through the C.G of the c/s, and is the axis where the stress and strain change sign. (p.10)" },
          { k: "eq", expr: "Equation of pure bending (Bernoulli-Euler bending equation):  M/I = f/y = E/R", where: [
            ["R", "Radius of curvature (from N.A to centre)"],
            ["y", "Distance measured from the N.A"],
          ] },
          { k: "note", t: "The bending-equation figure shows a curved beam element with the two radii R–R meeting at the centre of curvature at an angle θ_m, with the bending moment M applied at both ends of the element. (p.10)" },
          { k: "h", t: "📘 Assumptions of the theory of simple bending" },
          { k: "list", items: [
            "The beam is initially straight and of uniform cross-section.",
            "The material is homogeneous and linearly elastic (stress below the proportional limit).",
            "E is the same in tension and compression.",
            "<b>Plane sections remain plane</b> and normal to the neutral axis after bending.",
            "Deflections are small and the radius of curvature is large compared with the depth.",
            "The beam is slender enough that shear deformation can be ignored.",
          ] },
          { k: "note", t: "Assumptions as listed by <a href=\"https://www.roymech.co.uk/Useful_Tables/Beams/Beam_theory.html\" target=\"_blank\" rel=\"noopener\">RoyMech — beam theory</a>. When one fails the formula needs modifying: two materials → transformed section (§4.4); stress past yield → plastic bending (§4.5); deep beams (span/depth small) → shear deformation matters, and IS 456 treats them separately." },
          { k: "h", t: "📘 Deriving M/I = f/y = E/R in three steps" },
          { k: "steps", items: [
            "<b>Geometry (plane sections):</b> a fibre at distance y from the neutral layer, bent to radius R, is stretched in proportion to y: strain e = y/R.",
            "<b>Material (Hooke's law):</b> f = E·e = E·y/R ⇒ <b>f/y = E/R</b> — stress is linear in y, zero at the N.A.",
            "<b>Equilibrium:</b> with no axial load, ∫f dA = (E/R)∫y dA = 0, so the first moment about the N.A is zero — the N.A passes through the <b>centroid</b> (§3.1). The moment of the stresses must equal M: ∫f·y dA = (E/R)∫y² dA = EI/R ⇒ <b>M/I = E/R</b>.",
          ] },
          { k: "p", t: "Same three steps as RoyMech's derivation (linked above). The result packs three useful forms: <b>f = M·y/I</b> (stress), <b>1/R = M/EI</b> (curvature — the starting point of deflection in <a href=\"#/read/som/5\">Chapter 5</a>) and <b>f = E·y/R</b> (stress from a known curvature, e.g. a wire bent round a drum)." },
          { k: "dia", id: "hb-som-bendstress" },
          { k: "eg", title: "Worked example 4.1 — bending stresses and curvature in a T-beam", given: "The T-section of Worked example 3.1 (I = 2.618 × 10⁷ mm⁴, y_top = 64.55 mm, y_bot = 135.45 mm) is a 4 m simply supported steel beam with a UDL of 8 kN/m. E = 2 × 10⁵ N/mm². Find: maximum bending stresses and the radius of curvature at mid-span.", steps: [
            { t: "Maximum moment (mid-span, SS beam with UDL)", w: "M = wL²/8 = 8 × 4²/8 = 16 kN·m = 16 × 10⁶ N·mm (sagging)" },
            { t: "Stress at the top (compression in sagging)", w: "f_top = M·y_top/I = 16 × 10⁶ × 64.55 / 2.618 × 10⁷ = 39.4 N/mm² (C)" },
            { t: "Stress at the bottom (tension)", w: "f_bot = 16 × 10⁶ × 135.45 / 2.618 × 10⁷ = 82.8 N/mm² (T)" },
            { t: "Radius of curvature", w: "R = EI/M = 2 × 10⁵ × 2.618 × 10⁷ / 16 × 10⁶ = 327 300 mm ≈ 327 m" },
            { t: "Consistency check: e = y/R = f/E", w: "135.45 / 327 300 = 4.14 × 10⁻⁴;  82.8 / 200 000 = 4.14 × 10⁻⁴ ✔" },
          ], ans: "f_top = 39.4 N/mm² (C), f_bot = 82.8 N/mm² (T), R ≈ 327 m. Interpretation: the curvature is tiny (a 327 m radius) yet it produces 83 N/mm² — bending is a very efficient way to generate stress, which is why it usually governs beam design." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Cross-section ke across, bending stress <b>linearly</b> distribute hota hai — N.A par zero, aur N.A se jitna door utna zyada, ek taraf compressive aur doosri taraf tensile (sagging beam mein upar compression, neeche tension). Yeh triangular stress diagram hi M/I=f/y relation ka source hai — f, y ke directly proportional hai." },
          { k: "trap", t: "'y' hamesha <b>N.A se</b> measure hota hai, extreme fibre se nahi. Maximum bending stress f_max extreme fibre par hi aata hai (y = y_max, jahan y_max top ya bottom fibre ki N.A se distance hai) — N.A par khud f = 0 hota hai. (p.10) Unsymmetrical section (T, channel) mein top aur bottom ka y alag hai — dono check karo." },
        ],
      },

      /* ------------------------------------------------ 4.2 */
      {
        n: "4.2",
        title: "Section modulus, moment of resistance and efficient sections",
        hi: "परिच्छेद मापांक, प्रतिरोध आघूर्ण और कुशल परिच्छेद",
        blocks: [
          { k: "h", t: "📘 Notes — p.10" },
          { k: "eq", expr: "Section modulus  Z = I/y   ⇒   f = M/Z   ;   Flexural Rigidity = EI   ;   Curvature (1/R) = M/EI = (Bending moment)/(Flexural rigidity)", where: [] },
          { k: "def", term: "Moment of resistance", t: "The largest moment a section can carry without its extreme-fibre stress exceeding the permissible stress: M_r = f_perm × Z. Design condition: applied M ≤ M_r. For an unsymmetrical section use the <b>smaller</b> Z (larger y)." },
          { k: "cmp", t: "Section modulus of common sections (Z = I/y_max)", cols: ["Z", "Z per unit area (efficiency)"], rows: [
            ["Rectangle b × d", "bd²/6", "d/6 — doubles if depth doubles"],
            ["Solid circle d", "πd³/32", "d/8"],
            ["Hollow circle D, d", "π(D⁴ − d⁴)/(32D)", "much higher than solid of equal area (Worked example 3.2)"],
            ["I-section", "I/(D/2) — from tables or §3.3", "highest: area concentrated at the flanges"],
          ] },
          { k: "p", t: "Z depends on <b>depth squared</b> but width only to the first power — so a beam is always placed with its larger dimension vertical, and a plank laid flat is weak. Z values derived from I in §3.3 (general engineering knowledge)." },
          { k: "eq", expr: "Max rectangle cut from a circle of diameter D:  Max dimensions = (D/√2, √(2/3)·D)   ;   Max square dimension = D/√2", where: [] },
          { k: "note", t: "<b>Correction to the notes — strongest beam from a log.</b> The beam of maximum <i>strength</i> maximises Z = bd²/6 with b² + d² = D². Setting d(bd²)/db = 0 gives <b>b = D/√3 ≈ 0.577D</b> and d = √(2/3)·D ≈ 0.816D (d : b = √2). The notes' depth is right but the breadth D/√2 is wrong — D/√2 is the side of the largest <i>square</i>. Result confirmed by <a href=\"https://www.esaral.com/q/the-strength-of-a-beam-varies-as-the-product-of-its-breadth-and-square-of-its-depth-96695\" target=\"_blank\" rel=\"noopener\">eSaral's worked solution</a> (b = 2a/√3 for radius a). The <b>stiffest</b> beam maximises I = bd³/12, giving b = D/2, d = (√3/2)·D (derived here)." },
          { k: "dia", id: "hb-som-log" },
          { k: "eg", title: "Worked example 4.2 — moment of resistance and safe load of a timber beam", given: "A timber beam 150 mm wide × 300 mm deep spans 5 m, simply supported. Permissible bending stress 10 N/mm². Find: moment of resistance and the safe UDL.", steps: [
            { t: "Section modulus", w: "Z = bd²/6 = 150 × 300²/6 = 2.25 × 10⁶ mm³" },
            { t: "Moment of resistance", w: "M_r = 10 × 2.25 × 10⁶ = 22.5 × 10⁶ N·mm = 22.5 kN·m" },
            { t: "Safe UDL from wL²/8 = M_r", w: "w = 8 × 22.5 / 5² = 7.2 kN/m" },
          ], ans: "M_r = 22.5 kN·m; safe UDL = 7.2 kN/m. Interpretation: laid flat (300 wide × 150 deep) Z would halve to 1.125 × 10⁶ mm³ and the safe load would halve too." },
          { k: "eg", title: "Worked example 4.3 — strongest and stiffest beams from a 450 mm log", given: "A round log has diameter D = 450 mm. Find: dimensions of the strongest and the stiffest rectangular beams, and compare the strongest with the largest square.", steps: [
            { t: "Strongest", w: "b = 450/√3 = 259.8 mm;  d = √(2/3) × 450 = 367.4 mm\nZ = 259.8 × 367.4²/6 = 5.846 × 10⁶ mm³" },
            { t: "Largest square", w: "side = 450/√2 = 318.2 mm;  Z = 318.2³/6 = 5.370 × 10⁶ mm³" },
            { t: "Stiffest", w: "b = 450/2 = 225 mm;  d = 0.866 × 450 = 389.7 mm;  I = 225 × 389.7³/12 = 1.11 × 10⁹ mm⁴" },
          ], ans: "Strongest 260 × 367 mm (8.9% stronger than the 318 mm square); stiffest 225 × 390 mm. Interpretation: sawmills cut structural timber close to a √2 depth/breadth ratio for this reason." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Z hi beam ki 'bending capacity per unit stress' hai. Depth do guna karo to Z chaar guna — isliye beams hamesha khade (deep side vertical) lagte hain. Aur log se beam kaatne mein 'sabse strong' aur 'sabse stiff' alag shapes dete hain kyunki strength d² par aur stiffness d³ par depend karti hai." },
          { k: "trap", t: "Strongest beam ki breadth D/√3 hai, D/√2 nahi (woh square ka side hai). Aur T-section jaisi unsymmetrical section mein 'Z' do hote hain — moment of resistance chhote Z se nikalo." },
        ],
      },

      /* ------------------------------------------------ 4.3 */
      {
        n: "4.3",
        title: "Beams of uniform strength",
        hi: "समान सामर्थ्य के शहतीर",
        blocks: [
          { k: "def", term: "Beam of Uniform Section Strength", t: "The bending stress is constant throughout the beam (f = M/Z = constant). The bending stress (f) is also known as the 'strength of the beam'. (p.10)" },
          { k: "note", t: "'Strength of the beam' in this sense refers to the bending stress f itself (how much stress the section actually carries under the given M), not the material's ultimate/yield strength — a uniform-strength beam keeps f = M/Z the same at every section by varying Z (i.e. the section's depth or width) along the length. (p.10)" },
          { k: "p", t: "Since f = M/Z must be the same everywhere, Z(x) must follow the bending-moment diagram: Z(x) = M(x)/f. For a rectangular section bd²/6 this can be done by varying the depth (b constant) or the width (d constant). For a simply supported beam with a central load P, M = Px/2 from either support, which gives (derived here):" },
          { k: "eq", expr: "Constant width b:  d(x) = √(3Px / (b f))   ;   Constant depth d:  b(x) = 3Px / (f d²)", where: [
            ["x", "distance from the nearer support (0 ≤ x ≤ L/2)"],
            ["shape", "varying depth → parabolic profile; varying width → triangular (diamond) plan — the leaf-spring shape"],
            ["limit", "at the support M = 0 gives zero size; in practice a minimum section is kept there to carry the shear"],
          ] },
          { k: "eg", title: "Worked example 4.4 — depth profile of a uniform-strength beam", given: "SS beam, span 4 m, central load 20 kN, constant width 100 mm, permissible stress 10 N/mm². Find: depth at mid-span and at quarter-span.", steps: [
            { t: "Mid-span (x = 2000 mm)", w: "d = √(3 × 20 000 × 2000 / (100 × 10)) = √120 000 = 346.4 mm" },
            { t: "Quarter-span (x = 1000 mm)", w: "d = √(3 × 20 000 × 1000 / 1000) = √60 000 = 244.9 mm" },
          ], ans: "346 mm at mid-span, 245 mm at quarter-span (depth ∝ √x). Interpretation: a prismatic 346 mm beam would be under-stressed everywhere except mid-span; tapering saves material — seen in haunched/tapered girders, crane jibs and laminated leaf springs." },
          { k: "real", t: "'Beam of uniform strength' concept site par taper ho rahe leaf springs ya taper-depth beams mein dikhta hai — jahan section ka size is tarah design kiya jaata hai ki f = M/Z har jagah constant rahe, matlab material har cross-section par apni full capacity tak use ho, na zyada na kam. (p.10)" },
          { k: "trap", t: "Uniform strength ka matlab uniform section nahi — ulta, section badalta hai taaki stress same rahe. Support ke paas depth zero nahi rakh sakte kyunki wahan shear maximum hai (§4.6)." },
        ],
      },

      /* ------------------------------------------------ 4.4 */
      {
        n: "4.4",
        title: "Beams of two materials — flitched and transformed sections",
        hi: "दो पदार्थों के शहतीर — फ्लिच्ड एवं रूपांतरित परिच्छेद",
        blocks: [
          { k: "h", t: "📘 Notes — p.10" },
          { k: "def", term: "Beam made of different materials (composite beam)", t: "The composite section's width is considered as the equivalent width of section, so that the whole section can be analysed as one material. (p.10)" },
          { k: "eq", expr: "Equivalent width of a composite section:  b + 2mt   (m = modular ratio = Eb/Et)", where: [
            ["b", "width of the middle (base) material"],
            ["t", "width of each edge strip of the other material"],
            ["Eb, Et", "modulus of elasticity of the base material and of the edge-strip material"],
          ] },
          { k: "note", t: "<b>Correction to the notes — the modular ratio is the other way round.</b> To turn the edge strips into base material, their width must be multiplied by <b>m = E_strip / E_base = Et/Eb</b> — a stiffer strip counts as a <i>wider</i> piece of base material. With the notes' own symbol definitions, Eb/Et would make a steel plate on a timber beam look narrower, which is backwards. For a flitched beam (timber core, steel side plates) m = Es/Et (<a href=\"https://www.madeeasy.in/study/ce/strength-of-material/composite-beams\" target=\"_blank\" rel=\"noopener\">MADE EASY — composite beams</a>)." },
          { k: "p", t: "Why it works: plane sections remain plane, so at any level both materials have the <b>same strain</b>; hence at the same distance from the N.A, f_steel = m · f_timber. Compute I of the transformed (all-timber) section, find f_timber = M·y/I_eq, and multiply by m for the steel. If the two materials are not symmetric about the depth (e.g. a steel plate only at the bottom), the N.A shifts and must first be found from the transformed section's centroid. RCC working-stress analysis uses exactly this idea with steel area × m." },
          { k: "eg", title: "Worked example 4.5 — flitched beam", given: "A timber beam 200 mm wide × 300 mm deep has a 10 mm × 300 mm steel plate bolted to each side. E_s = 2 × 10⁵, E_t = 1 × 10⁴ N/mm². Permissible stresses: timber 8, steel 150 N/mm². Find: moment of resistance, and how the moment is shared.", steps: [
            { t: "Modular ratio and equivalent timber section", w: "m = 2 × 10⁵ / 1 × 10⁴ = 20\nEquivalent width = 200 + 2 × 20 × 10 = 600 mm (symmetric, N.A at mid-depth)\nI_eq = 600 × 300³/12 = 1.35 × 10⁹ mm⁴" },
            { t: "Check which material governs (extreme fibre, y = 150 mm)", w: "If timber reaches 8: steel = 20 × 8 = 160 > 150 ✘ → steel governs\nSteel at 150 ⇒ timber = 150/20 = 7.5 N/mm²" },
            { t: "Moment of resistance", w: "M_r = f_t · I_eq / y = 7.5 × 1.35 × 10⁹ / 150 = 67.5 × 10⁶ N·mm = 67.5 kN·m" },
            { t: "Share of moment (∝ each part's contribution to I_eq)", w: "Timber I = 200 × 300³/12 = 0.45 × 10⁹ → 1/3 of I_eq\nTimber carries 22.5 kN·m, steel plates 45.0 kN·m" },
          ], ans: "M_r = 67.5 kN·m (steel governs); timber 22.5, steel 45 kN·m. Interpretation: two thin plates (only 9% of the area) double the timber's capacity — the reason flitch beams are used to strengthen old timber floors." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Composite beam (jaise flitched timber-steel beam) ko analyse karne ka trick hai: weaker/different material ki width ko uske modular ratio se multiply karke, use 'as if woh bhi stronger material hi hai' treat karo — isse poora section ek hi material ka maan kar M/I=f/y wali standard bending theory seedhe apply ho jaati hai. (p.10)" },
          { k: "trap", t: "Transformed section se nikla stress <b>timber ka</b> hai — steel ka actual stress m guna karke milega. Aur dono materials ki permissible stress check karo; jo pehle limit par pahunche wahi govern karta hai." },
        ],
      },

      /* ------------------------------------------------ 4.5 */
      {
        n: "4.5",
        title: "Beyond yield — plastic moment and shape factor",
        hi: "पराभव से आगे — प्लास्टिक आघूर्ण और आकृति गुणांक",
        blocks: [
          { k: "p", t: "M = f·Z assumes the extreme fibre is the first and only fibre at the limit. A ductile steel section does not fail when its outer fibre yields: as M increases, yielding spreads inward until the whole section is at ±fy — a <b>plastic hinge</b>. The moment then is the <b>plastic moment</b> M_p = fy·Z_p. The <b>plastic neutral axis</b> divides the section into two <i>equal areas</i> (not through the centroid unless the section is symmetric) (<a href=\"https://people.duke.edu/~hpgavin/cee201/plastic.pdf\" target=\"_blank\" rel=\"noopener\">Duke CEE 201 notes</a>)." },
          { k: "eq", expr: "M_y = fy · Z_e   ;   M_p = fy · Z_p   ;   Shape factor  S = M_p / M_y = Z_p / Z_e", where: [
            ["Z_e", "elastic section modulus I/y_max"],
            ["Z_p", "plastic section modulus = sum of (area × distance to the equal-area axis) for both halves; rectangle bd²/4"],
          ] },
          { k: "cmp", t: "Shape factors (Duke CEE 201)", cols: ["Shape factor", "Why"], rows: [
            ["Rectangle", "1.5", "bd²/4 ÷ bd²/6"],
            ["Solid circle", "≈ 1.7", "lots of area near the N.A that is lightly stressed elastically"],
            ["I-section", "≈ 1.12", "flanges are already near yield when the extreme fibre yields — little reserve left"],
          ] },
          { k: "p", t: "<b>Link to IS 800:2007.</b> Laterally supported steel beams are designed on the plastic modulus: <b>M_d = β_b · Z_p · f_y / γ_m0</b>, with β_b = 1.0 for plastic and compact sections and Z_e/Z_p for semi-compact ones, and capped at 1.2 Z_e f_y/γ_m0 (cl. 8.2.1.2) (<a href=\"https://sjce.ac.in/wp-content/uploads/2018/01/CV610-Design-of-flexural-Member-2.pdf\" target=\"_blank\" rel=\"noopener\">SJCE Mysuru course notes</a>; β_b values also in <a href=\"https://docs.bentley.com/LiveContent/web/STAAD.Pro%20Help-v2024/en/topics/Design_Codes/Indian_Codes/c-stpst_IS800-2007_Bending.html\" target=\"_blank\" rel=\"noopener\">Bentley STAAD.Pro IS 800 docs</a>). See <a href=\"#/code/is800\">IS 800</a>." },
          { k: "eg", title: "Worked example 4.6 — elastic, plastic and IS 800 design moment of an I-section", given: "Symmetric I-section: flanges 150 × 15 mm, overall depth 300 mm, web 8 mm thick (clear web depth 270 mm). fy = 250 N/mm², γ_m0 = 1.10. Find: Z_e, Z_p, shape factor, M_y, M_p and the IS 800 design moment (plastic/compact section, laterally supported).", steps: [
            { t: "I and Z_e", w: "I = [150 × 300³ − (150 − 8) × 270³]/12 = 1.0458 × 10⁸ mm⁴\nZ_e = I/150 = 6.972 × 10⁵ mm³" },
            { t: "Z_p — both halves about the mid-depth (equal-area axis)", w: "Z_p = B·t_f·(D − t_f) + t_w·d²/4 = 150 × 15 × 285 + 8 × 270²/4\n    = 641 250 + 145 800 = 7.871 × 10⁵ mm³" },
            { t: "Shape factor", w: "S = 7.871/6.972 = 1.13 (cf. ≈ 1.12 for I-sections ✔)" },
            { t: "Yield and plastic moments", w: "M_y = 250 × 6.972 × 10⁵ = 174.3 kN·m\nM_p = 250 × 7.871 × 10⁵ = 196.8 kN·m" },
            { t: "IS 800 design moment", w: "Z_p·fy/γ_m0 = 7.871 × 10⁵ × 250/1.10 = 178.9 kN·m\nCap 1.2·Z_e·fy/γ_m0 = 1.2 × 6.972 × 10⁵ × 250/1.10 = 190.2 kN·m\nM_d = 178.9 kN·m" },
          ], ans: "Z_e = 6.97 × 10⁵, Z_p = 7.87 × 10⁵ mm³, S = 1.13; M_y = 174.3, M_p = 196.8, M_d = 178.9 kN·m. Interpretation: the plastic reserve of an I-section is only ~13%, while a solid rectangle has 50% — but the I-section uses its steel far better in the first place." },
          { k: "trap", t: "Plastic neutral axis = <b>equal-area</b> axis; elastic N.A = <b>centroidal</b> axis. Symmetric section mein dono same hain, T-section mein alag. Aur shape factor material property nahi, sirf shape ki property hai." },
        ],
      },

      /* ------------------------------------------------ 4.6 */
      {
        n: "4.6",
        title: "Shear stress distribution in beams",
        hi: "शहतीर में कर्तन प्रतिबल वितरण",
        blocks: [
          { k: "h", t: "📘 Notes — p.11" },
          { k: "eq", expr: "Shear stress at any section  q = F(aȳ)/(Ib)   ;   Average shear stress  q_avg = F/A", where: [
            ["F", "S.F at that section"],
            ["b", "width at that section"],
            ["A", "total area of the c/s"],
            ["aȳ", "moment of area of the section under consideration, about the N.A"],
          ] },
          { k: "h", t: "📘 Where the formula comes from" },
          { k: "p", t: "Take a short length dx of beam and cut off the part above some level y₁. Because M changes along dx (dM/dx = F), the bending stresses on its two ends differ, and their resultants differ by (dM/I)·aȳ. Nothing else acts horizontally on that piece except a shear stress q on its cut face of area b·dx. Horizontal equilibrium gives q·b·dx = (dM/I)·aȳ ⇒ <b>q = F·aȳ/(I·b)</b>. By <b>complementary shear</b>, the same q acts vertically on the cross-section at that level. (Approach as in the <a href=\"https://archive.nptel.ac.in/content/storage2/courses/112106141/Pdfs/6_2.pdf\" target=\"_blank\" rel=\"noopener\">NPTEL — IIT Madras Strength of Materials notes</a>, which write it τ = VQ/It.)" },
          { k: "eq", expr: "Rectangular section:  q_max = (3/2) q_avg   ;   Circular section:  q_max = (4/3) q_avg   ;   Triangular section:  q_max = (3/2) q_avg (at h/2 from top/bottom), q_NA = (4/3) q_avg   ;   Diamond/square (one diagonal horizontal):  q_max = (9/8) q_avg", where: [] },
          { k: "p", t: "For a rectangle the formula gives q = (F/2I)(d²/4 − y²) — a parabola, zero at the top and bottom and 1.5 × average at the N.A (IIT Madras notes, above)." },
          { k: "def", term: "I-section", t: "q_max = (F/8I) [ (B/t_w)(D² − d²) + d² ], where B is the flange width, t_w the web thickness, D the overall depth and d the depth between flange inner faces. (p.11)" },
          { k: "note", t: "The general formula q = F(aȳ)/(Ib) is what every one of these special-case results (rectangle, circle, triangle, diamond, I-section) is derived from — only 'a', 'ȳ' and 'b' change with the shape and the position of the section being checked. (p.11)" },
          { k: "p", t: "The notes also give shear-stress-distribution shapes (parabolic in the web, small in the flanges) for rectangle, circle, hollow circle, I-section, T-section and L-section. (p.11)" },
          { k: "dia", id: "hb-som-sheardist" },
          { k: "note", t: "For a <b>hollow circular</b> section, the shear-stress distribution diagram shows a <b>dip near the centre</b>, unlike the smooth single-peak parabola of a solid circle. (p.11)" },
          { k: "note", t: "The transcript's figures also show shear-stress distributions for a Plus/Cross section and bold I-shape and H-shape sections, but no separate q_max multiplier is written for these beyond the general q = F(aȳ)/(Ib) formula — use that formula directly for such sections. (p.11)" },
          { k: "list", items: [
            "For <b>pure bending</b> (F = 0), the shear stress is also zero. (p.11)",
            "If the width (b) suddenly decreases, the shear stress (q) suddenly increases by (B/b) times, and vice versa — e.g. for an I-section, the shear stress at the web-flange junction suddenly increases from (F/8I)(D² − d²) to (B/t_w)[(F/8I)(D² − d²)]. (p.11)",
            "For a higher width, the shear stress will be low (I ∝ 1/db), and vice versa. (p.11)",
            "At the extreme edge, shear stress must be zero (q ∝ a, and a = b × 0 = 0 at the extreme fibre). (p.11)",
          ] },
          { k: "note", t: "Reading the third bullet: what the notes mean is <b>q ∝ 1/b</b> at a given level (b is in the denominator of q = F·aȳ/Ib); 'I ∝ 1/db' is a transcription slip." },
          { k: "eg", title: "Worked example 4.7 — shear stress in a rectangular RCC-size section", given: "A 230 × 450 mm rectangular section carries a shear force of 90 kN (treat as homogeneous). Find: average, maximum, and the shear stress 75 mm below the top.", steps: [
            { t: "Average and maximum", w: "q_avg = 90 000 / (230 × 450) = 0.870 N/mm²\nq_max = 1.5 × 0.870 = 1.304 N/mm² (at the N.A)" },
            { t: "At 75 mm below the top (y = 150 mm from N.A) — using aȳ", w: "a = 230 × 75 = 17 250 mm²;  ȳ = 225 − 37.5 = 187.5 mm;  aȳ = 3.234 × 10⁶ mm³\nI = 230 × 450³/12 = 1.7466 × 10⁹ mm⁴\nq = 90 000 × 3.234 × 10⁶ / (1.7466 × 10⁹ × 230) = 0.725 N/mm²" },
            { t: "Check with the parabola formula", w: "q = (F/2I)(d²/4 − y²) = 90 000 × (50 625 − 22 500)/(2 × 1.7466 × 10⁹) = 0.725 ✔" },
          ], ans: "q_avg = 0.87, q_max = 1.30, q at 75 mm from top = 0.725 N/mm². Interpretation: in RCC design IS 456 works with the nominal shear stress τ_v = V/(b·d), an average over the effective section — the 1.5 peak is absorbed into the code's permissible values." },
          { k: "eg", title: "Worked example 4.8 — shear stress in an I-section and how much the web carries", given: "The I-section of Worked example 4.6 (B = 150, t_f = 15, D = 300, t_w = 8, d = 270 mm, I = 1.0458 × 10⁸ mm⁴) carries V = 150 kN. Find: stress in the flange at the junction, in the web at the junction, at the N.A, and the share of V taken by the web.", steps: [
            { t: "Flange at the junction", w: "q = (V/8I)(D² − d²) = 150 000 × (90 000 − 72 900)/(8 × 1.0458 × 10⁸) = 3.07 N/mm²" },
            { t: "Web at the junction (jump by B/t_w = 18.75)", w: "q = 3.07 × 18.75 = 57.5 N/mm²" },
            { t: "Maximum, at the N.A (notes' formula)", w: "q = (V/8I)[(B/t_w)(D² − d²) + d²] = 1.793 × 10⁻⁴ × (320 625 + 72 900) = 70.6 N/mm²" },
            { t: "Force carried by the web (integrate q·t_w over the web depth)", w: "V_web = (V/I)[B(D² − d²)d/8 + t_w d³/12] = 142 980 N ≈ 95% of V\nSimple 'web area' estimate: V/(D·t_w) = 150 000/2400 = 62.5 N/mm²" },
          ], ans: "Flange 3.1, web junction 57.5, N.A 70.6 N/mm²; the web carries ≈ 95% of the shear. Interpretation: this is why IS 800 checks shear on the web area (D × t_w), and why the web's average (62.5) is close to the true peak (70.6)." },
          { k: "h", t: "📘 Shear flow — designing the connections of built-up beams" },
          { k: "p", t: "Shear flow q_f = F·aȳ/I is the horizontal shear force per unit length along a joint (N/mm) — q × b. When a beam is built up from pieces (plates welded or bolted to an I-section, timber planks nailed together), the bolts, nails or welds along each joint must carry this shear flow: spacing s = (capacity of one fastener) / q_f (IIT Madras notes, above)." },
          { k: "note", t: "<b>Where the simple theory stops (general engineering knowledge, beyond this handbook):</b> (1) <i>Unsymmetrical bending</i> — if the load does not act along a principal axis (e.g. an angle section, or a purlin on a sloping roof), bending occurs about both axes and the N.A tilts. (2) <i>Shear centre</i> — for open sections that are not doubly symmetric (channels, angles), a load through the centroid also twists the beam; it must pass through the shear centre (outside the web, for a channel) to bend without twisting — so an unbraced channel loaded through its web tends to twist as well as bend. (3) <i>Curved beams</i> (crane hooks, rings) — stress is no longer linear in y." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "I-section ka shear-stress jump samajhna zaroori hai: web patla (t_w) hota hai to us jagah shear stress high hota hai (kyunki A ∝ 1/width — width kam, stress zyada), jaise hi flange shuru hota hai (jo bahut chauda B hota hai), same force ab zyada area par spread hota hai to stress achanak <b>gir</b> jaata hai. Isi wajah se I-section mein practically saara shear web hi le leta hai, flanges bahut kam." },
          { k: "real", t: "Bending moment flanges sambhalte hain, shear force web — I-section ka poora design isi division par hai. RCC beam mein shear crack support ke paas N.A ke aas-paas diagonally shuru hota hai (wahan shear stress max aur principal tension inclined, <a href=\"#/read/som/2\">Chapter 2.6</a>) — isliye stirrups support ke paas closely spaced rakhe jaate hain." },
          { k: "trap", t: "Triangular section mein q_max N.A par <b>nahi</b> hota — yeh section ke h/2 (mid-height, base se) par hota hai (q_max = (3/2)q_avg), jabki khud N.A par shear stress isse kam hai (q_NA = (4/3)q_avg). Yeh rectangular/circular section ki tarah 'max hamesha N.A par' wali soch se ulta hai. (p.11) Aur aȳ hamesha us level ke <b>ek taraf</b> ke area ka hota hai (upar ya neeche — dono same answer dete hain), poore section ka nahi." },
        ],
      },

      /* ------------------------------------------------ 4.7 */
      {
        n: "4.7",
        title: "Quick revision — theory of bending and shear stress",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Neutral layer (f=0) vs neutral axis (passes through C.G, stress/strain sign changes) (p.10).",
            "Bending equation M/I = f/y = E/R; y always from N.A (p.10); assumptions and three-step derivation (§4.1).",
            "Z = I/y, Flexural rigidity = EI, Curvature 1/R = M/EI (p.10); moment of resistance M_r = f·Z (§4.2).",
            "Strongest beam from a log b = D/√3, d = √(2/3)D; stiffest b = D/2, d = (√3/2)D (§4.2, corrected).",
            "Uniform strength: d(x) = √(3Px/bf) or b(x) = 3Px/(fd²) (§4.3).",
            "Composite beam: equivalent width = b + 2mt, m = E_strip/E_base (p.10, corrected); f_steel = m·f_timber at the same level (§4.4).",
            "Plastic moment M_p = fy·Z_p; shape factor 1.5 / 1.7 / ≈1.12; IS 800 M_d = β_b Z_p fy/γ_m0 (§4.5).",
            "q = F(aȳ)/(Ib); q_avg = F/A; q_max multipliers for rectangle (3/2), circle (4/3), triangle (3/2 at h/2), diamond (9/8) (p.11).",
            "I-section q_max formula and the sudden jump at the web-flange junction (p.11); web carries ~95% of V; shear flow F·aȳ/I (§4.6).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "f = M/Z is the working form of the bending equation for design (p.10).",
            "For pure bending, F = 0 ⇒ shear stress = 0 everywhere on the section (p.11).",
            "Shear stress is inversely related to width at a section (q ∝ 1/b) and is always zero at the extreme edge (p.11).",
            "Triangular section's q_max is at mid-height, not at the N.A — do not assume max shear is always at N.A (p.11).",
            "Bending is resisted mainly by the parts far from the N.A (flanges); shear mainly by the web.",
          ] },
          { k: "h", t: "🔗 Related in Civil Educator" },
          { k: "list", items: [
            "<a href=\"#/read/som/3\">Ch. 3 — Centroid, I, Z, SFD/BMD</a> (prerequisite)",
            "<a href=\"#/read/som/5\">Ch. 5 — Deflection: from 1/R = M/EI</a>",
            "<a href=\"#/read/som/2\">Ch. 2 — Principal stresses (bending + shear combined)</a>",
            "<a href=\"#/read/som/6\">Ch. 6 — Combined bending and torsion</a>",
            "Codes: <a href=\"#/code/is800\">IS 800</a> (plastic modulus design), <a href=\"#/code/is456\">IS 456</a> (deep beams, nominal shear stress)",
          ] },
        ],
      },
    ],
  },

);
