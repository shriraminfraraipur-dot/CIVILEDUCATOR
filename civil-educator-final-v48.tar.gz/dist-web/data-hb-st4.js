/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   Chapter 7 — Beams: Laterally Supported
   Chapter 8 — Lateral-Torsional Buckling

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "st"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "st-7",
      n: 7,
      title: "Beams: Laterally Supported",
      hi: "बीम — पार्श्व सहारे सहित",
      blurb: "Moment, shear, the interaction between them, and the two local failures that happen where the load comes in.",
      mins: 44,
      sections: [

        {
          n: "7.1",
          title: "What 'laterally supported' means",
          hi: "'पार्श्व सहारा' का अर्थ",
          blocks: [
            { k: "p", t: "This chapter assumes something holds the compression flange in line — a concrete slab cast onto it, a steel deck fixed to it, or close-spaced secondary beams. With that assumption the beam cannot buckle sideways, and its capacity is decided by the section alone." },
            { k: "p", t: "That is a large assumption, and Chapter 8 removes it. But it is also the common case in building floors, and it is the right place to start, because everything here still applies when lateral buckling is added — Chapter 8 changes only the stress the section is allowed to reach." },
            { k: "list", items: [
              "<strong>Bending</strong> — Cl. 8.2.1.2, and the class from Chapter 2 decides which section modulus is available.",
              "<strong>Shear</strong> — Cl. 8.4, carried almost entirely by the web.",
              "<strong>Their interaction</strong> — Cl. 9.2.2, which matters only above 0.6 Vd.",
              "<strong>Web buckling and web crippling</strong> — Cl. 8.7, local failures at supports and under point loads.",
              "<strong>Deflection</strong> — Cl. 5.6.1 and Table 6, at service load, and frequently what governs.",
            ]},
          ],
        },

        {
          n: "7.2",
          title: "Moment capacity",
          hi: "बंकन क्षमता",
          blocks: [
            { k: "dia", id: "hb-st-isection", cap: "Flanges carry the moment; the web holds them apart and carries the shear." },
            { k: "eq", expr: "Md = βb Zp fy / γm0        (Cl. 8.2.1.2)", where: [
              ["βb", "1.0 for a plastic or compact section; Ze/Zp for a semi-compact one"],
            ]},
            { k: "eq", expr: "but Md ≤ 1.2 Ze fy / γm0  for a simply supported beam  (1.5 Ze fy/γm0 for a cantilever)", where: [] },
            { k: "p", t: "The second limit deserves an explanation, because it looks like an arbitrary cap on a formula that was just derived. It is not about strength — it is about <strong>deformation at service load</strong>. A section with a very large shape factor would, if designed to its full plastic moment, already be yielding significantly under everyday load. The 1.2 (and 1.5 for a cantilever, which is statically determinate and has no redistribution to lose) keeps the working-load behaviour elastic." },
            { k: "note", t: "For a rolled I-section the shape factor is only about 1.15, so 1.2 Ze rarely bites — Zp fy comes out just under the cap. It matters for sections with large shape factors, and it is the kind of check that is cheap to do and embarrassing to omit." },
            { k: "trap", t: "βb is not a safety factor and it is not a reduction for buckling. It is a switch: Chapter 2's classification decides whether the section can actually develop its plastic moment, and βb encodes that answer. A class 3 section gets Ze fy/γm0, which for a rolled beam is about 13% less than the plastic value." },
          ],
        },

        {
          n: "7.3",
          title: "Shear capacity",
          hi: "अपरूपण क्षमता",
          blocks: [
            { k: "dia", id: "hb-st-webshear", cap: "The true shear distribution, the design idealisation, and the two regimes." },
            { k: "p", t: "The elastic shear stress in an I-section is nearly all in the web — the flanges carry only a few per cent, because their shear flow has nowhere to go. Design ignores the distribution entirely and works with an average over a defined shear area (Cl. 8.4.1):" },
            { k: "eq", expr: "Vd = Av fyw / (√3 γm0)", where: [
              ["Av", "shear area: D × tw for a rolled I-section loaded parallel to the web; d × tw for a welded section"],
              ["fyw", "yield stress of the web material"],
            ]},
            { k: "p", t: "The √3 is von Mises again: the shear yield stress of a ductile metal is its tensile yield divided by √3. That single relation appears in bolt shear (Chapter 3), weld throats (Chapter 4), block shear (Chapter 5) and here — it is the most reused constant in the code." },
            { k: "trap", t: "For a <strong>rolled</strong> section Av uses the full depth D, and for a <strong>welded</strong> one the clear web depth d. The difference is the flange thickness at each end, typically 8% of the shear area. The reason is that a rolled section's web-to-flange transition is a continuous fillet that carries shear, while a welded one's is a weld that is not counted." },
            { k: "note", t: "Cl. 8.4.2 adds a condition: if d/tw exceeds 67ε, the web can buckle in shear before it yields, and the capacity must be computed by the shear buckling rules instead. Rolled sections are comfortably below that limit — an ISMB 400 is at 38 — which is exactly why plate girders (Chapter 10), where d/tw runs to 200 and beyond, need a completely different treatment." },
          ],
        },

        {
          n: "7.4",
          title: "When shear and moment interact",
          hi: "जब अपरूपण और मोमेंट टकराते हैं",
          blocks: [
            { k: "p", t: "Moment and shear are usually largest at different places — moment at mid-span, shear at the supports — so for most beams they never have to be considered together. But a continuous beam at an interior support, or a beam with a heavy point load near one end, gets both at once." },
            { k: "p", t: "IS 800 draws a line at <strong>0.6 Vd</strong>. Below it, Cl. 8.2.1.2 permits the full moment capacity with no reduction at all. Above it, Cl. 9.2.2 reduces the moment capacity:" },
            { k: "eq", expr: "Mdv = Md − β (Md − Mfd),    β = (2V/Vd − 1)²", where: [
              ["Mfd", "plastic moment capacity of the FLANGES ALONE, after deducting the web's share"],
              ["V", "the factored shear at the section being checked"],
            ]},
            { k: "p", t: "The physical picture is simple once Mfd is understood. The web is doing the shearing; the flanges are doing the bending. As the shear approaches Vd the web is fully committed to shear and has nothing left for moment, and the beam is reduced to its flanges. Mfd is that floor, and β slides the capacity from Md down towards it." },
            { k: "list", items: [
              "At V = 0.6 Vd, β = (1.2 − 1)² = 0.04 — a 4% reduction, which is why the cut-off is drawn there: below it the effect is negligible.",
              "At V = Vd, β = 1 and Mdv = Mfd — the web contributes nothing to moment.",
              "The square makes the transition gentle at first and steep at the end, which matches test behaviour.",
            ]},
            { k: "note", t: "Mdv is still subject to the 1.2 Ze fy/γm0 cap from §7.2, so a high-shear check cannot produce a moment capacity larger than a low-shear one would have allowed." },
          ],
        },

        {
          n: "7.5",
          title: "Web buckling and web crippling",
          hi: "वेब बकलिंग और क्रिपलिंग",
          blocks: [
            { k: "p", t: "Everything so far has treated the beam as a whole. Two failures are purely local, and both happen where a concentrated force meets the web — at a support, or under a column or a heavy point load." },
            { k: "dia", id: "hb-st-webcrush", cap: "Two failures at the same place, with two different dispersion assumptions." },
            { k: "def", term: "Web buckling (Cl. 8.7.3.1)", t: "The web between the flanges behaves as a short column carrying the concentrated force, and bows sideways. The load is assumed to disperse at 45° down to the mid-depth of the web, giving an effective bearing length of (b1 + n1), and the capacity is that length times tw times a design compressive stress fcd, found from the column curve at a slenderness of 2.5 d/tw." },
            { k: "def", term: "Web crippling (Cl. 8.7.4)", t: "The web crushes locally just under the root of the flange. Here the dispersion is taken as 1 : 2.5 through the flange and root fillet only — a much shorter length — and the capacity is (b1 + n2) tw fyw/γm0. It is a yielding check, not a buckling one." },
            { k: "p", t: "Both are checked, and both are cured the same way: a <strong>bearing stiffener</strong> — a plate welded each side of the web, transferring the load directly between the flanges and taking the web out of the problem. Nearly every beam carrying a column above it, and nearly every plate girder support, has one." },
            { k: "trap", t: "The bearing length b1 is the <em>actual</em> length over which the load is delivered — the width of the seat, the bearing plate, or the supporting member. Assuming a generous value makes both checks pass on paper and neither pass in the building. If the beam sits on 75 mm of wall, b1 is 75 mm." },
          ],
        },

        {
          n: "7.6",
          title: "Deflection",
          hi: "विक्षेपण",
          blocks: [
            { k: "p", t: "Steel is strong but not especially stiff, so steel beams are often sized by deflection rather than by moment — the same situation Chapter 7 of the RCC handbook found with slabs, and for the same reason: the strength check leaves a section that is too flexible to live with." },
            { k: "p", t: "Cl. 5.6.1 requires deflection to be checked at <strong>service load</strong> — all partial safety factors 1.0 — and Table 6 gives the limits by member type and, crucially, by what the member is supporting. Brittle cladding gets a tighter limit than elastic cladding, because the limit is set by what the movement will damage." },
            { k: "eq", expr: "δ = 5 w L⁴ / (384 E I)      for a uniformly loaded simply supported beam", where: [] },
            { k: "p", t: "Two consequences of the L⁴ are worth holding on to. First, a beam that is comfortable at 5 m is rarely comfortable at 8 m — deflection grows six and a half times while the moment grows only 2.6 times. Second, deflection is a stiffness problem, so it depends on <strong>I</strong> and not on fy: switching to a higher grade of steel does nothing for it, exactly as it did nothing for column buckling in Chapter 6." },
            { k: "note", t: "The remedy for a beam that fails deflection is depth, and depth is cheap: I goes roughly as D², so a section one size deeper usually fixes it with no more steel by weight. Pre-cambering is the other answer where depth is fixed — building the beam with an upward bow equal to the dead-load deflection, so that it is flat once loaded." },
          ],
        },

        {
          n: "7.7",
          title: "A beam designed",
          hi: "एक बीम का डिज़ाइन",
          blocks: [
            { k: "eg",
              title: "Example 7.1 — Laterally supported beam",
              given: "ISMB 400, simply supported over 5.0 m, compression flange fully restrained by a slab cast on it. E250 steel. From the section tables: A = 7846 mm², Zp = 1176.18 × 10³ mm³, Ze = 1022.9 × 10³ mm³, Ixx = 20,458 × 10⁴ mm⁴, D = 400 mm, tw = 8.9 mm, tf = 16 mm. Section is plastic (Example 2.1).",
              steps: [
                { t: "Moment capacity (Cl. 8.2.1.2)", w: "Plastic section → βb = 1.0\nMd = 1.0 × 1176.18 × 10³ × 250/1.10 = 267.3 × 10⁶ N·mm = 267.3 kNm" },
                { t: "Check the deformation cap", w: "1.2 Ze fy/γm0 = 1.2 × 1022.9 × 10³ × 250/1.10 = 279.0 kNm\n267.3  <  279.0  ✓ the plastic value stands" },
                { t: "Shear capacity (Cl. 8.4.1)", w: "Av = D tw = 400 × 8.9 = 3560 mm²\nVd = 3560 × 250/(1.732 × 1.10) = 467.1 kN\n0.6 Vd = 280.3 kN" },
                { t: "Check web shear buckling (Cl. 8.4.2)", w: "d/tw = 340/8.9 = 38.2  <  67ε = 67  ✓ no shear buckling check needed" },
                { t: "What load does that allow?", w: "Mu = wu L²/8  →  wu = 8 × 267.3/5² = 85.5 kN/m (factored)\nV = wu L/2 = 85.5 × 2.5 = 213.8 kN\n213.8  <  280.3  →  LOW SHEAR, so the full Md applies  ✓" },
                { t: "Deflection at service load", w: "Service load w = 85.5/1.5 = 57.0 kN/m = 57.0 N/mm\nδ = 5 × 57.0 × 5000⁴/(384 × 2 × 10⁵ × 20,458 × 10⁴)\n  = 11.34 mm\nLimit span/300 = 16.67 mm  ✓   even span/360 = 13.9 mm  ✓" },
              ],
              ans: "ISMB 400 carries 85.5 kN/m factored over 5 m: Md = 267.3 kNm, shear is low, and the service deflection of 11.3 mm is within span/360.",
            },
            { k: "eg",
              title: "Example 7.2 — The same beam in high shear",
              given: "The same ISMB 400, now at a section carrying a factored shear of 400 kN together with a factored moment of 200 kNm — a heavy point load close to a support.",
              steps: [
                { t: "Is the shear high?", w: "V = 400 kN;  0.6 Vd = 280.3 kN\n400  >  280.3  →  HIGH SHEAR, Cl. 9.2.2 applies" },
                { t: "The reduction factor", w: "β = (2V/Vd − 1)² = (2 × 400/467.1 − 1)²\n  = (1.7127 − 1)² = 0.7127² = 0.508" },
                { t: "Moment capacity of the flanges alone", w: "Zpf = bf tf (D − tf) = 140 × 16 × (400 − 16) = 860,160 mm³\nMfd = 860,160 × 250/1.10 = 195.5 kNm" },
                { t: "Reduced moment capacity", w: "Mdv = Md − β(Md − Mfd)\n    = 267.3 − 0.508 × (267.3 − 195.5)\n    = 267.3 − 36.5 = 230.8 kNm\nCheck against the cap 1.2 Ze fy/γm0 = 279.0 kNm  ✓" },
                { t: "Verdict", w: "Applied 200 kNm  <  230.8 kNm  ✓ the section is adequate" },
              ],
              ans: "High shear costs 36.5 kNm — about 14% of the moment capacity. The section still works, but a designer who ignored the interaction would have been quoting 267 kNm for a section that can only deliver 231.",
            },
          ],
        },

        {
          n: "7.8",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Md = βb Zp fy/γm0, capped at 1.2 Ze fy/γm0 (1.5 for a cantilever).",
              "Vd = Av fyw/(√3 γm0); Av = D tw rolled, d tw welded.",
              "Below 0.6 Vd, no interaction. Above it, Mdv = Md − β(Md − Mfd) with β = (2V/Vd − 1)².",
              "Check d/tw against 67ε before trusting the simple shear formula.",
              "Web buckling and web crippling at every support and concentrated load — cured by a bearing stiffener.",
              "Deflection at service load, limits from Table 6, and depth is the cure.",
              "Neither deflection nor buckling improves with a higher grade of steel.",
            ]},
            { k: "p", t: "All of that assumed the compression flange was held. Chapter 8 lets go of it, and finds that the beam has been a column all along." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "st-8",
      n: 8,
      title: "Lateral-Torsional Buckling",
      hi: "पार्श्व-मरोड़ बकलिंग",
      blurb: "What happens when nothing holds the compression flange, and why one restraint at mid-span can nearly double a beam.",
      mins: 40,
      sections: [

        {
          n: "8.1",
          title: "A beam is a column in disguise",
          hi: "बीम भी एक कॉलम है",
          blocks: [
            { k: "p", t: "Look at the top half of a simply supported beam under load. It is a long, slender piece of steel in compression. Chapter 6 was about exactly that, and it concluded that such a thing buckles sideways. There is no reason for a compression flange to behave differently — and it does not." },
            { k: "dia", id: "hb-st-ltb", cap: "The compression flange kicks out, the tension flange stays put, and the section has to twist." },
            { k: "p", t: "There is one complication, and it is the whole of the subject's name. The compression flange cannot simply translate sideways, because the tension flange below it is being pulled straight and holds its end of the section in place. So the section deflects laterally <em>and rotates</em> at the same time. The mode is lateral-torsional buckling, and it depends on the section's resistance to both." },
            { k: "list", items: [
              "<strong>Minor-axis bending stiffness, EIy</strong> — resisting the sideways movement.",
              "<strong>Torsional stiffness, GIt</strong> — resisting the twist. This is St Venant torsion, and it is very small for an open I-section.",
              "<strong>Warping stiffness, EIw</strong> — resisting the flanges bending in opposite directions, which is how an I-section actually resists twist over a length.",
            ]},
            { k: "note", t: "That list explains why a closed section is immune. A rectangular or circular hollow section has an enormous torsional constant — the shear flow runs right round a closed loop — and its Iy is comparable to Ix. LTB simply does not govern for tubes, which is one reason they are chosen for long unrestrained spans." },
          ],
        },

        {
          n: "8.2",
          title: "What counts as restraint",
          hi: "सहारा किसे मानें",
          blocks: [
            { k: "dia", id: "hb-st-restraint", cap: "Continuous, discrete, or none — and LLT is what changes." },
            { k: "p", t: "The quantity that governs is <strong>LLT</strong>, the distance between points at which the compression flange is held against lateral movement. It is not the span, except in the case where nothing holds the flange anywhere along it." },
            { k: "list", items: [
              "<strong>Continuous restraint</strong> — a concrete slab cast on the flange, or a steel deck positively fixed to it. LLT effectively vanishes and the Chapter 7 treatment applies.",
              "<strong>Discrete restraint</strong> — secondary beams, purlins or bracing framing into the compression flange. LLT is the spacing between them.",
              "<strong>No restraint</strong> — a crane girder, an exposed beam, a beam during erection before the deck goes on. LLT is the full span.",
            ]},
            { k: "trap", t: "Restraint counts only if it restrains the <strong>compression</strong> flange, and only if it actually resists lateral force. A slab merely <em>resting</em> on the top flange is not restraint — friction is not a load path. A secondary beam framing into the web at mid-depth restrains the web, not the flange. And in a hogging region the compression flange is the <em>bottom</em> one, which the slab is not touching." },
            { k: "p", t: "That last point is worth dwelling on. At the interior support of a continuous beam the moment is hogging, so the bottom flange is in compression — and that is precisely the flange nothing is holding. A continuous beam that looks fully restrained by its slab may be unrestrained exactly where the moment is largest. Cl. 8.3 and Table 15 give effective lengths for LTB that account for the end conditions, including this case." },
          ],
        },

        {
          n: "8.3",
          title: "The bending strength curve",
          hi: "बंकन सामर्थ्य वक्र",
          blocks: [
            { k: "p", t: "Cl. 8.2.2 handles LTB with exactly the machinery of Chapter 6, applied to bending instead of compression. If the column curve is understood, this is the same thing with different letters." },
            { k: "eq", expr: "Md = βb Zp fbd,        fbd = χLT fy / γm0", where: [
              ["fbd", "design bending compressive stress — the reduced stress the section may reach"],
            ]},
            { k: "eq", expr: "λLT = √(βb Zp fy / Mcr)        φLT = 0.5 [1 + αLT(λLT − 0.2) + λLT²]", where: [
              ["Mcr", "elastic critical moment for lateral-torsional buckling"],
              ["αLT", "0.21 for rolled sections, 0.49 for welded ones"],
            ]},
            { k: "eq", expr: "χLT = 1 / [ φLT + (φLT² − λLT²)^0.5 ]   ≤ 1.0", where: [] },
            { k: "dia", id: "hb-st-ltbcurve", cap: "Full capacity at short unrestrained lengths, a steep fall through the practical range, a long tail beyond." },
            { k: "p", t: "Two details differ from the column case. First, the plateau extends to <strong>λLT = 0.4</strong> rather than 0.2 — a beam tolerates more slenderness before LTB costs it anything, because the tension flange is stabilising the section. Second, αLT is 0.21 for rolled sections against 0.34 or 0.49 for a column of the same shape; beams are less sensitive to imperfection than columns because the compression zone varies along the length." },
            { k: "h", t: "Mcr, and the shortcut" },
            { k: "p", t: "For a doubly symmetric section, simply supported and uniformly bent, Annex E gives Mcr from the three stiffnesses of §8.1 — a formula containing EIy, GIt and EIw. It is exact and it is tedious, and IS 800 provides an approximation for rolled I-sections instead (Cl. 8.2.2.1), giving fcr,b directly from two ratios that can be read off the section tables:" },
            { k: "eq", expr: "fcr,b = (1.1 π² E / (LLT/ry)²) × √[ 1 + (1/20)((LLT/ry)/(hf/tf))² ]       λLT = √(fy / fcr,b)", where: [
              ["LLT", "effective length for lateral-torsional buckling, from Cl. 8.3 / Table 15"],
              ["ry", "radius of gyration about the minor axis"],
              ["hf", "distance between the centroids of the two flanges = D − tf"],
            ]},
            { k: "p", t: "The first bracket is a Euler-like term in LLT/ry — the sideways-column part. The second is the warping correction: a deep beam with thin flanges (large hf/tf) warps easily and gets less help from it, while a stocky one with thick flanges gets more." },
          ],
        },

        {
          n: "8.4",
          title: "How much it costs, and how much a restraint is worth",
          hi: "कितना नुकसान, कितना फ़ायदा",
          blocks: [
            { k: "eg",
              title: "Example 8.1 — The Chapter 7 beam, with nothing holding it",
              given: "The same ISMB 400 over 5.0 m, but now with no lateral restraint anywhere along the span: LLT = 5000 mm. From the section tables ry = 28.2 mm, tf = 16 mm, D = 400 mm, Zp = 1176.18 × 10³ mm³. E250 steel, rolled section so αLT = 0.21.",
              steps: [
                { t: "The two ratios", w: "LLT/ry = 5000/28.2 = 177.3\nhf = D − tf = 400 − 16 = 384 mm;  hf/tf = 384/16 = 24" },
                { t: "Elastic critical bending stress (Cl. 8.2.2.1)", w: "first term  = 1.1 π² × 2×10⁵/177.3² = 2,171,313/31,435 = 69.07\nsecond term = √[1 + (1/20)(177.3/24)²] = √[1 + 0.05 × 54.58] = √3.729 = 1.931\nfcr,b = 69.07 × 1.931 = 133.4 N/mm²" },
                { t: "Non-dimensional slenderness", w: "λLT = √(fy/fcr,b) = √(250/133.4) = √1.874 = 1.369" },
                { t: "φLT and χLT", w: "φLT = 0.5[1 + 0.21(1.369 − 0.2) + 1.369²]\n    = 0.5[1 + 0.2455 + 1.8744] = 1.560\nχLT = 1/[1.560 + √(2.434 − 1.874)] = 1/[1.560 + 0.748] = 0.433" },
                { t: "Design bending stress and capacity", w: "fbd = 0.433 × 250/1.10 = 98.5 N/mm²\nMd = 1176.18 × 10³ × 98.5 = 115.8 × 10⁶ N·mm = 115.8 kNm" },
                { t: "Compare with Chapter 7", w: "laterally supported: 267.3 kNm\nunrestrained:        115.8 kNm\n→ 43% of it. The same beam, the same steel, the same span." },
              ],
              ans: "Md falls from 267.3 kNm to 115.8 kNm — a loss of 57% — purely because nothing is holding the compression flange.",
            },
            { k: "eg",
              title: "Example 8.2 — One restraint at mid-span",
              given: "The same beam, with a single secondary member framing into the compression flange at mid-span: LLT = 2500 mm.",
              steps: [
                { t: "The ratios", w: "LLT/ry = 2500/28.2 = 88.7;  hf/tf = 24 as before" },
                { t: "fcr,b", w: "first term  = 2,171,313/7859 = 276.3\nsecond term = √[1 + 0.05 × (88.7/24)²] = √[1 + 0.682] = 1.297\nfcr,b = 276.3 × 1.297 = 358.3 N/mm²" },
                { t: "λLT, φLT, χLT", w: "λLT = √(250/358.3) = 0.835\nφLT = 0.5[1 + 0.21(0.635) + 0.698] = 0.916\nχLT = 1/[0.916 + √(0.838 − 0.698)] = 1/[0.916 + 0.375] = 0.775" },
                { t: "Capacity", w: "fbd = 0.775 × 250/1.10 = 176.1 N/mm²\nMd = 1176.18 × 10³ × 176.1 = 207.2 kNm" },
                { t: "What the restraint bought", w: "115.8 → 207.2 kNm, an increase of 79%\nfrom one member, at one point, on one flange." },
              ],
              ans: "A single lateral restraint at mid-span raises the capacity by 79%, from 115.8 to 207.2 kNm — still short of the fully restrained 267.3, but at a fraction of the cost of a bigger section.",
            },
            { k: "trap", t: "Three numbers for the same beam: 267.3 restrained, 207.2 with one restraint, 115.8 with none. Quoting the section table's moment capacity without stating the restraint condition is meaningless, and in the unrestrained case it overstates the beam by a factor of 2.3." },
          ],
        },

        {
          n: "8.5",
          title: "Designing against it",
          hi: "इससे बचाव",
          blocks: [
            { k: "p", t: "Once LTB is understood the design responses follow directly from the formula, in rough order of cost:" },
            { k: "list", items: [
              "<strong>Reduce LLT.</strong> Nearly always the cheapest. A secondary member, a tie, or a bracing at mid-span costs a fraction of a larger beam, and Example 8.2 shows what it returns.",
              "<strong>Increase ry.</strong> A section with wider flanges — an ISWB or ISHB rather than an ISMB — has a much larger ry for similar depth and weight. This is the right move when restraint genuinely is not available.",
              "<strong>Use a closed section.</strong> A rectangular hollow section has such high torsional stiffness that LTB effectively disappears. More expensive per kilogram and harder to connect, but for a long unrestrained span it can still win.",
              "<strong>Accept the reduced capacity</strong> and size the beam for it. Sometimes correct, and always better than assuming the restraint is there when it is not.",
            ]},
            { k: "note", t: "Erection is a separate design case, and one that is missed with some regularity. A composite floor beam is fully restrained once the slab has hardened — but during erection it is a bare steel beam with nothing on its flange, carrying wet concrete, workers and equipment. The critical LTB check for such a beam is often the temporary condition, not the permanent one, and temporary bracing is a designer's responsibility to specify." },
          ],
        },

        {
          n: "8.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "The compression flange is a column; the tension flange makes it twist as it buckles.",
              "LLT is the distance between restraints to the COMPRESSION flange, not the span.",
              "Md = βb Zp fbd with fbd = χLT fy/γm0 — the column machinery, applied to bending.",
              "Plateau to λLT = 0.4; αLT = 0.21 rolled, 0.49 welded.",
              "fcr,b from Cl. 8.2.2.1: a Euler term in LLT/ry, times a warping correction in hf/tf.",
              "In a hogging region the compression flange is the bottom one — the slab is no help there.",
              "Halving LLT is the cheapest large gain available in steel beam design.",
              "Closed sections are effectively immune.",
              "Check the erection condition separately.",
            ]},
            { k: "p", t: "Chapter 9 puts bending and axial force on the same member — the beam-column, which is what most real frame members actually are, and where the interactions of Chapters 6, 7 and 8 all arrive at once." },
          ],
        },
      ],
    }

  );
})();
