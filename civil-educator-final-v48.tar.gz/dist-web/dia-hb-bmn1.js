/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: BUILDING MATERIALS · COMPLETE NOTES
   Drawn from the figures in the class notes. Styling classes are
   the shared .dia ones (s, thin, conc, soft, hi, ac, lb, em, ea),
   so every figure follows light and dark themes.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

(function () {
  /* arrowhead markers, one set per figure so ids never collide */
  const mk = (id) => `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
  </defs>`;
  const arr = (id, x1, y1, x2, y2, cls) => `<line class="${cls || "s"}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-end="url(#${id}-${cls === "hi" ? "m" : "a"})"/>`;
  const box = (x, y, w, h, lines, cls) => `<rect class="${cls || "conc"}" x="${x}" y="${y}" width="${w}" height="${h}" rx="7"/>` +
    lines.map((t, i) => `<text x="${x + w / 2}" y="${y + h / 2 + (i - (lines.length - 1) / 2) * 16 + 4}" text-anchor="middle"${i > 0 ? ' class="lb"' : ""}>${t}</text>`).join("");

  Object.assign(DB.diagrams, {

    /* ------------------------------------------------ 1.2 rock → use */
    "hb-bmn-stoneflow": {
      label: "From rock to building stone",
      svg: `<svg viewBox="0 0 680 210" role="img" aria-label="Flow: Rocks, then Quarrying, extracted as Stones, then Cutting, Dressing and Polishing, then Utilization.">
        ${mk("sf")}
        ${box(16, 30, 110, 48, ["Rocks"])}
        ${arr("sf", 126, 54, 170, 54)}
        ${box(172, 30, 120, 48, ["Quarrying"])}
        ${arr("sf", 292, 54, 380, 54, "hi")}
        <text class="em" x="336" y="44" text-anchor="middle">EXTRACTED</text>
        ${box(382, 30, 110, 48, ["Stones"])}
        ${arr("sf", 437, 78, 437, 112)}
        ${box(330, 114, 214, 54, ["Cutting, Dressing", "and Polishing"], "soft-b")}
        ${arr("sf", 330, 141, 242, 141)}
        ${box(92, 117, 148, 48, ["UTILIZATION"])}
        <text class="lb" x="600" y="44" text-anchor="middle">naturally</text><text class="lb" x="600" y="60" text-anchor="middle">available</text><text class="lb" x="340" y="200" text-anchor="middle">durability &gt; 50 years · construction possible without joints</text>
      </svg>`,
    },

    /* ------------------------------------------------ 1.3 igneous types */
    "hb-bmn-igneous": {
      label: "Where igneous rocks form",
      svg: `<svg viewBox="0 0 680 280" role="img" aria-label="Cross-section of the ground: volcanic rock such as basalt forms where magma pours onto the surface; hypabyssal rock such as dolerite forms at shallow depth; plutonic rock such as granite forms at deeper depth.">
        ${mk("ig")}
        <line class="s" x1="20" y1="70" x2="660" y2="70"/>
        <text class="lb" x="24" y="62">ground surface</text>
        <path class="soft" d="M300 70 L340 30 L380 70 Z"/>
        <path class="s" d="M300 70 L340 30 L380 70"/>
        <path class="hi" d="M340 70 L340 250"/>
        <path class="soft-b" d="M250 70 Q340 58 430 70 L430 76 Q340 66 250 76 Z"/>
        <text x="450" y="46">(c) VOLCANIC</text><text class="lb" x="450" y="62">on surface · Ex: Basalt</text>
        <rect class="softa" x="200" y="120" width="120" height="26" rx="6"/>
        <line class="gl" x1="20" y1="133" x2="660" y2="133"/>
        <text x="450" y="124">(b) HYPABYSSAL</text><text class="lb" x="450" y="140">shallow depth · Ex: Dolerite</text>
        <ellipse class="soft-b" cx="340" cy="225" rx="120" ry="34"/>
        <text x="468" y="220">(a) PLUTONIC</text><text class="lb" x="468" y="236">deeper depth · Ex: Granite</text>
        <text class="em" x="36" y="200">magma cools</text>
        <text class="em" x="36" y="216">→ IGNEOUS rock</text>
        <text class="lb" x="36" y="232">(eruptive / unstratified)</text>
        <text class="lb" x="36" y="112">below ground ↓</text>
      </svg>`,
    },

    /* ------------------------------------------------ 1.4 blasting */
    "hb-bmn-blast": {
      label: "Blasting a rock with a charge at distance L",
      svg: `<svg viewBox="0 0 680 300" role="img" aria-label="A rock mass with a drilled hole; dynamite at the bottom of the hole connected by a wire to a lit fuse; L is the shortest distance from the charge to the rock face. Quantity of explosive in grams equals L squared divided by 0.008.">
        ${mk("bl")}
        <path class="conc" d="M40 90 L120 60 L260 72 L360 58 L420 84 L430 270 L40 270 Z"/>
        <path class="thin" d="M70 140 L140 170 L190 150 M320 236 L400 250 M90 230 L150 210 M330 110 L400 130"/>
        <text class="lb" x="60" y="254">(ROCK STRATA)</text>
        <rect class="s" x="228" y="66" width="18" height="150" rx="3"/>
        <rect class="soft-b" x="226" y="186" width="22" height="32" rx="4"/>
        <text x="258" y="206">Dynamite</text>
        <path class="ac" d="M237 186 L237 40 L300 22"/>
        <text class="ea" x="306" y="26">✶ Fuse (lit)</text>
        <line class="hi" x1="206" y1="200" x2="206" y2="70"/>
        <line class="s" x1="196" y1="200" x2="216" y2="200"/><line class="s" x1="196" y1="70" x2="216" y2="70"/>
        <text class="em" x="178" y="140" text-anchor="end">L</text>
        <text x="470" y="120">Quantity (g) =</text>
        <text class="em" x="470" y="148" style="font-size:16px">L² / 0·008</text>
        <text class="lb" x="470" y="178">L → shortest distance of</text>
        <text class="lb" x="470" y="194">explosive from rock face</text>
      </svg>`,
    },

    /* ------------------------------------------------ 2.1 brick earth */
    "hb-bmn-brickearth": {
      label: "Composition of brick earth",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Bar chart of brick earth composition per IS 2117-1975: silica 50 to 60 percent, alumina 20 to 30 percent, oxides of iron 5 to 6 percent, lime not exceeding 5 percent, magnesia trace about 1 percent.">
        <text class="em" x="20" y="24">BRICK EARTH [IS 2117-1975] — share by weight</text>
        ${[["Silica", 50, 60, "shape, durability"],
           ["Alumina (Al₂O₃)", 20, 30, "plasticity"],
           ["Oxides of iron", 5, 6, "red colour"],
           ["Lime (CaCO₃)", 0, 5, "not exceeding 5% · prevents shrinkage"],
           ["Magnesia", 0, 1, "trace (1%) · yellowish tint"]].map(([n, a, b, why], i) => {
          const y = 48 + i * 38, sc = 5;
          return `<text x="20" y="${y + 17}">${n}</text>
            <rect class="gl" x="170" y="${y}" width="${60 * sc}" height="24" rx="3"/>
            ${a ? `<rect class="soft-b" x="170" y="${y}" width="${a * sc}" height="24" rx="3"/>` : ""}
            <rect class="soft" x="${170 + a * sc}" y="${y}" width="${(b - a) * sc}" height="24"/>
            <text class="lb" x="${178 + b * sc}" y="${y + 17}">${a ? a + "–" + b + "% · " : ""}${why}</text>`;
        }).join("")}
      </svg>`,
    },

    /* ------------------------------------------------ 2.2 brick size */
    "hb-bmn-bricksize": {
      label: "Standard brick, nominal size and frog",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="A standard brick 19 by 9 by 9 centimetres drawn inside its nominal 20 by 10 by 10 centimetre unit including a 1 centimetre mortar joint; the frog on top is 10 by 4 by 1 centimetres.">
        <path class="dash" d="M60 90 L300 90 L360 50 L120 50 Z M60 90 L60 210 L300 210 L300 90 M300 210 L360 170 L360 50"/>
        <path class="conc" d="M72 98 L290 98 L342 64 L124 64 Z"/>
        <path class="conc" d="M72 98 L72 202 L290 202 L290 98 Z"/>
        <path class="conc" d="M290 202 L342 168 L342 64 L290 98 Z"/>
        <path class="soft-b" d="M160 86 L240 86 L256 76 L176 76 Z"/>
        <line class="thin" x1="240" y1="80" x2="262" y2="112"/><text class="em" x="266" y="124">frog</text>
        <text x="181" y="226" text-anchor="middle">19 cm</text>
        <text x="330" y="140">9</text>
        <text x="52" y="156" text-anchor="end">9</text>
        <text x="420" y="70">Standard (without mortar)</text>
        <text class="em" x="420" y="90">19 × 9 × 9 cm</text>
        <text x="420" y="124">Nominal (with 1 cm mortar)</text>
        <text class="em" x="420" y="144">20 × 10 × 10 cm</text>
        <text class="lb" x="420" y="162">(dashed outline)</text>
        <text x="420" y="196">Frog</text>
        <text class="em" x="420" y="216">10 × 4 × 1 cm</text>
      </svg>`,
    },

    /* ------------------------------------------------ 2.4 brick mfg */
    "hb-bmn-brickmfg": {
      label: "Manufacturing of bricks",
      svg: `<svg viewBox="0 0 680 270" role="img" aria-label="Four stages: preparation of brick earth (unsoiling, digging, cleaning, weathering, blending, tempering); moulding (hand or machine); drying at or below 120 degrees C (natural or artificial); burning at 600 to 1200 degrees C (clamp or kiln) through dehydration, oxidation and vitrification.">
        ${mk("bm")}
        ${[["1  PREPARATION", ["unsoiling · digging", "cleaning · weathering", "blending · tempering"]],
           ["2  MOULDING", ["hand: ground / table", "machine: plastic /", "dry-press"]],
           ["3  DRYING", ["T ≤ 120 °C", "natural: sun, stacking", "artificial: tunnel,", "hot floor dryer"]],
           ["4  BURNING", ["T = 600–1200 °C", "clamp (temporary)", "kiln (permanent)"]]].map(([t, ls], i) => {
          const x = 14 + i * 168;
          return `<rect class="${i === 3 ? "soft-b" : "conc"}" x="${x}" y="30" width="150" height="130" rx="8"/>
            <text class="em" x="${x + 75}" y="54" text-anchor="middle">${t}</text>
            ${ls.map((l, j) => `<text class="lb" x="${x + 75}" y="${82 + j * 20}" text-anchor="middle">${l}</text>`).join("")}
            ${i < 3 ? arr("bm", x + 150, 90, x + 166, 90) : ""}`;
        }).join("")}
        <text x="518" y="184">stages of burning:</text>
        ${[["i", "Dehydration"], ["ii", "Oxidation"], ["iii", "Vitrification"]].map(([r, t], j) =>
          `<text class="${j === 2 ? "em" : "lb"}" x="${530}" y="${206 + j * 20}">(${r}) ${t}</text>`).join("")}
        <path class="thin" d="M589 160 L589 170"/>
        <text class="lb" x="20" y="200">Pugging = grinding clay with water to make it plastic</text>
        <text class="lb" x="20" y="220">Weathering: 15 days · Top soil removed: 20 cm · Clay from 60–120 cm</text>
      </svg>`,
    },

    /* ------------------------------------------------ 3.3 oxides */
    "hb-bmn-oxides": {
      label: "Main oxides of cement",
      svg: `<svg viewBox="0 0 680 220" role="img" aria-label="Bar chart of cement oxides: lime 62 to 65 percent, silica 18 to 25 percent, alumina 5 to 9 percent, iron oxide 5 percent, gypsum 1 to 3 percent, SO3 1 to 3 percent, alkali 0.2 to 1 percent.">
        <text class="em" x="20" y="22">COMPONENTS OF CEMENT (%)</text>
        ${[["Lime CaO", 62, 65, "strength, soundness"],
           ["Silica SiO₂", 18, 25, "strength"],
           ["Alumina Al₂O₃", 5, 9, "quick (flash) setting"],
           ["Iron oxide Fe₂O₃", 5, 5, "colour, catalyst"],
           ["Gypsum · SO₃", 1, 3, "IST control · soundness"],
           ["Alkali", 0.2, 1, "no function"]].map(([n, a, b, why], i) => {
          const y = 36 + i * 29, sc = 4;
          return `<text x="20" y="${y + 15}">${n}</text>
            <rect class="soft-b" x="170" y="${y}" width="${a * sc}" height="20" rx="3"/>
            ${b > a ? `<rect class="soft" x="${170 + a * sc}" y="${y}" width="${(b - a) * sc}" height="20"/>` : ""}
            <text class="lb" x="${178 + b * sc}" y="${y + 15}">${a === b ? a : a + "–" + b}% · ${why}</text>`;
        }).join("")}
      </svg>`,
    },

    /* ------------------------------------------------ 3.4 cement mfg */
    "hb-bmn-cementmfg": {
      label: "Manufacturing of cement",
      svg: `<svg viewBox="0 0 680 430" role="img" aria-label="Flow chart: calcareous compounds (CaO) and argillaceous compounds (alumina, silica and others) are each crushed and finely ground, then mixed (dry: 800 degrees preheat, wet: add water), burnt with fuel in a rotary kiln at 1400 to 1600 degrees C to form clinkers, cooled, and ground in a tube mill with gypsum to give fine powdered cement.">
        ${mk("cm")}
        ${box(30, 14, 200, 46, ["Calcareous compounds", "(CaO)"])}
        ${box(450, 14, 200, 46, ["Argillaceous compounds", "(alumina, silica & other)"])}
        ${arr("cm", 130, 60, 130, 78)}${arr("cm", 550, 60, 550, 78)}
        ${box(60, 80, 140, 34, ["Crushing"])}${box(480, 80, 140, 34, ["Crushing"])}
        ${arr("cm", 130, 114, 130, 132)}${arr("cm", 550, 114, 550, 132)}
        ${box(40, 134, 180, 46, ["Fine grinding", "tube mill / ball mill"])}${box(460, 134, 180, 46, ["Fine grinding"])}
        ${arr("cm", 200, 180, 280, 204)}${arr("cm", 480, 180, 400, 204)}
        ${box(260, 206, 160, 34, ["MIX INGREDIENTS"])}
        <text class="lb" x="440" y="218">dry: 800 °C preheat</text><text class="lb" x="440" y="234">wet: add water</text>
        ${arr("cm", 340, 240, 340, 258)}
        ${box(260, 260, 160, 34, ["ROTARY KILN"], "soft-b")}
        <ellipse class="softa" cx="130" cy="277" rx="56" ry="18"/><text x="130" y="281" text-anchor="middle">Fuel / coal</text>
        ${arr("cm", 186, 277, 258, 277)}
        <text class="em" x="436" y="282">1400–1600 °C</text>
        ${arr("cm", 340, 294, 340, 312)}
        ${box(250, 314, 180, 30, ["Clinkers (@ high temp.)"])}
        ${arr("cm", 340, 344, 340, 356)}
        ${box(260, 358, 160, 28, ["Cooling kiln"])}
        ${arr("cm", 420, 372, 470, 372)}
        ${box(472, 356, 180, 32, ["Tube mill grinding"])}
        ${box(472, 300, 180, 40, ["GYPSUM", "CaSO₄·2H₂O"], "soft-b")}
        ${arr("cm", 562, 340, 562, 354, "hi")}
        ${arr("cm", 562, 388, 562, 398)}
        ${box(462, 400, 200, 26, ["Fine powdered CEMENT"])}
      </svg>`,
    },

    /* ------------------------------------------------ 4.2 heat */
    "hb-bmn-heat": {
      label: "Heat of hydration of Bogue's compounds",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="Bar chart of heat of hydration in joules per gram: C3A (celite) 865, C3S (alite) 500, C4AF (felite) 420, C2S (belite) 265.">
        <text class="em" x="20" y="24">HEAT OF HYDRATION (J/g) — order C₃A &gt; C₃S &gt; C₄AF &gt; C₂S</text>
        ${[["C₃A · Celite", 865, "within 24 h · flash set · no strength"],
           ["C₃S · Alite", 500, "early strength · best cementing"],
           ["C₄AF · Felite", 420, "within 24 h · poorest cementing"],
           ["C₂S · Belite", 265, "after 1 year+ · ultimate strength"]].map(([n, v, note], i) => {
          const y = 44 + i * 50, w = v * 0.42;
          return `<text x="20" y="${y + 20}">${n}</text>
            <rect class="${i === 0 ? "soft-b" : "conc"}" x="150" y="${y}" width="${w}" height="28" rx="4"/>
            <text class="${i === 0 ? "em" : ""}" x="${158 + w}" y="${y + 19}">${v}</text>
            <text class="lb" x="150" y="${y + 43}">${note}</text>`;
        }).join("")}
      </svg>`,
    },

    /* ------------------------------------------------ 5.1 vicat */
    "hb-bmn-vicat": {
      label: "Vicat's apparatus attachments",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Three Vicat attachments: a plunger for the consistency test, a needle for initial setting time of 30 minutes, and a needle with annular collar for final setting time of 600 minutes; all used on cement paste in a mould.">
        ${[["PLUNGER", "Consistency test", "P = 30–40% (35%)", "plunger"],
           ["NEEDLE", "Initial setting time", "IST 30 min · 0·85P water", "needle"],
           ["NEEDLE + ANNULAR COLLAR", "Final setting time", "FST 600 min (10 hr)", "collar"]].map(([t, u, v, kind], i) => {
          const cx = 115 + i * 225;
          const tool = kind === "plunger"
            ? `<rect class="s" x="${cx - 5}" y="40" width="10" height="70"/><rect class="soft-b" x="${cx - 9}" y="110" width="18" height="34" rx="2"/>`
            : `<rect class="s" x="${cx - 5}" y="40" width="10" height="84"/><line class="hi" x1="${cx}" y1="124" x2="${cx}" y2="146"/>` +
              (kind === "collar" ? `<rect class="soft-b" x="${cx - 16}" y="134" width="32" height="8" rx="2"/>` : "");
          return `${tool}
            <path class="conc" d="M${cx - 60} 148 L${cx + 60} 148 L${cx + 52} 180 L${cx - 52} 180 Z"/>
            <text class="lb" x="${cx}" y="168" text-anchor="middle">cement paste</text>
            <text class="em" x="${cx}" y="202" text-anchor="middle">${t}</text>
            <text x="${cx}" y="220" text-anchor="middle">${u}</text>
            <text class="lb" x="${cx}" y="238" text-anchor="middle">${v}</text>`;
        }).join("")}
        <text class="lb" x="340" y="22" text-anchor="middle">one Vicat's apparatus — three attachments</text>
      </svg>`,
    },

    /* ------------------------------------------------ 6.1 4.75 sieve */
    "hb-bmn-4p75": {
      label: "The 4.75 mm sieve divides fine and coarse aggregate",
      svg: `<svg viewBox="0 0 680 240" role="img" aria-label="A 4.75 millimetre sieve: particles retained on it are coarse aggregate (gravel, ballast, stones) which contribute strength; particles passing are fine aggregate (sand, ash, surkhi, crushed stone) which act as filler and help workability. As per IS 383.">
        ${mk("sv")}
        <ellipse class="soft-b" cx="230" cy="70" rx="26" ry="16"/><ellipse class="soft-b" cx="290" cy="64" rx="22" ry="18"/><ellipse class="soft-b" cx="350" cy="72" rx="28" ry="14"/><ellipse class="soft-b" cx="410" cy="66" rx="20" ry="16"/>
        <line class="hi" x1="190" y1="96" x2="480" y2="96"/>
        <path class="thin" d="M200 96 L200 104 M220 96 L220 104 M240 96 L240 104 M260 96 L260 104 M280 96 L280 104 M300 96 L300 104 M320 96 L320 104 M340 96 L340 104 M360 96 L360 104 M380 96 L380 104 M400 96 L400 104 M420 96 L420 104 M440 96 L440 104 M460 96 L460 104"/>
        <text class="em" x="490" y="100">4·75 mm sieve (IS 383)</text>
        ${Array.from({ length: 26 }, (_, i) => `<circle class="soft-b" cx="${200 + (i % 13) * 20 + (i > 12 ? 10 : 0)}" cy="${170 + (i > 12 ? 16 : 0)}" r="3"/>`).join("")}
        ${arr("sv", 320, 108, 320, 156)}
        <text x="20" y="46">RETAINED</text><text class="em" x="20" y="64">Coarse aggregate</text><text class="lb" x="20" y="80">size &gt; 4·75 mm</text><text class="lb" x="20" y="96">→ strength</text>
        <text x="20" y="168">PASSING</text><text class="em" x="20" y="186">Fine aggregate</text><text class="lb" x="20" y="202">size &lt; 4·75 mm → filler,</text><text class="lb" x="20" y="218">workability</text>
      </svg>`,
    },

    /* ------------------------------------------------ 6.3 agg mix */
    "hb-bmn-aggmix": {
      label: "Aggregate mix",
      svg: `<svg viewBox="0 0 680 220" role="img" aria-label="Sketch of an aggregate mix: large gravel particles with small sand particles filling the spaces between them.">
        <rect class="gl" x="120" y="20" width="300" height="180" rx="8"/>
        ${[[170, 60, 34, 24], [260, 56, 30, 26], [350, 66, 36, 22], [190, 140, 30, 28], [290, 128, 38, 24], [370, 150, 28, 24], [220, 98, 22, 18]].map(([x, y, rx, ry]) =>
          `<ellipse class="conc" cx="${x}" cy="${y}" rx="${rx}" ry="${ry}"/>`).join("")}
        ${Array.from({ length: 60 }, (_, i) => { const x = 132 + ((i * 53) % 276), y = 30 + ((i * 37) % 160); return `<circle class="hif" cx="${x}" cy="${y}" r="2"/>`; }).join("")}
        <text class="em" x="450" y="80">Gravel (CA)</text><text class="lb" x="450" y="98">skeleton — strength</text>
        <text class="em" x="450" y="140">Sand (FA)</text><text class="lb" x="450" y="158">fills the spaces between</text>
        <text class="lb" x="270" y="216" text-anchor="middle">(AGGREGATE MIX)</text>
      </svg>`,
    },

    /* ------------------------------------------------ 7.1 tree */
    "hb-bmn-tree": {
      label: "Parts of a tree",
      svg: `<svg viewBox="0 0 680 284" role="img" aria-label="A tree: crown at the top bears leaves and fruits; trunk in the middle imparts strength and rigidity and is the timber; roots below ground form the foundation and absorb water and nutrients.">
        ${mk("tr")}
        <ellipse class="soft-b" cx="220" cy="78" rx="110" ry="60"/>
        <rect class="conc" x="204" y="126" width="32" height="104"/>
        <line class="s" x1="40" y1="230" x2="420" y2="230"/>
        <path class="thin" d="M220 230 L180 262 M220 230 L200 268 M220 230 L240 268 M220 230 L262 260 M210 230 L150 250 M230 230 L292 248"/>
        <text x="450" y="70">CROWN</text><text class="lb" x="450" y="86">bears leaves and fruits</text>
        ${arr("tr", 444, 74, 334, 78)}
        <text class="em" x="450" y="170">TRUNK ✓</text><text class="lb" x="450" y="186">strength &amp; rigidity — the timber</text>
        ${arr("tr", 444, 176, 240, 176, "hi")}
        <text x="450" y="240">ROOTS</text><text class="lb" x="450" y="256">foundation; absorb H₂O</text><text class="lb" x="450" y="272">and nutrients from soil</text>
        ${arr("tr", 444, 244, 296, 250)}
      </svg>`,
    },

    /* ------------------------------------------------ 7.2 FSP */
    "hb-bmn-fsp": {
      label: "Free water, bound moisture and the fibre saturation point",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Wood cells: free water in the cell cavities is removed first during seasoning; bound moisture in the cell walls remains. When all free water is lost the fibre saturation point is reached. Moisture content P percent equals W1 minus W2 over W2 times 100, where W2 is the weight after oven drying at 100 to 105 degrees C.">
        ${mk("fs")}
        ${[0, 1, 2].map((i) => {
          const cx = 90 + i * 78, cy = 100, r = 40;
          const pts = Array.from({ length: 6 }, (_, k) => { const a = Math.PI / 6 + k * Math.PI / 3; return (cx + r * Math.cos(a)).toFixed(1) + "," + (cy + r * Math.sin(a)).toFixed(1); }).join(" ");
          const pin = Array.from({ length: 6 }, (_, k) => { const a = Math.PI / 6 + k * Math.PI / 3; return (cx + 30 * Math.cos(a)).toFixed(1) + "," + (cy + 30 * Math.sin(a)).toFixed(1); }).join(" ");
          return `<polygon class="soft-b" points="${pts}"/><polygon class="conc" points="${pin}"/>
            ${[[-8, -6], [6, -10], [0, 6], [10, 8], [-10, 10]].map(([dx, dy]) => `<circle class="hif" cx="${cx + dx}" cy="${cy + dy}" r="2.4"/>`).join("")}`;
        }).join("")}
        <text class="em" x="20" y="186">cell cavity → FREE water (removed first)</text>
        <text class="lb" x="20" y="204">cell wall → BOUND moisture</text>
        <text class="lb" x="20" y="222">all free water gone = FIBRE SATURATION POINT</text>
        ${box(380, 40, 110, 50, ["Timber", "W1 (initial)"])}
        ${arr("fs", 490, 65, 560, 65)}
        <text class="lb" x="525" y="56" text-anchor="middle">OVEN</text><text class="em" x="525" y="110" text-anchor="middle">oven at 100–105 °C</text>
        ${box(562, 40, 108, 50, ["Dry timber", "W2"])}
        <text class="em" x="400" y="160">P% = (W1 − W2) / W2 × 100</text>
        <text class="lb" x="400" y="180">moisture content, on dry weight</text>
      </svg>`,
    },

    /* ------------------------------------------------ 7.4 sawing */
    "hb-bmn-sawing": {
      label: "Types of sawing",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Four log cross-sections with annular rings: 1 ordinary or flat or slab sawing with parallel cuts tangential to the rings; 2 quarter sawing with cuts at right angles dividing the log into quarters; 3 tangential sawing with cuts tangential to the rings meeting at right angles; 4 radial or rift sawing with cuts along the medullary rays from the centre.">
        ${[0, 1, 2, 3].map((i) => {
          const cx = 88 + i * 168, cy = 100;
          const rings = [62, 46, 30, 14].map((r) => `<circle class="${r === 62 ? "conc" : "thin"}" cx="${cx}" cy="${cy}" r="${r}"/>`).join("");
          let cuts = "";
          if (i === 0) cuts = [-40, -20, 0, 20, 40].map((d) => `<line class="hi" x1="${cx + d}" y1="${cy - 60}" x2="${cx + d}" y2="${cy + 60}"/>`).join("");
          if (i === 1) cuts = `<line class="hi" x1="${cx - 62}" y1="${cy}" x2="${cx + 62}" y2="${cy}"/><line class="hi" x1="${cx}" y1="${cy - 62}" x2="${cx}" y2="${cy + 62}"/><path class="soft" d="M${cx} ${cy} L${cx + 62} ${cy} A62 62 0 0 0 ${cx} ${cy - 62} Z"/>`;
          if (i === 2) cuts = [-30, 0, 30].map((d) => `<line class="hi" x1="${cx - 62}" y1="${cy + d}" x2="${cx + 62}" y2="${cy + d}"/><line class="ac" x1="${cx + d}" y1="${cy - 62}" x2="${cx + d}" y2="${cy + 62}"/>`).join("");
          if (i === 3) cuts = Array.from({ length: 8 }, (_, k) => { const a = k * Math.PI / 4; return `<line class="hi" x1="${cx}" y1="${cy}" x2="${(cx + 62 * Math.cos(a)).toFixed(1)}" y2="${(cy + 62 * Math.sin(a)).toFixed(1)}"/>`; }).join("");
          const [t, u, v] = [["1 Ordinary / flat / slab", "parallel cuts, tangential", "most common in India"],
                             ["2 Quarter", "cuts at right angles", "indistinct medullary rings"],
                             ["3 Tangential", "tangential cuts meeting", "at right angles"],
                             ["4 Radial / rift", "along medullary rays", "hardwood · aesthetic"]][i];
          return `${rings}${cuts}<circle class="hif" cx="${cx}" cy="${cy}" r="3"/>
            <text class="em" x="${cx}" y="192" text-anchor="middle">${t}</text>
            <text class="lb" x="${cx}" y="210" text-anchor="middle">${u}</text>
            <text class="lb" x="${cx}" y="226" text-anchor="middle">${v}</text>`;
        }).join("")}
      </svg>`,
    },

    /* ------------------------------------------------ 7.6 knot */
    "hb-bmn-knot": {
      label: "How a knot forms",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Left: a tree with a side branch being cut off. Right: the same trunk later, with food flowing up from the ground feeding the stub, which has formed a dark hard ring, the knot.">
        ${mk("kn")}
        <rect class="conc" x="120" y="40" width="40" height="170"/>
        <path class="conc" d="M160 110 L240 70 L248 84 L160 128 Z"/>
        <path class="ac" d="M188 92 L200 124 M196 88 L208 120"/>
        <text class="ea" x="214" y="136">cut off</text>
        <line class="s" x1="60" y1="210" x2="260" y2="210"/>
        <text class="lb" x="140" y="236" text-anchor="middle">1 · branch removed</text>
        ${arr("kn", 290, 125, 360, 125)}
        <rect class="conc" x="440" y="40" width="40" height="170"/>
        <circle class="soft-b" cx="470" cy="118" r="12"/><circle class="hif" cx="470" cy="118" r="5"/>
        ${arr("kn", 430, 204, 430, 140, "hi")}${arr("kn", 490, 204, 490, 140, "hi")}
        <text class="em" x="400" y="190" text-anchor="end">Food ↑</text>
        <text class="em" x="500" y="114">→ KNOT</text>
        <text class="lb" x="500" y="132">dark hard ring</text>
        <line class="s" x1="380" y1="210" x2="580" y2="210"/>
        <text class="lb" x="460" y="236" text-anchor="middle">2 · stub keeps getting nourishment</text>
      </svg>`,
    },

    /* ------------------------------------------------ 8.4 steps */
    "hb-bmn-concsteps": {
      label: "Manufacturing of concrete — seven steps",
      svg: `<svg viewBox="0 0 680 130" role="img" aria-label="Seven steps in a row: batching, mixing, transportation, placing, compaction, finishing, curing.">
        ${mk("cs")}
        ${["Batching", "Mixing", "Transport", "Placing", "Compaction", "Finishing", "Curing"].map((t, i) => {
          const x = 8 + i * 96;
          return `<rect class="${i === 0 || i === 6 ? "soft-b" : "conc"}" x="${x}" y="40" width="84" height="44" rx="7"/>
            <text class="lb" x="${x + 42}" y="30" text-anchor="middle">${i + 1}</text>
            <text x="${x + 42}" y="66" text-anchor="middle" style="font-size:11px">${t}</text>
            ${i < 6 ? arr("cs", x + 84, 62, x + 95, 62) : ""}`;
        }).join("")}
        <text class="lb" x="50" y="104" text-anchor="middle">volume /</text><text class="lb" x="50" y="118" text-anchor="middle">weight</text>
        <text class="lb" x="146" y="104" text-anchor="middle">hand /</text><text class="lb" x="146" y="118" text-anchor="middle">machine</text>
        <text class="lb" x="530" y="104" text-anchor="middle">uniform</text><text class="lb" x="530" y="118" text-anchor="middle">surface</text>
      </svg>`,
    },

    /* ------------------------------------------------ 9.4 volume column */
    "hb-bmn-concvol": {
      label: "Absolute volume of 1 m³ of concrete",
      svg: `<svg viewBox="0 0 680 290" role="img" aria-label="A stacked column representing one cubic metre of fresh concrete: from bottom, cement, water, air, then coarse plus fine aggregate. Voids are air plus water; solids are cement plus aggregates. Aggregate volume equals one minus voids minus cement.">
        ${mk("cv")}
        ${[["CA + FA", 150, "soft-b"], ["Air", 22, "gl"], ["Water", 48, "softa"], ["Cement", 40, "conc"]].reduce((acc, [t, h, c]) => {
          const y = acc.y; acc.y += h;
          acc.s += `<rect class="${c}" x="120" y="${y}" width="140" height="${h}"/><rect class="s" x="120" y="${y}" width="140" height="${h}" style="fill:none"/>
            <text x="190" y="${y + h / 2 + 4}" text-anchor="middle">${t}</text>`;
          return acc;
        }, { y: 20, s: "" }).s}
        <line class="hi" x1="90" y1="20" x2="90" y2="280"/>
        <line class="s" x1="82" y1="20" x2="98" y2="20"/><line class="s" x1="82" y1="280" x2="98" y2="280"/>
        <text class="em" x="72" y="154" text-anchor="end">V</text>
        <path class="thin" d="M270 170 L282 170 L282 240 L270 240"/><text class="lb" x="290" y="200">voids</text><text class="lb" x="290" y="216">(A + W)</text>
        <text x="370" y="60">Vconcrete = Vvoids + Vsolids</text>
        <text class="lb" x="370" y="80">= (VA + Vw) + (Vc + VCA + VFA)</text>
        <text x="370" y="120">each part = weight / (S.G. × 1000)</text>
        <text class="em" x="370" y="160">VAggregate = 1 − Vvoids − Vcement</text>
        <text class="lb" x="370" y="200">FA share P = FA / (FA + CA)</text>
        <text class="lb" x="370" y="218">default: FA 33·33%, CA 66·66%</text>
      </svg>`,
    },

    /* ------------------------------------------------ 10.1 slump */
    "hb-bmn-slump": {
      label: "Slump cone test",
      svg: `<svg viewBox="0 0 680 230" role="img" aria-label="Left: a cone filled with fresh concrete. Right: after the cone is lifted, the concrete sinks; the drop in height from the top of the cone is the slump.">
        ${mk("sl")}
        <path class="conc" d="M100 190 L150 50 L210 50 L260 190 Z"/>
        <text class="lb" x="180" y="214" text-anchor="middle">1 · cone filled with concrete</text>
        ${arr("sl", 290, 120, 350, 120)}
        <text class="lb" x="320" y="108" text-anchor="middle">lift</text>
        <path class="dash" d="M400 190 L450 50 L510 50 L560 190"/>
        <path class="soft-b" d="M392 190 Q400 104 450 96 L512 96 Q566 108 572 190 Z"/>
        <line class="hi" x1="600" y1="50" x2="600" y2="96"/>
        <line class="s" x1="590" y1="50" x2="610" y2="50"/><line class="s" x1="590" y1="96" x2="610" y2="96"/>
        <text class="em" x="616" y="78">slump</text>
        <text class="lb" x="480" y="214" text-anchor="middle">2 · concrete sinks — measure the drop</text>
      </svg>`,
    },

  });
})();
