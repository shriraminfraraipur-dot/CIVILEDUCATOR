/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   Chapter 7 — Compaction
   Chapter 8 — Consolidation and Settlement
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "ge"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "ge-7",
      n: 7,
      title: "Compaction",
      hi: "संघनन",
      blurb: "The one chapter where you choose the soil's density instead of measuring it — and the curve that says how.",
      mins: 28,
      sections: [

        {
          n: "7.1",
          title: "Compaction is not consolidation",
          hi: "संघनन बनाम समेकन",
          blocks: [
            { k: "p", t: "The two words are routinely swapped and they describe different processes with different mechanisms and different timescales. Getting them straight now saves a great deal of confusion in Chapter 8." },
            { k: "cmp", t: "Both densify soil. Nothing else about them is the same.",
              cols: ["Compaction (Ch 7)", "Consolidation (Ch 8)"],
              rows: [
                ["What is expelled", "<strong>Air</strong>", "<strong>Water</strong>"],
                ["Applied by", "Mechanical energy — rolling, ramming, vibration", "A sustained static load"],
                ["Timescale", "Immediate — one pass of a roller", "Months to years"],
                ["Soil state", "Partly saturated", "Saturated"],
                ["Who controls it", "The engineer — you specify the density", "The soil — you can only predict it"],
                ["Where", "Fills, embankments, subgrades — soil that is PLACED", "Natural ground beneath a structure"],
              ] },
            { k: "p", t: "So compaction is a construction operation with a specification attached, and consolidation is a natural process you must forecast and live with. This chapter is the only one in the handbook where the engineer gets to decide what the soil's density will be." },
          ],
        },

        {
          n: "7.2",
          title: "The compaction curve",
          hi: "संघनन वक्र",
          blocks: [
            { k: "p", t: "Compact the same soil at a series of water contents with the same effort and plot dry density against water content. The result is not a straight line — it rises to a peak and falls away, and the peak is the whole point." },
            { k: "dia", id: "hb-ge-compact", cap: "A peak, a zero air voids ceiling, and a second curve for heavier effort." },
            { k: "def", term: "Optimum moisture content (OMC)", t: "The water content at which the given compactive effort produces the greatest dry density." },
            { k: "def", term: "Maximum dry density (MDD)", t: "The dry density at the OMC. Both MDD and OMC are properties of the soil <em>and</em> of the effort — change the effort and both change." },
            { k: "p", t: "Why a peak? On the dry side, water films lubricate the grains and let them slide into a tighter packing, so adding water helps. Past the optimum the voids are nearly full; water is incompressible and cannot drain away in the time a roller passes, so it starts to occupy space the grains would otherwise have taken. Adding more water now <em>reduces</em> the dry density." },
            { k: "eq", expr: "zero air voids line:   γd = G γw / (1 + w G)", where: [] },
            { k: "p", t: "That line is the dry density the soil would have if it were fully saturated at that water content — no air at all. <strong>The compaction curve can never cross it or touch it</strong>, because that would mean negative air volume, and the gap between the curve and the line is a direct measure of the air voids left in the fill." },
            { k: "eg",
              title: "Example 7.1 — Reading a Proctor test",
              given: "Standard Proctor test, 1000 cm³ mould, G = 2.68. Bulk densities (g/cm³) at water contents 10, 12, 14, 16, 18%: 1.92, 2.04, 2.12, 2.11, 2.06.",
              steps: [
                { t: "Dry densities ρd = ρ/(1 + w)", w: "10%: 1.745   12%: 1.821   14%: 1.860   16%: 1.819   18%: 1.746" },
                { t: "MDD and OMC", w: "peak at about 14% → MDD ≈ 1.86 g/cm³, OMC ≈ 14%" },
                { t: "Zero-air-voids density at 14%", w: "ρd,zav = G ρw/(1 + wG) = 2.68/(1 + 0.14 × 2.68) = 1.949 g/cm³" },
                { t: "Air voids at the optimum", w: "na = 1 − ρd (1/G + w) = 1 − 1.86 × (0.373 + 0.14) = 1 − 0.954 = 4.6%" },
              ],
              ans: "MDD 1.86 g/cm³ at OMC 14%, with about 5% air voids left at the peak — typical: no amount of compaction at that effort reaches the ZAV line." },
            { k: "p", t: "Increasing the compactive effort raises the curve and shifts its peak to the <em>left</em> — a higher maximum dry density at a lower optimum water content. That is why the modified Proctor test (IS 2720 Part 8, heavier rammer, greater drop, more layers) gives a higher MDD than the standard test (Part 7) on the same soil, and why a specification must always say which test it means." },
          ],
        },

        {
          n: "7.3",
          title: "Specifying and checking it",
          hi: "विनिर्देश और जाँच",
          blocks: [
            { k: "p", t: "A compaction specification is written as a percentage of the laboratory maximum — typically 95% or 98% of standard or modified Proctor MDD — together with a permitted band of water content around the OMC." },
            { k: "eq", expr: "relative compaction  =  field dry density / laboratory MDD  × 100%", where: [] },
            { k: "eg",
              title: "Example 7.2 — What a field density result actually tells you",
              given: "A soil with G = 2.68 is compacted in the field. A field density test gives a dry density of 1.82 g/cm³ at a water content of 14.5%. The laboratory MDD is 1.87 g/cm³ at an OMC of 13.0%.",
              steps: [
                { t: "Relative compaction", w: "= 1.82/1.87 × 100 = 97.3%\nAgainst a 95% specification: passes  ✓" },
                { t: "Void ratio achieved", w: "γd = G γw/(1 + e), so  e = G γw/γd − 1\n  = 2.68 × 1.0/1.82 − 1 = 1.4725 − 1 = 0.4725" },
                { t: "Degree of saturation", w: "S = wG/e = 0.145 × 2.68/0.4725 = 0.3886/0.4725\n  = 0.822 = 82.2%" },
                { t: "Air voids remaining", w: "na = (1 − S) e/(1 + e) = (1 − 0.822) × 0.4725/1.4725\n   = 0.178 × 0.3209 = 0.0571 = 5.7%" },
                { t: "Sanity check against the ZAV line", w: "ZAV density at w = 14.5%:\nγd = 2.68 × 1.0/(1 + 0.145 × 2.68) = 2.68/1.3886 = 1.930 g/cm³\nAchieved 1.82 < 1.930  ✓ — below the ceiling, as it must be" },
              ],
              ans: "97.3% relative compaction with 5.7% air voids remaining. The specification passes, but note the water content: at 14.5% the fill is 1.5% wet of optimum, which is on the falling branch of the curve.",
            },
            { k: "note", t: "That last observation is not pedantry. Being wet of optimum is often specified deliberately — a clay compacted wet of optimum ends up with a dispersed structure that is <strong>less permeable and less prone to swelling</strong>, which is exactly what a dam core wants. Compacted dry of optimum, the same clay is stronger and stiffer but will swell if it later gets wet. <strong>The side of the optimum is a design decision, not an accident.</strong>" },
            { k: "list", items: [
              "<strong>Core cutter</strong> — quick, for cohesive soils free of stones.",
              "<strong>Sand replacement</strong> — for gravelly soils where a core cutter cannot be driven.",
              "<strong>Nuclear density gauge</strong> — fast and non-destructive, needs calibration and a licence.",
            ]},
            { k: "real", t: "On site the plant is chosen by the soil, not by what is in the yard. <strong>Smooth-wheeled rollers</strong> for granular bases and finishing; <strong>sheepsfoot</strong> for clays, because the feet knead and break down clods that a smooth drum would only bridge over; <strong>vibratory</strong> rollers for sands and gravels, where vibration rearranges grains far more effectively than static weight; <strong>pneumatic</strong> for a wide range, with the kneading action a smooth drum lacks." },
          ],
        },

        {
          n: "7.4",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Compaction expels air, quickly, by mechanical effort. Consolidation expels water, slowly, under load.",
              "The curve peaks at OMC because water first lubricates and then occupies space.",
              "MDD and OMC belong to the soil AND the effort — always state which Proctor test.",
              "Heavier effort: higher peak, drier optimum.",
              "The zero air voids line is a ceiling that can never be reached.",
              "Specify as a percentage of laboratory MDD, with a water content band.",
              "Dry of optimum is stronger but swells; wet of optimum is less permeable. Choose deliberately.",
              "Sheepsfoot for clay, vibratory for sand — the plant follows the soil.",
            ]},
            { k: "p", t: "Chapter 8 takes the other process in that comparison table — the slow one, that the engineer cannot control and must instead predict." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "ge-8",
      n: 8,
      title: "Consolidation and Settlement",
      hi: "समेकन और बैठान",
      blurb: "Why a building on clay is still settling ten years after it was finished, and how much it has left to go.",
      mins: 40,
      sections: [

        {
          n: "8.1",
          title: "Three settlements, three timescales",
          hi: "तीन प्रकार का बैठान",
          blocks: [
            { k: "list", items: [
              "<strong>Immediate (elastic) settlement</strong> — distortion at constant volume, as the load is applied. Over by the end of construction. Dominant in sands, where it is essentially the whole story.",
              "<strong>Primary consolidation</strong> — volume change as water is squeezed out of the voids. Months to decades. The subject of this chapter.",
              "<strong>Secondary compression (creep)</strong> — continued slow compression of the soil skeleton at constant effective stress, after the excess pore pressure has gone. Significant in organic soils and peat, minor in most inorganic clays.",
            ]},
            { k: "p", t: "For a footing on sand, settlement is over before the building is occupied. For the same footing on clay it may take twenty years, and the useful questions are <em>how much in total</em> and <em>how fast</em> — which are two separate calculations with two separate soil parameters." },
          ],
        },

        {
          n: "8.2",
          title: "The mechanism",
          hi: "क्रियाविधि",
          blocks: [
            { k: "dia", id: "an-ge-consol", cap: "A piston, a spring and a valve. The load never changes; only who carries it does." },
            { k: "p", t: "Terzaghi's spring analogy is the clearest explanation in soil mechanics. A cylinder of water with a spring inside and a valved piston on top. Apply a load:" },
            { k: "steps", items: [
              "<strong>At the instant of loading</strong>, the valve has passed no water, so the spring cannot have shortened. Water is nearly incompressible, so it carries the entire load: u = Δσ, σ′ = 0.",
              "<strong>Water begins to escape</strong> through the valve. The piston descends, the spring shortens and starts to take load. Every unit of load the spring takes is a unit the water sheds: u falls, σ′ rises, and their sum never changes.",
              "<strong>Eventually the water pressure returns to its original value.</strong> Flow stops, the spring carries all of the added load: u = 0 excess, σ′ = Δσ.",
            ]},
            { k: "p", t: "Map that onto soil: the spring is the soil skeleton, the water is the pore water, the valve is the permeability, and the piston is the foundation. <strong>The total stress is constant throughout</strong> — all that happens is a slow handover, and it is slow precisely because clay's permeability is so low." },
            { k: "trap", t: "The load does not increase during consolidation and the soil does not \"get more load over time\". The building applied everything it was ever going to apply on the day it was finished. What changes is <em>which phase is carrying it</em> — and since only σ′ causes compression (Chapter 5), the settlement follows the handover rather than the load." },
          ],
        },

        {
          n: "8.3",
          title: "How much — the e–log p curve",
          hi: "कितना — e–log p वक्र",
          blocks: [
            { k: "p", t: "An oedometer test (IS 2720 Part 15) loads a laterally confined sample in increments, letting each one fully consolidate, and records the void ratio at each stress. Plotted against log σ′, the result has a characteristic shape." },
            { k: "dia", id: "hb-ge-elogp", cap: "A flat recompression branch, a steep virgin line, and the pressure where they meet." },
            { k: "def", term: "Preconsolidation pressure σ′c", t: "The greatest effective stress the soil has ever carried. Below it the soil has been here before and barely compresses; above it, it is in new territory and compresses a great deal. Found graphically from the curve, usually by Casagrande's construction." },
            { k: "list", items: [
              "<strong>Normally consolidated (NC)</strong> — σ′₀ = σ′c. The soil has never carried more than it carries now. It will settle substantially under any new load.",
              "<strong>Overconsolidated (OC)</strong> — σ′₀ < σ′c. Something heavier was once on top — ice, eroded ground, a desiccated crust — and was removed. It will settle much less, provided the new stress stays below σ′c.",
            ]},
            { k: "eq", expr: "compression index  Cc = Δe / Δ(log σ′)        — the slope of the virgin line", where: [] },
            { k: "eq", expr: "Sc = (Cc H / (1 + e₀)) × log₁₀[ (σ′₀ + Δσ) / σ′₀ ]", where: [
              ["H", "thickness of the compressible layer"],
              ["e₀", "initial void ratio"],
              ["σ′₀", "initial effective stress at mid-depth of the layer"],
              ["Δσ", "the increase in effective stress, from Chapter 6"],
            ]},
            { k: "note", t: "Terzaghi and Peck's correlation <strong>Cc = 0.009 (LL − 10)</strong> for undisturbed clay of low to moderate sensitivity is a genuinely useful estimate — it lets you predict settlement from an Atterberg limit when no oedometer test exists. It is an estimate: use it for feasibility, not for a final design." },
            { k: "eg",
              title: "Example 8.1 — An overconsolidated clay settles far less",
              given: "A 4.0 m clay layer with e₀ = 0.90 and Cc = 0.32, σ′₀ = 120 kPa at mid-depth and a structure adding Δσ = 80 kPa (the same layer as Example 8.2), is found to have a preconsolidation pressure σ′p = 150 kPa and a recompression index Cs = 0.05.",
              steps: [
                { t: "Recompression part, 120 → 150 kPa", w: "S₁ = Cs H/(1 + e₀) × log₁₀(150/120) = 0.05 × 4.0/1.90 × 0.0969 = 0.0102 m" },
                { t: "Virgin part, 150 → 200 kPa", w: "S₂ = Cc H/(1 + e₀) × log₁₀(200/150) = 0.6737 × 0.1249 = 0.0842 m" },
                { t: "Total", w: "S = 10.2 + 84.2 = 94 mm  (149.5 mm if it were normally consolidated — Example 8.2)" },
                { t: "Cc estimated instead from LL = 48%", w: "Cc ≈ 0.009 (48 − 10) = 0.34 — close to the measured 0.32" },
              ],
              ans: "About 94 mm instead of 150 mm: the first 30 kPa costs almost nothing because the clay has been there before. Missing the preconsolidation pressure is one of the commonest reasons settlement predictions are too pessimistic." },
          ],
        },

        {
          n: "8.4",
          title: "How fast — the time factor",
          hi: "कितनी तेज़ी से — समय गुणक",
          blocks: [
            { k: "p", t: "Terzaghi's one-dimensional theory gives the rate. Its solution is expressed through a dimensionless time factor, which is what makes laboratory results transferable to the field." },
            { k: "eq", expr: "Tv  =  cv t / d²", where: [
              ["cv", "coefficient of consolidation, m²/year — from the oedometer test"],
              ["t", "elapsed time"],
              ["d", "the longest drainage path"],
            ]},
            { k: "trap", t: "<strong>d is the longest path a water particle must travel to escape</strong>, not the thickness of the layer. A clay layer draining to sand on both faces has d = H/2; the same layer on rock, draining only upward, has d = H. Since time goes as d², <strong>the singly drained layer takes four times as long</strong>. This is the most common error in the whole chapter." },
            { k: "eq", expr: "U < 60%:   Tv = (π/4)(U/100)²          U > 60%:   Tv = 1.781 − 0.933 log₁₀(100 − U%)", where: [
              ["U", "average degree of consolidation, per cent"],
            ]},
            { k: "p", t: "Two values are worth remembering because they turn up constantly: <strong>Tv = 0.197 at U = 50%</strong> and <strong>Tv = 0.848 at U = 90%</strong>. The gap between them tells the real story — getting from half to ninety per cent takes more than four times as long as reaching half did." },
            { k: "eg",
              title: "Example 8.2 — Settlement, and how long it takes",
              given: "A 4.0 m clay layer, drained on both faces, with e₀ = 0.90, Cc = 0.32 and cv = 3.5 m²/year. The effective stress at mid-depth is 120 kPa and a new structure adds 80 kPa.",
              steps: [
                { t: "Total primary consolidation settlement", w: "Sc = (Cc H/(1 + e₀)) × log₁₀[(σ′₀ + Δσ)/σ′₀]\n   = (0.32 × 4.0/1.90) × log₁₀(200/120)\n   = 0.6737 × log₁₀(1.6667)\n   = 0.6737 × 0.22185 = 0.1495 m = 149.5 mm" },
                { t: "Drainage path", w: "Drained both faces → d = H/2 = 2.0 m" },
                { t: "Time to 50% consolidation", w: "Tv = 0.197\nt = Tv d²/cv = 0.197 × 4.0/3.5 = 0.225 years = 82 days\nSettlement by then = 0.50 × 149.5 = 74.8 mm" },
                { t: "Time to 90% consolidation", w: "Tv = 1.781 − 0.933 log₁₀(10) = 1.781 − 0.933 = 0.848\nt = 0.848 × 4.0/3.5 = 0.969 years ≈ 12 months\nSettlement by then = 0.90 × 149.5 = 134.6 mm" },
                { t: "And if it drained only upward", w: "d = 4.0 m, so d² is four times larger\nt to 90% = 0.848 × 16.0/3.5 = 3.88 years" },
              ],
              ans: "149.5 mm of primary consolidation: half of it in under three months, 90% in about a year — or nearly four years if the layer could only drain upward. One assumption about drainage changes the programme by a factor of four.",
            },
          ],
        },

        {
          n: "8.5",
          title: "Doing something about it",
          hi: "उपाय",
          blocks: [
            { k: "list", items: [
              "<strong>Preloading</strong> — heap a surcharge of fill on the site before building, let the clay consolidate under it, then remove it. The settlement happens to the fill instead of to the structure.",
              "<strong>Vertical (sand or band) drains</strong> — the elegant answer. Since time goes as d², installing drains at 2 m centres turns a 10 m drainage path into a 1 m one and cuts the time by a factor of a hundred. Consolidation becomes largely <em>radial</em> rather than vertical, and a two-year wait becomes a few months.",
              "<strong>Stage construction</strong> — build in lifts, letting each one consolidate and gain strength before adding the next. Standard for embankments on soft ground.",
              "<strong>Piling through</strong> the compressible layer to something firmer — Chapter 12.",
              "<strong>Lightweight fill</strong>, reducing Δσ rather than fighting it.",
            ]},
            { k: "trap", t: "<strong>Differential</strong> settlement is what damages a structure, not total settlement. A building that settles 100 mm uniformly is level and undamaged; one that settles 40 mm at one corner and 70 mm at another is cracked. IS 1904 gives permissible values, and they are expressed as differential settlement or <em>angular distortion</em> — about 1/300 of the column spacing for ordinary RC frames and 1/500 where partitions are sensitive, with total settlements of the order of 50–75 mm (<a href=\"https://infralens.in/term/settlement\" target=\"_blank\" rel=\"noopener\">InfraLens summary of IS 1904</a>) — precisely because the differential is what matters." },
            { k: "note", t: "<b>Correction (v39):</b> an earlier version gave ‘about 1/500 for framed buildings’ as the IS 1904 figure. 1/500 is the stricter value for sensitive finishes and the common international baseline for avoiding cracking (Poulos et al., as summarised by <a href=\"https://eng.libretexts.org/Bookshelves/Civil_Engineering/Fundamentals_of_Foundation_Engineering_and_their_Applications_2e/04%3A_SETTLEMENT_OF_SHALLOW_FOUNDATIONS/4.03%3A_Tolerable_settlement\" target=\"_blank\" rel=\"noopener\">LibreTexts</a>, with 1/150–1/250 for structural damage); ordinary frames are usually allowed 1/300. Check the governing table of IS 1904 for the foundation type and soil." },
            { k: "real", t: "Vertical drains are visible on any major embankment project on soft coastal ground: a grid of band drains punched 15 or 20 m down before the fill goes on, with a sand blanket over the top to take the water away. The clay is not improved at all — <strong>only the drainage path is shortened</strong>, and that is enough to turn a decade into a season." },
          ],
        },

        {
          n: "8.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Immediate, primary consolidation, secondary compression — three settlements, three timescales.",
              "The spring analogy: total stress constant, load handed from water to skeleton.",
              "Sc = (Cc H/(1 + e₀)) log₁₀[(σ′₀ + Δσ)/σ′₀].",
              "Cc ≈ 0.009(LL − 10) for a first estimate.",
              "σ′c is what the soil remembers. NC settles a lot, OC very little.",
              "Tv = cv t/d², and d is the longest DRAINAGE PATH — half the layer if drained both sides.",
              "Tv = 0.197 at U = 50%, 0.848 at U = 90%.",
              "Vertical drains shorten d, and time goes as d².",
              "Differential settlement damages buildings; total settlement mostly does not.",
            ]},
            { k: "p", t: "Chapters 5 to 8 have dealt with how soil deforms. Chapter 9 asks the other question — at what point it stops deforming and fails." },
          ],
        },
      ],
    }

  );
})();
