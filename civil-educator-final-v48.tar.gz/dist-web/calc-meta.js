/* ============================================================
   CIVIL EDUCATOR — calculator presentation metadata
   An icon, a plain-language one-liner and search keywords for
   every calculator, so the list reads as a tool shelf rather
   than a wall of formulas.
   ============================================================ */

window.CALCMETA = {
  /* ---------------------------------------------------------- RCC */
  "concrete-qty": { icon: "🧱", desc: "Cement bags, sand and aggregate for a given volume of concrete",
    kw: "concrete cement bags sand aggregate mix m20 quantity volume dry" },
  "steel-weight": { icon: "⚖️", desc: "Weight of reinforcement from diameter, length and number of bars",
    kw: "steel weight bar kg per metre d2/162 rebar tonnage" },
  "dev-length": { icon: "📏", desc: "Anchorage length a bar needs to develop its full strength",
    kw: "development length ld anchorage bond tau bd embedment" },
  "lap-length": { icon: "🔗", desc: "Overlap for splicing bars in tension or compression",
    kw: "lap splice overlap tension compression 30d" },
  "bar-spacing": { icon: "📐", desc: "Convert between bar spacing and steel area per metre",
    kw: "spacing ast per metre c/c slab distribution area of steel" },
  "mu-lim": { icon: "🏗", desc: "Limiting moment a section can carry before it needs compression steel",
    kw: "mulim limiting moment xu max balanced singly doubly" },
  "ast-singly": { icon: "🧮", desc: "Tension steel required in a singly reinforced beam",
    kw: "ast area of steel singly reinforced beam flexure design moment" },
  "tauc-calc": { icon: "✂️", desc: "Shear stress against the concrete capacity — do you need stirrups?",
    kw: "shear tau v tau c stirrups table 19 diagonal tension" },
  "span-depth": { icon: "📉", desc: "Deflection check by the span to effective depth ratio",
    kw: "span depth ratio deflection 7 20 26 modification factor serviceability" },
  "slab-qty": { icon: "🟦", desc: "Concrete and steel estimate for a slab",
    kw: "slab quantity concrete steel estimate rcc" },
  "beam-qty": { icon: "▭", desc: "Concrete and steel estimate for beams",
    kw: "beam quantity concrete steel estimate rcc" },
  "column-qty": { icon: "🏛", desc: "Concrete volume for a group of columns",
    kw: "column quantity concrete volume rcc" },
  "footing-qty": { icon: "⬛", desc: "Concrete volume for isolated or sloped footings",
    kw: "footing foundation quantity concrete sloped isolated pedestal" },

  /* -------------------------------------------------- CONSTRUCTION */
  brickwork: { icon: "🧱", desc: "Bricks, cement and sand for a wall, with openings deducted",
    kw: "brickwork bricks wall mortar cement sand masonry opening" },
  plaster: { icon: "🪣", desc: "Cement and sand for plastering a given area",
    kw: "plaster mortar cement sand render 12mm wall ceiling" },
  excavation: { icon: "⛏", desc: "Excavation volume including bulking for disposal",
    kw: "excavation earthwork digging volume bulking pit trench" },
  backfill: { icon: "🔙", desc: "Backfill volume left after the foundation is built",
    kw: "backfill filling foundation shrinkage compaction" },
  earthwork: { icon: "🚜", desc: "Volume between cross sections by the prismoidal rule",
    kw: "earthwork prismoidal trapezoidal cross section cut fill road" },
  pcc: { icon: "◼️", desc: "Lean concrete bedding — volume and materials",
    kw: "pcc lean concrete bedding blinding 1:4:8 materials" },

  /* -------------------------------------------------------- BBS */
  "bbs-stirrup": { icon: "🔩", desc: "Cutting length of a rectangular stirrup with hooks and bends",
    kw: "stirrup cutting length hook bend deduction ring tie bbs" },
  "bbs-bar": { icon: "📏", desc: "Cutting length of a straight, L-shaped or cranked bar",
    kw: "bar cutting length crank l bar bend deduction bbs schedule" },
  "bbs-beam": { icon: "▬", desc: "Full bar bending schedule for a beam",
    kw: "beam bbs bar bending schedule top bottom stirrups anchorage" },
  "bbs-slab": { icon: "▦", desc: "Main and distribution steel schedule for a slab",
    kw: "slab bbs bar bending schedule main distribution spacing" },

  /* ---------------------------------------------------- SURVEYING */
  "area-offsets": { icon: "📊", desc: "Area from offsets by the trapezoidal or Simpson's rule",
    kw: "area offsets simpson trapezoidal chain survey irregular boundary" },
  "area-coords": { icon: "🗺", desc: "Area of a closed polygon from its corner coordinates",
    kw: "area coordinates shoelace polygon plot land boundary" },
  "distance-bearing": { icon: "🧭", desc: "Distance and whole-circle bearing between two points",
    kw: "distance bearing wcb coordinates easting northing traverse" },
  "level-hi": { icon: "📶", desc: "Reduced levels by the height of instrument method, with the check",
    kw: "levelling reduced level hi height of instrument bs fs benchmark" },
  slope: { icon: "📐", desc: "Slope as a ratio, a percentage and an angle",
    kw: "slope gradient angle percentage ratio 1 in n camber" },
  traverse: { icon: "🔺", desc: "Latitudes, departures and the closing error of a traverse",
    kw: "traverse latitude departure closing error bowditch closure" },

  /* --------------------------------------------------- CONVERSION */
  "conv-length": { icon: "📏", desc: "mm, cm, m, km, inch, foot, yard, mile",
    kw: "convert length mm cm m km inch foot feet yard mile" },
  "conv-area": { icon: "⬜", desc: "m², ft², acre, hectare, bigha and more",
    kw: "convert area sqm sqft acre hectare bigha guntha cent" },
  "conv-volume": { icon: "🧊", desc: "m³, litre, ft³, gallon",
    kw: "convert volume cubic metre litre cft gallon" },
  "conv-mass": { icon: "⚖️", desc: "kg, tonne, quintal, pound",
    kw: "convert mass weight kg tonne quintal pound lb" },
  "conv-force": { icon: "💪", desc: "N, kN, kgf, tonne-force",
    kw: "convert force newton kn kgf tonne ton" },
  "conv-stress": { icon: "🎚", desc: "N/mm², MPa, kN/m², kg/cm², psi",
    kw: "convert stress pressure mpa n/mm2 kpa kg/cm2 psi bar" },
};

/* The handful students reach for most often — shown first on the calculator page. */
window.CALCPOPULAR = ["concrete-qty", "steel-weight", "dev-length", "brickwork", "bbs-stirrup", "conv-stress"];
