/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   Chapter 11 — Curves
   Chapter 12 — Triangulation, Total Station and GNSS
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;

  hb.chapters.push(

    /* =========================================================== CH 11 */
    {
      id: "sv-11",
      n: 11,
      title: "Curves",
      hi: "वक्र",
      blurb: "Joining two straights so that a vehicle can actually take the corner — and pegging it out on the ground.",
      mins: 54,
      sections: [

        {
          n: "11.1",
          title: "Why a curve at all",
          hi: "वक्र क्यों",
          blocks: [
            { k: "p", t: "Two straight alignments meeting at an angle cannot simply meet — a vehicle cannot change direction instantaneously. A curve is inserted to make the change gradual, and the whole of this chapter is about choosing it and marking it on the ground." },
            { k: "list", items: [
              "<strong>Simple circular curve</strong> — a single arc of one radius joining the two straights. The basic case.",
              "<strong>Compound curve</strong> — two or more arcs of different radii, curving the same way. Used where terrain forbids a single radius.",
              "<strong>Reverse curve</strong> — two arcs curving in opposite directions, meeting at a common tangent point. Fine at low speeds, poor at high ones because the superelevation has to reverse through zero.",
              "<strong>Transition curve</strong> — a curve of gradually changing radius, inserted between a straight and a circular arc.",
              "<strong>Vertical curve</strong> — a parabola in the vertical plane, joining two gradients.",
            ]},
          ],
        },

        {
          n: "11.2",
          title: "The simple circular curve",
          hi: "सरल वृत्तीय वक्र",
          blocks: [
            { k: "dia", id: "hb-sv-curve", cap: "Six quantities, all of them from R and Δ alone." },
            { k: "p", t: "Two straights meet at the <strong>point of intersection (PI)</strong> with a deflection angle Δ between them. A circular arc of radius R is fitted, touching each straight at a tangent point. Everything else follows:" },
            { k: "eq", expr: "tangent length   T = R tan(Δ/2)          curve length   L = π R Δ / 180", where: [] },
            { k: "eq", expr: "long chord   LC = 2R sin(Δ/2)          apex distance   E = R[ sec(Δ/2) − 1 ]          mid-ordinate   M = R[ 1 − cos(Δ/2) ]", where: [] },
            { k: "def", term: "Degree of curve", t: "An alternative to quoting the radius: the angle subtended at the centre by a standard arc. On the 30 m arc definition used in India, D = 1718.9/R. A 5.73° curve is therefore a 300 m radius. Railway practice often uses it because it is easier to compare than a radius." },
            { k: "eg",
              title: "Example 11.1 — Setting out data for a simple curve",
              given: "Two straights deflect through Δ = 45°00'. A circular curve of R = 300 m is to be inserted. The chainage of the point of intersection is 1250.000 m.",
              steps: [
                { t: "Tangent length", w: "T = R tan(Δ/2) = 300 × tan22°30'\n  = 300 × 0.414214 = 124.264 m" },
                { t: "Curve length", w: "L = πRΔ/180 = π × 300 × 45/180 = 235.619 m" },
                { t: "Long chord, apex distance, mid-ordinate", w: "LC = 2R sin(Δ/2) = 600 × 0.382683 = 229.610 m\nE  = R[sec(Δ/2) − 1] = 300 × (1.082392 − 1) = 24.718 m\nM  = R[1 − cos(Δ/2)] = 300 × (1 − 0.923880) = 22.836 m" },
                { t: "Degree of curve (30 m arc)", w: "D = 1718.9/R = 1718.9/300 = 5.730°  =  5°44'" },
                { t: "Chainages — and this is where mistakes happen", w: "chainage of T₁ = chainage of PI − T = 1250.000 − 124.264 = 1125.736 m\nchainage of T₂ = chainage of T₁ + L = 1125.736 + 235.619 = 1361.355 m" },
              ],
              ans: "T = 124.264 m, L = 235.619 m; the curve runs from chainage 1125.736 to 1361.355.",
            },
            { k: "trap", t: "The chainage of the second tangent point is found by adding the <strong>curve length</strong>, not by going out to the PI and adding the tangent length back. Going round the arc is shorter than going out and back: 1250.000 + 124.264 = 1374.264 would be 12.9 m too far, and every peg beyond the curve would be wrong by that amount." },
          ],
        },

        {
          n: "11.3",
          title: "Setting it out",
          hi: "वक्र को ज़मीन पर उतारना",
          blocks: [
            { k: "dia", id: "an-sv-setout", cap: "Rankine's method: turn the total deflection angle from the tangent, and swing a chord from the last peg." },
            { k: "p", t: "Two families of method, and the choice depends on what instrument is available and whether the ground can be walked." },
            { k: "cmp", t: "Linear against angular methods.",
              cols: ["Linear methods (tape only)", "Angular — Rankine's deflection angles"],
              rows: [
                ["Instruments", "Tape and optical square; no theodolite", "Theodolite at T₁, plus a tape"],
                ["Typical method", "Offsets from the long chord, or from the tangent", "Deflection angle turned from the tangent, chord measured from the last peg"],
                ["Accuracy", "Modest — errors do not accumulate, but each point is independent and rough", "High"],
                ["Ground needed", "Must be able to tape across the curve area", "Only the chord between consecutive pegs"],
                ["Instrument moves?", "—", "<strong>No</strong> — one set-up does the whole curve"],
                ["Used for", "Short curves, minor roads, drains", "Roads and railways — the standard method"],
              ] },
            { k: "eq", expr: "Rankine's deflection angle for a chord C:   δ  =  1718.9 C / R   minutes", where: [] },
            { k: "p", t: "The angles <strong>accumulate</strong>: the theodolite is set to δ₁ for the first peg, δ₁+δ₂ for the second, and so on. The tape gives the chord from the previous peg, and the intersection of the ray and the chord is the peg position." },
            { k: "trap", t: "The final accumulated deflection angle must come to exactly <strong>Δ/2</strong>. That is not a coincidence and it is not optional — it is the arithmetic check that catches a slip in the table <em>before</em> anyone drives a peg. If the last angle is not Δ/2, the table is wrong, and no amount of careful fieldwork will fix it." },
            { k: "note", t: "The first and last chords are usually <em>sub-chords</em>, shorter than the rest, because the tangent point rarely falls on a round chainage. Their deflection angles are computed from the same formula with the sub-chord length. Getting this wrong is the second most common error in curve setting-out." },
            { k: "eg",
              title: "Example 11.2 — Rankine's table for the curve of Example 11.1",
              given: "R = 300 m, Δ = 45°, T₁ at chainage 1125.736 m, T₂ at 1361.355 m. Pegs at every 20 m of through chainage.",
              steps: [
                { t: "Chords", w: "first sub-chord: 1140.000 − 1125.736 = 14.264 m\nfull chords: 1140 to 1360 = 220 m = 11 × 20 m\nlast sub-chord: 1361.355 − 1360.000 = 1.355 m\ncheck: 14.264 + 220 + 1.355 = 235.619 = L  ✓" },
                { t: "Deflection angles δ = 1718.9 C/R minutes", w: "first:  1718.9 × 14.264/300 = 81.73′ = 1°21′44″\nfull:   1718.9 × 20/300     = 114.59′ = 1°54′36″\nlast:   1718.9 × 1.355/300  = 7.76′ = 0°07′46″" },
                { t: "Accumulate", w: "peg 1 (ch 1140): 1°21′44″\npeg 2 (ch 1160): 3°16′20″ … each full chord adds 1°54′36″\npeg 12 (ch 1360): 22°22′15″\nT₂ (ch 1361.355): 22°30′01″" },
                { t: "Check", w: "Δ/2 = 22°30′00″ — agreement to 1″ of rounding  ✓" },
              ],
              ans: "Set 1°21′44″ for the first peg, add 1°54′36″ for each 20 m peg, and the final reading at T₂ must be 22°30′. The 1″ difference is rounding; anything larger means a slip in the table.",
            },
          ],
        },

        {
          n: "11.4",
          title: "Transition curves and superelevation",
          hi: "संक्रमण वक्र और सुपरएलिवेशन",
          blocks: [
            { k: "p", t: "A vehicle moving from a straight onto a circular arc meets full centrifugal force instantly, because the radius changes from infinity to R at a point. At speed that is uncomfortable, hard on the track or road, and unsafe. A transition curve makes the change gradual by having a radius that decreases steadily from infinity to R." },
            { k: "list", items: [
              "<strong>Centrifugal force is introduced gradually</strong> rather than suddenly.",
              "<strong>Superelevation can be applied gradually</strong> along its length, instead of appearing at a point.",
              "<strong>Passenger comfort</strong>, and reduced wear on rails, tyres and the pavement edge.",
            ]},
            { k: "eq", expr: "equilibrium:   e + f = V² / (127 R)        IRC design superelevation (75% of V, no friction):   e = (0.75V)² / (127 R) = V² / (225 R)", where: [
              ["V", "design speed, km/h; R in m; e and f as ratios"],
              ["limits", "e ≤ 0.07 in plain and rolling terrain; f ≤ 0.15"],
            ]},
            { k: "p", t: "The IRC procedure, as set out in <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105101087/15-Ltexhtml/p9/p.html\" target=\"_blank\" rel=\"noopener\">NPTEL Transportation Engineering — superelevation design</a>: (1) compute e for 75% of the design speed with no friction; (2) if it exceeds 0.07, provide 0.07; (3) then check the friction needed at the full design speed, f = V²/(127R) − 0.07; (4) if that exceeds 0.15, the speed on the curve must be restricted to the value at which e = 0.07 and f = 0.15 together hold the vehicle, Va = √(0.22 × 127 R) km/h." },
            { k: "eq", expr: "length by rate of change of centrifugal acceleration:   L = v³ / (C R),   with  C = 80/(75 + V),  0.5 ≤ C ≤ 0.8", where: [
              ["v", "speed in m/s"],
            ]},
            { k: "eq", expr: "IRC empirical length:   L = 2.7 V² / R (plain, rolling);  1.0 V² / R (steep)          shift:   S = L² / (24 R)", where: [] },
            { k: "eg",
              title: "Example 11.3 — Transition curve for a highway",
              given: "Design speed 80 km/h, circular curve radius 500 m.",
              steps: [
                { t: "Superelevation — IRC step 1", w: "e = V²/(225R) = 80²/(225 × 500) = 6400/112,500 = 0.057  →  5.7%" },
                { t: "Steps 2–4", w: "0.057 < 0.07, so provide e = 5.7%; friction needed at full speed\nf = 80²/(127 × 500) − 0.057 = 0.101 − 0.057 = 0.044  <  0.15  ✓ — no speed restriction" },
                { t: "Length by rate of change of centrifugal acceleration", w: "v = 80/3.6 = 22.222 m/s\nC = 80/(75 + 80) = 80/155 = 0.516  (within the 0.5–0.8 range  ✓)\nL = v³/(CR) = 22.222³/(0.516 × 500)\n  = 10,973.9/258.1 = 42.52 m" },
                { t: "Length by the IRC empirical rule", w: "L = 2.7 V²/R = 2.7 × 6400/500 = 34.56 m" },
                { t: "Third criterion — rate of introducing superelevation", w: "L = e N (W + We)/2 with the pavement rotated about the centre line\nN = 150 (1 in 150, plain terrain), W + We ≈ 7.5 m (two-lane, with widening)\nL = 0.057 × 150 × 7.5/2 = 31.8 m\n(if rotated about the inner edge the /2 is dropped: 63.7 m — and that would govern)" },
                { t: "Adopt the largest", w: "42.52 m (rotation about the centre line)  →  provide L = 45 m" },
                { t: "Shift", w: "S = L²/(24R) = 45²/(24 × 500) = 2025/12,000 = 0.169 m" },
              ],
              ans: "Superelevation 5.7%, transition length 45 m, shift 0.169 m. The circular curve is shifted inwards by the shift, and the transition is inserted at each end.",
            },
            { k: "note", t: "<b>Correction (v35):</b> an earlier version computed e = V²/(127R) = 10.1% here, declared it over the 7% limit, and concluded that the speed must be reduced. That formula is the <em>no-friction equilibrium</em> value, not the IRC design value. IRC designs superelevation for 75% of the speed and lets friction carry the rest, giving 5.7% and a curve that is perfectly adequate at 80 km/h. The real lesson survives on a tighter curve: at R = 150 m, NPTEL's worked case gives e = 0.188 → capped at 0.07, f required 0.265 > 0.15, and the speed must be restricted to √(0.22 × 9.81 × 150) = 18.0 m/s ≈ 64 km/h." },
            { k: "note", t: "Transition-length criteria cross-checked with <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105101087/16-Ltexhtml/p4/p.html\" target=\"_blank\" rel=\"noopener\">NPTEL — transition curve length</a>: L₁ = v³/(cR) with c = 80/(75 + 3.6v), 0.5 ≤ c ≤ 0.8 (v in m/s — identical to the km/h form above); L₂ by rate of introducing superelevation; L₃ = 35v²/R in plain and rolling terrain (= 2.7V²/R) and 12.96v²/R in steep terrain (= 1.0V²/R); adopt the largest. Maximum superelevation 7% plain/rolling, 10% hill roads, 4% urban per <a href=\"https://engineeringhulk.com/civil/transportation/highway-geometric-design/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>." },
            { k: "p", t: "The <strong>ideal transition</strong> is the clothoid or spiral, in which the radius is inversely proportional to the length along the curve — exactly matching a steady rate of change of centrifugal acceleration. The cubic parabola is the traditional approximation, easy to set out by offsets, and adequate for the small deflections of road and rail practice." },
          ],
        },

        {
          n: "11.5",
          title: "Vertical curves, and what to carry forward",
          hi: "ऊर्ध्वाधर वक्र और सार",
          blocks: [
            { k: "p", t: "Where two gradients meet, a vertical curve smooths the change. A <strong>parabola</strong> is used rather than a circle, because a parabola gives a constant rate of change of grade and is far easier to compute — offsets from the tangent vary as the square of the distance." },
            { k: "list", items: [
              "<strong>Summit (crest) curve</strong> — the governing requirement is <em>sight distance</em>. The curve must be long enough for a driver to see far enough ahead to stop, or to overtake.",
              "<strong>Sag (valley) curve</strong> — the governing requirements are headlight sight distance at night, and passenger comfort under the increased apparent gravity.",
            ]},
            { k: "p", t: "The length follows from the algebraic difference in grades and the sight distance required, and IRC gives the design expressions. The sign convention that avoids confusion: an upgrade is positive, a downgrade negative, so a +3% meeting a −2% has an algebraic difference of 5%, and that 5% is what the curve has to absorb." },
            { k: "eq", expr: "RL at distance x from the beginning of the curve:   y = RL(BVC) + g₁x + (g₂ − g₁) x² / (2L)        highest/lowest point at  x = g₁L / (g₁ − g₂)", where: [
              ["g₁, g₂", "grades as ratios (+ up, − down)"],
              ["L", "length of the vertical curve, measured horizontally"],
            ]},
            { k: "eg",
              title: "Example 11.4 — RLs on a summit curve",
              given: "A +3% grade meets a −2% grade at a PVI of chainage 1500 m, RL 105.000 m. A 200 m parabolic vertical curve is used, symmetrical about the PVI.",
              steps: [
                { t: "Beginning of the curve", w: "BVC at chainage 1500 − 100 = 1400 m; RL = 105.000 − 0.03 × 100 = 102.000 m" },
                { t: "RLs at 40 m stations", w: "y = 102.000 + 0.03x − 0.05x²/400\nx = 0   → 102.000      x = 40  → 103.000\nx = 80  → 103.600      x = 120 → 103.800\nx = 160 → 103.600      x = 200 → 103.000" },
                { t: "Summit", w: "x = 0.03 × 200/0.05 = 120 m → chainage 1520 m, RL 103.800 m" },
                { t: "Check at the end", w: "EVC RL by the tangent: 105.000 − 0.02 × 100 = 103.000  ✓" },
              ],
              ans: "Summit at chainage 1520 m, RL 103.800 m — 1.2 m below the PVI. The high point is not at the PVI unless the two grades are equal and opposite.",
            },
            { k: "list", items: [
              "T = R tan(Δ/2), L = πRΔ/180, LC = 2R sin(Δ/2), E = R[sec(Δ/2) − 1], M = R[1 − cos(Δ/2)].",
              "Chainage of T₂ = chainage of T₁ + L. Never PI + T.",
              "D = 1718.9/R on the 30 m arc definition.",
              "Rankine: δ = 1718.9 C/R minutes, angles accumulate, and the last must equal Δ/2.",
              "First and last chords are sub-chords — compute their own deflection angles.",
              "IRC: e = V²/(225R) for 75% speed, ≤ 0.07; check f ≤ 0.15 at full speed or restrict speed. L = largest of v³/(cR), the superelevation-rate rule and 2.7V²/R. Shift = L²/24R.",
              "Vertical curve: y = RL(BVC) + g₁x + (g₂ − g₁)x²/2L; summit or sag at x = g₁L/(g₁ − g₂).",
              "Vertical curves are parabolas; summits are governed by sight distance, sags by headlights and comfort.",
            ]},
            { k: "p", t: "Chapter 12 closes the handbook with the control that everything else hangs from, and with the instruments that have replaced most of what the previous eleven chapters describe — while leaving all of their principles intact." },
          ],
        },
      ],
    },

    /* =========================================================== CH 12 */
    {
      id: "sv-12",
      n: 12,
      title: "Triangulation, Total Station and GNSS",
      hi: "त्रिभुजन, टोटल स्टेशन और GNSS",
      blurb: "The control that everything hangs from, and the instruments that changed how it is measured but not what it means.",
      mins: 46,
      sections: [

        {
          n: "12.1",
          title: "Triangulation",
          hi: "त्रिभुजन",
          blocks: [
            { k: "p", t: "Chapter 1 said to work from the whole to the part. Triangulation is that principle at national scale: a framework of triangles covering a whole country, in which <strong>angles</strong> are measured at every station and only one or two lengths — the base lines — are measured at all." },
            { k: "p", t: "The reason for that lopsided arrangement is historical and practical. Before EDM, an angle could be measured to a second with a good theodolite, while measuring a length of several kilometres to matching accuracy took weeks of extraordinary care. So you measured one base line beautifully and propagated it through the network by trigonometry." },
            { k: "list", items: [
              "<strong>Base line</strong> — measured with invar tapes under controlled tension and temperature, to perhaps 1 in a million. Everything in the network scales from it.",
              "<strong>Well-conditioned triangles</strong> — the same rule as Chapter 3, and for the same reason: no angle below about 30°. An equilateral triangle is ideal, because the computed sides are then least sensitive to angular error.",
              "<strong>Base net</strong> — the short base line is expanded to the length of the main triangulation sides through a chain of carefully conditioned figures.",
              "<strong>Satellite station</strong> — where a station cannot physically be occupied (a church spire, a tower), observations are made from an eccentric station nearby and reduced to the true centre.",
              "<strong>Signals and towers</strong> — targets, sometimes on built towers, so that distant stations are intervisible.",
            ]},
            { k: "eg",
              title: "Example 12.1 — Carrying a base through a triangle",
              given: "Base AB = 1200.000 m measured. Corrected angles: at A 58°20′, at B 63°10′.",
              steps: [
                { t: "Third angle", w: "C = 180° − 58°20′ − 63°10′ = 58°30′" },
                { t: "Sine rule", w: "AC = AB sin B/sin C = 1200 × 0.892323/0.852640 = 1255.85 m\nBC = AB sin A/sin C = 1200 × 0.851117/0.852640 = 1197.86 m" },
                { t: "Sensitivity", w: "a 10″ error in C changes AC by AC × cot C × 10″/206265\n= 1255.85 × 0.6128 × 4.85×10⁻⁵ = 0.037 m  (1 in 34,000)" },
              ],
              ans: "AC = 1255.85 m, BC = 1197.86 m. With angles near 60° the side errors stay small; as an angle approaches 0° or 180° its cotangent grows without limit — the reason for the 30° rule.",
            },
            { k: "def", term: "Trilateration", t: "The mirror image: measure all the <em>sides</em> and compute the angles. Impractical before EDM and straightforward after it. Modern control networks are usually <strong>triangulateration</strong> — both angles and distances measured, with the redundancy adjusted by least squares." },
            { k: "real", t: "The Great Trigonometrical Survey of India, begun in 1802, is the monument to this method — a chain of triangles from the southern tip to the Himalaya, and it is what gave the world the height of Everest. The base lines were measured with compensation bars, and the whole subcontinent's mapping hung on them." },
          ],
        },

        {
          n: "12.2",
          title: "EDM and the total station",
          hi: "EDM और टोटल स्टेशन",
          blocks: [
            { k: "p", t: "Electromagnetic distance measurement times a modulated light or microwave signal travelling to a reflector and back. Since the speed of light is known, the travel time gives the distance — and it does so in seconds, to a few millimetres, over kilometres." },
            { k: "eq", expr: "D = (c / 2n) × t", where: [
              ["c", "speed of light in vacuum"],
              ["n", "refractive index of the air on the day — which is why temperature and pressure are entered into the instrument"],
              ["t", "measured two-way travel time"],
            ]},
            { k: "p", t: "That refractive index term is the one field consideration. Air density changes the speed of light enough to matter at these precisions, so a total station asks for temperature and pressure and applies the correction itself. Entering the defaults on a hot day costs a few parts per million — small, but systematic, and Chapter 2 had something to say about those." },
            { k: "def", term: "Total station", t: "A theodolite, an EDM and a computer in one instrument. It measures the horizontal angle, the vertical angle and the slope distance to a prism, and computes the horizontal distance, the height difference and the coordinates on the spot — storing them, and able to set out from them in reverse." },
            { k: "p", t: "Notice what it has <em>not</em> changed. It measures a distance and an angle from a known point: that is the polar fix, the third pattern in §1.3, exactly as it was with a chain and a theodolite. <strong>The geometry of Chapter 1 is untouched; only the speed and the precision have moved.</strong>" },
            { k: "list", items: [
              "<strong>Reflectorless</strong> measurement to a surface, for façades and inaccessible points.",
              "<strong>Robotic</strong> instruments that track the prism, so one person can survey alone.",
              "<strong>Data flows straight to CAD</strong>, eliminating booking and plotting blunders entirely — which removes Chapter 2's mistakes, though not its systematic errors.",
            ]},
            { k: "eg",
              title: "Example 12.2 — Reducing a total station observation",
              given: "Slope distance 245.632 m, vertical angle +3°12′20″, instrument height 1.520 m, prism height 1.800 m. RL of the station 100.000 m.",
              steps: [
                { t: "Horizontal distance", w: "H = S cos v = 245.632 × cos 3°12′20″ = 245.248 m" },
                { t: "Height difference to the prism", w: "V = S sin v = 245.632 × 0.055918 = 13.735 m" },
                { t: "Ground to ground", w: "ΔH = V + hi − ht = 13.735 + 1.520 − 1.800 = 13.455 m" },
                { t: "Curvature and refraction (Chapter 6)", w: "0.0673 × 0.245² = 0.004 m — add for a sight this long" },
              ],
              ans: "Horizontal distance 245.248 m; RL of the target point 100.000 + 13.455 + 0.004 = 113.459 m. The instrument does exactly this arithmetic — and gets it wrong in exactly the same way if the prism height is mis-entered.",
            },
          ],
        },

        {
          n: "12.3",
          title: "GNSS",
          hi: "GNSS",
          blocks: [
            { k: "dia", id: "hb-sv-gnss", cap: "Resection again — but the known points are 20,000 km up and moving." },
            { k: "p", t: "A satellite broadcasts its position and the exact time the signal left it. The receiver notes the time it arrived, and the difference times the speed of light is the range to that satellite. Three ranges would fix a position in three dimensions." },
            { k: "p", t: "But the receiver's own clock is a cheap quartz oscillator, not an atomic standard, and an error of a microsecond is 300 m of range. So the clock error is a <strong>fourth unknown</strong>, and a fourth satellite provides the fourth equation. That is the whole reason four satellites are needed rather than three, and it is why a GNSS receiver is really solving for position <em>and time</em> simultaneously." },
            { k: "list", items: [
              "<strong>GPS</strong> (United States), <strong>GLONASS</strong> (Russia), <strong>Galileo</strong> (Europe), <strong>BeiDou</strong> (China), and <strong>NavIC/IRNSS</strong> (India, regional). GNSS is the collective term.",
              "<strong>Errors</strong> — satellite clock and orbit, ionospheric and tropospheric delay, multipath from reflective surfaces, and receiver noise.",
              "<strong>DOP (dilution of precision)</strong> — the geometry factor. Satellites bunched in one part of the sky give a poor fix however good the ranging, which is precisely the danger-circle lesson from §5.4 in another costume.",
              "<strong>DGPS</strong> — a second receiver on a known point computes the current errors and broadcasts corrections, since nearby receivers share most of them.",
              "<strong>RTK</strong> — real-time kinematic, using the carrier phase rather than the code, giving centimetre accuracy live. This is what site setting-out uses today.",
            ]},
            { k: "trap", t: "GNSS gives <strong>ellipsoidal</strong> height, measured from a mathematical ellipsoid. Levelling gives <strong>orthometric</strong> height, measured from the geoid — the surface gravity actually defines, which is what water flows along. The two differ by the geoid–ellipsoid separation, tens of metres in India and varying across the country. Using a GNSS height as a reduced level without applying a geoid model is a serious error, and it is one that drainage designs have been built on." },
            { k: "eq", expr: "orthometric height  H = h − N", where: [
              ["h", "ellipsoidal height from GNSS"],
              ["N", "geoid undulation (geoid height above the ellipsoid) from a geoid model; negative where the geoid lies below the ellipsoid"],
            ]},
            { k: "eg",
              title: "Example 12.3 — From GNSS height to reduced level",
              given: "An RTK rover gives an ellipsoidal height h = 32.415 m at a site where the geoid model gives N = −68.20 m (illustrative value).",
              steps: [
                { t: "Apply the separation", w: "H = h − N = 32.415 − (−68.20) = 100.615 m" },
              ],
              ans: "RL ≈ 100.62 m. Booking 32.415 as the RL would put the whole site 68 m too low. Over short distances N changes slowly, so height differences from GNSS are far better than absolute heights.",
            },
            { k: "note", t: "Even a good geoid model should be checked against a local benchmark: the Indian vertical datum issues noted in Chapter 6 (<a href=\"https://www.fig.net/resources/proceedings/fig_proceedings/fig2018/papers/ts06e/TS06E_singh_9497.pdf\" target=\"_blank\" rel=\"noopener\">FIG 2018</a>) mean that GNSS-derived levels and old levelled benchmarks may disagree by more than the job can tolerate." },
          ],
        },

        {
          n: "12.4",
          title: "Field astronomy, in one section",
          hi: "क्षेत्र खगोलशास्त्र",
          blocks: [
            { k: "p", t: "Before GNSS, the only way to get a <em>true</em> bearing — as opposed to a magnetic or an assumed one — was to observe a celestial body. The sun or a star is observed with a theodolite, the time is noted, and the azimuth of a line is computed from the astronomical triangle relating the pole, the zenith and the body." },
            { k: "list", items: [
              "<strong>Azimuth determination</strong> — the practical purpose. A long traverse accumulates angular error, and an astronomical azimuth observed at intervals cuts it off.",
              "<strong>Latitude and longitude</strong> — determinable from altitude observations and accurate time, and this is how position was fixed before satellites.",
              "<strong>Polaris</strong> — convenient in the northern hemisphere because it sits close to the celestial pole and moves very little.",
            ]},
            { k: "p", t: "It has been almost entirely replaced by GNSS, which gives azimuth and position faster and better. It remains worth knowing for two reasons: it is still the independent check on a GNSS-derived orientation, and the geometry of the astronomical triangle is the geometry the whole coordinate system rests on." },
          ],
        },

        {
          n: "12.5",
          title: "Closing the loop",
          hi: "पूरा चक्र",
          blocks: [
            { k: "p", t: "Twelve chapters back this handbook began with two principles: work from the whole to the part, and fix a point by at least two independent measurements with a third as a check. It is worth seeing how completely they survived." },
            { k: "list", items: [
              "<strong>Whole to part</strong> — triangulation across a country, a traverse across a site, a grid across a building. The scale changes and the principle does not.",
              "<strong>Two measurements and a check</strong> — the check line in a chain survey, the 180° test for local attraction, the closed level circuit, the traverse closing error, the final deflection angle equalling Δ/2, the redundant fifth satellite. Every chapter has one.",
              "<strong>Errors</strong> — Chapter 2's three kinds turn up in every chapter since. Tape corrections and curvature are systematic errors computed away; balanced sights and two-face observations are systematic errors cancelled by technique; averaging and least squares handle the random ones; and checks catch the blunders.",
            ]},
            { k: "p", t: "A total station and a GNSS rover have changed how fast and how well a measurement can be made. They have not changed what a measurement <em>is</em>, what can go wrong with it, or the obligation to prove it. <strong>A survey you cannot check is still a survey you cannot defend</strong> — and that sentence is as true of a point cloud with a million points as it was of a chain and two ranging rods." },
            { k: "note", t: "Values and methods here are set out for learning. Before using any of them on work that will be built or registered, confirm against the governing standard — IS 1492 for chains, IS 2932 for staves, the IRC codes for road geometry, and Survey of India practice for control and datum. And close your circuits." },
          ],
        },
      ],
    }

  );
})();
