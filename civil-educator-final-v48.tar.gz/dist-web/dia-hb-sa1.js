/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for the Structural Analysis handbook,
   Chapter 1.
   ------------------------------------------------------------
   Same conventions as diagrams.js: strokes are currentColor so
   both themes work, meaning-carrying strokes use .hi (marker) or
   .ac (accent), and every figure gets its own marker id prefix so
   two figures on one page never collide.

   Drawn for this app. A figure here has to do work the prose
   cannot — show a mechanism, a shape, a comparison. Decoration
   is left out on purpose.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hbmk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}
/* hatched ground under a support */
function grd(x, y, w) {
  let s = `<line class="s" x1="${x}" y1="${y}" x2="${x + w}" y2="${y}"/>`;
  for (let i = 0; i < w; i += 9) s += `<line class="thin" x1="${x + i}" y1="${y}" x2="${x + i - 7}" y2="${y + 8}"/>`;
  return s;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 1.1  ANALYSIS vs DESIGN */
  "hb-sa-scope": {
    label: "Where analysis ends and design begins",
    svg: `<svg viewBox="0 0 672 258" role="img" aria-label="Flow chart: geometry and loads feed into analysis, which produces forces and displacements, which then feed into design against IS 456 or IS 800 to give section and reinforcement">
      ${hbmk("sc")}
      <rect class="conc" x="14" y="86" width="126" height="76" rx="8"/>
      <text x="77" y="112" text-anchor="middle">Geometry</text>
      <text x="77" y="132" text-anchor="middle">Loads</text>
      <text class="lb" x="77" y="150" text-anchor="middle">IS 875, IS 1893</text>

      <line class="ac" x1="146" y1="124" x2="196" y2="124" marker-end="url(#sc-c)"/>

      <rect class="soft-b" x="202" y="72" width="150" height="104" rx="8"/>
      <text class="em" x="277" y="98" text-anchor="middle">ANALYSIS</text>
      <text class="lb" x="277" y="120" text-anchor="middle">equilibrium</text>
      <text class="lb" x="277" y="138" text-anchor="middle">compatibility</text>
      <text class="lb" x="277" y="156" text-anchor="middle">energy</text>

      <line class="ac" x1="358" y1="124" x2="408" y2="124" marker-end="url(#sc-c)"/>

      <rect class="conc" x="414" y="40" width="212" height="72" rx="8"/>
      <text x="520" y="64" text-anchor="middle">Forces</text>
      <text class="lb" x="520" y="84" text-anchor="middle">reaction · SF · BM · axial</text>
      <text class="lb" x="520" y="102" text-anchor="middle">this is the analysis output</text>

      <rect class="conc" x="414" y="136" width="212" height="72" rx="8"/>
      <text x="520" y="160" text-anchor="middle">Displacements</text>
      <text class="lb" x="520" y="180" text-anchor="middle">deflection · rotation</text>
      <text class="lb" x="520" y="198" text-anchor="middle">serviceability check</text>

      <line class="thin dash" x1="520" y1="112" x2="520" y2="136"/>

      <line class="hi" x1="520" y1="228" x2="520" y2="216" marker-start="url(#sc-m)"/>
      <text class="em" x="520" y="242" text-anchor="middle">DESIGN takes over here — IS 456 / IS 800</text>
    </svg>`,
    caption: "Analysis answers <strong>how much force and how much movement</strong>. Only after that answer exists does a design code have anything to say. No IS code will ever tell you the bending moment in your beam — it tells you what section can carry the one you calculated.",
  },

  /* ---------------------------------------- 1.3  IDEALISATION */
  "hb-sa-ideal": {
    label: "Real frame reduced to a line diagram",
    svg: `<svg viewBox="0 0 640 260" role="img" aria-label="Left, a real concrete frame with finite member widths and a monolithic haunched joint. Right, the same frame as a line diagram with members on centre lines and a rigid joint marked">
      ${hbmk("id")}
      <text class="lb" x="150" y="22" text-anchor="middle">REAL</text>
      <text class="lb" x="480" y="22" text-anchor="middle">IDEALISED</text>
      <line class="gl" x1="315" y1="16" x2="315" y2="246"/>

      <rect class="conc" x="52" y="46" width="30" height="170"/>
      <rect class="conc" x="228" y="46" width="30" height="170"/>
      <rect class="conc" x="52" y="46" width="206" height="26"/>
      <path class="conc" d="M82 72 L112 72 L82 102 Z"/>
      <path class="conc" d="M228 72 L198 72 L228 102 Z"/>
      ${grd(40, 216, 54)}
      ${grd(216, 216, 54)}
      <text class="lb" x="97" y="122">haunch</text>
      <text class="lb" x="155" y="240" text-anchor="middle">finite widths, monolithic corners</text>

      <line class="s" x1="382" y1="59" x2="382" y2="216"/>
      <line class="s" x1="578" y1="59" x2="578" y2="216"/>
      <line class="s" x1="382" y1="59" x2="578" y2="59"/>
      <circle class="acf" cx="382" cy="59" r="5"/>
      <circle class="acf" cx="578" cy="59" r="5"/>
      ${grd(368, 216, 28)}
      ${grd(564, 216, 28)}
      <text class="ea" x="382" y="46" text-anchor="middle">rigid joint</text>
      <text class="ea" x="578" y="46" text-anchor="middle">rigid joint</text>
      <line class="thin" x1="382" y1="230" x2="578" y2="230" marker-start="url(#id-a)" marker-end="url(#id-a)"/>
      <text class="lb" x="480" y="248" text-anchor="middle">L measured centre to centre</text>
    </svg>`,
    caption: "Idealisation is where the analysis is really decided. Members become their centre lines, a monolithic corner becomes a <strong>rigid joint</strong> that carries moment, and the haunch disappears. Every one of those is a deliberate simplification — and each one you cannot name is a place your answer can be wrong.",
  },

  /* ---------------------------------------- 1.5  SIGN CONVENTION */
  "hb-sa-sign": {
    label: "Sign convention for axes, shear force and bending moment",
    svg: `<svg viewBox="0 0 672 230" role="img" aria-label="Positive directions: x to the right, y upward, clockwise rotation positive; positive shear is the pair that rotates the element clockwise; positive bending moment sags the element">
      ${hbmk("sg")}
      <text class="lb" x="76" y="24" text-anchor="middle">AXES</text>
      <line class="ac" x1="40" y1="130" x2="128" y2="130" marker-end="url(#sg-c)"/>
      <line class="ac" x1="40" y1="130" x2="40" y2="56" marker-end="url(#sg-c)"/>
      <text class="ea" x="134" y="134">+x</text>
      <text class="ea" x="34" y="50" text-anchor="end">+y</text>
      <path class="hi" d="M62 168 A22 22 0 1 1 84 190" marker-end="url(#sg-m)"/>
      <text class="em" x="96" y="184">+θ</text>
      <text class="lb" x="76" y="212" text-anchor="middle">clockwise positive</text>

      <line class="gl" x1="212" y1="16" x2="212" y2="214"/>
      <text class="lb" x="340" y="24" text-anchor="middle">POSITIVE SHEAR</text>
      <rect class="conc" x="288" y="88" width="104" height="58"/>
      <line class="hi" x1="278" y1="146" x2="278" y2="82" marker-end="url(#sg-m)"/>
      <line class="hi" x1="402" y1="88" x2="402" y2="152" marker-end="url(#sg-m)"/>
      <text class="em" x="340" y="122" text-anchor="middle">⊕</text>
      <text class="lb" x="340" y="180" text-anchor="middle">left face up, right face down</text>
      <text class="lb" x="340" y="198" text-anchor="middle">— element tends to rotate clockwise</text>

      <line class="gl" x1="468" y1="16" x2="468" y2="214"/>
      <text class="lb" x="556" y="24" text-anchor="middle">POSITIVE MOMENT</text>
      <path class="s" d="M500 118 Q556 152 612 118"/>
      <path class="hi" d="M500 104 A30 30 0 0 1 516 96" marker-start="url(#sg-m)"/>
      <path class="hi" d="M612 104 A30 30 0 0 0 596 96" marker-start="url(#sg-m)"/>
      <text class="em" x="556" y="112" text-anchor="middle">⊕</text>
      <text class="lb" x="556" y="180" text-anchor="middle">sagging — tension at the bottom</text>
      <text class="lb" x="556" y="198" text-anchor="middle">the fibre that needs steel</text>
    </svg>`,
    caption: "Pick one convention and never change it inside a problem. The sagging-positive rule is the useful one to internalise, because <strong>positive moment means tension at the bottom</strong>, and tension is where the reinforcement goes.",
  },

  /* ---------------------------------------- 1.6  SUPPORTS */
  "hb-sa-supports": {
    label: "Support types, what each restrains and the reactions produced",
    svg: `<svg viewBox="0 0 640 400" role="img" aria-label="Four supports drawn in a row: roller with one vertical reaction, hinge with two reactions, fixed with two forces and a moment, and guided roller with one force and a moment">
      ${hbmk("sp")}

      <text class="lb" x="80" y="24" text-anchor="middle">ROLLER</text>
      <line class="s" x1="30" y1="76" x2="130" y2="76"/>
      <circle class="s" cx="66" cy="88" r="11"/>
      <circle class="s" cx="96" cy="88" r="11"/>
      ${grd(26, 100, 108)}
      <line class="hi" x1="80" y1="152" x2="80" y2="104" marker-end="url(#sp-m)"/>
      <text class="em" x="80" y="172" text-anchor="middle">1 reaction</text>
      <text class="lb" x="80" y="192" text-anchor="middle">stops y only</text>
      <text class="lb" x="80" y="210" text-anchor="middle">free to slide + rotate</text>

      <text class="lb" x="240" y="24" text-anchor="middle">HINGE / PIN</text>
      <path class="s" d="M240 72 L214 104 L266 104 Z"/>
      <circle class="acf" cx="240" cy="72" r="4"/>
      ${grd(200, 104, 80)}
      <line class="hi" x1="240" y1="152" x2="240" y2="110" marker-end="url(#sp-m)"/>
      <line class="hi" x1="186" y1="130" x2="228" y2="130" marker-end="url(#sp-m)"/>
      <text class="em" x="240" y="172" text-anchor="middle">2 reactions</text>
      <text class="lb" x="240" y="192" text-anchor="middle">stops x and y</text>
      <text class="lb" x="240" y="210" text-anchor="middle">still free to rotate</text>

      <text class="lb" x="410" y="24" text-anchor="middle">FIXED</text>
      <line class="s" x1="410" y1="72" x2="470" y2="72"/>
      <line class="s" x1="410" y1="46" x2="410" y2="100"/>
      ${grd(382, 100, 30)}
      <line class="hi" x1="410" y1="150" x2="410" y2="108" marker-end="url(#sp-m)"/>
      <line class="hi" x1="356" y1="128" x2="398" y2="128" marker-end="url(#sp-m)"/>
      <path class="hi" d="M436 128 A20 20 0 1 1 452 144" marker-end="url(#sp-m)"/>
      <text class="em" x="410" y="172" text-anchor="middle">3 reactions</text>
      <text class="lb" x="410" y="192" text-anchor="middle">stops x, y and rotation</text>
      <text class="lb" x="410" y="210" text-anchor="middle">nothing is free</text>

      <text class="lb" x="566" y="24" text-anchor="middle">GUIDED ROLLER</text>
      <line class="s" x1="524" y1="72" x2="608" y2="72"/>
      <rect class="conc" x="546" y="76" width="40" height="18"/>
      <circle class="s" cx="556" cy="102" r="8"/>
      <circle class="s" cx="576" cy="102" r="8"/>
      ${grd(528, 112, 76)}
      <line class="hi" x1="566" y1="158" x2="566" y2="120" marker-end="url(#sp-m)"/>
      <path class="hi" d="M596 136 A20 20 0 1 1 612 152" marker-end="url(#sp-m)"/>
      <text class="em" x="566" y="176" text-anchor="middle">2 reactions</text>
      <text class="lb" x="566" y="196" text-anchor="middle">stops y and rotation</text>
      <text class="lb" x="566" y="214" text-anchor="middle">slides along x</text>

      <line class="gl" x1="20" y1="244" x2="620" y2="244"/>
      <text class="em" x="320" y="276" text-anchor="middle">The rule behind all four</text>
      <text x="320" y="306" text-anchor="middle">Stop a movement → get a reaction along it.</text>
      <text x="320" y="330" text-anchor="middle">Stop rotation → get a moment as well.</text>
      <text class="lb" x="320" y="360" text-anchor="middle">Do not memorise the pictures. Ask what the point can still do.</text>
      <text class="lb" x="320" y="382" text-anchor="middle">Whatever it can still do carries no reaction.</text>
    </svg>`,
    caption: "Every support in the list follows from one sentence: <strong>a reaction exists only where a movement is prevented.</strong> An inclined roller follows it too — its reaction is normal to the surface it rolls on, not vertical.",
  },

  /* ---------------------------------------- 1.10 INSTABILITY */
  "hb-sa-stability": {
    label: "Two unstable arrangements that pass the reaction count",
    svg: `<svg viewBox="0 0 640 280" role="img" aria-label="Left, a beam on three parallel vertical rollers slides sideways under horizontal load. Right, a frame whose three reaction lines meet at one point rotates about that point.">
      ${hbmk("st")}
      <text class="lb" x="160" y="24" text-anchor="middle">THREE PARALLEL REACTIONS</text>
      <line class="s" x1="40" y1="90" x2="292" y2="90"/>
      <circle class="s" cx="60" cy="102" r="10"/><circle class="s" cx="166" cy="102" r="10"/><circle class="s" cx="272" cy="102" r="10"/>
      ${grd(40, 114, 40)} ${grd(146, 114, 40)} ${grd(252, 114, 40)}
      <line class="hi" x1="60" y1="150" x2="60" y2="118" marker-end="url(#st-m)"/>
      <line class="hi" x1="166" y1="150" x2="166" y2="118" marker-end="url(#st-m)"/>
      <line class="hi" x1="272" y1="150" x2="272" y2="118" marker-end="url(#st-m)"/>
      <line class="ac" x1="20" y1="70" x2="86" y2="70" marker-end="url(#st-c)"/>
      <text class="ea" x="96" y="74">H</text>
      <path class="dash" d="M40 82 L332 82"/>
      <text class="lb" x="160" y="178" text-anchor="middle">r = 3, and ΣFx = 0 can never be satisfied</text>
      <text class="em" x="160" y="200" text-anchor="middle">the beam simply slides →</text>

      <line class="gl" x1="330" y1="16" x2="330" y2="268"/>

      <text class="lb" x="486" y="24" text-anchor="middle">THREE CONCURRENT REACTIONS</text>
      <line class="s" x1="384" y1="150" x2="588" y2="150"/>
      <line class="s" x1="384" y1="150" x2="384" y2="98"/>
      <line class="s" x1="588" y1="150" x2="588" y2="98"/>
      <path class="s" d="M384 98 L370 78 L398 78 Z"/>
      <path class="s" d="M588 98 L574 78 L602 78 Z"/>
      ${grd(362, 78, 44)} ${grd(566, 78, 44)}
      <circle class="acf" cx="486" cy="60" r="5"/>
      <text class="ea" x="486" y="48" text-anchor="middle">O</text>
      <line class="thin dash" x1="384" y1="98" x2="486" y2="60"/>
      <line class="thin dash" x1="588" y1="98" x2="486" y2="60"/>
      <line class="thin dash" x1="486" y1="150" x2="486" y2="60"/>
      <path class="hi" d="M520 78 A44 44 0 0 1 512 116" marker-end="url(#st-m)"/>
      <text class="lb" x="486" y="196" text-anchor="middle">every reaction line passes through O</text>
      <text class="em" x="486" y="218" text-anchor="middle">so ΣM about O can never be satisfied</text>

      <text class="lb" x="320" y="256" text-anchor="middle">Both arrangements have exactly the right number of reactions.</text>
      <text class="lb" x="320" y="274" text-anchor="middle">Counting says determinate. Reality says mechanism.</text>
    </svg>`,
    caption: "This is why determinacy is a <strong>necessary condition and never a sufficient one</strong>. After every count, sketch the reaction directions and ask two questions: are they all parallel, and do they all pass through one point?",
  },

  /* ---------------------------------------- 1.11 COUNTING Ds */
  "hb-sa-ds": {
    label: "Counting static indeterminacy on a portal frame",
    svg: `<svg viewBox="0 0 676 290" role="img" aria-label="A single bay portal frame with fixed bases, members and joints labelled, showing the count of members, joints and reactions used in the indeterminacy formula">
      ${hbmk("ds")}
      <line class="s" x1="140" y1="72" x2="340" y2="72"/>
      <line class="s" x1="140" y1="72" x2="140" y2="212"/>
      <line class="s" x1="340" y1="72" x2="340" y2="212"/>
      <line class="s" x1="118" y1="212" x2="162" y2="212"/>
      <line class="s" x1="318" y1="212" x2="362" y2="212"/>
      ${grd(112, 212, 56)} ${grd(312, 212, 56)}

      <circle class="acf" cx="140" cy="72" r="5"/><circle class="acf" cx="340" cy="72" r="5"/>
      <circle class="acf" cx="140" cy="212" r="5"/><circle class="acf" cx="340" cy="212" r="5"/>
      <text class="ea" x="130" y="64" text-anchor="end">B</text>
      <text class="ea" x="350" y="64">C</text>
      <text class="ea" x="130" y="228" text-anchor="end">A</text>
      <text class="ea" x="350" y="228">D</text>
      <text class="em" x="240" y="62" text-anchor="middle">member 2</text>
      <text class="em" x="128" y="146" text-anchor="end">member 1</text>
      <text class="em" x="352" y="146">member 3</text>

      <line class="hi" x1="140" y1="256" x2="140" y2="222" marker-end="url(#ds-m)"/>
      <line class="hi" x1="96" y1="238" x2="130" y2="238" marker-end="url(#ds-m)"/>
      <path class="hi" d="M162 238 A16 16 0 1 1 174 250" marker-end="url(#ds-m)"/>
      <line class="hi" x1="340" y1="256" x2="340" y2="222" marker-end="url(#ds-m)"/>
      <line class="hi" x1="296" y1="238" x2="330" y2="238" marker-end="url(#ds-m)"/>
      <path class="hi" d="M362 238 A16 16 0 1 1 374 250" marker-end="url(#ds-m)"/>
      <text class="lb" x="240" y="278" text-anchor="middle">3 reactions at each fixed base → r = 6</text>

      <line class="gl" x1="404" y1="40" x2="404" y2="264"/>
      <text class="em" x="420" y="72">m = 3   j = 4   r = 6   rr = 0</text>
      <text x="420" y="106">Ds = 3m + r − 3j − rr</text>
      <text x="420" y="132">   = 3(3) + 6 − 3(4) − 0</text>
      <text x="420" y="158">   = 9 + 6 − 12</text>
      <text class="em" x="420" y="186">   = 3</text>
      <text class="lb" x="420" y="216">Cross-check, the other route:</text>
      <text class="lb" x="420" y="236">Dse = r − 3 = 3,  Dsi = 0</text>
      <text class="lb" x="420" y="256">(open at the bottom — no closed box)</text>
    </svg>`,
    caption: "Both routes must give the same number. When they disagree the error is almost always in the joint count — <strong>every support point is a joint</strong>, and an internal hinge joining n members releases n − 1 moments, not one.",
  },

  /* ---------------------------------------- 1.12 COUNTING Dk */
  "hb-sa-dk": {
    label: "Degrees of freedom of the same portal",
    svg: `<svg viewBox="0 0 672 290" role="img" aria-label="The same portal frame, with the two joint rotations and the single sway displacement marked as the three remaining degrees of freedom once axial deformation is neglected">
      ${hbmk("dk")}
      <path class="dash" d="M140 72 L340 72 M140 72 L140 212 M340 72 L340 212"/>
      <path class="s" d="M176 66 L376 66 M140 212 Q150 140 176 66 M340 212 Q350 140 376 66"/>
      ${grd(112, 212, 56)} ${grd(312, 212, 56)}
      <circle class="acf" cx="176" cy="66" r="5"/><circle class="acf" cx="376" cy="66" r="5"/>

      <line class="hi" x1="140" y1="42" x2="182" y2="42" marker-end="url(#dk-m)"/>
      <text class="em" x="196" y="46">Δ  sway</text>
      <path class="hi" d="M158 92 A26 26 0 0 1 182 104" marker-end="url(#dk-m)"/>
      <text class="em" x="190" y="112">θB</text>
      <path class="hi" d="M358 92 A26 26 0 0 1 382 104" marker-end="url(#dk-m)"/>
      <text class="em" x="390" y="112">θC</text>
      <text class="lb" x="240" y="248" text-anchor="middle">bases fixed — no rotation, no movement there</text>

      <line class="gl" x1="430" y1="40" x2="430" y2="264"/>
      <text x="446" y="72">Dk = 3j − r</text>
      <text x="446" y="98">   = 3(4) − 6 = 6</text>
      <text class="lb" x="446" y="130">neglect axial deformation</text>
      <text class="lb" x="446" y="150">of all 3 members:</text>
      <text x="446" y="180">   6 − 3 = 3</text>
      <text class="em" x="446" y="212">θB ,  θC ,  Δ</text>
      <text class="lb" x="446" y="242">exactly the three unknowns</text>
      <text class="lb" x="446" y="260">slope-deflection will solve for</text>
    </svg>`,
    caption: "Ds and Dk are the two halves of the same picture. <strong>Ds = 3 says the force method needs three compatibility equations; Dk = 3 says the displacement method needs three unknowns.</strong> On this frame they happen to be equal — usually they are not, and the smaller one tells you which method is shorter.",
  },

  /* ---------------------------------------- 1.13 ELASTIC CURVE */
  "hb-sa-elastic": {
    label: "Elastic curve of a two-span continuous beam, with points of contraflexure",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="Top, the deflected shape of a two span continuous beam sagging in both spans and hogging over the middle support. Below, the matching bending moment diagram, with the points of contraflexure aligned with the zeros of the moment">
      ${hbmk("ec")}
      <text class="lb" x="320" y="20" text-anchor="middle">ELASTIC CURVE (deflected shape)</text>
      <path class="dash" d="M60 66 L580 66"/>
      <path class="hi" d="M60 66 Q170 124 250 76 Q320 40 390 76 Q470 124 580 66"/>
      <path class="s" d="M60 66 L48 84 L72 84 Z"/>
      <circle class="s" cx="54" cy="90" r="5"/><circle class="s" cx="66" cy="90" r="5"/>
      <path class="s" d="M320 58 L308 40 L332 40 Z"/>
      <path class="s" d="M580 66 L568 84 L592 84 Z"/>
      ${grd(40, 96, 40)} ${grd(300, 30, 40)} ${grd(560, 90, 44)}
      <circle class="acf" cx="250" cy="76" r="5"/><circle class="acf" cx="390" cy="76" r="5"/>
      <text class="ea" x="250" y="112" text-anchor="middle">P₁</text>
      <text class="ea" x="390" y="112" text-anchor="middle">P₂</text>
      <text class="lb" x="152" y="128" text-anchor="middle">sagging</text>
      <text class="lb" x="320" y="34" text-anchor="middle">hogging</text>
      <text class="lb" x="490" y="128" text-anchor="middle">sagging</text>

      <line class="gl" x1="30" y1="152" x2="610" y2="152"/>
      <text class="lb" x="320" y="176" text-anchor="middle">BENDING MOMENT DIAGRAM</text>
      <line class="s" x1="60" y1="228" x2="580" y2="228"/>
      <path class="softa" d="M60 228 Q155 300 250 228 Z"/>
      <path class="softa" d="M390 228 Q485 300 580 228 Z"/>
      <path class="soft" d="M250 228 Q320 160 390 228 Z"/>
      <path class="ac" d="M60 228 Q155 300 250 228"/>
      <path class="hi" d="M250 228 Q320 160 390 228"/>
      <path class="ac" d="M390 228 Q485 300 580 228"/>
      <line class="thin dash" x1="250" y1="76" x2="250" y2="240"/>
      <line class="thin dash" x1="390" y1="76" x2="390" y2="240"/>
      <text class="ea" x="250" y="258" text-anchor="middle">zero</text>
      <text class="ea" x="390" y="258" text-anchor="middle">zero</text>
      <text class="em" x="320" y="182" text-anchor="middle">−</text>
      <text class="ea" x="155" y="262" text-anchor="middle">+</text>
      <text class="lb" x="320" y="288" text-anchor="middle">Top steel must run past P₁ and P₂ — not stop at the support</text>
    </svg>`,
    caption: "The two diagrams must agree. A <strong>point of contraflexure on the elastic curve has to line up with a zero on the bending moment diagram</strong>; if it does not, one of them is wrong. This is also the cheapest way to see where top steel is needed, and how far it must run.",
  },

  /* ---------------------------------------- 1.2 LOAD PATH */
  "hb-sa-loadpath": {
    label: "Load path from slab to soil",
    svg: `<svg viewBox="0 0 730 300" role="img" aria-label="A load applied on a slab passes to the beam, then the column, then the footing and finally spreads into the soil, each stage drawn with an arrow">
      ${hbmk("lp")}
      <line class="ac" x1="300" y1="22" x2="300" y2="52" marker-end="url(#lp-c)"/>
      <text class="ea" x="312" y="38">w</text>
      <rect class="conc" x="120" y="56" width="400" height="20"/>
      <text class="lb" x="320" y="70" text-anchor="middle">SLAB</text>
      <rect class="conc" x="120" y="76" width="400" height="26"/>
      <text class="lb" x="320" y="94" text-anchor="middle">BEAM</text>
      <rect class="conc" x="270" y="102" width="44" height="106"/>
      <text class="lb" x="292" y="160" text-anchor="middle">COL</text>
      <path class="conc" d="M214 208 H370 L346 246 H238 Z"/>
      <text class="lb" x="292" y="232" text-anchor="middle">FOOTING</text>
      <rect class="soft" x="150" y="246" width="290" height="44"/>
      <line class="s" x1="60" y1="246" x2="580" y2="246"/>
      <text class="lb" x="500" y="272">SOIL</text>
      <line class="hi" x1="238" y1="258" x2="238" y2="286" marker-end="url(#lp-m)"/>
      <line class="hi" x1="292" y1="258" x2="292" y2="286" marker-end="url(#lp-m)"/>
      <line class="hi" x1="346" y1="258" x2="346" y2="286" marker-end="url(#lp-m)"/>

      <line class="thin dash" x1="540" y1="66" x2="600" y2="66"/>
      <text class="lb" x="604" y="70">bending</text>
      <line class="thin dash" x1="540" y1="89" x2="600" y2="89"/>
      <text class="lb" x="604" y="93">bending + shear</text>
      <line class="thin dash" x1="322" y1="155" x2="600" y2="155"/>
      <text class="lb" x="604" y="159">axial</text>
      <line class="thin dash" x1="378" y1="227" x2="600" y2="227"/>
      <text class="lb" x="604" y="231">spreading</text>
    </svg>`,
    caption: "A structure is whatever carries load to the ground safely. Tracing that path — and naming <strong>what kind of action each element carries</strong> — is the first thing to do with any structure you are handed, and the last thing to check when an answer looks odd.",
  },

});
