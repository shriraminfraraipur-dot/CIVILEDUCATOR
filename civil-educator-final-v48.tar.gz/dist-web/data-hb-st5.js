/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   Chapter 9  — Beam-Columns: Combined Forces
   Chapter 10 — Plate Girders

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "st"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 9 */
    {
      id: "st-9",
      n: 9,
      title: "Beam-Columns: Combined Forces",
      hi: "बीम-कॉलम: संयुक्त बल",
      blurb: "Axial load and bending on the same member, the moment the member makes for itself, and the two checks that both have to pass.",
      mins: 36,
      sections: [

        {
          n: "9.1",
          title: "Almost every real member is one",
          hi: "लगभग हर सदस्य ऐसा ही है",
          blocks: [
            { k: "p", t: "Chapters 5 to 8 dealt with pure cases: tension only, compression only, bending only. Very few members in a real frame are any of those." },
            { k: "list", items: [
              "A <strong>column</strong> in a rigid frame gets a moment from every beam that frames into it, because the beams are never loaded symmetrically.",
              "A <strong>truss chord</strong> with purlins landing between its panel points carries axial force plus local bending.",
              "A <strong>crane column</strong> carries the roof load axially and the crane surge as a moment.",
              "A <strong>bracing member</strong> carries axial force plus the bending from its own self weight over a long span.",
            ]},
            { k: "p", t: "IS 800 Section 9 handles all of them, and it does so with two separate checks that answer two different questions. Both have to pass." },
          ],
        },

        {
          n: "9.2",
          title: "Why they cannot be added",
          hi: "इन्हें जोड़ा क्यों नहीं जा सकता",
          blocks: [
            { k: "p", t: "The obvious approach — check P against Pd, check M against Md, and be satisfied if both pass — is wrong, and the reason is worth understanding because it is the same reason slender columns need additional moments in Chapter 8 of the RCC handbook." },
            { k: "dia", id: "hb-st-pdelta", cap: "The bending deflects the member; the axial load then acts at that eccentricity and adds more moment." },
            { k: "p", t: "The applied moment deflects the member sideways by δ. The axial load P is now acting δ away from the member's axis, so it contributes a further moment of P δ. That extra moment increases δ, which increases P δ, and so on. The loop either converges to a larger deflection than first-order analysis predicted, or it does not converge at all — which is failure." },
            { k: "def", term: "Second-order (P–δ) effect", t: "The additional moment a member generates in itself by deflecting under axial load. It grows with the axial load and with the member's slenderness, and it is what makes the interaction of P and M non-linear." },
            { k: "note", t: "There is a companion effect at frame scale, P–Δ, where the whole storey sways sideways and the column axial loads act at the storey drift. Cl. 4.4 covers it, and for a sway frame it can be larger than P–δ. A braced frame largely avoids it — one more entry on the list of things bracing pays for." },
          ],
        },

        {
          n: "9.3",
          title: "The two checks",
          hi: "दो जाँचें",
          blocks: [
            { k: "dia", id: "hb-st-interaction", cap: "Section capacity asks about the cross-section; overall buckling asks about the member." },
            { k: "h", t: "Check 1 — section capacity (Cl. 9.3.1)" },
            { k: "p", t: "Can the cross-section itself carry P and M together? Axial force uses up part of the section, leaving less for bending, so the moment capacity is <em>reduced</em>. For a plastic or compact I-section, Cl. 9.3.1.1 gives the reduced capacity about the major axis as" },
            { k: "eq", expr: "Mndz = 1.11 Mdz (1 − n)  ≤  Mdz,    where n = N/Nd", where: [
              ["N", "factored axial force"],
              ["Nd", "design axial capacity of the section = Ag fy/γm0 — the SECTION's squash capacity, not the buckling capacity"],
              ["Mdz", "the section's moment capacity about the major axis, from Chapter 7"],
            ]},
            { k: "p", t: "The 1.11 and the cap together produce a curve that is <strong>flat at first</strong>: up to n ≈ 0.1 the moment capacity is not reduced at all, because the axial force can be carried by the web, which was contributing little to the moment anyway. Only once n grows does the axial force start eating into the flanges. (That is the form for standard rolled I and channel sections; welded sections have their own expression in the same clause.)" },
            { k: "note", t: "<b>Correction (v45):</b> an earlier version printed this as 1.14 Mdz(1 − n²), which overstates the reduced capacity — by about 50% at n = 0.47. The 1.11 Mdz(1 − n) form is the one applied in <a href=\"https://prd-aws-docs.bentley.com/LiveContent/web/STAAD.Pro%20Help-v20/en/GUID-4275ADC9-85BB-459F-9D06-2899530D6869.html\" target=\"_blank\" rel=\"noopener\">STAAD.Pro's IS 800 verification example</a>." },
            { k: "p", t: "For a semi-compact section Cl. 9.3.1.3 gives the simpler and more conservative linear form, since such a section cannot redistribute:" },
            { k: "eq", expr: "N/Nd  +  Mz/Mdz  +  My/Mdy  ≤  1.0", where: [] },
            { k: "h", t: "Check 2 — overall member buckling (Cl. 9.3.2)" },
            { k: "p", t: "Will the member, as a whole, buckle under the combination? This check uses the <strong>buckling</strong> capacities — Pd from Chapter 6 and the lateral-torsional Md from Chapter 8 — not the section capacities, and Cl. 9.3.2.2 states it as a pair of interaction expressions containing moment amplification factors Ky, Kz and KLT and the equivalent uniform moment factors Cm." },
            { k: "eq", expr: "P/Pdy + Ky Cmy My/Mdy + KLT Mz/Mdz  ≤  1.0        P/Pdz + 0.6 Ky Cmy My/Mdy + Kz Cmz Mz/Mdz  ≤  1.0", where: [
              ["Ky, Kz", "moment amplification factors, functions of the slenderness and the axial utilisation (Cl. 9.3.2.2)"],
              ["Cm", "equivalent uniform moment factor — a credit for a moment that is not constant along the member"],
            ]},
            { k: "note", t: "The K and Cm factors are what make this check less conservative than a plain sum, and they need the code in hand. A simple <strong>linear</strong> sum, P/Pd + Mz/Mdz ≤ 1.0, is always conservative and is a legitimate first screen: if it passes, the member is adequate and no further work is needed. It is only when it fails marginally that the full expressions are worth the effort." },
            { k: "trap", t: "The two checks use different capacities for the same symbols. Check 1 uses Nd = Ag fy/γm0, the squash capacity — no buckling at all. Check 2 uses Pd = Ae fcd, which for a real column is much smaller. Substituting one for the other is a serious error in either direction." },
          ],
        },

        {
          n: "9.4",
          title: "A beam-column checked",
          hi: "एक बीम-कॉलम की जाँच",
          blocks: [
            { k: "eg",
              title: "Example 9.1 — Column with an end moment",
              given: "ISHB 300, 4.0 m long, both ends pinned, E250 steel, carrying a factored axial compression of 800 kN and a factored major-axis moment of 80 kNm. From the section tables: A = 7485 mm², bf = 250 mm, tf = 10.6 mm, Zpz = 953.4 × 10³ mm³. From Example 6.1, the axial buckling capacity of this member is Pd = 1092 kN. Assume the compression flange is restrained, so Mdz is the Chapter 7 value.",
              steps: [
                { t: "Section capacities", w: "Nd = A fy/γm0 = 7485 × 250/1.10 = 1701.1 kN\nMdz = Zpz fy/γm0 = 953.4 × 10³ × 250/1.10 = 216.7 kNm" },
                { t: "Axial utilisation of the SECTION", w: "n = N/Nd = 800/1701.1 = 0.470" },
                { t: "Check 1 — reduced section moment capacity (Cl. 9.3.1.1)", w: "Mndz = 1.11 × 216.7 × (1 − 0.470)\n     = 1.11 × 216.7 × 0.530 = 127.4 kNm   (< Mdz = 216.7  ✓ cap not reached)\nApplied Mz = 80 kNm  <  127.4 kNm   ✓ SECTION CAPACITY OK" },
                { t: "Check 2 — overall buckling, conservative linear screen", w: "P/Pd  + Mz/Mdz\n= 800/1092 + 80/216.7\n= 0.733 + 0.369 = 1.102   >  1.0   ✗ FAILS" },
                { t: "What that means", w: "The cross-section is comfortably strong enough — it is using 63% of its reduced moment capacity.\nThe MEMBER is not: buckling has already consumed 73% of its capacity on the axial load alone." },
              ],
              ans: "The section passes and the member fails. The fix is a buckling fix, not a strength one: brace the minor axis at mid-height (KL/ry falls to 37, χ rises to 0.89 and Pd to about 1512 kN — the screen drops to 0.90), or choose a section with a larger ry — not a section with a larger Zp.",
            },
            { k: "trap", t: "Read the two lines of that example together. Check 1 used 63% of the available capacity; check 2 used 110%. A designer who checked only the cross-section would have passed a member that buckles. It is always the second check that governs for anything of ordinary slenderness." },
            { k: "note", t: "The linear screen in step 4 is conservative. The full Cl. 9.3.2.2 expressions, with Cm credited for a moment that varies along the member and KLT for the lateral-torsional behaviour, credit Cm only in the minor-axis expression; with the compression flange restrained (λLT = 0, KLT = 1) the major-axis expression stays close to the screen here, so do not count on it to rescue the member. Bracing, or a stiffer section, is the reliable fix." },
          ],
        },

        {
          n: "9.5",
          title: "Bending with axial tension",
          hi: "तनाव के साथ बंकन",
          blocks: [
            { k: "p", t: "The other combination is gentler, and for a helpful reason: axial tension <strong>straightens</strong> a member. There is no P–δ amplification, because the axial force acts to reduce the deflection rather than increase it." },
            { k: "p", t: "Cl. 9.3.1 still requires the section capacity check, because tension uses up section just as compression does. But Cl. 9.3.2.1 permits the moment to be reduced to account for the straightening effect, rather than amplified — the opposite sign of everything in §9.3." },
            { k: "note", t: "A wind-uplift case in a portal frame often puts the rafter into axial tension with a reversed moment. It is a different load case from the gravity one and has to be checked separately, but it is rarely the one that governs the member — the compression case usually is. What it <em>can</em> govern is the connections and the holding-down bolts, which see a reversal they were not designed for." },
          ],
        },

        {
          n: "9.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "P and M cannot be checked separately — the member's own deflection couples them.",
              "Check 1, section capacity (Cl. 9.3.1): Mndz = 1.11 Mdz(1 − n) ≤ Mdz for rolled I-sections, with n = N/Nd and Nd the squash capacity.",
              "Check 2, overall buckling (Cl. 9.3.2): uses Pd and the LTB Md, with amplification factors K and Cm.",
              "A plain linear sum is a valid conservative screen for check 2.",
              "Check 2 almost always governs.",
              "When it fails, the answer is bracing or a better ry — a stronger section is the wrong lever.",
              "Axial tension helps rather than hurts, but the section check still applies.",
            ]},
            { k: "p", t: "Chapter 10 goes the other way — to members so large that no rolled section exists, built from plate, where the designer chooses every dimension and the web is deliberately allowed to do something the code has so far forbidden." },
          ],
        },
      ],
    },

    /* =========================================================== CH 10 */
    {
      id: "st-10",
      n: 10,
      title: "Plate Girders",
      hi: "प्लेट गर्डर",
      blurb: "Beams built from plate, webs thin enough to buckle on purpose, and the truss that appears inside one after it has.",
      mins: 42,
      sections: [

        {
          n: "10.1",
          title: "When no rolled section will do",
          hi: "जब कोई रोल्ड सेक्शन काफ़ी न हो",
          blocks: [
            { k: "p", t: "Rolled sections stop at a certain depth, and beyond a certain span or load nothing in the catalogue is adequate. The answer is to weld one from plate — and the moment you do, every proportion becomes a decision instead of a given." },
            { k: "dia", id: "hb-st-girder", cap: "Flanges, web, intermediate stiffeners and bearing stiffeners — five independent choices." },
            { k: "list", items: [
              "<strong>Depth</strong> — typically span/10 to span/12 for a building girder, shallower for a bridge with headroom constraints. Deeper is more efficient in bending and needs more stiffening in shear.",
              "<strong>Web thickness</strong> — as thin as the shear and the stability rules allow, because the web is a large area of steel that contributes little to the moment.",
              "<strong>Flange plates</strong> — sized to carry the moment, and proportioned so they classify as plastic or compact.",
              "<strong>Stiffeners</strong> — bearing stiffeners where loads and reactions arrive, intermediate stiffeners to control the web.",
            ]},
            { k: "p", t: "The design idea is simple and worth stating plainly: <strong>put the steel in the flanges, where the moment is, and make the web only as strong as the shear requires</strong>. A deep girder has a very large lever arm between its flanges, so the flange forces are small for a given moment, and the web only has to hold the two flanges apart and carry the shear." },
          ],
        },

        {
          n: "10.2",
          title: "The web, and the limits on how thin it can be",
          hi: "वेब कितना पतला",
          blocks: [
            { k: "p", t: "A rolled beam's web has d/tw around 40, comfortably below every limit in the code. A plate girder's routinely exceeds 150, and Cl. 8.6.1 sets bounds on how far that can go:" },
            { k: "list", items: [
              "<strong>Without intermediate stiffeners</strong>, d/tw is limited to about 200ε (Cl. 8.6.1.1) — beyond that the panel is simply too slender to be relied on.",
              "<strong>Against the compression flange buckling INTO the web</strong>, Cl. 8.6.1.2 sets a separate limit related to the flange and web slenderness. A very thin web offers no support to the flange sitting on it, and the flange can dimple downwards into it.",
              "<strong>Serviceability</strong> — a very thin web visibly ripples under load even when it is structurally adequate, which clients notice.",
            ]},
            { k: "trap", t: "That second limit catches people out because it is not about shear at all. The flange is a compressed plate resting on the edge of the web, and the web is the only thing preventing it from buckling downwards out of its own plane. Halving the web thickness to save weight can produce a girder that fails in a mode nobody was thinking about." },
          ],
        },

        {
          n: "10.3",
          title: "Shear buckling",
          hi: "अपरूपण बकलिंग",
          blocks: [
            { k: "p", t: "Chapter 7 gave the shear capacity as Av fyw/(√3 γm0) and added a condition: valid only while d/tw ≤ 67ε. A plate girder is nowhere near that, so its web does not reach shear yield — it buckles first." },
            { k: "dia", id: "hb-st-shearbuckle", cap: "Shear is diagonal tension one way and diagonal compression the other; the compression diagonal is what ripples." },
            { k: "p", t: "Pure shear on a panel is equivalent to tension along one diagonal and compression along the other, at 45°. The panel is a thin plate, and a thin plate in compression buckles. The elastic critical shear stress comes from plate theory:" },
            { k: "eq", expr: "τcr,e = kv π² E / [ 12 (1 − μ²) (d/tw)² ]", where: [
              ["kv", "shear buckling coefficient, depending on the panel's aspect ratio c/d"],
              ["c", "spacing of the transverse stiffeners — the panel length"],
              ["μ", "Poisson's ratio, 0.3"],
            ]},
            { k: "eq", expr: "kv = 5.35  with transverse stiffeners at the supports only;    kv = 4.0 + 5.35/(c/d)²  for c/d < 1.0;    kv = 5.35 + 4.0/(c/d)²  for c/d ≥ 1.0", where: [] },
            { k: "note", t: "<b>Correction (v45):</b> an earlier version gave kv = 5.35 for every panel with c/d ≥ 1. That value belongs to a web with stiffeners at the supports only (an effectively infinite panel); intermediate stiffeners at c/d ≥ 1 give 5.35 + 4/(c/d)² — 9.35 at c/d = 1 (IS 800 Cl. 8.4.2.2; the same plate-buckling coefficients as classical stability theory). Example 10.1 has been reworked." },
            { k: "p", t: "This is where stiffeners earn their place, and it is worth being precise about what they do: <strong>an intermediate stiffener carries almost no shear itself</strong>. It shortens the panel, which raises kv, which raises the critical stress. The web still carries the shear — it is simply given less room in which to buckle." },
            { k: "eq", expr: "λw = √( fyw / (√3 τcr,e) )", where: [
              ["λw", "non-dimensional web slenderness — the same idea as λ and λLT in earlier chapters"],
            ]},
            { k: "p", t: "Cl. 8.4.2.2's simple post-critical method then gives the shear strength in three ranges, the now-familiar shape of a plateau and a falling branch:" },
            { k: "list", items: [
              "λw ≤ 0.8 — τb = fyw/√3. The web reaches shear yield; no buckling penalty.",
              "0.8 &lt; λw &lt; 1.2 — τb = [1 − 0.8(λw − 0.8)] fyw/√3. Inelastic buckling, a linear transition.",
              "λw ≥ 1.2 — τb = fyw/(√3 λw²). Elastic buckling, and τb collapses towards τcr,e.",
            ]},
            { k: "eg",
              title: "Example 10.1 — What stiffener spacing is worth",
              given: "Plate girder web 1500 mm deep × 10 mm thick, E250 steel (fyw = 250 N/mm²). Compare transverse stiffeners at 1500 mm spacing (c/d = 1.0) with stiffeners at 750 mm (c/d = 0.5).",
              steps: [
                { t: "Check the web slenderness limit", w: "d/tw = 1500/10 = 150  <  200ε = 200  ✓ permissible with intermediate stiffeners" },
                { t: "Case 0 — stiffeners at the supports only", w: "kv = 5.35\nτcr,e = 5.35 × π² × 2×10⁵/[12 × 0.91 × 150²]\n     = 10,560,477/245,700 = 43.0 N/mm²\nλw = √(250/(1.732 × 43.0)) = √3.359 = 1.833   → elastic range (λw ≥ 1.2)\nτb = 250/(1.732 × 1.833²) = 43.0 N/mm²\nVd = Av τb/γm0 = 15,000 × 43.0/1.10 = 586 kN" },
                { t: "Case A — stiffeners at 1500 mm (c/d = 1.0)", w: "kv = 5.35 + 4.0/1.0² = 9.35\nτcr,e = 9.35 × 1,973,921/245,700 = 75.1 N/mm²\nλw = √(250/(1.732 × 75.1)) = 1.386   → elastic range\nτb = 250/(1.732 × 1.386²) = 75.1 N/mm²\nVd = 15,000 × 75.1/1.10 = 1024 kN" },
                { t: "Case B — stiffeners at 750 mm (c/d = 0.5)", w: "kv = 4.0 + 5.35/0.5² = 4.0 + 21.4 = 25.4\nτcr,e = 25.4 × 1,973,921/245,700 = 204.1 N/mm²\nλw = √(250/(1.732 × 204.1)) = √0.707 = 0.841   → inelastic range\nτb = [1 − 0.8(0.841 − 0.800)] × 250/1.732 = 0.967 × 144.3 = 139.6 N/mm²\nVd = 15,000 × 139.6/1.10 = 1904 kN" },
                { t: "For reference — if the web could reach shear yield", w: "Vd = Av fyw/(√3 γm0) = 15,000 × 250/(1.732 × 1.10) = 1968 kN" },
              ],
              ans: "Stiffeners at 1500 mm raise the capacity from 586 kN (supports only) to 1024 kN; halving the spacing to 750 mm raises it again to 1904 kN — a factor of 1.86. The unstiffened web delivers 30% of its shear-yield capacity, the 1500 mm panels 52%, the 750 mm panels 97%.",
            },
            { k: "trap", t: "Notice that in Cases 0 and A, τb came out exactly equal to τcr,e. That is not a coincidence — in the elastic range the formula reduces to the critical stress, because the web really does buckle elastically and nothing more is available. The web is 15,000 mm² of steel delivering 586 kN, when the same area at shear yield would give 1968 kN. That is what an unstiffened deep web costs." },
          ],
        },

        {
          n: "10.4",
          title: "Tension field action",
          hi: "टेंशन फ़ील्ड क्रिया",
          blocks: [
            { k: "p", t: "Here is what makes plate girders genuinely different from everything earlier in this handbook. A buckled web panel is <strong>not</strong> a failed one. The compression diagonal has gone, but the tension diagonal is still perfectly capable of carrying load — a thin sheet is very good in tension whatever it does in compression." },
            { k: "dia", id: "hb-st-tensionfield", cap: "After buckling, a diagonal tension band remains, anchored by the flanges and the stiffeners." },
            { k: "p", t: "So the girder reorganises itself. The web becomes a series of diagonal tension bands; the flanges anchor the top and bottom of each band; and the transverse stiffeners act as <strong>vertical compression posts</strong> between them. The whole girder is now behaving as a Pratt truss, and it can carry a great deal more than the buckling load. Cl. 8.4.2.2 permits this to be used explicitly, as the tension field method." },
            { k: "list", items: [
              "The web must be <strong>anchored</strong> all round the panel for the band to develop — this is why end panels are treated specially, having no adjacent panel to balance against.",
              "The <strong>stiffeners become compression members</strong> and must be designed as such, with a real check, not merely detailed.",
              "The <strong>flanges must resist the band's pull</strong> along their length, which produces local bending in them between stiffeners.",
            ]},
            { k: "note", t: "This is one of the few places in structural design where a component is allowed to fail in a recognised way and then relied upon afterwards. It is the reason aircraft skins are built the way they are, and it is why a plate girder web that visibly ripples under load may be behaving exactly as designed." },
            { k: "trap", t: "Tension field action cannot be invoked casually. It requires the anchorage conditions to be satisfied, the stiffeners to be designed for the resulting compression, and the end panels to be handled separately. A girder designed by the simple post-critical method and then site-modified — a stiffener omitted, a panel lengthened — loses the assumption it was built on." },
          ],
        },

        {
          n: "10.5",
          title: "Flanges, and the flange-only approximation",
          hi: "फ़्लैंज और उनका अनुमान",
          blocks: [
            { k: "p", t: "A plate girder's web is usually class 4 in bending — far too slender to count on through its depth. That leads to a design approach that is both conservative and honest: <strong>assume the flanges carry the entire moment</strong> and treat the web as contributing nothing to it." },
            { k: "eq", expr: "Md ≈ Af fy (d + tf) / γm0        →       Af ≈ M γm0 / [ fy (d + tf) ]", where: [
              ["Af", "area of one flange plate, mm²"],
              ["d + tf", "approximate lever arm between the flange centroids"],
            ]},
            { k: "p", t: "The flange plate then has to be proportioned so that it classifies acceptably. For a <strong>welded</strong> section the outstand limits of Chapter 2 are tighter than for a rolled one — 8.4ε for plastic, 9.4ε for compact — so the flange cannot simply be made wide and thin." },
            { k: "eg",
              title: "Example 10.2 — Sizing the flanges",
              given: "Plate girder, web 1500 × 10 mm, required factored moment capacity 3000 kNm, E250 steel, welded section.",
              steps: [
                { t: "Flange area required", w: "Try a 25 mm flange plate:\nAf = M γm0/[fy(d + tf)] = 3000 × 10⁶ × 1.10/(250 × 1525)\n   = 3.3 × 10⁹/381,250 = 8656 mm²" },
                { t: "Choose a plate", w: "Try 360 mm × 25 mm = 9000 mm²  >  8656  ✓" },
                { t: "Check the flange classification (Chapter 2, welded limits)", w: "outstand b = (360 − 10)/2 = 175 mm\nb/tf = 175/25 = 7.0\nWelded plastic limit = 8.4ε = 8.4\n7.0  <  8.4  →  PLASTIC flange  ✓" },
                { t: "Capacity delivered", w: "Md = 9000 × 250 × 1525/1.10 = 3119 × 10⁶ N·mm = 3119 kNm\n3119  >  3000  ✓" },
              ],
              ans: "Flanges 360 × 25 mm give 3119 kNm against a required 3000 kNm, with a plastic flange. Note that a 400 × 25 plate would give 3466 kNm and a b/tf of 7.8 — still plastic, but heavier than needed.",
            },
            { k: "trap", t: "Widening a flange plate to gain area is not free: it increases the outstand and can push the flange from plastic to compact to semi-compact, at which point the section modulus available falls and some of the gain is lost. <strong>Thicker is usually better than wider</strong> for a plate girder flange — and it also helps the Cl. 8.6.1.2 check of §10.2." },
          ],
        },

        {
          n: "10.6",
          title: "Stiffeners",
          hi: "स्टिफ़नर",
          blocks: [
            { k: "dia", id: "hb-st-stiffeners", cap: "Three kinds of stiffener doing three different jobs." },
            { k: "def", term: "Bearing stiffener (Cl. 8.7.5)", t: "At every support and under every significant concentrated load. It carries the whole reaction directly between the flanges, bypassing the web entirely, and is designed as a short column — the stiffener plates plus an effective width of web acting with them. Without one, the web buckling and crippling checks of Chapter 7 apply to a web far too slender to pass them." },
            { k: "def", term: "Intermediate transverse stiffener (Cl. 8.7.2)", t: "Divides the web into panels and raises kv. It carries little load in the simple post-critical method and real compression in tension field action, and it must have enough <strong>stiffness</strong> — a minimum second moment of area — to hold the line of the panel edge while the web buckles beside it." },
            { k: "def", term: "Longitudinal stiffener (Cl. 8.7.13)", t: "Runs along the girder in the compression zone of a very deep web, where it is <em>bending</em> rather than shear that buckles the web. Placed at roughly one-fifth of the depth from the compression flange, where it does the most good. Common in bridge girders, rare in buildings." },
            { k: "note", t: "The stiffness requirement for an intermediate stiffener is a genuinely different kind of criterion from everything else in this handbook. It is not asked to carry a force; it is asked not to move. A stiffener strong enough but too flexible simply buckles along with the web and achieves nothing." },
          ],
        },

        {
          n: "10.7",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Plate girder: depth around span/10 to span/12; flanges carry the moment, web carries the shear.",
              "d/tw limited to about 200ε with stiffeners, plus a separate limit against the flange buckling into the web.",
              "A deep web buckles in shear before it yields: τcr,e = kv π²E/[12(1−μ²)(d/tw)²].",
              "kv = 5.35 with end stiffeners only; 5.35 + 4/(c/d)² for c/d ≥ 1; 4.0 + 5.35/(c/d)² below it — which is what stiffener spacing controls.",
              "λw decides the branch: plateau below 0.8, transition to 1.2, elastic beyond.",
              "Intermediate stiffeners can more than triple the shear capacity of a deep web (586 → 1904 kN in Example 10.1).",
              "Tension field action lets a buckled web keep working as a truss diagonal — but the stiffeners then become compression members.",
              "Size flanges by Af ≈ M γm0/[fy(d + tf)], then check the welded-section classification limits.",
              "Bearing stiffeners at every support and concentrated load.",
            ]},
            { k: "p", t: "Chapters 11 and 12 assemble everything into structures — bases, trusses, industrial buildings and gantry girders — and close with the one failure mode this handbook has not yet touched, which happens at stresses far below anything computed so far." },
          ],
        },
      ],
    }

  );
})();
