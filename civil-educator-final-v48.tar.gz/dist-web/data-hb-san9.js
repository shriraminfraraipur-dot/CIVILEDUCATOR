/* ============================================================
   Structural Analysis — Theory of Structures (T) pages that were
   not yet in the app: T p.34–40 (why indeterminate structures,
   force vs displacement methods), T p.89–93 (MDM numericals),
   T p.94–103 (truss basics, zero-force examples, method of joints
   and sections numericals), T p.169–171 (arch numericals).
   Inserted into the existing san chapters before each chapter's
   Quick-revision section. Added v47.
   ============================================================ */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "san"; });
  if (!hb) return;
  function ins(n, secs) {
    var ch = hb.chapters.find(function (c) { return c.n === n; });
    if (!ch) return;
    var tail = ch.sections.pop();
    secs.forEach(function (s) { ch.sections.push(s); });
    ch.sections.push(tail);
    ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
  }

  /* ---------------- Chapter 9 — T p.34–40 ---------------- */
  ins(9, [
    {
      n: "", title: "Why we build indeterminate structures, and force vs displacement methods (T p.34–40)",
      hi: "अनिर्धार्य संरचनाएँ क्यों, और बल बनाम विस्थापन विधियाँ",
      blocks: [
        { k: "h", t: "📘 Notes — T p.34–36" },
        { k: "p", t: "In structural analysis we are mainly concerned with <b>indeterminate structures</b>, because most of the structures we build are statically indeterminate. A structure is determinate when D<sub>S</sub> = 0 (D<sub>S</sub> &lt; 0 means it is unstable) and indeterminate when D<sub>S</sub> &gt; 0. The problem with D<sub>S</sub> &gt; 0: the number of unknown member forces and support reactions is more than the number of equations of statics, so statics alone cannot find all of them. (T p.34)" },
        { k: "cmp", t: "Same span, same central point load P — determinate vs indeterminate (T p.35)",
          cols: ["Simply supported beam", "Fixed beam (both ends fixed)"],
          rows: [
            ["Useful equations (vertical load only)", "ΣF<sub>y</sub> = 0, ΣM<sub>z</sub> = 0 (ΣF<sub>x</sub> = 0 is 'useless' — no horizontal force)", "ΣF<sub>y</sub> = 0, ΣM<sub>z</sub> = 0"],
            ["D<sub>S</sub> for vertical loading", "2 − 2 = 0", "4 − 2 = 2"],
            ["D<sub>S</sub> under general loading", "—", "D<sub>se</sub> = 6 − 3 = 3"],
            ["Bending moment", "Triangle, maximum Pl/4 at mid-span", "Hogging Pl/8 at each support and sagging Pl/8 at mid-span"],
          ] },
        { k: "list", items: [
          "Fixed beam with no load: D<sub>S</sub> = 3. With a vertical point load: D<sub>S</sub> = 2. With an inclined point load: D<sub>S</sub> = 3, because the horizontal reactions now take part. (T p.35)",
          "<b>Why indeterminate?</b> The bending moment comes out smaller than in the determinate structure (Pl/8 against Pl/4 above). (T p.35)",
        ] },
        { k: "h", t: "Important points of the solution (T p.36–37)" },
        { k: "list", items: [
          "i) Member forces are reduced in the indeterminate structure, for a given loading, compared with the determinate structure. (T p.36)",
          "ii) Smaller member forces ⇒ smaller cross-section ⇒ saving in material. (T p.36)",
          "iii) If an overload comes, the indeterminate structure can <b>re-distribute</b> the extra load to its redundant supports; a determinate structure cannot. (T p.36)",
          "Drawback (i): the fixed (indeterminate) beam costs more to make than the simply supported one — supports cost more. (T p.36)",
          "Figure (ii) on T p.36: under the same load P the fixed beam deflects only a little (small δ), the simply supported beam much more (large δ). (T p.36)",
          "Drawback: in indeterminate structures, <b>differential settlement of supports causes additional stresses</b> in the material, so the supports must be made very strong — this costs money, but overall we still save, so we go for statically indeterminate structures. (T p.37)",
        ] },
        { k: "h", t: "📘 Notes — force vs displacement methods (T p.37–39)" },
        { k: "cmp", t: "The two families of methods (T p.37–38)",
          cols: ["Force method", "Displacement method"],
          rows: [
            ["Also known as", "Compatibility method; method of consistent deformation; flexibility method", "Stiffness method"],
            ["Unknowns", "Forces — member forces, support reactions, or both", "Joint displacements"],
            ["Unknowns found from", "Compatibility equations", "Equilibrium equations"],
            ["Number of equations", "= D<sub>S</sub>", "= D<sub>K</sub>"],
            ["Preferable when", "D<sub>S</sub> &lt; D<sub>K</sub>", "D<sub>K</sub> &lt; D<sub>S</sub>"],
          ] },
        { k: "eg", title: "T's examples — which method to choose (T p.38)",
          given: "Choose between the force and displacement methods by comparing D_S and D_K for: (a) a beam fixed at the left end and pinned at the right, general load; (b) a continuous beam on three supports — pin, roller, roller; (c) a two-span beam fixed at both ends with a pin support in the middle.",
          steps: [
            { t: "(a) Fixed + pinned beam", w: "D_S = 5 − 3 = 2 ;  D_K = 1\nD_S > D_K  ⇒  displacement method" },
            { t: "(b) Pin–roller–roller continuous beam", w: "D_S = 1 ;  D_K = 5 (DoF 1 + 2 + 2)\nD_K > D_S  ⇒  force method" },
            { t: "(c) Fixed–pin–fixed two-span beam", w: "D_S = 8 − 3 = 5 ;  D_K = 1\nD_S > D_K  ⇒  displacement method" },
          ],
          ans: "(a) displacement method; (b) force method; (c) displacement method. (T p.38)" },
        { k: "cmp", t: "Methods in each family, as listed in the notes (T p.38–39)",
          cols: ["Belongs to", "Note in T"],
          rows: [
            ["Castigliano's theorem (method of least work)", "Force", "—"],
            ["Strain energy method", "Force", "Deflection of <b>linear</b> structures is found by the strain energy method; of <b>non-linear</b> structures by the complementary energy method"],
            ["Virtual work (unit load) method", "Force", "Derived from Castigliano's theorem"],
            ["Clapeyron's three-moment equation", "Force", "Continuous and fixed beams"],
            ["Column analogy method", "Force", "Rigid frame analysis"],
            ["Flexibility matrix method", "Force", "—"],
            ["Slope deflection method", "Displacement", "—"],
            ["Moment distribution method", "Displacement", "—"],
            ["Stiffness matrix method", "Displacement", "—"],
            ["Kani's method", "Displacement", "Used for multi-storey buildings and frames"],
          ] },
        { k: "h", t: "📘 Notes — fundamental assumption: superposition (T p.39–40)" },
        { k: "def", term: "Principle of superposition", t: "The total displacement, support reaction or member force at a point of a structure carrying several external loads can be found by adding together the displacements, support reactions or member forces caused by each load acting separately. Figure (T p.39): a cantilever with 10 kN and 20 kN loads — δ<sub>B</sub> under both = δ<sub>B</sub> (10 kN alone) + δ<sub>B</sub> (20 kN alone). (T p.39)" },
        { k: "list", items: [
          "Two requirements: ① linear elastic material response (Hooke's law valid); ② small displacement theory applies (displacements are small). (T p.40)",
          "Frames under transverse (lateral) loading are analysed quickly by the <b>cantilever method</b> or the <b>portal method</b>. (T p.40)",
          "Virtual work done is zero when a body is in equilibrium. (T p.40)",
          "Strain energy can analyse statically indeterminate structures because strain energy is directly related to the slope and deflection it causes: ∂U/∂R = Δ and ∂U/∂M = θ. (T p.40)",
        ] },
        { k: "eq", expr: "∂U/∂R = Δ        ∂U/∂M = θ", where: [["U", "strain energy of the structure"], ["R, M", "force and moment at the point"], ["Δ, θ", "deflection and slope there"]] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Indeterminate structure ek 'backup plan' wali structure hai: support zyada hain, isliye moment Pl/4 se ghat kar Pl/8 ho jaata hai, section chhota lagta hai, aur overload aaye to load doosre support par chala jaata hai. Keemat yeh hai ki statics se solve nahi hoti — extra equations chahiye. Force method mein woh extra equations compatibility se aati hain (D<sub>S</sub> jitni), displacement method mein joint equilibrium se (D<sub>K</sub> jitni). Isliye jo number chhota ho, wahi method chuno." },
        { k: "trap", t: "Sirf structure dekh kar method mat chuno — pehle D<sub>S</sub> aur D<sub>K</sub> dono gino. Fixed–pin–fixed beam (T p.38) mein D<sub>S</sub> = 5 hai par D<sub>K</sub> sirf 1, isliye wahan slope-deflection ya moment distribution kahin tez hai." },
        { k: "real", t: "Isi wajah se site par continuous slabs aur beams banaye jaate hain, simply supported nahi — moment kam, steel kam. Par saath hi foundation ki differential settlement par dhyan dena padta hai, kyunki indeterminate structure mein settlement khud stress paida karti hai (T p.37)." },
      ],
    },
  ]);

  /* ---------------- Chapter 12 — T p.89–93 ---------------- */
  ins(12, [
    {
      n: "", title: "Worked numericals from T — continuous beams with overhangs (T p.89–93)",
      hi: "T के हल किए गए उदाहरण — ओवरहैंग वाले सतत बीम",
      blocks: [
        { k: "h", t: "📘 Notes — T p.89–91 (UPSC (M), 30 marks)" },
        { k: "p", t: "Beam (T p.89): A (hinged/roller end) — span AB = 6 m, 3I, udl 24 kN/m — B (roller) — span BC = 12 m, 10I, udl 16 kN/m — C (roller) — span CD = 6 m, 2I, point load 72 kN at 2 m from C — D (roller) — overhang 1.5 m carrying 24 kN at the free end. The overhang is statically determinate: it applies 24 × 1.5 = 36 kN-m at D. 'Continuous hinged/roller supports are treated as fixed [for the FEM step], because they take bending moment.' (T p.89)" },
        { k: "cmp", t: "Distribution factors (T p.89) — far ends A and D are hinged, so their spans use (3/4)·I/L",
          cols: ["Relative stiffness", "Total at joint", "DF"],
          rows: [
            ["B — BA", "(3/4)(3I/6) = 9I/24", "29I/24", "9/29"],
            ["B — BC", "10I/12 = 20I/24", "", "20/29"],
            ["C — CB", "10I/12 = 20I/24", "26I/24", "20/26"],
            ["C — CD", "(3/4)(2I/6) = 6I/24", "", "6/26"],
          ] },
        { k: "eg", title: "Four-support beam with overhang, by MDM (T p.89–91)",
          given: "Beam as described above: AB 6 m (3I, 24 kN/m), BC 12 m (10I, 16 kN/m), CD 6 m (2I, 72 kN at 2 m from C), overhang at D 1.5 m with 24 kN. A and D are end supports. Find the member end moments.",
          steps: [
            { t: "Fixed-end moments", w: "M_FAB = −24×6²/12 = −72 ; M_FBA = +72\nM_FBC = −16×12²/12 = −192 ; M_FCB = +192\nM_FCD = −72×2×4²/6² = −64 ; M_FDC = +72×2²×4/6² = +32" },
            { t: "First balancing at the hinged ends", w: "A: +72 (carry +36 to BA)\nD: DC must equal the overhang's 36 ⇒ +4 (carry +2 to CD)\nNew FEMs: AB 0, BA 108, BC −192, CB 192, CD −62, DC 36" },
            { t: "Balance B (out of balance 108 − 192 = −84) and C (192 − 62 = +130)", w: "B: BA (9/29)×84 = 26.6 [as written] ; BC (20/29)×84 = 57.94\nC: CB −(20/26)×130 = −100 ; CD −(6/26)×130 = −30" },
            { t: "Carry over and repeat (only between B and C; nothing to A or D, which are hinged)", w: "CO: BC −50 ; CB 28.97\nBalance: 15.52 | 34.48 | −22.28 | −6.69\nCO: −11.14 | 17.24\nBalance: 3.46 | 9.68 | −13.26 | −5.98\nCO: −6.68 | 4.80\nBalance: 2.29 | 4.572 | −3.69 | −1.11" },
            { t: "Sum", w: "M_AB = 0 ; M_BA = 155.826 ; M_BC = −155.826 ; M_CB = 104.2 ; M_CD = −104.2 ; M_DC = 36" },
          ],
          ans: "M_B = 155.826 kN-m, M_C = 104.2 kN-m (hogging), M_D = 36 kN-m, M_A = 0. (T p.90–91)" },
        { k: "note", t: "<b>Check:</b> (1) 9/29 × 84 = 26.07, not 26.6 (20/29 × 84 = 57.93 is right). (2) Solving the same beam exactly by slope-deflection gives M<sub>B</sub> = 155.95 kN-m and M<sub>C</sub> = 104.29 kN-m; the notes' 155.826 and 104.2 are where the iteration was stopped (and carry the 26.6 slip), so they are within about 0.1%. The method is exactly right. Some of the later balance rows also do not sum to zero at a joint because of rounding — a sign to carry one or two more cycles in an exam answer." },
        { k: "h", t: "📘 Notes — T p.91–93 (IE(M) / SSC-JE 30 marks, 2013)" },
        { k: "eg", title: "Fixed–roller–roller beam with an overhang (T p.91–93)",
          given: "A fixed at the left; span AB = 4 m (3I) with a 6 t point load 1 m from A; B roller; span BC = 4 m (4I) with udl 2 t/m; C roller; overhang CD = 1 m with 3 t at D. Determine the member end moments and plot the BMD.",
          steps: [
            { t: "Overhang (determinate)", w: "M_C from overhang = 3 × 1 = 3 t-m" },
            { t: "Distribution factors at B", w: "BA = 3I/4 ; BC = (3/4)(4I/4) = 3I/4 ; total 3I/2\nDF_BA = 1/2 ; DF_BC = 1/2 ; DF_AB = 0 (fixed) ; DF_CB = 1" },
            { t: "Fixed-end moments", w: "M_FAB = −6×1×3²/16 = −3.375 t-m ; M_FBA = +6×1²×3/16 = +1.125\nM_FBC = −2×4²/12 = −2.67 ; M_FCB = +2.67" },
            { t: "Balance C to 3 t-m, carry to B", w: "CB: +0.33 → 3 ; carry +0.165 to BC ⇒ BC = −2.505" },
            { t: "Balance B (1.125 − 2.505 = −1.38) and carry to A", w: "BA +0.69 ; BC +0.69 ; carry +0.345 to A" },
            { t: "Sum", w: "M_AB = −3.03 ; M_BA = 1.815 ; M_BC = −1.815 ; M_CB = 3 t-m" },
            { t: "Span AB reactions (simply supported part + end-moment part m/l)", w: "Simply supported: 3×6/4 = 4.5 at A ; 6×1/4 = 1.5 at B\nEnd moments: (3.03 − 1.815)/4 = 0.30375\nV_A = 4.5 + 0.30375 = 4.80375 t ; V_B = 1.5 − 0.30375 = 1.19625 t" },
            { t: "Bending moment under the 6 t load", w: "4.80375 × 1 − 3.03 = 1.77375 t-m (sagging)" },
          ],
          ans: "M_A = −3.03, M_B = −1.815, M_C = −3 t-m; SF in AB: +4.80375 t then −1.19625 t; maximum sagging 1.77375 t-m under the load. BMD of BC: hogging 1.815 and 3 at the ends with the udl parabola (free BM 2×4²/8 = 4) superposed. (T p.92–93)" },
        { k: "p", t: "<b>BMD by parts (T p.93):</b> draw the end-moment diagram (a trapezium from 3.03 at A to 1.815 at B, hogging) and add the simply supported diagram for the 6 t load (a triangle with peak 6×1×3/4 = 4.5 under the load); the net diagram is the difference." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Overhang wale beam mein pehla kaam hamesha overhang ko alag karna hai — woh determinate hai, uska moment (yahan 36 kN-m ya 3 t-m) seedha support par 'known moment' ban jaata hai. Phir end support ka DF = 1 rakho, taaki wahan ka moment wahi known value ban jaaye, aur baaki joints par normal MDM chalao." },
        { k: "trap", t: "End support jahan overhang hai, wahan moment zero nahi hota — wahan moment = overhang ka moment hai. Bahut students DF = 1 dekh kar wahan zero likh dete hain; yahan DC = 36 kN-m aur CB = 3 t-m hai (T p.90, p.92)." },
      ],
    },
  ]);

  /* ---------------- Chapter 6 — T p.94–103 ---------------- */
  ins(6, [
    {
      n: "", title: "Trusses in T's notes — exam question types, assumptions and zero-force examples (T p.94–98)",
      hi: "T के नोट्स में ट्रस — प्रश्न प्रकार, मान्यताएँ और शून्य-बल उदाहरण",
      blocks: [
        { k: "h", t: "📘 Notes — T p.94–96" },
        { k: "p", t: "Figure (T p.94): a through-truss bridge — two vertical trusses (top chord, bottom chord, verticals and diagonals) joined at the top by X-shaped <b>lateral (wind) bracing</b>, with the <b>deck</b> between them carried on transverse <b>floor beams</b>. A plane truss is labelled with its <b>top chord</b>, <b>bottom chord</b> and <b>diagonal</b> members, a hinged/pinned support and a roller support. (T p.94)" },
        { k: "list", items: [
          "Three kinds of exam question (T p.94): (i) a statically <b>determinate</b> truss — find the <b>deflection</b> at some joints (UPSC mains); (ii) a statically <b>indeterminate</b> truss — find support reactions and member forces (SSC-JE mains); (iii) a statically determinate truss — find support reactions and member forces.",
          "<b>TRUSS = truss members + joints + supports.</b> A 2D (planar) structure is one where the external loads and the structure act in the same plane. (T p.95)",
          "A truss has two kinds of static indeterminacy — external and internal. D<sub>se</sub> = number of support reactions − equations of statics; D<sub>se</sub> = 0 ⇒ externally determinate (all reactions from statics). (T p.95)",
        ] },
        { k: "list", items: [
          "Assumptions for the analysis and design of trusses (★ T p.96): i) members are joined by <b>smooth pins</b>; ii) all external loads are applied <b>at joints only</b>; iii) members take only <b>axial loads</b>; iv) self-weight of members is ignored.",
        ] },
        { k: "h", t: "📘 Notes — zero-force examples (T p.96–98)" },
        { k: "def", term: "Trick 1 (T p.96)", t: "If only two non-collinear members meet at a joint and no external load acts there, both are zero-force members." },
        { k: "def", term: "Trick 2 (T p.97)", t: "If three members meet at a joint, two of them collinear, and no external load acts there, the third member is a zero-force member." },
        { k: "list", items: [
          "<b>eg ① (T p.96):</b> 13-member truss, pinned at L1, roller at L4, free end L5. Members ① and ② are collinear at the joint between them, so Trick 1 does not apply there. Members ④ (bottom chord L4–L5) and ⑤ (inclined U3–L5) meet at the unloaded free joint L5 ⇒ <b>zero-force members</b>.",
          "<b>eg ② (T p.97):</b> truss A–B–E with a horizontal load P at C. Members ① (B–E) and ⑦ (C–E) meet at the unloaded end joint E ⇒ zero-force members.",
          "<b>eg ③ (T p.97):</b> load P at the free end E. Members ② and ③ meet at the unloaded corner C ⇒ zero-force; ⑥ and ⑤ meet at E, which carries P ⇒ <b>not</b> zero-force.",
          "<b>Trick 2 example (T p.97–98):</b> truss tied to a wall at H and A, load P at bottom joint C. ED and CD meet at the unloaded end D ⇒ zero (Trick 1). At G, HG and GB are collinear and GF is not ⇒ GF = 0 (Trick 2). At C: ΣF<sub>y</sub> = 0 gives F<sub>CE</sub> = P, and F<sub>CB</sub> = 0.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Zero-force member dhoondhna truss ka 'pehla filter' hai — jo member zero hain unhe pehle hi mita do, phir bache huye joints par method of joints lagao. Dhyan sirf do cheezon par: joint par external load hai ya nahi, aur members collinear hain ya nahi." },
        { k: "trap", t: "Joint par load ho to trick lagti hi nahi — eg ③ mein E par P laga hai, isliye ⑤ aur ⑥ zero nahi hain (T p.97). Aur support reaction bhi 'external load' hai." },
      ],
    },
    {
      n: "", title: "Method of joints and method of sections — T's worked numericals (T p.98–103)",
      hi: "जोड़ विधि और खंड विधि — T के हल किए गए उदाहरण",
      blocks: [
        { k: "h", t: "📘 Notes — method of joints (T p.98–101)" },
        { k: "steps", items: [
          "Step 1 — find all support reactions from the equations of statics. (T p.99)",
          "Step 2 — pick a joint with only <b>two</b> unknown forces and find them with ΣF<sub>x</sub> = 0, ΣF<sub>y</sub> = 0. (T p.99)",
          "Step 3 — repeat step 2 joint by joint until all joints are covered. (T p.99)",
        ] },
        { k: "eg", title: "Square truss by the method of joints (T p.99–101)",
          given: "Square truss ABCD, 5 m × 5 m: A bottom-left (hinged), B bottom-right (roller), D top-left, C top-right; diagonal AC. Loads: 10 N down at D, 10 N down at C, 10 N horizontal (to the right) at C. Find the reactions and all member forces.",
          steps: [
            { t: "ΣF_x = 0", w: "−H_A + 10 = 0  ⇒  H_A = 10 N (to the left)" },
            { t: "ΣF_y = 0", w: "R_A + R_B − 10 − 10 = 0  ⇒  R_A + R_B = 20" },
            { t: "ΣM_A = 0", w: "−R_B × 5 + 10 × 5 + 10 × 5 = 0  ⇒  R_B = 20 N ; R_A = 0" },
            { t: "Joint B", w: "ΣF_y: F_BC + 20 = 0  ⇒  F_BC = −20 N\nΣF_x: F_AB = 0" },
            { t: "Joint D", w: "F_DC = 0 ;  −10 − F_AD = 0  ⇒  F_AD = −10 N" },
            { t: "Joint C", w: "ΣF_x: −F_DC + 10 − F_AC/√2 = 0  ⇒  F_AC = 10√2 N" },
          ],
          ans: "AB = 0; AD = 10 N (compression); AC = 10√2 N (tension); BC = 20 N (compression); CD = 0. (T p.100–101)" },
        { k: "h", t: "📘 Notes — method of sections (T p.102–103)" },
        { k: "p", t: "Choose the section so that the members cut carry at most <b>three</b> unknowns. Step 1: support reactions from statics. Step 2: cut a section with at most three unknowns. Step 3: repeat until all member forces are found. (T p.102)" },
        { k: "eg", title: "Roof truss — forces in FH, GH and GI by the method of sections (T p.103)",
          given: "Symmetrical roof truss, span 6 panels @ 5 m = 30 m, central rise 8 m. Bottom joints A (hinged), C, E, G, I, K, L (roller); top joints B, D, apex F, H, J. Loads: 1 kN at B, D, F, H, J and 5 kN at C, E, G. Find the forces in FH, GH and GI.",
          steps: [
            { t: "Reactions", w: "ΣF_x = 0 ⇒ H₁ = 0 ; R₁ + R₂ = 20\nΣM_A: 6×5 + 6×10 + 6×15 + 1×20 + 1×25 − R₂×30 = 0\nR₂ = 7.5 kN ; R₁ = 12.5 kN" },
            { t: "Angles", w: "tan α = 8/15  ⇒  α = 28.07°\ntan(α + β) = 8/5  ⇒  α + β = 56.0°\nβ = 56 − 28.07 = 28.07°  [as written]" },
            { t: "Right-hand part: ΣF_x = 0, ΣF_y = 0, ΣM = 0", w: "F_IG = 13.13 kN (T)\nF_HF = 13.82 kN (C)\nF_HG = 1.371 kN (C)" },
          ],
          ans: "F_IG = 13.13 kN (tension), F_HF = 13.82 kN (compression), F_HG = 1.371 kN (compression). (T p.103)" },
        { k: "note", t: "<b>Check:</b> the three forces are right — taking moments about H (20 m, 5.33 m) for the right part: 7.5 × 10 − 1 × 5 = F<sub>IG</sub> × 5.333 ⇒ F<sub>IG</sub> = 13.125 kN; about G: 7.5 × 15 − 1 × 5 − 1 × 10 = F<sub>HF</sub> × (120/17 m) ⇒ F<sub>HF</sub> = 13.81 kN; then vertical equilibrium gives F<sub>HG</sub> = 1.371 kN. Only the angle lines are off: tan<sup>−1</sup>(8/5) = 57.99°, not 56.0°, and 56 − 28.07 = 27.93°, not 28.07°. Taking moments, as above, avoids the angles altogether and is the safer exam route." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Method of joints poore truss ke liye hai; method of sections tab jab sirf 2–3 members ki force chahiye. Sections mein trick yeh hai ki moment us point ke baare mein lo jahan doosre do unknown members milte hain — ek equation mein ek hi unknown bachta hai." },
        { k: "trap", t: "Force ka sign pehle se tension maan kar chalo; answer negative aaye to woh compression hai (jaise square truss mein F<sub>BC</sub> = −20 N ⇒ 20 N compression). Beech mein direction badalne se galti hoti hai." },
      ],
    },
  ]);

  /* ---------------- Chapter 13 — T p.169–171 ---------------- */
  ins(13, [
    {
      n: "", title: "Arch numericals from T — unequal supports and a horizontal load (T p.169–171)",
      hi: "T के आर्च संख्यात्मक — असमान सपोर्ट और क्षैतिज भार",
      blocks: [
        { k: "h", t: "📘 Notes — T p.169" },
        { k: "p", t: "<b>eg ① (T p.169):</b> two-hinged parabolic arch, span 30 m (5 m + 25 m), rise 6 m, a 40 kN load at 5 m from A. 'Calculate horizontal thrust? — this question is very complicated; it is a subjective question and is discussed later.' The notes do not solve it." },
        { k: "note", t: "<b>General Engineering Knowledge (not in T):</b> for a two-hinged parabolic arch with I = I<sub>0</sub> sec θ and a point load W at distance a from a springing, H = 5W·a(l − a)(l² + al − a²)/(8hl³). Here: 5 × 40 × 5 × 25 × (900 + 150 − 25)/(8 × 6 × 27000) = 19.77 kN. At a = l/2 this gives the crown result 25Wl/128h of section 13.5." },
        { k: "eg", title: "Three-hinged parabolic arch with supports at different levels (T p.169–170)",
          given: "A is 4 m below the crown C and B is 8 m below it. Horizontal distances: A to C = 6 m, C to B = 10 m. Udl 30 kN/m over the whole 16 m, plus a 300 kN point load 3 m to the right of the crown (7 m from B). Find V_A, V_B and H.",
          steps: [
            { t: "ΣF_y = 0", w: "V_A + V_B = 30 × 16 + 300 = 780 kN" },
            { t: "ΣM_C = 0, left part", w: "V_A × 6 − 30 × 6 × 3 − H_A × 4 = 0  ⇒  6V_A − 4H_A = 540  —(1)" },
            { t: "ΣM_C = 0, right part", w: "V_B × 10 − 30 × 10 × 5 − 300 × 3 − H_B × 8 = 0  ⇒  V_B − 0.8H = 240  —(2)" },
            { t: "With H_A = H_B, add", w: "V_A − 0.67H_A = 90\nV_B − 0.8H_A = 240\nV_A + V_B = 1.44H_A + 330  [as written]\n780 = 1.44H_A + 330" },
          ],
          ans: "H_A = H_B = 312.5 kN; V_A = 300 kN; V_B = 480 kN (as in the notes, T p.170)." },
        { k: "note", t: "<b>Check:</b> 2/3 + 0.8 = 1.4667, not 1.44. Then 450 = 1.4667 H ⇒ <b>H = 306.8 kN</b>, V<sub>A</sub> = 90 + (2/3)(306.8) = <b>294.5 kN</b>, V<sub>B</sub> = 240 + 0.8(306.8) = <b>485.5 kN</b>. Test the notes' answer in equation (1): 6 × 300 − 4 × 312.5 = 550 ≠ 540, so 312.5 does not satisfy it; 306.8 does." },
        { k: "eg", title: "Three-hinged parabolic arch with a vertical and a horizontal load (T p.170–171)",
          given: "Span 40 m, supports A and B level, crown C at mid-span. At a point 10 m from A, 3.75 m above the springing line, a 30 kN vertical load and a 20 kN horizontal load (acting to the right) are applied. Find V_A, V_B, H_A, H_B.",
          steps: [
            { t: "Rise of the arch (from y = 4hx(l − x)/l²)", w: "3.75 = 4h × 10 × 30/40²  ⇒  h = 5 m (used as 5 in the moment equations)" },
            { t: "ΣF_y = 0", w: "V_A + V_B = 30  —(i)" },
            { t: "ΣF_x = 0", w: "H_A + 20 − H_B = 0  ⇒  H_A − H_B = −20  —(ii)" },
            { t: "ΣM_C = 0, right part", w: "V_B × 20 − H_B × 5 = 0  ⇒  V_B = 0.25H_B  —(iii)" },
            { t: "ΣM_C = 0, left part", w: "V_A × 20 − H_A × 5 − 20 × 1.25 − 30 × 10 = 0  ⇒  V_A = 0.25H_A + 16.25  —(iv)" },
            { t: "Add (iii) and (iv), use (i)", w: "30 = 0.25(H_A + H_B) + 16.25  ⇒  H_A + H_B = 55  —(v)" },
            { t: "Solve (ii) and (v)", w: "−2H_B = −75  ⇒  H_B = 37.5 kN ; H_A = 17.5 kN" },
          ],
          ans: "H_A = 17.5 kN, H_B = 37.5 kN, V_A = 20.625 kN, V_B = 9.375 kN. (T p.171)" },
        { k: "p", t: "Re-check (all equations satisfied): 20.625 + 9.375 = 30 ✓; 17.5 + 20 − 37.5 = 0 ✓; 20 × 9.375 = 5 × 37.5 ✓; 20 × 20.625 − 5 × 17.5 − 25 − 300 = 0 ✓." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen hinge wale arch mein hamesha 4 unknown (V<sub>A</sub>, V<sub>B</sub>, H<sub>A</sub>, H<sub>B</sub>) aur 4 equations: ΣF<sub>x</sub>, ΣF<sub>y</sub>, aur crown hinge par do baar ΣM = 0 (left part se aur right part se). Support alag level par ho ya horizontal load ho — tareeqa wahi rehta hai, sirf lever arm dhyan se lena hai (crown ki height har support se alag)." },
        { k: "trap", t: "Horizontal load lagte hi H<sub>A</sub> ≠ H<sub>B</sub> ho jaata hai (yahan 17.5 aur 37.5 kN). 'H<sub>A</sub> = H<sub>B</sub>' sirf tab sach hai jab koi horizontal external load na ho." },
      ],
    },
  ]);
})();
