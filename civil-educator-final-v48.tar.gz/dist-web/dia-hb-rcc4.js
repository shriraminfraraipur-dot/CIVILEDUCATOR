/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 7–8
   Slabs · Columns
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 7.2 ONE-WAY / TWO-WAY */
  "hb-rcc-slabway": {
    label: "How a slab decides which way to span",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Two slab panels in plan. The long narrow panel carries load across the short direction only and is a one way slab. The nearly square panel shares the load between both directions and is a two way slab.">
      ${hbmk("sw")}
      <text class="em" x="168" y="26" text-anchor="middle">ly / lx &gt; 2 — ONE-WAY</text>
      <rect class="conc" x="46" y="50" width="244" height="120"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<line class="hi" x1="${64+i*30}" y1="56" x2="${64+i*30}" y2="164" marker-end="url(#sw-m)" marker-start="url(#sw-m)"/>`).join("")}
      <line class="s" x1="46" y1="50" x2="46" y2="170"/>
      <line class="s" x1="290" y1="50" x2="290" y2="170"/>
      <line class="thin dash" x1="46" y1="50" x2="290" y2="50"/>
      <line class="thin dash" x1="46" y1="170" x2="290" y2="170"/>
      <text class="lb" x="168" y="192" text-anchor="middle">lx (short)</text>
      <text class="lb" x="168" y="216" text-anchor="middle">the load takes the short route —</text>
      <text class="lb" x="168" y="236" text-anchor="middle">the long direction barely bends</text>
      <text class="ea" x="168" y="266" text-anchor="middle">main steel across lx</text>
      <text class="lb" x="168" y="288" text-anchor="middle">distribution steel the other way,</text>
      <text class="lb" x="168" y="308" text-anchor="middle">to spread load and resist shrinkage</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="314"/>

      <text class="em" x="524" y="26" text-anchor="middle">ly / lx ≤ 2 — TWO-WAY</text>
      <rect class="conc" x="424" y="50" width="200" height="150"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="hi" x1="${446+i*32}" y1="56" x2="${446+i*32}" y2="194" marker-end="url(#sw-m)" marker-start="url(#sw-m)"/>`).join("")}
      ${[0,1,2,3,4].map(i=>`<line class="ac" x1="430" y1="${68+i*30}" x2="618" y2="${68+i*30}" marker-end="url(#sw-c)" marker-start="url(#sw-c)"/>`).join("")}
      <line class="s" x1="424" y1="50" x2="424" y2="200"/><line class="s" x1="624" y1="50" x2="624" y2="200"/>
      <line class="s" x1="424" y1="50" x2="624" y2="50"/><line class="s" x1="424" y1="200" x2="624" y2="200"/>
      <text class="lb" x="524" y="222" text-anchor="middle">both directions bend —</text>
      <text class="lb" x="524" y="242" text-anchor="middle">the load splits between them</text>
      <text class="ea" x="524" y="270" text-anchor="middle">main steel BOTH ways</text>
      <text class="lb" x="524" y="292" text-anchor="middle">short-span bars go in the lower layer,</text>
      <text class="lb" x="524" y="312" text-anchor="middle">because they need the greater d</text>
    </svg>`,
    caption: "The load always takes the stiffer path, and stiffness goes as 1/L³. Double the span and that strip is eight times more flexible, which is why a panel longer than about twice its width sheds almost everything across the short direction.",
  },

  /* ---------------------------------------- 7.4 SPAN/DEPTH */
  "hb-rcc-spandepth": {
    label: "Why deflection, not strength, sizes a slab",
    svg: `<svg viewBox="0 0 700 260" role="img" aria-label="Two bar charts comparing a beam and a slab: for the beam the depth required by bending strength is close to the depth required by deflection, while for the slab the deflection requirement is far deeper than the strength requirement">
      ${hbmk("sd")}
      <text class="em" x="350" y="26" text-anchor="middle">WHAT ACTUALLY FIXES THE DEPTH</text>
      <line class="s" x1="90" y1="196" x2="620" y2="196"/>
      <line class="s" x1="90" y1="56" x2="90" y2="196"/>
      <text class="lb" x="80" y="60" text-anchor="end">depth</text>

      <rect class="soft" x="150" y="150" width="60" height="46"/>
      <rect class="softa" x="230" y="128" width="60" height="68"/>
      <text class="lb" x="220" y="216" text-anchor="middle">BEAM</text>
      <text class="lb" x="180" y="142" text-anchor="middle">strength</text>
      <text class="lb" x="260" y="120" text-anchor="middle">deflection</text>
      <text class="lb" x="220" y="240" text-anchor="middle">close together — either may govern</text>

      <rect class="soft" x="400" y="170" width="60" height="26"/>
      <rect class="softa" x="480" y="86" width="60" height="110"/>
      <text class="lb" x="470" y="216" text-anchor="middle">SLAB</text>
      <text class="lb" x="430" y="162" text-anchor="middle">strength</text>
      <text class="em" x="510" y="78" text-anchor="middle">deflection</text>
      <text class="em" x="470" y="240" text-anchor="middle">deflection wins, almost always</text>
      <line class="gl" x1="345" y1="46" x2="345" y2="230"/>
    </svg>`,
    caption: "A slab spans one metre of width carrying a few kN/m². The moment is small, so very little depth is needed for strength — but the same slab is thin and flexible, so it sags. The span/depth rule of Cl. 23.2.1 is therefore the first calculation in a slab design, not a check at the end.",
  },

  /* ---------------------------------------- 7.7 CORNER TORSION */
  "hb-rcc-corner": {
    label: "Why a restrained slab corner lifts, and what holds it down",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A two way slab panel in plan showing the corners tending to lift off their supports, and the mesh of torsion reinforcement provided in four layers over one fifth of the shorter span at each corner">
      ${hbmk("cn")}
      <text class="em" x="172" y="26" text-anchor="middle">THE CORNER WANTS TO LIFT</text>
      <rect class="conc" x="56" y="48" width="232" height="170"/>
      <path class="soft" d="M56 48 Q172 132 288 48 Q172 190 56 48 Z" opacity="0.35"/>
      <path class="hi" d="M76 70 L58 44" marker-end="url(#cn-m)"/>
      <path class="hi" d="M268 70 L286 44" marker-end="url(#cn-m)"/>
      <path class="hi" d="M76 196 L58 222" marker-end="url(#cn-m)"/>
      <path class="hi" d="M268 196 L286 222" marker-end="url(#cn-m)"/>
      <text class="lb" x="172" y="140" text-anchor="middle">the panel dishes downwards</text>
      <text class="lb" x="172" y="164" text-anchor="middle">in the middle …</text>
      <text class="lb" x="172" y="244" text-anchor="middle">… so the corners rotate up.</text>
      <text class="lb" x="172" y="266" text-anchor="middle">Held down, they twist instead — torsion.</text>

      <line class="gl" x1="352" y1="16" x2="352" y2="272"/>

      <text class="em" x="524" y="26" text-anchor="middle">CORNER REINFORCEMENT (Cl. D-1.8)</text>
      <rect class="conc" x="418" y="48" width="212" height="170"/>
      <rect class="softa" x="418" y="48" width="66" height="54"/>
      ${[0,1,2,3].map(i=>`<line class="steel" x1="${426+i*16}" y1="52" x2="${426+i*16}" y2="98"/>`).join("")}
      ${[0,1,2].map(i=>`<line class="steel" x1="422" y1="${58+i*16}" x2="480" y2="${58+i*16}"/>`).join("")}
      <line class="ac" x1="418" y1="116" x2="484" y2="116" marker-end="url(#cn-c)" marker-start="url(#cn-c)"/>
      <text class="ea" x="500" y="120">lx / 5</text>
      <text class="lb" x="524" y="244" text-anchor="middle">four layers — two top, two bottom —</text>
      <text class="lb" x="524" y="266" text-anchor="middle">each ¾ of the mid-span steel of the short span</text>
    </svg>`,
    caption: "A panel held down at its corners cannot lift, so the twist has to be resisted instead. Cl. D-1.8 is the answer: a mesh in four layers over a fifth of the shorter span. It is the most frequently omitted reinforcement in Indian slab detailing, and its absence shows up as diagonal cracks running across the corners of the ceiling.",
  },

  /* ---------------------------------------- 8.2 EFFECTIVE LENGTH */
  "hb-rcc-efflength": {
    label: "Effective length depends on what the ends are held by",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Four columns with different end restraints, each shown with the buckled shape and the theoretical effective length: both ends fixed giving half the height, one end fixed and one pinned, both ends pinned giving the full height, and a cantilever giving twice the height">
      ${hbmk("ef")}
      <text class="em" x="350" y="24" text-anchor="middle">SAME COLUMN, FOUR DIFFERENT EFFECTIVE LENGTHS</text>
      ${[
        ["both ends", "FIXED", "0.50 l", 92],
        ["one fixed,", "one pinned", "0.70 l", 252],
        ["both ends", "PINNED", "1.00 l", 412],
        ["fixed base,", "free top", "2.00 l", 572],
      ].map(([a, bLbl, v, x], i) => `
        <line class="s" x1="${x}" y1="60" x2="${x}" y2="210"/>
        <path class="hi" d="${[
          `M${x} 210 C${x - 26} 180 ${x + 26} 120 ${x} 60`,
          `M${x} 210 C${x - 30} 170 ${x + 20} 110 ${x} 60`,
          `M${x} 210 C${x - 34} 160 ${x - 34} 110 ${x} 60`,
          `M${x} 210 C${x} 150 ${x + 20} 100 ${x + 40} 60`,
        ][i]}"/>
        ${grd(x - 28, 214, 56)}
        ${i === 3 ? "" : `<line class="s" x1="${x - 24}" y1="56" x2="${x + 24}" y2="56"/>`}
        <text class="lb" x="${x}" y="240" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="258" text-anchor="middle">${bLbl}</text>
        <text class="em" x="${x}" y="284" text-anchor="middle">le = ${v}</text>`).join("")}
    </svg>`,
    caption: "The effective length is the length of the equivalent pin-ended column that would buckle at the same load. IS 456 Table 28 gives the values, and since the additional moment in a slender column goes as (le/D)², halving the effective length quarters it. Restraint is worth more than concrete.",
  },

  /* ---------------------------------------- 8.6 INTERACTION */
  "hb-rcc-interaction": {
    label: "The column interaction diagram",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="An axial load against moment interaction curve for a column, showing the pure axial capacity at the top, the balanced point at the nose where the moment capacity is greatest, the compression failure branch above it and the tension failure branch below it, ending at the pure bending capacity">
      ${hbmk("in")}
      <text class="em" x="350" y="26" text-anchor="middle">A COLUMN'S CAPACITY IS A CURVE, NOT A NUMBER</text>
      <line class="s" x1="120" y1="60" x2="120" y2="280"/>
      <line class="s" x1="120" y1="280" x2="560" y2="280"/>
      <text class="lb" x="108" y="66" text-anchor="end">Pu</text>
      <text class="lb" x="566" y="284">Mu</text>

      <path class="hi" d="M120 74 C230 84 318 126 344 186 C362 226 300 262 120 280"/>
      <circle class="hif" cx="120" cy="74" r="6"/>
      <circle class="hif" cx="348" cy="196" r="6"/>
      <circle class="hif" cx="120" cy="280" r="6"/>
      <text class="ea" x="132" y="70">Puz — pure axial</text>
      <text class="ea" x="360" y="192">BALANCED point</text>
      <text class="lb" x="360" y="212">largest moment the</text>
      <text class="lb" x="360" y="230">column can carry</text>
      <text class="ea" x="132" y="300">Mu — pure bending</text>

      <line class="thin dash" x1="120" y1="196" x2="348" y2="196"/>
      <text class="lb" x="236" y="122" text-anchor="middle">above the balanced point:</text>
      <text class="lb" x="236" y="140" text-anchor="middle">CONCRETE crushes first —</text>
      <text class="lb" x="236" y="158" text-anchor="middle">more axial load makes it WEAKER in bending</text>
      <text class="lb" x="252" y="252" text-anchor="middle">below it: STEEL yields first —</text>
      <text class="lb" x="252" y="270" text-anchor="middle">more axial load makes it STRONGER in bending</text>
      <text class="lb" x="350" y="326" text-anchor="middle">any (Pu, Mu) inside the curve is safe; outside it is not</text>
    </svg>`,
    caption: "This is why a column cannot be designed from one formula the way a beam can. Axial load and moment help each other below the balanced point and fight each other above it, so the check is always a point plotted against a curve — which is what the charts in SP:16 are.",
  },

  /* ---------------------------------------- 8.9 COLUMN TIES */
  "hb-rcc-ties": {
    label: "What lateral ties are actually for",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="On the left a column bar buckling outwards between widely spaced ties and spalling the cover. On the right correctly spaced ties with every alternate bar supported by a corner of a tie or a cross tie, holding the bars in place and confining the core">
      ${hbmk("ti")}
      <text class="em" x="168" y="26" text-anchor="middle">TIES TOO FAR APART</text>
      <rect class="conc" x="70" y="50" width="196" height="180"/>
      <line class="s" x1="100" y1="56" x2="100" y2="224"/>
      <path class="hi" d="M236 56 C206 110 266 166 236 224"/>
      <line class="steel" x1="86" y1="70" x2="250" y2="70"/>
      <line class="steel" x1="86" y1="210" x2="250" y2="210"/>
      <path class="soft-b" d="M256 120 L280 118 L280 162 L256 160 Z"/>
      <text class="em" x="168" y="252" text-anchor="middle">the bar buckles outward</text>
      <text class="lb" x="168" y="272" text-anchor="middle">and takes the cover with it</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="272"/>

      <text class="em" x="524" y="26" text-anchor="middle">TIES AT THE RIGHT PITCH</text>
      <rect class="conc" x="426" y="50" width="196" height="180"/>
      <line class="s" x1="456" y1="56" x2="456" y2="224"/>
      <line class="s" x1="592" y1="56" x2="592" y2="224"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="steel" x1="442" y1="${66+i*30}" x2="606" y2="${66+i*30}"/>`).join("")}
      <text class="lb" x="524" y="252" text-anchor="middle">pitch ≤ least of: least lateral dimension,</text>
      <text class="lb" x="524" y="272" text-anchor="middle">16 × smallest bar diameter, 300 mm (Cl. 26.5.3.2)</text>
    </svg>`,
    caption: "Lateral ties carry almost no load themselves. Their job is to stop the longitudinal bars from buckling outwards once the concrete around them starts to go, and to confine the core so that it keeps its strength after the cover has spalled. That is why the pitch rule is tied to the bar diameter, not to the load.",
  },

});
