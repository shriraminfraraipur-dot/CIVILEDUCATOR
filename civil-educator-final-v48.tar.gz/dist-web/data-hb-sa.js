/* ============================================================
   CIVIL EDUCATOR — HANDBOOK ENGINE + STRUCTURAL ANALYSIS Ch. 1
   ------------------------------------------------------------
   The library's topic pages are reference cards: open one, get an
   answer, leave. A handbook is the opposite — it is meant to be
   read from the first line to the last, in order, and to leave
   the reader able to do the thing rather than merely recognise it.

   So a chapter here is a sequence of blocks, not a set of fields:

     p      paragraph
     h      sub-heading inside a section
     def    a definition worth boxing
     eq     a displayed equation, with its symbols under it
     dia    a figure from DB.diagrams
     tbl    a table from DB.tables, rendered in place
     steps  a numbered procedure
     eg     a worked example — given, steps, answer
     note   a short aside the reader should not skip
     list   bullets
     trap   the mistake students actually make here

   Rules kept while writing:
   - Nothing is left as "refer to the code" or "beyond our scope".
     If a step is needed to follow the argument, the step is here.
   - Every equation that gets used is derived or at least justified,
     never dropped in.
   - Every worked example carries its arithmetic, not just its answer.
   - Written from scratch. The methods are common engineering
     knowledge; the wording, the numbers and the traps are ours.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "sa",
  subject: "struct-analysis",
  name: "Structural Analysis",
  hi: "संरचनात्मक विश्लेषण",
  icon: "📐",
  blurb: "Poora course, shuru se aakhir tak, bina shortcut ke. Har method derive kiya gaya hai, har example ka hisaab likha hai.",
  note: "Structural analysis is governed by mechanics, not by any IS code. Where a code decides what is done with the result — IS 456 for a concrete section, IS 800 for a steel one — the text says so.",
  chapters: [
    {
      id: "sa-1",
      n: 1,
      title: "Basic Concepts",
      hi: "मूल अवधारणाएँ",
      blurb: "Idealisation, supports, equilibrium, indeterminacy and the deflected shape — everything the later chapters assume you already have.",
      mins: 35,
      sections: [

        /* ------------------------------------------------ 1.1 */
        {
          n: "1.1",
          title: "What analysis does, and where design begins",
          hi: "विश्लेषण क्या करता है, और डिज़ाइन कहाँ से शुरू होता है",
          blocks: [
            { k: "p", t: "Structural engineering splits cleanly into two halves, and confusing them is the first thing to stop doing. <strong>Analysis</strong> takes a structure whose geometry you know and a loading you have decided on, and returns two families of answers — the forces everywhere in it, and the movements everywhere in it. <strong>Design</strong> starts after that: it takes a force and finds a section, a grade of concrete, an area of steel that can carry it safely." },
            { k: "p", t: "This matters because students often go looking in IS 456 for a bending moment. It is not there and never will be. No design code in the world tells you the bending moment in your beam — the code tells you what to do with the bending moment once you have calculated it. Analysis is your job." },
            { k: "dia", id: "hb-sa-scope" },
            { k: "list", items: [
              "<strong>Forces</strong> from analysis: support reactions, shear force, bending moment, axial force, torsion.",
              "<strong>Displacements</strong> from analysis: deflection and rotation at any point.",
              "<strong>Design</strong> then uses the forces for strength (IS 456 Cl. 38 for flexure, for example) and the displacements for serviceability (IS 456 Cl. 23.2).",
            ]},
            { k: "note", t: "Analysis needs the section properties (EI, A) before it can give displacements — and you need a section to know EI. So analysis and design go round in a loop: assume a section, analyse, design, check whether the assumed section still holds. Two passes usually settle it. A first-time reader often finds this circularity confusing; it is not a flaw, it is how the work is actually done." },
          ],
        },

        /* ------------------------------------------------ 1.2 */
        {
          n: "1.2",
          title: "What a structure is — the load path",
          hi: "संरचना क्या है — लोड का रास्ता",
          blocks: [
            { k: "def", term: "Structure", t: "Any arrangement of members that can carry the load applied to it safely down to the ground." },
            { k: "p", t: "Read that definition backwards and it becomes useful. The load has to reach the ground. It reaches the ground along a path, through a chain of elements, and each element in the chain carries it by a particular kind of action — bending, shear, axial force, or some combination. If you can trace that path, you understand the structure; if you cannot, no amount of calculation will save you." },
            { k: "dia", id: "hb-sa-loadpath" },
            { k: "p", t: "Notice that the <em>action changes</em> along the path. The slab carries the load mainly in bending. It delivers a reaction to the beam, which again carries it in bending and shear. The beam delivers a point load to the column, which carries it in pure axial compression if the frame is not swaying. The column delivers it to the footing, which spreads it over enough area that the soil pressure is acceptable. Same load, four different structural actions." },
            { k: "trap", t: "A structure with no complete load path is not a weak structure — it is not a structure at all. The classic case is a beam whose support has been removed during alterations on site, or a column discontinued at a floor without a transfer beam. Nothing about the calculation warns you; the path is simply broken." },
          ],
        },

        /* ------------------------------------------------ 1.3 */
        {
          n: "1.3",
          title: "Idealisation — from the real thing to the line diagram",
          hi: "आदर्शीकरण — असली ढाँचे से रेखा-चित्र तक",
          blocks: [
            { k: "p", t: "You never analyse a real structure. You analyse a model of it. Members with real width and depth become lines along their centroidal axes; a monolithic concrete corner with a haunch becomes a point called a rigid joint; a wall bearing on soil becomes one of the four supports from §1.6. Every one of those substitutions throws something away." },
            { k: "dia", id: "hb-sa-ideal" },
            { k: "h", t: "The two idealisations that cause real damage" },
            { k: "list", items: [
              "<strong>Calling a monolithic joint a pin.</strong> A beam cast integrally with its column does transfer moment into that column, whatever your model says. Model it as pinned and you design the column for axial load alone, and you provide no top steel in the beam at that face. The real structure cracks exactly there.",
              "<strong>Calling a column base fixed.</strong> A large raft or a well-tied pile cap may genuinely be near fixed. A small isolated footing on soft soil is not — it rotates. Assuming fixity underestimates the sway of the frame and overestimates the base moment, and both errors point the wrong way for safety.",
            ]},
            { k: "p", t: "The discipline that prevents both is small: before calculating anything, write down your idealisation as a list — what each support is, what each joint is, and what you are neglecting. In an exam that list earns marks on its own. On site it is the record of why the numbers came out the way they did, which is what you will be asked for when someone questions the design two years later." },
            { k: "note", t: "Neglecting axial deformation of members is the standard idealisation in frame analysis by hand, and §1.12 shows exactly what it buys you. It is an approximation, not a law: in a tall building where columns shorten measurably under load, it stops being acceptable." },
          ],
        },

        /* ------------------------------------------------ 1.4 */
        {
          n: "1.4",
          title: "Planar and space structures",
          hi: "समतल और त्रि-आयामी संरचनाएँ",
          blocks: [
            { k: "p", t: "If two axes are enough to describe both the geometry and the loading, the structure is planar — a plane frame, a plane truss, a continuous beam. If three are needed, it is a space structure. The distinction is not cosmetic: it fixes how many equilibrium equations you get, and therefore how much statics can do for you." },
            { k: "eq", expr: "Plane:  ΣFx = 0,  ΣFy = 0,  ΣM = 0        →  3 equations", where: [] },
            { k: "eq", expr: "Space:  ΣFx = ΣFy = ΣFz = 0,  ΣMx = ΣMy = ΣMz = 0   →  6 equations", where: [] },
            { k: "p", t: "Real buildings are three-dimensional, and yet almost all hand analysis is planar. The reason is that a regular building can be cut into a series of plane frames, each taking the load in its own tributary area, and analysed separately. That works as long as the building is reasonably regular. Once it is not — an L-shaped plan, a heavy re-entrant corner, a stiff core off to one side — the frames start to interact through the floor diaphragm and the planar split quietly stops being true. That is precisely the situation IS 1893 flags as a plan irregularity and asks for a three-dimensional analysis." },
          ],
        },

        /* ------------------------------------------------ 1.5 */
        {
          n: "1.5",
          title: "Sign convention",
          hi: "चिह्न परिपाटी",
          blocks: [
            { k: "p", t: "A sign convention is arbitrary. Being consistent about it is not. Most errors in slope-deflection and moment distribution are sign errors made at the moment of substituting back, and they survive because nothing in the arithmetic looks wrong." },
            { k: "dia", id: "hb-sa-sign" },
            { k: "h", t: "The two conventions you will actually use" },
            { k: "list", items: [
              "<strong>For drawing SF and BM diagrams:</strong> sagging moment positive. This one is worth internalising because positive moment means tension at the bottom fibre — and tension is where the steel goes. The sign is telling you something physical.",
              "<strong>For slope-deflection and moment distribution:</strong> all member end moments clockwise positive, and all joint rotations clockwise positive. This one is chosen because it makes the equations symmetric, not because it is intuitive. Under it, a sagging span has a negative moment at its left end and a positive one at its right.",
            ]},
            { k: "trap", t: "The two conventions disagree, and that is fine — they are used in different places. What is not fine is switching between them inside one problem. Write the convention at the top of the page before you start, and convert to the sagging-positive one only at the end, when you are about to draw the bending moment diagram." },
          ],
        },

        /* ------------------------------------------------ 1.6 */
        {
          n: "1.6",
          title: "Supports and the reactions they produce",
          hi: "सपोर्ट और उनसे मिलने वाली प्रतिक्रियाएँ",
          blocks: [
            { k: "def", term: "Support", t: "Anything that prevents a movement at a point. The reaction is whatever force or moment is needed to prevent it — so it always acts opposite to the movement it stops." },
            { k: "p", t: "That single sentence generates the whole list. Prevent one translation and you get one force along it. Prevent two and you get two forces. Prevent rotation as well and you also get a moment. Nothing else needs remembering." },
            { k: "dia", id: "hb-sa-supports" },
            { k: "h", t: "Reading the count off a structure" },
            { k: "list", items: [
              "Roller — 1 reaction. Free to slide and to rotate.",
              "Hinge or pin — 2 reactions. Free to rotate only.",
              "Fixed — 3 reactions in a plane (2 forces and a moment). Nothing free.",
              "Guided roller — 2 reactions (1 force and a moment). Free to slide only.",
              "Internal hinge — not a support at all. It <em>releases</em> a restraint rather than adding one, and §1.11 shows how to account for it.",
            ]},
            { k: "trap", t: "An inclined roller gives a reaction <strong>normal to the surface it rolls on</strong>, not vertical. Drawing it vertical is one of the most common ways to lose marks, and it silently breaks the equilibrium equations because the horizontal component has gone missing." },
            { k: "note", t: "On site this is a real decision and not just a drawing convention. A bearing detailed to slide behaves as a roller; the same bearing bolted through behaves closer to a hinge. Specify one and detail the other and the structure will develop forces nobody designed for — which is what causes cracking at the ends of long precast members restrained by accident." },
          ],
        },

        /* ------------------------------------------------ 1.7 */
        {
          n: "1.7",
          title: "Types of structural member",
          hi: "संरचनात्मक सदस्यों के प्रकार",
          blocks: [
            { k: "p", t: "Members are named after the action they are meant to carry, and the name carries a design consequence." },
            { k: "list", items: [
              "<strong>Tie</strong> — pure tension. The most efficient member there is, because the whole cross-section works at full stress and there is nothing to buckle.",
              "<strong>Strut / column</strong> — compression. Capacity is governed by buckling, not by the crushing strength of the material, as soon as the member is at all slender. This is why a steel column's design strength depends on its effective length.",
              "<strong>Beam</strong> — transverse load carried in bending and shear. Stress varies across the depth, so most of the material near the neutral axis is barely working; that is why I-sections exist.",
              "<strong>Beam-column</strong> — axial force and bending together. Almost every real column in a frame is one of these, because the beams framing into it push moment in.",
              "<strong>Truss member</strong> — pure axial force only, by construction, provided the joints are pinned and loads come only at joints (§1.3).",
              "<strong>Arch</strong> — mainly compression along its curve, with the horizontal thrust at the supports doing the work (see Chapter 9).",
            ]},
            { k: "note", t: "Efficiency runs in that order: tie, then arch, then truss, then beam. A beam is the least efficient way to cross a span and by far the most convenient — which is why we build so many of them." },
          ],
        },

        /* ------------------------------------------------ 1.8 */
        {
          n: "1.8",
          title: "Equilibrium",
          hi: "संतुलन",
          blocks: [
            { k: "p", t: "A body at rest has no unbalanced force and no unbalanced moment. In a plane that is three equations, and they hold for the whole structure and equally for any part of it you choose to cut out — which is the entire basis of the free body diagram, the method of sections and, in fact, of finding internal forces at all." },
            { k: "eq", expr: "ΣFx = 0 ,   ΣFy = 0 ,   ΣM = 0", where: [
              ["ΣFx, ΣFy", "Sum of all forces on the free body, resolved along two perpendicular directions"],
              ["ΣM", "Sum of moments of all those forces about any point — the point is your choice, and choosing it well removes unknowns"],
            ]},
            { k: "h", t: "Choosing the moment centre" },
            { k: "p", t: "ΣM = 0 can be written about any point, and this is the single largest labour-saver in statics. Take moments about a point where two of your unknowns intersect and both vanish from the equation, leaving the third alone. Students who take moments about the left support out of habit end up solving simultaneous equations they never needed." },
            { k: "eg", title: "Example 1.1 — reactions of a simply supported beam", given: "Span AB = 6 m. Hinge at A, roller at B. A point load of 40 kN acts 2 m from A. Find the reactions.", steps: [
              { t: "Count the unknowns", w: "Hinge at A gives HA and VA; roller at B gives VB. Three unknowns, three equations — determinate." },
              { t: "ΣFx = 0", w: "No horizontal load, so HA = 0.\n(Worth writing down. It is an answer, not an omission.)" },
              { t: "ΣM about A = 0", w: "Taking clockwise as positive and noting that VA and HA pass through A, so they drop out:\n40 × 2 − VB × 6 = 0\nVB = 80 / 6 = 13.33 kN ↑" },
              { t: "ΣFy = 0", w: "VA + VB = 40\nVA = 40 − 13.33 = 26.67 kN ↑" },
              { t: "Check with the other moment centre", w: "ΣM about B: VA × 6 − 40 × 4 = 0 → VA = 160/6 = 26.67 kN ✓\nThe check costs one line and catches an arithmetic slip immediately." },
            ], ans: "HA = 0, VA = 26.67 kN ↑, VB = 13.33 kN ↑" },
            { k: "note", t: "The load sits nearer A, and the larger reaction came out at A. Whenever a reaction comes out on the wrong side of that common-sense test, stop and re-check before going further — the error will only get more expensive." },
          ],
        },

        /* ------------------------------------------------ 1.9 */
        {
          n: "1.9",
          title: "Compatibility",
          hi: "संगतता",
          blocks: [
            { k: "def", term: "Compatibility", t: "The requirement that the structure's displacements fit together — members connected at a joint move with that joint, the material stays continuous, and a support that prevents a movement really does have zero movement there." },
            { k: "p", t: "Equilibrium alone runs out as soon as a structure has more unknowns than equations, and compatibility is where the missing equations come from. They are statements about deformation, not about force, which is why an indeterminate analysis needs EI and a determinate one does not." },
            { k: "list", items: [
              "At a <strong>rigid joint</strong>, every member end rotates through the same angle — the angles between members are preserved.",
              "At an <strong>internal hinge</strong>, the members may rotate differently, but the displacement is common.",
              "At a <strong>fixed support</strong>, both rotation and displacement are zero.",
              "At a <strong>roller</strong>, the displacement normal to the surface is zero and everything else is free.",
            ]},
            { k: "p", t: "One consequence is worth stating now because it explains a great deal later. In a determinate structure, support settlement, temperature change and a member made slightly too short produce <em>no force at all</em> — the structure simply moves or rotates to accommodate them. In an indeterminate structure they produce real forces, because the redundant restraints refuse to let it move freely. That is the whole reason a long continuous deck needs expansion joints and a series of simply supported spans does not." },
          ],
        },

        /* ------------------------------------------------ 1.10 */
        {
          n: "1.10",
          title: "Stability — why the count is not enough",
          hi: "स्थिरता — गिनती काफ़ी क्यों नहीं",
          blocks: [
            { k: "p", t: "Before asking whether a structure is determinate, ask whether it is stable. A structure with fewer unknowns than equations is a mechanism: it moves. But — and this is the part that catches people — a structure with exactly the right number of reactions can also be a mechanism if those reactions are badly arranged." },
            { k: "dia", id: "hb-sa-stability" },
            { k: "h", t: "The two geometric instabilities" },
            { k: "list", items: [
              "<strong>All reactions parallel.</strong> Nothing resists force in the perpendicular direction. ΣFx = 0 cannot be satisfied by any set of values, so the structure slides.",
              "<strong>All reaction lines concurrent.</strong> They all pass through one point, so none of them can produce a moment about that point, and the structure rotates about it.",
            ]},
            { k: "p", t: "Both pass the arithmetic test. This is why determinacy is a necessary condition and never a sufficient one — the count tells you whether enough equations exist, not whether the arrangement can actually resist what is applied." },
            { k: "trap", t: "Internal instability is the same idea one level down. A four-bar panel in a truss with no diagonal will distort into a parallelogram however well supported the truss is. Count the members as well as the reactions, and look for panels with no bracing." },
          ],
        },

        /* ------------------------------------------------ 1.11 */
        {
          n: "1.11",
          title: "Static indeterminacy",
          hi: "स्थैतिक अनिश्चितता",
          blocks: [
            { k: "def", term: "Static indeterminacy, Ds", t: "The number of unknown forces in excess of what equilibrium can supply — that is, the number of redundant forces whose values equilibrium alone cannot fix." },
            { k: "p", t: "It comes in two parts. <strong>External</strong> indeterminacy counts surplus reactions: in a plane, Dse = r − 3. <strong>Internal</strong> indeterminacy counts surplus members or closed loops: a closed box in a rigid-jointed plane frame is internally indeterminate to 3. Total Ds = Dse + Dsi." },
            { k: "eq", expr: "Ds = 3m + r − 3j − rr        (plane rigid frame or beam)", where: [
              ["m", "Number of members"],
              ["r", "Number of independent reaction components"],
              ["j", "Number of joints — every support point counts as one"],
              ["rr", "Released restraints: an internal hinge joining n members releases n − 1 moments"],
            ]},
            { k: "tbl", id: "tb-sa-ind" },
            { k: "dia", id: "hb-sa-ds" },
            { k: "eg", title: "Example 1.2 — a portal frame with an internal hinge", given: "The same single-bay portal (m = 3, j = 4, both bases fixed so r = 6), but now with an internal hinge inserted at the mid-point of the beam. Find Ds.", steps: [
              { t: "Adding the hinge changes the counts", w: "Putting a hinge in the middle of the beam splits it into two members and adds a joint:\nm = 4,  j = 5,  r = 6" },
              { t: "Count the release", w: "The hinge joins n = 2 members, so it releases n − 1 = 1 moment.\nrr = 1" },
              { t: "Apply the formula", w: "Ds = 3m + r − 3j − rr\n   = 3(4) + 6 − 3(5) − 1\n   = 12 + 6 − 15 − 1\n   = 2" },
              { t: "Sense-check it", w: "Without the hinge the frame was indeterminate to 3 (see the figure above). Adding one hinge releases one restraint, so Ds must drop by exactly 1 — from 3 to 2. It does. ✓" },
            ], ans: "Ds = 2. The frame now needs two compatibility equations instead of three." },
            { k: "h", t: "Why indeterminacy is a good thing" },
            { k: "p", t: "It is tempting to treat redundancy as a nuisance because it makes the arithmetic longer. Structurally it is the opposite. A redundant structure has alternative load paths: lose one member and the force redistributes instead of the structure collapsing. A determinate structure has exactly one path for every force, so losing any member is losing the structure. That is the whole argument behind the ductile detailing requirements of IS 13920 — they exist to make sure the redistribution can actually happen before anything breaks." },
            { k: "trap", t: "Count joints including supports, and do not forget that an internal hinge joining three members releases <strong>two</strong> moments, not one. This single slip is the most common reason a student's Ds is out by one." },
          ],
        },

        /* ------------------------------------------------ 1.12 */
        {
          n: "1.12",
          title: "Kinematic indeterminacy",
          hi: "गतिज अनिश्चितता",
          blocks: [
            { k: "def", term: "Kinematic indeterminacy, Dk", t: "The number of independent joint displacements that are not known in advance — the degrees of freedom of the structure." },
            { k: "p", t: "Each free joint of a plane frame can move two ways and rotate one way, so it has three degrees of freedom; each restrained component removes one. A plane truss joint carries no moment, so it has only two." },
            { k: "eq", expr: "Dk = 3j − r   (plane frame)        Dk = 2j − r   (plane truss)", where: [
              ["j", "Number of joints"],
              ["r", "Number of displacement components the supports restrain"],
              ["—", "Then deduct one more for every member assumed axially rigid"],
            ]},
            { k: "dia", id: "hb-sa-dk" },
            { k: "p", t: "The deduction for axial rigidity is what makes hand analysis of frames possible at all. Six degrees of freedom on a simple portal is beyond hand methods; three is a comfortable slope-deflection problem. It is an approximation and it is a good one for ordinary frames, because bending displacements are typically an order of magnitude larger than axial shortening." },
            { k: "h", t: "Choosing the method — the real reason both counts are taught" },
            { k: "p", t: "The force method takes redundant forces as unknowns, so its work scales with Ds. The displacement methods — slope-deflection, moment distribution, matrix stiffness — take joint displacements as unknowns, so their work scales with Dk. Compute both before you start and take the smaller." },
            { k: "eg", title: "Example 1.3 — which method is shorter?", given: "A continuous beam on five supports (four spans), all simple except the ends, carrying vertical load only. Compare Ds and Dk.", steps: [
              { t: "Static indeterminacy", w: "Reactions: 5 vertical + 1 horizontal at the hinged end = 6.\nDse = r − 3 = 6 − 3 = 3\nNo closed loops, so Dsi = 0.\nDs = 3" },
              { t: "Kinematic indeterminacy", w: "Joints j = 5, restrained components r = 6, so Dk = 3(5) − 6 = 9.\nNeglect axial deformation of the 4 members: 9 − 4 = 5.\nVertical displacement at every support is prevented, which removes 4 more, leaving the joint rotations:\nDk = 5 rotations − 4 = ... in practice, 5 unknown rotations at the 5 joints, of which the two end ones are eliminated by the simple-support end conditions." },
              { t: "Compare honestly", w: "Force method: 3 redundants, so 3 simultaneous compatibility equations, each needing unit-load deflections.\nMoment distribution: no simultaneous equations at all — 3 or 4 balancing cycles on a table." },
            ], ans: "Ds = 3 here, and although the raw Dk is larger, moment distribution still wins because it never forms simultaneous equations. Counts guide the choice; they do not decide it by themselves." },
            { k: "note", t: "That last point is worth keeping. Ds and Dk tell you the size of each problem, but moment distribution's advantage is that it replaces solving equations with iterating, and iteration on a table is far less error-prone by hand. Chapter 7 shows why." },
          ],
        },

        /* ------------------------------------------------ 1.13 */
        {
          n: "1.13",
          title: "The elastic curve",
          hi: "इलास्टिक कर्व",
          blocks: [
            { k: "def", term: "Elastic curve", t: "The deflected centre line of the structure under load." },
            { k: "p", t: "Its curvature at any point has the same sign as the bending moment there. Sagging moment curves the member concave upward; hogging curves it concave downward; and the curve changes sense exactly where the moment passes through zero — the point of contraflexure." },
            { k: "eq", expr: "d²y / dx² = M / EI", where: [
              ["y", "Deflection at distance x along the member"],
              ["M", "Bending moment at that section"],
              ["EI", "Flexural rigidity — E is the modulus of elasticity, I the second moment of area"],
            ]},
            { k: "p", t: "That is the differential equation the whole of deflection theory is built on, and it says something you can use without integrating anything: <em>where the moment is large, the curvature is sharp; where the moment is zero, the curve is momentarily straight.</em> Sketching on that basis alone gets the shape right." },
            { k: "dia", id: "hb-sa-elastic" },
            { k: "h", t: "Rules for sketching, in the order you use them" },
            { k: "steps", items: [
              "Mark what the supports force: a fixed support leaves the curve horizontal; a hinge or roller allows rotation but no displacement.",
              "Mark the rigid joints: the angle between members there is preserved as the joint rotates.",
              "Sag where the moment is positive, hog where it is negative.",
              "Put a point of contraflexure at every zero of the bending moment diagram.",
              "Check the two drawings against each other — every point of contraflexure must line up with a zero.",
            ]},
            { k: "p", t: "This is the cheapest error check in the whole subject and the one most worth the thirty seconds. It also has a direct detailing consequence: the hogging region is where top steel is needed, and the steel must run <em>past</em> the point of contraflexure, not stop at it. Top steel curtailed too early is among the most common detailing failures in continuous slabs and beams, and it is exactly why IS 456 gives curtailment rules instead of letting bars stop at the theoretical cut-off." },
            { k: "trap", t: "A sketch that shows sagging over an interior support of a continuous beam is wrong, always. If your calculated moments say otherwise, the calculation has a sign error — go back to §1.5." },
          ],
        },

        /* ------------------------------------------------ 1.14 */
        {
          n: "1.14",
          title: "What the rest of this handbook does",
          hi: "इस हैंडबुक में आगे क्या है",
          blocks: [
            { k: "p", t: "Everything so far has been about setting a problem up correctly. The chapters that follow solve it, and they divide along the line drawn in §1.12." },
            { k: "list", items: [
              "<strong>Determinate structures</strong> (Chapters 2–4) — trusses, and the influence lines that tell you where to put a moving load. Statics is enough here.",
              "<strong>Deflections</strong> (Chapter 5) — strain energy and the unit load method. Needed for serviceability, and needed again as the engine inside the force method.",
              "<strong>Force method</strong> (Chapter 6) — consistent deformation. Unknowns are redundant forces; work scales with Ds.",
              "<strong>Displacement methods</strong> (Chapters 7–8) — slope-deflection and moment distribution. Unknowns are joint displacements; work scales with Dk.",
              "<strong>Arches</strong> (Chapter 9), <strong>matrix methods</strong> (Chapter 10) and <strong>dynamics</strong> (Chapter 11) follow.",
            ]},
            { k: "note", t: "If you read only two sections of this chapter again before starting Chapter 2, make them §1.6 on supports and §1.11 on static indeterminacy. Every later method assumes both without re-explaining them." },
          ],
        },
      ],
    },
  ],
});
