/* Surveying class notes — Chain and tape surveying (linear measurement, terms, equipment, ranging, slopes, standardisation and slope corrections), notes p.116–132 — inserted into sv chapter 3 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 3; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- units + principle */
    {
      n: "",
      title: "Notes — Units, linear measurement and the principle of chain surveying",
      hi: "इकाइयाँ, रेखीय मापन और चेन सर्वेक्षण का सिद्धांत",
      blocks: [
        { k: "h", t: "📘 Notes — p.116–117" },
        { k: "cmp", t: "Units of measurement (p.116)", cols: ["Equals"], rows: [
          ["1 foot", "0.3048 m"],
          ["1 yard", "3 feet"],
          ["1 mile", "5280 feet"],
          ["1 mile", "1.609 km"],
          ["1 sq. mile", "2.590 km²"],
          ["1 sq. mile", "640 acre"],
          ["1 acre", "43560 ft²"],
          ["1 hectare", "2.471 acre"],
        ] },
        { k: "def", term: "Linear measurement", t: "Survey (of linear measurement) is often referred to as <b>chain survey</b>. In chain surveying the distance between two points is generally considered as the <b>horizontal distance</b>. (p.116)" },
        { k: "def", term: "Procedure in chain surveying", t: "Chain surveying consists of measuring the lengths of a series of <b>straight lines</b> with chain or tape and then locating the details on the ground relative to these lines. The details are located either by measuring to other lines, known as <b>tie lines</b>, or by measuring <b>offsets at right angles</b> to the main survey line. (p.116)" },
        { k: "h", t: "Two ways of locating a point C (p.117)" },
        { k: "list", items: [
          "<b>By tie lines</b> — C is located by measuring AC and BC. AC, BC = tie lines; AB = main survey line. Figure (p.117): triangle with vertical side AB (B at top, A at bottom) and apex C to the right; lines AC and BC drawn.",
          "<b>By offset</b> — C is located by the offset DC and measuring AD. Figure (p.117): vertical line with B at top, A at bottom; point D on it; DC drawn horizontally at right angles from D to C on the right (the offset).",
        ] },
        { k: "p", t: "When the area to be surveyed is large, using tie lines and the offset method, a <b>network of triangles</b> covering the whole area is made, and details are noted with the help of tie lines or by the offset method. (p.117)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Chain survey me angle kabhi nahi naapa jaata — sirf lambaai. Isliye ek point C ko fix karne ke do hi tareeke hain: ya to do known points A aur B se uski doori naap lo (tie lines AC, BC — jaise compass se do arcs kaatna), ya line AB par chalte hue jahan C saamne aaye wahan ruk kar AD naapo aur phir right angle par DC naapo (offset). Dono me C ka position sirf lengths se tay ho jaata hai. Badi area ke liye yahi idea triangles ke jaal (network) me badal jaata hai — section 3.2 dekho." },
        { k: "trap", t: "\"Distance\" in chain surveying always means <b>horizontal</b> distance. A length taped along sloping ground is not yet the plotted distance — it must be stepped or corrected for slope (see the slope sections below)." },
        { k: "real", t: "Old land records and village maps in India use feet, chains and acres; the conversions on p.116 (1 ft = 0.3048 m, 1 acre = 43560 ft², 1 ha = 2.471 acre) are what you need to read them against a metric plan." },
      ],
    },

    /* ---------------------------------------------------------- terms */
    {
      n: "",
      title: "Notes — Chain survey terms: stations, lines, offsets, chainage",
      hi: "चेन सर्वे की परिभाषाएँ — स्टेशन, रेखाएँ, ऑफ़सेट, चेनेज",
      blocks: [
        { k: "h", t: "📘 Notes — p.117–119" },
        { k: "p", t: "<b>Figure (p.117) — \"Basic definition\":</b> a four-sided survey figure with main stations B (top), A (right), D (bottom) and C (left); sides BA, AD, DC, CB and the diagonal BD (nearly vertical) are drawn. Point e lies on CB and f on CD, with line e–f joining them (vertical). Point h lies on BA and g on BD, with a dashed line h–g. Point i lies on BD near the top with a dashed line from i to h. A red line runs from C to k on BD, and a red line from A to j on BD. A small rectangle (an object/building) is drawn just right of line ef, its corners marked 1, 2, 3; points 6, 7, 8 are marked on line ef opposite 1, 2, 3 (the offsets). Small tick marks appear on sides BA and AD." },
        { k: "def", term: "Main stations", t: "A main station is a point in chain survey where two sides of a triangle meet. These stations <b>command the boundary</b>. A, B, C, D are main stations. (p.118)" },
        { k: "def", term: "Tie station (Subsidiary station)", t: "A tie station is a station on a survey line which joins two main stations. These are helpful in locating the <b>interior details</b> of the area to be surveyed. E, F, G, J, I are tie stations. (p.118)" },
        { k: "def", term: "Main survey line", t: "A survey line or chain line joining two main stations is called a main survey line. AB, DB, BC, CA are main survey lines. (p.118)" },
        { k: "def", term: "Tie line (Subsidiary line / Auxiliary line)", t: "A chain line joining two tie stations is called a tie line or subsidiary line; this line is also called an <b>auxiliary line</b>. Auxiliary lines are provided to note the interior details which are far away from the main survey line. EF, GH, HI are tie lines (auxiliary lines). (p.118)" },
        { k: "def", term: "Base line", t: "The <b>longest</b> main survey line, which divides the survey area into two parts. It passes through the centre of the survey area. It is the <b>most important line</b>, as the directions of the other lines are fixed with reference to this line. AB is the base line. (p.119)" },
        { k: "def", term: "Check line / Proof line", t: "Also called a proof line, it is provided to check the accuracy of the survey work: the <b>measured length and the calculated length must be the same</b>. CK and Di are check lines. (p.119)" },
        { k: "def", term: "Offsets", t: "The distance of an object from the survey line. It may be <b>perpendicular or oblique</b>. 1–6, 2–7, 3–8 are offsets. (p.119)" },
        { k: "def", term: "Chainage", t: "The distance measured along the survey line in the <b>direction of progress</b> of the work. (p.119)" },
        { k: "note", t: "Reading the figure: the station and line labels above are kept exactly as the notes list them (e.g. \"CA\" among main survey lines, \"AB is base line\", check lines \"CK and Di\"). In the sketch itself the drawn sides are BA, AD, DC, CB with BD as the long line through the middle, and the two red lines are C–k and A–j — keep that in mind if you redraw it. (p.117–119)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek hierarchy socho: <b>main stations</b> boundary ke kone hain → unko jodne wali <b>main survey lines</b> triangles banati hain → in lines par beech me <b>tie stations</b> → do tie stations ko jodne wali <b>tie line</b> andar ki detail tak pahunchti hai → detail ko line se jodne wala chhota naap <b>offset</b> hai. Sabse lambi line jo area ke beech se jaati hai woh <b>base line</b> hai — baaki sab usi se orient hote hain. <b>Check line</b> ka kaam sirf ek hai: jo length naapi aur jo plot/calculate se aayi, dono match karein — tabhi survey par bharosa." },
        { k: "p", t: "Section 3.2 me yahi framework explain hai — check line kyun survey ko 'defensible' banati hai aur offsets chhote kyun hone chahiye." },
        { k: "trap", t: "Do not mix up <b>tie line</b> and <b>check line</b>. A tie line joins two <i>tie stations</i> to pick up interior detail; a check (proof) line exists to compare measured length with calculated length. A line can serve both purposes, but the definitions are different and MCQs test the definition." },
        { k: "real", t: "Chainage is written in the field book as distance from the start of the line in the direction of work — e.g. an offset to a building corner is booked as \"chainage 46.2 m, offset 8.5 m right\"." },
      ],
    },

    /* ---------------------------------------------------------- well-conditioned triangle */
    {
      n: "",
      title: "Notes — Well-conditioned triangle",
      hi: "सुस्थित त्रिभुज (वेल-कंडीशन्ड ट्रायंगल)",
      blocks: [
        { k: "h", t: "📘 Notes — p.120" },
        { k: "p", t: "In chain surveying, attempts should be made to select survey stations such that they form <b>well-conditioned triangles</b>. (p.120)" },
        { k: "def", term: "Well-conditioned triangle", t: "A triangle is said to be well conditioned if <b>all intersections of its lines are clearly visible</b>. (p.120)" },
        { k: "list", items: [
          "Figure (p.120, left) — \"well-conditioned triangle\": triangle ABC with A at top, B bottom-left, C bottom-right; the lines cross at each vertex at large angles; each intersection (A, B, C) circled.",
          "Figure (p.120, right) — \"Not well-conditioned triangle\": a long thin triangle — near-vertical line through A (top) and B (bottom) at left, two long nearly-parallel lines from A and B meeting at C far to the right at a very small angle; intersections circled; note: \"intersection of C is not clearly visible\".",
        ] },
        { k: "note", t: "<b>Note:</b> if the angle between the lines is between <b>30° and 120°</b>, clear intersections are achieved, and an <b>equilateral triangle</b> is the most appropriate well-conditioned triangle. (p.120)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Jab do lines bahut chhote angle par milti hain, to unka crossing point ek lambi 'patti' jaisa dikhta hai — exact kahan mila, pata hi nahi chalta. Thoda sa bhi galti lambaai me ho to apex door khisak jaata hai. 30° se 120° ke beech har kone par lines saaf cross karti hain. Equilateral (har angle 60°) sabse safe hai kyunki koi bhi angle extreme ke paas nahi hai." },
        { k: "trap", t: "The limits are <b>30° to 120°</b> — not 30° to 90°. An angle of 100° is still acceptable; a triangle with one 15° angle is not, even if the other two look fine." },
      ],
    },

    /* ---------------------------------------------------------- chains + tapes */
    {
      n: "",
      title: "Notes — Chains and tapes",
      hi: "चेन और टेप के प्रकार",
      blocks: [
        { k: "h", t: "📘 Notes — p.120–122" },
        { k: "h", t: "(1) Types of chain (p.120)" },
        { k: "cmp", cols: ["Length", "No. of links"], rows: [
          ["(i) Revenue chain", "33 feet", "16 links"],
          ["(ii) Gunter's chain", "66 feet", "100 links"],
          ["(iii) Engineer's chain", "100 feet", "100 links"],
          ["(iv) Metric chain", "30 m", "150 links"],
          ["(iv) Metric chain", "20 m", "100 links"],
        ] },
        { k: "list", items: [
          "As per IS code specification, every metre length of chain should be individually accurate to within <b>±2 mm</b>, when measured under a pull of <b>80 N</b>. (p.121)",
          "The overall length of chain should be within the limits given below — (a) <b>20 m ± 5 mm</b> for 20 m chain; (b) <b>30 m ± 8 mm</b> for 30 m chain. (p.121)",
        ] },
        { k: "h", t: "(2) Tapes (p.121–122)" },
        { k: "def", term: "(i) Cloth or linen tape", t: "Closely woven linen or synthetic material, <b>varnished</b> to resist moisture. Available in lengths of <b>10 to 30 m</b> and width <b>12 to 15 mm</b>. (p.121)" },
        { k: "def", term: "(ii) Metallic tape", t: "A linen tape with <b>brass or copper wires</b> woven into it longitudinally to reduce stretching. (p.121)" },
        { k: "def", term: "(iii) Steel tape", t: "More accurate than metallic tape; made of steel or stainless steel strips. Available in length <b>1–50 m</b> and width <b>6–10 mm</b>. (p.121)" },
        { k: "def", term: "(iv) Invar tape", t: "Made of an alloy of <b>Nickel (36%) and Steel (64%)</b>. Available in lengths <b>30 m, 50 m and 100 m</b> and width <b>6 mm</b>. These tapes have a very low coefficient of thermal expansion — <b>0.122 × 10⁻⁶ /°C</b>. (p.122)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Accuracy ki seedhi: cloth/linen (stretch hota hai, sirf rough kaam/offset) → metallic (wire daal ke stretch kam) → steel (accurate, par dhoop me phailta hai) → invar (nickel-steel, temperature se lagbhag nahi phailta — base line jaise precise kaam ke liye). Chain ke liye link count yaad rakhne ka shortcut: metric chain me har link 20 cm hai, isliye 20 m = 100 links aur 30 m = 150 links. Purani chains ka itihas aur sources section 3.1 me hain." },
        { k: "trap", t: "Only the <b>20 m</b> metric chain has 100 links; the <b>30 m</b> chain has 150. Gunter's (66 ft) and engineer's (100 ft) chains both have 100 links, while the revenue chain (33 ft) has only 16 — a favourite one-mark question." },
        { k: "real", t: "Before starting work, a chain is laid against a standard length under the specified pull; if it is outside the tolerance (±5 mm on 20 m, ±8 mm on 30 m) it is adjusted, or its actual length is recorded so the standardisation correction can be applied later." },
      ],
    },

    /* ---------------------------------------------------------- accessories */
    {
      n: "",
      title: "Notes — Accessories: pegs, arrows, rods, cross-staffs, optical square, clinometer",
      hi: "सहायक उपकरण — खूँटी, तीर, रेंजिंग रॉड, क्रॉस-स्टाफ़, ऑप्टिकल स्क्वायर",
      blocks: [
        { k: "h", t: "📘 Notes — p.122–125" },
        { k: "def", term: "(i) Peg", t: "Used to mark definite points on the ground, either temporarily or semi-permanently. Figure (p.122): a long narrow rectangular wooden peg with a pointed (tapered) lower end; length marked <b>150 mm</b>. (p.122)" },
        { k: "def", term: "(ii) Arrow", t: "When measuring the length of a long line, the tape has to be laid down a number of times, and the positions of the ends are marked with arrows. Figure (p.122): a steel wire bent into a ring/loop at the top (loop marked <b>50 mm</b>) with a straight shank ending in a pointed tip; overall length <b>400 mm</b>; pointed tip <b>15 mm</b>. A second sketch shows a line A—B with a tick near A and an upward arrow labelled \"arrow\" pointing to it. (p.122)" },
        { k: "list", items: [
          "Arrows are used by the <b>leader</b> to mark the end stations, and are later collected by the <b>follower</b>. (p.123)",
          "The number of arrows in the hand of the follower indicates the number of chain lengths measured. (p.123)",
        ] },
        { k: "eg", title: "Notes example — Length from arrows held by the follower", given: "Chain length = 20 metre. Number of arrows in hand of follower = 5. Find the measured length.", steps: [
          { t: "Each arrow = one chain length", w: "Measured length = chain length × no. of arrows" },
          { t: "Substitute", w: "Measured length = 20 × 5 = 100 m" },
        ], ans: "Measured length = 100 m (p.123)" },
        { k: "def", term: "(iii) Ranging rods", t: "The process of locating a number of points on a long survey line is called <b>ranging</b> or ranging out. Ranging rods are used to locate intermediate points such that these points lie on the straight line joining the two end points. Ranging is a must before starting the measurement of a line whose length is more than the chain length. Ranging rods are <b>30 mm in diameter and 2–3 m long</b>, painted in alternate colours such as red and white, red and black, or black and white. Figure (p.123): vertical rod with a small flag at the top, body in alternate bands, pointed shoe at the bottom. (p.123)" },
        { k: "def", term: "(iv) Offset rod", t: "Similar to a ranging rod except that at the top an <b>open ring or hook</b> is provided. It is also provided with <b>two short narrow vertical slots at right angles</b> to each other passing through the centre of the section. Mainly used to align the offset line and measure short offsets. Figure (p.124): vertical rod with a hook at top, alternate bands, a small rectangular slot near the lower part, pointed lower end. (p.124)" },
        { k: "def", term: "(v) Cross staff (open cross-staff)", t: "Used to set out <b>right angles</b> to the survey line. Figure (p.124): two flat arms crossing at right angles, each arm end bent up as a vane with a small sight slit (four slits in all), mounted on a vertical stand/pole. (p.124)" },
        { k: "def", term: "(vi) French cross-staff", t: "Used to set out angles in <b>multiples of 45°</b> with respect to a chain line. Figure (p.124): plan of an octagon with sight lines radiating from the centre through the faces at 45° intervals (horizontal, vertical and two diagonals); angle between adjacent lines marked 45°. (p.124)" },
        { k: "def", term: "(vii) Optical square", t: "Used to set out a <b>right angle</b> with respect to the chain line. It uses the principle of <b>double reflection</b>: the reflected ray becomes perpendicular to the incident ray after double reflection from two mirrors placed at <b>45°</b> to each other. (p.125)" },
        { k: "p", t: "Figure (p.125) — optical square ray diagram: <b>index mirror</b> (inclined, upper left) and <b>horizon mirror</b> (inclined, lower right). The <b>incident ray</b> comes horizontally from the left to the horizon mirror, reflects up-left to the index mirror, and reflects vertically downward as the <b>reflected ray</b>; a right-angle symbol marks where the reflected (vertical) ray crosses the incident (horizontal) ray. (p.125)" },
        { k: "def", term: "(viii) Prism square", t: "Also based on the double-reflection principle, but here the <b>mirror is replaced by a prism</b>. (p.125)" },
        { k: "def", term: "(ix) Clinometer", t: "Used to measure the <b>slope of the ground</b> and angles in the vertical plane. Figure (p.125): two sketches of a semicircular graduated arc with a hanging plumb pointer. Left — clinometer level: top edge horizontal, pointer vertical reading 0; scale 0 at bottom with 10, 20, 30, 40 on both sides. Right — clinometer tilted: top edge inclined, pointer still vertical; scale marks 20, 30, 40, 50 on the left and 10, 20, 30, 40, 50 on the right. (p.125)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har accessory ek kaam ke liye: <b>peg</b> station pakka karta hai, <b>arrow</b> har chain-length ka nishaan aur ginti dono, <b>ranging rod</b> line seedhi rakhta hai, <b>offset rod</b> chhote offset ko align/naapta hai. Right angle set karne ke liye cross-staff (slits se dekh ke), French cross-staff (45° ke multiples bhi), aur optical/prism square (do reflection = 90°, sabse accurate). Clinometer zameen ka dhalaan batata hai — jo aage slope correction me kaam aata hai." },
        { k: "p", t: "Optical square ka magic: do mirror 45° par hon to ray do baar reflect hokar hamesha 2 × 45° = 90° ghoom jaati hai — instrument thoda hile tab bhi right angle sahi rehta hai." },
        { k: "trap", t: "Arrows count chain lengths only while they are in the <b>follower's</b> hand (he picks them up behind the leader). Counting the arrows still with the leader, or forgetting the last partial length, gives a wrong total. In the notes' example 5 arrows with the follower × 20 m = 100 m." },
        { k: "real", t: "On site, offsets longer than a few metres are set out with an optical square or prism square rather than by eye; the open cross-staff is the cheap field alternative." },
      ],
    },

    /* ---------------------------------------------------------- ranging */
    {
      n: "",
      title: "Notes — Ranging: direct, indirect (reciprocal) and random-line",
      hi: "रेंजिंग — प्रत्यक्ष, अप्रत्यक्ष (पारस्परिक) और रैंडम लाइन",
      blocks: [
        { k: "h", t: "📘 Notes — p.125–127" },
        { k: "def", term: "(x) Ranging (Ranging-out)", t: "For measuring the length of a survey line, the chain or tape is stretched along the line joining the two stations. If the distance between the end stations is <b>less than</b> the chain or tape, the chain or tape is simply stretched between the two points — no intermediate point is required. However, if the distance between the end points is <b>greater than</b> the length of the chain, intermediate points must be established before starting any measurement. These intermediate points should be in a straight line between the end points, which ensures that the straight-line distance is measured. This process of establishing intermediate points is called <b>ranging or ranging out</b>. (p.125–126)" },
        { k: "list", items: ["1) Direct ranging", "2) Indirect ranging", "3) Random ranging (random line method)"] },
        { k: "h", t: "1) Direct ranging (p.126)" },
        { k: "p", t: "Adopted when intermediate points are established along a chain line by <b>direct observation from the end station</b>. Figure (p.126): line from A to B (end stations as vertical marks) divided into four segments l₁ | l₂ | l₃ | l₄. AB = l₁ + l₂ + l₃ + l₄. (p.126)" },
        { k: "h", t: "2) Indirect ranging (Reciprocal ranging / Repeated alignment) (p.126–127)" },
        { k: "p", t: "Adopted when the end stations are <b>not intervisible</b>, due to rising ground between them or due to a long distance between the end stations. Example — to lay out a straight line between inaccessible points, or points across a mountain. (p.126–127)" },
        { k: "p", t: "Figure (p.126): ground profile rising as a hill between A (left) and B (right), with C and D on top of the hill. Vertical lines drop from A, C, D, B. On C's vertical: points C₁, C₂, C₃ (top to bottom); on D's vertical: D₁, D₂, D₃ (top to bottom). Sight lines C₁—D₂, D₂—B, A—C₂—D₂ and A—C₃—D₃—B show successive approximations converging onto the straight line A–B at the bottom. (p.126)" },
        { k: "steps", items: [
          "Let A and B be the two end stations of a line with rising ground between them; C and D are two intermediate points to be established on the chain line. (p.127)",
          "Two chainmen stand at C₁ and D₁ such that the chainman at C₁ can see both the ranging rod (at B) and the chainman at D₁, and the chainman at D₁ can see both the ranging rod at C₁ and A. (p.127)",
          "The chainman at C₁ directs the chainman at D₁ to move to D₂ so as to be in line with B. (p.127)",
          "Then the chainman at D₂ directs the chainman at C₁ to move to C₂ so as to be in line with A. (p.127)",
          "By successively directing each other, the two chainmen proceed to the line AB and finally come to C and D exactly in line AB. (p.127)",
        ] },
        { k: "h", t: "3) Random line method (p.127)" },
        { k: "p", t: "AB is the original survey line to be established. B′ is a point from where B is visible, and AB′ is a clearly visible line. By measuring AB′ and BB′ we can find the length of AB; and by measuring AB′, BB′ and AC′ we can find the length of CC′ by the similar-triangle property. By this process we locate point C, and similarly point D. (p.127)" },
        { k: "p", t: "Figure (p.127): the random line A—D′—C′—B′ (upper) and the true survey line A—D—C—B (lower, diverging from A); perpendiculars D′D, C′C (dashed) and B′B (solid) drop from the random line to the survey line, forming a long thin triangle AB′B. (p.127)" },
        { k: "eq", expr: "AB = √( (AB′)² + (B′B)² )", where: [["AB′", "length measured along the random line"], ["B′B", "perpendicular from B′ to B"]] },
        { k: "eq", expr: "AB′ / BB′ = AC′ / CC′ = AD′ / DD′   (similar triangles)", where: [["AC′, AD′", "distances along the random line to C′, D′"], ["CC′, DD′", "perpendicular distances to be set out to reach C, D on line AB"]] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen situations, teen tareeke: dono ends ek doosre ko dikhte hain → <b>direct ranging</b>. Beech me pahaadi hai, ends nahi dikhte → <b>reciprocal ranging</b>: do aadmi pahaadi par khade hokar baari-baari ek doosre ko line me laate hain (C₁→D₂→C₂→…) jab tak dono AB par na aa jaayein. Beech me jungle/building hai jisse line dikh hi nahi rahi → <b>random line</b>: ek aasaan line AB′ chalao, B′ se B tak perpendicular naapo, phir similar triangles se har beech wale point ka offset CC′ = AC′ × BB′ / AB′ nikaal lo." },
        { k: "p", t: "Obstacles ka bada classification (chaining rukti hai / dekhna rukta hai / dono) section 3.3 me hai." },
        { k: "trap", t: "Reciprocal ranging does <b>not</b> need A and B to be seen from each other — it needs each chainman to see the <i>other</i> chainman and the end station beyond him. Using it where the ends are intervisible is unnecessary; using direct ranging over a hill is impossible." },
        { k: "real", t: "Ranging by eye is good only to within a short distance; for long lines on site, a theodolite is often used to line in the intermediate pegs, but on a small plot two ranging rods and a third held in between are still the standard field method." },
      ],
    },

    /* ---------------------------------------------------------- slopes */
    {
      n: "",
      title: "Notes — Linear measurement on level and sloping ground",
      hi: "समतल और ढलान वाली ज़मीन पर रेखीय मापन",
      blocks: [
        { k: "h", t: "📘 Notes — p.128" },
        { k: "def", term: "Case 1 — On smooth level ground", t: "If the distance to be measured is longer than one chain length, intermediate stations are established in line with the end stations by ranging, and the length is determined. (p.128)" },
        { k: "def", term: "Case 2 — On sloping ground", t: "The horizontal distance can be measured (A) <b>by stepping</b>, or (B) by <b>measuring the length along the slope</b>. (p.128)" },
        { k: "list", items: [
          "Figure (p.128, left) \"By stepping\": a valley-shaped ground curve from A (upper left) down to the bottom and up to the right, with B below the lowest point; horizontal steps l₁, l₂, l₃ taken successively down the slope with vertical drops between them.",
          "Figure (p.128, right) \"By sloping\": right triangle — A at top of a vertical line on the left, sloping line of length l from A down to B on the right, angle θ at B between the slope and the horizontal; horizontal base labelled l cos θ.",
        ] },
        { k: "eq", expr: "By stepping:  AB = l₁ + l₂ + l₃", where: [["l₁, l₂, l₃", "horizontal lengths of the successive steps"]] },
        { k: "eq", expr: "By sloping:  horizontal distance = l cos θ", where: [["l", "length measured along the uniform slope"], ["θ", "angle of the slope with the horizontal"]] },
        { k: "note", t: "If the ground slope is <b>uniform</b>, measuring along the slope is possible; but if a <b>variable slope</b> is observed, the <b>stepping method</b> is used. (p.128)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Stepping matlab seedhiyaan: tape ko har baar horizontal pakdo, end se plumb-bob gira ke neeche point lo, aur agla step wahan se. Saare horizontal tukde jod do. Ye har tarah ki ulti-seedhi zameen par chalta hai. Agar dhalaan ek jaisa (uniform) hai, to seedha slope par naap kar clinometer se θ lo aur l cos θ se horizontal nikaal lo — tez hai, par sirf uniform slope par." },
        { k: "trap", t: "In stepping, go <b>downhill</b> — the tape is held horizontal from the higher point and plumbed down at the lower end, which is far easier than holding the uphill end up in the air. And never add the vertical drops into AB — only the horizontal lengths l₁ + l₂ + l₃." },
      ],
    },

    /* ---------------------------------------------------------- standardisation */
    {
      n: "",
      title: "Notes — Chain and tape corrections: standardisation, with numericals",
      hi: "चेन और टेप संशोधन — मानकीकरण (स्टैंडर्डाइज़ेशन), संख्यात्मक उदाहरण",
      blocks: [
        { k: "h", t: "📘 Notes — p.129–131" },
        { k: "cmp", t: "Corrections (p.129)", cols: ["Corrections applied"], rows: [
          ["Chain correction", "1) Correction for standardisation · 2) Correction for slope"],
          ["Tape correction", "1) Correction for standardisation · 2) Correction for slope · 3) Correction for pull · 4) Correction for temperature · 5) Correction for sag · 6) Correction for MSL"],
        ] },
        { k: "h", t: "1) Correction for standardisation (p.129)" },
        { k: "eq", expr: "Correct length = (Actual length of tape / Nominal length of tape) × Measured length", where: [] },
        { k: "eq", expr: "C.L = (l′ / l) × L′", where: [["l′", "actual (true) length of the chain/tape"], ["l", "nominal (designated) length of the chain/tape"], ["L′", "measured length"], ["C.L", "correct (true) length"]] },
        { k: "eq", expr: "Corrected area = (l′ / l)² × Measured area", where: [] },
        { k: "eq", expr: "Corrected volume = (l′ / l)³ × Measured volume", where: [] },
        { k: "eg", title: "Notes example — Finding the actual length of the tape", given: "A line of true length 500 m, measured with a tape of 20 m, is reported to be 502 m. Then the correct length of the tape?", steps: [
          { t: "C.L = (l′/l) × measured length", w: "500 = (l/20) × 502" },
          { t: "Solve", w: "l = 19.92 m" },
        ], ans: "Actual length of the tape = 19.92 m (p.130)" },
        { k: "eg", title: "Notes example — True length with a long chain; chain lengthening during work", given: "The length of a line measured with a chain was found to be 250 m. Calculate the true length of the line if (i) the length was measured with a chain of 30 m which was 10 cm too long; (ii) the length of the chain was 30 m at the beginning and 30.10 m at the end of the work.", steps: [
          { t: "(i) C.L = (l′/l) × measured length", w: "C.L = (30.1/30) × 250 = 250.833 m" },
          { t: "(ii) Chain lengths", w: "l₁ = 30 m, l₂ = 30.1 m" },
          { t: "(ii) Average length", w: "Avg = (30 + 30.1)/2 = 30.05 m" },
          { t: "(ii) Correct length", w: "C.L = (30.05/30) × 250 = 250.416 m" },
        ], ans: "(i) 250.833 m   (ii) 250.416 m (p.130)" },
        { k: "note", t: "<b>Check:</b> (30.05/30) × 250 = 250.41667 m, which rounds to <b>250.417 m</b> (the notes truncate to 250.416). Part (i) 250.833 m is correct. (p.130)" },
        { k: "eg", title: "Notes example — Chain lengthening in two stages", given: "A distance of 2000 m was measured by a 30 m chain. Later on it was detected that the chain was 0.1 m too long. Another 500 m (total 2500 m) was measured and it was detected that the chain was 0.15 m too long. If the length of the chain in the initial stage was correct, determine the correct length that was measured.", steps: [
          { t: "Data", w: "First part 2000 m, l = 30 m" },
          { t: "Average length, first 2000 m", w: "l_avg = (30 + 30.1)/2 = 30.05" },
          { t: "Average length, next 500 m", w: "l′_avg = (30.1 + 30.15)/2 = 30.125" },
          { t: "Correct length of first part", w: "C.L₁ = (30.05/30) × 2000\nC.L₁ = 2003.333 m" },
          { t: "Correct length of second part", w: "C.L₂ = (30.125/30) × 500\nC.L₂ = 502.853 m" },
          { t: "Total", w: "C.L total = 2003.33 + 502.853\nC.L total = 2505.4133 m" },
        ], ans: "Correct total length = 2505.4133 m (p.130–131)" },
        { k: "note", t: "<b>Check:</b> (30.125/30) × 500 = <b>502.083 m</b>, not 502.853 m. Also 2003.33 + 502.853 would be 2506.183, not 2505.4133. With the correct second part: 2003.333 + 502.083 = <b>2505.417 m</b> — so the notes' final total (2505.413 m) is essentially right, but the C.L₂ line is mis-written. (p.131)" },
        { k: "eg", title: "Notes example — Correct area with a short tape", given: "The area of a field was found to be 4000 m² when measured with a tape of 30 m. If the tape was 0.11 m too short, determine the correct area.", steps: [
          { t: "Formula", w: "Corrected area = (L′/L)² × measured area" },
          { t: "Substitute", w: "Corrected area = [(30 − 0.11)/30]² × 4000" },
          { t: "Result", w: "Corrected area = 3970.72 m²" },
        ], ans: "Corrected area = 3970.72 m² (p.131)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Logic ek line ka: agar tape <b>lamba</b> hai (l′ &gt; l), to har baar jab aap '30 m' likhte ho, asal me zyada zameen cover hoti hai — isliye sahi length measured se <b>zyada</b> hogi (ratio l′/l &gt; 1). Tape <b>chhota</b> ho to ulta — sahi length kam. Area do lengths ka product hai isliye ratio ka square, volume teen lengths ka isliye cube." },
        { k: "p", t: "Jab chain kaam ke dauraan dheere-dheere lambi hoti jaaye (start 30, end 30.1), to us hisse ke liye <b>average length</b> lo. Do stage ho to har stage ka apna average — pehle stage ka (30 + 30.1)/2, doosre ka (30.1 + 30.15)/2. Section 3.4 me yahi correction Ca = L(c/l) form me likha hai — dono same hain, kyunki (l′/l)L′ = L′ + L′(l′ − l)/l." },
        { k: "trap", t: "Do not put the ratio upside down. True = (actual tape / nominal tape) × measured. A tape that is <b>too short</b> (0.11 m short) makes the field area <b>too large</b>, so the corrected area (3970.72 m²) is <b>smaller</b> than 4000 m². If your answer moves the wrong way, you have inverted l′/l." },
        { k: "real", t: "Chains stretch with use (links open out, rings wear), which is why the notes' examples have the chain growing from 30 m to 30.1 m to 30.15 m during the work. Testing the chain at the start and end of the day lets you apply the average-length correction." },
      ],
    },

    /* ---------------------------------------------------------- slope correction */
    {
      n: "",
      title: "Notes — Correction for slope (θ known, or h measured)",
      hi: "ढलान के लिए संशोधन",
      blocks: [
        { k: "h", t: "📘 Notes — p.131–132" },
        { k: "h", t: "When the slope angle θ is known (p.131)" },
        { k: "p", t: "Figure (p.131): right triangle — A at left, B at right on the horizontal base; sloping side L from A up to the top of the vertical at B; angle θ at A; vertical height h at B (double arrow); horizontal base A↔B labelled L cos θ. (p.131)" },
        { k: "steps", items: [
          "Error = M.V − T.V (measured value − true value) (p.131)",
          "E = L − L cos θ (p.131)",
          "E = L(1 − cos θ) (p.131)",
          "Correction = − error (p.131)",
        ] },
        { k: "eq", expr: "Cs = − L (1 − cos θ)     (if θ is known)", where: [["L", "length measured along the slope"], ["θ", "angle of slope with the horizontal"]] },
        { k: "h", t: "When the difference of elevation h is measured (p.132)" },
        { k: "p", t: "Figure (p.132): right triangle — A at left, B at right; sloping side L from A to the top of the vertical at B; angle θ at A; vertical height h at B (double arrow); horizontal base AB labelled √(L² − h²). Side note on the page: (1 − x)^(1/n) ≈ 1 − x/n − x²/(2n²). (p.132)" },
        { k: "steps", items: [
          "Length of AB = √(L² − h²) (p.132)",
          "Correction = T.V − M.V (p.132)",
          "Cs = √(L² − h²) − L (p.132)",
          "Cs = L[(1 − h²/L²)^(1/2) − 1] (p.132)",
          "Cs = L[1 − h²/(2L²) − h⁴/(8L⁴) − 1] (p.132)",
          "Cs = − h²/(2L) − h⁴/(8L³) ← the second term is neglected (p.132)",
        ] },
        { k: "eq", expr: "Cs = − h² / (2L)", where: [["h", "difference in elevation between the ends of the measured length"], ["L", "length measured along the slope"]] },
        { k: "note", t: "<b>Check:</b> the side-note expansion (1 − x)^(1/n) ≈ 1 − x/n − x²/(2n²) is right only for <b>n = 2</b> (it gives 1 − x/2 − x²/8, which is what the derivation uses). The general binomial second term is −(n − 1)x²/(2n²). The slope derivation itself is correct. (p.132)" },
        { k: "note", t: "<b>Note:</b> slope correction is <b>always negative</b>. If the higher term is not neglected, the correction is increased by <b>h⁴/(8L³)</b>. (p.132)" },
        { k: "eg", title: "Notes example — Downhill end of a tape held too low", given: "If the downhill end of a 20 m tape is held 80 cm too low, then its horizontal length will be?", steps: [
          { t: "Slope correction", w: "Cs = −h²/(2L) = −0.80²/(2 × 20 × 10) = −0.016" },
          { t: "True value", w: "T.V = Measured value + correction" },
          { t: "Result", w: "T.V = 20 − 0.016 = 19.984 m" },
        ], ans: "Horizontal length = 19.984 m (p.132)" },
        { k: "note", t: "<b>Check:</b> the denominator should be 2 × 20 = 40, giving 0.64/40 = <b>0.016 m</b> — the notes' value −0.016 and answer 19.984 m are correct; the written \"× 10\" is a slip (0.64/400 would be 0.0016). The exact value 20 − √(20² − 0.8²) = 0.016006 m, so the h⁴/8L³ term (0.0000064 m) is negligible here. (p.132)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Dhalaan par tape ki lambaai hypotenuse hai, aur hamein chahiye base (horizontal). Hypotenuse hamesha base se lamba hota hai, isliye measured value hamesha zyada aati hai aur correction <b>hamesha negative</b>. θ pata ho to L(1 − cos θ) ghatao; level ka farak h pata ho to h²/2L ghatao. h²/2L chhote slopes ke liye bahut accurate hai — section 3.5 ka Example 3.3 dikhata hai ki 1 in 10 par bhi error sirf 0.4 mm per 30 m hai." },
        { k: "trap", t: "Do not plug h in cm with L in m. In the example h = 80 cm must be written 0.80 m before squaring: 0.80²/(2 × 20) = 0.016 m. Mixing units (80²/40 = 160) or adding the correction instead of subtracting (20 + 0.016) are the two classic mistakes." },
        { k: "real", t: "When a chainman holds the downhill end of the tape low instead of horizontal, the same h²/2L error creeps into every tape length — on long lines over rough ground this is why the leader checks the tape is level (or the slope is recorded) before booking each length." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — Chain and tape surveying (p.116–132)",
      hi: "पुनरावृत्ति — चेन और टेप सर्वेक्षण",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "✅ 1 ft = 0.3048 m; 1 mile = 5280 ft = 1.609 km; 1 sq. mile = 2.590 km² = 640 acre; 1 acre = 43560 ft²; 1 ha = 2.471 acre (p.116)",
          "✅ Chain survey distance = horizontal distance; details located by tie lines or by perpendicular offsets; large areas → network of triangles (p.116–117)",
          "✅ Main station: where two sides of a triangle meet, commands the boundary; tie (subsidiary) station: on a survey line, for interior details (p.118)",
          "✅ Main survey line joins two main stations; tie/subsidiary/auxiliary line joins two tie stations (p.118)",
          "✅ Base line: longest main line, through the centre, most important — other directions referred to it (p.119)",
          "✅ Check (proof) line: measured length = calculated length (p.119)",
          "✅ Offset: distance of object from survey line, perpendicular or oblique; chainage: distance along the line in direction of progress (p.119)",
          "✅ Well-conditioned triangle: all intersections clearly visible; angles 30°–120°; equilateral is best (p.120)",
          "✅ Revenue chain 33 ft (16 links); Gunter's 66 ft (100 links); Engineer's 100 ft (100 links); metric 30 m (150 links), 20 m (100 links) (p.120)",
          "✅ IS: every metre of chain within ±2 mm under 80 N pull; overall 20 m ± 5 mm, 30 m ± 8 mm (p.121)",
          "✅ Cloth/linen tape 10–30 m, 12–15 mm wide, varnished; metallic tape = linen + brass/copper wires; steel tape 1–50 m, 6–10 mm wide (p.121)",
          "✅ Invar tape: Ni 36% + steel 64%; 30, 50, 100 m; 6 mm wide; α = 0.122 × 10⁻⁶ /°C (p.122)",
          "✅ Peg 150 mm; arrow 400 mm long, 50 mm loop, 15 mm tip; arrows with follower = chain lengths measured (20 m × 5 = 100 m) (p.122–123)",
          "✅ Ranging rod 30 mm dia, 2–3 m long, alternate colours; offset rod has hook/ring and two slots at right angles (p.123–124)",
          "✅ Open cross-staff → right angles; French cross-staff → multiples of 45°; optical square → right angle by double reflection, mirrors at 45°; prism square → prism instead of mirror; clinometer → slope / vertical angles (p.124–125)",
          "✅ Ranging needed when line longer than chain; direct (ends intervisible), indirect/reciprocal (rising ground, long distance), random line (p.125–127)",
          "✅ Random line: AB = √(AB′² + B′B²); AB′/BB′ = AC′/CC′ = AD′/DD′ (p.127)",
          "✅ Sloping ground: stepping AB = l₁ + l₂ + l₃ (variable slope) or along slope l cos θ (uniform slope) (p.128)",
          "✅ Chain corrections: standardisation, slope. Tape corrections: standardisation, slope, pull, temperature, sag, MSL (p.129)",
          "✅ C.L = (l′/l) × L′; area × (l′/l)²; volume × (l′/l)³ (p.129)",
          "✅ Chain changing during work → use average length (p.130–131)",
          "✅ Answers: tape 19.92 m; 250.833 m and 250.416 m (≈ 250.417); 2505.41 m (C.L₂ should read 502.083 m); 3970.72 m² (p.130–131)",
          "✅ Slope correction: Cs = −L(1 − cos θ) (θ known); Cs = −h²/(2L) (h known); always negative; higher term h⁴/(8L³) increases it (p.131–132)",
          "✅ 20 m tape, downhill end 80 cm low → Cs = −0.016 m → 19.984 m (p.132)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
