/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: MATERIAL TESTING & QC · Ch 4–6
   Concrete cube & acceptance · Non-destructive testing · Soil tests
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "qc");
  if (!hb) { console.error("[qc2] handbook qc not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 4 */
    {
      id: "qc-4",
      n: 4,
      title: "Concrete — Workability, Cube Test and Acceptance",
      hi: "कंक्रीट — वर्केबिलिटी, क्यूब टेस्ट और स्वीकृति",
      blurb: "Testing fresh concrete for workability, the cube test on hardened concrete, and the statistical acceptance rule that judges the group, not the cube.",
      mins: 24,
      sections: [
        {
          n: "4.1",
          title: "Fresh and hardened — two moments, two tests",
          hi: "ताज़ा और कठोर",
          blocks: [
            { k: "p", t: "Concrete is tested at two moments. Fresh, at the point of placing, its workability is checked (slump being the commonest) to confirm it can be placed and compacted properly. Hardened, at 28 days, cubes are crushed to confirm its strength. The first catches a bad batch before it is placed; the second confirms what was placed reached its grade." },
            { k: "def", term: "Slump test", t: "The standard field workability test: fill a standard cone with concrete, lift it, and measure how far the concrete settles (slumps). Only a true slump — the mass settling evenly — is valid; a shear or collapse slump signals a harsh or too-wet mix. Low slump is stiff, high slump is flowing; the target is the lowest slump the placing method can handle." },
            { k: "def", term: "Cube test", t: "The acceptance test for strength: standard 150 mm cubes are cast from the concrete as placed, cured under water, and crushed at 28 days (often also at 7 days for early warning). The crushing load over the area gives the compressive strength, compared with the grade." },
          ],
        },
        {
          n: "4.2",
          title: "Acceptance — the group decides",
          hi: "स्वीकृति — समूह तय करता है",
          blocks: [
            { k: "p", t: "Because concrete strength scatters, a single cube result cannot accept or reject a lot — half of every batch would be below its own average. IS 456 instead judges concrete by two rules together, built around the scatter." },
            { k: "dia", id: "hb-qc-acceptance", cap: "The two acceptance rules — group mean and no weak individual." },
            { k: "eg", title: "Example 4.1 — Checking acceptance of an M25 pour",
              given: "Four consecutive cube results for M25 concrete are 31, 29, 33 and 27 N/mm². The established standard deviation is σ = 4.0 N/mm². Apply the two acceptance rules (using the commonly-cited M20-and-above values: mean ≥ fck + 0.825σ or fck + 4, whichever greater; individual ≥ fck − 4).",
              steps: [
                { t: "Group mean", w: "(31 + 29 + 33 + 27) / 4 = 120 / 4 = 30.0 N/mm²" },
                { t: "Rule 1 — mean threshold", w: "fck + 0.825σ = 25 + 0.825×4 = 28.3\nfck + 4       = 29\ntake the greater → 29.0\nmean 30.0 ≥ 29.0  → PASS" },
                { t: "Rule 2 — no weak individual", w: "limit = fck − 4 = 21\nlowest result 27 ≥ 21  → PASS" },
              ],
              ans: "Both rules pass, so the concrete is accepted. Note the logic: the mean rule (30.0 ≥ 29) stops a run of merely-average concrete slipping through, and the individual rule (27 ≥ 21) stops one genuinely weak batch hiding behind good neighbours. The exact constants (the 0.825, the ±4) must be read from the current IS 456 Table 11 — it has been amended since 2000 — they are quoted here as the widely-used values, not invented." },
            { k: "trap", t: "A single cube below fck does not, by itself, reject the concrete — this surprises people and is often mishandled on site. One low result is expected scatter; what matters is whether the group mean clears its (higher) threshold and whether any result falls below the individual floor. Panicking over one low cube, or conversely accepting on one high cube, both misread the rule. The decision is always about the group, with a floor under each member." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "qc-5",
      n: 5,
      title: "Non-Destructive Testing",
      hi: "अविनाशी परीक्षण",
      blurb: "Judging concrete already in the structure without cutting it — the rebound hammer and ultrasonic pulse velocity — and when a core is the final word.",
      mins: 18,
      sections: [
        {
          n: "5.1",
          title: "Testing what is already built",
          hi: "बने हुए का परीक्षण",
          blocks: [
            { k: "p", t: "Cubes test the concrete as delivered; but sometimes you must judge the concrete already in the structure — a member whose cubes failed, an old building being assessed, a suspect patch. You cannot crush it, so you test it without destroying it." },
            { k: "dia", id: "hb-qc-ndt", cap: "The rebound hammer and the ultrasonic pulse velocity test." },
            { k: "cmp", t: "The two common NDT methods",
              cols: ["Rebound hammer", "Ultrasonic pulse velocity"],
              rows: [
                ["Measures", "surface hardness", "speed of sound through the concrete"],
                ["Indicates", "surface strength (roughly)", "density & soundness, internal voids"],
                ["Reads high when", "surface is hard/strong", "concrete is dense & sound"],
                ["Reads low when", "surface soft or carbonated", "voids, cracks or honeycombing inside"],
              ] },
            { k: "note", t: "The two are complementary and often used together: the rebound hammer reads only the surface (and can be fooled by a hard carbonated skin over weak concrete), while the ultrasonic pulse travels right through and reveals internal voids the surface hides. Neither gives a true strength directly — both are indicators calibrated against known concrete, best read together." },
            { k: "eg", title: "Example 5.1 — Reading an ultrasonic pulse velocity",
              given: "Direct transmission across a 300 mm column; transit time 68 µs.",
              steps: [
                { t: "Velocity", w: "V = path/time = 0.300 m/68 × 10⁻⁶ s = 4410 m/s = 4.41 km/s" },
                { t: "Grade (IS 13311 Part 1)", w: "3.5–4.5 km/s → ‘good’" },
              ],
              ans: "4.41 km/s — good-quality, uniform concrete along that path." },
            { k: "note", t: "The grading table and its caveats (moisture, steel along the path) are in <a href=\"#/read/ct/8\">Concrete Technology, Chapter 8</a>." },
          ],
        },
        {
          n: "5.2",
          title: "The core is the final word",
          hi: "कोर अंतिम निर्णय",
          blocks: [
            { k: "p", t: "NDT results are indicators, not verdicts. When they are doubtful, disputed, or when a real strength number is needed for a decision, the argument is settled by cutting an actual core from the member and crushing it." },
            { k: "def", term: "Core test", t: "A cylindrical core is drilled from the hardened concrete in the structure, measured, capped and crushed like a cube. It gives the real strength of the concrete actually in place — not a proxy — which is why it is the arbiter when cubes and NDT disagree, or when the concrete in a specific member must be known for certain." },
            { k: "real", t: "The classic sequence plays out when a 28-day cube fails: the structure is not automatically condemned, because the cube tests the batch, not the member. The engineer first uses the rebound hammer and ultrasonic test to assess the concrete actually in the suspect member, and if those are inconclusive or the stakes are high, cuts a core and crushes it. <strong>The cube is evidence about the delivered batch; the core is evidence about the standing structure</strong> — and it is the structure you finally have to decide about." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "qc-6",
      n: 6,
      title: "Soil Tests",
      hi: "मिट्टी परीक्षण",
      blurb: "The tests that classify a soil and grade its strength for foundations and pavements, and why the soaked, worst-case value is the one that matters.",
      mins: 18,
      sections: [
        {
          n: "6.1",
          title: "Classifying and grading the soil",
          hi: "मिट्टी का वर्गीकरण",
          blocks: [
            { k: "p", t: "Soil is tested (IS 2720) first to classify it — what kind of soil is it? — and then to grade its strength for a particular use, foundation or pavement. Classification comes from the index properties met in the Geotechnical handbook." },
            { k: "cmp", t: "The soil test groups",
              cols: ["Tells you"],
              rows: [
                ["Grain size / sieve & hydrometer", "the size distribution → sand, silt, clay"],
                ["Atterberg limits (LL, PL)", "plasticity → clay behaviour, classification"],
                ["Compaction (Proctor)", "max dry density & optimum moisture for fill"],
                ["CBR", "strength for pavement subgrade design"],
                ["Shear / triaxial", "shear strength for foundation bearing"],
              ] },
            { k: "note", t: "The Atterberg limits do something remarkable, worth recalling from the Geotechnical handbook: they measure the clay content and behaviour of a soil through the water contents at which it changes state, without ever looking at an individual grain. The plasticity index (LL − PL) is a measurement of the clay itself, and it drives the whole fine-soil classification." },
          ],
        },
        {
          n: "6.2",
          title: "Test the soil at its worst",
          hi: "मिट्टी को उसकी सबसे कमज़ोर स्थिति में परखें",
          blocks: [
            { k: "p", t: "The single most important habit in soil testing for design is to test the soil in the condition it will be weakest in service — usually soaked, after the monsoon — not in the convenient dry state it arrives at the lab." },
            { k: "trap", t: "The CBR test is soaked before testing for exactly this reason: soil is weakest when saturated, which is precisely when the heaviest damage happens on a road. Designing a pavement on the dry, strong CBR gives a pavement that fails every monsoon. The same logic runs through soil testing generally — the design value is the worst-case (soaked, remoulded, whichever is relevant) value, not the best-case one the sample happens to show." },
            { k: "list", items: [
              "<strong>Procedure</strong> — a 50 mm plunger penetrates the specimen at 1.25 mm/min, after four days' soaking under a surcharge weight.",
              "<strong>Standard loads</strong> — 1370 kg at 2.5 mm and 2055 kg at 5.0 mm penetration (the crushed-stone standard).",
              "<strong>Reporting</strong> — CBR at 2.5 mm normally; if the 5 mm value is higher, the test is repeated and, if confirmed, the 5 mm value is used.",
            ] },
            { k: "note", t: "All three as given by <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105101087/21-Ltexhtml/p6/p.html\" target=\"_blank\" rel=\"noopener\">NPTEL Transportation Engineering</a> (IS 2720 Part 16)." },
            { k: "eg", title: "Example 6.1 — A soaked CBR result",
              given: "After four days' soaking, the specimen carries 55 kg at 2.5 mm penetration and 75 kg at 5.0 mm.",
              steps: [
                { t: "At 2.5 mm", w: "CBR = 55/1370 × 100 = 4.0%" },
                { t: "At 5.0 mm", w: "CBR = 75/2055 × 100 = 3.6%" },
                { t: "Report", w: "2.5 mm value is higher → CBR = 4.0%" },
              ],
              ans: "Soaked CBR 4% — a weak subgrade that will need a thick pavement (the design charts in the Transportation handbook take this number directly)." },
            { k: "real", t: "This connects the lab to the field failure directly. A road built on a subgrade tested dry looks fine through the first dry season and then breaks up in the first heavy rains, because the soil that was strong in the lab turned weak when it got wet in the ground. <strong>Testing the soil at its worst is not pessimism — it is testing it in the state it will actually be in when the load arrives.</strong>" },
          ],
        },
      ],
    },

  );
})();
