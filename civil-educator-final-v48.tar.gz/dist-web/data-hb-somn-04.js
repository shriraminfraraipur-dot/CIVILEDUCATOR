/* MACE Academy SOM notes — strain energy of bars in series, stepped bars, axial diagrams, composite bars, stress tensor, complementary shear and strain matrix, M p.73–82 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- M p.72–73 */
    {
      n: "",
      title: "MACE notes — strain energy of bars in series and the effect of diameter",
      hi: "श्रेणी में जुड़े दंडों की विकृति ऊर्जा और व्यास का प्रभाव",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.72–73" },
        { k: "p", t: "<b>Que4 (question on M p.72):</b> Find out the total S.E. (strain energy) stored in the tapered bar as shown below. (M p.72)" },
        { k: "p", t: "Figure (M p.72): a stepped bar fixed to a wall at its left end, made of three segments in series, left to right — segment 1: depth d₁, modulus E₁, length L₁; segment 2: depth d₂, modulus E₂, length L₂; segment 3: depth d₃, modulus E₃, length L₃. (The notes call it a 'tapered' bar; it is drawn as a stepped bar.) (M p.72)" },
        { k: "p", t: "Figure (M p.73): three separate free bodies labelled U₁, U₂, U₃. Each bar has P ← at its left end and → P at its right end, i.e. all three segments carry the same tensile force P. (M p.73)" },
        { k: "eq", expr: "U₁ = P²L₁/(2A₁E₁)   ;   U₂ = P²L₂/(2A₂E₂)   ;   U₃ = P²L₃/(2A₃E₃)", where: [] },
        { k: "eq", expr: "U = (P²/2) [ L₁/(A₁E₁) + L₂/(A₂E₂) + L₃/(A₃E₃) ]   . . . (Ans)", where: [
          ["L/AE", "axial flexibility of a segment"],
          ["U", "Axial flexibility × P²/2"],
        ] },
        { k: "p", t: "Margin note under the bracket (M p.73): ↳ U = Axial flexibility × P²/2 — <b>L/AE चा sum</b> (Marathi: 'the sum of L/AE'). (M p.73)" },
        { k: "steps", items: [
          "If E = same for all bars: U = (P²/2E) [ L₁/A₁ + L₂/A₂ + L₃/A₃ ] (M p.73)",
          "= (P²/2E) [ 4L₁/(πd₁²) + 4L₂/(πd₂²) + 4L₃/(πd₃²) ] (M p.73)",
          "∴ <b>U = (2P²/πE) [ L₁/d₁² + L₂/d₂² + L₃/d₃² ]</b> (M p.73)",
          "If L₁ = L₂ = L₃ = L: ∴ <b>U = (2P²L/πE) [ 1/d₁² + 1/d₂² + 1/d₃² ]</b> — ↳ sum of reciprocal of square of diameter. (M p.73)",
        ] },
        { k: "eg", title: "MACE notes example — Ques5: strain energy when the diameter is doubled", given: "If diameter of a bar is doubled then the total strain energy stored in the bar due to axial load will become? a) half  b) Twice  c) four times  d) Eight times  e) becomes 1/4 th i.e. 0.25 times", steps: [
          { t: "Figure: small square cross-section labelled d ⇒ larger square cross-section labelled 2d. U ∝ 1/d²", w: "U ∝ 1/d²" },
          { t: "Bar of diameter d", w: "U = P²L/(2AE)\n= P²L/(2((π/4)d²)E)   [2 cancelled into 4 → 2]\n∴ U = 2P²L/(πd²E)" },
          { t: "Bar of diameter 2d", w: "U = P²L/(2((π/4)(2d)²)E)   [2 cancelled into 4 → 2]\n= 2P²L/(π·4d²·E)\nU = (1/4)(2P²L/(πd²E))" },
          { t: "Conclusion", w: "If d is doubled, S.E becomes 0.25 times i.e. reduces by 75%\nd↑ ⇒ U↓\n2d ⇒ U/4" },
        ], ans: "(e) becomes 1/4th, i.e. 0.25 times — strain energy reduces by 75%. (M p.73)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Bars in series mein <b>force same</b> rehta hai (har segment mein P), isliye har segment ki energy P²L/2AE alag se nikal ke jod sakte ho — common factor P²/2 bahar aa jaata hai aur bracket mein sirf flexibilities (L/AE) ka sum bachta hai. Matlab jo segment sabse 'flexible' hai (lamba, patla, ya kam E wala), wahi sabse zyada energy store karta hai." },
        { k: "p", t: "Diameter double karne par area 4 guna ho jaata hai; same P ke liye stress aur strain dono ¼ ho jaate hain, aur U = ½·P·ΔL hone se energy bhi ¼. Isliye U ∝ 1/d² (load same rakhne par). Ye wahi stepped-bar idea hai jo <a href=\"#/read/som/2\">§2.2</a> mein elongation ke liye diya gaya hai — wahan ΔL = Σ PL/AE, yahan U = Σ P²L/2AE." },
        { k: "trap", t: "Ques5 mein 'diameter double → energy bhi kuch guna badhegi' sochna galat hai. Load P fixed hai, to moti bar kam khinchti hai aur <b>kam</b> energy store karti hai: 2d ⇒ U/4, 'four times' nahi." },
      ],
    },

    /* ---------------------------------------------------------- M p.74–76 */
    {
      n: "",
      title: "MACE notes — stepped bars: elongation, equilibrium loads and why strain energies don't superpose",
      hi: "सोपानी दंड — दीर्घीकरण, संतुलन भार और अध्यारोपण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.74–76" },
        { k: "p", t: "<b>Ques6:</b> Find out the total elongation of the bar as shown below. L₁ ≠ L₂ ≠ L₃; d₁ ≠ d₂ ≠ d₃. (M p.74)" },
        { k: "p", t: "Figure (M p.74): stepped bar of three segments in series — segment 1 (E₁, d₁) length L₁; segment 2 (E₂, d₂, drawn slimmer) length L₂; segment 3 (E₃, d₃) length L₃. Load P ← at the left end and → P at the right end. Answer sketch: three free bodies labelled ΔL₁, ΔL₂, ΔL₃, each with P ← at the left end and → P at the right end. Equilibrium of a cut piece: +P − x = 0 ⇒ <b>x = P</b>. (M p.74)" },
        { k: "eq", expr: "ΔL = ΔL₁ + ΔL₂ + ΔL₃ = PL₁/(A₁E₁) + PL₂/(A₂E₂) + PL₃/(A₃E₃) = P [ L₁/(A₁E₁) + L₂/(A₂E₂) + L₃/(A₃E₃) ]   . . . (Ans)", where: [] },
        { k: "steps", items: [
          "If E = constant: ΔL = (P/E) [ 4L₁/(πd₁²) + 4L₂/(πd₂²) + 4L₃/(πd₃²) ] (M p.74)",
          "<b>ΔL = (4P/πE) [ L₁/d₁² + L₂/d₂² + L₃/d₃² ]</b> (M p.74)",
          "If L = constant: <b>ΔL = (4PL/πE) ( 1/d₁² + 1/d₂² + 1/d₃² )</b> (M p.74)",
        ] },
        { k: "eg", title: "MACE notes example — Que7: magnitude of load P for equilibrium", given: "Find out the magnitude of load 'P' on bar as shown below. (Figure: bar of two segments; 5 KN ← at the left end; load → P at the junction; → 2 KN at the right end; first segment 1 m, second segment 2 m.)", steps: [
          { t: "Σfx = 0", w: "−5 + P + 2 = 0" },
          { t: "Solve", w: "P = −2 + 5\nP = 3 KN" },
        ], ans: "P = 3 KN (M p.74)" },
        { k: "eg", title: "MACE notes example — Ques8: axial load at B for equilibrium", given: "A bar as shown below having uniform area and modulus of elasticity throughout is subjected to loading. What is the axial load required to be applied at point B so that the bar is in equilibrium. a) 3 KN (←)  b) 4 KN (←)  c) 4 KN (→)  d) 10 KN (←). (Figure: bar A–B–C, B at mid-length; 3 KN → at end A; 7 KN ← at end C.)", steps: [
          { t: "Σfx = 0, assume direction of 'P' is leftward at B (side sketch: ← P at B, 'so that P should come +ve')", w: "+3 − P − 7 = 0\n−4 − P = 0" },
          { t: "Result is negative", w: "P = −4 KN   i.e. wrong assumed direction" },
          { t: "Reverse the direction", w: "∴ P = 4 KN (→)" },
        ], ans: "(c) 4 KN (→) (M p.74–75)" },
        { k: "eg", title: "MACE notes example — Ques9: total elongation of a steel bar under four loads", given: "A steel bar of cross section 500 mm² is acted upon by forces as shown below. Determine the total elongation of the bar (assume E = 200 GPa). (Figure: bar A–B–C–D; 1000 N ← at A; ← 400 N at B; → 800 N at C; → 600 N at D; AB = 100 mm, BC = 200 mm, CD = 200 mm.)", steps: [
          { t: "Data", w: "A = 500 mm²\nE = 200 GPa = 200×10³ MPa" },
          { t: "Free bodies (all three marked 'Tensile')", w: "Segment 1 (100 mm): 1000 N ← … → 1000 N\nSegment 2 (200 mm): 1400 N ← … → 1400 N\nSegment 3 (200 mm): 600 N ← … → 600 N" },
          { t: "@ B", w: "+1000 − x = −400\nx = 1400 N" },
          { t: "@ C, check", w: "+1400 − 600 = 800 N (OK)" },
          { t: "Sign convention", w: "Tensile → +ve\nCompressive → −ve" },
          { t: "Total elongation", w: "ΔL = +ΔL₁ + ΔL₂ + ΔL₃\nΔL = + P₁L₁/(A₁E₁) + P₂L₂/(A₂E₂) + P₃L₃/(A₃E₃)" },
          { t: "But A = constant & E = constant", w: "= (1/AE) [P₁L₁ + P₂L₂ + P₃L₃]\n= (1/(500×200×10³)) [1000×100 + 1400×200 + 600×200]\n= (10⁴/(500×200×10³)) [10 + 28 + 12]\n= 50/(10×10³)\n= 5×10⁻³" },
        ], ans: "ΔL = 0.005 mm (M p.75)" },
        { k: "p", t: "<b>Que10:</b> In the previous problem find out the total strain energy stored in the bar. <b>Ans:</b> ↳ U ≠ U₁ + U₂ + U₃ (the words 'In Actual' struck through; boxed beside it: <b>U &gt; U₁ + U₂ + U₃ in actual</b>). This method cannot be applied to find out the total strain energy because here principle of superposition is not valid [U = P²L/2AE ⇒ U ∝ P²]. (M p.76)" },
        { k: "note", t: "<b>Check:</b> The rule 'U is not additive' applies to <b>separate load cases</b> (M p.72: U for P₁ + P₂ together = U₁ + U₂ + P₁P₂L/AE, more than U₁ + U₂). It does <b>not</b> stop you adding the energies of <b>segments</b> once each segment's actual internal force is known — that is exactly what M p.73 does (U = U₁ + U₂ + U₃ for a bar in series). For Ques9 the segment forces are 1000 N, 1400 N and 600 N (tension), so U = Σ P²L/(2AE) = (1000²×100 + 1400²×200 + 600²×200)/(2×500×200 000) = 5.64×10⁸/2×10⁸ = <b>2.82 N·mm</b>. What would be wrong is to find the energy for each external load (1000, 400, 800, 600 N) acting alone and add those." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Stepped bar ka formula ek line ka hai: ΔL = Σ PᵢLᵢ/(AᵢEᵢ). Asli kaam hai har segment ka <b>internal force</b> Pᵢ nikalna — bar ko segment ke andar kaato aur ek side ka balance karo (Ques9 mein @B: 1000 + 400 = 1400 N). Phir 'Tensile +, Compressive −' ke saath jodo. Ques7 aur Ques8 mein yahi ΣFx = 0 sirf missing load dhoondhne ke liye use hua — direction galat assume karo to answer negative aata hai, bas direction ulat do." },
        { k: "p", t: "Elongation load ke saath linear hai, isliye loads ke effects jod sakte ho (superposition chalta hai). Energy P² ke saath badhti hai — (P₁ + P₂)² ≠ P₁² + P₂² — isliye alag-alag load cases ki energies jodna galat hai. Segment-wise energy jodna phir bhi sahi hai, kyunki har segment ka total force already pata hai." },
        { k: "trap", t: "Ques9 mein sabse common galti: segment BC ka force 400 N ya 800 N le lena (jo load point par laga hai). BC ka internal force 1400 N hai — A par 1000 N aur B par 400 N, dono BC ko khinch rahe hain." },
        { k: "real", t: "Multi-level tie rods, hanger rods with couplers of different sizes, and pile segments with steps in section are all checked exactly like this — internal force per segment, then Σ PL/AE." },
      ],
    },

    /* ---------------------------------------------------------- M p.76–77 */
    {
      n: "",
      title: "MACE notes — axial thrust, normal stress and displacement diagrams",
      hi: "अक्षीय प्रणोद, अभिलम्ब प्रतिबल और विस्थापन आरेख",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.76–77" },
        { k: "p", t: "<b>Que11:</b> For the bar axially loaded as shown below, draw (i) axial thrust diagram (normal force diagram), (ii) normal stress diagram, (iii) elongation or displacement diagram. (M p.76)" },
        { k: "p", t: "Figure (M p.76): stepped bar fixed at its left end to a wall labelled 'non-yielding (non-movable)'. Left segment: A = 1000 mm², E = 200 GPa, length 100 mm. Step at B. Right (smaller) segment: A = 500 mm², E = 200 GPa, length 100 mm. Load → 1000 N at B (on the step) and → 1000 N at the right free end. (M p.76)" },
        { k: "list", items: [
          "Free bodies (M p.76): right segment — 1000 N ← at its left end, → 1000 N at its right end; left segment — 2000 N ← at its left end, → 2000 N at B.",
          "Positions along the left segment: L = 0, L = 50 mm, L = 100 mm, with ΔL = PL/AE: ΔL = 0 at L = 0; ΔL′ = 50P/AE at L = 50; ΔL = 100P/AE at B. (M p.76)",
          "@ B: −1000 + 2000 ⇒ +1000 o.k (→). (M p.76)",
          "σ = P/A: left part P = 2000 N, σn = 2 MPa; right part P = 1000 N, σN = P/A = 1000/500 = 2 MPa. A double arrow 'L↑↑ ⇒' shows L increasing to the right. (M p.76)",
          "<b>Axial thrust diagram</b> (M p.76): stepped rectangle — ordinate 2000 N from L = 0 to B (labelled 2000 N at both ends), steps down at B to 1000 N, constant 1000 N to the free end.",
          "<b>Normal stress diagram</b> (M p.76): rectangle of constant height 2 MPa over the full length (labelled 2 MPa at left and right).",
          "<b>Displacement diagram</b> (M p.76): ΔL = PL/AE ⇒ ΔL ∝ L′. Straight line rising from 0 at the fixed end to 10⁻³ at B (mid-length) and continuing to 2×10⁻³ at the free end; the vertical at the free end is split into 10⁻³ (lower) + 10⁻³ (upper).",
        ] },
        { k: "eg", title: "MACE notes example — Que11: elongations of the two segments", given: "Stepped bar fixed at the left: left segment A = 1000 mm², right segment A = 500 mm², each 100 mm long, E = 200 GPa; 1000 N → at B and 1000 N → at the free end. Find the segment elongations for the displacement diagram.", steps: [
          { t: "Left segment (P = 2000 N)", w: "ΔL₁ = PL/AE = (2000×100)/(1000×200×10³)\nΔL = 1×10⁻³ mm" },
          { t: "Right segment (P = 1000 N)", w: "ΔL₂ = PL/AE = (1000×100)/(500×200×10³)\nΔL = 1×10⁻³ mm" },
          { t: "Displacement diagram", w: "0 at the wall → 10⁻³ mm at B → 2×10⁻³ mm at the free end (10⁻³ + 10⁻³)" },
        ], ans: "ΔL₁ = 1×10⁻³ mm, ΔL₂ = 1×10⁻³ mm; free end moves 2×10⁻³ mm; stress 2 MPa throughout; thrust 2000 N then 1000 N. (M p.76)" },
        { k: "eg", title: "MACE notes example — Que12: thrust diagram, deflection diagram and deflections at B and C", given: "Draw the axial thrust diagram & deflection diagram of bar given below & find out axial deflection at point B and C. A = 200 mm², E = 200 GPa. (Figure: bar A–B–C fixed at A (wall); load → 200 N at B; load → 200 N at free end C; AB = 1000 mm, BC = 1000 mm.)", steps: [
          { t: "Free bodies", w: "Segment AB: 400 ← at left, → 400 at B (ΔL = 0 at A)\nSegment BC: 200 ← at left, → 200 at C" },
          { t: "ΔL = PL/AE for AB", w: "ΔL = (400×1000)/(200×200×10³)\n(ΔL)_B = 0.01 mm" },
          { t: "ΔL = PL/AE for BC", w: "(ΔL)_C = (200×1000)/(200×200×10³)\n= 0.5×10⁻²\n(ΔL)_C = 0.005 mm" },
          { t: "Axial thrust diagram", w: "Stepped: 400 N over AB, drops at B to 200 N over BC" },
          { t: "Normal stress diagram", w: "2 MPa over AB (labelled at A and at B), steps down to 1 MPa over BC" },
          { t: "Axial displacement diagram", w: "Line from 0 at A rising to 0.01 mm at B, then with flatter slope to 0.015 mm at C; vertical at C split into 0.01 mm (lower) + 0.005 mm (upper)" },
        ], ans: "(ΔL)_B = 0.01 mm; (ΔL)_C = 0.005 mm; displacement diagram reaches 0.015 mm at C. (M p.77)" },
        { k: "note", t: "<b>Check:</b> The boxed (ΔL)_C = 0.005 mm is the <b>elongation of segment BC alone</b>. The axial deflection (movement) of point C measured from the fixed end is 0.01 + 0.005 = <b>0.015 mm</b> — the value the notes' own displacement diagram shows at C. The deflection of B is 0.01 mm. Stresses check: 400/200 = 2 MPa, 200/200 = 1 MPa ✔." },
        { k: "p", t: "Memory line beside the displacement diagram (M p.77): <b>चा slope म्हणजे strain</b> (Marathi: 'its slope means strain' — the slope of the axial displacement diagram is the strain)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen diagrams ek chain hain: <b>thrust</b> (har section par internal force) ÷ area = <b>stress</b>; stress ÷ E = strain; aur strain ko length ke saath jodte jao (integrate) to <b>displacement</b>. Isliye displacement diagram har segment mein seedhi line hai aur uska slope = us segment ka strain. Que11 mein stress dono taraf 2 MPa hai, isliye slope same hai aur line ek hi seedhi line ban jaati hai; Que12 mein BC ka stress aadha hai, isliye wahan line ka slope aadha (flatter) ho jaata hai." },
        { k: "trap", t: "Displacement diagram mein point ka deflection <b>cumulative</b> hota hai — fixed end se us point tak saare segments ka ΔL jodo. Que12 mein C ka deflection 0.005 mm nahi, 0.015 mm hai; 0.005 mm sirf BC ka stretch hai." },
        { k: "real", t: "The same thrust-and-displacement picture is used for a pile carrying load in stages (shaft force dropping with depth as friction is shed) and for a multi-storey column, where the axial force steps up at each floor." },
      ],
    },

    /* ---------------------------------------------------------- M p.77–78 */
    {
      n: "",
      title: "MACE notes — composite bars: compatibility and equivalent modulus",
      hi: "संयुक्त दंड — संगतता शर्त और समतुल्य प्रत्यास्थता मापांक",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.77–78" },
        { k: "h", t: "★ Axial deflection of composite bar (M p.77)" },
        { k: "def", term: "Compatibility condition", t: "(i) <b>P = P₁ + P₂</b> — total load shared by both.<br>(ii) <b>ΔL₁ = ΔL₂ = ΔL</b> — both bars deflect by the same amount. (M p.77)" },
        { k: "p", t: "Figure (M p.77): composite bar of length L between two end plates; upper bar ① labelled P₁, A₁, E₁ (hatched one way), lower bar ② labelled P₂, A₂, E₂ (hatched the other way); load P ← at the left plate and → P at the right plate. (M p.77)" },
        { k: "steps", items: [
          "ΔL₁ = P₁L/(A₁E₁) ⇒ P₁ = ΔL₁ (A₁E₁/L) (M p.77)",
          "ΔL₂ = P₂L/(A₂E₂) ⇒ P₂ = ΔL₂ (A₂E₂/L) (M p.77)",
          "∴ P₁L/(A₁E₁) = P₂L/(A₂E₂) ⇒ <b>P₁/(A₁E₁) = P₂/(A₂E₂)</b> (boxed) (M p.77)",
          "P = P₁ + P₂ ⇒ ΔL(AE/L) = ΔL₁(A₁E₁/L) + ΔL₂(A₂E₂/L); ΔL and L cancel (struck off) (M p.77)",
          "<b>E = (A₁E₁ + A₂E₂)/(A₁ + A₂)</b> (boxed) [∵ A₁ + A₂ = A] ↳ equivalent modulus of elasticity (M p.77)",
        ] },
        { k: "eq", expr: "Equivalent modulus  E_eq = (A₁E₁ + A₂E₂)/(A₁ + A₂)   ;   (★) General formula:  ΔL = P·L/(A₁E₁ + A₂E₂)", where: [
          ["A₁, A₂", "areas of the two bars, A = A₁ + A₂"],
          ["E₁, E₂", "moduli of the two materials"],
          ["L", "common length of both bars"],
        ] },
        { k: "h", t: "★ Compatibility for three bars between rigid supports (M p.78)" },
        { k: "p", t: "Figure (M p.78): three vertical bars between a rigid top support (hatched) and a rigid bottom support. Left: Aluminium bar of length L_Alu (full height). Centre: steel bar of length L_st, ending on a raised (hatched) block on the bottom support, so it is shorter. Right: Aluminium bar (full height). Labels below: left P_Al, A_Al, E_Al; centre P_st, A_st, E_st; right P_Al, E_Al, A_Al. (M p.78)" },
        { k: "list", items: [
          "(i) Deflection (elongation/contraction) of all three bars is same, i.e. <b>(ΔL)_Al = (ΔL)_steel</b>. (M p.78)",
          "(ii) Total load is shared by all 3 bars: P = P_Al + P_st + P_Al ⇒ <b>P = 2P_Al + P_st</b> (boxed). (M p.78)",
        ] },
        { k: "note", t: "<b>Source difference:</b> none in substance. The existing <a href=\"#/read/som/2\">§2.3</a> writes the composite bar as σ_c = P/(A_c + mA_s) with m = E_s/E_c; the MACE notes write ΔL = PL/(A₁E₁ + A₂E₂). They are the same result: divide the MACE formula by L to get the common strain P/(A₁E₁ + A₂E₂); multiplying by E_c gives σ_c = P/(A_c + (E_s/E_c)A_s). Both rest on the same compatibility condition (equal strain)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Composite bar ke do bars ek hi end plates se jude hain, isliye dono ko <b>same</b> ΔL milna padega — yahi compatibility hai. Load phir stiffness AE ke ratio mein bat'ta hai: P₁ : P₂ = A₁E₁ : A₂E₂. Poore composite ko ek single bar maan sakte ho jiska area A₁ + A₂ aur modulus 'equivalent E' (area-weighted average) ho." },
        { k: "p", t: "Teen-bar wale case mein beech wali steel bar chhoti hai (raised block par khadi), par bottom support rigid hai, isliye teeno ka ΔL same hai — lambai alag hone se strain alag hoga, deflection nahi." },
        { k: "trap", t: "Equal deflection ka matlab equal strain tabhi hai jab lengths same hon. M p.78 jaise case mein (L_Al ≠ L_st) ΔL same lo, strain nahi: P_Al·L_Al/(A_Al·E_Al) = P_st·L_st/(A_st·E_st). Aur load sharing likhte waqt dono aluminium bars gino — P = 2P_Al + P_st." },
        { k: "real", t: "Reinforced concrete columns, steel-tube columns filled with concrete and bolts passing through sleeves are all composite bars: the two materials are forced to shorten together, so the stiffer steel picks up the larger stress." },
      ],
    },

    /* ---------------------------------------------------------- M p.78–79 */
    {
      n: "",
      title: "MACE notes — stress tensor, 3D and 2D stress matrices",
      hi: "प्रतिबल टेंसर — त्रिविमीय और द्विविमीय प्रतिबल मैट्रिक्स",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.78–79" },
        { k: "list", items: [
          "A 3D stress element is generally called as <b>stress tensor</b>. (M p.78)",
          "Stress, strain and moment of inertia all are tensor quantities. (M p.78)",
          "Tensors are the quantities which are expressed on the basis of their <b>plane of action</b> and the <b>axis along which they act</b>. (M p.78)",
          "Figure (M p.78): cube with the y-plane (top face) and y-axis (upward arrow); the x-plane (right face) and → x-axis; the z-plane (front face) and z-axis (arrow out of the front face).",
          "Types of force/stress by nature: ① normal force on any plane, which produces <b>normal stress</b>; ② tangential or parallel force on any plane, which produces <b>tangential or shear stress</b>. (M p.78)",
          "Shear stress is denoted by τ: <b>τ = Shear force / Area</b>. (M p.78)",
        ] },
        { k: "def", term: "Suffix convention", t: "In σ_zz (or τ_xy), the <b>first suffix = plane</b> on which the stress acts, the <b>second suffix = axis (direction)</b> in which it acts. (M p.78)" },
        { k: "p", t: "Figure (M p.78): 3D stress cube, axes y (up), x (right), z (out of page). Top face (y): σ_yy upward, τ_yx toward x, τ_yz toward z. Right face (x): σ_xx outward to the right, τ_xy upward, τ_xz toward z. Front face (z): σ_zz outward toward the viewer, τ_zy upward, τ_zx toward x. (M p.78)" },
        { k: "cmp", t: "Meaning of each stress component (M p.79)", cols: ["Plane", "Direction"], rows: [
          ["σ_xx — normal stress", "x-plane", "x"],
          ["σ_yy — normal stress", "y-plane", "y"],
          ["σ_zz — normal stress", "z-plane", "z"],
          ["τ_xy — shear stress", "x-plane", "y"],
          ["τ_xz — shear stress", "x-plane", "z"],
          ["τ_yx — shear stress", "y-plane", "x"],
          ["τ_yz — shear stress", "y-plane", "z"],
          ["τ_zx — shear stress", "z-plane", "x"],
          ["τ_zy — shear stress", "z-plane", "y"],
        ] },
        { k: "p", t: "Based upon the above loading situation, the total stress or equivalent stress on the material is written in matrix form — the <b>3D stress matrix or 3D stress tensor</b> (3×3): (M p.79)" },
        { k: "cmp", t: "3D stress matrix σ (3×3) (M p.79)", cols: ["y-column", "z-column"], rows: [
          ["x-plane row: σ_xx", "τ_xy", "τ_xz"],
          ["y-plane row: τ_yx", "σ_yy", "τ_yz"],
          ["z-plane row: τ_zx", "τ_zy", "σ_zz"],
        ] },
        { k: "list", items: [
          "(★) Normal stress components ⇒ <b>3</b> (M p.79)",
          "Shear stress components ⇒ <b>6</b> (M p.79)",
          "Total stress components ⇒ <b>9</b> (M p.79)",
        ] },
        { k: "h", t: "★ 2D stress matrix (M p.79)" },
        { k: "cmp", t: "2D stress matrix σ (2×2) (M p.79)", cols: ["y-column"], rows: [
          ["x-plane row: σ_xx", "τ_xy"],
          ["y-plane row: τ_yx", "σ_yy"],
        ] },
        { k: "p", t: "Figure (M p.79): square element — σ_xx → on the right face and σ_xx ← on the left face; σ_yy ↑ on top and σ_yy ↓ on bottom; τ_yx → along the top face and ← along the bottom face; τ_xy ↑ on the right face and ↓ on the left face. (M p.79)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek point par stress ek single number nahi hai — wo is par depend karta hai ki tum <b>kaunse plane</b> ko dekh rahe ho aur us plane par <b>kis direction</b> mein force hai. Isliye do suffix chahiye: pehla plane (jis axis ke perpendicular plane hai), doosra direction. Cube ke teen faces × har face par teen components = 9; diagonal par 3 normal, baaki 6 shear." },
        { k: "p", t: "2D (plane stress) mein z ka koi component nahi liya jaata, to sirf σ_xx, σ_yy, τ_xy, τ_yx bachte hain — yahi <a href=\"#/read/som/2\">§2.5</a> ke inclined-plane formulas ka input hai." },
        { k: "trap", t: "τ_xy aur τ_yx ko mix mat karo: τ_xy = <b>x-plane</b> par <b>y-direction</b> mein (right face par upar), τ_yx = <b>y-plane</b> par <b>x-direction</b> mein (top face par right). Magnitude same hai (agla section), par face alag hai." },
      ],
    },

    /* ---------------------------------------------------------- M p.79–80 */
    {
      n: "",
      title: "MACE notes — law of complementary shear stress",
      hi: "पूरक अपरूपण प्रतिबल का नियम",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.79–80" },
        { k: "p", t: "Consider a 2-dimensional stress system as shown below; only consider the shear stress components in the coordinate axes. (M p.79)" },
        { k: "p", t: "Figure (M p.79, left): x–y–z axes; cube element dx × dy × dz with σ_yy up and τ_yx on the top face (y), τ_xy and σ_xx on the right face (x), σ_zz on the front face (z); note with arrow to the z-axis: 'not consider any component of z-axis'." },
        { k: "p", t: "Figure (M p.79, right): x–y axes; square element ABCD (A bottom-left, B top-left, C top-right, D bottom-right), width dx, height dy. τ_yx → along top face BC; τ_yx ← along bottom face AD; τ_xy ↑ along right face CD; τ_xy ↓ along left face AB. Note: 'stress (not force)'." },
        { k: "h", t: "Consider equilibrium of body (M p.80)" },
        { k: "steps", items: [
          "<b>(i) Force equilibrium:</b> Σfx = 0: +τ_yx − τ_yx = 0; Σfy = 0: +τ_xy − τ_xy = 0. (M p.80)",
          "<b>(ii) Rotational equilibrium:</b> ΣM_A = 0: +τ_yx × (dx·dz) × BA − τ_xy × (dy·dz) × DA = 0 (M p.80)",
          "τ_yx × dx·dz × dy = τ_xy × dy·dz × dx (dx, dz, dy struck off both sides) (M p.80)",
          "(★) <b>τ_yx = τ_xy</b> — law of complementary shear (boxed, highlighted). (M p.80)",
        ] },
        { k: "eq", expr: "τ_yx = τ_xy   (law of complementary shear stress)", where: [
          ["force", "stress × area of the face (dx·dz on top/bottom, dy·dz on the sides)"],
          ["arm", "BA = dy for the top-face force, DA = dx for the side-face force"],
        ] },
        { k: "p", t: "The law of complementary shear (written 'complimentary function' in the notes) is based upon <b>rotational equilibrium</b> of the body. (M p.80)" },
        { k: "h", t: "NOTE (M p.80)" },
        { k: "list", items: [
          "Owing to the characteristic of complementary shear stresses for the equilibrium of members subjected to shear stresses, <b>near a free boundary on which no external force acts, the shear stress must follow a direction parallel to the boundary</b>. (M p.80)",
          "This is because any component of the shear force perpendicular to the surface will find no complementary shear on the boundary plane. (M p.80)",
          "The presence of complementary shear stress may cause an <b>early failure of anisotropic materials such as timber</b>, which is weak in shear along the grain than normal to the grain. (M p.80)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Top aur bottom faces ke shear forces ek couple banate hain jo element ko ek taraf ghumana chahta hai; side faces ke shear forces doosra couple banate hain jo ulti taraf ghumata hai. Element ghoom nahi raha (equilibrium), to dono couples barabar — aur area × arm dono taraf dx·dy·dz hi aata hai, isliye stresses barabar: τ_xy = τ_yx. Isliye ek plane par shear ho to uske perpendicular plane par bhi utna hi shear hona <b>zaroori</b> hai." },
        { k: "p", t: "Yahi wajah hai ki beam ki vertical shear ke saath horizontal shear bhi hoti hai (<a href=\"#/read/som/4\">Chapter 4</a> ka q = Faȳ/Ib), aur timber beam aksar grain ke along horizontally split hoti hai — wahan complementary (horizontal) shear lagta hai jahan lakdi kamzor hai." },
        { k: "trap", t: "Complementary shear <b>force equilibrium</b> se nahi nikalta — ΣFx = 0 aur ΣFy = 0 to apne aap satisfy ho jaate hain. Ye <b>moment (rotational) equilibrium</b> se aata hai. MCQ mein 'based on' pucha jaaye to answer rotational equilibrium hai." },
        { k: "real", t: "At a free surface of a beam (top or bottom fibre, or any unloaded edge) there is no shear stress perpendicular to that surface — which is why the shear-stress distribution in a rectangular beam is zero at the extreme fibres." },
      ],
    },

    /* ---------------------------------------------------------- M p.81–82 */
    {
      n: "",
      title: "MACE notes — shear strain, sign convention of shear and the strain matrix",
      hi: "अपरूपण विकृति, अपरूपण का चिह्न परिपाटी और विकृति मैट्रिक्स",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.81–82" },
        { k: "cmp", t: "Strain (M p.81)", cols: ["Symbol", "Direction / cause"], rows: [
          ["Axial strain", "ε_lin", "in the direction of load (P_normal)"],
          ["Lateral strain", "ε_lat", "in the direction perpendicular to load (P_normal)"],
          ["Shear strain", "φ", "due to τ or shear force"],
        ] },
        { k: "def", term: "Shear strain (φ)", t: "Shear strain or <b>angular deformation</b>. Figure (M p.81): rectangular block of height h fixed to the ground (hatched base); S = shear force → at the top; the top is displaced by ΔL; the deformed position (red) has the left side inclined at angle φ from the vertical. (M p.81)" },
        { k: "h", t: "★ Sign conventions of shear (M p.81)" },
        { k: "p", t: "Sign key: ↑ +, → +, ← −, ↓ −. (M p.81)" },
        { k: "cmp", t: "Positive and negative shear on an element (M p.81)", cols: ["Arrows on the faces", "Sign rule (red notes)"], rows: [
          ["+ve shear", "τ_yx → on top (+); τ_xy ↑ on right (+); τ_yx ← on bottom (−); τ_xy ↓ on left (−)", "top &amp; right: + × + = +ve; bottom &amp; left: − × − = +ve"],
          ["−ve shear", "τ_yx ← on top (−); τ_xy ↑ on left (+); τ_xy ↓ on right (−); τ_yx → on bottom (+)", "top &amp; left: + × − ⇒ −ve; bottom &amp; right: + × − ⇒ −ve"],
        ] },
        { k: "h", t: "★ Positive and negative cases of shear (M p.81)" },
        { k: "list", items: [
          "Figure, +ve shear (M p.81): x–y axes; original square with corner A at the origin; deformed (red) rhombus leaning to the right, with B (top-right corner) moved up-right; angle φ/2 between the left side and the y-axis and φ/2 between the bottom side and the x-axis at A; dashed diagonal AB. Inset: shear arrows top →, right ↑, bottom ←, left ↓. Label: <b>AB → diagonal (under compression)</b>. Total shear strain = φ/2 + φ/2 ⇒ φ.",
          "Figure, −ve shear (M p.81): original square with corner A at the origin; deformed (red) rhombus with the left side tilted left of the y-axis (φ/2) and the bottom side tilted below the x-axis (φ/2); B at top-right; dashed diagonal AB. Inset: shear arrows top ←, left ↑, right ↓, bottom →. Label: <b>AB → diagonal (under tension)</b>. Total shear strain = φ/2 + φ/2 ⇒ φ.",
          "Below each case (M p.81): a sketch of a hatched vertical support with a horizontal member joined at its corner, with a short red crack line at the corner — under +ve shear the line runs downward to the right from the top corner; under −ve shear it runs upward to the right.",
        ] },
        { k: "note", t: "<b>Check:</b> In the notes' own +ve-shear figure the angle at A closes from 90° to 90° − φ (both sides rotate towards the diagonal) and B moves outward, so the diagonal AB through A and B gets <b>longer — it is in tension</b>; the other diagonal shortens (compression). In the −ve case the angle at A opens to 90° + φ, so AB <b>shortens — compression</b>. The labels 'compression' (+ve) and 'tension' (−ve) on M p.81 are interchanged. This agrees with the existing <a href=\"#/read/som/2\">§2.5</a>: pure shear is equivalent to principal stresses ±τ on the 45° diagonals, with tension along the diagonal that the shear arrows point towards (here the A–B diagonal for +ve shear)." },
        { k: "p", t: "<b>★ NOTE:</b> After analysis of strain i.e. shear strain, we come to know that linear strain is half of the shear strain, i.e. <b>linear strain = shear strain (φ)/2 = φ/2</b>. (M p.81)" },
        { k: "h", t: "★ Matrix representation of strain (M p.82)" },
        { k: "cmp", t: "Strain matrix (M p.82)", cols: ["y-column", "z-column"], rows: [
          ["x-row: ε_xx", "φ_xy/2", "φ_xz/2"],
          ["y-row: φ_yx/2", "ε_yy", "φ_yz/2"],
          ["z-row: φ_zx/2", "φ_zy/2", "ε_zz"],
        ] },
        { k: "p", t: "Figure (M p.82): 3D cube — top face: ε_yy upward, φ_yx/2 toward x, φ_yz/2 toward z; right face: ε_xx outward, φ_xy/2 upward, φ_xz/2 toward z; front face: ε_zz outward toward the viewer, φ_zy/2 upward, φ_zx/2 toward x. (M p.82)" },
        { k: "list", items: [
          "⇒ φ_xy, φ_xz … etc. are shear strains. (M p.82)",
          "Linear strain = fn(φ) ∴ <b>ε_linear = φ/2</b>. (M p.82)",
          "As per the law of complementary shear: [τ_yx = τ_xy] — τ₁, [τ_xz = τ_zx] — τ₂ and [τ_yz = τ_zy] — τ₃. (M p.82)",
          "<b>For 3D:</b> independent shear components = 3; normal stress components = 3; total (written 'total shear component') = <b>6</b>. (M p.82)",
          "<b>For 2D:</b> independent shear component = 1; normal stress components = 2; total (written 'total shear component') = <b>3</b>. (M p.82)",
        ] },
        { k: "note", t: "<b>Check:</b> The totals 6 (3D) and 3 (2D) are correct, but they are the totals of <b>independent stress components</b> (normal + independent shear), not 'shear components' as the label on M p.82 reads. The independent shear components alone are 3 (3D) and 1 (2D)." },
        { k: "eg", title: "MACE notes example — Que1: shear modulus from a strain matrix", given: "A block is tested for shear stress. The shear stress applied in x-y plane was fixed to 1000 MPa. The strain matrix corresponding to applied stresses is shown below. What will be the shear modulus of test block. Strain = [0.002 0.005 0.003 ; 0.005 0.006 0.000 ; 0.003 0.000 0.009] (arrow to 0.005 in row 1, column 2: φ_xy/2). a) 100 GPa  b) 200 GPa  c) 150 GPa  d) 250 GPa", steps: [
          { t: "Read the data", w: "τ_xy = 1000 MPa\nφ_xy/2 = 0.005\n∴ φ_xy = 0.01" },
          { t: "Shear modulus (G) = τ/φ", w: "G = τ/φ\n= 1000/0.01\n= 1000×10²\n= 100×10³ MPa" },
          { t: "Convert", w: "But 1 GPa = 10³ MPa\n∴ G = 100 GPa" },
        ], ans: "(a) G = 100 GPa (M p.82)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Shear strain φ ek <b>angle</b> hai — square kitna tircha (rhombus) ho gaya. Ye tirchapan do sides mein bat jaata hai: har side φ/2 ghoomti hai. Isliye strain matrix ke off-diagonal mein φ/2 likha jaata hai (tensor shear strain), aur pure shear mein 45° diagonal ka linear strain bhi φ/2 hi nikalta hai — yahi relation <a href=\"#/read/som/2\">§2.1</a> mein E = 2G(1 + μ) derive karne mein use hua hai." },
        { k: "p", t: "Que1 jaisa sawaal 'matrix padhne' ka test hai: matrix mein jo 0.005 hai wo φ_xy/2 hai, φ_xy nahi. Double karo (0.01), phir G = τ/φ. Matrix symmetric hai (0.005 dono jagah, 0.003 dono jagah) — complementary shear ka hi result." },
        { k: "trap", t: "Strain matrix ki off-diagonal value ko seedha φ maan lena sabse common galti hai: 1000/0.005 = 200 GPa (option b) aata hai, jo galat hai. Off-diagonal = φ/2, isliye pehle 2 se multiply karo → G = 100 GPa." },
        { k: "real", t: "Strain gauges and rosettes read linear strains only; the shear strain at a point is obtained from them through exactly this φ/2 relation (see the strain-rosette part of §2.6)." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — bars in series, composite bars, stress tensor and strain matrix (M p.73–82)",
      hi: "पुनरावृत्ति — श्रेणी दंड, संयुक्त दंड, प्रतिबल टेंसर और विकृति मैट्रिक्स",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and definitions (M p.73–82)" },
        { k: "list", items: [
          "✅ Bars in series, same P: U = (P²/2) Σ L/(AE) = axial flexibility × P²/2 (M p.73)",
          "✅ Same E: U = (2P²/πE) Σ L/d²; same E and L: U = (2P²L/πE) Σ 1/d² (M p.73)",
          "✅ Diameter doubled (same P): U becomes ¼, i.e. reduces by 75% — U ∝ 1/d² (M p.73)",
          "✅ Stepped bar: ΔL = P Σ L/(AE); same E: ΔL = (4P/πE) Σ L/d²; same E and L: ΔL = (4PL/πE) Σ 1/d² (M p.74)",
          "✅ Missing load: ΣFx = 0; a negative answer means the assumed direction is wrong (Que7: P = 3 KN; Ques8: P = 4 KN →) (M p.74–75)",
          "✅ Ques9: internal forces 1000 N, 1400 N, 600 N (all tensile); ΔL = (1/AE)ΣPL = 0.005 mm (M p.75)",
          "✅ Strain energy is not superposable (U ∝ P²): U &gt; U₁ + U₂ for separate load cases; segment energies with their internal forces may still be added (M p.72, p.76; see Check)",
          "✅ Diagrams: axial thrust → normal stress (σ = P/A) → displacement (ΔL = PL/AE, slope = strain — 'चा slope म्हणजे strain') (M p.76–77)",
          "✅ Que11: 2000 N / 1000 N thrust, 2 MPa stress throughout, displacement 10⁻³ mm at B and 2×10⁻³ mm at the free end (M p.76)",
          "✅ Que12: (ΔL)_B = 0.01 mm; BC stretches 0.005 mm; C moves 0.015 mm; stress 2 MPa then 1 MPa (M p.77)",
          "✅ Composite bar compatibility: P = P₁ + P₂ and ΔL₁ = ΔL₂ = ΔL; P₁/(A₁E₁) = P₂/(A₂E₂) (M p.77)",
          "✅ Equivalent E = (A₁E₁ + A₂E₂)/(A₁ + A₂); ΔL = PL/(A₁E₁ + A₂E₂) (M p.77)",
          "✅ Al–steel–Al bars: (ΔL)_Al = (ΔL)_steel and P = 2P_Al + P_st (M p.78)",
          "✅ Stress, strain and moment of inertia are tensors; first suffix = plane, second = direction (M p.78)",
          "✅ 3D stress tensor: 3 normal + 6 shear = 9 components; 2D stress matrix is 2×2 (M p.79)",
          "✅ Complementary shear τ_xy = τ_yx — from rotational (moment) equilibrium (M p.80)",
          "✅ At a free, unloaded boundary the shear stress is parallel to the boundary; complementary shear can cause early failure of timber along the grain (M p.80)",
          "✅ Shear strain φ = angular deformation; +ve shear: top → and right ↑ (+ × +); total shear strain = φ/2 + φ/2 = φ (M p.81)",
          "✅ Linear strain = φ/2; strain matrix off-diagonals are φ/2 (M p.81–82)",
          "✅ Independent components: 3D = 3 normal + 3 shear = 6; 2D = 2 normal + 1 shear = 3 (M p.82)",
          "✅ G = τ/φ; Que1: φ_xy = 2 × 0.005 = 0.01, G = 1000/0.01 = 100 GPa (M p.82)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
