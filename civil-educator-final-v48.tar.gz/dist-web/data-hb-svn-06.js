/* Surveying class notes — Compass surveying: local attraction and its correction, adjusting FB/BB, equilateral traverse, three-ships problem, prismatic and surveyor's compass, notes p.30–42 and p.239–240 — inserted into sv chapter 4 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 4; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- p.30–31 */
    { n: "", title: "Notes — Local attraction: cause and detection", hi: "स्थानीय आकर्षण — कारण और पहचान", blocks: [
      { k: "h", t: "📘 Notes — p.30–31" },
      { k: "def", term: "Local attraction", t: "Local attraction is the attraction of the magnetic needle to a <b>local magnetic field other than the earth's magnetic field</b>. (p.30)" },
      { k: "p", t: "It is caused by any <b>iron material in the vicinity (area) of the compass station</b>.<br>Eg: bus, buckle of belt, dial gauge of wrist watch, transmission line etc. (p.30)" },
      { k: "p", t: "Under the influence of the local magnetic field the magnetic needle will <b>deflect</b> (इधर-उधर) from the magnetic meridian, resulting in <b>erroneous</b> (गलत) reading of a traverse at that station. (p.30)" },
      { k: "p", t: "To determine local attraction it is <b>mandatory to take the fore bearing and back bearing of each line</b>. The two bearings (fore and back bearing of a line) should differ by <b>exactly 180°</b>. If the difference between fore bearing and back bearing is different from 180°, local attraction is suspected<br>(A) at both the stations, or<br>(B) at either of the stations. (p.30)" },
      { k: "list", items: [
        "Figure (p.30, bottom left): a line joining two stations; at the left station a meridian with the bearing angle α₁, at the right station a meridian with the bearing angle α₂; the line is marked 180° — i.e. α₂ should equal α₁ ± 180° when there is no local attraction.",
        "Figure (p.30, bottom right): vertical axis TN and a horizontal axis; a line MN (magnetic north) inclined to TN, and a further inclined line labelled \"← due to local attraction\" — the needle pulled away from the magnetic meridian.",
      ] },
      { k: "note", t: "<b>Note:</b> local attraction affects <b>all the bearings of a station by the same amount</b>. (p.31)" },
      { k: "h", t: "Correction for local attraction (p.31)" },
      { k: "list", items: [
        "1) By calculating local attraction at each station",
        "2) The method of included angles",
      ] },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Local attraction station ki bimari hai, line ki nahi. Jis station par iron paas mein hai, wahan needle har direction mein same amount se khiski hui hai — isliye us station se li gayi har bearing mein same error hoga. FB aur BB ka 180° wala test isi liye hai: agar kisi line ka FB − BB exactly 180° hai to dono end stations saaf hain. Chapter ka main 'Local attraction' section bhi yahi baat 'property of the station' kehkar samjhata hai." },
      { k: "trap", t: "If FB − BB ≠ 180°, the notes say attraction is suspected at <b>both</b> stations or at <b>either</b> one — you cannot tell which from that one line alone. Students often blame the second station automatically. Only a neighbouring clean line tells you which station is at fault." },
      { k: "real", t: "The notes' list is practical: a passing bus, your own belt buckle, a wrist watch, an overhead transmission line. Keep steel tapes, arrows and phones away from the compass while reading." },
    ] },

    /* ---------------------------------------------------------- p.31–32 */
    { n: "", title: "Notes — Method 1: local attraction at each station", hi: "विधि 1 — प्रत्येक स्टेशन पर स्थानीय आकर्षण", blocks: [
      { k: "h", t: "📘 Notes — p.31–32" },
      { k: "p", t: "In this method local attraction at each station is found out and the required correction is applied to the observed bearings. (p.31)" },
      { k: "steps", items: [
        "<b>Step 1</b> — Observe a line whose FB and BB differ by exactly 180°. (p.31)",
        "<b>Step 2</b> — End stations of such a line are considered free from local attraction, and readings observed from these stations are assumed to be correct. (p.31)",
        "<b>Step 3</b> — With the help of bearings of the previous or next station, bearings of all other lines are calculated correctly. (p.31)",
      ] },
      { k: "eq", expr: "Error (local attraction) at a station = M.V − T.V   ;   Correction = − Error", where: [
        ["M.V", "measured (observed) value of the bearing at that station"],
        ["T.V", "true (correct) value of the bearing"],
      ] },
      { k: "cmp", t: "Observed bearings (p.32). Circled values written beside the table in the notes are the corrected bearings.", cols: ["FB", "BB"], rows: [
        ["AB", "140° (138° circled)", "318°"],
        ["BC", "60°", "240°"],
        ["CD", "125°", "302° (305° circled)"],
        ["DE", "150° (153° circled)", "333°"],
      ] },
      { k: "eg", title: "Notes example — Correct bearings of a traverse (Method 1)",
        given: "Line AB: FB 140°, BB 318°; BC: FB 60°, BB 240°; CD: FB 125°, BB 302°; DE: FB 150°, BB 333°. Find correct bearings of the traverse.",
        steps: [
          { t: "Find the clean line", w: "Line BC has a difference of 180° in its FB and BB (240° − 60° = 180°)\nso stations B and C are free from local attraction and readings taken from B and C are correct" },
          { t: "Correct readings", w: "BB of AB = 318°\nFB of BC = 60°\nBB of BC = 240°\nFB of CD = 125°" },
          { t: "Line AB", w: "Correct FB of AB = 318° − 180° = 138° (T.V)\nError / local attraction of A = M.V − T.V = 140° − 138° = +2°\nCorrection at A = −2°" },
          { t: "Line CD", w: "Correct BB of CD = 125° + 180° = 305° (T.V)\nError at E = M.V − T.V = 302° − 305° = −3°\nCorrection at D = +3°" },
          { t: "Line DE", w: "(Correct) FB of DE = 150° + 3° = 153°\nCorrect, now BB = 180° + 153° = 333°" },
        ],
        ans: "Corrected: AB 138° / 318°, BC 60° / 240°, CD 125° / 305°, DE 153° / 333°. Correction at A = −2°, at D = +3°; B, C (and E) free. (p.32)" },
      { k: "note", t: "<b>Check:</b> the notes write \"Error at E = 302° − 305° = −3°\". 302° is the back bearing of CD, which is observed at <b>D</b>, so this is the error at D (the next line correctly says \"correction at D = +3°\"). The value −3° is right. E is free: observed BB of DE 333° = corrected FB 153° + 180°. (p.32)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Logic ek chain hai. Saaf line (BC) se shuru karo. B saaf hai, isliye B par li gayi BB of AB = 318° sahi hai; usse FB of AB = 138° milti hai, aur A par padhi 140° se A ka error +2° nikla. Isi tarah C saaf hai to FB of CD = 125° sahi; isse BB of CD 305° honi chahiye thi, D par 302° padha — D ka error −3°, correction +3°, jo D ki <b>har</b> bearing (FB of DE bhi) par lagega." },
      { k: "trap", t: "Sign: error = observed − correct, and the correction has the <b>opposite</b> sign. A station reading 2° too high (+2° error) needs −2°. Adding the error instead of the correction doubles the mistake." },
    ] },

    /* ---------------------------------------------------------- p.33–36 */
    { n: "", title: "Notes — Method 2: included angles, with the five-line traverse solved both ways", hi: "विधि 2 — अन्तर्गत कोण विधि", blocks: [
      { k: "h", t: "📘 Notes — p.33–36" },
      { k: "p", t: "This method is <b>most suitable for a closed traverse</b>. In this method <b>included angles</b> are used for determining the correct bearings of lines. (p.33)" },
      { k: "steps", items: [
        "<b>Step 1</b> — Calculate the included angles of the traverse and check their sum against (2n ± 4) × 90°. If there is any error in the observed bearings, in this case the required correction is distributed equally in all the included angles. (p.33)",
        "<b>Step 2</b> — Locate a line whose FB and BB differ by exactly 180°. (p.33)",
        "<b>Step 3</b> — Find out correct bearings of successive lines by using the correct observed bearing and the correct included angles. (p.33)",
      ] },
      { k: "eq", expr: "Included angle at a station = FB of the next line − BB of the previous line  (add 360° if negative)", where: [
        ["e.g. ∠B", "FB of BC − BB of AB"],
        ["check", "sum of interior angles = (2n − 4) × 90°, n = number of sides"],
      ] },
      { k: "cmp", t: "Observed bearings — compass traverse ABCDEA run anticlockwise (p.33–34)", cols: ["FB", "BB"], rows: [
        ["AB", "150°", "329°45′"],
        ["BC", "77°30′", "256°"],
        ["CD", "41°30′", "222°45′"],
        ["DE", "314°15′", "134°45′"],
        ["EA", "220°15′", "40°15′"],
      ] },
      { k: "eg", title: "Notes example — Five-line traverse ABCDEA, Method 1",
        given: "The compass traverse ABCDEA (bearings in the table above) was run anticlockwise. Determine the local attraction and correct bearings by both the methods.",
        steps: [
          { t: "Clean line", w: "Line EA differs by 180°, as 220°15′ − 40°15′ = 180°\nHence BB of line DE is correct, i.e. 134°45′\nand FB of line AB is correct, i.e. 150°" },
          { t: "Correct readings", w: "Correct BB of AB = 150° + 180° = 330° (T.V)\nFB of AB = 150°\nFB of EA = 220°15′\nBB of EA = 40°15′\nBB of DE = 134°45′" },
          { t: "Error and corrected BC", w: "Error at A = 329°15′ − 330° = −15′\nCorrect FB of BC = 77°30′ + 15′ = 77°45′\nCorrect BB of BC = 180° + 77°45′ = 257°45′" },
          { t: "Error and corrected CD", w: "The value (correction) at B = 256° − 257°45′ = −1°45′\nCorrect FB of CD = 41°30′ + 1°45′ = 43°15′\nCorrect BB of CD = 43°15′ + 180° = 223°15′" },
          { t: "Error and corrected DE", w: "Error at C = 222°45′ − 223°15′ = −0°30′\nCorrect FB of DE = 314°15′ + 0°30′ = 314°45′\nCorrect BB of DE = 315°45′ − 180° = 134°45′" },
        ],
        ans: "Corrected bearings: AB 150° / 330°, BC 77°45′ / 257°45′, CD 43°15′ / 223°15′, DE 314°45′ / 134°45′, EA 220°15′ / 40°15′. (p.34–35)" },
      { k: "note", t: "<b>Check (p.34–35):</b> (1) \"Error at A = 329°15′ − 330°\": the observed BB of AB is 329°45′ (table), and 329°45′ − 330° = −15′, the value the notes use; 329°15′ − 330° would be −45′. (2) The station labels run one behind: BB of AB is read at <b>B</b>, BB of BC at <b>C</b>, BB of CD at <b>D</b>. So the errors are B = −15′, C = −1°45′, D = −0°30′ (corrections +15′, +1°45′, +0°30′); A and E are free. The values are right, only the letters slip. (3) \"Correct BB of DE = 315°45′ − 180° = 134°45′\": the FB just found is 314°45′, and 314°45′ − 180° = 134°45′ ✓ (315°45′ − 180° would be 135°45′). The final 134°45′ agrees with the observed BB at the clean station E, so the corrections close." },
      { k: "p", t: "<b>Figure (p.35), Method 2:</b> the closed traverse drawn as a pentagon — A at left, B at bottom, C lower right, D at right, E at top — with a N–S/E–W cross at each station and red arcs for the included angles. At A: 40°15′ (towards E), 150° (towards B), included angle 109°45′. At B: 77°30′ (towards C), 329°45′ (towards A), included angle 107°45′. At C: 41°30′ (towards D), 256° (towards B), included angle 145°30′. At D: 222°45′ (towards C), 314°15′ (towards E), included angle written 92°45′ with a × beside it (computed below as 91°30′). At E: 220°15′ (towards A), 134°45′ (towards D), included angle 85°30′. (p.35)" },
      { k: "eg", title: "Notes example — Five-line traverse ABCDEA, Method 2 (included angles)",
        given: "Same traverse ABCDEA, run anticlockwise. Find the included angles and the correct bearings.",
        steps: [
          { t: "Included angles", w: "∠A = FB of AB − BB of EA = 150° − 40°15′ = 109°45′\n∠B = FB of BC − BB of AB = 77°30′ − 329°45′ + 360° = 107°45′\n∠C = FB of CD − BB of BC = 41°30′ − 256° + 360° = 145°30′\n∠D = FB of DE − BB of CD = 314°15′ − 222°45′ = 91°30′\n∠E = 220°15′ − 134°45′ = 85°30′" },
          { t: "Sum check", w: "Sum = 540° = (2n − 4) × 90° (n = 5)" },
          { t: "Clean line", w: "EA has a difference of 180° in BB and FB\nE and A are free from local attraction\nFB of AB = 150° — correct; BB = 150° + 180° = 330°" },
          { t: "Line BC", w: "∠B = FB of BC − BB of AB\nFB of BC = 170° + 330° − 360° = 77°45′" },
          { t: "Line CD", w: "∠C = FB of CD − BB of BC\n145°30′ = FB of CD − (77°45′ + 180°)\nFB of CD = 145°30′ + 77°45′ + 180° − 360° = 43°15′" },
          { t: "Line DE", w: "∠D = FB of DE − BB of CD\n91°30′ = FB of DE − (43°15′ + 180°)\nFB of DE = 91°30′ + 43°15′ + 180° = 314°45′\nBB of DE = 314°45′ − 180° = 134°45′" },
        ],
        ans: "Included angles 109°45′, 107°45′, 145°30′, 91°30′, 85°30′ (sum 540°). Correct FB: AB 150°, BC 77°45′, CD 43°15′, DE 314°45′ (BB of DE 134°45′) — same as Method 1. (p.35–36)" },
      { k: "note", t: "<b>Check (p.36):</b> the notes write \"FB of BC = 170° + 330° − 360° = 77°45′\". The angle to add is ∠B = 107°45′ (struck out on the left of that line): 107°45′ + 330° − 360° = 77°45′ ✓. Taken literally, 170° + 330° − 360° = 140°." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Method 2 ka secret: ek station par dono bearings mein same error hota hai, to unka <b>difference</b> (included angle) error-free hota hai. Isliye pehle saare angles nikalo aur (2n − 4) × 90° se check karo — yahan 540° exactly aaya, matlab angles mein koi galti nahi. Phir clean line EA se shuru karke angle jodte jao: FB next = ∠ + BB previous (360° se upar ho to 360° ghatao). Dono methods ne same answer diya — yahi asli check hai." },
      { k: "trap", t: "In Method 1 it is very easy to name the wrong station. The back bearing of a line is read at its <b>far</b> end: BB of AB is observed at B, not A. Write the station name next to every observed value before you start." },
      { k: "real", t: "Method 2 is preferred for a closed traverse in the field because the angle-sum check catches reading or booking mistakes before any bearing is corrected." },
    ] },

    /* ---------------------------------------------------------- p.37–38 */
    { n: "", title: "Notes — When no line has FB − BB = 180°: adjusting FB and BB", hi: "जब कोई रेखा 180° पर न हो — FB और BB का समायोजन", blocks: [
      { k: "h", t: "📘 Notes — p.37–38" },
      { k: "p", t: "Here we can observe that <b>none of the lines has a difference in FB and BB of exactly 180°</b>. (p.37)" },
      { k: "p", t: "In such a case we choose a line such that it has the <b>least deviation from 180°</b> in its FB and BB. Then the FB and BB of this line are adjusted such that their difference becomes exactly 180°. (p.37)" },
      { k: "note", t: "The question table for this traverse is not copied in the notes. The working uses line AB (FB 191°30′, BB 13°) and the included angles ∠A = 138°, ∠B = 56°, ∠C = 145°15′, ∠D = 51°45′, ∠E = 149°. (p.37–38)" },
      { k: "eg", title: "Notes example — Traverse ABCDE with no clean line",
        given: "None of the lines has FB and BB differing by exactly 180°. Line AB: FB 191°30′, BB 13°. Included angles: ∠B = 56°, ∠C = 145°15′, ∠D = 51°45′, ∠E = 149°, ∠A = 138°. Find the corrected bearings.",
        steps: [
          { t: "Choose the line nearest to 180°", w: "AB is the line which is nearest to 180°, i.e. 191°30′ − 13° = 178°30′" },
          { t: "Difference and half", w: "180° − 178°30′ = 1°30′ (difference)\n1°30′ / 2 = 45′" },
          { t: "Adjust FB and BB of AB so that their difference becomes 180°", w: "Correct FB of AB = 191°30′ + 45′ = 192°15′\nBB of AB = 13° − 45′ = 12°15′\n(FB − BB) of line AB = 180°" },
          { t: "Line BC", w: "∠B = FB of BC − BB of AB\n56° = FB of BC − 12°15′\nFB of BC = 68°15′" },
          { t: "Line CD", w: "∠C = FB of CD − BB of BC\n145°15′ = FB of CD − (180° + 68°15′)\nFB of CD = 33°30′" },
          { t: "Line DE", w: "∠D = FB of DE − BB of CD\n51°45′ = FB of DE − (180° + 33°30′)\nFB of DE = 265°15′" },
          { t: "Line EA", w: "∠E = FB of EA − BB of DE\n149° = FB of EA − (265°15′ − 180°)   [the 15′ is overwritten in the notes]\nFB of EA = 234°15′" },
          { t: "Closing check at A", w: "∠A = FB of AB − BB of EA\n138° = FB of AB − (234°15′ − 180°)\nFB of AB = 192°15′" },
        ],
        ans: "FB of AB = 192°15′ (BB 12°15′), BC = 68°15′, CD = 33°30′, DE = 265°15′, EA = 234°15′; the working closes back on FB of AB = 192°15′. (p.37–38)" },
      { k: "p", t: "Arithmetic re-worked: 56° + 145°15′ + 51°45′ + 149° + 138° = 540° = (2n − 4) × 90° for n = 5, and every boxed FB on p.38 checks (360° is subtracted where the sum exceeds 360°, e.g. 145°15′ + 248°15′ − 360° = 33°30′). (p.38)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Jab koi bhi line saaf na mile, to sabse kam galti wali line (yahan AB, sirf 1°30′ off) ko 'saaf maan lo': uski galti ko aadha-aadha FB aur BB mein baant do taaki difference exactly 180° ho jaye. Phir included angles (jo local attraction se affected nahi hote) se aage ki saari bearings nikal lo. Last step mein ghoom ke wapas FB of AB = 192°15′ aana hi chahiye — woh closing check hai." },
      { k: "trap", t: "The 45′ is added to one bearing and subtracted from the other so that the gap opens from 178°30′ to 180°. Adding 45′ to both bearings leaves the difference unchanged at 178°30′ — a common slip." },
    ] },

    /* ---------------------------------------------------------- p.39–40 */
    { n: "", title: "Notes — Equilateral traverse: magnetic and true bearings from a sun observation", hi: "समबाहु ट्रैवर्स — चुम्बकीय और वास्तविक दिशाकोण", blocks: [
      { k: "h", t: "📘 Notes — p.39–40" },
      { k: "p", t: "<b>Q.</b> In an anticlockwise traverse ABC all the sides were equal. The magnetic FB of BC was obtained to be 15°30′. The bearing of the sun was observed to be 184°30′ at local noon. Calculate the MB and TB of all sides of the traverse. (p.39)" },
      { k: "p", t: "<b>Figure (p.39):</b> equilateral triangle traverse — A at top-left, B at bottom, C at right, each with a short north line. At B the bearing of BC from north, 15°30′, and the interior angle 60°. At C the interior angle 60°, with arcs from north for 195°30′ (BB of BC) and 255°30′ (FB of CA). At A the angle 75°30′ from north (BB of CA) and the interior angle 60°. (p.39)" },
      { k: "eg", title: "Notes example — Magnetic bearings of an equilateral traverse",
        given: "Anticlockwise traverse ABC, all sides equal; magnetic FB of BC = 15°30′. Find the magnetic bearings of all sides.",
        steps: [
          { t: "Equilateral", w: "AB = BC = CA, so ∠A = ∠B = ∠C = 60°" },
          { t: "Line BC", w: "FB of BC = 15°30′\nBB of BC = 195°30′" },
          { t: "Line CA", w: "FB of CA = 195°30′ + 60° = 255°30′\nBB of CA = 255°30′ − 180° = 75°30′" },
          { t: "Line AB", w: "FB of AB = 75°30′ + 60° = 135°30′\nBB of AB = 135°30′ + 180° = 315°30′" },
        ],
        ans: "Magnetic bearings — AB: FB 135°30′, BB 315°30′; BC: FB 15°30′, BB 195°30′; CA: FB 255°30′, BB 75°30′. (p.39–40)" },
      { k: "p", t: "<b>Figure (p.40):</b> true north–south line with a horizontal line through it; a red inclined line (magnetic meridian) whose north end is tilted to the <b>left</b> (west) of true north. Angle between true north and magnetic north = 4°30′ = δ. Arc from true north clockwise to south = 180° = TB; arc from magnetic north clockwise to south = 184°30′ = MB (bearing of the sun at local noon). (p.40)" },
      { k: "eq", expr: "TB = MB − δ   →   δ = 184°30′ − 180° = 4°30′", where: [
        ["TB", "true bearing (sun at local noon is due south, TB = 180°)"],
        ["MB", "magnetic bearing of the sun = 184°30′"],
        ["δ", "magnetic declination, 4°30′ (magnetic north west of true north, per the figure)"],
      ] },
      { k: "cmp", t: "Magnetic and true bearings (p.40; true bearings boxed in red in the notes)", cols: ["Magnetic FB / BB", "True FB / BB"], rows: [
        ["AB", "135°30′ / 315°30′", "131° / 311°"],
        ["BC", "15°30′ / 195°30′", "11° / 191°"],
        ["CA", "255°30′ / 75°30′", "251° / 71°"],
      ] },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Local noon par sun exactly true south mein hota hai, to uski true bearing 180° hai. Compass ne 184°30′ padha — matlab compass ki har reading 4°30′ zyada aa rahi hai (magnetic north, true north se 4°30′ west mein hai). Bas har magnetic bearing mein se 4°30′ ghatao: TB = MB − δ. Equilateral triangle mein har angle 60° hai, to FB next = BB previous + 60° se teeno lines nikal jaati hain." },
      { k: "trap", t: "Don't add the declination here. The sun gave MB &gt; TB (184°30′ against 180°), so the magnetic readings are too large and δ is subtracted. Always decide the sign from a sketch like the one on p.40, not from memory." },
      { k: "real", t: "A sun observation at local noon is a quick field way to find the declination at a site without any reference station." },
    ] },

    /* ---------------------------------------------------------- p.40–42 */
    { n: "", title: "Notes — Three-ships problem", hi: "तीन जहाज़ों का प्रश्न", blocks: [
      { k: "h", t: "📘 Notes — p.40–42" },
      { k: "p", t: "<b>Q.</b> 3 ships A, B and C started from Bombay at the same time in 3 directions. The speed of all three ships was the same, i.e. 30 km/h. Their bearings were measured to be N70°E, S70°E and S10°E respectively. After an hour, the captain of B determined the bearings of the other 2 ships with respect to his own ship. Calculate the values of the bearings which might have been determined by the captain of ship B. (p.40)" },
      { k: "list", items: [
        "Figure (p.41): origin O (Bombay) with N–S and E–W lines. OA at 70° from north (N70°E), 30 km, to A at top-right; OB at 70° from south (S70°E), 30 km, to B at lower right; OC at 10° from south (S10°E), 30 km, to C at the bottom. A is joined to B (a nearly vertical line), B to C. Curved arrows inside triangles OAB and OBC show the direction of traversing.",
        "Figure (p.41): triangle OBC redrawn — O top-left, B right, C bottom-left (OC vertical); interior angles 60° at O, B and C; a red arc around the outside of B shows the exterior angle.",
        "Figure (p.42): triangle OAB — O left, A top-right, B bottom-right (AB nearly vertical); OA = 30, OB = 30; at O the angle from north to OA is 70° and from south to OB is 70°; interior angles O = 40°, A = 70°, B = 70°.",
      ] },
      { k: "eg", title: "Notes example — Bearing of ship C as seen from ship B (triangle OBC)",
        given: "OB = OC = 30 km; OB = S70°E, OC = S10°E. Find the bearing of C from B.",
        steps: [
          { t: "Triangle OBC", w: "∠BOC = 70° − 10° = 60° with OB = OC, so ∠O = ∠B = ∠C = 60°" },
          { t: "Line OB", w: "FB of OB = S70°E = 110°\nBB of OB = 110° + 180° = 290°" },
          { t: "Exterior angle at B", w: "As traverse OBC runs clockwise, ∠B would be exterior\n∠B = 360° − 60° = 300°" },
          { t: "FB of BC", w: "∠B = FB of BC − BB of OB\n300° = FB of BC − 290°\nFB of BC = 300° + 290° − 360° = 230°" },
          { t: "Closing at C", w: "∠C = FB of CO − BB of BC\n300° = FB of CO − (230° − 180°)\nFB of CO = 350°\nBB of CO = 350° − 180° = 170°" },
        ],
        ans: "Bearing of ship C from ship B = FB of BC = 230°. (Check: BB of CO = 170° = S10°E, the given direction of C.) (p.41–42)" },
      { k: "eg", title: "Notes example — Bearing of ship A as seen from ship B (triangle OAB)",
        given: "OA = OB = 30 km; OA = N70°E, OB = S70°E. Find the bearing of A from B.",
        steps: [
          { t: "Triangle OAB", w: "∠O = 180° − 70° − 70° = 40°\n∠B = ∠A = (180° − 40°) / 2 = 70°" },
          { t: "Line OA", w: "FB of OA = 70°\nBB of OA = 250°" },
          { t: "Angle at A", w: "As the traverse runs anticlockwise, ∠A will be interior\n∠A = FB of AO − BB of OA\n70° = FB of AO − 180°\nFB of AO = 250°\nBB of AO = 70°" },
          { t: "Angle at B", w: "∠B = FB of BA − BB of OB\n70° = FB of BA − 290°\nFB of BA = 360°\nBB of BA = 180°" },
        ],
        ans: "Bearing of ship A from ship B = FB of BA = 360° (due north); BB of BA = 180°. (p.42)" },
      { k: "note", t: "<b>Check (p.42):</b> the two answers re-work by coordinates (O at origin, 30 km legs): from B, ship A lies due north (360°) and ship C lies at 230°. On the ∠A line the notes first wrote 250° and 320° and struck them out; the line as left, \"70° = FB of AO − 180°\", is not an angle relation — FB of AO is simply BB of OA = 70° + 180° = 250°, so the result 250° is right. It is not needed for the answer: only BB of OB = 290° and ∠B = 70° are used to get FB of BA = 360°." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Trick: Bombay ko O maan lo aur teeno ships ki 1 hour ki position (30 km each) plot karo. Ab O–B–C aur O–A–B do triangles ban gaye jinki sides aur angles pata hain — yeh bas chhote traverse hain. B ke captain ko jo bearing chahiye woh line BC aur BA ki FB hai. Angle rule wahi hai: ∠ = FB next − BB previous; clockwise traverse mein yeh exterior angle (360° − 60° = 300°) deta hai, anticlockwise mein interior." },
      { k: "p", t: "In quadrantal form the notes' answers read: A from B = due N (360°), C from B = S50°W (230°)." },
      { k: "trap", t: "With the rule ∠ = FB of next line − BB of previous line, the angle you get is the clockwise angle from the back line to the forward line. In a clockwise-run triangle that is the <b>exterior</b> angle (300°), not the interior 60°. Using 60° there gives the wrong bearing." },
    ] },

    /* ---------------------------------------------------------- p.239–240 */
    { n: "", title: "Notes — Prismatic compass and surveyor's compass", hi: "प्रिज़्मैटिक कम्पास और सर्वेयर कम्पास", blocks: [
      { k: "h", t: "📘 Notes — p.239–240" },
      { k: "h", t: "Prismatic compass → 0° – 360° (p.239)" },
      { k: "p", t: "Azimuth → WCB (TB). (p.239)" },
      { k: "p", t: "Figure (p.239): circle for the graduated ring of the prismatic compass with four tick marks — top 180° N, right 270° E, bottom 0° S, left 90° W. (p.239)" },
      { k: "list", items: [
        "The prismatic compass is generally <b>smaller</b> in size than the surveyor's compass. (p.239)",
        "A prismatic compass consists of a circular box of about <b>85–100 mm</b> dia. (p.239)",
        "The magnetic needle used in the prismatic compass is <b>broad</b> in shape. (p.239)",
        "An <b>aluminium ring</b> graduated in degrees and half degrees is <b>directly attached to the needle</b>. (p.239)",
        "The graduation increases in the clockwise direction, with the <b>zero</b> of the graduation coinciding with the <b>South</b> end, 90° with West, 180° with North and 270° with East. (p.239)",
        "The prismatic compass is used to measure <b>WCB</b>; as a prism is used to read the readings, the readings are already inverted. (p.239)",
      ] },
      { k: "h", t: "Surveyor's compass (p.240)" },
      { k: "list", items: [
        "It consists of a <b>brass or aluminium</b> circular box of about <b>150 mm</b> diameter. (p.240)",
        "The graduated scale ring is <b>directly fixed to the box</b>, which governs the size of the compass. (p.240)",
        "Graduations are in degrees or half degrees. (p.240)",
        "It is used to measure <b>QB</b> (quadrantal bearing; written \"QB. QCB\" in the notes). (p.240)",
      ] },
      { k: "p", t: "Figure (p.240): circle for the graduated ring of the surveyor's compass with four tick marks — top 0 N, right 90 E, bottom 0 S, left W 90. (p.240)" },
      { k: "cmp", t: "Side by side, from the notes (p.239–240)", cols: ["Prismatic compass", "Surveyor's compass"], rows: [
        ["Size", "Smaller; box about 85–100 mm dia", "Box about 150 mm dia (brass or aluminium)"],
        ["Graduated ring", "Aluminium ring attached to the needle", "Fixed directly to the box"],
        ["Graduation", "Degrees and half degrees; 0° at S, 90° W, 180° N, 270° E, clockwise", "Degrees or half degrees; 0 at N and S, 90 at E and W"],
        ["Needle", "Broad", "—"],
        ["Measures", "WCB (0°–360°), read through a prism", "QB"],
      ] },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Prismatic compass mein ring needle ke saath chipki hai, isliye ring hilti nahi — box ghoomta hai. Reading prism se line of sight ke opposite side par padhi jaati hai, isi liye zero South end par rakha gaya hai: jab aap north ki taraf dekhte ho, prism ke neeche South wala hissa (0°) aata hai. Figures ulte likhe hote hain taaki prism mein seedhe dikhein. Surveyor's compass mein ring box ke saath ghoomti hai aur seedhe upar se padhi jaati hai — QB deta hai. Chapter ka 'The two compasses' table yahi comparison aur detail mein deta hai." },
      { k: "trap", t: "Prismatic compass zero is at the <b>South</b> end of the ring, not North (p.239). Students who draw 0° at N on the prismatic dial mix it up with the surveyor's compass." },
    ] },

    /* ---------------------------------------------------------- revision */
    { n: "", title: "Notes revision — Compass surveying: local attraction, traverses, compasses (p.30–42, p.239–240)", hi: "नोट्स पुनरावृत्ति — कम्पास सर्वेक्षण", blocks: [
      { k: "h", t: "✅ Key points from the notes" },
      { k: "list", items: [
        "✅ Local attraction = attraction of the needle to a local magnetic field other than the earth's; caused by iron near the station (bus, belt buckle, wrist-watch dial, transmission line). (p.30)",
        "✅ Take FB and BB of every line; they should differ by exactly 180°. If not, attraction is suspected at both stations or at either station. (p.30)",
        "✅ Local attraction affects all bearings of a station by the same amount. (p.31)",
        "✅ Two corrections: (1) local attraction at each station, (2) included angles. (p.31)",
        "✅ Method 1: find a line with FB − BB = 180°; its end stations are free; work station by station. Error = M.V − T.V; correction = −error. (p.31–32)",
        "✅ p.32 answer: AB 138°/318°, BC 60°/240°, CD 125°/305°, DE 153°/333°; correction at A −2°, at D +3°. (p.32)",
        "✅ Method 2 (best for closed traverse): included angle = FB of next line − BB of previous line; check sum = (2n ± 4) × 90° and distribute any error equally. (p.33)",
        "✅ Five-line traverse ABCDEA: angles 109°45′, 107°45′, 145°30′, 91°30′, 85°30′ = 540°; corrected FB AB 150°, BC 77°45′, CD 43°15′, DE 314°45′, EA 220°15′. (p.35–36)",
        "✅ No clean line: take the line with least deviation from 180°, split the shortfall equally between FB and BB (AB: 178°30′ → ±45′ → 192°15′ / 12°15′). (p.37)",
        "✅ p.38 answer: FB of BC 68°15′, CD 33°30′, DE 265°15′, EA 234°15′, closing on AB 192°15′. (p.38)",
        "✅ Equilateral traverse: all angles 60°; magnetic AB 135°30′/315°30′, BC 15°30′/195°30′, CA 255°30′/75°30′. (p.39–40)",
        "✅ Sun at local noon: TB = 180°; MB = 184°30′ → δ = 4°30′; TB = MB − δ → AB 131°/311°, BC 11°/191°, CA 251°/71°. (p.40)",
        "✅ Three ships (30 km/h, 1 h): from B, ship C at 230°, ship A at 360°; clockwise OBC uses exterior ∠B = 300°. (p.40–42)",
        "✅ Prismatic compass: 85–100 mm box, broad needle, aluminium ring attached to needle, degrees and half degrees, 0° at S, 90° W, 180° N, 270° E, measures WCB through a prism. (p.239)",
        "✅ Surveyor's compass: brass or aluminium box about 150 mm, ring fixed to the box, degrees or half degrees, measures QB. (p.240)",
      ] },
    ] },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
