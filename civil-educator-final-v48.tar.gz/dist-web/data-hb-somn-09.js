/* MACE Academy SOM notes — Basics (motion, DOF, equilibrium, supports, beams, support reactions, load shifting, internal hinges), M p.4–13, and centroid, C.G., moment of inertia, theorems, radius of gyration, mass MOI and principal axes, M p.110–117 — inserted into som chapter 3 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 3; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------- A. motion, DOF, equilibrium */
    {
      n: "",
      title: "MACE notes — Motion, degrees of freedom and equilibrium conditions",
      hi: "गति, स्वातंत्र्य कोटि और साम्यावस्था की शर्तें",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.4" },
        { k: "p", t: "<b>Basics — Motion (displacement)</b> is of two kinds (M p.4):<br>→ <b>Rotational</b> — caused by an unbalanced <b>moment</b><br>→ <b>Translational</b> — caused by an unbalanced <b>force</b>" },
        { k: "p", t: "<b>Figure (M p.4):</b> left sketch labelled <i>couple</i> — a vertical line with a horizontal arrow at its top pointing right and a horizontal arrow at its bottom pointing left (two equal, opposite, parallel forces). Right sketch labelled <i>moment</i> — a clockwise curved arrow." },
        { k: "list", items: [
          "<b>NOTE (M p.4):</b> No unbalanced force → No translation.",
          "No unbalanced moment → No rotation.",
          "A body can undergo various types of motion based upon direction.",
          "The number of directions in which the body can show displacement is called the <b>degree of freedom (DOF)</b>.",
        ] },
        { k: "h", t: "Space (3D) — M p.4" },
        { k: "p", t: "<b>Figure (M p.4):</b> 3D axes x, y, z with a small cube at the origin. Along y (up): arrow 'Δy (Fy or ΣFy)' and rotation arrow 'θy (My or ΣMy)'. Along x (right): 'Δx (Fx or ΣFx)' and 'θx (Mx or ΣMx)'. Along z (towards the viewer): 'Δz (Fz or ΣFz)' and 'θz (Mz or ΣMz)'. Rotations written in red." },
        { k: "list", items: [
          "Translational (3) = Δx, Δy and Δz",
          "Rotational (3) = θx, θy and θz",
          "Total possible displacement (6) = Δx, Δy, Δz, θx, θy, θz ← total free displacement components. (M p.4)",
        ] },
        { k: "cmp", t: "★ Equilibrium conditions in 3D (M p.4)", cols: ["Conditions"], rows: [
          ["1) Translational (force) equilibrium", "ΣFx = 0, ΣFy = 0, ΣFz = 0"],
          ["2) Moment / rotational equilibrium", "ΣMx = 0, ΣMy = 0, ΣMz = 0"],
          ["Total", "<b>6 equilibrium conditions</b>"],
        ] },
        { k: "h", t: "Planar (2D) — M p.4" },
        { k: "p", t: "<b>Figure (M p.4):</b> 2D axes x (right) and y (up) with a small square at the origin; up arrow 'Δy (Fy or ΣFy)', right arrow 'Δx (Fx or ΣFx)', and a curved rotation arrow round the square 'θxy (M)'." },
        { k: "p", t: "Total possible displacement (3) = Δx, Δy and θxy. (M p.4)" },
        { k: "cmp", t: "★ Equilibrium conditions in 2D (M p.4)", cols: ["Conditions"], rows: [
          ["1) Translational equilibrium (Δx, Δy)", "ΣFx = 0, ΣFy = 0"],
          ["2) Rotational equilibrium (θxy)", "ΣM = 0"],
          ["Total", "<b>3 equilibrium conditions</b>"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har free displacement ke against ek equilibrium equation hoti hai. Space mein body 3 direction mein khisak sakti hai aur 3 axes ke around ghoom sakti hai — isliye 6 equations. Plane (2D beam/frame) mein sirf x, y mein khisakna aur us plane mein ghoomna bachta hai — isliye 3 equations: ΣFx = 0, ΣFy = 0, ΣM = 0. Inhi 3 se simply supported beam ya cantilever ke reactions nikalte hain (§ reactions, aage)." },
        { k: "p", t: "Couple aur moment ka farq bhi yahin se samjho: couple do barabar, ulti, parallel forces hain — inka net force zero hai, isliye couple sirf <b>rotation</b> karata hai, translation nahi." },
        { k: "trap", t: "2D problem mein 6 equations lagane ki koshish mat karo — beam ke plane mein sirf 3 independent equilibrium equations hain. Agar unknown reactions 3 se zyada hain, to beam statically indeterminate hai (M p.12)." },
      ],
    },

    /* ---------------------------------------------- B. supports, joints, beam types */
    {
      n: "",
      title: "MACE notes — Restraints, supports, joints and types of beams",
      hi: "प्रतिबंध, आधार, जोड़ और धरनों के प्रकार",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.5–7" },
        { k: "p", t: "<b>★ Requirement of a structure (M p.5):</b> is to provide, at rest → <b>stability and strength</b>.<br>← equilibrium satisfy झाला पाहिजे — <i>(Marathi) equilibrium must be satisfied</i><br>← by ensuring proper support (provision of restraint)." },
        { k: "def", term: "Restraint", t: "To avoid or to restrict displacement by means of a support. (M p.5)" },
        { k: "def", term: "Degree of freedom (DOF)", t: "Total number of free displacements − displacements restricted by supports [number of support reactions (R)]. (M p.5)" },
        { k: "cmp", t: "Total DOF and the DOF formula (M p.5)", cols: ["3D", "2D"], rows: [
          ["Total DOF (total free components)", "6", "3"],
          ["DOF after supports", "<b>DOF = 6 − R</b>", "<b>DOF = 3 − R</b>"],
        ] },
        { k: "p", t: "<b>Example — 2D (M p.5), Figure:</b> a member pushed horizontally against a wall (hatched, labelled 'Restriction'); red arrows show a vertical arrow at the wall and a curved rotation arrow — only the movement into the wall is stopped. Total free displacement = 3; restricted = 1; <b>DOF = 2</b>." },
        { k: "cmp", t: "Support types (M p.5)", cols: ["Behaviour", "No. of restraints (reactions) R", "DOF = 3 − R (2D)"], rows: [
          ["1) Hinge / pinned support — figure: pin at A on hatched ground, H_A → and V_A ↑", "Rotation allowed", "2", "1 (R)"],
          ["2) Roller support — figure: support at A on rollers, V_A ↑", "Rotation allowed; translation in one direction allowed", "1", "2 (R, T)"],
          ["3) Fixed support — figure: beam built into a block, load P ↓ at the free end; horizontal reaction, vertical reactions (red, up/down) and a curved moment arrow at the support", "No rotation or translation allowed", "3", "0"],
          ["4) Slider; guided rollers — figure: a vertical member on rollers sitting in a curved hatched base (slider), and a roller held between upper and lower hatched guides with the member attached horizontally (guided rollers)", "Rotation allowed — e.g. sliding window, channel gate", "2", "1"],
        ] },
        { k: "note", t: "<b>Check (slider / guided roller row):</b> with R = 2 and DOF = 1 only one movement can stay free. <i>General Engineering Knowledge:</i> a guided roller (slider) is normally taken to allow <b>translation along the guide</b> and to resist the force across the guide <b>and the rotation</b> (2 reactions: one force + one moment). If rotation were the free movement, both translations would be held — that is a hinge. Read the notes' 'rotation allowed' together with the counts: R = 2, DOF = 1." },
        { k: "def", term: "Rigid joint", t: "After application of loads the shape of the joint remains the same as it was before. If at the time of construction the angle between two members was 90° and after loading the angle of 90° remains the same, then the joint is a rigid joint. (M p.6)" },
        { k: "def", term: "Pin joint", t: "The joint which cannot maintain its initial shape, or say the angle, is called a pin joint. (M p.6)" },
        { k: "cmp", t: "★ Types of beams (M p.6)", cols: ["Reaction", "DOF (as written)"], rows: [
          ["1) Simply supported beam", "3", "3"],
          ["2) Cantilever beam", "3", "3"],
          ["3) Propped cantilever beam", "4", "2"],
          ["4) Continuous beam", "—", "—"],
          ["5) Overhang beam", "", ""],
        ] },
        { k: "note", t: "<b>Check (DOF column):</b> by the notes' own formula DOF = 3 − R (M p.5): simply supported 3 − 3 = <b>0</b>; cantilever 3 − 3 = <b>0</b>; propped cantilever 3 − 4 = <b>−1</b>, i.e. one reaction more than the 3 equilibrium equations — degree of static indeterminacy Ds = 1, exactly as M p.12 states. The '3' in the first two rows matches the number of equilibrium equations available, not the DOF left after supports." },
        { k: "list", items: [
          "<b>Figure 1 (M p.6) — Simply supported beam:</b> span L; left end hinge (horizontal reaction → and vertical ↑), right end roller (vertical ↑).",
          "<b>Figure 2 — Cantilever beam:</b> fixed into a wall at the left (curved moment arrow, horizontal arrow and vertical ↑ reaction), free at the right; span L.",
          "<b>Figure 3 — Propped cantilever beam:</b> fixed at the left wall (moment, horizontal and vertical ↑), propped at the right end with a vertical reaction ↑; span L.",
          "<b>Figure 4 — Continuous beam:</b> fixed at the left wall (moment, vertical ↑) with four more upward reactions ↑ along the beam at intermediate points and the right end.",
          "<b>Figure 5 — Overhang beam:</b> hinge (→ and ↑) at the left and a roller (↑) set inward from the right end, the beam continuing beyond the roller as an overhang.",
          "<b>Example figure (M p.6):</b> overhanging beam on two supports with a point load ↓ at the overhanging right end; the deflected shape (blue) bends down beyond the right support while the left part lifts up (red dashed line shows the upward tilt at the left end); the reaction at the left support is shown acting <b>downward</b>, labelled '(↓) R_A'.",
        ] },
        { k: "def", term: "Support", t: "Structural element which <b>reduces the degree of freedom</b> of the point where it is provided. (M p.7)" },
        { k: "p", t: "↓ Support (support reaction) [redundants] ∝ stability [equilibrium] ∝ 1/(DOF ↑). (M p.7)" },
        { k: "list", items: [
          "<b>Ex ① Beam without support</b> (figure: a free rectangular beam) — DOF: 3 + 3 = <b>6 (unstable)</b>. (M p.7)",
          "<b>Ex ② Beam with support</b> (figure: beam fixed into a wall at its left end — cantilever) — DOF: 0 + 3 = <b>3 (stable than without support)</b>. (M p.7)",
        ] },
        { k: "note", t: "Reading M p.7: the counts '3 + 3' and '0 + 3' add the DOF of the beam's <b>two end points</b>, 3 each in 2D — the support 'reduces the DOF of the point where it is provided'. Fixing the left end takes that point's 3 to 0; the free end keeps its 3. For the beam as one rigid body, the count is DOF = 3 − R (M p.5): free beam 3, cantilever 0." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har support kuch movements rokta hai, aur jo movement rokta hai, us direction mein <b>reaction</b> deta hai. Roller sirf neeche dabne se rokta hai (1 reaction), hinge dono direction mein khisakne se rokta hai par ghoomne deta hai (2 reactions), fixed support kuch bhi nahi hone deta (3 reactions: H, V, M). Isliye reactions ki ginti = rokhi gayi displacements ki ginti." },
        { k: "p", t: "Overhang wale example ka lesson: overhang ke end par load lagao to beam support B ke upar see-saw ki tarah ghoomti hai — left end upar uthna chahta hai, isliye A par reaction <b>neeche</b> ki taraf (hold-down) lagta hai. Reaction hamesha upar hi ho, yeh zaroori nahi." },
        { k: "trap", t: "Beam types table ke DOF column ko DOF = 3 − R se mat milao bina soche — simply supported aur cantilever dono ka DOF (after supports) zero hai, isliye woh stable aur determinate hain. Propped cantilever mein R = 4 &gt; 3, isliye woh indeterminate hai (Ds = 1)." },
        { k: "real", t: "Sliding window aur channel gate guided-roller support ke examples hain (M p.5). Bridge bearings mein ek end hinge aur doosra roller rakhte hain taaki temperature se expand hone par girder free khisak sake." },
      ],
    },

    /* ---------------------------------------------- C. support reactions, shortcut */
    {
      n: "",
      title: "MACE notes — Calculation of support reactions and the shortcut (span-ratio) method",
      hi: "आधार प्रतिक्रियाओं की गणना और शॉर्टकट विधि",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.8–9" },
        { k: "p", t: "<b>Figure (M p.8) — Beam:</b> 3D sketch of a beam block with several downward loads ↓↓↓↓ on top, an inclined force at one end and upward reactions; beside it a line beam with a horizontal arrow → at the left end, upward reactions ↑ at both ends and a downward load ↓ in the middle." },
        { k: "p", t: "Loads on a beam ↓ → <b>non-parallel, non-concurrent</b> } <b>general force system</b>. (M p.8)<br>⇒ 2D ⇒ 3 equilibrium conditions: ΣFx = 0, ΣFy = 0, ΣM = 0. Sign convention sketch: ↑ +, ↓ −, → +, ← −. (M p.8)" },
        { k: "eg", title: "MACE notes example — 1) SS beam with a point load at L/3", given: "Simply supported beam AB: hinge at A (H_A, V_A), roller at B (V_B); point load P at L/3 from A (2L/3 from B). Find the reactions.", steps: [
          { t: "(i) ΣFx = 0", w: "+H_A = 0 ...(1)\nSo, in absence of horizontal load, H_A = 0" },
          { t: "(ii) ΣFy = 0", w: "V_A + V_B − P = 0\nV_A + V_B = P ...(2)" },
          { t: "(iii) ΣM_support = 0, ΣM_A = 0", w: "+P × (L/3) − V_B × L = 0\nV_B = P/3" },
          { t: "Put in (2)", w: "V_A = P − P/3\n(side working: 1 − 1/3 = (3 − 1)/3 = 2/3)\nV_A = 2P/3" },
        ], ans: "H_A = 0; V_A = 2P/3; V_B = P/3 (M p.8)" },
        { k: "h", t: "Shortcut method / trick (M p.8)" },
        { k: "steps", items: [
          "Step ⓪: ΣM = 0 ··· always.",
          "Step I: Find the total load.",
          "Step II: Find the span distribution due to the load.",
          "Step III: Find the load distribution as per the span distribution.",
          "Step IV: Write down the support reactions.",
        ] },
        { k: "p", t: "<b>NOTE (M p.8):</b> load is distributed in the same proportion as the load distributes the span.<br>Total load P → (1/3) — P/3 = V_B ; → (2/3) — 2P/3 = V_A." },
        { k: "eq", expr: "Symmetric beam:  R_A / R_B = 1", where: [["symmetric", "loads placed symmetrically about mid-span — each support takes half the total load (M p.8)"]] },
        { k: "eg", title: "MACE notes example — 2) SS beam with UDL over the whole span", given: "Simply supported beam AB, span L, hinge at A, roller at B, UDL w N/m over the whole span. Find the reactions.", steps: [
          { t: "Symmetric beam, so R_A = R_B = half the total load wL", w: "V_A = wL/2\nV_B = wL/2" },
        ], ans: "V_A = V_B = wL/2 (M p.8)" },
        { k: "eg", title: "MACE notes example — 3) SS beam with two end UDLs (symmetric)", given: "Simply supported beam AB: UDL w₁ N/m over length L₁ from A, unloaded middle length L₃, UDL w₂ N/m over length L₂ up to B; a dashed centre line is drawn through the middle of the span. Find the reactions.", steps: [
          { t: "Symmetric beam, so each support takes half the total load", w: "R_A = (w₁L₁ + w₂L₂)/2\nR_B = (w₁L₁ + w₂L₂)/2" },
        ], ans: "R_A = R_B = (w₁L₁ + w₂L₂)/2 (M p.8)" },
        { k: "note", t: "<b>Check:</b> R_A = R_B = (w₁L₁ + w₂L₂)/2 holds only when the loading really is symmetric about the centre line, i.e. <b>w₁ = w₂ and L₁ = L₂</b>. For unequal end loads take moments: R_B·L = w₁L₁(L₁/2) + w₂L₂(L − L₂/2), and R_A = w₁L₁ + w₂L₂ − R_B." },
        { k: "h", t: "Unsymmetric beams (M p.9)" },
        { k: "eg", title: "MACE notes example — 4) UDL over the left half of an SS beam", given: "Simply supported beam AB, span L = L/2 + L/2, UDL w N/m over the left half (from A to mid-span). Equivalent beam: resultant wL/2 at L/4 from A and 3L/4 from B. Find R_A and R_B.", steps: [
          { t: "Total load", w: "wL/2" },
          { t: "Split by span ratio (as written)", w: "1/4 → (1/4)(wL/2) = wL/8\n3/4 → (3/4)(wL/2) = 3wL/8" },
          { t: "Reactions (as written)", w: "R_A = wL/8\nR_B = 3wL/8" },
        ], ans: "R_A = wL/8, R_B = 3wL/8 (M p.9, as written — see Check)" },
        { k: "note", t: "<b>Check:</b> the reactions are swapped. The resultant wL/2 sits L/4 from A, i.e. <b>nearer A</b>, so A carries the larger share. ΣM_A = 0: R_B·L = (wL/2)(L/4) ⇒ <b>R_B = wL/8</b>, and <b>R_A = wL/2 − wL/8 = 3wL/8</b>. The notes' own rule from example 1 gives the same: the support takes the fraction of the span on the <b>far</b> side of the load (V_A = 2P/3 when the load is L/3 from A)." },
        { k: "eg", title: "MACE notes example — 5) UDL over the middle 2 m of a 6 m SS beam", given: "Simply supported beam, hinge at left (V_A), roller at right (V_B); span divided 1 m — 2 m — 3 m; UDL 2 kN/m over the middle 2 m segment. Equivalent beam: 4 kN at 2 m from A and 4 m from B. Find V_A and V_B.", steps: [
          { t: "Total load", w: "2 × 2 = 4 kN" },
          { t: "Split by span ratio", w: "2/6 = 1/3 → (1/3) × 4 = 4/3\n4/6 = 2/3 → (2/3) × 4 = 8/3" },
          { t: "Reactions", w: "V_A = 8/3 = 2.67 kN\nV_B = 4/3 = 1.33 kN" },
        ], ans: "V_A = 2.67 kN, V_B = 1.33 kN (M p.9)" },
        { k: "eg", title: "MACE notes example — 6) Triangular (UVL) load on an SS beam", given: "Simply supported beam, hinge at left (V_A), roller at right (V_B), span L; load varying uniformly from zero at A to w kN/m at B; resultant line at 2L/3 from A and L/3 from B. Find V_A and V_B.", steps: [
          { t: "Total load", w: "wL/2" },
          { t: "Split by span ratio", w: "(1/3) × (wL/2) = wL/6\n(2/3) × (wL/2) = wL/3" },
        ], ans: "V_A = wL/6, V_B = wL/3 (M p.9)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Shortcut ka asli logic lever (taraazu) hai: load jis support ke <b>paas</b> hai, woh support zyada load leta hai. Load span ko do hisson mein baant-ta hai — har support ko <b>doosre (door wale) hisse</b> ka fraction milta hai. Load L/3 par A ke paas: A ko 2/3, B ko 1/3. Yeh sirf ΣM = 0 ka short form hai, isliye step ⓪ 'ΣM = 0 always'." },
        { k: "p", t: "UDL ya UVL ko pehle ek resultant point load mein badlo (UDL: wL beech mein; UVL: wL/2 centroid par, yaani bade end se L/3) — phir wahi span-ratio trick lagao." },
        { k: "trap", t: "Fraction ulta lagana sabse common galti hai — example 4 mein notes mein bhi yahi hua hai. Hamesha sanity check karo: load jis support ke paas, us support ka reaction <b>bada</b>. UDL left half par hai to R_A &gt; R_B (3wL/8 vs wL/8)." },
        { k: "real", t: "Site par slab ya wall ka load beam par aksar ek hisse mein hota hai (jaise sirf ek side balcony). Column/footing design ke liye har support ka reaction isi tareeke se nikalte hain — galat fraction se ek column under-designed ho jaata hai." },
      ],
    },

    /* ---------------------------------------------- D. applied moments, load shifting */
    {
      n: "",
      title: "MACE notes — Reactions due to applied moments, and the load-shifting technique",
      hi: "लगाए गए आघूर्ण से प्रतिक्रियाएँ और भार-स्थानांतरण तकनीक",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.9–10" },
        { k: "eg", title: "MACE notes example — 7) Couple M at mid-span of an SS beam", given: "Simply supported beam AB, hinge at A, roller at B, span L/2 + L/2; a concentrated moment (couple) M applied at mid-span. Horizontal reaction at A marked zero. Find V_A and V_B.", steps: [
          { t: "ΣM_A = 0", w: "−V_B × L + M = 0\nV_B = M/L" },
          { t: "ΣFy = 0", w: "V_A + V_B = 0\nV_A = −V_B\nV_A = −M/L" },
        ], ans: "V_B = M/L (↑); V_A = −M/L (↓) (M p.9)" },
        { k: "list", items: [
          "<b>Conclusion (M p.9):</b> Reaction = (Net moment)/(Span).",
          "V_A = −V_B means the magnitude of the reactions is the same but the direction is opposite.",
          "★ V_A/V_B = −1, i.e. &lt; 0, i.e. negative.",
          "Couple formed due to reactions = V_B·L or V_A·L = (M/L)·L = <b>M</b>.",
        ] },
        { k: "eg", title: "MACE notes example — 8) MCQ: 20 kN·m couple on a 4 m SS beam", given: "Simply supported beam AB (hinge A, roller B), span 4 m; concentrated moment M = 20 kN·m (clockwise) applied at 3 m from A and 1 m from B. Options for (V_A, V_B): a) 5 (↓), 5 (↓); b) 5 (↑), 5 (↑); c) 5 (↓), 5 (↑); d) 5 (↑), 5 (↓).", steps: [
          { t: "Horizontal", w: "H_A = 0" },
          { t: "Reaction = moment / span", w: "V_A = 20/4 = 5 kN (↓)\nV_B = 5 kN (↑)" },
        ], ans: "Option (c): V_A = 5 kN (↓), V_B = 5 kN (↑) — the position of the couple does not matter (M p.10)" },
        { k: "eg", title: "MACE notes example — 9) Point load and couple at mid-span", given: "Simply supported beam AB, hinge A, roller B, span 1 m + 1 m; at mid-span a point load 10 kN ↓ and a moment 5 kN·m (clockwise). Find the reactions.", steps: [
          { t: "For 10 kN (symmetric)", w: "A: +5 kN ↑ ; B: +5 kN ↑" },
          { t: "For 5 kN·m: M/L = 5/2", w: "A: −2.5 kN ↓ ; B: +2.5 kN ↑" },
          { t: "Total", w: "A: +2.5 kN ; B: +7.5 kN" },
        ], ans: "V_A = 2.5 kN ↑, V_B = 7.5 kN ↑ (M p.10)" },
        { k: "eg", title: "MACE notes example — 10) Point load and a larger couple at mid-span", given: "Simply supported beam AB, hinge A, roller B, span 1 m + 1 m; at mid-span a point load 10 kN ↓ and a moment 20 kN·m (clockwise). Find the reactions.", steps: [
          { t: "For 10 kN", w: "A: ↑ +5 kN ; B: ↑ +5 kN" },
          { t: "For 20 kN·m: M/L = 20/2", w: "A: ↓ −10 kN ; B: ↑ +10 kN" },
          { t: "Total", w: "V_A = −5 kN ; V_B = +15 kN" },
        ], ans: "V_A = −5 kN (i.e. 5 kN ↓), V_B = +15 kN ↑ (M p.10)" },
        { k: "h", t: "★ Load shifting technique (M p.10)" },
        { k: "p", t: "<b>① Figure (M p.10):</b> member AB of length L with load P ↓ at end B. The effect of 'P' at A is analysed by <b>shifting load 'P' to point 'A'</b> — second sketch: the same member with P ↓ now at A together with a moment <b>P·L</b> (curved arrow) at A." },
        { k: "list", items: [
          "Effect of P at B = <b>Translation</b>.",
          "Effect of P at A = <b>Rotation + Translation</b>.",
          "To check the effect of any load at any location other than its point of application, we need to shift that load to that particular location from any other location. (M p.10)",
        ] },
        { k: "eg", title: "MACE notes example — Load shifting ② load on a bracket", given: "Simply supported beam AB (hinge A with horizontal reaction zero, roller B), total span 4 m (2 m + 1 m + 1 m). At 2 m from A a vertical bracket rises 1 m and then runs horizontally 1 m to the right; a load 2 kN ↓ acts at the end of the bracket (above the point 3 m from A). Find the reactions.", steps: [
          { t: "Shift the load to the beam at 2 m from A", w: "2 kN ↓ plus a moment 2 kN × 1 m = 2 kN·m\nEquivalent beam: span 2 m + 2 m; at mid-span 2 kN ↓ and 2 kN·m" },
          { t: "For 2 kN", w: "A: ↑ +1 kN ; B: ↑ +1 kN" },
          { t: "M/L = 2/4", w: "A: ↓ −0.5 kN ; B: ↑ +0.5 kN" },
          { t: "Total", w: "A: ↑ +0.5 kN ; B: ↑ +1.5 kN" },
        ], ans: "V_A = 0.5 kN ↑, V_B = 1.5 kN ↑ (M p.10)" },
        { k: "eg", title: "MACE notes example — Load shifting ③ post with horizontal and vertical loads", given: "Simply supported beam AB (hinge A, roller B), span 2 m + 2 m. At mid-span a vertical post 1 m high; at its top a horizontal load 2 kN → and, at the end of a short horizontal arm to the right of the post top, a vertical load 2 kN ↓. Find the reactions.", steps: [
          { t: "Shift both loads to the beam at mid-span", w: "2 kN ↓, 2 kN → (along the beam), and moments 2 kN·m and 2 kN·m\n(side note: H₂ ↓ V₂ ; M = 2 + 2)\nEquivalent beam: at mid-span 2 kN →, 2 kN ↓ and 4 kN·m; at A horizontal reaction H_A = 2 kN ←" },
          { t: "For 2 kN ↓", w: "A: 1 kN ↑ ; B: +1 kN ↑" },
          { t: "For 4 kN·m: M/L = 4/4", w: "A: ↓ −1 kN ; B: ↑ +1 kN" },
          { t: "Total", w: "V_A = 0 ; V_B = 2 kN\nH_A = 2 kN (←)" },
        ], ans: "V_A = 0, V_B = 2 kN ↑, H_A = 2 kN ← (M p.10)" },
        { k: "note", t: "Reading the figure of ③ (M p.10): the arm carrying the vertical 2 kN is not dimensioned; the notes' moment of 2 kN·m from that load implies an arm of <b>1 m</b>. The horizontal 2 kN acting 1 m above the beam gives the other 2 kN·m. Both act clockwise, so M = 2 + 2 = 4 kN·m, and ΣM_A = 0 gives V_B × 4 = 2 × 2 + 4 ⇒ V_B = 2 kN, V_A = 0 ✔." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Beam par lagi couple M ka net force zero hai, isliye dono reactions mil kar sirf ek ulti couple banate hain: barabar magnitude M/L, ulti direction. Isi wajah se couple beam par <b>kahin bhi</b> lagao, reactions same (example 8 mein 3 m par lagi, phir bhi 20/4 = 5 kN)." },
        { k: "p", t: "Load shifting ka matlab: force ko kisi doosre point par le jao to wahan wahi force <b>plus</b> ek moment (force × perpendicular distance) lagana padta hai. Bracket ya post par laga load beam par 'force + couple' ban jaata hai — phir superposition: point load ka hissa span ratio se, couple ka hissa M/L se, aur dono jod do." },
        { k: "trap", t: "Couple ke reactions ki direction dhyan se lo — ek support ka reaction <b>neeche</b> (negative) aata hai. Example 10 mein V_A = −5 kN: A par beam ko neeche pakadna padega. Aur load shift karte waqt moment bhoolna (sirf force shift karna) sabse aam galti hai." },
        { k: "real", t: "Column brackets (corbels), signboard posts, crane rails ke brackets — inka load beam/column par force + moment ban kar aata hai. Eccentric connection ka design isi 'load shifting' se shuru hota hai." },
      ],
    },

    /* ---------------------------------------------- E. internal hinges */
    {
      n: "",
      title: "MACE notes — Internal hinges and beams broken at the hinge",
      hi: "आंतरिक कब्ज़ा (इंटरनल हिंज) और हिंज पर बँटी धरनें",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.11–13" },
        { k: "p", t: "<b>Figure (M p.11):</b> beam ABC fixed at A (wall at left), with an internal hinge (pin in a small box) at B and extending to the free end C; label 'internal hinge / moment release' points to B; a dashed outline below B with a curved arrow shows that portion BC can rotate freely about B. Beside it: 3D sketch of two plates joined by a pin (bolt) — a hinge connection. AB and BC are rotationally independent." },
        { k: "list", items: [
          "If there is an internal hinge, the beam is differentiated into two portions, one on either side of the internal hinge. (M p.11)",
          "One portion and the other are <b>rotationally independent</b> due to the internal pin. Thus, in the above beam, portion AB and portion BC are rotationally independent, i.e. no moment or rotational effect can be transferred across point B. Thus the algebraic sum of all the moments on either side of the hinge (on any one side) becomes <b>zero at the internal hinge</b>. Thus an internal hinge serves as a <b>moment release</b>. (M p.11)",
          "An internal hinge <b>decreases the rigidity / stiffness</b> of the beam. (M p.11)",
          "Ex: tractor trolley connected to the engine by a hinge. (M p.11)",
        ] },
        { k: "list", items: [
          "<b>Figure, left (M p.11):</b> cantilever fixed at the left wall with a point load ↓ at the free end; dashed red and blue deflected shapes; vertical deflection at the tip marked 'Δ = deflection' and the tip angle marked 'Rotation or (slope = θ)'. Labelled <b>'Less flexible, more stiff'</b>.",
          "<b>Figure, right (M p.11):</b> the same cantilever with an internal hinge in its span and a point load ↓ at the free end; deformed, the part beyond the hinge drops and rotates sharply about the hinge, labelled 'internal hinge (discontinuity)'. Labelled <b>'more flexible, less stiff'</b>.",
        ] },
        { k: "p", t: "<b>NOTE (M p.11):</b> since, due to the internal hinge, the beam can be differentiated into two portions which are rotationally independent, we can simply analyse the two portions of the beam independently by simply <b>breaking the structure at the hinge point</b>." },
        { k: "eg", title: "MACE notes example — 1) Propped cantilever, then with an internal hinge", given: "Propped cantilever AB: fixed at A, propped at B; point load P at 3L/4 from A (L/4 from B). Then the same beam with an internal hinge H at L/2 from A: dimensions L/2 (A–H), L/4 (H to load), L/4 (load to B). Find the reactions.", steps: [
          { t: "Without hinge", w: "Total reactions (unknowns) = 4\nEquilibrium conditions = 3\nDegree of indeterminacy Ds = 1" },
          { t: "Break the structure at the hinge — free body H–B (span L/4 + L/4, P at middle)", w: "ΣM_H = 0\n+P·(L/4) − R_B·(L/2) = 0\nR_B = P/2 ; reaction at H = P/2 ↑" },
          { t: "Free body A–H: cantilever of length L/2 carrying P/2 ↓ at H", w: "H_A = 0\nR_A = P/2\nFixing moment at A = PL/4 (curved arrow on the figure)" },
        ], ans: "R_B = P/2, R_A = P/2, H_A = 0, M_A = PL/4 (M p.12)" },
        { k: "eg", title: "MACE notes example — 2) Fixed A, hinge H, roller B, UDL on H–B", given: "Beam fixed at A, internal hinge H at 2 m from A, roller support B 2 m beyond H; UDL 20 kN/m on H–B. Find the reactions.", steps: [
          { t: "Free body H–B: resultant 40 kN ↓ at the middle", w: "Reaction at H = 20 kN ↑ ; R_B = 20 kN" },
          { t: "Free body A–H: cantilever of 2 m with 20 kN ↓ at H", w: "Horizontal reaction at A = 0\nR_A = 20 kN\n(margin note: M × L = 20 × 2 = 40 kN·m)\nΣM_A = 0: −M + 20 × 2 = 0\nM = 40 kN·m" },
        ], ans: "R_B = 20 kN, R_A = 20 kN, M_A = 40 kN·m (M p.12)" },
        { k: "eg", title: "MACE notes example — 3) Load between the fixed end and the hinge", given: "Beam fixed at A, point load 20 kN ↓ at 1 m from A, internal hinge H at 2 m from A, roller support B 2 m beyond H. Find the reactions.", steps: [
          { t: "Free body H–B (span 2 m, no load)", w: "Reactions at H and B are both zero" },
          { t: "Free body A–H: cantilever with 20 kN at 1 m, zero force at H", w: "Horizontal reaction at A = 0\nM_A = 20 × 1 = 20 kN·m\nV_A = 20 kN ↑" },
        ], ans: "R_B = 0, M_A = 20 kN·m, V_A = 20 kN ↑ (M p.12)" },
        { k: "eg", title: "MACE notes example — 4) UDL between the fixed end and the hinge", given: "Beam fixed at A, UDL 2 kN/m over the 2 m from A to the internal hinge H; beyond H an unloaded portion to support B (reaction at B drawn as zero). Find the reactions.", steps: [
          { t: "Portion H–B is unloaded", w: "Reaction at B = 0, force at H = 0" },
          { t: "Free body A–H: resultant 4 kN ↓ at 1 m", w: "Horizontal reaction at A = 0\nM_A = 4 × 1 = 4 kN·m\nR_A = 4 kN" },
        ], ans: "M_A = 4 kN·m, R_A = 4 kN, R_B = 0 (M p.12)" },
        { k: "eg", title: "MACE notes example — 5) Point load before the hinge, couple after it", given: "Beam fixed at A; 20 kN ↓ at 1 m from A; internal hinge H at 2 m from A; moment 20 kN·m at 3 m from A; roller support B at 4 m from A (1 m + 1 m + 1 m + 1 m). The figure shows the deflected shape in red: a sagging curve A–H and a dash-dot curve H–B.", steps: [
          { t: "Free body H–B: span 2 m, couple 20 kN·m at its middle", w: "R_B = M/L = 20/2 = 10 kN\nReaction at H on H–B drawn 10 kN ↓, so 10 kN ↑ acts on A–H at H" },
          { t: "Free body A–H: 20 kN ↓ at 1 m, 10 kN ↑ at H (2 m)", w: "Horizontal reaction at A = 0\nM_A = 20 × 1 − 10 × 2 = 20 − 20\nM_A = 0" },
          { t: "Vertical reaction", w: "V_A = 20 − 10 = 10 kN\nΣFy = 0: +V_A − 20 + 10 = 0\nV_A = 10 kN ↑" },
        ], ans: "R_B = 10 kN, M_A = 0, V_A = 10 kN ↑ (M p.12)" },
        { k: "eg", title: "MACE notes example — 5 (second) Beam resting on another beam", given: "Lower beam AB: hinge at A, roller at B, span 3 m (2 m + 1 m). Upper beam H–C: end H rests on the lower beam at 2 m from A (drawn as a roller), end C on a hinge support 2 m beyond B (H to C = 1 m + 2 m = 3 m). UDL 2 kN/m over H–C. Find the reactions.", steps: [
          { t: "Free body H–C: resultant 6 kN ↓ at the middle", w: "Reaction at H = 3 kN ↑ ; R_C = 3 kN" },
          { t: "Free body A–B: 3 kN ↓ (from H) at 2 m from A", w: "3 kN → 2/3 → 3 × (2/3) = 2 kN = R_B\n3 kN → 1/3 → 3 × (1/3) = 1 kN = R_A" },
        ], ans: "R_C = 3 kN, R_A = 1 kN, R_B = 2 kN (M p.12)" },
        { k: "eg", title: "MACE notes example — 6) Fixed–roller beam carrying another beam (flagged in the notes)", given: "Lower beam A–B: fixed at A, roller at B, span 2 m (1 m + 1 m), UDL 10 kN/m over A–B. Upper beam C–D: end C rests on rollers on the lower beam at 1 m from A, end D on a hinge support 1 m beyond B (C–D = 2 m), UDL 10 kN/m over C–D.", steps: [
          { t: "Free body C–D: resultant 20 ↓ at the middle", w: "Reactions 10 kN ↑ at C and 10 kN ↑ at D" },
          { t: "Free body A–B (as written)", w: "Load at mid-span (C) = 10 kN from C; plus UDL 10 × 2\n(10 + 20) = 30\nR_A = 15 kN ; R_B = 15 kN" },
        ], ans: "R_A = 15 kN, R_B = 15 kN as written — but the notes add: 'No internal hinge so this is indeterminate beam — don't write this problem' (M p.12)" },
        { k: "note", t: "<b>Check:</b> the notes are right to strike this out. A fixed at A with a roller at B is a propped cantilever (4 unknowns, Ds = 1) with no internal hinge to release a moment, so 15/15 cannot be found from statics alone — it would be correct only if A were a pin. The upper beam C–D (10 kN at C, 10 kN at D) is fine." },
        { k: "eg", title: "MACE notes example — 7) Inclined 45° load beyond an internal hinge", given: "Beam A–B: A fixed; internal hinge H at 2 m from A; inclined load P at 1 m to the right of H (3 m from A), acting at 45° to the beam axis (arrow pointing down-left onto the beam, 45° marked on the B side); B = roller at the right end, 1 m beyond the load. Find the reactions at A.", steps: [
          { t: "Resolve P", w: "Vertical: P sin45 = P/√2 ↓\nHorizontal: P cos45 = P/√2 ←" },
          { t: "Free body H–B (load at the middle of 2 m)", w: "Vertical reactions: P/(2√2) ↑ at H and P/(2√2) ↑ at B\nRoller B takes no horizontal force, so the hinge H supplies P/√2 →" },
          { t: "Free body A–H (2 m): at H, P/(2√2) ↓ and P/√2 ← transferred from the hinge", w: "M_A = P/(2√2) × 2 = P/√2\nH_A = P/√2 (→)\nR_A = P/(2√2) (↑)" },
        ], ans: "M_A = P/√2, H_A = P/√2, R_A = P/(2√2) (M p.13)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Internal hinge par moment zero hota hai — yeh ek extra equation deta hai. Isliye propped cantilever (4 unknowns, sirf 3 equations) mein ek internal hinge daal do to woh determinate ban jaata hai. Tareeka hamesha same: beam ko hinge par tod do, pehle woh hissa solve karo jo apne aap mein simply supported hai (hinge + support), phir hinge ka force ulti direction mein doosre hisse (cantilever wale) par laga do." },
        { k: "p", t: "Inclined load wale example mein ek extra baat: roller horizontal force nahi le sakta, isliye load ka poora horizontal component hinge se hote hue fixed support A tak jaata hai (H_A = P/√2)." },
        { k: "trap", t: "Hinge ka force doosre hisse par transfer karte waqt direction ulti karna mat bhoolo (Newton ka third law): H–B par hinge reaction ↑ hai to A–H par wahi force ↓ lagega. Aur jab tak internal hinge na ho, fixed + roller beam ko statics se solve karne ki koshish mat karo — woh indeterminate hai (example 6)." },
        { k: "real", t: "Gerber (cantilever-suspended span) bridges mein jaan-boojh kar internal hinges rakhe jaate hain taaki support settlement se extra stress na aaye; tractor-trolley ka hitch bhi isi tarah ka moment release hai (M p.11)." },
      ],
    },

    /* ---------------------------------------------- F. centroid vs C.G. */
    {
      n: "",
      title: "MACE notes — Centroid, centre of gravity and the first moment of area",
      hi: "केन्द्रक, गुरुत्व केंद्र और क्षेत्रफल का प्रथम आघूर्ण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.110–111" },
        { k: "p", t: "<b>V-1 ★ Centre of gravity, moment of inertia and centroid.</b> (M p.110)" },
        { k: "def", term: "Centroid", t: "Geometric centre ⟸ centroid. Figure: a rectangle with both diagonals drawn, the centre point marked. (M p.110)" },
        { k: "def", term: "C.G. or centre of mass", t: "Point through which the mass of the body acts ⟸ C.G. Figure: a square with a downward arrow W at its centre. (M p.110)" },
        { k: "p", t: "<b>NOTE (M p.110):</b> the centroid is nothing but the point about which the <b>algebraic sum of moments of areas is zero</b>." },
        { k: "p", t: "<b>Figure (M p.110):</b> a square divided by a vertical dashed line through C; left part A₂, right part A₁; distances x₂ (to the left part's centroid) and x₁ (to the right part's centroid) from C. If the algebraic sum of the first moment of area about C ⟹ A₁x₁ − A₂x₂ = 0 ... C is the centroid." },
        { k: "eq", expr: "A₂x₂ = A₁x₁ (at centroid)   ⟹   ΣAᵢxᵢ = 0 at the centroid", where: [["Aᵢ, xᵢ", "area of each part and the distance of its centroid from C (signed)"]] },
        { k: "p", t: "Similarly, the <b>centre of gravity</b> is the point about which the algebraic sum of moments of masses is zero. (M p.110)" },
        { k: "p", t: "<b>Ex 1 (M p.110), Figure:</b> a horizontal bar with the C.G. marked on top; loads at the left (↓) and right (↓) ends (both written W₁ on the sketch); distances x₁ (left load to C.G.) and x₂ (C.G. to right load). <b>W₁x₁ = W₂x₂ ... at C.G.</b>" },
        { k: "cmp", t: "Side note (M p.110)", cols: ["Applies to"], rows: [
          ["Centroid", "Plane figures"],
          ["C.G.", "3D figures"],
        ] },
        { k: "p", t: "<b>Ex 2 (M p.111), Figure:</b> Position ① — side elevation of a block resting on horizontal ground, point A and the C.G. on one vertical line with an arrow downward; top view a rectangle with its centre B (B = centroid). An arrow 'change of orientation' leads up to Position ② — side elevation of the same block resting on a plane inclined at θ, point A and the C.G. with a vertical arrow downward; top view a rectangle with diagonals and centre B′ (B′ = centroid)." },
        { k: "p", t: "<b>NOTE (M p.111):</b> due to change in orientation, the <b>centroid</b> of the body changes but the <b>C.G. remains the same</b>." },
        { k: "note", t: "<b>Source difference:</b> §3.1 above (from the older notes, p.8) says the centroid and C.G. are 'located at the same point' in a 2D view. The MACE note says the centroid changes with orientation while the C.G. does not. Both are right about different things: for a homogeneous body the C.G. is a fixed point <b>in the body</b>; the 'centroid' in the MACE figure is the centroid of the <b>plane figure seen in top view</b> (B, then B′), and that projected figure changes when the block is tilted. For a flat homogeneous lamina (the 2D case) centroid and C.G. coincide." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Centroid sirf <b>shape</b> ki property hai (area ka balance point), C.G. <b>weight/mass</b> ki property hai (wazan ka balance point). Dono ki definition ek hi tarah ki hai — 'jis point ke about first moment ka algebraic sum zero ho' — bas area ki jagah mass. Taraazu ka rule W₁x₁ = W₂x₂ yahi kehta hai." },
        { k: "p", t: "Ek line yaad rakho: plane figure → centroid; 3D body → C.G. (M p.110). Beam ke cross-section jaise flat shapes ke liye hum hamesha centroid nikalte hain." },
        { k: "trap", t: "A₁x₁ − A₂x₂ = 0 mein distances <b>signed</b> hain — centroid ke ek taraf positive, doosri taraf negative. Isliye centroid ke about ΣAx = 0 aata hai. Agar sab distances positive le liye to yeh check kabhi zero nahi dega." },
        { k: "real", t: "Truck ya crane ka C.G. load ke saath badalta hai aur slope par khade hone se tipping ka khatra badhta hai — isliye site par cranes ke load charts mein boom angle aur radius ke hisaab se safe load diya hota hai." },
      ],
    },

    /* ---------------------------------------------- G. standard centroids, angle & T */
    {
      n: "",
      title: "MACE notes — Centroids of standard figures, angle section and T-section",
      hi: "मानक आकृतियों के केन्द्रक, एंगल सेक्शन और T-सेक्शन",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.111–112" },
        { k: "cmp", t: "★ Centroid of some standard figures (M p.111)", cols: ["Figure (M p.111)", "Centroid as marked"], rows: [
          ["1) Rectangle", "Length L (top), height B (left); centroid dot at the centre", "L/2 from each vertical side; B/2 from the base"],
          ["2) Square", "Side a; diagonals dashed", "At the intersection of the diagonals; a/2 from each side"],
          ["3) Right-angled triangle", "Vertical side h on the left, base b along the bottom, hypotenuse from top-left to bottom-right", "h/3 from the base (2h/3 from the top); horizontally marked 'b/2' from the vertical side and '2b/3' to the far corner"],
          ["4) Circle", "Diameter D on top; R = D/2; labels 'circumference' and 'radial direction (towards the centre)'", "At the centre — circle ⇒ infinite axes of symmetry exist"],
          ["5) Solid plate (semicircular)", "Semicircle with base D = 2R", "4r/3π above the base"],
          ["6) Arc", "Thin semicircular arc", "'2r/3π' above the base diameter (as written)"],
          ["7) Quarter circle", "Dashed 'axis of symmetry' at 45°", "4r/3π from the vertical edge and 4r/3π from the horizontal edge"],
          ["8) Hemisphere", "Flat face vertical, 'diametral axis' at the flat face", "3r/8 from the flat face"],
          ["9) Solid circular cone", "Apex at left, circular base ('diametral axis') at right, dashed 'axis of rotation'", "On the axis, 3h/4 from the apex, h/4 from the base"],
          ["10) Sector of circle", "Vertex at left, arc at right, dashed axis of symmetry", "'(3r/α) sin α' from the vertex (as written)"],
        ] },
        { k: "note", t: "<b>Check — three entries on M p.111:</b><br>• Triangle: the horizontal mark should be <b>b/3</b> from the vertical side (b/3 + 2b/3 = b); 'b/2' cannot be paired with 2b/3. The vertical h/3 from the base is right.<br>• Semicircular arc (thin wire): ȳ = <b>2r/π</b> (≈ 0.637r) from the diameter, not 2r/3π. (Integration: ȳ = ∫r sinθ · r dθ / (πr) = 2r²/(πr).)<br>• Sector of half-angle α (radians) measured from the axis of symmetry: x̄ = <b>2r sin α / (3α)</b> from the vertex, not (3r/α) sin α. Check: α = π/2 gives a semicircle, 2r/(3·π/2) = 4r/3π ✔.<br>Other entries (rectangle, square, semicircle 4r/3π, quarter circle 4r/3π, hemisphere 3r/8, cone h/4 from base) are correct." },
        { k: "h", t: "Que 1 — angle section (M p.112)" },
        { k: "p", t: "<b>Que 1:</b> For a given angle section, find the distance of the centroid from the x and y axes respectively.<br><b>Figure (M p.112):</b> an L-shaped angle on x–y axes — vertical leg of width b rising d above the horizontal leg; horizontal leg extending d beyond the vertical leg, thickness b. <b>Step 1 — separate:</b> vertical rectangle A₁ (width b, height b + d from the x-axis) and horizontal rectangle A₂ (length d, height b) at the bottom right; y-axis along the left edge, x-axis along the bottom; arrows show A₁ ↓ and A₂ ↓ at their centroids, and a red dashed line through the overall centroid labelled 'A₃ = (A₁ + A₂) = ΣA'. Distances from the y-axis: x₁ (to A₁'s centroid), x̄ (overall, red), x₂ (to A₂'s centroid). x̄ = centroid of the angle section." },
        { k: "p", t: "Algebraic sum of moments of area about the y-axis (as written): +A₁x₂ + A₂x₂ = ΣA × x̄ (M p.112)" },
        { k: "eq", expr: "x̄ = (A₁x₁ + A₂x₂)/ΣA   ;   ȳ = (y₁A₁ + y₂A₂)/ΣA   ;   ★ x̄ = x₁(A₁/ΣA) + x₂(A₂/ΣA)", where: [
          ["A₁, A₂", "areas of the two rectangles; ΣA = A₁ + A₂"],
          ["x₁, x₂ / y₁, y₂", "distances of their centroids from the y-axis / x-axis"],
        ] },
        { k: "note", t: "The first line on M p.112 has a slip of the pen: it should read <b>+A₁x₁ + A₂x₂ = ΣA × x̄</b>, which is what the boxed formula below it uses. For this angle, with the notes' labels: A₁ = b(b + d), x₁ = b/2, y₁ = (b + d)/2; A₂ = bd, x₂ = b + d/2, y₂ = b/2 (the notes stop at the general formula)." },
        { k: "eg", title: "MACE notes example — Que 2 centroid of a T-section", given: "Find out the centroid of a T-section: top flange 100 mm wide × 20 mm thick (A₁); web 20 mm wide (A₂), web height 80 mm below the flange. x measured from the left edge of the flange, y from the base.", steps: [
          { t: "Areas and centroid distances", w: "A₁ = 100 × 20 = 2000\nA₂ = 80 × 20 = 1600\nx₁ = 50, x₂ = 50\ny₁ = 90, y₂ = 40" },
          { t: "x̄", w: "x̄ = (A₁x₁ + A₂x₂)/ΣA\n= ((100 × 20) × 50 + (80 × 20) × 50)/((100 × 20) + (80 × 20))\nx̄ = 50 mm" },
          { t: "ȳ", w: "ȳ = (A₁y₁ + A₂y₂)/ΣA = 76.25 mm" },
        ], ans: "x̄ = 50 mm, ȳ = 76.25 mm (M p.112, as written — see Check)" },
        { k: "note", t: "<b>Check:</b> ȳ = (2000 × 90 + 1600 × 40)/(2000 + 1600) = 244 000/3600 = <b>67.78 mm</b> from the base. The notes' 76.25 is 244 000/3200 — the numerator divided by a wrong ΣA. x̄ = 50 mm is right (symmetry). Sanity check: 67.78 lies between y₂ = 40 and y₁ = 90 and nearer the bigger area A₁, as it must." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Standard shapes ke centroid ratte nahi, logic se yaad rakho: triangle mein base se h/3 (zyada area neeche hai, isliye centroid neeche khisakta hai); semicircle plate 4r/3π ≈ 0.424r; patli arc mein saara material curve par hai, isliye uska centroid plate se upar — 2r/π ≈ 0.637r. Cone ka h/4 base se, hemisphere ka 3r/8 flat face se." },
        { k: "p", t: "Composite section ka formula x̄ = x₁(A₁/ΣA) + x₂(A₂/ΣA) batata hai ki centroid parts ke centroids ka <b>area-weighted average</b> hai — isliye answer hamesha y₁ aur y₂ ke beech aur bade area ki taraf hoga. Yeh ek free check hai." },
        { k: "trap", t: "Har part ka y us part ke <b>apne centroid</b> tak lo, ek hi reference edge se. T-section mein flange ka y₁ = 80 + 10 = 90 (base se), 10 nahi. Aur ΣA mein sab parts jodo — T-section ke notes wale answer mein yahi galti hui." },
        { k: "real", t: "Steel tables mein ISA (angle) sections ke liye Cxx, Cyy (centroid distances) diye hote hain — bolt line aur welding ka balance isi centroid ke hisaab se karte hain taaki connection mein eccentricity na aaye." },
      ],
    },

    /* ---------------------------------------------- H. MOI, standard MOIs, theorems */
    {
      n: "",
      title: "MACE notes — Moment of inertia, standard sections and the two theorems",
      hi: "जड़त्व आघूर्ण, मानक परिच्छेद और दो प्रमेय",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.112–114" },
        { k: "p", t: "<b>V-2 ★ Moment of inertia (M.I.)</b> (M p.112)" },
        { k: "list", items: [
          "★ Property associated with <b>rotation</b> of bodies; generally applicable to plane bodies.",
          "<b>2nd moment of area.</b>",
          "→ Found out as Ixx, Iyy. (M p.112)",
        ] },
        { k: "p", t: "<b>Figure (M p.112):</b> an arbitrary area on x–y axes; a small hatched elemental area dA at distance x from the y-axis and y from the x-axis." },
        { k: "eq", expr: "MI about x–x = 2nd moment of area about the x-axis = (y·dA)·y = y²·dA   ⟹   Ixx = ∫y² dA  (for the entire area)", where: [["y", "distance of dA from the x-axis"]] },
        { k: "eq", expr: "MI about y–y = 2nd moment of area about the y-axis = (x·dA)·x   ⟹   Iyy = ∫x² dA", where: [["x", "distance of dA from the y-axis"]] },
        { k: "p", t: "<b>NOTE (M p.113):</b> to find the moment of inertia there are two methods — a) <b>Routh's rule</b>, b) <b>integration method</b>." },
        { k: "cmp", t: "★ Moment of inertia of some standard figures — about the centroidal axes (M p.113)", cols: ["Ixx", "Iyy / other"], rows: [
          ["1) Rectangle (b wide, d deep)", "bd³/12", "Iyy = db³/12"],
          ["2) Square (side a)", "a⁴/12", "Iyy = a⁴/12"],
          ["3) Circle (diameter D)", "(π/64)D⁴", "Iyy = (π/64)D⁴"],
          ["4) Triangle (base b, height h)", "bh³/36", "—"],
          ["5) Circular ring (thin; mean radius r, thickness t)", "Ixx = Iyy = πr³t = (π/8)d³·t", "A = 2πrt"],
          ["6) Quarter circle (radius r)", "0.055r⁴ = 0.05488r⁴", "—"],
          ["7) Semicircle (radius r)", "0.11r⁴", "—"],
        ] },
        { k: "h", t: "★ Theorems on moment of inertia (M p.113)" },
        { k: "list", items: [
          "i) <b>Parallel axis theorem</b> (transfer theorem)",
          "ii) <b>Perpendicular axis theorem</b> (polar moment of inertia)",
        ] },
        { k: "def", term: "i) Parallel axis theorem", t: "Moment of inertia about any parallel axis = moment of inertia about the centroidal axis + A × [distance between the centroidal axis and the parallel axis]². (M p.113)" },
        { k: "p", t: "<b>Figure (M p.113):</b> a rectangle of width b and depth d (area A); red dashed 'centroidal axis' through mid-depth; the 'base' line at the bottom extended as the 'parallel axis'; h = distance between the centroidal axis and the base." },
        { k: "eq", expr: "★ I_base = I_centroidal + A·h²", where: [["h", "distance between the centroidal axis and the parallel axis"]] },
        { k: "h", t: "ii) Perpendicular axis theorem (M p.114)" },
        { k: "p", t: "<b>Figure (M p.114):</b> 3D axes x, y, z (z coming out obliquely); a hatched elemental area dA in an arbitrary shape lying in the x–y plane, at distance x from the y-axis, y from the x-axis and radial distance r (dashed) from the origin." },
        { k: "steps", items: [
          "We know that Ixx = ∫y² dA, Iyy = ∫x² dA, Izz = ∫r² dA.",
          "But by Pythagoras' theorem, x² + y² = r².",
          "Multiply by dA on both sides: x² dA + y² dA = r² dA.",
          "Integrate on both sides: ∫x² dA + ∫y² dA = ∫r² dA.",
        ] },
        { k: "eq", expr: "★ Iyy + Ixx = Izz  (= I_polar)", where: [["r", "radial or polar distance of dA from the z-axis"], ["z-axis", "perpendicular to the plane of the area, through the point where x and y meet"]] },
        { k: "note", t: "<b>Source difference / cross-check with §3.3:</b> the MACE values agree with the table in §3.3 — quarter circle 0.05488r⁴ (§3.3: ≈ 0.0549r⁴) and semicircle 0.11r⁴ (§3.3: ≈ 0.1098r⁴); 0.11 is that value rounded. Thin ring: πr³t is the limit of π(R⁴ − r⁴)/4 for a small thickness t (re-derived: R = r + t/2, inner r − t/2 ⇒ ≈ π·4r³t/4 = πr³t ✔); with d = 2r, (π/8)d³t = πr³t ✔." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "First moment (∫y dA) centroid dhoondhta hai; second moment (∫y² dA) batata hai ki area axis se kitna <b>door phaila</b> hai. Distance square hoti hai, isliye door ka material bahut zyada count hota hai — I-section aur hollow tube isi wajah se efficient hain." },
        { k: "p", t: "Do theorems do kaam karte hain: <b>parallel axis</b> — centroidal I ko kisi bhi parallel axis par le jaata hai (+Ah², hamesha badhta hai); <b>perpendicular axis</b> — plane ke do perpendicular axes ke I jod kar plane ke perpendicular (z) axis ka I deta hai, yaani polar MOI, jo shaft ke torsion mein kaam aata hai." },
        { k: "trap", t: "Parallel axis theorem sirf <b>centroidal</b> axis se shuru hota hai: I = I_G + Ah². Base se apex par seedha Ah² mat lagao. Aur perpendicular axis theorem sirf <b>plane lamina</b> ke liye hai — z-axis area ke plane ke perpendicular honi chahiye." },
        { k: "real", t: "Rectangle ka Ixx = bd³/12 depth ke cube se badhta hai — isliye beam ko hamesha uski <b>depth</b> vertical rakh kar lagate hain (230 × 450 beam, 450 vertical). Plank ko flat rakh do to woh bahut zyada jhukta hai." },
      ],
    },

    /* ---------------------------------------------- I. MOI numericals, k, I-section */
    {
      n: "",
      title: "MACE notes — MOI numericals, radius of gyration and the I-section",
      hi: "जड़त्व आघूर्ण के प्रश्न, परिभ्रमण त्रिज्या और I-सेक्शन",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.114–116" },
        { k: "eg", title: "MACE notes example — Que 1 rectangle about its base", given: "Find out the moment of inertia of a rectangular section b × d about an axis passing through the base 'b'. (Figure: dashed centroidal axis at mid-depth with Ixx = bd³/12; h = distance from the centroidal axis to the base; base line labelled I_base.)", steps: [
          { t: "Parallel axis theorem", w: "I_base = I_centroidal + A·h²\n= bd³/12 + (b × d) × (d/2)²\n= bd³/12 + bd³/4   (second term ×3/×3)\n= 4bd³/12" },
        ], ans: "I_base = bd³/3 (M p.114)" },
        { k: "eg", title: "MACE notes example — Que 2 triangle about apex and base", given: "Find out the MOI of a triangular section at the apex and the base. Triangle of base b and height H, apex at top. Figure labels: centroidal axis at H/3 above the base (2H/3 below the apex) — bH³/36; 'axis in the plane passing through apex parallel to the centroidal axis' — bH³/4; 'axis in the plane passing through base parallel to centroidal axis' — bH³/12; a vertical line through the apex bisecting the base labelled 'in the plane passing through apex and bisecting the base' with a red note bH³/36.", steps: [
          { t: "Apex (centroid 2H/3 away)", w: "I_apex = bH³/36 + (½bH)(2H/3)²\n= bH³/36 + (4/18)bH³   (×2/×2)\nI_apex = bH³/4" },
          { t: "Base (centroid H/3 away)", w: "I_base = bH³/36 + ½b·H(H/3)²\n= bH³/36 + bH³/18   (×2/×2)\n= 3bH³/36\nI_base = bH³/12" },
        ], ans: "I_apex = bH³/4, I_base = bH³/12 (M p.114)" },
        { k: "note", t: "<b>Source difference:</b> the older notes (p.8, §3.3) wrote 'triangle, origin at the vertex (apex): Ixx = bh³/12'. The MACE notes give <b>bH³/12 about the base</b> and <b>bH³/4 about the apex</b> — the MACE values are right (re-derived above; same as the correction note and Worked example 3.3 in §3.3). The red 'bH³/36' written next to the vertical line through the apex in the MACE figure is not the MOI about that vertical axis: for an isosceles triangle, I about the axis of symmetry is <b>hb³/48</b> (General Engineering Knowledge). bH³/36 belongs to the horizontal centroidal axis." },
        { k: "eg", title: "MACE notes example — Que 3 hollow circular section", given: "What is the MOI of a hollow circular section of external diameter 'D' and internal diameter 'd'?", steps: [
          { t: "Hollow = solid of dia D − cut portion of dia d", w: "Iyy = Ixx = (π/64)D⁴ − (π/64)d⁴\nIxx = Iyy = (π/64)(D⁴ − d⁴)" },
          { t: "In radii", w: "= (π/64)[(2R)⁴ − (2r)⁴]\n= (π/64)(2)⁴[R⁴ − r⁴]\nIxx = Iyy = (π/4)(R⁴ − r⁴)" },
        ], ans: "Ixx = Iyy = (π/64)(D⁴ − d⁴) = (π/4)(R⁴ − r⁴) (M p.115)" },
        { k: "eg", title: "MACE notes example — Que 4 polar MOI of a hollow circular section", given: "Find out the polar moment of inertia of a hollow circular section (external diameter D, internal diameter d).", steps: [
          { t: "Polar MI of hollow = polar MI of solid (D) − polar MI of cut portion (d)", w: "= (I_P)_D − (I_P)_d\n= [Ixx + Iyy]_D − [Ixx + Iyy]_d\n= [(π/64)D⁴ + (π/64)D⁴] − [(π/64)d⁴ + (π/64)d⁴]\n= 2 × (π/64)D⁴ − 2 × (π/64)d⁴" },
        ], ans: "I_polar = (π/32)[D⁴ − d⁴] for hollow; I_polar = (π/32)D⁴ for solid, or I_polar = 2Ixx = 2Iyy (M p.115)" },
        { k: "eg", title: "MACE notes example — Que 5 MCQ: square about the axis normal to its plane", given: "A square section of side a × a will have MOI about an axis passing through the centroid and perpendicular to its plane: a) a⁴  b) a⁴/12  c) a⁴/6  d) a³/6. (Figure: square with dashed centroidal axes, Iyy = a⁴/12 and Ixx = a⁴/12, and a red curved arrow at the centroid for rotation about the axis normal to the plane.)", steps: [
          { t: "Perpendicular to the plane and through the centroid ⟹ polar MOI", w: "I_polar = Ixx + Iyy\n= a⁴/12 + a⁴/12 = a⁴/6" },
        ], ans: "Option (c) a⁴/6 (M p.115)" },
        { k: "p", t: "• ⊥ar to its plane म्हणजे z-z axis च्या about विचारलय — <i>(Marathi) 'perpendicular to its plane' means the question asks about the z–z axis.</i> (M p.115)" },
        { k: "eg", title: "MACE notes example — Que 6 circle about a tangent in its plane", given: "What is the MOI of a circular section about an axis tangent to the circle in the plane of the circle? (Figure: circle of diameter D, dashed vertical centroidal axis with I = (π/64)D⁴, and a dashed vertical tangent at the right edge labelled 'tangent in plane'; h = distance from the centre to the tangent; note 'I parallel axis = I_c + Ah²'.)", steps: [
          { t: "Parallel axis theorem with h = D/2", w: "I_parallel axis = (π/64)D⁴ + ((π/4)D²)·[D/2]²\n= (π/64)D⁴ + (π/16)D⁴   (×4/×4)\n= (π/64)(5D⁴)" },
        ], ans: "I_tangent = 5πD⁴/64 (M p.116)" },
        { k: "h", t: "★ Radius of gyration (K) — M p.116" },
        { k: "eq", expr: "I = A·K²   ⟹   K = √(I/A)", where: [["I", "moment of inertia"], ["A", "area"], ["K", "radius of gyration"]] },
        { k: "p", t: "<b>Side note (boxed, M p.116) — in steel:</b> λ = L_eff / r_min, where r_min = minimum radius of gyration." },
        { k: "eg", title: "MACE notes example — Que 7 centroid and MOI of an I-section", given: "Consider the following I-section; locate the centroid and find out the MOI of the I-section. Total depth 100 mm. Top flange (1): 100 mm wide × 10 mm thick. Web (2): 10 mm thick, 80 mm high. Bottom flange (3): 80 mm wide × 10 mm thick. y measured from the base; h = distance of each part's centroid from the overall centroidal axis (Ixx)c.", steps: [
          { t: "Areas and centroid heights", w: "A₁ = 1000, y₁ = 95\nA₂ = 800, y₂ = 50\nA₃ = 800, y₃ = 5\nΣA = 2600" },
          { t: "Centroid", w: "ȳ = (A₁y₁ + A₂y₂ + A₃y₃)/(A₁ + A₂ + A₃) = 53.46" },
          { t: "Distances h = |ȳ − yᵢ|", w: "h₁ = 95 − 53.46 = 41.54\nh₂ = 53.46 − 50 = 3.46\nh₃ = 53.46 − 5 = 48.46" },
          { t: "Parallel axis theorem for each part (Ixx = bd³/12)", w: "(Ixx)c = [Ixx₁ + A₁h₁²] + [Ixx₂ + A₂h₂²] + [Ixx₃ + A₃h₃²]\n= [(100 × 10³)/12 + 1000(41.54)²] + [(10 × 80³)/12 + 800(3.46)²] + [(80 × 10³)/12 + 800(48.46)²]" },
          { t: "Result", w: "(Ixx)c = (left blank in the notes)" },
        ], ans: "ȳ = 53.46 mm from the base; (Ixx)c set up but not evaluated in the notes (M p.116)" },
        { k: "note", t: "<b>Check:</b> the denominator of ȳ is written 'A₁ + A₂ + y₃' on M p.116 — it should be A₁ + A₂ + A₃ = 2600 (the value 53.46 = 139 000/2600 uses the right sum). Completing the last line: flange 1 = 8 333 + 1 725 444 = 1 733 777; web = 426 667 + 9 586 = 436 252; flange 3 = 6 667 + 1 878 817 = 1 885 483; <b>(Ixx)c ≈ 4.056 × 10⁶ mm⁴</b>." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har MOI numerical ek hi recipe hai: (1) shape ko standard parts mein todo, (2) centroid nikalo, (3) har part ka apna I_G + A·h² lo, jahan h = part ke centroid se overall centroid tak, (4) sab jodo. Hollow section mein 'solid minus hole' karo. Plane ke perpendicular axis ka sawaal ho to Ixx + Iyy (polar)." },
        { k: "p", t: "Radius of gyration K = √(I/A) ek length hai jo batati hai section ka area axis se 'average' kitna door hai. Column hamesha us axis ke about buckle karta hai jahan K <b>sabse kam</b> ho — isliye steel mein slenderness λ = L_eff/r_min." },
        { k: "trap", t: "I-section mein flanges ka apna I (bd³/12, b = 100, d = 10) bahut chhota hai — asli contribution Ah² term se aata hai. Students aksar Ah² bhool kar sirf bd³/12 jod dete hain, jo answer ko ~25 guna kam kar deta hai. Aur tangent wale sawaal mein h = D/2 hai, D nahi." },
        { k: "real", t: "Steel column ke design mein IS 800 ke buckling curves λ = KL/r_min par chalte hain (§ columns, Chapter 5); ISMB section ka r_yy (minor axis) r_xx se kaafi kam hota hai, isliye column weak axis ke about pehle buckle karta hai." },
      ],
    },

    /* ---------------------------------------------- J. mass MOI, principal axes */
    {
      n: "",
      title: "MACE notes — Mass moment of inertia, product of inertia and principal axes",
      hi: "द्रव्यमान जड़त्व आघूर्ण, जड़त्व गुणनफल और मुख्य अक्ष",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.117" },
        { k: "list", items: [
          "Moment of inertia is a property applied to plane figures and associated with the <b>area</b> of the body. (M p.117)",
          "Mass moment of inertia is associated with the <b>mass</b> of the body. It is simply the <b>2nd moment of mass</b>. (M p.117)",
        ] },
        { k: "eq", expr: "MMI = second moment of mass = ∫r² dm", where: [["r", "distance of the mass element dm from the axis"]] },
        { k: "cmp", t: "Area MOI vs mass MOI (M p.117)", cols: ["Moment of inertia (2nd moment of area)", "Mass moment of inertia (2nd moment of mass)"], rows: [
          ["Formula", "∫y² dA or ∫x² dA  (x² → (distance)², dA → (area)²  — as written)", "∫r² dm  (r² → (distance)², dm → kg)"],
          ["Unit", "<b>m⁴</b> ★", "<b>kg·m²</b> ★ or (kg·m²·s²)/s² = (kg·m·m·s²)/s² = <b>N·m·s²</b> ★"],
          ["Dimension", "<b>M⁰ L⁴ T⁰</b> ★", "<b>M¹ L² T⁰</b> ★"],
        ] },
        { k: "note", t: "In the formula row, 'dA → (area)²' as written means dA is an area, unit m² — so ∫y² dA has unit m² × m² = m⁴, which is the unit the notes box. Unit check of N·m·s²: N = kg·m/s², so N·m·s² = kg·m², ✔." },
        { k: "list", items: [
          "<b>NOTE (M p.117):</b> the <b>product of inertia</b> about the principal axes is <b>zero</b>.",
          "Maximum and minimum moments of inertia are called <b>principal moments of inertia</b>, which occur about the <b>principal axes</b>. Principal axes always pass through the centroid.",
          "Product of inertia is zero about the principal axes, and at least one of the principal axes is always a symmetrical axis.",
        ] },
        { k: "note", t: "<b>Check — reading the last two NOTE lines (General Engineering Knowledge):</b> (1) the product of inertia is I_xy = ∫xy dA; the principal axes are the pair of perpendicular axes for which I_xy = 0. (2) Principal axes can be found at any point, but the ones used in beam and column design are the <b>centroidal</b> principal axes — that is what the notes mean. (3) 'At least one principal axis is always a symmetry axis' is true only <b>if the section has an axis of symmetry</b> (then that axis and the axis perpendicular to it are principal). Sections with no symmetry axis — an unequal angle, a Z-section — still have principal axes, but they are inclined, and neither is a symmetry axis." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Area MOI (m⁴) beam ke <b>mudne</b> (bending) ka resistance batata hai; mass MOI (kg·m²) kisi body ke <b>ghoomne</b> (rotation, angular acceleration) ka resistance batata hai. Naam same, kaam alag — SOM mein jab 'I' likha ho to lagbhag hamesha area MOI hota hai." },
        { k: "p", t: "Principal axes woh do perpendicular directions hain jahan section ka I sabse zyada aur sabse kam hota hai, aur product of inertia zero. Symmetric section (rectangle, I-section) mein yeh seedhe symmetry axis aur uske perpendicular hain — isliye wahan Ixx aur Iyy hi principal values hain." },
        { k: "trap", t: "Unit mein confuse mat hona: area MOI ka unit m⁴ (ya mm⁴) hai, kg·m² nahi. Aur yeh mat maan lo ki har section ka principal axis uski edge ke parallel hota hai — unequal angle (ISA 100 × 65) ka principal axis tircha hota hai, isliye single-angle strut weak (v–v) axis ke about buckle karta hai." },
        { k: "real", t: "Steel tables mein angle sections ke liye r_vv (minimum radius of gyration, inclined principal axis) alag se diya hota hai — single-angle bracing/struts ka design isi r_vv se hota hai, r_xx ya r_yy se nahi." },
      ],
    },

    /* ---------------------------------------------- K. revision */
    {
      n: "",
      title: "MACE notes revision — basics, reactions, centroid and moment of inertia (M p.4–13, M p.110–117)",
      hi: "पुनरावृत्ति — मूल बातें, प्रतिक्रियाएँ, केन्द्रक और जड़त्व आघूर्ण",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and definitions" },
        { k: "list", items: [
          "Unbalanced force → translation; unbalanced moment → rotation; DOF = number of directions in which a body can displace (M p.4).",
          "3D: 6 displacements (Δx, Δy, Δz, θx, θy, θz), 6 equilibrium conditions; 2D: 3 (Δx, Δy, θxy), 3 conditions ΣFx = ΣFy = ΣM = 0 (M p.4).",
          "Restraint = restricting a displacement by a support; DOF = 6 − R (3D), DOF = 3 − R (2D) (M p.5).",
          "Hinge: R = 2, DOF 1 (rotation); roller: R = 1, DOF 2 (R, T); fixed: R = 3, DOF 0; slider/guided roller: R = 2, DOF 1 (sliding window, channel gate) (M p.5).",
          "Rigid joint keeps its angle (90° stays 90°) after loading; pin joint does not (M p.6).",
          "Beam types: simply supported (R = 3), cantilever (R = 3), propped cantilever (R = 4, Ds = 1), continuous, overhang; overhang with end load can give a downward reaction at the far support (M p.6, p.12).",
          "Support reduces the DOF of the point where it is provided; more support → more stability (M p.7).",
          "Shortcut: ΣM = 0 always; load shares in the span ratio — each support takes the fraction of span on the far side of the load. P at L/3 from A → V_A = 2P/3, V_B = P/3 (M p.8).",
          "Symmetric beam R_A/R_B = 1; full UDL → wL/2 each (M p.8).",
          "UDL on the left half → R_A = 3wL/8, R_B = wL/8 (notes print them swapped, M p.9 — corrected).",
          "6 m beam, 2 kN/m over the middle 2 m (1–2–3) → V_A = 2.67 kN, V_B = 1.33 kN (M p.9).",
          "UVL 0 → w: V_A = wL/6 (light end), V_B = wL/3 (heavy end) (M p.9).",
          "Couple M on an SS beam: reaction = net moment/span = M/L, V_A/V_B = −1, position of couple irrelevant (M p.9–10).",
          "20 kN·m on 4 m → 5 kN ↓ at A, 5 kN ↑ at B; 10 kN + 5 kN·m on 2 m → 2.5 / 7.5 kN; 10 kN + 20 kN·m → −5 / +15 kN (M p.10).",
          "Load shifting: a force moved to another point = same force + moment (force × distance); effect at the far point = rotation + translation (M p.10).",
          "Internal hinge = moment release: ΣM on either side = 0; portions rotationally independent; reduces stiffness; analyse by breaking at the hinge (M p.11).",
          "Hinge examples: P/2 each with M_A = PL/4; 20/20 kN with M_A = 40 kN·m; M_A = 20 kN·m; M_A = 4 kN·m; M_A = 0, V_A = 10 kN; R_A = 1, R_B = 2, R_C = 3 kN (M p.12).",
          "45° load P beyond a hinge: M_A = P/√2, H_A = P/√2, R_A = P/(2√2) (M p.13).",
          "Centroid = geometric centre; point about which ΣAᵢxᵢ = 0. C.G. = point through which mass acts; ΣWx = 0. Centroid → plane figures, C.G. → 3D (M p.110).",
          "Change of orientation changes the (projected) centroid but not the C.G. (M p.111).",
          "Centroids: rectangle/square at centre; triangle h/3 from base and b/3 from the vertical side (notes: b/2 — corrected); semicircle 4r/3π; semicircular arc 2r/π (notes: 2r/3π — corrected); quarter circle 4r/3π from each edge; hemisphere 3r/8; cone h/4 from base; sector 2r sin α/(3α) (notes: (3r/α) sin α — corrected) (M p.111).",
          "Composite: x̄ = (A₁x₁ + A₂x₂)/ΣA = x₁(A₁/ΣA) + x₂(A₂/ΣA); ȳ likewise (M p.112).",
          "T-section 100 × 20 flange + 20 × 80 web: x̄ = 50 mm; ȳ = 67.78 mm from base (notes print 76.25 — corrected) (M p.112).",
          "MOI = 2nd moment of area: Ixx = ∫y² dA, Iyy = ∫x² dA; methods: Routh's rule, integration (M p.112–113).",
          "Rectangle bd³/12, db³/12; square a⁴/12; circle πD⁴/64; triangle bh³/36; thin ring πr³t = (π/8)d³t; quarter circle 0.055r⁴; semicircle 0.11r⁴ (M p.113).",
          "Parallel axis: I = I_G + Ah²; perpendicular axis: Izz = Ixx + Iyy = I_polar (M p.113–114).",
          "Rectangle about base bd³/3; triangle about base bH³/12, about apex bH³/4 (M p.114).",
          "Hollow circle I = (π/64)(D⁴ − d⁴) = (π/4)(R⁴ − r⁴); polar (π/32)(D⁴ − d⁴), solid (π/32)D⁴ = 2Ixx (M p.115).",
          "Square about the axis normal to its plane through the centroid: a⁴/6 (M p.115).",
          "Circle about a tangent in its plane: 5πD⁴/64 (M p.116).",
          "Radius of gyration K = √(I/A), I = AK²; steel slenderness λ = L_eff/r_min (M p.116).",
          "I-section (100 × 10 top, 10 × 80 web, 80 × 10 bottom): ȳ = 53.46 mm from base; (Ixx)c ≈ 4.056 × 10⁶ mm⁴ (completed here) (M p.116).",
          "Mass MOI = ∫r² dm, unit kg·m² = N·m·s², dimension M¹L²T⁰; area MOI unit m⁴, dimension M⁰L⁴T⁰ (M p.117).",
          "Principal axes: product of inertia zero, max/min (principal) MOI occur about them, taken through the centroid; a symmetry axis, if present, is a principal axis (M p.117, clarified).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
