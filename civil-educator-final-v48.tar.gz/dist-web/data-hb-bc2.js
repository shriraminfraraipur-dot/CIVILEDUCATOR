/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING CONSTRUCTION · Ch 3–5
   Brickwork bonds · Load-bearing masonry design · Plaster & finishes
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bc");
  if (!hb) { console.error("[bc2] handbook bc not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "bc-3",
      n: 3,
      title: "Brickwork Practice and Bonds",
      hi: "चिनाई की विधि और बॉन्ड",
      blurb: "Why brickwork is bonded at all, the difference between English and Flemish bond, and the workmanship rules that make a wall strong.",
      mins: 32,
      sections: [
        {
          n: "3.1",
          title: "Break the joint or it isn't a wall",
          hi: "जोड़ तोड़ो वरना दीवार नहीं",
          blocks: [
            { k: "p", t: "The single idea behind all brick bonding is this: no vertical joint may run continuously up the wall. Stack bricks with their joints aligned and each column of bricks is independent — the wall splits into separate stacks under load. Bonding staggers the joints so every brick rests across the two below it, tying the whole wall into one mass." },
            { k: "dia", id: "hb-bc-bonds", cap: "Unbonded stacking versus English and Flemish bond." },
            { k: "def", term: "Header and stretcher", t: "A header is a brick laid with its end showing on the face — it runs across the thickness of the wall, binding its two skins together. A stretcher is laid with its long side showing — it runs along the wall's length. Bonds are simply patterns of headers and stretchers." },
            { k: "def", term: "Lap", t: "The horizontal distance by which a brick in one course overlaps the joint below it — usually a quarter or half brick. The lap is what breaks the vertical joint; a bond with no proper lap (a 'straight joint') is a line of weakness that cracks straight up." },
          ],
        },
        {
          n: "3.2",
          title: "English versus Flemish",
          hi: "इंग्लिश बनाम फ़्लेमिश",
          blocks: [
            { k: "p", t: "The two common bonds arrange headers and stretchers differently, and the choice is the familiar one between strength and appearance." },
            { k: "cmp", t: "The two bonds",
              cols: ["English bond", "Flemish bond"],
              rows: [
                ["Pattern", "whole courses of headers, then stretchers", "header & stretcher alternate in every course"],
                ["Strength", "stronger — the standard for load-bearing", "slightly weaker (more internal straight joints)"],
                ["Appearance", "plainer", "more attractive, patterned face"],
                ["Economy", "uses fewer cut bricks (bats)", "needs more bats"],
                ["Use", "structural walls, engineering work", "facing, architectural work"],
              ] },
            { k: "list", items: [
              "<strong>Queen closer</strong> — in English bond a brick cut lengthwise in half (a quarter-brick wide face) is laid next to the corner header in each header course. It is what produces the quarter-brick lap; omit it and the joints line up.",
              "<strong>Wall thickness in bricks</strong> — a ‘half-brick’ wall is one stretcher thick (a partition); a ‘one-brick’ wall is one header long (about 200 mm modular or 230 mm non-modular); load-bearing external walls are commonly one or one-and-a-half bricks.",
              "<strong>Stretcher bond</strong> — stretchers only, half-brick lap; used for half-brick partitions and the leaves of cavity walls, never for a thick load-bearing wall because no brick crosses its thickness.",
            ] },
            { k: "real", t: "You can read a wall's bond from the street. If whole courses show only brick-ends (headers) alternating with courses of long faces (stretchers), it is English bond — usually a structural, load-bearing wall. If every course mixes ends and faces in a regular pattern, it is Flemish — usually chosen because someone wanted the face to look good. <strong>The bond quietly tells you whether strength or appearance was the priority.</strong>" },
          ],
        },
        {
          n: "3.3",
          title: "Workmanship — what makes brickwork sound",
          hi: "कारीगरी",
          blocks: [
            { k: "p", t: "A good bond drawn on paper is undone by bad laying. A handful of workmanship rules separate a sound wall from a weak one, and they are the things to check on site." },
            { k: "list", items: [
              "<strong>Fully filled joints</strong> — every vertical and horizontal joint packed with mortar; unfilled joints are voids and leaks.",
              "<strong>Bricks soaked before laying</strong> — a dry brick sucks water out of the mortar, starving it of the water it needs to gain strength.",
              "<strong>Courses level and plumb</strong> — checked with line and spirit level; a wall out of plumb is eccentrically loaded and weaker.",
              "<strong>Limited daily height</strong> — raise a wall only so much a day, so the fresh mortar below is not overloaded before it sets.",
              "<strong>Joints about 10 mm</strong> — thicker joints mean more of the weak material and more shrinkage.",
              "<strong>Cured</strong> — kept damp for a few days like any cement work, so the mortar gains strength.",
            ] },
            { k: "trap", t: "Laying dry bricks is one of the most common and most damaging site habits. The parched brick draws the mixing water straight out of the mortar, which then never properly hydrates and sets weak and powdery — so the joints, already the weak link, become weaker still. Bricks must be soaked until they stop bubbling before they are laid." },
            { k: "cmp", t: "Workmanship numbers, and where the sources disagree", cols: ["Value", "Source"], rows: [
              ["Soaking", "at least 2 hours before use", "BSEH marking scheme; InfraLens checklist (citing IS 2212)"],
              ["Joint thickness", "10 mm (8–10 mm; checklist 10 ± 3 mm)", "BSEH; InfraLens"],
              ["Height raised per day", "<strong>1.0 m typical</strong> / <strong>not more than 1.5 m</strong>", "InfraLens / BSEH — they disagree"],
              ["Curing", "7 days / 7–14 days", "InfraLens (citing IS 2212) / BSEH"],
              ["Plumb", "± 6 mm per 3 m height", "InfraLens"],
            ]},
            { k: "note", t: "Sources: <a href=\"https://bseh.org.in/uploads/files/16745d2d95aa8c0274bbbc2e0c3b7235.pdf\" target=\"_blank\" rel=\"noopener\">BSEH construction marking scheme</a> and the <a href=\"https://infralens.in/formats/site-execution/brickwork-inspection-checklist\" target=\"_blank\" rel=\"noopener\">InfraLens brickwork checklist</a>. The daily-height limit is quoted differently; where the specification of the job does not say, the lower figure is the safe one. IS 2212 is the governing code of practice for brickwork — check the job specification against it." },
            { k: "eg", title: "Example 3.1 — Bricks for one wall",
              given: "A one-brick (230 mm) wall 4.0 m long and 3.0 m high contains a door opening 1.0 × 2.1 m. Non-modular bricks, 10 mm joints (434 bricks per m³ from Example 2.2).",
              steps: [
                { t: "Net area", w: "4.0 × 3.0 − 1.0 × 2.1 = 12.0 − 2.1 = 9.9 m²" },
                { t: "Volume", w: "9.9 × 0.23 = 2.277 m³" },
                { t: "Bricks", w: "2.277 × 434 = 988 bricks (before wastage)" },
              ],
              ans: "About 990 bricks, plus whatever wastage allowance the estimate states. Deduct openings before multiplying — and add back the lintel bearings if the lintel is measured separately." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "bc-4",
      n: 4,
      title: "Load-Bearing Masonry Design",
      hi: "लोड बेयरिंग चिनाई डिज़ाइन",
      blurb: "How a wall actually carries its load, the two ways it can fail, and why slenderness and eccentric load are the things the design controls.",
      mins: 34,
      sections: [
        {
          n: "4.1",
          title: "Two ways a wall fails",
          hi: "दीवार दो तरह से टूटती है",
          blocks: [
            { k: "p", t: "In load-bearing construction the walls are the structure, so it matters exactly how they carry load and how they fail. A masonry wall can fail in two entirely different ways, and good design is about knowing which threat governs a given wall." },
            { k: "dia", id: "hb-bc-slender", cap: "Crushing versus buckling, and the slenderness ratio between them." },
            { k: "def", term: "Crushing", t: "A material failure: the compressive stress simply exceeds what the masonry can bear, and it spalls and crushes. This governs short, thick, stocky walls, where stability is not in question and only strength matters." },
            { k: "def", term: "Buckling", t: "A stability failure: a tall, thin wall bows out sideways and fails long before the masonry is crushed. This governs slender walls, and it is far more dangerous because it can happen at a stress well below the material's strength — the wall was never overloaded, it simply lost its footing." },
          ],
        },
        {
          n: "4.2",
          title: "Slenderness and eccentricity",
          hi: "तनुता और उत्केंद्रता",
          blocks: [
            { k: "p", t: "Two things decide how much load a wall can safely carry: how slender it is, and how centrally the load sits on it. Both are captured in the design as reduction factors on the basic material strength." },
            { k: "def", term: "Slenderness ratio", t: "The effective height of the wall divided by its effective thickness. The higher it is, the more buckling governs and the more the safe load is reduced. The effective height depends on how the wall is restrained top and bottom (a floor slab framing into it shortens the effective height and helps)." },
            { k: "eg", title: "Example 4.1 — Slenderness of a storey-height wall",
              given: "A 200 mm thick wall spans a storey height of 3.0 m, restrained by floor slabs top and bottom (effective height ≈ 0.75 × actual). Find the slenderness ratio.",
              steps: [
                { t: "Effective height", w: "restrained both ends → 0.75 × 3.0 = 2.25 m" },
                { t: "Slenderness ratio", w: "= effective height / thickness\n= 2.25 / 0.20 = 11.25" },
              ],
              ans: "A slenderness ratio of about 11 — moderate, comfortably within the IS 1905 limit of 27 for walls in cement mortar. The floor slabs restraining the wall top and bottom are what keep it low; an unrestrained free-standing wall of the same height would be far more slender and carry much less." },
            { k: "def", term: "Eccentricity", t: "How far off-centre the load sits on the wall. A slab bearing on one edge of a wall, rather than centrally, pushes the load to one side — which bends the wall and dramatically worsens buckling. Central load is best; the design penalises eccentric load with a further reduction." },
            { k: "trap", t: "The dangerous combination is a slender wall carrying an eccentric load — a tall thin wall with a slab bearing on one edge. Slenderness invites buckling, eccentricity bends the wall the way it wants to buckle, and the two together can drop the safe load to a fraction of the wall's material strength. Load-bearing walls are kept as central and as restrained as the plan allows for exactly this reason." },
          ],
        },
        {
          n: "4.3",
          title: "Permissible stress by IS 1905",
          hi: "IS 1905 से अनुमेय प्रतिबल",
          blocks: [
            { k: "p", t: "IS 1905 turns those ideas into arithmetic. Start from a <strong>basic compressive stress</strong> that depends on the strength of the unit and the grade of the mortar (Table 8 of the code), then multiply by factors for slenderness and eccentricity, for small cross-sections, and for the shape of the unit:" },
            { k: "eq", expr: "permissible stress  fp = Ks × Ka × Kp × fb", where: [
              ["fb", "basic compressive stress (IS 1905 Table 8)"],
              ["Ks", "stress reduction factor for slenderness ratio and eccentricity (Table 9)"],
              ["Ka", "area reduction factor = 0.7 + 1.5A for a cross-section A < 0.2 m², otherwise 1.0"],
              ["Kp", "shape modification factor for the unit's height-to-width ratio (Table 10)"],
            ]},
            { k: "list", items: [
              "<strong>Effective height</strong> — 0.75H for a wall restrained in position and direction at top and bottom (RC floor slabs), 0.85H with full restraint at one end only, H where it is held in position but free to rotate at both ends.",
              "<strong>Slenderness limit</strong> — 27 for walls in cement mortar.",
              "<strong>Ks</strong> falls steadily with slenderness: for an axial load it is 0.56 at a slenderness ratio of 22 and 0.51 at 24.",
            ]},
            { k: "eg", title: "Example 4.2 — Is a 100 mm wall safe?",
              given: "Two-storey building, storey height 3.0 m, 100 mm brick wall in M1 mortar with units of 10 N/mm² (fb = 0.96 N/mm²). Slab load on the wall 10.66 kN/m² over a 2.65 m width; masonry 20 kN/m³. Units 200 × 100 × 90 mm (Kp = 1.06). Check the ground-storey wall per metre run.",
              steps: [
                { t: "Load per metre", w: "slabs: 10.66 × 2.65 = 28.25 kN\nwall self-weight, two storeys: 2 × 0.1 × 3.0 × 20 = 12.0 kN\ntotal = 40.25 kN/m" },
                { t: "Actual stress", w: "40.25 × 10³/(100 × 1000) = 0.40 N/mm²" },
                { t: "Slenderness", w: "he = 0.75 × 3.0 = 2.25 m;  SR = 2250/100 = 22.5  (< 27 ✓)\nKs ≈ 0.55 (between 0.56 at 22 and 0.51 at 24)" },
                { t: "Area factor", w: "A = 0.1 × 1.0 = 0.1 m² < 0.2  →  Ka = 0.7 + 1.5 × 0.1 = 0.85" },
                { t: "Permissible stress", w: "fp = 0.55 × 0.85 × 1.06 × 0.96 = 0.476 N/mm²" },
              ],
              ans: "0.40 < 0.48 N/mm² — safe, but only just; the slenderness factor alone has removed 45% of the basic stress. A 200 mm wall (SR 11.25) would have a far larger margin." },
            { k: "note", t: "Factors, the 0.96 N/mm² basic stress, the slenderness limit of 27 and this example (re-run here; the source multiplies 10.66 × 2.65 as 28.36, which should be 28.25 — the conclusion is unchanged) are from <a href=\"https://sist.sathyabama.ac.in/sist_coursematerial/uploads/SCI1211.pdf\" target=\"_blank\" rel=\"noopener\">Sathyabama SCI1211 masonry design notes</a>, which follows IS 1905:1987. Confirm table values against the current edition of IS 1905 before design use." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "bc-5",
      n: 5,
      title: "Plastering and Finishes",
      hi: "प्लास्टर और फिनिशिंग",
      blurb: "The coats that give a wall its skin, why plaster is meant to be renewed, and the finishes that protect and decorate it.",
      mins: 26,
      sections: [
        {
          n: "5.1",
          title: "Plaster — the sacrificial skin",
          hi: "प्लास्टर — बलिदानी परत",
          blocks: [
            { k: "p", t: "Plaster is a thin cement or lime mortar coat over masonry that gives a smooth, even surface, hides the joints, and — most importantly — takes the weathering and wear so the wall behind it does not. It is meant to be renewed over the building's life; it is the skin, not the structure." },
            { k: "def", term: "Plaster coats", t: "Plaster is applied in one, two or three coats depending on the finish wanted. The first (rendering) coat evens the surface and provides grip; the second (floating) coat brings it true; the final (setting) coat gives the smooth finish. External work usually gets more coats than internal." },
            { k: "list", items: [
              "<strong>Right thickness</strong> — IS 1661 (as summarised by <a href=\"https://www.jkcement.com/blog/basics-of-cement/what-is-plastering-thickness/\" target=\"_blank\" rel=\"noopener\">JK Cement's summary of IS 1661</a>): single-coat work 10–15 mm; two-coat work not more than 20 mm in all (backing 10–12 mm, finish 3–8 mm); three-coat work not more than 25 mm; on concrete soffits not more than 15 mm. Too thick and it sags and cracks off; too thin and it does not cover.",
              "<strong>Grip</strong> — the surface is roughened (raked joints, a spatterdash coat) so the plaster keys to it.",
              "<strong>Cured</strong> — the base coat kept damp for at least seven days (same source), or it dries before it hydrates and dusts off.",
              "<strong>Right mix</strong> — rich enough to be durable, lean enough not to shrink and crack.",
            ] },
            { k: "eg", title: "Example 5.1 — Materials for plastering 100 m²",
              given: "12 mm thick cement plaster, 1:6, on 100 m² of brick wall. Dry-volume factor 1.3 (as Example 2.1); cement 1440 kg/m³, 50 kg bags.",
              steps: [
                { t: "Wet volume", w: "100 × 0.012 = 1.20 m³" },
                { t: "Dry volume", w: "1.20 × 1.3 = 1.56 m³" },
                { t: "Cement and sand (1 + 6 = 7 parts)", w: "cement = 1.56/7 = 0.223 m³ × 1440 = 321 kg = 6.4 bags\nsand = 1.56 × 6/7 = 1.34 m³" },
              ],
              ans: "About 6.4 bags of cement and 1.34 m³ of sand per 100 m², before any allowance for filling joints, uneven backgrounds and wastage — which on rough brickwork can be substantial; state the allowance on the estimate." },
            { k: "trap", t: "Plaster cracking and falling off is very often the plaster doing its job — absorbing the movement and weathering that would otherwise have attacked the wall — but it is also caused by the avoidable errors: too thick a coat, a too-rich (over-shrinking) mix, plastering onto a smooth un-keyed surface, or no curing. The first is expected maintenance; the rest are workmanship failures." },
          ],
        },
        {
          n: "5.2",
          title: "Finishes — protect, then decorate",
          hi: "फिनिश",
          blocks: [
            { k: "p", t: "Over the plaster go the finishes — paint, tiles, cladding, waterproofing — each answering a service demand rather than a structural one. They protect the surface and give it its final appearance, and they are chosen and renewed on a maintenance cycle." },
            { k: "cmp", t: "What a finish is for",
              cols: ["Its job", "Where / when"],
              rows: [
                ["Paint / distemper", "decoration + a sheddable protective coat", "renewed every few years"],
                ["Tiles / cladding", "hard, cleanable, water-resistant skin", "wet areas, floors, facades"],
                ["Waterproofing", "keeps water out of roofs, wet areas, basements", "the highest-value durability spend"],
                ["Pointing", "finishes exposed masonry joints", "where the brick itself is meant to show"],
              ] },
            { k: "real", t: "Waterproofing of the roof and wet areas is the finish that repays its cost many times over, because water is the root of most building decay — rising damp, leaking roofs, saturated walls, corroding reinforcement all trace back to water getting in. <strong>Money spent keeping water out is the cheapest durability money on the whole building</strong>, and the first place a leaking building should be examined." },
          ],
        },
      ],
    },

  );
})();
