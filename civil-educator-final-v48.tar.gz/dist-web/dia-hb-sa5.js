/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: Structural Analysis handbook, Ch. 8–9
   Moment distribution · Arches and cables
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 8.1 LOCK AND RELEASE */
  "hb-sa-md-cycle": {
    label: "One cycle of moment distribution",
    svg: `<svg viewBox="0 0 736 300" role="img" aria-label="Four stages: all joints locked so fixed end moments appear, one joint released showing the out of balance moment, the out of balance shared between the members in proportion to stiffness, and half of each share carried over to the far end">
      ${hbmk("mc")}
      <text class="em" x="90" y="28" text-anchor="middle">1 · LOCK</text>
      <line class="s" x1="24" y1="96" x2="156" y2="96"/>
      <line class="s" x1="90" y1="96" x2="90" y2="60"/>
      <rect class="soft-b" x="78" y="84" width="24" height="24" rx="4"/>
      <text class="lb" x="90" y="146" text-anchor="middle">every joint clamped</text>
      <text class="lb" x="90" y="164" text-anchor="middle">→ fixed end moments</text>

      <line class="gl" x1="186" y1="16" x2="186" y2="220"/>

      <text class="em" x="276" y="28" text-anchor="middle">2 · RELEASE ONE</text>
      <line class="s" x1="210" y1="96" x2="342" y2="96"/>
      <line class="s" x1="276" y1="96" x2="276" y2="60"/>
      <circle class="acf" cx="276" cy="96" r="6"/>
      <path class="hi" d="M254 76 A28 28 0 0 1 298 76" marker-end="url(#mc-m)"/>
      <text class="em" x="276" y="52" text-anchor="middle">out of balance</text>
      <text class="lb" x="276" y="146" text-anchor="middle">the clamp is taken off,</text>
      <text class="lb" x="276" y="164" text-anchor="middle">so the joint must rotate</text>

      <line class="gl" x1="372" y1="16" x2="372" y2="220"/>

      <text class="em" x="462" y="28" text-anchor="middle">3 · DISTRIBUTE</text>
      <line class="s" x1="396" y1="96" x2="528" y2="96"/>
      <line class="s" x1="462" y1="96" x2="462" y2="60"/>
      <circle class="acf" cx="462" cy="96" r="6"/>
      <line class="hi" x1="452" y1="112" x2="410" y2="112" marker-end="url(#mc-m)"/>
      <line class="hi" x1="472" y1="112" x2="514" y2="112" marker-end="url(#mc-m)"/>
      <line class="hi" x1="476" y1="82" x2="476" y2="60" marker-end="url(#mc-m)"/>
      <text class="lb" x="462" y="146" text-anchor="middle">shared in proportion</text>
      <text class="lb" x="462" y="164" text-anchor="middle">to member stiffness</text>

      <line class="gl" x1="558" y1="16" x2="558" y2="220"/>

      <text class="em" x="648" y="28" text-anchor="middle">4 · CARRY OVER</text>
      <line class="s" x1="582" y1="96" x2="714" y2="96"/>
      <circle class="acf" cx="648" cy="96" r="6"/>
      <line class="hi" x1="630" y1="112" x2="594" y2="112" marker-end="url(#mc-m)"/>
      <text class="em" x="594" y="132" text-anchor="middle">½</text>
      <line class="hi" x1="666" y1="112" x2="702" y2="112" marker-end="url(#mc-m)"/>
      <text class="em" x="702" y="132" text-anchor="middle">½</text>
      <text class="lb" x="648" y="146" text-anchor="middle">half of each share goes</text>
      <text class="lb" x="648" y="164" text-anchor="middle">to the far end, if fixed</text>

      <line class="gl" x1="20" y1="196" x2="700" y2="196"/>
      <text class="em" x="360" y="226" text-anchor="middle">Then lock it again, move to the next joint, and repeat.</text>
      <text class="lb" x="360" y="254" text-anchor="middle">Each cycle the out-of-balance moments get smaller, because only half of each</text>
      <text class="lb" x="360" y="274" text-anchor="middle">correction travels onward. Three or four cycles is usually enough to stop.</text>
    </svg>`,
    caption: "No simultaneous equations anywhere. <strong>The method converges because the carry-over is only a half</strong> — each round of corrections is smaller than the one before, so the numbers settle instead of wandering.",
  },

  /* ---------------------------------------- 8.2 STIFFNESS */
  "hb-sa-md-stiff": {
    label: "Why a pinned far end gives 3EI/L instead of 4EI/L",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="Left, a member with its far end fixed needs a moment of four EI over L for unit rotation and carries half of it over. Right, the same member with a pinned far end needs only three EI over L and carries nothing over.">
      ${hbmk("ms")}
      <text class="em" x="168" y="28" text-anchor="middle">FAR END FIXED</text>
      <line class="thin dash" x1="60" y1="130" x2="280" y2="130"/>
      <path class="s" d="M60 130 Q160 96 280 130"/>
      <line class="s" x1="280" y1="108" x2="280" y2="152"/>
      ${grd(280, 152, 22)}
      <path class="hi" d="M42 112 A24 24 0 0 1 64 104" marker-start="url(#ms-m)"/>
      <text class="em" x="40" y="100" text-anchor="end">4EI/L</text>
      <path class="ac" d="M60 130 L128 112"/>
      <text class="ea" x="104" y="150">θ = 1</text>
      <path class="hi" d="M296 112 A24 24 0 0 1 318 104" marker-start="url(#ms-m)"/>
      <text class="em" x="322" y="104">2EI/L</text>
      <text class="lb" x="168" y="196" text-anchor="middle">the far end resists too, so more</text>
      <text class="lb" x="168" y="214" text-anchor="middle">moment is needed at the near end</text>
      <text class="em" x="168" y="244" text-anchor="middle">carry-over = + ½</text>

      <line class="gl" x1="350" y1="16" x2="350" y2="266"/>

      <text class="em" x="528" y="28" text-anchor="middle">FAR END PINNED</text>
      <line class="thin dash" x1="420" y1="130" x2="640" y2="130"/>
      <path class="s" d="M420 130 Q520 104 640 130"/>
      <path class="s" d="M640 130 L628 150 L652 150 Z"/>
      ${grd(620, 150, 40)}
      <path class="hi" d="M402 112 A24 24 0 0 1 424 104" marker-start="url(#ms-m)"/>
      <text class="em" x="400" y="100" text-anchor="end">3EI/L</text>
      <path class="ac" d="M420 130 L488 112"/>
      <text class="ea" x="464" y="150">θ = 1</text>
      <circle class="acf" cx="640" cy="130" r="5"/>
      <text class="lb" x="528" y="196" text-anchor="middle">the far end simply rotates freely,</text>
      <text class="lb" x="528" y="214" text-anchor="middle">so it offers no help</text>
      <text class="em" x="528" y="244" text-anchor="middle">carry-over = 0</text>
    </svg>`,
    caption: "Using 3EI/L for a member whose far end is pinned takes that end <strong>out of the iteration entirely</strong> — no carry-over ever reaches it. On a continuous beam with simple end supports this often collapses the whole problem to a single balancing step.",
  },

  /* ---------------------------------------- 9.1 ARCH vs BEAM */
  "hb-sa-arch-thrust": {
    label: "How horizontal thrust reduces the bending moment in an arch",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="Above, a simply supported beam under uniform load with its parabolic bending moment diagram. Below, an arch of the same span and load, where the horizontal thrust times the arch height cancels the beam moment.">
      ${hbmk("at")}
      <text class="em" x="170" y="26" text-anchor="middle">BEAM — no thrust</text>
      <line class="s" x1="50" y1="74" x2="290" y2="74"/>
      ${[0,1,2,3,4,5,6].map(i=>`<line class="ac" x1="${54+i*39}" y1="48" x2="${54+i*39}" y2="68" marker-end="url(#at-c)"/>`).join("")}
      <path class="s" d="M50 74 L38 94 L62 94 Z"/><circle class="s" cx="284" cy="86" r="9"/>
      <line class="s" x1="50" y1="150" x2="290" y2="150"/>
      <path class="soft" d="M50 150 Q170 230 290 150 Z"/>
      <path class="hi" d="M50 150 Q170 230 290 150"/>
      <text class="em" x="170" y="252" text-anchor="middle">M = wL²/8</text>
      <text class="lb" x="170" y="274" text-anchor="middle">all of it carried in bending</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="320"/>

      <text class="em" x="524" y="26" text-anchor="middle">ARCH — thrust at the springings</text>
      ${[0,1,2,3,4,5,6].map(i=>`<line class="ac" x1="${408+i*39}" y1="42" x2="${408+i*39}" y2="62" marker-end="url(#at-c)"/>`).join("")}
      <path class="s" d="M404 150 Q524 56 644 150"/>
      <path class="s" d="M404 150 L392 170 L416 170 Z"/>
      <path class="s" d="M644 150 L632 170 L656 170 Z"/>
      ${grd(384, 170, 40)} ${grd(624, 170, 40)}
      <line class="hi" x1="368" y1="150" x2="410" y2="150" marker-start="url(#at-m)"/>
      <text class="em" x="366" y="142" text-anchor="end">H</text>
      <line class="hi" x1="680" y1="150" x2="638" y2="150" marker-start="url(#at-m)"/>
      <text class="em" x="684" y="142">H</text>
      <line class="thin dash" x1="524" y1="86" x2="524" y2="150"/>
      <line class="thin" x1="500" y1="86" x2="500" y2="150" marker-start="url(#at-a)" marker-end="url(#at-a)"/>
      <text class="lb" x="490" y="122" text-anchor="end">y</text>
      <text class="em" x="524" y="212" text-anchor="middle">M(arch) = M(beam) − H·y</text>
      <text class="lb" x="524" y="244" text-anchor="middle">for a parabola under a full-span UDL</text>
      <text class="em" x="524" y="270" text-anchor="middle">H·y cancels M(beam) exactly → M = 0</text>
      <text class="lb" x="524" y="296" text-anchor="middle">the arch works in pure compression</text>
      <text class="lb" x="350" y="330" text-anchor="middle">Flatter arch → smaller y → larger H. The abutments have to take it.</text>
    </svg>`,
    caption: "An arch is not a curved beam — it is a different mechanism. <strong>The thrust H does the work that bending would otherwise have to do</strong>, and the price is a horizontal force at the foundation that a beam never produces.",
  },

  /* ---------------------------------------- 9.6 ARCH TYPES */
  "hb-sa-arch-types": {
    label: "Three-hinged, two-hinged and fixed arches",
    svg: `<svg viewBox="0 0 700 260" role="img" aria-label="Three arches side by side: three hinged with hinges at both springings and the crown and Ds equal to zero, two hinged with Ds equal to one, and fixed with Ds equal to three, each with a note on its sensitivity to temperature and settlement">
      ${hbmk("ay")}
      <text class="em" x="116" y="28" text-anchor="middle">THREE-HINGED</text>
      <path class="s" d="M36 140 Q116 68 196 140"/>
      <path class="s" d="M36 140 L26 158 L46 158 Z"/><path class="s" d="M196 140 L186 158 L206 158 Z"/>
      ${grd(18, 158, 36)} ${grd(178, 158, 36)}
      <circle class="acf" cx="116" cy="82" r="6"/>
      <circle class="acf" cx="36" cy="140" r="5"/><circle class="acf" cx="196" cy="140" r="5"/>
      <text class="em" x="116" y="186" text-anchor="middle">Ds = 0</text>
      <text class="lb" x="116" y="210" text-anchor="middle">determinate</text>
      <text class="lb" x="116" y="230" text-anchor="middle">temperature and settlement</text>
      <text class="lb" x="116" y="248" text-anchor="middle">cause NO stress</text>

      <line class="gl" x1="236" y1="16" x2="236" y2="252"/>

      <text class="em" x="350" y="28" text-anchor="middle">TWO-HINGED</text>
      <path class="s" d="M270 140 Q350 68 430 140"/>
      <path class="s" d="M270 140 L260 158 L280 158 Z"/><path class="s" d="M430 140 L420 158 L440 158 Z"/>
      ${grd(252, 158, 36)} ${grd(412, 158, 36)}
      <circle class="acf" cx="270" cy="140" r="5"/><circle class="acf" cx="430" cy="140" r="5"/>
      <text class="em" x="350" y="186" text-anchor="middle">Ds = 1</text>
      <text class="lb" x="350" y="210" text-anchor="middle">stiffer, less material</text>
      <text class="lb" x="350" y="230" text-anchor="middle">temperature and settlement</text>
      <text class="lb" x="350" y="248" text-anchor="middle">DO cause stress</text>

      <line class="gl" x1="470" y1="16" x2="470" y2="252"/>

      <text class="em" x="584" y="28" text-anchor="middle">FIXED</text>
      <path class="s" d="M504 140 Q584 68 664 140"/>
      <line class="s" x1="486" y1="140" x2="522" y2="140"/>
      <line class="s" x1="646" y1="140" x2="682" y2="140"/>
      ${grd(486, 140, 36)} ${grd(646, 140, 36)}
      <text class="em" x="584" y="186" text-anchor="middle">Ds = 3</text>
      <text class="lb" x="584" y="210" text-anchor="middle">stiffest, least material</text>
      <text class="lb" x="584" y="230" text-anchor="middle">most sensitive of all —</text>
      <text class="lb" x="584" y="248" text-anchor="middle">needs sound foundations</text>
    </svg>`,
    caption: "The trade is always the same. <strong>More restraint means less material and more sensitivity</strong> — a fixed arch is the most economical in steel or concrete and the least forgiving of a foundation that moves. On poor ground the three-hinged form is often the right engineering answer even though it uses more material.",
  },

  /* ---------------------------------------- 9.7 CABLE */
  "hb-sa-cable": {
    label: "A cable under uniform load: horizontal pull, sag and maximum tension",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A cable hanging between two level supports under a uniformly distributed load, with the sag marked, the horizontal component constant along the cable, and the tension greatest at the supports where the slope is steepest">
      ${hbmk("cy")}
      <line class="thin dash" x1="90" y1="70" x2="610" y2="70"/>
      <path class="hi" d="M90 70 Q350 250 610 70"/>
      ${[0,1,2,3,4,5,6,7,8,9,10,11,12].map(i=>{const x=90+i*40;const t=(x-90)/520;const y=70+4*160*t*(1-t);return `<line class="ac" x1="${x}" y1="${y+6}" x2="${x}" y2="${y+34}" marker-end="url(#cy-c)"/>`;}).join("")}
      <text class="ea" x="350" y="210" text-anchor="middle">w per metre of span</text>
      <line class="s" x1="74" y1="46" x2="106" y2="46"/>
      <line class="s" x1="594" y1="46" x2="626" y2="46"/>
      <line class="s" x1="90" y1="46" x2="90" y2="70"/>
      <line class="s" x1="610" y1="46" x2="610" y2="70"/>
      <line class="thin" x1="350" y1="70" x2="350" y2="150" marker-start="url(#cy-a)" marker-end="url(#cy-a)"/>
      <text class="em" x="362" y="116">h  sag</text>
      <line class="thin" x1="90" y1="34" x2="610" y2="34" marker-start="url(#cy-a)" marker-end="url(#cy-a)"/>
      <text class="lb" x="350" y="28" text-anchor="middle">L</text>

      <line class="hi" x1="350" y1="150" x2="410" y2="150" marker-end="url(#cy-m)"/>
      <text class="em" x="420" y="154">H — same everywhere</text>

      <line class="hi" x1="90" y1="70" x2="126" y2="106" marker-start="url(#cy-m)"/>
      <text class="em" x="132" y="112">T(max)</text>
      <path class="thin dash" d="M90 70 L150 70"/>
      <path class="thin" d="M126 70 A36 36 0 0 0 120 90"/>
      <text class="lb" x="140" y="88">θ</text>

      <line class="gl" x1="40" y1="238" x2="660" y2="238"/>
      <text class="em" x="350" y="266" text-anchor="middle">H = wL² / 8h        V(support) = wL/2        T(max) = √(H² + V²)</text>
      <text class="lb" x="350" y="296" text-anchor="middle">A cable has no bending stiffness, so it takes the funicular shape of whatever load it carries:</text>
      <text class="lb" x="350" y="314" text-anchor="middle">a parabola under a uniform load along the span, a catenary under its own weight.</text>
    </svg>`,
    caption: "The horizontal component is constant along the whole cable — nothing acts horizontally between the supports to change it. So <strong>the tension is greatest where the cable is steepest</strong>, which is at the supports, and a flatter cable (smaller sag) needs a much larger H.",
  },

});
