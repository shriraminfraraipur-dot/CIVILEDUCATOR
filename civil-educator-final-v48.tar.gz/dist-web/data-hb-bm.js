/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING MATERIALS
   ------------------------------------------------------------
   The sixth handbook, and the most physical of them: this one
   is about the stuff itself — stone, brick, cement, timber,
   steel — what each is, how it is tested, and how you tell a
   good one from a bad one standing on a site.

   One habit runs through every chapter: a material is judged
   against three demands at once — strength, durability and
   economy — and no material wins on all three. The engineering
   is the choice.

   Standards are named where they govern (IS 1077 for bricks,
   IS 269/8112/12269 for cements, IS 383 for aggregate, IS 1121
   for stone). Confirm any value against the published standard
   before using it on real work.

   Chapters 1–2 here; later chapters follow in data-hb-bm2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "bm",
  subject: "building-materials",
  name: "Building Materials",
  hi: "भवन निर्माण सामग्री",
  icon: "🧱",
  blurb: "Har material kya hai, kaise banta hai, kaise test hota hai, aur site par achhe-bure me farq kaise karein — ek shelf par poora material store.",
  note: "Test values and limits here are the standard ones (IS 1077, IS 269, IS 383 and the rest, named where they apply). They are quoted for learning; confirm against the current published standard before using a value on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "bm-1",
      n: 1,
      title: "What Makes a Material Fit to Build With",
      hi: "सामग्री कब निर्माण योग्य होती है",
      blurb: "The three demands every material is judged against, and why the whole subject is a series of trade-offs rather than a search for the best material.",
      mins: 20,
      sections: [
        {
          n: "1.1",
          title: "There is no best material",
          hi: "कोई सर्वश्रेष्ठ सामग्री नहीं होती",
          blocks: [
            { k: "p", t: "A beginner looks for the strongest material, or the cheapest, or the one that lasts longest, and expects one answer. There isn't one. Steel is enormously strong but rusts and is expensive; granite lasts for centuries but is heavy and dear; mud is almost free but weak and washes away. Each is the right answer to a different question." },
            { k: "p", t: "So the subject is not a ranking. It is a shelf of materials, each with a profile of what it is good and bad at, and the skill is matching a material to a job. That is why an engineer on site can say why brick and not stone for this wall, why this cement and not that one for this pour — not from memory of a league table, but from understanding what each material offers." },
            { k: "cmp", t: "The same wall, three materials",
              cols: ["Burnt-clay brick", "Stone"],
              rows: [
                ["Strength", "adequate (3.5–10 N/mm²)", "very high"],
                ["Durability", "good if well burnt", "excellent"],
                ["Cost & labour", "low, fast to lay", "high, slow, skilled"],
                ["Where it wins", "ordinary walls, everywhere", "plinths, facing, heavy load"],
              ] },
            { k: "note", t: "The comparison block above is the shape of the whole handbook: every material gets measured against the same demands, so you can put any two side by side and say which fits the job." },
          ],
        },
        {
          n: "1.2",
          title: "The three demands",
          hi: "तीन माँगें",
          blocks: [
            { k: "p", t: "Every material a civil engineer places has to answer three questions at once. They pull against each other, which is what makes selection an engineering decision rather than a lookup." },
            { k: "def", term: "Strength", t: "The load the material can carry before it fails — in compression, tension, shear or bending. Different materials are strong in different directions: brick and stone in compression, steel in both, timber along its grain." },
            { k: "def", term: "Durability", t: "How long it survives its environment — water, frost, heat, chemicals, sun, insects — without losing that strength. A material is only as good as its behaviour on the worst day of its service life, not the day it was placed." },
            { k: "def", term: "Economy", t: "Not just price. Availability nearby, the labour and skill to work it, the speed of placing, and the cost of maintaining it afterwards. A cheap material that needs constant repair is not economical." },
            { k: "dia", id: "hb-bm-demands", cap: "A material sits at the centre of three competing demands." },
            { k: "real", t: "A coastal building shows all three fighting. Salt air rusts steel and attacks ordinary cement, so durability pushes you toward stone or special cement; economy pushes back toward cheap local brick; strength sets a floor under both. <strong>The final choice is a negotiated settlement between the three</strong>, and a good engineer can name the reasoning." },
          ],
        },
        {
          n: "1.3",
          title: "Properties you will keep meeting",
          hi: "बार-बार मिलने वाले गुण",
          blocks: [
            { k: "p", t: "A handful of physical properties come up for every material, so it is worth fixing them once here rather than redefining them in each chapter." },
            { k: "list", items: [
              "<strong>Density / unit weight</strong> — mass per volume. Decides self-weight, which for large structures is the biggest load of all.",
              "<strong>Porosity & water absorption</strong> — how much void space, and how much water it drinks. Predicts frost damage, staining, and how much water a brick steals from mortar.",
              "<strong>Durability indices</strong> — resistance to weathering, chemical attack, abrasion and fire.",
              "<strong>Thermal & acoustic behaviour</strong> — how it conducts heat and sound, which decides comfort and services, not structure.",
              "<strong>Workability</strong> — how easily it is cut, shaped, laid or finished. A material impossible to work economically is not used however good it is on paper.",
            ] },
            { k: "trap", t: "Water absorption is the quiet predictor. A material that drinks water freely is usually the one that fails first — it cracks when the water freezes, it stains as salts move through it, and it weakens mortar by robbing it of the water it needed to cure. When two materials look equal, the drier one usually wins." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "bm-2",
      n: 2,
      title: "Stone",
      hi: "पत्थर",
      blurb: "Where a building stone comes from, why its origin predicts how it behaves, and the tests that decide whether a stone is fit to build with.",
      mins: 22,
      sections: [
        {
          n: "2.1",
          title: "Classified by origin — the one that matters",
          hi: "उत्पत्ति के आधार पर वर्गीकरण",
          blocks: [
            { k: "p", t: "Stone is classified three ways — by origin, by chemical composition and by physical structure — but origin is the one to learn first, because it predicts the other two and it predicts behaviour on the wall." },
            { k: "dia", id: "hb-bm-rocks", cap: "The same rock, seen through three classifications." },
            { k: "def", term: "Igneous rock", t: "Cooled from molten rock as one solid mass — granite, basalt, trap. Dense, hard, no natural planes of weakness, very durable. Granite is the premier facing and load-bearing stone." },
            { k: "def", term: "Sedimentary rock", t: "Laid down in beds over ages — sandstone, limestone. Softer, easier to cut, but splits along its bedding planes, so it must be laid the way it sat in the ground." },
            { k: "def", term: "Metamorphic rock", t: "Old rock re-cooked under heat and pressure — marble (from limestone), slate (from shale), quartzite (from sandstone). Recrystallised, often banded or foliated, which can be a plane of weakness (slate splits into roofing sheets precisely because of it)." },
          ],
        },
        {
          n: "2.2",
          title: "Laying stone the right way",
          hi: "पत्थर सही दिशा में लगाना",
          blocks: [
            { k: "p", t: "The most common failure of stonework is not weak stone — it is good stone laid the wrong way. A bedded (sedimentary) stone is strong across its beds and weak along them. In the quarry the beds lie horizontal; in the wall they must stay horizontal, so the load presses across the beds, not along them." },
            { k: "def", term: "Natural bed", t: "The plane along which a sedimentary stone was originally deposited. The rule is simple: the natural bed should lie perpendicular to the direction of load — i.e. horizontal in an ordinary wall, so the weight presses across the beds." },
            { k: "trap", t: "Lay a bedded stone face-bedded (beds vertical, parallel to the wall face) and the exposed face flakes off sheet by sheet within a few winters as water gets into the beds and freezes. The stone is fine; the orientation killed it." },
            { k: "real", t: "In an arch the load direction curves, so the beds must curve with it — each voussoir is cut so its natural bed is radial, perpendicular to the thrust. This is why arch stones are cut individually and cannot simply be sawn from a slab." },
          ],
        },
        {
          n: "2.3",
          title: "Is this stone fit to build with?",
          hi: "क्या यह पत्थर उपयुक्त है",
          blocks: [
            { k: "p", t: "A stone is judged by a short list of qualities and a matching set of tests. You rarely run all of them; you run the one that answers the worry you have." },
            { k: "cmp", t: "Each quality has a test that answers it",
              cols: ["How it is checked", "Why it matters"], rows: [
              ["Strength", "crushing test on cubes (IS 1121)", "load-bearing walls, piers"],
              ["Low absorption", "24-hour water absorption", "frost resistance, staining"],
              ["Hardness", "abrasion test (floors, paving)", "wear underfoot"],
              ["Weathering", "acid / crystallisation test", "resists acid rain, salts"],
              ["Soundness", "tap it — a ringing note is sound", "hidden cracks, flaws"],
            ] },
            { k: "p", t: "The acid test is the one that separates the two big chemical families. A calcareous stone — limestone, marble — is calcium carbonate, and dilute acid attacks it (it fizzes). A siliceous stone — granite, sandstone bound with silica — shrugs acid off. In a city with acidic rain, that single fact steers you away from marble for exposed work." },
            { k: "eg", title: "Reading a simple stone report",
              given: "A sandstone sample: crushing strength 65 N/mm², water absorption 4%, no reaction with dilute acid, rings when tapped.",
              steps: [
                { t: "Strength — is it enough?", w: "65 N/mm² vs ~35 wanted for good building stone\n→ comfortable, fine for load-bearing" },
                { t: "Absorption — will it survive frost?", w: "4% vs 5% ceiling for a durable stone\n→ passes, will resist frost" },
                { t: "Chemistry — acid rain a threat?", w: "no reaction with dilute acid → siliceous\n→ acid rain does not attack it" },
                { t: "Soundness — hidden flaws?", w: "rings when tapped → no internal shakes or cracks" },
              ],
              ans: "A good, durable building stone — fit for exposed load-bearing work. Every figure was checked against what 'good' means, not taken on faith." },
            { k: "note", t: "Numbers like the 35 N/mm² and 5% above are the customary marks of a good stone, not clause values you can quote as law. IS 1121 gives the test method; the acceptance figure belongs to the project specification." },
          ],
        },
      ],
    },

  ],
});
