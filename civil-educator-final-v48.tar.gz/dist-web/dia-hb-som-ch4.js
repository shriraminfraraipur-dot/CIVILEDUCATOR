/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 4.
   Conventions as in dia-hb-som-ch1.js. Stress diagrams are drawn
   to scale for Worked examples 4.1, 4.5 and 4.6.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 4.1  BENDING STRESS */
  "hb-som-bendstress": {
    label: "Linear bending-stress distribution across the T-section (Worked example 4.1, to scale)",
    svg: `<svg viewBox="0 0 640 340" role="img" aria-label="Left: the T-section from Chapter 3, 200 millimetres deep, with its neutral axis 64.55 below the top. Right: the bending stress diagram for a sagging moment of 16 kilonewton metres. Stress varies linearly with distance from the neutral axis: zero at the neutral axis, 39.4 newtons per square millimetre compression at the top of the flange, and 82.8 tension at the bottom of the web. The larger stress is at the fibre farther from the neutral axis.">
      <!-- section: scale 1.3 px/mm, top y=40 -->
      <rect class="conc" x="62" y="40" width="195" height="26"/>
      <rect class="conc" x="146.5" y="66" width="26" height="234"/>
      <line class="ac" x1="40" y1="124" x2="600" y2="124" style="stroke-dasharray:8 5"/>
      <text class="ea" x="40" y="116">N.A.</text>
      <text class="lb" x="270" y="86">y_top = 64.55</text>
      <text class="lb" x="180" y="220">y_bot = 135.45</text>
      <!-- stress diagram: baseline x=420, 2 px per N/mm² -->
      <line class="s" x1="420" y1="30" x2="420" y2="310"/>
      <path class="soft-b" d="M420 40 L341 40 L420 124 Z"/>
      <path class="soft-b" d="M420 124 L585 300 L420 300 Z" style="fill:var(--accent)"/>
      <line class="hi" x1="341" y1="40" x2="585" y2="300"/>
      <text class="em" x="336" y="34" text-anchor="end">39.4 (C)</text>
      <text class="ea" x="590" y="316" text-anchor="end">82.8 (T)</text>
      <text class="lb" x="428" y="140">f = 0</text>
      <text class="lb" x="500" y="60">f = M·y / I</text>
      <text class="lb" x="500" y="76">M = 16 kN·m (sagging)</text>
    </svg>`,
    caption: "Stress grows linearly from zero at the neutral axis. Because the bottom fibre is about twice as far from the N.A. as the top, it carries about twice the stress — design is governed by the larger y (smaller Z).",
  },

  /* ---------------------------------------- 4.3  SHEAR STRESS */
  "hb-som-sheardist": {
    label: "Shear-stress distribution: rectangle and I-section (Worked examples 4.5 and 4.6)",
    svg: `<svg viewBox="0 0 640 330" role="img" aria-label="Left: a rectangular section 230 by 450 and beside it its shear stress distribution, a parabola that is zero at the top and bottom edges and greatest at the neutral axis, 1.30 newtons per square millimetre, which is 1.5 times the average of 0.87. Right: an I-section 300 deep with 150 by 15 flanges and an 8 millimetre web, and its shear stress distribution for a shear force of 150 kilonewtons. In the flanges the stress is tiny, rising from zero at the outer edge to 3.1 at the flange-web junction. At the junction it jumps sharply to 57.5 in the web, because the width drops from 150 to 8, then rises parabolically to a maximum of 70.6 at the neutral axis. The web carries about 95 percent of the shear force.">
      <!-- rectangle -->
      <rect class="conc" x="30" y="57.5" width="115" height="225"/>
      <line class="dash" x1="20" y1="170" x2="300" y2="170"/>
      <line class="s" x1="160" y1="50" x2="160" y2="290"/>
      <path class="soft-b" d="M160 57.5 L161.2 58.0 L178.9 66.0 L195.3 74.0 L210.5 82.0 L224.3 90.0 L236.8 98.0 L247.9 106.0 L257.8 114.0 L266.3 122.0 L273.6 130.0 L279.5 138.0 L284.1 146.0 L287.4 154.0 L289.3 162.0 L290.0 170.0 L289.3 178.0 L287.4 186.0 L284.1 194.0 L279.5 202.0 L273.6 210.0 L266.3 218.0 L257.8 226.0 L247.9 234.0 L236.8 242.0 L224.3 250.0 L210.5 258.0 L195.3 266.0 L178.9 274.0 L161.2 282.0 L160.0 282.5 Z"/>
      <text class="em" x="296" y="164" text-anchor="end">1.30 = 1.5 q_avg</text>
      <text class="lb" x="88" y="306" text-anchor="middle">230 × 450</text>
      <text class="lb" x="200" y="306" text-anchor="middle">V = 90 kN</text>

      <!-- I-section -->
      <rect class="conc" x="330" y="50" width="120" height="12"/>
      <rect class="conc" x="386.8" y="62" width="6.4" height="216"/>
      <rect class="conc" x="330" y="278" width="120" height="12"/>
      <line class="dash" x1="320" y1="170" x2="630" y2="170"/>
      <line class="s" x1="470" y1="44" x2="470" y2="296"/>
      <path class="soft-b" d="M470.0 50.0 L471.3 52.4 L472.5 54.8 L473.8 57.2 L475.0 59.6 L476.1 62.0 L585.0 62.0 L586.1 64.4 L590.4 74.0 L594.4 83.6 L597.9 93.2 L601.0 102.8 L603.7 112.4 L605.9 122.0 L607.8 131.6 L609.2 141.2 L610.3 150.8 L610.9 160.4 L611.1 170.0 L610.9 179.6 L610.3 189.2 L609.2 198.8 L607.8 208.4 L605.9 218.0 L603.7 227.6 L601.0 237.2 L597.9 246.8 L594.4 256.4 L590.4 266.0 L586.1 275.6 L585.0 278.0 L476.1 278.0 L475.0 280.4 L473.8 282.8 L472.5 285.2 L471.3 287.6 L470.0 290.0 Z"/>
      <text class="lb" x="480" y="44">3.1 (flange)</text>
      <text class="ea" x="582" y="56" text-anchor="end">jump → 57.5</text>
      <text class="em" x="616" y="164" text-anchor="end">70.6</text>
      <text class="lb" x="390" y="306" text-anchor="middle">I: 150 × 300, web 8</text>
      <text class="lb" x="540" y="306" text-anchor="middle">V = 150 kN</text>
      <text class="lb" x="540" y="322" text-anchor="middle">web takes ≈ 95% of V</text>
    </svg>`,
    caption: "Rectangle: a parabola peaking at 1.5 × average at the N.A. I-section: almost nothing in the flanges, a jump of B/t_w at the junction, and a nearly uniform high stress in the web — which is why steel designers check shear on the web area alone.",
  },

  /* ---------------------------------------- 4.2  STRONGEST BEAM FROM A LOG */
  "hb-som-log": {
    label: "Strongest rectangular beam that can be cut from a round log",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="A circle of diameter D with a rectangle inscribed in it so that its diagonal equals D. For the strongest beam the breadth is D over root 3, about 0.577 D, and the depth is root two-thirds D, about 0.816 D, giving a depth to breadth ratio of root 2. For comparison, the stiffest beam has breadth D over 2 and depth root 3 over 2 times D.">
      <circle class="s" cx="200" cy="150" r="130"/>
      <rect class="soft-b" x="125" y="43.9" width="150" height="212.2"/>
      <line class="ac" x1="125" y1="256.1" x2="275" y2="43.9"/>
      <text class="ea" x="214" y="140">D</text>
      <line class="thin" x1="125" y1="272" x2="275" y2="272"/><text class="lb" x="200" y="290" text-anchor="middle">b</text>
      <line class="thin" x1="345" y1="43.9" x2="345" y2="256.1"/><text class="lb" x="352" y="154">d</text>
      <text x="400" y="70">Strongest (max Z = bd²/6):</text>
      <text class="em" x="400" y="90">b = D/√3 ≈ 0.577D</text>
      <text class="em" x="400" y="108">d = √(2/3)·D ≈ 0.816D</text>
      <text class="em" x="400" y="126">d : b = √2 : 1</text>
      <text x="400" y="166">Stiffest (max I = bd³/12):</text>
      <text class="ea" x="400" y="186">b = D/2,  d = (√3/2)·D</text>
      <text class="ea" x="400" y="204">d : b = √3 : 1</text>
      <text class="lb" x="400" y="240">Constraint: b² + d² = D²</text>
    </svg>`,
    caption: "Maximising bd² (strength) or bd³ (stiffness) subject to b² + d² = D² gives different shapes — the stiffest beam is deeper and narrower than the strongest.",
  },
});
