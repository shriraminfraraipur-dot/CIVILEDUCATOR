/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: MATERIAL TESTING & QC · Ch 7–8
   Brick, steel & bitumen tests · Quality control and acceptance
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "qc");
  if (!hb) { console.error("[qc3] handbook qc not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "qc-7",
      n: 7,
      title: "Brick, Steel and Bitumen Tests",
      hi: "ईंट, स्टील और बिटुमेन परीक्षण",
      blurb: "The acceptance tests for three more everyday materials — what each checks and the value that means pass.",
      mins: 20,
      sections: [
        {
          n: "7.1",
          title: "Brick and steel",
          hi: "ईंट और स्टील",
          blocks: [
            { k: "p", t: "Bricks and reinforcing steel each have a short, well-defined acceptance test set, and knowing what each test guards against is the point." },
            { k: "cmp", t: "IS 1786 — minimum mechanical properties of reinforcing bars", cols: ["Min. tensile strength (N/mm²)", "Min. elongation (%)"], rows: [
              ["Fe 415", "485", "14.5"],
              ["Fe 415D", "500", "18.0"],
              ["Fe 500", "545 (and ≥ 1.08 × actual yield)", "12.0"],
              ["Fe 500D", "565 (and ≥ 1.10 × actual yield)", "16.0"],
              ["Fe 550 / 550D", "585 / 600", "10.0 / 14.5"],
              ["Fe 600", "660", "10.0"],
            ]},
            { k: "note", t: "Values from <a href=\"https://engineeringhulk.com/civil/construction-materials/steel-reinforcement-materials/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>. The ‘D’ grades are the ductile grades — higher elongation and a higher tensile/yield ratio — specified for seismic detailing. The same source gives a ratio of 1.08 for Fe 415; the familiar wording of IS 1786 is ‘10% more than the actual 0.2% proof stress’ for Fe 415, so that ratio is not quoted here — check the standard." },
            { k: "eg", title: "Example 7.1 — Does this bar meet Fe 500D?",
              given: "Tensile test on a 16 mm bar: load at 0.2% proof 104 kN, maximum load 121 kN. Gauge length 5.65√A; after fracture the gauge marks are 94.5 mm apart.",
              steps: [
                { t: "Area", w: "A = π/4 × 16² = 201.1 mm²" },
                { t: "Proof and tensile strength", w: "fy = 104,000/201.1 = 517 N/mm²  (≥ 500 ✓)\nfu = 121,000/201.1 = 602 N/mm²  (≥ 565 ✓)\nfu/fy = 1.16  (≥ 1.10 ✓)" },
                { t: "Elongation", w: "gauge length = 5.65 × √201.1 = 80.1 mm\nelongation = (94.5 − 80.1)/80.1 = 18.0%  (≥ 16 ✓)" },
              ],
              ans: "Passes every Fe 500D tensile requirement. The bend and rebend tests must still be passed — strength alone does not qualify a bar." },
            { k: "cmp", t: "Brick tests (IS 1077)",
              cols: ["Guards against"],
              rows: [
                ["Compressive strength", "too weak → sets the class (3.5, 7.5, 10 …)"],
                ["Water absorption", "a thirsty brick → frost damage, weak joints (≤ ~20% first class)"],
                ["Efflorescence", "soluble salts → white staining through plaster later"],
                ["Dimension & shape", "irregular units → poor bonding, uneven work"],
              ] },
            { k: "cmp", t: "Steel (reinforcement) tests",
              cols: ["Guards against"],
              rows: [
                ["Tensile / yield strength", "weak steel → sets the grade (Fe 415, Fe 500)"],
                ["Elongation (ductility)", "brittle steel → sudden failure, poor bending"],
                ["Bend & rebend", "steel that cracks on bending → fails at hooks/bends"],
                ["Mass per metre", "under-weight (rolled thin) bars → less steel than billed"],
              ] },
            { k: "trap", t: "The rebend test on steel matters more than beginners think. Reinforcement is bent into hooks and stirrups on site, and a steel that passes on strength but cracks when bent (and re-bent, after ageing) will fracture at exactly those bends — the most highly stressed points in seismic detailing. Strength alone does not qualify a reinforcing steel; it must also bend without cracking, which is what the bend and rebend tests confirm." },
          ],
        },
        {
          n: "7.2",
          title: "Bitumen",
          hi: "बिटुमेन",
          blocks: [
            { k: "p", t: "Bitumen is graded almost entirely by consistency, because its whole behaviour is a balance between being soft enough to lay and stiff enough to last (Transportation handbook). The tests measure that balance." },
            { k: "cmp", t: "IS 73:2013 viscosity-grade bitumen — selected requirements", cols: ["Absolute viscosity at 60 °C (Poise)", "Penetration at 25 °C, min / softening point, min"], rows: [
              ["VG-10", "800–1200", "80 / 40 °C"],
              ["VG-20", "1600–2400", "60 / 45 °C"],
              ["VG-30", "2400–3600", "45 / 47 °C"],
              ["VG-40", "3200–4800", "35 / 50 °C"],
            ]},
            { k: "note", t: "Read from <a href=\"https://law.resource.org/pub/in/bis/S11/is.73.2013.pdf\" target=\"_blank\" rel=\"noopener\">IS 73:2013 (Public.Resource.Org)</a>. Since 2013 Indian paving bitumen is graded by viscosity at 60 °C — the summer pavement temperature — rather than by penetration; penetration and softening point remain as checks. VG-30 is the common grade for most of the country; VG-40 for hot, heavily loaded roads." },
            { k: "cmp", t: "Bitumen tests",
              cols: ["Measures"],
              rows: [
                ["Penetration", "hardness — how far a needle sinks (0.1 mm)"],
                ["Softening point", "the temperature at which it flows (ring-and-ball)"],
                ["Ductility", "how far it stretches before breaking (cm)"],
                ["Viscosity", "flow resistance — basis of VG grading"],
                ["Flash point", "temperature safety — when vapours ignite"],
              ] },
            { k: "note", t: "The grade of bitumen is chosen for the climate, and the tests are how you confirm it: a hot region needs a higher softening point (won't rut in summer), a cold region needs more ductility (won't crack in winter). There is no universally best bitumen, only the right grade for the local temperature range — and the penetration, softening point and ductility tests together place a given sample on that scale." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "qc-8",
      n: 8,
      title: "Quality Control and Acceptance",
      hi: "गुणवत्ता नियंत्रण और स्वीकृति",
      blurb: "Why the spread of results matters as much as the average, how good control saves cement, and what quality control really buys.",
      mins: 20,
      sections: [
        {
          n: "8.1",
          title: "The spread matters as much as the average",
          hi: "फैलाव औसत जितना ही महत्वपूर्ण",
          blocks: [
            { k: "p", t: "Individual tests accept or reject one lot, but quality control is about the pattern across many lots — and the surprising lesson is that the spread of results matters as much as their average. Two sites producing the same average strength can differ completely in how safe their concrete is." },
            { k: "dia", id: "hb-qc-control", cap: "Same average strength, different scatter — and different safety." },
            { k: "def", term: "Standard deviation (σ)", t: "A measure of how much the results scatter around their average. A small σ means tight, consistent results (good control); a large σ means wide, erratic results (poor control). It is the key number in quality control, because acceptance and target strength both depend on it." },
            { k: "eg", title: "Example 8.1 — How good is this site's control?",
              given: "Ten consecutive M25 sample results (N/mm²): 28.5, 31.0, 26.5, 30.0, 33.5, 29.0, 27.5, 32.0, 30.5, 28.0.",
              steps: [
                { t: "Mean", w: "296.5/10 = 29.65 N/mm²" },
                { t: "Standard deviation", w: "s = √[Σ(x − x̄)²/(n − 1)] = 2.16 N/mm²" },
                { t: "What the mix needs to aim for with this s", w: "fck + 1.65 s = 25 + 3.57 = 28.6 N/mm² — below the 29.65 achieved" },
              ],
              ans: "s ≈ 2.2 N/mm², much tighter than the 4.0 assumed in mix design, and no result is below 25. A site that can show this record can justify a leaner mix — but only after enough results (IS 10262 asks for at least 30) to establish s reliably." },
            { k: "p", t: "This is why the target mean strength was set as fck + 1.65σ back in the Concrete Technology handbook. A well-controlled site with a small σ can aim its mix just above the grade and still keep only 1 result in 20 below fck; a poorly-controlled site with a large σ must aim far higher — using more cement on every cubic metre — to keep that same small failure rate. The scatter, not the average, is what forces the extra cement." },
          ],
        },
        {
          n: "8.2",
          title: "What quality control really buys",
          hi: "गुणवत्ता नियंत्रण असल में क्या देता है",
          blocks: [
            { k: "p", t: "It is easy to see quality control as paperwork — forms, cube registers, test certificates. Understanding the scatter reveals what it actually buys: safety and money at the same time." },
            { k: "list", items: [
              "<strong>Consistency</strong> — good control shrinks σ, so fewer results fall below the grade: the concrete is more reliably safe.",
              "<strong>Cement saved</strong> — a smaller σ lets the target mean strength drop closer to the grade, saving cement on every pour.",
              "<strong>Early warning</strong> — regular testing (7-day cubes, slump on every load) catches a drifting mix before a lot is condemned.",
              "<strong>A defensible record</strong> — when something is questioned, the test record is the evidence that the work met spec.",
            ] },
            { k: "real", t: "A site that tightens its control — accurate batching, consistent materials, disciplined curing, regular testing — is rewarded twice: its concrete is more reliably above grade, and it can design a leaner mix because its scatter is small. A sloppy site pays twice over: erratic strength and a fat, cement-heavy mix forced by its own inconsistency. <strong>Good quality control is not a cost centre — it is safety and cement savings arriving together</strong>, and that is the note this whole app has tried to sound: understand why, and the right practice pays for itself." },
          ],
        },
      ],
    },

  );
})();
