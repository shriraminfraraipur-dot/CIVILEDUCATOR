/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: CONCRETE TECHNOLOGY · Chapters 6–8
   Mix proportioning · Durability, exposure & cover · Curing, formwork & QC
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "ct");
  if (!hb) { console.error("[ct3] handbook ct not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "ct-6",
      n: 6,
      title: "Mix Proportioning — Nominal and Design Mix",
      hi: "मिक्स अनुपात",
      blurb: "Two ways to arrive at a mix: the fixed volumetric recipes for small work, and the calculated design mix that squeezes the same strength from less cement.",
      mins: 34,
      sections: [
        {
          n: "6.1",
          title: "Nominal mixes — the fixed recipes",
          hi: "नॉमिनल मिक्स",
          blocks: [
            { k: "p", t: "A nominal mix is a fixed volumetric recipe — 1:1.5:3, 1:2:4, 1:3:6 (cement : sand : coarse aggregate) — used for small and non-critical work where designing a mix would be overkill. It is simple and safe but wasteful: it uses more cement than needed to be sure of the strength." },
            { k: "eg", title: "Example 6.1 — Materials for one cubic metre of M20 (1:1.5:3)",
              given: "Find the cement, sand, coarse aggregate and water for 1 m³ of compacted M20 nominal concrete (1:1.5:3). Take the dry-volume factor as 1.54, cement density 1440 kg/m³, one bag = 50 kg, and a water-cement ratio of 0.5.",
              steps: [
                { t: "Dry material needed", w: "1 m³ compacted needs ~1.54 m³ of dry\nloose material (it bulks then packs down)" },
                { t: "Split by the ratio (sum = 1+1.5+3 = 5.5)", w: "cement = 1.54 × 1/5.5   = 0.280 m³\nsand   = 1.54 × 1.5/5.5 = 0.420 m³\nc.agg  = 1.54 × 3/5.5   = 0.840 m³" },
                { t: "Cement to mass and bags", w: "0.280 × 1440 = 403 kg\n403 / 50     = 8.06 bags" },
                { t: "Water at w/c = 0.5", w: "0.5 × 403 = 201 litre" },
              ],
              ans: "Per m³: about 8 bags cement, 0.42 m³ sand, 0.84 m³ coarse aggregate, ~200 litres water. A design mix for the same M20 would typically use less cement — this is the price of the nominal recipe's simplicity." },
            { k: "tbl", id: "tb-nominalmix" },
            { k: "note", t: "Check Example 6.1 against IS 456 Table 9: for M20 the table allows at most 30 litres of water per 50 kg of cement — a w/c of 0.60 — so the 0.5 used above is inside the limit; and the total aggregate is 4.5 × the cement mass, inside the 250 kg per 50 kg bag (5 ×) maximum. Note that the code's nominal-mix table is on a <em>mass</em> basis; the 1.54 dry-volume method is the site convention for converting it to volumes." },
            { k: "note", t: "The 1.54 factor is the standard allowance for the fact that dry loose materials pack down and lose air voids when mixed and compacted, so you need about 1.54 m³ of loose material to end up with 1 m³ of solid concrete. It varies a little with materials; 1.52–1.57 is the usual range." },
          ],
        },
        {
          n: "6.2",
          title: "Design mixes — earning the strength",
          hi: "डिज़ाइन मिक्स",
          blocks: [
            { k: "p", t: "A design mix is calculated (by IS 10262) from the target mean strength, the materials' actual properties, the exposure and the workability wanted. It arrives at proportions that meet the strength with the least cement — so it is cheaper and more durable, but needs testing and control." },
            { k: "cmp", t: "Nominal vs design mix",
              cols: ["Design mix", "Nominal mix"],
              rows: [
                ["How set", "calculated from materials & target", "fixed recipe from a table"],
                ["Cement used", "least needed — economical", "more, to be safe"],
                ["Needs testing", "yes — trial mixes, cubes", "no"],
                ["Used for", "M25 and above, all real structures", "small work, up to ~M20"],
              ] },
            { k: "steps", items: [
              "Fix the <strong>target mean strength</strong> = fck + 1.65σ (Chapter 5).",
              "Pick the <strong>water-cement ratio</strong> from the target strength and the durability (exposure) limit — whichever is lower governs.",
              "Choose <strong>water content</strong> from the workability and maximum aggregate size.",
              "Get <strong>cement content</strong> = water ÷ w/c, and check it against the durability minimum.",
              "Find <strong>aggregate proportions</strong>, then cast <strong>trial mixes</strong> and adjust.",
            ] },
            { k: "eg", title: "Example 6.2 — An M25 design mix, IS 10262:2019 method",
              given: "M25, moderate exposure, 20 mm crushed coarse aggregate, Zone II sand, slump 100 mm, OPC 43, no admixture. Specific gravities: cement 3.15, coarse aggregate 2.74, fine aggregate 2.65 (assumed for illustration).",
              steps: [
                { t: "Target strength", w: "f′ck = max(25 + 1.65 × 4.0, 25 + 5.5) = 31.6 N/mm² (Example 5.1)" },
                { t: "Water-cement ratio", w: "from the code's strength–w/c curve for the cement in use; take 0.45 for illustration\nmoderate exposure limit (IS 456 Table 5) = 0.50 → 0.45 ≤ 0.50 ✓" },
                { t: "Water content", w: "186 kg/m³ for 20 mm aggregate at 50 mm slump\n+3% per extra 25 mm: 100 mm slump → +6% → 186 × 1.06 = 197 kg/m³" },
                { t: "Cement content", w: "197/0.45 = 438 kg/m³  (≥ 300 for moderate exposure ✓; ≤ 450 kg/m³ IS 456 cap ✓)" },
                { t: "Coarse aggregate fraction", w: "0.62 of total aggregate volume for Zone II at w/c 0.50;\n+0.01 for each 0.05 reduction in w/c → 0.63 at w/c 0.45" },
                { t: "Volumes per m³", w: "cement 438/3150 = 0.139 m³\nwater 0.197 m³\nentrapped air 0.010 m³ (1%)\naggregate = 1 − 0.010 − 0.139 − 0.197 = 0.654 m³" },
                { t: "Masses", w: "coarse = 0.654 × 0.63 × 2740 = 1129 kg\nfine   = 0.654 × 0.37 × 2650 = 641 kg" },
              ],
              ans: "Trial mix per m³: cement 438 kg, water 197 kg, fine aggregate 641 kg, coarse aggregate 1129 kg (w/c 0.45). Adjust for aggregate moisture and absorption, cast trial cubes, and revise — the calculation is only the starting point." },
            { k: "note", t: "Base water 186 kg/m³, the 3% per 25 mm slump adjustment, the 0.62 coarse-aggregate fraction and the ±0.01 per 0.05 w/c rule are from <a href=\"https://pdfcoffee.com/is-10262-2019-pdf-free.html\" target=\"_blank\" rel=\"noopener\">IS 10262:2019 text (PDFCOFFEE)</a> and agree with <a href=\"https://media.springernature.com/original/springer-static/esm/art%3A10.1007%2Fs44290-025-00208-w/MediaObjects/44290_2025_208_MOESM1_ESM.pdf\" target=\"_blank\" rel=\"noopener\">a published IS 10262:2019 mix design</a>. <b>Conflict:</b> that published design uses 2% entrapped air for 20 mm aggregate; 1% is used here — with 2% the aggregates fall to 1111 and 631 kg. The w/c of 0.45 is an assumed reading of the strength curve, not a code value. Specific gravities must be measured." },
            { k: "trap", t: "Durability can overrule strength when setting the w/c. A mild-exposure M25 might allow w/c = 0.55 for strength, but a severe marine exposure caps it lower — and you must take the lower. The mix is designed for the worse of the two demands, never just for strength." },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "ct-7",
      n: 7,
      title: "Durability, Exposure and Cover",
      hi: "टिकाऊपन, एक्सपोज़र और कवर",
      blurb: "Why a strong concrete can still fail, how the reinforcement is protected, and how the code turns the environment into limits on cover and water-cement ratio.",
      mins: 30,
      sections: [
        {
          n: "7.1",
          title: "Strength is not durability",
          hi: "सामर्थ्य ही टिकाऊपन नहीं",
          blocks: [
            { k: "p", t: "A concrete can hit its strength on day 28 and still fail in ten years. Durability is a separate property: how well the concrete resists the slow attack of water, chloride, sulphate, carbonation and frost over its service life. Most concrete failures are durability failures, not strength failures." },
            { k: "def", term: "Durability", t: "The ability of concrete to resist weathering, chemical attack and abrasion while keeping its properties. It is governed mostly by permeability — how easily aggressive agents get in — which is set by the water-cement ratio and the compaction and curing." },
            { k: "def", term: "Permeability", t: "How easily water and dissolved salts pass through the concrete. Low permeability is the master durability property: a dense, low-w/c, well-compacted, well-cured concrete keeps the attackers out, whatever its strength grade." },
            { k: "note", t: "Notice the same three levers keep returning: low w/c, good compaction, good curing. They set strength in the early chapters and durability here — because both come from the same thing, a dense concrete with few voids and connected pores." },
          ],
        },
        {
          n: "7.2",
          title: "Protecting the steel — cover and exposure",
          hi: "स्टील की सुरक्षा — कवर और एक्सपोज़र",
          blocks: [
            { k: "p", t: "In reinforced concrete the durability question is usually: how long until the reinforcement rusts? The concrete protects the steel chemically, but that protection is slowly eaten away from the surface inward." },
            { k: "dia", id: "hb-ct-cover", cap: "Cover, the attack fronts, and the two dials that protect the steel." },
            { k: "def", term: "Cover", t: "The depth of concrete between the outer surface and the nearest reinforcement. It is the distance carbonation and chloride must travel before they reach the steel — so more cover means a longer protected life. It is a durability requirement set by the code, not a placing convenience." },
            { k: "def", term: "Exposure condition", t: "IS 456's classification of how aggressive the environment is — mild, moderate, severe, very severe, extreme (marine). Each level fixes a minimum cover, a maximum water-cement ratio and a minimum cement content. Harsher exposure demands denser concrete and deeper cover." },
            { k: "tbl", id: "tb-exposure" },
            { k: "tbl", id: "tb-cover" },
            { k: "trap", t: "Cover is not there to protect against fire alone or to 'look neat' — it is a durability clock. Skimp the cover (bars pushed to the face, spacers left out) and the steel begins to rust years early. The rust expands, cracks the cover off, and exposes more steel — a runaway failure that starts with a few missing spacer blocks." },
            { k: "h", t: "How long does cover last? The √t law" },
            { k: "p", t: "Carbonation advances from the surface roughly in proportion to the square root of time, x = k√t, where k (mm/year<sup>½</sup>) depends on the concrete and its exposure (<a href=\"https://en.wikipedia.org/wiki/Durability_of_reinforced_concrete_structures\" target=\"_blank\" rel=\"noopener\">Wikipedia's article on RC durability</a>). The same law means the protection bought by cover grows with its <em>square</em>." },
            { k: "eg", title: "Example 7.1 — Time for carbonation to reach the steel",
              given: "A phenolphthalein test on a 4-year-old column shows carbonation 10 mm deep. Cover provided 30 mm (moderate exposure); a neighbouring column was built with only 20 mm.",
              steps: [
                { t: "Carbonation coefficient", w: "k = x/√t = 10/√4 = 5 mm/year^½" },
                { t: "Time to reach 30 mm", w: "t = (30/5)² = 36 years" },
                { t: "Time to reach 20 mm", w: "t = (20/5)² = 16 years" },
              ],
              ans: "Losing a third of the cover cuts the time to de-passivation from 36 to 16 years — more than half. Cover is a durability clock whose rate goes as the square." },
          ],
        },
        {
          n: "7.3",
          title: "Chemical attack — the common agents",
          hi: "रासायनिक हमला",
          blocks: [
            { k: "p", t: "Beyond corrosion of the steel, the concrete itself is attacked by a few specific agents, and the defence is chosen to match the attacker." },
            { k: "cmp", t: "The attackers and the defences",
              cols: ["What it does", "The defence"],
              rows: [
                ["Chloride (sea, de-icing salt)", "rusts the reinforcement", "low w/c, ample cover, cap chloride content"],
                ["Sulphate (soil, groundwater)", "expands & disrupts the paste", "sulphate-resisting cement (low C₃A)"],
                ["Carbonation (CO₂ in air)", "neutralises the paste → steel de-passivates", "dense low-w/c concrete, cover"],
                ["Acid / soft water", "dissolves the paste", "dense concrete, protective coatings"],
              ] },
            { k: "real", t: "A foundation in sulphate-bearing soil shows the principle: ordinary cement's C₃A reacts with sulphate to form expansive crystals that crack the concrete from within, so you specify sulphate-resisting cement, which simply has the C₃A limited. <strong>The defence is always matched to the specific attacker — there is no all-purpose durable concrete, only concrete right for its exposure.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "ct-8",
      n: 8,
      title: "Curing, Formwork and Quality Control",
      hi: "क्योरिंग, फॉर्मवर्क और गुणवत्ता नियंत्रण",
      blurb: "The steps after placing that decide whether the designed strength is actually reached — keeping it wet, holding its shape, and proving on site that it worked.",
      mins: 36,
      sections: [
        {
          n: "8.1",
          title: "Curing — the cheapest strength on the site",
          hi: "क्योरिंग",
          blocks: [
            { k: "p", t: "Curing means keeping concrete moist (and warm enough) so hydration continues after placing. It is the most under-valued step: hydration only proceeds while water is present, so concrete that dries out early simply stops gaining strength — permanently — at whatever it had reached." },
            { k: "def", term: "Curing", t: "Maintaining adequate moisture and temperature in concrete for long enough that hydration can develop its strength and durability. Common methods: ponding, wet hessian, curing compounds, and covering with plastic sheet." },
            { k: "p", t: "The strength lost to poor curing is large and invisible. Concrete cured properly for a fortnight can reach nearly its full potential; the same concrete allowed to dry after a day or two may reach only a fraction of it — and there is no way to tell by looking. IS 456 Cl. 13.5.1 requires moist curing for at least 7 days for OPC, at least 10 days where mineral admixtures or blended cements are used, and suggests extending it to 10–14 days in hot, dry weather (as summarised by <a href=\"https://infralens.in/knowledge/curing-period-concrete-is-456\" target=\"_blank\" rel=\"noopener\">InfraLens</a>)." },
            { k: "trap", t: "Hot, windy, sunny weather is when curing matters most and is hardest — the surface dries in minutes, hydration stalls at the top, and you get a weak, dusting, crazed surface over sound concrete below. That is precisely when ponding or covering must start earliest, not when it can be skipped because 'it looks dry and hard'." },
          ],
        },
        {
          n: "8.2",
          title: "Formwork — holding the shape, then letting go",
          hi: "फॉर्मवर्क",
          blocks: [
            { k: "p", t: "Formwork (shuttering) is the temporary mould that holds fresh concrete to its shape and carries its weight until it can carry itself. It is temporary, but getting it wrong causes real failures — bulging faces, honeycombed corners, or collapse under the wet load." },
            { k: "list", items: [
              "<strong>Strong and rigid</strong> enough to carry the wet concrete without bulging or sagging.",
              "<strong>Tight</strong> at the joints so paste does not leak out (leaking paste leaves honeycombed, sandy surfaces).",
              "<strong>Clean and oiled</strong> so it releases cleanly and can be reused.",
              "<strong>Removed at the right time</strong> — the striking time — not before the concrete can carry itself.",
            ] },
            { k: "def", term: "Striking time", t: "How long formwork must stay before removal, set by which part it supports: vertical faces can come off after 16–24 hours; soffit sheeting can be struck after 3 days (slabs) or 7 days (beams) provided props are left under; the props themselves stay 7–14 days for slabs and 14–21 days for beams depending on span (IS 456 Cl. 11.3, table below)." },
            { k: "tbl", id: "tb-formwork" },
            { k: "trap", t: "Removing the soffit props of a beam or slab too early is a genuine cause of collapse — the young concrete has not gained the strength to carry its own span, let alone construction load above. Side forms and soffit forms are on completely different clocks, and the soffit is the one that kills people." },
          ],
        },
        {
          n: "8.3",
          title: "Quality control — proving it on site",
          hi: "गुणवत्ता नियंत्रण",
          blocks: [
            { k: "p", t: "The last job is proving the concrete is what was specified. This is done by sampling and cube-testing to an acceptance rule, backed up by non-destructive tests on the structure itself when a result is in doubt." },
            { k: "list", items: [
              "<strong>Sampling</strong> — cubes cast at a set frequency (per volume placed and per day), cured and crushed at 28 days.",
              "<strong>Acceptance criteria</strong> — IS 456 judges concrete on the mean of groups of consecutive cubes AND on no single result falling too far below fck — not on one cube alone.",
              "<strong>Non-destructive tests</strong> — rebound hammer (surface hardness) and ultrasonic pulse velocity (density/uniformity) assess concrete already in place, without cutting it.",
              "<strong>Core test</strong> — the arbiter when cubes and NDT disagree: a cylinder is cut from the actual structure and crushed.",
            ] },
            { k: "tbl", id: "tb-sampling" },
            { k: "def", term: "Acceptance by groups, not singles", t: "Because strength scatters, a single low cube does not condemn the concrete. IS 456 asks that the mean of consecutive cube groups exceeds fck by a margin AND that no individual result falls more than a set amount below fck — a rule built around the scatter, not against it." },
            { k: "real", t: "When a 28-day cube fails, the structure is not automatically condemned — that is what the rebound hammer, ultrasonic test and, finally, a cut core are for: to assess the concrete actually in the member, which may be sound even if one cube was not. <strong>The cube is evidence about the batch; the core is evidence about the structure.</strong>" },
            { k: "eg", title: "Example 8.1 — Accepting a batch of M25",
              given: "Four consecutive, non-overlapping sample results (each the mean of 3 cubes) for M25: 29.0, 27.5, 31.0, 26.0 N/mm². Established standard deviation 3.5 N/mm². Criteria as commonly quoted from IS 456 Table 11 for M20 and above: mean of 4 ≥ the greater of fck + 0.825 s and fck + 4; every individual ≥ fck − 4.",
              steps: [
                { t: "Mean of the four", w: "(29.0 + 27.5 + 31.0 + 26.0)/4 = 113.5/4 = 28.4 N/mm²" },
                { t: "Required mean", w: "fck + 0.825 s = 25 + 2.9 = 27.9 (rounded to 28.0)\nfck + 4 = 29.0  →  29.0 governs" },
                { t: "Individual results", w: "lowest 26.0 ≥ 25 − 4 = 21  ✓" },
              ],
              ans: "Individuals pass but the mean (28.4) is below 29.0 — the concrete represented is not accepted on cubes alone. The next steps are investigation: NDT on the members, then cores if needed (IS 456 Cl. 17), not automatic demolition." },
            { k: "note", t: "Table 11 values as quoted by <a href=\"https://thecivilstudies.com/concrete-strength-compliance-is-456-cube-test/\" target=\"_blank\" rel=\"noopener\">TheCivilStudies</a> and used in the Quality Control handbook. IS 456 Table 11 has been amended since 2000; confirm the current amended criteria before applying them to a contract." },
            { k: "cmp", t: "Ultrasonic pulse velocity — quality grading (IS 13311 Part 1)", cols: ["Concrete quality"], rows: [
              ["Above 4.5 km/s", "Excellent"],
              ["3.5 – 4.5 km/s", "Good"],
              ["3.0 – 3.5 km/s", "Medium"],
              ["Below 3.0 km/s", "Doubtful / poor"],
            ]},
            { k: "note", t: "Grading as reproduced by <a href=\"https://www.nbmcw.com/product-technology/construction-chemicals-waterproofing/concrete-admixtures/techniques-for-concrete-quality-measurements.html\" target=\"_blank\" rel=\"noopener\">NBM&CW</a>. UPV is affected by moisture, path length and reinforcement along the path, so it grades uniformity rather than giving strength directly; it is now covered by IS 516 (Part 5)." },
            { k: "h", t: "Maturity — strength from temperature history" },
            { k: "eq", expr: "maturity M = Σ (T − T₀) Δt  (°C·h, T₀ = −11 °C)        Plowman: strength % of 28-day value = A + B log₁₀(M × 10⁻³)", where: [
              ["A, B", "constants by strength class — for a 28-day strength of 35–52.5 N/mm², A = 32, B = 54"],
            ]},
            { k: "eg", title: "Example 8.2 — Strength after a cold fortnight",
              given: "M40 concrete (28-day strength class 35–52.5 N/mm²) cured 15 days (360 h) at an average 10 °C.",
              steps: [
                { t: "Maturity", w: "M = (10 − (−11)) × 360 = 7560 °C·h" },
                { t: "Plowman", w: "A + B log₁₀(7.56) = 32 + 54 × 0.8785 = 79.4% of the 28-day strength" },
                { t: "Strength", w: "0.794 × 40 = 31.8 N/mm²" },
              ],
              ans: "About 32 N/mm² — useful when deciding whether props can come out early in cold weather. Formulae and constants from the ACE Engineering College notes; maturity estimates should be calibrated against cubes for the actual mix." },
            { k: "note", t: "Nurse–Saul maturity, the −11 °C datum and Plowman's constants as given in the <a href=\"https://www.aceec.ac.in/wp-content/uploads/2025/07/Unit-3.pdf\" target=\"_blank\" rel=\"noopener\">ACE Engineering College notes</a>, whose own worked case this example reproduces (79.4%, 31.8 N/mm²)." },
          ],
        },
      ],
    },

  );
})();
