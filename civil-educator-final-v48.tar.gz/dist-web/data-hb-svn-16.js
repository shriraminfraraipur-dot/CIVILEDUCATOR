/* Surveying class notes — Curves (horizontal curves, simple circular curve), notes p.231–238 — inserted into sv chapter 11 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 11; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- types */
    { n: "", title: "Notes — Curves and the five horizontal curves", hi: "वक्र और क्षैतिज वक्रों के प्रकार", blocks: [
      { k: "h", t: "📘 Notes — p.231–233" },
      { k: "def", term: "Curves", t: "Curves are defined as an <b>arc with some finite radius</b> provided between intersecting straights to <b>gradually negotiate a change in direction</b>. (p.231)" },
      { k: "p", t: "This change in direction of straights may be <b>horizontal</b> or <b>vertical</b>, resulting in provision of a <b>horizontal curve</b> and a <b>vertical curve</b>. (p.231)" },
      { k: "list", items: [
        "<b>Horizontal curves</b>:",
        "1) Simple circular curve",
        "2) Compound curve",
        "3) Reverse curve",
        "4) Transition curve",
        "5) Broken back curve (p.231)",
      ] },
      { k: "def", term: "1) Simple circular curve", t: "A simple circular curve consists of an <b>arc of a circle</b> which is <b>tangential to two straight lines</b>. (p.231)" },
      { k: "p", t: "Figure (p.231): two straight lines meeting at an apex in an inverted-V (Λ) shape; a single circular arc is drawn just below the apex, touching both lines, with an arrow labelling it \"simple circular curve\"." },
      { k: "def", term: "2) Compound curve", t: "A compound curve consists of <b>two circular arcs of different radius</b> with their <b>centres of curvature on the same side</b> of the common tangent. (p.231–232)" },
      { k: "p", t: "Figure (p.232): two adjoining arcs curving the same way. The first arc has radius R₁ and centre O₁ (lowest point); the second has radius R₂ and centre O₂. O₂ lies on the common radius drawn from O₁ to the junction point of the two arcs. Lines: O₁ to the start of the first arc (R₁); O₁ through O₂ to the common junction point (common radius); O₂ to the end of the second arc (R₂)." },
      { k: "def", term: "3) Reverse curve / S-curve / Serpentine curve", t: "When two simple circular curves of <b>equal or different radius</b> having <b>opposite direction of curvature</b> are joined together, the resultant curve is called a <b>reverse curve</b>. (p.232)<br>(The notes spell it \"Superpentine\" and add a short Hindi side note in red.)" },
      { k: "p", t: "Figure (p.232): an S-shaped curve. The lower arc curves one way about centre O₁ with radius R₁ (lower left); the upper arc curves the opposite way about centre O₂ with radius R₂ (upper right). A straight line joins O₁ and O₂ and passes through the point where the curvature reverses." },
      { k: "def", term: "4) Transition curve", t: "A transition curve is a curve of <b>varying radius</b>, i.e. from <b>infinite to R</b>. It is generally provided <b>between a straight line and a simple circular curve</b>. (p.232–233)" },
      { k: "p", t: "Figure (p.232): a line that starts as a short segment labelled \"straight\", then bends gradually in a segment labelled \"Transition\", then continues as an arc labelled \"circular\"; tick marks separate the three portions." },
      { k: "def", term: "5) Broken back curve", t: "Shown in the notes by a figure only. (p.233)" },
      { k: "p", t: "Figure (p.233): two circular arcs curving in the <b>same direction</b> (both on the same side), joined by a long straight common tangent at the top — the left arc of radius R₁ about a centre O (bottom left), the right arc of radius R₂ about a centre O (bottom right). The shape is like an upside-down \"U\" with a flat straight top." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Sab curves ko do sawaal se pehchaano: <b>radius ek hai ya zyada?</b> aur <b>centres ek taraf hain ya alag taraf?</b> Ek radius = simple. Do radius, centres same side, arcs seedhe jude hue = compound. Centres opposite side = reverse (S-shape). Same side ke do arcs ke beech chhota straight aa jaye = broken back. Aur jiska radius dheere-dheere ∞ se R tak ghatata hai = transition. Chapter ke §11.1 mein inke site-use (terrain, superelevation) samjhaaye gaye hain." },
      { k: "trap", t: "Compound aur broken back dono mein dono arcs <b>ek hi direction</b> mein mudte hain — farq yeh hai ki compound mein arcs seedhe ek common tangent point par milte hain, jabki broken back mein unke beech ek <b>straight common tangent</b> hota hai. Reverse curve mein direction <b>ulti</b> hoti hai — use compound mat likhna." },
      { k: "real", t: "A broken back curve is generally avoided on roads and railways because the short straight between two same-direction arcs gives a jerky, unsightly alignment; it is better replaced by a single larger arc or a compound curve." },
    ] },

    /* ---------------------------------------------------------- definitions */
    { n: "", title: "Notes — Simple circular curve: parts and definitions", hi: "सरल वृत्तीय वक्र — अवयव और परिभाषाएँ", blocks: [
      { k: "h", t: "📘 Notes — p.233–235" },
      { k: "p", t: "Figure (p.233): the back tangent runs from A up to the vertex V; the forward tangent runs from V down to B. V is labelled \"Point of intersection / Vertex\", and the deflection angle Δ is marked at V between the extension of the back tangent and the forward tangent. The curve starts at T₁ on the back tangent (\"Point of curve (P.C)\") and ends at T₂ on the forward tangent (\"Point of tangency\"). T₁V is marked \"Tangent length\". A vertical line from V downward: the part from V to the apex of the curve is E, \"Apex distance\"; the part from the curve apex down to the chord T₁T₂ is M, \"Mid ordinate\". The arc is labelled l (length of curve); the chord T₁T₂ is labelled \"L, Long chord\". Radii R are drawn from the centre O to T₁ and to T₂; the angle at O is Δ, split by the vertical bisector into Δ/2 and Δ/2." },
      { k: "def", term: "(i) Back tangent (AT₁)", t: "The tangent line <b>before the beginning</b> of the curve is called the back tangent. It is also called the <b>rear tangent</b>. (p.233)" },
      { k: "def", term: "(ii) Forward tangent (T₂B)", t: "The tangent line <b>after the end</b> of the curve is called the forward tangent. (p.233)" },
      { k: "def", term: "(iii) Vertex / Point of intersection (P.I.)", t: "It is the point of intersection of the back and forward tangents. (p.234)" },
      { k: "def", term: "(iv) Deflection angle (Δ)", t: "It is the angle between the back tangent and the forward tangent. (p.234)" },
      { k: "def", term: "(v) Point of curve (P.C.)", t: "It is the point on the back tangent at the <b>beginning</b> of the curve. (p.234)" },
      { k: "def", term: "(vi) Point of tangency (P.T.)", t: "It is the point on the forward tangent at the <b>end</b> of the curve. (p.234)" },
      { k: "def", term: "(vii) Tangent distance / length (T₁V = T₂V)", t: "It is the distance between the point of curve and the point of intersection, and also equals the distance between the point of tangency and the point of intersection. (p.234)" },
      { k: "def", term: "(viii) Apex distance (E) / External distance", t: "It is the distance between the point of intersection and the <b>apex point on the curve</b>. (p.234)" },
      { k: "def", term: "(ix) Long chord", t: "It is the chord joining the point of curve (P.C.) and the point of tangency (P.T.). (p.234)" },
      { k: "def", term: "(x) Mid ordinate", t: "It is the distance between the <b>centre of the long chord</b> and the apex point on the curve. (p.235)" },
      { k: "def", term: "(xi) Length of curve (l)", t: "It is the length of the <b>arc</b> between the point of curve and the point of tangency. (p.235)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Figure ko ek vertical line (V se centre O tak) ke around symmetric dekho. Upar se neeche chalo: <b>V</b> → apex distance <b>E</b> → curve ka beech wala point (apex) → mid-ordinate <b>M</b> → long chord ka beech → aur aage centre O. Toh E aur M dono isi ek line ke tukde hain — E curve ke <i>bahar</i> (V ki taraf), M curve ke <i>andar</i> (chord ki taraf)." },
      { k: "p", t: "Teen \"lengths\" alag-alag cheezein naapti hain: <b>tangent length</b> T₁ se V tak (seedhi line par), <b>length of curve l</b> T₁ se T₂ tak arc ke saath, aur <b>long chord L</b> T₁ se T₂ tak seedha. Hamesha L &lt; l &lt; 2T." },
      { k: "trap", t: "Deflection angle Δ, vertex par <b>back tangent ke extension</b> aur forward tangent ke beech ka angle hai — dono tangents ke beech ka andar wala angle (jo 180° − Δ hai) nahi. Centre par radii ke beech bhi wahi Δ banta hai, isliye sab formulas mein Δ/2 aata hai." },
    ] },

    /* ---------------------------------------------------------- formulas */
    { n: "", title: "Notes — Element formulas of a simple circular curve", hi: "सरल वृत्तीय वक्र के सूत्र", blocks: [
      { k: "h", t: "📘 Notes — p.235  (★ marked \"IMP\")" },
      { k: "eq", expr: "1) Length of curve:   l = π R Δ / 180", where: [["R", "radius of the curve"], ["Δ", "deflection angle, in degrees"]] },
      { k: "eq", expr: "2) Tangent length:   T = R tan(Δ/2)", where: [] },
      { k: "eq", expr: "3) Length of long chord:   L = 2R sin(Δ/2)", where: [] },
      { k: "eq", expr: "4) Apex distance:   E = R [sec(Δ/2) − 1]", where: [] },
      { k: "eq", expr: "5) Mid ordinate:   m = R [1 − cos(Δ/2)]", where: [] },
      { k: "p", t: "All five are boxed in the notes. (p.235)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Sab kuch centre O par bane right-angled triangles se aata hai, jinka angle Δ/2 hai. Triangle O–T₁–V mein T₁V tangent hai aur OT₁ = R, toh <b>T = R tan(Δ/2)</b> aur OV = R sec(Δ/2); OV mein se R ghatao toh apex distance <b>E</b>. Triangle O–T₁–(chord ka beech) mein aadhi chord = R sin(Δ/2) → <b>L = 2R sin(Δ/2)</b>, aur centre se chord ki doori R cos(Δ/2); R mein se ghatao toh mid-ordinate <b>m</b>. Length of curve sirf arc = R × (Δ in radian) = πRΔ/180." },
      { k: "trap", t: "πRΔ/180 mein Δ <b>degree</b> mein daalna hai (π/180 usi ka conversion hai). Aur calculator mein π ko 3.14 mat lo — R bada ho toh farq metres mein aata hai (neeche wale example ka Check dekho)." },
    ] },

    /* ---------------------------------------------------------- chainage and designation */
    { n: "", title: "Notes — Chainage of tangent points and degree of curve", hi: "स्पर्श बिंदुओं की चेनेज और वक्र की डिग्री", blocks: [
      { k: "h", t: "📘 Notes — p.236–237" },
      { k: "h", t: "Chainage of tangent points" },
      { k: "p", t: "Figure (p.236): vertex V at the top; the back tangent runs from T₁ to V with a double arrow labelled \"Tangent length T\"; the forward tangent runs from V down to T₂; the circular arc from T₁ to T₂ is labelled l; a dotted chord joins T₁ and T₂." },
      { k: "eq", expr: "Chainage of T₁ = Chainage of point of intersection − Tangent length", where: [] },
      { k: "eq", expr: "Chainage of T₂ = Chainage of T₁ + Length of curve", where: [] },
      { k: "p", t: "(p.236)" },
      { k: "h", t: "Designation of curve" },
      { k: "p", t: "A curve can be designated by its <b>radius 'R'</b> and its <b>degree 'D'</b>. (p.236)" },
      { k: "def", term: "Degree of curve", t: "The angle subtended at the centre by an arc or chord of <b>specified length</b>. (p.236)" },
      { k: "p", t: "Figure (p.236): a sector — arc at the top with an arrow labelled l along it; two radii meet at the centre; one radius is labelled R; the angle at the centre is labelled D." },
      { k: "h", t: "Relationship between radius and degree — arc definition (for highways)" },
      { k: "p", t: "If R is the radius and D is the degree of curve (30 m arc):<br>D × R = 30°<br>D × R × π/180° = 30<br>D = (30 × 180°)/(πR) = 1718.9/R ≃ <b>1719/R</b> — for 30 m arc (boxed)<br>D = <b>1146/R</b> — for 20 m arc (boxed). (p.236)" },
      { k: "note", t: "<b>Check:</b> the line \"D × R = 30°\" is shorthand. The arc length is R × (D in radians) = 30 m, i.e. R × D × π/180 = 30 m with D in degrees — which is the next line of the notes. 30 × 180/π = 1718.87 → 1718.9 ✓; 20 × 180/π = 1145.9 → 1146 ✓." },
      { k: "p", t: "Side note in red (p.236): \"Arc definition — 30 m / 20 m — for Highways\", with a narrow sector showing arc length 30 m at the top, radius R and central angle D." },
      { k: "h", t: "Chord definition (for railways)" },
      { k: "p", t: "If 'R' is the radius of curve and 'D' is its degree for a 30 m chord. (p.237)" },
      { k: "p", t: "Figure (p.237): an isosceles triangle / sector — a chord of 30 m at the top, split into 15 and 15 by a perpendicular from the centre; the two sides R and R meet at the centre at the bottom; central angle D, with the half-angle D/2 marked between a side and the bisector." },
      { k: "p", t: "sin(D/2) = 15/R<br>As the angle is very small, sin(D/2) = tan(D/2) = D/2 (radians)<br>D/2 = 15/R ⇒ (π/180°) × (D/2) = 15/R<br>D = 1718.9/R ≃ <b>1719/R</b> — for 30 m chord (boxed)<br>D = <b>1146/R</b> — for 20 m chord (boxed). (p.237)" },
      { k: "p", t: "Side note in red (Hindi, p.237): \"30m तक chord और arc में कोई फर्क नहीं पड़ेगा\" — up to 30 m, chord and arc make no difference." },
      { k: "note", t: "<b>Note</b> → As the degree of curve is <b>inversely proportional</b> to the radius of curve, for a <b>flat</b> curve the degree of curve will be <b>small</b>, and for a <b>sharp</b> curve (minimum straight reach) the degree of curve will be <b>large</b>. &nbsp; <b>D ∝ 1/R</b> (boxed). (p.237)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Degree of curve radius ka hi doosra naam hai — \"30 m chalne par direction kitni degree badli?\" Jitna chhota radius, utna tez mudna, utni badi D. Isliye D ∝ 1/R. Arc definition mein 30 m arc ke saath naapte hain, chord definition mein 30 m seedhi chord ke saath; chhote angle par sin(D/2) ≈ D/2 hone se dono se same formula 1718.9/R nikalta hai — wahi Hindi note keh raha hai." },
      { k: "p", t: "Chainage ka rule chapter ke §11.2 wale trap se judta hai: T₁ tak V se peeche aate ho (tangent length ghatao), lekin T₂ tak <b>curve ke saath</b> chalte ho (length of curve jodo), kyunki chainage road ke centre line ke saath naapi jaati hai." },
      { k: "trap", t: "Chainage of T₂ = chainage of P.I. + T likhna sabse common galti hai. Curve banne ke baad road V se hokar nahi jaati — T₂ ki chainage = chainage of T₁ + l." },
      { k: "real", t: "On site the P.I. chainage is known from the straight alignment; the tangent points T₁ and T₂ are first pegged by measuring the tangent length back and forward from V along each straight, and the chainage of every peg on and beyond the curve is then carried on from T₁ along the arc." },
    ] },

    /* ---------------------------------------------------------- worked example */
    { n: "", title: "Notes example — Simple curve with R = 1000 m, Δ = 60°", hi: "उदाहरण — R = 1000 m, Δ = 60°", blocks: [
      { k: "h", t: "📘 Notes — p.237–238" },
      { k: "eg",
        title: "Notes example — Elements, chainages and degree of a simple circular curve",
        given: "A simple circular curve having R = 1000 m, Δ = 60° and chainage of point of intersection = 1120.5 m. Determine the length of curve, tangent distance, apex distance, mid-ordinate, chainage of T₁ and T₂, and degree of curve for arc length 30 m.",
        steps: [
          { t: "Data", w: "R = 1000 m\nΔ = 60°" },
          { t: "Length of curve", w: "l = πRΔ/180 = 1046.66 m" },
          { t: "Tangent length", w: "T = R tan(Δ/2)\n= 1000 tan 30°\n= 577.35 m" },
          { t: "Apex distance", w: "E = R[sec(Δ/2) − 1]\n= 1000[sec 30° − 1]\n= 154.70 m" },
          { t: "Mid ordinate", w: "m = R[1 − cos(Δ/2)]\nM = 133.97 m" },
          { t: "Chainage of T₁", w: "= chainage of point of intersection − tangent length\n= 1120.5 − 577.35\n= 543.15 m" },
          { t: "Chainage of T₂", w: "= chainage of T₁ + length of curve\n= 543.15 + 1046.66\n= 1589.81 m" },
          { t: "Degree of curve for 30 m arc", w: "D = 1719/R = 1719/1000\nD = 1.719°" },
        ],
        ans: "l = 1046.66 m, T = 577.35 m, E = 154.70 m, M = 133.97 m, chainage of T₁ = 543.15 m, chainage of T₂ = 1589.81 m, D = 1.719° (p.237–238)",
      },
      { k: "note", t: "<b>Check:</b> the notes' length of curve 1046.66 m comes from taking π = 3.14 (3.14 × 1000 × 60/180 = 1046.67). With the true π: l = π × 1000 × 60/180 = <b>1047.20 m</b>. This carries into T₂: chainage of T₂ = 543.15 + 1047.20 = <b>1590.35 m</b> (notes: 1589.81 m, 0.54 m short). T = 577.35 m, E = 154.70 m, M = 133.97 m, chainage of T₁ = 543.15 m and D = 1718.9/1000 = 1.719° all re-work correctly." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Order yaad rakho: pehle <b>T</b> (kyunki T₁ ki chainage ke liye chahiye), phir <b>l</b> (T₂ ke liye), aur E, m, L sirf curve ki shape batate hain — chainage mein unka koi kaam nahi. Δ/2 = 30° hone se sab values ek baar nikaal lo: tan 30° = 0.5774, sec 30° = 1.1547, cos 30° = 0.8660." },
      { k: "p", t: "Is example mein Δ = 60° hone se long chord = 2R sin 30° = R = 1000 m — notes mein yeh nahi poocha gaya, par apna answer cross-check karne ka aasaan tareeka hai: l (1047.20) long chord (1000) se thoda bada, aur 2T (1154.70) se chhota hona chahiye." },
      { k: "trap", t: "Bade radius wale curves mein π = 3.14 lene se l mein lagbhag 0.05% ki galti aati hai — yahan 0.54 m — aur yeh galti T₂ aur aage ki har chainage mein chali jaati hai. Calculator ka π button use karo." },
    ] },

    /* ---------------------------------------------------------- revision */
    { n: "", title: "Notes revision — Curves (p.231–238)", hi: "पुनरावृत्ति — वक्र", blocks: [
      { k: "h", t: "✅ Key points from the notes" },
      { k: "list", items: [
        "✅ Curve: arc of finite radius between intersecting straights to gradually negotiate a change in direction; horizontal or vertical. (p.231)",
        "✅ Horizontal curves: simple circular, compound, reverse, transition, broken back. (p.231)",
        "✅ Simple circular curve: one arc of a circle tangential to two straights. (p.231)",
        "✅ Compound: two arcs of different radius, centres on the same side of the common tangent. (p.231–232)",
        "✅ Reverse / S / serpentine: two arcs (equal or different radius) with opposite curvature joined together. (p.232)",
        "✅ Transition: radius varies from ∞ to R; between a straight and a circular curve. (p.232–233)",
        "✅ Broken back: two same-direction arcs joined by a straight common tangent (figure). (p.233)",
        "✅ Back (rear) tangent AT₁ before the curve; forward tangent T₂B after it; vertex / P.I. where they meet; Δ = angle between back and forward tangents. (p.233–234)",
        "✅ P.C. on back tangent at beginning; P.T. on forward tangent at end; T₁V = T₂V = tangent length. (p.234)",
        "✅ Apex (external) distance E: P.I. to apex of curve; long chord: P.C. to P.T.; mid ordinate: centre of long chord to apex; l: arc from P.C. to P.T. (p.234–235)",
        "✅ l = πRΔ/180; T = R tan(Δ/2); L = 2R sin(Δ/2); E = R[sec(Δ/2) − 1]; m = R[1 − cos(Δ/2)]. (p.235)",
        "✅ Chainage of T₁ = chainage of P.I. − T; chainage of T₂ = chainage of T₁ + l. (p.236)",
        "✅ Degree of curve: angle at the centre subtended by an arc or chord of specified length; curve designated by R and D. (p.236)",
        "✅ Arc definition (highways): D = 1718.9/R ≃ 1719/R for 30 m arc; D = 1146/R for 20 m arc. (p.236)",
        "✅ Chord definition (railways): sin(D/2) = 15/R ≈ D/2 → D ≃ 1719/R for 30 m chord; 1146/R for 20 m chord; up to 30 m, chord and arc give no difference. (p.237)",
        "✅ D ∝ 1/R: flat curve → small D; sharp curve → large D. (p.237)",
        "✅ Example R = 1000 m, Δ = 60°, P.I. at 1120.5 m: notes give l = 1046.66 m, T = 577.35 m, E = 154.70 m, M = 133.97 m, T₁ = 543.15 m, T₂ = 1589.81 m, D = 1.719° (with true π: l = 1047.20 m, T₂ = 1590.35 m). (p.237–238)",
      ] },
    ] },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
