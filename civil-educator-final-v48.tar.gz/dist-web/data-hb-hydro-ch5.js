/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 5
   Infiltration
   Sources: S2 p.37-47 (infiltration, measurement, Horton's
   equation, classification, φ/W-index), S3 p.1-12 (infiltrometer
   comparison, φ/W-index worked problems), S1 p.2 (percolation /
   seepage definitions, pulled in because this chapter's brief
   explicitly needs them and no other source in range states them).
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-5",
    n: 5,
    title: "Infiltration",
    hi: "अंतःस्रवण (Infiltration)",
    blurb: "Infiltration vs percolation vs seepage, infiltration capacity and cumulative infiltration, single/double-ring infiltrometers and the rain simulator, Horton's equation with its two integrated cases, the infiltration-capacity classification table, φ-index and W-index — and every worked numerical across both sources, kept in full.",
    mins: 42,
    sections: [

      /* ============================================================ 5.1 */
      {
        n: "5.1",
        title: "Infiltration, Percolation and Seepage — Definitions and Infiltration Capacity",
        hi: "अंतःस्रवण, रिसन और सीपेज — परिभाषाएँ और अंतःस्रवण क्षमता",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.2, S2 p.37" },
          { k: "def", term: "Infiltration", t: "The flow of water into the ground through the soil surface. It is a <b>vertical</b> movement, and it occurs close to the surface — an <b>interface</b> (the wetted surface zone) is essential to the infiltration process. (S2 p.37; S1 p.2)" },
          { k: "def", term: "Percolation", t: "The long-term movement of already-infiltrated water downward through the soil or rock strata, beyond the surface interface, typically down to the ground water table. (S1 p.2)" },
          { k: "def", term: "Seepage", t: "The movement of infiltrated water in <b>any direction except vertical</b> (i.e. lateral/oblique movement within the soil). (S1 p.2)" },
          { k: "note", t: "Infiltration and percolation are both processes of water moving through the pore spaces of the soil — the difference is only where in the profile they happen: infiltration is the entry at the surface (interface), percolation is the continued downward travel afterward, further down toward the rock strata / water table. Seepage is distinguished by <b>direction</b>, not depth — it is whatever movement is not vertical. (S1 p.2)" },
          { k: "h", t: "📘 Notes — S2 p.37" },
          { k: "p", t: "Let <b>i</b> = intensity of rainfall (cm/hr), <b>F</b> = actual rate of infiltration (cm/hr), and <b>Fp</b> = infiltration capacity of the soil (cm/hr). The actual rate of infiltration is governed by which of i and Fp is smaller:" },
          { k: "eq", expr: "F = i,  when i ≤ Fp  (rainfall fully infiltrates, no runoff)  ;  F = Fp,  when i ≥ Fp  (soil infiltrates at its capacity; the excess (i − Fp) becomes runoff)", where: [
            ["F", "actual rate of infiltration at that instant (cm/hr)"],
            ["Fp", "infiltration capacity — the soil's maximum possible rate at that time (cm/hr)"],
          ] },
          { k: "def", term: "Infiltration Capacity (fp)", t: "The maximum rate at which a given soil, at a given time, can absorb water. Units: cm/hr or mm/hr. It is not a constant — it falls as the soil wets up (see Horton's equation, §5.3). (S2 p.37)" },
          { k: "def", term: "Cumulative Infiltration Capacity (Fp)", t: "The accumulated depth of infiltrated water since the start of the process — i.e. the volume (per unit area) that has gone in, not the instantaneous rate. Units: cm or mm.", },
          { k: "eq", expr: "Fp = ∫₀ᵗ fp · dt", where: [
            ["Fp", "cumulative infiltration capacity up to time t (cm or mm)"],
            ["fp", "instantaneous infiltration capacity (cm/hr)"],
            ["t", "time since the start of infiltration (hr)"],
          ] },
          { k: "p", t: "Plotted against time, fp vs t falls steeply at first and flattens out as the soil saturates — a <b>sandy soil</b>'s curve stays higher throughout (it keeps absorbing faster) than a <b>clayey soil</b>'s curve, which drops lower and flattens sooner. Fp (cumulative) at any time is simply the <b>area under the fp-vs-t curve</b> up to that time. (S2 p.37)" },
          { k: "h", t: "📘 Notes — S2 p.42" },
          { k: "cmp", t: "Infiltration-capacity classification (S2 p.42)", cols: ["Class"], rows: [
            ["< 2.5 mm/hr", "Very low"],
            ["2.5 mm/hr – 12.5 mm/hr", "Low"],
            ["12.5 mm/hr – 25 mm/hr", "Medium"],
            ["> 25 mm/hr", "High"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "F aur Fp ko confuse mat karo — F woh hai jo <b>actually</b> ho raha hai is instant par, Fp woh hai jo soil <b>kar sakti hai</b> (uski capacity/limit). Jab rain halki hai (i kam hai Fp se), poora pani soak ho jaata hai, F=i. Jab rain tez hai (i zyada hai Fp se), soil apni max speed (Fp) par hi absorb karegi, baaki sab runoff ban jaayega. Isi logic se Fp hamesha ek ceiling hai, F us ceiling ke neeche ya usi par hota hai, kabhi usse zyada nahi." },
          { k: "trap", t: "Infiltration capacity (fp, lowercase, a <b>rate</b> in cm/hr) aur cumulative infiltration capacity (Fp, uppercase, a <b>depth/volume</b> in cm) — dono alag units hain aur dono alag symbols se likhe jaate hain notes mein. Fp = ∫fp·dt hai, matlab Fp curve ke neeche ka area hai, fp khud curve hai." },
        ],
      },

      /* ============================================================ 5.2 */
      {
        n: "5.2",
        title: "Measuring Infiltration — Infiltrometers and the Rain Simulator",
        hi: "अंतःस्रवण मापन — इन्फिल्ट्रोमीटर और रेन सिम्युलेटर",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.38-39" },
          { k: "p", t: "Infiltration is measured by field methods: (1) <b>Infiltrometers</b> — (a) tube-type or single-ring infiltrometer, (b) double-ring infiltrometer; (2) <b>Rain simulator</b> (flooding-type infiltrometer); (3) <b>Hydrograph analysis</b> — infiltration is inferred by analysing a catchment's rainfall-runoff hydrograph (no further procedural detail recorded in these notes). (S2 p.38)" },
          { k: "def", term: "Single Ring (Tube-type) Infiltrometer", t: "A ring of 30 cm diameter and 60 cm height is driven into the ground to a depth of 50 cm (leaving 10 cm projecting above ground level). Water is poured into the ring, and the depth of infiltration is recorded at regular time intervals. The infiltration capacity of the soil at each interval is the depth infiltrated divided by that time interval. (S2 p.38)" },
          { k: "def", term: "Double Ring Infiltrometer", t: "Two concentric rings — an outer ring of 60 cm diameter and an inner ring of 30 cm diameter, both 25 cm high — are driven into the ground together. Water is ponded in the <b>outer</b> ring first; this ring acts as a jacket layer, preventing lateral spreading of water from the inner ring. Only then is infiltration read from the <b>inner</b> ring, so that the measured infiltration is purely vertical. (S2 p.38)" },
          { k: "real", t: "The whole reason the double-ring design exists is lateral spreading: in a single ring, water seeping outward and sideways from the ring's edge inflates the measured infiltration rate (the ground isn't being wetted purely vertically underneath the ring). The outer ring's ponded water keeps the soil around the inner ring already saturated laterally, so whatever the inner ring records is genuinely one-dimensional, vertical infiltration — a cleaner, more representative figure for design use." },
          { k: "def", term: "Rain Simulator (flooding-type infiltrometer)", t: "A small plot of land, 2 m × 4 m, is fitted with a series of nozzles along its longer side. The nozzles drop simulated rain from a height of 2 m and can produce a range of rainfall intensities. Surface runoff from the plot is collected and measured. Experiments are run at various intensities and durations; using the water-budget equation, the infiltration rate and its variation with time are back-calculated from the measured rainfall input and runoff output. (S2 p.39; S3 p.1)" },
          { k: "note", t: "<b>Flooding-type infiltrometer vs rain simulator:</b> the infiltration rate measured by a flooding-type infiltrometer (single/double ring, where water is simply ponded on the surface) is <b>always higher</b> than the infiltration rate measured by a rain simulator on the same soil, for the same reason a ring under-represents real rainfall — ponded water has no raindrop impact to compact and partially seal the surface, whereas a rain simulator's falling drops strike the soil the way natural rain does, so it reproduces the sealing/crusting effect that slightly lowers the real infiltration rate. (S3 p.1)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno methods same hi cheez (infiltration capacity) maapne ki koshish karte hain, par alag-alag tareeke se — ring methods seedha pani daal ke depth/time naapte hain (direct), rain simulator natural rainfall ko imitate karta hai aur runoff se back-calculate karta hai (indirect, par zyada realistic), aur hydrograph analysis poore catchment ke scale par kaam karta hai. Field mein jo bhi method use karo, double-ring hamesha single-ring se zyada reliable mana jaata hai kyunki usme lateral-spreading ka error minimise ho jaata hai." },
        ],
      },

      /* ============================================================ 5.3 */
      {
        n: "5.3",
        title: "Horton's Infiltration Equation — Derivation and the Two Cases",
        hi: "हॉर्टन का अंतःस्रवण समीकरण — व्युत्पत्ति और दो स्थितियाँ",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.39-40" },
          { k: "p", t: "When the rainfall intensity i exceeds the infiltration capacity fp (i.e. i > fp), the actual infiltration rate equals the infiltration capacity itself: f = fp. Plotted against time, fp starts at a high initial value fo, falls off (roughly exponentially) and flattens out to a constant value fc once the soil reaches a steady saturated state at time tc; beyond tc it stays at fc. (S2 p.39)" },
          { k: "def", term: "Horton's Equation", t: "The infiltration capacity at any time t, for 0 ≤ t ≤ tc:" },
          { k: "eq", expr: "fp = fc + (fo − fc)·e^(−Kh·t)      [0 ≤ t ≤ tc]", where: [
            ["fp", "infiltration capacity at time t (cm/hr)"],
            ["fo", "initial infiltration capacity, at t = 0 (cm/hr)"],
            ["fc", "constant / steady-state infiltration capacity, reached at time tc (cm/hr)"],
            ["Kh", "Horton's decay constant (time⁻¹, i.e. hr⁻¹)"],
            ["t", "duration of the rainfall or storm, from the start (hr)"],
          ] },
          { k: "h", t: "📘 Notes — S2 p.40 — Case 1: 0 ≤ t ≤ tc" },
          { k: "p", t: "The cumulative infiltration capacity Fp up to any time t (≤ tc) is the area bounded by the fp-vs-t curve, i.e. the integral of Horton's equation:" },
          { k: "eq", expr: "F̄p = ∫₀ᵗ [fc + (fo − fc)·e^(−Kh·t)] dt = fc·t + [(fo − fc)/Kh]·[1 − e^(−Kh·t)]", where: [] },
          { k: "note", t: "<b>V. Imp (as marked in the source):</b> for large Kh·t, e^(−Kh·t) becomes very small (→ 0), so the bracket [1 − e^(−Kh·t)] → 1, and the formula simplifies to the commonly-used approximate form: <b>F̄p ≈ fc·t + (fo − fc)/Kh</b>. (S2 p.40)" },
          { k: "h", t: "📘 Notes — S2 p.40 — Case 2: t > tc" },
          { k: "p", t: "When the storm duration t is longer than tc (the time to reach the steady state), the area under the curve splits into two parts: A1, the area from 0 to tc (same exponential-decay shape as Case 1), plus A2, a plain rectangle from tc to t at the constant height fc (since fp no longer changes once it has flattened out)." },
          { k: "eq", expr: "Fp = A1 + A2 = ∫₀^tc fp·dt + fc·(t − tc)", where: [] },
          { k: "eq", expr: "Fp = fc·tc + (fo − fc)/Kh + fc·(t − tc)      [for large Kh and tc, i.e. using the same V.Imp approximation on the A1 part]", where: [] },
          { k: "dia", id: "hb-hydro-horton", cap: "Horton's infiltration-capacity curve — fo decays to fc at time tc; the shaded Case 1 area is the cumulative infiltration up to tc, and Case 2 simply tacks on a rectangle fc·(t − tc) for any time beyond tc." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Horton ka equation bas yeh keh raha hai ki infiltration capacity exponentially decay karti hai fo se fc tak, aur Kh batata hai yeh decay kitni fast hai. Case 1 aur Case 2 mein formula alag nahi hai — Case 2 sirf Case 1 ke upar ek extra rectangle add kar deta hai, kyunki ek baar fp apni steady value (fc) par pahunch jaaye, uske baad woh seedha, flat line hai — uska area nikalna integration nahi, simple multiplication (fc × extra time) hai." },
          { k: "trap", t: "V.Imp approximation (F̄p ≈ fc·t + (fo−fc)/Kh) sirf tab use karo jab Kh·t genuinely bada ho (e^(−Kht) negligible ho) — chhote t ya chhote Kh ke liye yeh approximation galat answer dega, poora exponential term [1−e^(−Kht)] hi use karna padega. (S2 p.40)" },
        ],
      },

      /* ============================================================ 5.4 */
      {
        n: "5.4",
        title: "Horton's Equation — Worked Examples",
        hi: "हॉर्टन के समीकरण पर हल किए गए उदाहरण",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.40-41" },
          { k: "eg", title: "Idealised infiltration-capacity curve: infiltration in the last 20 minutes of a storm", given: "Infiltration capacity curve: fp = 3 + e^(−2t) cm/hr, for a storm of 60 min total duration. Find the infiltration capacity (depth) in the last 20 minutes of the storm.", steps: [
            { t: "The last 20 minutes of a 60-min storm run from t = 40 min to t = 60 min, i.e. from t = 40/60 hr to t = 1 hr", w: "t: 40/60 hr → 1 hr" },
            { t: "Depth infiltrated in that window is the definite integral of fp over it", w: "Fp = ∫_(40/60)^1 (3 + e^(−2t)) dt" },
            { t: "Antiderivative of (3 + e^(−2t))", w: "∫(3 + e^(−2t)) dt = 3t − e^(−2t)/2" },
            { t: "Evaluate at the upper limit, t = 1", w: "3(1) − e^(−2)/2 = 3 − (0.1353)/2 = 3 − 0.0677 = 2.9323" },
            { t: "Evaluate at the lower limit, t = 0.667 hr", w: "3(0.667) − e^(−1.333)/2 = 2.0 − (0.2636)/2 = 2.0 − 0.1318 = 1.8682" },
            { t: "Subtract to get the depth over the last 20 minutes", w: "Fp = 2.9323 − 1.8682 = 1.0641" },
          ], ans: "Fp ≈ 1.06 cm (infiltrated in the last 20 minutes)" },
          { k: "note", t: "<b>Check:</b> the source's working stops right after setting up the evaluated bracket, [3t + e^(−2t)/(−2)] from 0.67 to 1, without carrying it through to a final number. The steps above simply complete that same bracket arithmetically — the setup itself matches the source exactly. (S2 p.40-41)" },
          { k: "h", t: "📘 Notes — S2 p.41" },
          { k: "eg", title: "Q.37 (WB) — runoff from a storm using Horton's Case-2 formula and an evaporation loss", given: "Catchment area A = 1.8 km². Total precipitation P = 24 cm. Horton's constants: fo = 2 cm/hr, fc = 0.5 cm/hr, tc = 3 hr, Kh = 5 hr⁻¹. Pan evaporation Ep = 0.8 cm, Pan coefficient Cp = 0.7. Find the runoff.", steps: [
            { t: "Cumulative infiltration by the Case-2 formula (storm runs 3 hr beyond tc, i.e. total duration 6 hr)", w: "Fp = [fc·t + ((fo − fc)/Kh)(1 − e^(−Kh·t))] + fc·(t − tc)" },
            { t: "Substitute the given values (first bracket evaluated at t = tc = 3 hr)", w: "Fp = 0.5×3 + [(2 − 0.5)/5](1 − e^(−5×3)) + 0.5(3)" },
            { t: "0.5×3 = 1.5; the exponential term e^(−15) is negligible, so (1.5/5)(1) = 0.3; plus 0.5×3 = 1.5", w: "Fp = 1.5 + 0.3 + 1.5" },
            { t: "Sum the infiltration loss", w: "Fp = 3.3 cm" },
            { t: "Evaporation loss, using the actual reservoir evaporation = Cp × Ep", w: "Evaporation loss = 0.7 × 0.8 = 0.56 cm" },
            { t: "Total abstraction (loss) = infiltration + evaporation", w: "Total loss = 3.3 + 0.56 = 3.86 cm" },
            { t: "Runoff = total precipitation − total loss", w: "Runoff = 24 − 3.86 = 20.14 cm" },
          ], ans: "Runoff = 20.14 cm" },
          { k: "h", t: "📘 Notes — S2 p.41" },
          { k: "eg", title: "Q.39 — finding Horton's decay constant Kh from the slope of a semi-log plot", given: "A plot of t (y-axis) against log(fp − fc) (x-axis) is a straight line of slope m = −0.4605. Find Kh.", steps: [
            { t: "Start from Horton's equation and isolate the exponential term", w: "fp = fc + (fo − fc)e^(−Kh·t)  ⇒  (fp − fc) = (fo − fc)e^(−Kh·t)" },
            { t: "Take log (base 10) of both sides", w: "log(fp − fc) = log(fo − fc) + log[e^(−Kh·t)] = log(fo − fc) − Kh·t·log₁₀e" },
            { t: "Rearrange to the linear form t = m·log(fp − fc) + c, matching the plotted straight line", w: "t = [−1/(Kh·log₁₀e)]·log(fp − fc) + [1/(Kh·log₁₀e)]·log(fo − fc)" },
            { t: "The slope of that line is therefore −1/(Kh·log₁₀e); equate to the given slope", w: "−0.4605 = −1/(Kh·log₁₀e)" },
            { t: "Solve for Kh using log₁₀e ≈ 0.4343", w: "Kh = 1/(0.4605 × 0.4343) ≈ 1/0.2000" },
          ], ans: "Kh = 5 hr⁻¹" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Q.39 ek bahut useful trick hai jab Kh seedha nahi diya ho: Horton's equation ko log lekar linear (y=mx+c) form mein convert kar do, phir graph ka slope seedha Kh de deta hai. Yeh exact wahi technique hai jo kisi bhi exponential-decay data (fo se fc tak) ko experimentally fit karne mein use hoti hai." },
        ],
      },

      /* ============================================================ 5.5 */
      {
        n: "5.5",
        title: "φ-index and W-index — Definitions, Classification and the φ ≥ W Relation",
        hi: "φ-इंडेक्स और W-इंडेक्स — परिभाषाएँ और φ ≥ W संबंध",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.42-45, S3 p.1-2" },
          { k: "def", term: "W-index", t: "The average infiltration rate over the <b>entire</b> duration of the storm — total infiltration divided by total storm duration. Units: cm/hr or mm/hr." },
          { k: "eq", expr: "W-index = Total infiltration (cm) / Total duration of storm (hr)", where: [] },
          { k: "def", term: "φ-index", t: "The average rate of loss such that the volume of rainfall in excess of that rate equals the volume of direct runoff — equivalently, the average infiltration rate below which rainfall simply infiltrates (no runoff), such that total rainfall volume minus runoff volume is accounted for. In formula form (strict): total infiltration occurring <b>during the periods when rainfall intensity exceeds φ itself</b> (periods of rainfall excess), divided by the duration of just those excess periods. (S2 p.42, 44; S3 p.1)" },
          { k: "eq", expr: "φ-index = (Total infiltration during periods of rainfall excess) / (Time period during which rainfall excess occurs)", where: [] },
          { k: "p", t: "Derivation sketch, using a storm split into a non-excess sub-period (duration t1, where the whole of the rainfall P1 infiltrates, I1 = P1) and an excess sub-period (duration t2, where precipitation P2 splits into infiltration I2 and runoff Q2, so P2 = I2 + Q2): (S2 p.42)" },
          { k: "eq", expr: "W-index = (I1 + I2)/(t1 + t2)   [uses the whole storm]  ;  φ-index = I2/t2   [uses only the excess sub-period]", where: [] },
          { k: "p", t: "Since I2 = P2 − Q2, substituting gives the practically useful runoff formula:" },
          { k: "eq", expr: "Runoff (Q) = Total rainfall in the period where rainfall excess occurs − φ-index × (duration of that excess period)", where: [] },
          { k: "cmp", t: "Hyetograph form of the same two indices, split across several sub-storms i1…i6 over times t1…t6, of which i2, i3, i4 exceed φ (S2 p.44)", cols: ["Formula"], rows: [
            ["W-index", "(I1+I2+I3+I4+I5+I6) / (t1+t2+t3+t4+t5+t6)  — averages over ALL sub-storms"],
            ["φ-index", "(I2+I3+I4) / (t2+t3+t4)  — averages only over the sub-storms that exceed φ"],
          ] },
          { k: "note", t: "<b>φ-index ≥ W-index, always</b> (S2 p.44, boxed in red in the source; S3 p.2 states it as a strict φ-index &gt; W-index). φ-index only looks at the stronger storms (those producing rainfall excess, i.e. the ones with the most infiltration), while W-index averages in the weaker storms too — a weak storm contributes very little infiltration but still takes up just as much time in the denominator, which pulls the average down. Equality (φ = W) holds only in the special case where <b>every</b> sub-storm produces rainfall excess, i.e. there is nothing weak to drag the average down. (S2 p.44-45)" },
          { k: "note", t: "<b>Two different W-index formulas appear across the sources — both kept here:</b> S2 (p.42) defines W-index simply as Total infiltration / Total duration, with no separate initial-loss term. S3 (p.2) instead gives <b>W-index = (P − R − Initial loss)/t</b>, explicitly subtracting an initial-loss depth before dividing. Neither source reconciles the two forms; S2's plain form is what every worked example in this chapter that computes a W-index actually uses (no example subtracts a separate initial loss when computing W). See each source's own page for its own form." },
          { k: "note", t: "<b>Two φ-index recipes also appear, and which one a given worked problem uses matters:</b> (a) the strict, iterative excess-duration formula — φ = (total infiltration in the excess period)/(duration of just that excess period) — used whenever some rainfall increments fall below φ and must be identified and excluded first (this is the method in §5.5's derivation above, and in the IAS/IES and Q.51 problems of §5.7); (b) a quicker single-pass formula, <b>φ-index = (P − R)/t</b>, dividing by the <b>total</b> storm duration t with no exclusion step (S3 p.2, and used throughout §5.6 and §5.8's problems). Formula (b) is only exactly correct when every increment of the storm already produces rainfall excess (nothing to exclude) — otherwise it is a first trial that may need refining by formula (a), exactly as the IAS/IES worked example in §5.7 demonstrates explicitly." },
          { k: "trap", t: "★ φ-index should never be less than the infiltration capacity of the soil. ★ If the runoff (or rainfall excess) for a storm is zero, the φ-index does not exist for that storm — there is nothing to average over. (S2 p.44)" },
          { k: "note", t: "When no rainfall-runoff data is available at all to compute φ-index for a catchment, it may be assumed as <b>φ-index = 0.1 cm/hr</b> for the purpose of estimating flood discharge. (S3 p.3)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Dono indices ek hi sawaal ka jawab dete hain — 'storm ke dauraan average kitna infiltrate hua' — bas dono ka 'average' lene ka tareeka alag hai. W-index <b>sab</b> kuch include karta hai (weak aur strong storms dono), φ-index sirf <b>strong</b> storms include karta hai (jo runoff produce karte hain), isi liye φ ≥ W hamesha. Formula yaad rakhne ka tareeka: φ ka 't' sirf excess-period ka hai, W ka 't' poore storm ka hai — agar koi sawaal yeh clear nahi karta ki konsa 't' use karna hai, to pehle total-duration wala simple formula try karo, phir check karo ki koi sub-storm φ se kam to nahi (agar hai, to usko exclude karke phir se calculate karo)." },
        ],
      },

      /* ============================================================ 5.6 */
      {
        n: "5.6",
        title: "φ-index Worked Examples I — Direct Application (excess-duration method)",
        hi: "φ-इंडेक्स हल किए गए उदाहरण I — प्रत्यक्ष प्रयोग",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.43" },
          { k: "eg", title: "Runoff from three consecutive 2-hour storms", given: "Rainfall in three consecutive 2-hour storms is 4 cm, 6 cm and 2 cm respectively. φ-index = 2.5 cm/hr. Find the runoff.", steps: [
            { t: "Convert each storm's rainfall to an intensity (duration 2 hr each)", w: "i1 = 4/2 = 2 cm/hr;  i2 = 6/2 = 3 cm/hr;  i3 = 2/2 = 1 cm/hr" },
            { t: "Compare each to φ = 2.5 cm/hr: i1 (2) and i3 (1) are both below φ — no rainfall excess, excluded; only i2 (3) exceeds φ", w: "Only the 2nd storm (6 cm in 2 hr) produces rainfall excess" },
            { t: "Runoff = rainfall of the excess storm − φ-index × its duration", w: "Runoff = 6 − 2.5×2 = 6 − 5" },
          ], ans: "Runoff = 1 cm" },
          { k: "eg", title: "Runoff from five consecutive half-hour storms", given: "Rainfall in 5 consecutive half-hour storms is 2, 3, 1, 4 and 5 cm respectively. φ-index = 2 cm/hr. Find the runoff.", steps: [
            { t: "Convert each half-hour (0.5 hr) rainfall to intensity", w: "i1=4, i2=6, i3=2, i4=8, i5=10 cm/hr (dividing each by 0.5 hr)" },
            { t: "Compare to φ = 2 cm/hr: i3 = 2 cm/hr is not greater than φ, so excluded; i1, i2, i4, i5 all exceed φ", w: "Storms 1, 2, 4, 5 (totalling 2+3+4+5 = 14 cm) produce rainfall excess, over 4 × 0.5 hr = 2 hr total" },
            { t: "Runoff = sum of excess-storm rainfall − φ-index × total excess duration", w: "Runoff = (2+3+4+5) − 2cm/hr × 2hr = 14 − 4" },
          ], ans: "Runoff = 10 cm" },
          { k: "eg", title: "Runoff from three consecutive 20-minute storms", given: "Rainfall in three consecutive 20-minute storms is 2 cm, 3 cm and 1 cm respectively. φ-index = 4 cm/hr. Find the runoff.", steps: [
            { t: "Convert each 20-min (1/3 hr) rainfall to intensity", w: "i1 = 2×60/20 = 6 cm/hr;  i2 = 3×60/20 = 9 cm/hr;  i3 = 1×60/20 = 3 cm/hr" },
            { t: "Compare to φ = 4 cm/hr: i1 (6) and i2 (9) exceed φ; i3 (3) does not — excluded", w: "Storms 1 and 2 (totalling 2+3 = 5 cm) produce rainfall excess, over 2×20 = 40 min = 40/60 hr" },
            { t: "Runoff = excess rainfall − φ-index × excess duration", w: "Runoff = (2+3) − 4 × (40/60) = 5 − 2.667" },
          ], ans: "Runoff ≈ 2.33 cm" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno examples mein pattern same hai: (1) har storm ki intensity nikaalo, (2) jo φ se kam hai usse pura ignore karo (woh sab infiltrate ho gaya, zero runoff), (3) baaki (excess) storms ke rainfall ka sum lo aur usse φ×(unki combined duration) minus karo. Yeh hi exact formula hai jo §5.5 mein derive hua tha." },
        ],
      },

      /* ============================================================ 5.7 */
      {
        n: "5.7",
        title: "φ-index Worked Examples II — Iterative Method on Real Storm Data",
        hi: "φ-इंडेक्स हल किए गए उदाहरण II — पुनरावृत्त विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.45-46 — IAS-87 / IES-2014" },
          { k: "eg", title: "IAS-87(3) / IES-2014(5) — φ-index from an 8-hour hyetograph, by iteration", given: "A storm with 15.0 cm total precipitation produces a direct runoff of 8.7 cm, over 8 hours, with incremental hourly rainfall (cm): 0.6, 1.35, 2.25, 3.45, 2.70, 2.4, 1.5, 0.75. (i) Estimate the φ-index. (ii) What is the difference between W-index and φ-index?", steps: [
            { t: "First trial — assume the whole 8-hr storm produces rainfall excess, using Runoff = P − φ×t", w: "8.7 = 15 − φ×8  ⇒  φ = (15 − 8.7)/8 = 6.3/8" },
            { t: "First-trial φ-index", w: "φ ≈ 0.7875 cm/hr" },
            { t: "Also compute the W-index for comparison: total infiltration = total P − total R", w: "Total infiltration = 15 − 8.7 = 6.3 cm" },
            { t: "W-index = total infiltration / total duration", w: "W-index = 6.3/8 = 0.7875 cm/hr (the notes print 0.785)" },
            { t: "The first trial is numerically the same as this W-index (both 6.3/8 = 0.7875 cm/hr), so it cannot be accepted as the φ-index until the hyetograph is checked: the hourly values 0.6 cm/hr and 0.75 cm/hr are both below this φ, so they do NOT produce rainfall excess and must be excluded from the denominator on a second pass", w: "Exclude the 1st hour (0.6 cm) and the 8th hour (0.75 cm); 6 hours remain" },
            { t: "Recompute φ-index using only the infiltration and duration of the remaining (excess-producing) 6 hours: subtract the excluded hours' rainfall (which is pure infiltration, no runoff) from total infiltration, and divide by the remaining 6 hr", w: "φ = [6.3 − (0.75 + 0.6)] / 6 = (6.3 − 1.35)/6 = 4.95/6" },
          ], ans: "φ-index = 0.825 cm/hr (refined, second-pass value)" },
          { k: "note", t: "<b>Correction (v45):</b> 6.3/8 = <b>0.7875</b> cm/hr, not 0.785 as printed in the notes for the W-index — so the first-trial φ and the W-index are the same number here, and the notes' remark that φ is \"barely above\" W is only a rounding artefact. The final φ-index, 0.825 cm/hr, is correct: all six remaining hourly depths (1.35 to 3.45 cm) exceed it, and Σ(i − 0.825) over them = 8.7 cm. (S2 p.45)" },
          { k: "note", t: "<b>Check:</b> the source writes \"∴ total I = 15 − 8.7 ⇒ 6.36 cm\", which is an arithmetic slip — 15 − 8.7 = 6.3, not 6.36. The correct value, 6.3 cm, is what the source itself then actually carries forward into the very next line's W-index calculation (6.3/8 = 0.785) and into the final φ-index refinement above, so the 6.36 figure is an isolated transcription/arithmetic error that does not propagate into the final answer. (S2 p.45)" },
          { k: "p", t: "Verification given in the source: with φ = 0.825 cm/hr over the 6 excess hours, Runoff = Σ(hourly rainfall − φ) for the 6 excess hours = (1.35−φ)+(2.25−φ)+(3.45−φ)+(2.70−φ)+(2.4−φ)+(1.5−φ) = 8.7 cm, which matches the given runoff exactly, confirming the refined φ-index. (S2 p.46)" },
          { k: "h", t: "📘 Notes — S2 p.46 — Q.51 (WB)" },
          { k: "eg", title: "Q.51 (WB) — φ-index and W-index from an accumulated-rainfall record", given: "Accumulated rainfall (mm) at t = 0, 2, 4, 6, 8, 10, 12, 14 hr is 0, 6, 17, 57, 70, 81, 87, 90. Total direct-runoff volume = 1.2×10⁶ m³ over a catchment area of 30 km².", steps: [
            { t: "Convert accumulated rainfall to incremental rainfall per 2-hr interval", w: "Increments (mm): 6, 11, 40, 13, 11, 6, 3" },
            { t: "Convert each increment to an intensity by dividing by the 2-hr interval", w: "i (mm/hr): 3, 5.5, 20, 6.5, 5.5, 3, 1.5" },
            { t: "Total rainfall = sum of all increments (or the last accumulated value)", w: "Total P = 90 mm" },
            { t: "Runoff depth = runoff volume / catchment area", w: "Runoff = 1.2×10⁶ m³ / 30×10⁶ m² = 0.04 m = 40 mm" },
            { t: "W-index = total infiltration / total duration = (P − R)/T", w: "W = (90 − 40)/14 = 50/14" },
            { t: "W-index result", w: "W ≈ 3.57 mm/hr" },
            { t: "For φ-index: identify which increments exceed the threshold and produce excess — the middle four increments (11, 40, 13, 11 mm, i.e. the 5.5, 20, 6.5, 5.5 mm/hr intensities) are the ones circled as excess-producing in the source, over 4×2 = 8 hr", w: "Runoff = (11+40+13+11) − φ×8 = 75 − 8φ" },
            { t: "Set equal to the known runoff (40 mm) and solve for φ", w: "40 = 75 − 8φ  ⇒  φ = 35/8" },
          ], ans: "W-index ≈ 3.57 mm/hr;  φ-index = 4.375 mm/hr" },
          { k: "note", t: "<b>Check:</b> the source's intermediate line \"Rainfall = (1.2×10⁶ m³)/(30×10⁶ m²) = 0.4 m\" has a misplaced decimal — 1.2×10⁶/30×10⁶ = 0.04 m (40 mm), not 0.4 m. The source's very next line, \"Runoff = 40 cm\" (unit should read mm, consistent with the mm-based table), together with its subsequent W-index line (90 − 40)/14, shows the source actually used the correct value, 40 mm, throughout the rest of the solution — only that one intermediate '0.4 m' line is in error. (S2 p.46)" },
          { k: "h", t: "📘 Notes — S2 p.47 — Q.6 (WB)" },
          { k: "eg", title: "Q.6 (WB) — runoff from a 3-hour storm using Horton's decaying infiltration curve directly", given: "A 3-hour storm has hourly rainfall intensities i = 10, 20, 10 mm/hr (1st, 2nd, 3rd hour). Infiltration capacity f = 6.8 + 8.7e^(−t) mm/hr. Find the runoff.", steps: [
            { t: "Total rainfall over the storm", w: "P = 10×1 + 20×1 + 10×1 = 40 mm" },
            { t: "Evaluate f at t = 0, 1, 2 hr to see how it compares to each hour's intensity", w: "f(0) = 15.5 mm/hr;  f(1) = 10.0 mm/hr;  f(2) = 7.97 mm/hr" },
            { t: "1st hour: i = 10 mm/hr is less than f over that hour (f starts at 15.5) — all of it infiltrates, no runoff; 2nd and 3rd hours (i = 20, 10 mm/hr) exceed the now-lower f, so they do produce runoff", w: "Only hours 2 and 3 (rainfall 20 + 10 = 30 mm) contribute to runoff" },
            { t: "Runoff = (rainfall of hours 2-3) − (actual infiltration over hours 2-3, found by integrating f from t=1 to t=3)", w: "Runoff = (20+10) − ∫₁³ (6.8 + 8.7e^(−t)) dt" },
            { t: "Evaluate the integral: ∫(6.8+8.7e^(−t))dt = 6.8t − 8.7e^(−t)", w: "[6.8(3) − 8.7e^(−3)] − [6.8(1) − 8.7e^(−1)] = [20.4 − 0.433] − [6.8 − 3.201] = 19.967 − 3.599 = 16.368 mm" },
            { t: "Subtract from the hour 2-3 rainfall", w: "Runoff = 30 − 16.368" },
          ], ans: "Runoff ≈ 13.63 mm" },
        ],
      },

      /* ============================================================ 5.8 */
      {
        n: "5.8",
        title: "φ-index Worked Examples III — Mixed Problems (S3)",
        hi: "φ-इंडेक्स हल किए गए उदाहरण III — मिश्रित प्रश्न",
        blocks: [
          { k: "h", t: "📘 Notes — S3 p.4-5 — IIT-B Link, 2013" },
          { k: "eg", title: "IIT-B Link question, 2013 (4 marks) — φ-index and the intensity of a second storm", given: "The 1st storm has intensity 4 cm/hr and duration 5 hours, giving a runoff of 12 cm. A 2nd storm, at the same place, lasts 8 hours and gives a runoff depth of 14 cm. Find (1) the φ-index, (2) the intensity of the 2nd storm.", steps: [
            { t: "φ-index = (P − R)/t = (i×t − R)/t = i − R/t, for storm 1", w: "φ = 4 − 12/5 = 4 − 2.4" },
            { t: "φ-index from storm 1", w: "φ = 1.6 cm/hr" },
            { t: "φ-index is a soil property, so it is the same for storm 2: 1.6 = i2 − R2/t2", w: "1.6 = i2 − 14/8 = i2 − 1.75" },
            { t: "Solve for i2", w: "i2 = 1.6 + 1.75" },
          ], ans: "(1) φ-index = 1.6 cm/hr;  (2) Intensity of 2nd storm = 3.35 cm/hr" },
          { k: "h", t: "📘 Notes — S3 p.5-6 — IIT-Kharagpur" },
          { k: "eg", title: "IIT-Kharagpur — depth of infiltration in successive half-hours using Horton's equation", given: "Infiltration capacity f(t) = 3 + 1.2e^(−1.5t) cm/hr. Find (a) depth of infiltration in the 1st half-hour, (b) depth in the 2nd half-hour, (c) total depth, (d) average rate of infiltration.", steps: [
            { t: "(a) Integrate f from t=0 to t=0.5 hr; antiderivative is 3t − (1.2/1.5)e^(−1.5t) = 3t − 0.8e^(−1.5t)", w: "F_P1 = [3(0.5) − 0.8e^(−0.75)] − [0 − 0.8e^0] = (1.5 − 0.378) − (−0.8) = 1.5 − 0.378 + 0.8" },
            { t: "1st half-hour result", w: "F_P1 ≈ 1.92 cm" },
            { t: "(b) Integrate f from t=0.5 to t=1 hr using the same antiderivative", w: "F_P2 = [3(1) − 0.8e^(−1.5)] − [3(0.5) − 0.8e^(−0.75)] = (3 − 0.178) − (1.5 − 0.378) = 2.822 − 1.122" },
            { t: "2nd half-hour result", w: "F_P2 ≈ 1.69 cm" },
            { t: "(c) Total depth over the full hour", w: "F_P = F_P1 + F_P2 = 1.92 + 1.69" },
            { t: "(d) Average rate = total depth / total time (1 hr)", w: "f_avg = F_P / 1hr = 3.62 / 1" },
          ], ans: "(a) 1.92 cm; (b) 1.69 cm; (c) 3.62 cm total; (d) average rate = 3.62 cm/hr" },
          { k: "h", t: "📘 Notes — S3 p.7-8 — isolated hour's rainfall" },
          { k: "eg", title: "Runoff depth from an isolated-hour rainfall record, given φ-index", given: "An isolated hour's rainfall occurs over a catchment: 1st hour 9 mm, 2nd hour 28 mm, 3rd hour 12 mm, 4th hour 7 mm. φ-index for the catchment = 10 mm/hr. Find the runoff depth.", steps: [
            { t: "Each hour's rainfall is already an hourly intensity (duration 1 hr each)", w: "i1=9, i2=28, i3=12, i4=7 mm/hr" },
            { t: "Compare each to φ = 10 mm/hr: i1 (9) and i4 (7) are below φ — no runoff from these; i2 (28) and i3 (12) exceed φ", w: "Only hours 2 and 3 produce runoff" },
            { t: "Runoff = Σ(excess-hour intensity − φ) × 1 hr, for the excess hours only", w: "Runoff = 0 + (28−10)×1 + (12−10)×1 + 0 = 18 + 2" },
          ], ans: "Runoff = 20 mm" },
          { k: "h", t: "📘 Notes — S3 p.8-9 — cumulative-rainfall table" },
          { k: "eg", title: "φ-index from a cumulative-rainfall record and a given effective-rainfall depth", given: "Cumulative rainfall (cm) at t = 0, 2, 4, 6, 8, 10 hr is 0, 2, 3.5, 7.5, 9.5, 10. The depth of effective rainfall (= runoff) is 5.2 cm. Find the φ-index.", steps: [
            { t: "Convert cumulative rainfall to incremental rainfall per interval (must be done first — the cumulative figures themselves are not intensities)", w: "Increments (cm): 2, 1.5, 4, 2, 0.5" },
            { t: "Take the last cumulative value as the total precipitation depth P", w: "P = 10 cm" },
            { t: "Total storm duration T", w: "T = 10 hr" },
            { t: "First trial: φ = (P − R)/T over the total duration", w: "φ = (10 − 5.2)/10 = 4.8/10 = 0.48 cm/hr" },
            { t: "Check each interval's intensity against this trial φ: the 2-hr increments give 1.0, 0.75, 2.0, 1.0, 0.25 cm/hr. The last interval (0.25 cm/hr) is below 0.48, so it produces no excess — drop it", w: "P′ = 10 − 0.5 = 9.5 cm;  t′ = 8 hr" },
            { t: "Second trial", w: "φ = (9.5 − 5.2)/8 = 4.3/8 = 0.5375 cm/hr — all remaining intensities (1.0, 0.75, 2.0, 1.0) exceed it, so it is final\nCheck: (0.4625 + 0.2125 + 1.4625 + 0.4625) × 2 = 5.2 cm ✓" },
          ], ans: "φ-index = 0.5375 cm/hr ≈ 0.54 cm/hr (the notes print 0.48 cm/hr)" },
          { k: "note", t: "<b>Correction (v45):</b> (P − R)/T = 0.48 cm/hr is only the first trial (numerically the W-index-type average). The φ-index is the constant rate above which rainfall volume equals runoff volume, so any interval with intensity below φ must be removed and φ recomputed. The 8–10 hr interval (0.5 cm in 2 hr = 0.25 cm/hr) is below 0.48 cm/hr; dropping it gives φ = (9.5 − 5.2)/8 = <b>0.5375 cm/hr</b>, which reproduces R = 5.2 cm exactly. With φ = 0.48 cm/hr the computed excess would be 5.66 cm, not 5.2 cm. The notes stop at 0.48 cm/hr. (S3 p.8–9)" },
          { k: "h", t: "📘 Notes — S3 p.9-10 — IES, with a stated initial loss" },
          { k: "eg", title: "IES — depth of excess rainfall given φ-index and a stated initial loss", given: "Hourly rainfall over a catchment: 1st hr 6 mm, 2nd hr 9 mm, 3rd hr 20 mm, 4th hr 8 mm, 5th hr 4 mm. φ-index = 5 mm/hr. Initial loss = 15 mm. Find the depth of excess rainfall (= runoff).", steps: [
            { t: "Each hour's rainfall is already an hourly intensity", w: "i1=6, i2=9, i3=20, i4=8, i5=4 mm/hr" },
            { t: "Compare each to φ = 5 mm/hr: i5 (4) is below φ — excluded; i1, i2, i3, i4 (6, 9, 20, 8) all exceed φ", w: "Hours 1-4 produce excess; hour 5 does not" },
            { t: "Runoff = Σ(excess-hour intensity − φ) × 1 hr, over the excess hours", w: "Runoff = (6−5) + (9−5) + (20−5) + (8−5) = 1 + 4 + 15 + 3" },
          ], ans: "Runoff = 23 mm" },
          { k: "note", t: "The problem statement names a separate 15 mm initial loss, but the worked solution (as transcribed) applies the φ-index directly across every hourly increment above φ, with no separate initial-loss subtraction step. Coincidentally, the first two hours' rainfall (6 + 9 = 15 mm) sums to exactly the stated initial-loss figure, which may be why the two numbers appear together in the problem — but the shown arithmetic does not use the 15 mm figure at all. (S3 p.9-10)" },
          { k: "h", t: "📘 Notes — S3 p.10 — φ-index from a D.R.H. peak" },
          { k: "eg", title: "φ-index from a Direct-Runoff-Hydrograph peak and base", given: "Total rainfall P = 15 mm over a storm duration of 4 hours. Direct-runoff hydrograph: peak Qpeak = 20 cumec (m³/s), time base tbase = 50 hours. Catchment area = 1400 km². Find the φ-index.", steps: [
            { t: "Runoff volume = area of the (triangular) D.R.H. = ½ × tbase × Qpeak", w: "Volume = ½ × 20 m³/s × 50 hr × 3600 s/hr" },
            { t: "Runoff depth = runoff volume / catchment area", w: "R = [½ × 20 × 50 × 3600] / [1400 × (1000)²] = 1.28×10⁻³ m" },
            { t: "Convert to mm", w: "R = 1.28 mm" },
            { t: "φ-index = (P − R)/t, using the total storm duration t = 4 hr", w: "φ = (15 − 1.28)/4 = 13.72/4" },
          ], ans: "φ-index = 3.43 mm/hr" },
          { k: "h", t: "📘 Notes — S3 p.11 — SSC objective, invariant φ-index between two storms" },
          { k: "eg", title: "SSC objective — using the same φ-index across two different storms", given: "A 4-hour storm gives 60 mm rainfall and 40 mm runoff at a location. A second storm at the same location gives 20 mm rainfall over 2 hours. Find the runoff depth of the second storm.", steps: [
            { t: "φ-index is the same soil property for both storms: φ|₁ = φ|₂", w: "(P−R)/t |₁ = (P−R)/t |₂" },
            { t: "Substitute storm 1's values on the left", w: "(60−40)/4 = (20−R)/2" },
            { t: "Simplify the left side", w: "20/4 = 5 = (20−R)/2" },
            { t: "Solve for R", w: "10 = 20 − R  ⇒  R = 10" },
          ], ans: "Runoff of 2nd storm = 10 mm" },
          { k: "trap", t: "If solving for runoff this way ever gives a <b>negative</b> value, it means there is in fact no runoff for that storm — take R = 0, not a negative depth. (S3 p.11)" },
          { k: "h", t: "📘 Notes — S3 p.11-12 — SSC, 6-hour storm" },
          { k: "eg", title: "SSC — φ-index from a 6-hour storm's hourly intensities and total runoff", given: "A 6-hour storm has hourly rainfall intensities 7, 18, 25, 17, 11, 6 mm/hr, producing a total runoff of 39 mm. Find the φ-index.", steps: [
            { t: "Total rainfall P = sum of each hour's rainfall (intensity × 1 hr each)", w: "P = 7+18+25+17+11+6 = 84 mm" },
            { t: "First trial over the full 6 hr", w: "φ = (84 − 39)/6 = 45/6 = 7.5 mm/hr" },
            { t: "The 1st hour (7 mm/hr) and the 6th hour (6 mm/hr) are below 7.5 mm/hr, so they produce no excess — drop them and recompute over the remaining 4 hr", w: "φ = (84 − 7 − 6 − 39)/4 = 32/4 = 8.0 mm/hr — all remaining intensities (18, 25, 17, 11) exceed 8\nCheck: (18−8) + (25−8) + (17−8) + (11−8) = 10 + 17 + 9 + 3 = 39 mm ✓" },
          ], ans: "φ-index = 8.0 mm/hr (the notes print 7.5 mm/hr)" },
          { k: "note", t: "<b>Correction (v45):</b> 7.5 mm/hr is only the first trial. Two hours of the storm (7 and 6 mm/hr) fall below it and so cannot contribute runoff; excluding them gives φ = (84 − 13 − 39)/4 = <b>8.0 mm/hr</b>, which reproduces the 39 mm runoff exactly. With φ = 7.5 mm/hr the excess would be 41 mm, not 39 mm. The notes print 7.5 mm/hr. (S3 p.11–12)" },
        ],
      },

      /* ============================================================ 5.9 */
      {
        n: "5.9",
        title: "Quick revision — Infiltration",
        hi: "त्वरित पुनरावृत्ति — अंतःस्रवण",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Infiltration = vertical entry at the surface (interface essential); Percolation = further downward travel after infiltration; Seepage = any non-vertical movement of infiltrated water (S1 p.2).",
            "F = i when i ≤ Fp (all rainfall infiltrates); F = Fp when i ≥ Fp (excess becomes runoff); Fp (cumulative) = ∫fp·dt = area under the rate curve (S2 p.37).",
            "Single-ring infiltrometer (30cm dia, 60cm ht, 50cm embedded) vs double-ring (30/60cm dia, 25cm ht, outer ring = lateral jacket); rain simulator (2m×4m plot, 2m drop ht); flooding-type always reads higher than a rain simulator (S2 p.38-39; S3 p.1).",
            "Horton's equation fp = fc + (fo−fc)e^(−Kh·t) for 0≤t≤tc; Case 1 integral F̄p = fc·t + [(fo−fc)/Kh][1−e^(−Kht)] ≈ fc·t + (fo−fc)/Kh for large Kh·t; Case 2 adds fc·(t−tc) (S2 p.39-40).",
            "Infiltration-capacity classes: <2.5 very low, 2.5-12.5 low, 12.5-25 medium, >25 mm/hr high (S2 p.42).",
            "W-index = total infiltration/total duration (whole storm); φ-index = infiltration during the excess period/duration of that excess period only; φ-index ≥ W-index always, equal only if every sub-storm produces excess (S2 p.42-45).",
            "φ-index shortcut φ=(P−R)/t (total duration) works only when nothing needs excluding; otherwise iterate — compute a first trial, drop any increment below that φ, and recompute over the remaining excess duration (S2 p.45-46; S3 p.2-12).",
            "If no data exists, φ-index may be assumed 0.1 cm/hr for flood-discharge estimation; φ-index never exists for zero-runoff storms; a negative computed runoff means R=0 (S2 p.44; S3 p.3, p.11).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "fp (rate, cm/hr) vs Fp (cumulative depth, cm) — Fp = ∫fp dt, don't mix the two up.",
            "Double-ring beats single-ring because the outer ring's ponded water stops lateral spreading, isolating a purely vertical reading from the inner ring.",
            "Horton Case 1 and Case 2 use the SAME exponential-decay area — Case 2 just bolts on a flat rectangle fc·(t−tc) for time spent beyond tc.",
            "φ-index's defining trick: only the storms/hours that exceed φ itself count toward both the numerator (their infiltration) and the denominator (their duration) — everything below φ is dropped entirely, which is exactly why φ-index ≥ W-index.",
            "When a φ-index problem gives total P, total R and total t with no hourly breakdown, φ=(P−R)/t is the only method available — and it is exactly correct in that case, since there's no way to tell which hours to exclude.",
          ] },
        ],
      },

    ],
  });
})();
