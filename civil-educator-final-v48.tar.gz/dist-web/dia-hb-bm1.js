/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: BUILDING MATERIALS handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.2 THE THREE DEMANDS */
  "hb-bm-demands": {
    label: "What every material is judged against",
    svg: `<svg viewBox="0 0 700 314" role="img" aria-label="A material sits at the centre of three demands it must answer at once: strength to carry load, durability to survive its environment over time, and economy including availability and workability, with the point that no single material wins on all three.">
      ${hbmk("dm")}
      <text class="em" x="350" y="24" text-anchor="middle">NO MATERIAL WINS ON ALL THREE — YOU CHOOSE THE TRADE</text>
      <circle class="hif" cx="350" cy="164" r="30"/>
      <text class="lb" x="350" y="160" text-anchor="middle">the</text>
      <text class="lb" x="350" y="176" text-anchor="middle">material</text>
      ${[["STRENGTH", 350, 74, "carries the load —", "compression, tension, shear"],
         ["DURABILITY", 150, 236, "survives its", "environment over time"],
         ["ECONOMY", 550, 236, "available, workable,", "affordable to place"]]
        .map(([t, x, y, a, b]) => `
        <line class="ac" x1="350" y1="164" x2="${x}" y2="${y > 164 ? y - 44 : y + 30}"/>
        <circle class="acf" cx="${x}" cy="${y}" r="6"/>
        <text class="em" x="${x}" y="${y - 14}" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="${y + 20}" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="${y + 38}" text-anchor="middle">${b}</text>`).join("")}
      <text class="lb" x="350" y="286" text-anchor="middle">steel is strong but rusts and costs; stone lasts but is heavy and dear;</text>
      <text class="lb" x="350" y="304" text-anchor="middle">mud is cheap but weak — engineering is the choice between them</text>
    </svg>`,
    caption: "A material is never good or bad in the abstract — it is fit or unfit for a particular job in a particular place. The whole subject is learning what each material offers on these three axes so that, standing on a site, you can say why brick and not stone, why this cement and not that one. <strong>Every later chapter is one material measured against these three demands.</strong>",
  },

  /* ------------------------------------------- 2.1 ROCK CLASSIFICATION */
  "hb-bm-rocks": {
    label: "Where a building stone comes from",
    svg: `<svg viewBox="-8 0 716 300" role="img" aria-label="Rocks classified three ways: by origin into igneous, sedimentary and metamorphic; the same rocks reclassified by chemical composition and by physical structure, showing that granite, sandstone and marble come from three different origins and behave differently as building stone.">
      ${hbmk("rk2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE SAME STONE, CLASSIFIED THREE WAYS</text>
      ${[["IGNEOUS", 130, "cooled from molten rock", "hard, dense, durable", "GRANITE, basalt, trap"],
         ["SEDIMENTARY", 350, "laid down in layers", "softer, splits along beds", "SANDSTONE, limestone"],
         ["METAMORPHIC", 570, "old rock re-cooked", "recrystallised, often banded", "MARBLE, slate, quartzite"]]
        .map(([t, x, a, b, c]) => `
        <rect class="conc" x="${x - 92}" y="56" width="184" height="30"/>
        <text class="em" x="${x}" y="76" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="112" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="140" text-anchor="middle">${b}</text>
        <text class="ea" x="${x}" y="172" text-anchor="middle">${c}</text>`).join("")}
      <text class="em" x="350" y="212" text-anchor="middle">this is the ORIGIN classification — the one that predicts behaviour</text>
      <text class="lb" x="350" y="244" text-anchor="middle">a stone is also classified by CHEMISTRY (siliceous / argillaceous / calcareous)</text>
      <text class="lb" x="350" y="264" text-anchor="middle">and by STRUCTURE (stratified / unstratified / foliated) — three lenses on one rock</text>
      <text class="lb" x="350" y="290" text-anchor="middle">calcareous stone (limestone, marble) is attacked by acid rain; siliceous stone resists — origin tells which</text>
    </svg>`,
    caption: "Origin is the classification worth knowing first because it predicts everything else. An igneous stone cooled as one solid mass, so it is dense and has no natural planes of weakness; a sedimentary stone was laid in beds, so it splits easily along them and must be laid in the wall the same way it sat in the ground. <strong>Lay a bedded stone the wrong way up and it flakes off face-first within a few winters.</strong>",
  },

  /* ------------------------------------------- 3.1 BRICK ANATOMY */
  "hb-bm-brick": {
    label: "The parts of a brick, and the frog",
    svg: `<svg viewBox="0 0 724 300" role="img" aria-label="A standard brick drawn in three dimensions showing its length, width and height faces named as stretcher, header and bed, with the frog as a recess in the top bed face, alongside the modular and conventional brick sizes and the reason the frog exists.">
      ${hbmk("bk")}
      <text class="em" x="350" y="24" text-anchor="middle">A BRICK HAS THREE FACES AND EACH HAS A JOB</text>
      <path class="conc" d="M120 120 L300 120 L300 200 L120 200 Z"/>
      <path class="soft" d="M120 120 L160 90 L340 90 L300 120 Z"/>
      <path class="softa" d="M300 120 L340 90 L340 170 L300 200 Z"/>
      <rect class="soft-b" x="200" y="98" width="60" height="14" rx="2"/>
      <text class="lb" x="230" y="84" text-anchor="middle">frog</text>
      <text class="lb" x="210" y="166" text-anchor="middle">STRETCHER face</text>
      <text class="lb" x="320" y="150" text-anchor="middle" transform="rotate(-32 320 150)">HEADER</text>
      <text class="lb" x="250" y="104" text-anchor="middle">BED (top)</text>
      <line class="ac" x1="120" y1="214" x2="300" y2="214" marker-end="url(#bk-c)" marker-start="url(#bk-c)"/>
      <text class="lb" x="210" y="230" text-anchor="middle">length</text>

      <line class="gl" x1="392" y1="60" x2="392" y2="286"/>
      <text class="em" x="410" y="84">MODULAR (IS 1077):  190 × 90 × 90 mm</text>
      <text class="lb" x="410" y="108">with a 10 mm joint it works to a clean</text>
      <text class="lb" x="410" y="126">200 × 100 × 100 module — bricks per m³ = 500</text>
      <text class="em" x="410" y="158">CONVENTIONAL (traditional):  230 × 110 × 70 mm</text>
      <text class="lb" x="410" y="182">the size most Indian kilns still make</text>
      <text class="ea" x="410" y="214">the FROG:</text>
      <text class="lb" x="410" y="236">a recess pressed into the top bed. Mortar</text>
      <text class="lb" x="410" y="254">fills it and keys the course above — so the</text>
      <text class="lb" x="410" y="272">frog is laid UPWARDS, never down.</text>
    </svg>`,
    caption: "The frog is the small detail that catches people out on site. It is there to lock the mortar bed to the brick, so it must face up: a brick laid frog-down leaves a void that weakens the joint and traps water. The named faces matter too — a wall is bonded by deliberately alternating headers and stretchers, and you cannot describe a bond without the words for the faces.",
  },

  /* ------------------------------------------- 3.3 BRICK TESTS */
  "hb-bm-bricktests": {
    label: "The three field tests that grade a brick",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three brick tests shown side by side: a compressive strength test crushing a brick in a machine, a water absorption test weighing a brick dry then after 24 hours of soaking, and an efflorescence test standing a brick in water and watching for salt deposits.">
      ${hbmk("bt")}
      <text class="em" x="350" y="24" text-anchor="middle">THREE TESTS, THREE DIFFERENT QUESTIONS</text>
      ${[["COMPRESSIVE", 120, "is it strong enough?", "class designation ="],
         ["ABSORPTION", 350, "will it drink water?", "good brick < 20% by wt"],
         ["EFFLORESCENCE", 580, "does it carry salt?", "nil–slight is acceptable"]]
        .map(([t, x, q, r]) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="80" text-anchor="middle">${q}</text>`).join("")}
      <path class="s" d="M70 108 L170 108"/><path class="s" d="M70 176 L170 176"/>
      <rect class="conc" x="96" y="130" width="48" height="30"/>
      <line class="ac" x1="120" y1="92" x2="120" y2="106" marker-end="url(#bt-c)"/>
      <line class="ac" x1="120" y1="192" x2="120" y2="178" marker-end="url(#bt-c)"/>
      <text class="ea" x="120" y="210" text-anchor="middle">strength = load / area</text>
      <text class="lb" x="120" y="230" text-anchor="middle">class 3.5, 7.5, 10 …</text>
      <text class="lb" x="120" y="248" text-anchor="middle">(N/mm², min of the class)</text>

      <rect class="conc" x="306" y="120" width="46" height="28"/>
      <text class="lb" x="329" y="138" text-anchor="middle">W₁ dry</text>
      <rect class="softa" x="306" y="164" width="46" height="28"/>
      <rect class="conc" x="306" y="164" width="46" height="28" opacity="0.4"/>
      <text class="lb" x="329" y="182" text-anchor="middle">W₂ wet</text>
      <text class="ea" x="350" y="222" text-anchor="middle">absorption = (W₂−W₁)/W₁</text>
      <text class="lb" x="350" y="242" text-anchor="middle">soak 24 h · first class ≤ 20%</text>
      <text class="lb" x="350" y="260" text-anchor="middle">the wetter it drinks, the weaker</text>

      <path class="s" d="M540 150 L620 150 L620 188 L540 188 Z"/>
      <rect class="softa" x="540" y="168" width="80" height="20"/>
      <rect class="conc" x="566" y="120" width="28" height="52"/>
      <path class="hi dash" d="M566 132 L594 132"/>
      <text class="lb" x="640" y="140" text-anchor="end">salt rises,</text>
      <text class="lb" x="640" y="158" text-anchor="end">water leaves,</text>
      <text class="lb" x="640" y="176" text-anchor="end">white bloom</text>
      <text class="lb" x="580" y="214" text-anchor="middle">stand in water, let it evaporate</text>
      <text class="lb" x="580" y="232" text-anchor="middle">a white deposit = soluble salts</text>
      <text class="lb" x="580" y="250" text-anchor="middle">that will later stain the plaster</text>
    </svg>`,
    caption: "These three tests answer three separate worries and a brick can pass one and fail another. Strength decides how high you can build; absorption predicts both frost damage and how much water the brick will steal from the mortar; efflorescence warns of salts that will later push through plaster and paint as white patches. <strong>A cheap brick that looks fine dry can still ruin a finished wall through efflorescence alone.</strong>",
  },

  /* ------------------------------------------- 4.2 CEMENT MANUFACTURE */
  "hb-bm-cement": {
    label: "How cement is made, and what setting really is",
    svg: `<svg viewBox="-60 0 820 310" role="img" aria-label="The dry process of cement manufacture shown as a flow from limestone and clay through crushing and blending, into a rotary kiln where clinker forms at high temperature, then clinker plus gypsum ground to cement powder, followed by hydration where water turns the powder back into a rock.">
      ${hbmk("cm3")}
      <text class="em" x="350" y="24" text-anchor="middle">LIMESTONE + CLAY → A ROCK → POWDER → A ROCK AGAIN</text>
      ${[["limestone\\n+ clay", 70], ["crush &\\nblend", 190], ["ROTARY KILN\\n~1450°C", 330], ["clinker\\n+ gypsum", 470], ["GRIND to\\ncement", 590]]
        .map(([t, x], i) => `
        <rect class="${i === 2 ? "soft-b" : "conc"}" x="${x - 44}" y="70" width="88" height="52"/>
        <text class="lb" x="${x}" y="92" text-anchor="middle">${t.split("\\n")[0]}</text>
        <text class="lb" x="${x}" y="110" text-anchor="middle">${t.split("\\n")[1]}</text>
        ${i < 4 ? `<line class="ac" x1="${x + 46}" y1="96" x2="${x + 74}" y2="96" marker-end="url(#cm3-c)"/>` : ""}`).join("")}
      <text class="lb" x="300" y="146" text-anchor="middle">in the kiln the raw meal fuses into hard CLINKER nodules — the cement compounds themselves</text>
      <text class="ea" x="590" y="166" text-anchor="middle">gypsum slows the set</text>

      <line class="gl" x1="60" y1="182" x2="640" y2="182"/>
      <text class="em" x="350" y="206" text-anchor="middle">THE FOUR COMPOUNDS (Bogue) — and what each one does</text>
      ${[["C₃S", "alite", "early strength, most heat", 140],
         ["C₂S", "belite", "late strength, low heat", 300],
         ["C₃A", "aluminate", "flash set, most heat — gypsum tames it", 470],
         ["C₄AF", "ferrite", "colour, little strength", 610]]
        .map(([f, n, r, x]) => `
        <text class="em" x="${x}" y="238" text-anchor="middle">${f}</text>
        <text class="lb" x="${x}" y="256" text-anchor="middle">${n}</text>`).join("")}
      <text class="lb" x="350" y="284" text-anchor="middle">C₃S gives the 7-day strength you feel; C₂S keeps gaining for a year. RAPID-HARDENING cement is just more C₃S.</text>
      <text class="lb" x="350" y="304" text-anchor="middle">SETTING is not drying — it is HYDRATION, a chemical reaction with water that gives off heat and would happen underwater too</text>
    </svg>`,
    caption: "The single most useful idea about cement is in the last line: it does not dry, it reacts. Add water and the compounds chemically combine into interlocking crystals — which is why concrete sets under water, why it gets hot while curing, and why you keep it damp rather than let it dry. <strong>Gypsum is the small addition that stops C₃A from flash-setting the moment water hits it</strong>, buying the working time a mason needs.",
  },

  /* ------------------------------------------- 4.3 CEMENT SETTING TIME */
  "hb-bm-vicat": {
    label: "Initial and final set — the Vicat apparatus",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="The Vicat apparatus dropping a needle into a cement paste at intervals: at first the needle sinks fully, at initial set it stops short of the base, and at final set it barely marks the surface, with the two times defined by how far the needle penetrates.">
      ${hbmk("vc")}
      <text class="em" x="350" y="24" text-anchor="middle">SETTING IS TIMED BY HOW FAR A NEEDLE SINKS</text>
      ${[["FRESH", 130, 168, "needle sinks", "to the bottom", "t = 0"],
         ["INITIAL SET", 350, 116, "needle stops", "5 mm from base", "≥ 30 min (OPC)"],
         ["FINAL SET", 570, 74, "needle leaves", "no impression", "≤ 600 min"]]
        .map(([t, x, depth, a, b, tm], i) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <path class="conc" d="M${x - 44} 200 L${x + 44} 200 L${x + 38} 230 L${x - 38} 230 Z"/>
        <rect class="softa" x="${x - 40}" y="176" width="80" height="26"/>
        <line class="hi ${i === 0 ? "an-step" : ""}" style="--del:${i * 0.6}s;--dur:3s" x1="${x}" y1="74" x2="${x}" y2="${depth}" marker-end="url(#vc-m)"/>
        <text class="lb" x="${x}" y="252" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="270" text-anchor="middle">${b}</text>
        <text class="ea" x="${x}" y="290" text-anchor="middle">${tm}</text>`).join("")}
      <line class="gl" x1="240" y1="64" x2="240" y2="296"/>
      <line class="gl" x1="460" y1="64" x2="460" y2="296"/>
    </svg>`,
    caption: "Both times matter for different reasons on site. Before <em>initial set</em> the paste can still be mixed, placed and compacted — miss that window and disturbing the concrete breaks the bonds forming inside it. After <em>final set</em> the mass has stiffened enough to carry its own shape and curing takes over. <strong>Initial set too fast leaves no working time; final set too slow delays every following operation.</strong>",
  },

  /* ------------------------------------------- 6.1 SIEVE / FM */
  "hb-bm-sieve": {
    label: "Grading a sand — the sieve stack and fineness modulus",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A stack of test sieves from coarse at the top to fine at the bottom with a pan, sand retained on each, and the fineness modulus computed as the sum of cumulative percentages retained divided by one hundred, with the point that a higher number means a coarser sand.">
      ${hbmk("sv2")}
      <text class="em" x="350" y="24" text-anchor="middle">ONE NUMBER FOR HOW COARSE A SAND IS</text>
      ${[["4.75 mm", 60], ["2.36 mm", 96], ["1.18 mm", 132], ["600 µm", 168], ["300 µm", 204], ["150 µm", 240], ["PAN", 276]]
        .map(([t, y], i) => `
        <rect class="${i === 6 ? "conc" : "softa"}" x="120" y="${y}" width="180" height="30"/>
        <line class="s" x1="120" y1="${y + 30}" x2="300" y2="${y + 30}"/>
        <text class="lb" x="110" y="${y + 20}" text-anchor="end">${t}</text>
        ${i < 6 ? [0,1,2,3,4].map(k => `<circle class="hif" cx="${140 + k * 32}" cy="${y + 15 - (i)}" r="${2.6 - i * 0.25}"/>`).join("") : ""}`).join("")}
      <text class="lb" x="210" y="${60}" text-anchor="middle">coarse ↑</text>
      <text class="lb" x="210" y="298" text-anchor="middle">↓ fine</text>

      <line class="gl" x1="336" y1="44" x2="336" y2="290"/>
      <text class="em" x="356" y="72">FM = Σ(cumulative % retained) / 100</text>
      <text class="lb" x="356" y="98">add up the % retained AT AND ABOVE each</text>
      <text class="lb" x="356" y="116">of the standard sieves, divide by 100</text>
      <text class="ea" x="356" y="148">fine sand      FM ≈ 2.2 – 2.6</text>
      <text class="ea" x="356" y="170">medium sand    FM ≈ 2.6 – 2.9</text>
      <text class="ea" x="356" y="192">coarse sand    FM ≈ 2.9 – 3.2</text>
      <text class="lb" x="356" y="222">a HIGHER FM means a COARSER sand —</text>
      <text class="lb" x="356" y="240">more retained high in the stack.</text>
      <text class="lb" x="356" y="268">it is a grading summary, not a size:</text>
      <text class="lb" x="356" y="286">two different sands can share one FM.</text>
    </svg>`,
    caption: "Fineness modulus compresses a whole sieve analysis into a single figure you can compare and specify. It is not a particle size — it is a weighted average of how high up the stack the material was caught. A higher number is a coarser sand, which needs less water and less cement paste to coat it. <strong>The catch worth remembering: two quite different gradings can give the same FM</strong>, so it summarises fineness without fully describing the grading.",
  },

  /* ------------------------------------------- 7.1 TIMBER STRUCTURE */
  "hb-bm-timber": {
    label: "Inside a log — why timber is strong along the grain",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A cross section of a tree trunk showing bark, sapwood, heartwood, annual growth rings and the medullary rays, alongside the three axes of timber and the point that it is far stronger along the grain than across it, plus common defects.">
      ${hbmk("tb2")}
      <text class="em" x="350" y="24" text-anchor="middle">TIMBER IS A BUNDLE OF STRAWS — STRONG ALONG, WEAK ACROSS</text>
      <circle class="s" cx="180" cy="168" r="108" fill="none"/>
      <circle class="thin" cx="180" cy="168" r="92" fill="none"/>
      <circle class="thin" cx="180" cy="168" r="74" fill="none"/>
      <circle class="softa" cx="180" cy="168" r="56"/>
      <circle class="thin" cx="180" cy="168" r="40" fill="none"/>
      <circle class="hif" cx="180" cy="168" r="5"/>
      <text class="lb" x="180" y="154" text-anchor="middle">pith</text>
      <line class="ac" x1="180" y1="168" x2="180" y2="60" marker-end="url(#tb2-c)"/>
      ${[["bark", 60], ["sapwood — living, pale", 88], ["heartwood — dead, strong", 128], ["annual rings", 250]]
        .map(([t, y]) => `<text class="lb" x="300" y="${y}" >${t}</text>`).join("")}
      <line class="gl" x1="316" y1="60" x2="316" y2="286"/>
      <text class="em" x="336" y="88">along the grain (fibres)</text>
      <text class="lb" x="336" y="110">high tension & bending strength —</text>
      <text class="lb" x="336" y="128">this is how a beam is cut</text>
      <text class="em" x="336" y="160">across the grain</text>
      <text class="lb" x="336" y="182">weak, splits easily — never load</text>
      <text class="lb" x="336" y="200">a joint to pull fibres apart</text>
      <text class="ea" x="336" y="232">seasoning removes moisture:</text>
      <text class="lb" x="336" y="252">wet timber shrinks, warps and rots —</text>
      <text class="lb" x="336" y="270">seasoned to ~12% before use. Defects:</text>
      <text class="lb" x="336" y="288">knots, shakes, warp — each a plane of weakness</text>
    </svg>`,
    caption: "Timber's whole character follows from its structure: it is millions of hollow cellulose tubes glued together and running the length of the tree. That is why it carries load beautifully along the grain and splits along it just as easily — and why every timber joint is designed to load the fibres in their strong direction. <strong>Seasoning matters because a tree is roughly half water</strong>, and that water must leave slowly and evenly or the piece warps, checks and later rots.",
  },

});
