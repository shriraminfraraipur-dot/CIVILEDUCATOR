/* ============================================================
   TUNNEL ENGINEERING · COMPLETE NOTES — Chapters 1–2
   Introduction, classification, shape · Investigation, setting
   out and shafts
   Sources: A (43 pp, denser) · B (18 pp, sparser, overlapping)
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];
DB.handbooks.push({
  id: "tunnel", subject: "tunnel-engineering",
  name: "Tunnel Engineering — Complete Notes",
  hi: "सुरंग अभियांत्रिकी — सम्पूर्ण नोट्स", icon: "🚇",
  blurb: "Do alag students ke class notes se banaya gaya handbook — A (43 page, zyada detailed) aur B (18 page, chhota par kai jagah A ko confirm/complement karta hai), har fact page-cited.",
  note: "Sources: A = 43-page notes, B = 18-page notes (different students, overlapping content). Har block par source aur page likha hai. Jahan dono alag values dete hain, dono dikhaye gaye hain.",
  chapters: []
});
(DB.handbooks || []).find(function (h) { return h.id === "tunnel"; }).chapters.push(

  /* ============================================================ CH 1 */
  {
    id: "tunnel-1",
    n: 1,
    title: "Introduction, Classification and Shape of Tunnels",
    hi: "परिचय, वर्गीकरण और सुरंग का आकार",
    blurb: "Tunnel aur open cut ki definition, open-cut depth limit ka ek documented conflict, alignment/purpose/ground ke hisaab se classification, aur tunnel ke chhah usual cross-sections — circular se rectangular tak — unke pros-cons ke saath.",
    mins: 18,
    sections: [
      {
        n: "1.1",
        title: "Tunnel, open cut and the depth-limit question",
        hi: "सुरंग, ओपन कट और गहराई-सीमा का सवाल",
        blocks: [
          { k: "h", t: "📘 Notes — A p.2 / B p.1" },
          { k: "def", term: "Tunnel", t: "An underground passage for the transport of passengers, water, sewage, minerals, gas etc. (A p.2) B p.1 defines it almost the same way — an <b>artificial underground passage to by-pass obstacles</b>." },
          { k: "def", term: "Open cut", t: "An open-to-sky passage excavated through a huge soil mass or obstacle like a hill, run to the required dimension to connect two points. (A p.2, B p.1)" },
          { k: "p", t: "Tunnels are economical for <b>greater depths</b> as compared to open cuts. An open cut, on the other hand, will require less time and cost of construction as compared to a tunnel when the depth is small. (A p.2)" },
          { k: "h", t: "The open-cut depth limit — a real conflict in the source notes" },
          { k: "note", t: "<b>Conflict — at what depth does tunnelling become preferable to an open cut?</b> The notes give three different numbers, attributed to three different sources, for essentially the same question:<br>• <b>18 m (60 ft)</b> — the general economical limit for open cuts (A p.2, tagged MES 2017).<br>• <b>15 m</b> — for highways specifically: tunnelling is preferred once open-cut depth exceeds 15 m, also tagged <b>MES 2017</b> (A p.2). B p.1 independently states this same 15 m rule, without naming a source.<br>• <b>20 m</b> — the same highway question, but per the <b>MPSC answer key</b>, and separately again per <b>Made Easy and ACE</b> (A p.2).<br>All three figures are quoted exactly as the transcript gives them. The source itself does not resolve which one is correct — different coaching institutes and answer keys disagree on this point." },
          { k: "list", items: [
            "A p.2 marks the 18 m figure with its imperial equivalent '(60 feet)', confirming it is meant as a firm number, not a rough rounding.",
            "B p.1, being the sparser source, records only the 15 m rule and does not mention the 18 m or 20 m variants at all.",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh ek genuine syllabus-level conflict hai, invented nahi. Agar exam mein yeh depth-limit poochha jaaye toh answer <b>source ke saath</b> dena chahiye — jaise 'MPSC ke hisaab se 20 m' ya 'MES 2017 ke hisaab se 15 m (highway)' — kyunki A ki apni notes mein bhi teen alag values hain. Ek single number yaad karke exam mein confidently likhna risky hai; better hai dono/teeno numbers aur unke source yaad rakhna." },
        ],
      },
      {
        n: "1.2",
        title: "Classification of tunnels",
        hi: "सुरंगों का वर्गीकरण",
        blocks: [
          { k: "h", t: "📘 Notes — A p.2–3 / B p.1–2" },
          { k: "h", t: "1) By alignment" },
          { k: "list", items: [
            "<b>Off-spur tunnels</b> — short length tunnels to negotiate minor local obstacles: a very high projection on the way which cannot be followed with a permitted curve. (A p.2, tagged MES 2017; B p.1)",
            "<b>Saddle or base tunnels</b> — tunnel constructed in the valleys along the natural slope, till the slope does not exceed the ruling gradient. (A p.2–3, B p.1)",
            "<b>Slope tunnels</b> — tunnel constructed in steep hills for economic and safe operation of roads and railways. (A p.3, B p.1)",
            "<b>Spiral tunnels</b> — provided in a narrow valley in the form of loops in the interior of a mountain, so as to increase the length of the tunnel and avoid steep slopes. (A p.3, B p.1)",
          ] },
          { k: "h", t: "2) By purpose" },
          { k: "list", items: [
            "<b>Conveyance tunnel</b> — for water supply, sewerage etc. (A p.3). B p.1 additionally names <b>hydro-electric power plant tunnels</b> under this head.",
            "<b>Traffic tunnels</b> — A p.3 lists highway, railway, pedestrian and navigation tunnels under this head; B p.1 names only highway and railway tunnels.",
          ] },
          { k: "note", t: "Not a numeric conflict, just a coverage gap: B's list of traffic-tunnel sub-types (highway, railway) is a subset of A's fuller list (highway, railway, pedestrian, navigation). Combine both when answering." },
          { k: "h", t: "3) By type of ground / material encountered in construction" },
          { k: "list", items: [
            "A p.3 lists five types: a) tunnels in hard rock, b) tunnels in soft material, c) tunnels in quick sand, d) open cut tunnels, e) tunnels underneath a river bed or in water bearing soils.",
            "B p.1–2 lists three types under this head: 1) tunnels in soft materials, 2) tunnels in hard rocks, 3) tunnels underneath a river bed or in water bearing soils — it does not separately list 'quick sand' or 'open cut tunnels' as their own category.",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno classification angles alag sawaal poochhte hain — alignment poochhta hai 'tunnel kaise mudta/curve leta hai', purpose poochhta hai 'tunnel kis kaam ke liye hai', aur ground/material poochhta hai 'kis zameen mein bana hai'. Exam mein confuse mat ho — same tunnel teeno categories mein simultaneously aa sakta hai (jaise ek railway tunnel purpose se 'traffic tunnel' hoga aur ground se 'hard rock tunnel' bhi ho sakta hai)." },
        ],
      },
      {
        n: "1.3",
        title: "Shape of tunnels — circular and D-section",
        hi: "सुरंग का आकार — वृत्ताकार और D-सेक्शन",
        blocks: [
          { k: "h", t: "📘 Notes — A p.4–5 / B p.4" },
          { k: "p", t: "The shape of a tunnel depends on: i) nature of the soil, ii) pressure of the ground, iii) purpose of the tunnel. (A p.4)" },
          { k: "def", term: "Circular section", t: "Offers greater resistance to external pressure caused by water, water-bearing soils or soft grounds; the best theoretical section for resisting internal or external forces. (A p.4) It provides the greatest c/s area for the least perimeter (A p.4, tagged MES 2018). It is most suitable for sewers and water-carrying (A p.4, tagged IES 1997) and best suited in non-cohesive soils (A p.4, tagged ESE 1998; B p.4 repeats this without the exam tag, adding that it withstands heavy internal or external <b>radial</b> pressures). Suitable for tunnels driven by the <b>shield method</b>. (A p.4, B p.4)" },
          { k: "list", items: [
            "Disadvantage: not suitable for roads or railways, as more filling is required for a flat base. (A p.4)",
            "Disadvantage: difficult placement of concrete lining. (A p.4, B p.4)",
          ] },
          { k: "def", term: "D-section or segmental roof section", t: "A section with an arched roof and straight sides. (A p.4) The segmental roof takes the external load and transfers it onto the vertical side walls, which may be constructed of R.C.C. in the case of soft soils. (A p.4, tagged MES 2018) It is most suited in rock tunnels, and suitable for subways or navigational tunnels (A p.5, tagged ESE 1997 / ESE 1998; B p.4 states the subway/navigation suitability too). It has a nearly flat invert, giving additional working floor space during driving, and a flat floor useful for moving equipment. (A p.5, B p.4)" },
          { k: "trap", t: "Don't mix up the two exam-tagged suitability claims: <b>sewers / water-carrying → circular section</b> (IES 1997), while <b>subways / navigation tunnels → D-section</b> (ESE 1997/98). Both are 'tunnels carrying flowing water/traffic underground' in a loose sense, and MCQ options often swap the two." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Circular sabse strong shape hai external/internal pressure ke against, isliye jahan pressure ka bada role hai (soft ground, shield-driven tunnel, sewer) wahan circular use hota hai. Lekin flat floor chahiye ho (traffic ya equipment ke liye) toh circular ka curved base problem create karta hai — isi wajah se D-section aata hai, jo circular jaisi strength deta hai roof mein par ek flat invert bhi deta hai." },
        ],
      },
      {
        n: "1.4",
        title: "Shape of tunnels — egg, elliptical, horse-shoe and rectangular",
        hi: "सुरंग का आकार — अंडाकार, दीर्घवृत्ताकार, घोड़े की नाल और आयताकार",
        blocks: [
          { k: "h", t: "📘 Notes — A p.5–6 / B p.5" },
          { k: "def", term: "Egg-shaped section", t: "Generally adopted for carrying sewage (A p.5, tagged ESE 1997; B p.5 states this as the primary reason too). It maintains the self-cleansing velocity of the flow of sewage in dry and rainy seasons — B p.5 phrases this as 'gives self-cleansing velocity even in DWF (dry weather flow)' (A p.5 tagged ESE 1998, B p.5). Its circular side walls resist external and internal pressure, and it provides the least c/s area at the bottom (A p.5, tagged MES 2018)." },
          { k: "def", term: "Elliptical section", t: "Narrow at the base, so it cannot be used as a traffic tunnel; used in ground softer than rock. Its major axis is kept vertical to have better resistance to external pressure, and it is suited for carrying water and sewage. (A p.5)" },
          { k: "note", t: "B does not mention the elliptical section at all in these pages — this is a coverage gap in the sparser source, not a conflicting fact." },
          { k: "def", term: "Horse-shoe section", t: "The most popular section for a tunnel (A p.5) / 'most suitable' is qualified in B p.5 specifically for <b>soft rocks</b>. It has a semi-circular roof with arches, sides and a curved invert; suitable for soft rock (A p.5–6, tagged ESE 1997 / ESE 1998); commonly used for highways and railways, and also suitable for carrying water and sewage; when lined, the section gives good resistance to external pressure (A p.5–6, B p.5). It is the best shape suited for traffic purpose, and the floor is nearly flat, giving more working space to the contractor and space to store materials during construction (A p.6, tagged MES 2018; B p.5 states the same 'better working space, best for traffic purpose' point). Its main disadvantage: difficult to construct. (A p.6)" },
          { k: "def", term: "Rectangular section", t: "In the form of an R.C.C. box, most suitable in the case of hard rocks; generally adopted for pedestrian traffic; costly and difficult to construct. (A p.6, B p.5 — both sources agree closely on this section.)" },
          { k: "list", items: [
            "To attain the required shape of a tunnel, <b>Trimmers</b> are used. (A p.6, tagged MES 2015; B p.5)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Har shape ek specific problem solve karta hai: egg-shape sewage ke liye hai kyunki low-flow mein bhi velocity self-cleansing rehti hai (patla bottom); horse-shoe traffic ke liye best hai kyunki flat floor + strong arch roof dono milte hain; rectangular sirf tab jab hard rock ho aur pedestrian traffic ho, warna costly aur mushkil hai banana. Yaad rakhne ka tarika: 'sewage → egg', 'traffic/highway/railway → horse-shoe', 'pressure-heavy soft ground/shield → circular', 'subway/navigation → D-section'." },
        ],
      },
      {
        n: "1.5",
        title: "Size of tunnel and terminology",
        hi: "सुरंग का आकार और शब्दावली",
        blocks: [
          { k: "h", t: "📘 Notes — A p.6 / B p.1–2" },
          { k: "list", items: [
            "Size of a tunnel depends on the following factors (A p.6): 1) purpose of the tunnel, 2) the thickness of the lining, 3) the provisions required for the drainage facility, 4) the clear opening required to handle the volume of traffic, 5) nature of the traffic.",
          ] },
          { k: "def", term: "Tunnel approaches", t: "The open cuts provided at either end of a tunnel — i.e. at the entrance and the exit. (B p.2)" },
          { k: "def", term: "Portal", t: "The entrance or exit of a tunnel. (B p.2) — expanded further with A's description of portal design in Chapter 2 (Section 2.6)." },
          { k: "def", term: "Invert", t: "The base of the tunnel. (B p.2)" },
          { k: "cmp", t: "Standard tunnel dimensions for a single B.G. (broad gauge) railway track (B p.2)", cols: ["Value"], rows: [
            ["Width of tunnel", "4.9 m to 5.5 m"],
            ["Height of tunnel", "6.7 m to 7.3 m"],
          ] },
          { k: "note", t: "This B.G. tunnel width/height figure is confirmed again later in the A notes as well (A p.41, outside this chapter's core page range), where the same 4.9–5.5 m width and 6.7–7.3 m height are given for a single B.G. track — both sources agree on this value." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Size sirf 'tunnel kitna bada dikhna chahiye' se decide nahi hota — lining ki thickness, drainage ki jagah aur traffic ka volume sab final internal dimension ko affect karte hain. Isliye size ek design output hai, sirf ek assumption nahi." },
        ],
      },
      {
        n: "1.6",
        title: "Quick revision",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Tunnel vs open cut definitions, and the open-cut depth-limit conflict: 18 m (general/MES 2017) vs 15 m (MES 2017, highway; also B) vs 20 m (MPSC / Made Easy / ACE).",
            "Classification by alignment (off-spur, saddle/base, slope, spiral), by purpose (conveyance, traffic), by ground/material.",
            "All six shapes with their one-line reason: circular (pressure/shield), D-section (subway/navigation, rock), egg (sewage self-cleansing), elliptical (water/sewage, soft ground), horse-shoe (traffic — highway/railway), rectangular (hard rock, pedestrian).",
            "Size of tunnel depends on purpose, lining thickness, drainage, traffic opening, nature of traffic.",
            "B.G. railway tunnel: width 4.9–5.5 m, height 6.7–7.3 m.",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Three different depth numbers exist in the source for the open-cut-vs-tunnel decision — always name the source with the number.",
            "Circular = strongest against pressure but bad flat-floor traffic; horse-shoe = best all-round traffic shape; egg = sewage-specific.",
            "Trimmers are the tool used to achieve the final required tunnel shape.",
          ] },
        ],
      },
    ],
  },

  /* ============================================================ CH 2 */
  {
    id: "tunnel-2",
    n: 2,
    title: "Investigation, Setting Out and Shafts",
    hi: "अन्वेषण, सेटिंग आउट और शाफ्ट",
    blurb: "Investigation ki teen stages, heading vs drift, theodolite-laser-Weisbach triangle se alignment set karna, tunnel mein grades ka ek aur documented conflict, shaft ke cuts/size/types, aur portals-twin tunnels.",
    mins: 22,
    sections: [
      {
        n: "2.1",
        title: "Information needed for investigation",
        hi: "अन्वेषण के लिए आवश्यक जानकारी",
        blocks: [
          { k: "h", t: "📘 Notes — A p.6" },
          { k: "p", t: "For investigation of a tunnel site, the information required is: (A p.6)" },
          { k: "list", items: [
            "a) Origin of the soil mass",
            "b) Hydrology in the surrounding proposed tunnel site",
            "c) Presence of flow gases",
            "d) Temperature of the nearby soil",
            "e) Physical and mechanical strength of the soil mass",
            "f) Location of weak geological features like faults, folds etc.",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh checklist teen tarah ke risk cover karti hai — geological risk (faults/folds), environmental risk (gases, hydrology, temperature) aur strength risk (mechanical strength). Tunnel design shuru karne se pehle yeh sab pata hona zaroori hai, warna construction ke beech mein surprises milte hain." },
        ],
      },
      {
        n: "2.2",
        title: "Three stages of investigation; heading vs drift",
        hi: "अन्वेषण की तीन अवस्थाएँ; हेडिंग बनाम ड्रिफ्ट",
        blocks: [
          { k: "h", t: "📘 Notes — A p.7–8 / B p.2" },
          { k: "h", t: "Stage 1 — investigation prior to planning the project" },
          { k: "p", t: "Geological investigation is made to determine the relation between the bed rock and top soil, through surface exploration in the form of morphology, petrology etc. Geophysical methods, like electrical resistivity methods, are used to locate the positions of weak zones such as faults, folds, shear zones etc. (A p.7) B p.2 names this stage only as 'investigations before planning', without going into this level of detail." },
          { k: "h", t: "Stage 2 — investigation at the time of planning" },
          { k: "list", items: [
            "Carried out by (i) percussion, (ii) rotary percussion — for loose soils, (iii) rotary drilling — for rocky soils. (A p.7)",
            "B p.2 lists the same three drilling methods (percussion, rotary percussion, rotary), and adds that the core obtained from drill holes gives only <b>disturbed samples</b>; for undisturbed samples, shafts spaced 0.5 km to 1 km c/c are excavated.",
          ] },
          { k: "note", t: "The 0.5–1 km shaft spacing given here (B p.2) is for exploratory shafts dug to obtain undisturbed samples during planning — a different purpose from, and a different number than, the shaft spacing used later for transferring the tunnel alignment underground (Section 2.3)." },
          { k: "h", t: "Stage 3 — investigation at the time of construction: heading vs drift" },
          { k: "def", term: "Heading", t: "Part of the tunnel c/s excavated for small lengths; can be a top, bottom or side excavation, and being only a part of the tunnel, it does not require extra cost. It gives information <b>at the time of</b> tunnel construction. (A p.7–8, B p.2 — both sources agree closely.)" },
          { k: "def", term: "Drift", t: "Part of the tunnel c/s excavated for the <b>entire length</b> of the tunnel. It gives complete information <b>prior to</b> construction of the tunnel. (A p.7–8, B p.2)" },
          { k: "list", items: [
            "Both heading and drift costs are included in the cost of tunnelling. (A p.8)",
            "Both heading and drift give information about natural features and difficulties to be encountered — structure of soil, temperature, gases, rock fall, landslides etc. (A p.8)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Farak sirf itna hai: heading ek 'sample piece' hai (poori length nahi), isliye extra cost nahi lagta aur info construction ke saath-saath milti hai. Drift poori length excavate karta hai pehle hi, isliye construction shuru hone se <b>pehle</b> hi complete picture mil jaati hai — par obviously zyada mehenga/time-consuming hai." },
        ],
      },
      {
        n: "2.3",
        title: "Setting out / alignment of tunnel",
        hi: "सुरंग की सेटिंग आउट / संरेखण",
        blocks: [
          { k: "h", t: "📘 Notes — A p.8–9 / B p.3–4" },
          { k: "def", term: "Setting out", t: "Defined as marking the centre line or alignment of any construction work on the ground. (A p.8) It is done <b>indirectly</b>, in different stages, using theodolites (A p.8); B p.3 confirms it is done indirectly, specifically in four steps." },
          { k: "list", items: [
            "1) Setting out the tunnel on the ground surface (B p.3)",
            "2) Transfer of the centre line from the surface to underground (B p.3)",
            "3) Underground setting out (B p.4)",
            "4) Underground levelling (B p.4)",
          ] },
          { k: "p", t: "<b>Step 1 in detail (A p.8):</b> the modern way of providing horizontal control on the ground surface is by running an open traverse between the two ends of the proposed tunnel, using a theodolite of precision 1″ and a laser unit pole. The laser pole unit defines a thin, visible vertical plane up to a large height, which is bisected by the theodolite for measurement of the traverse lines. Lengths of survey lines are measured by the direct method of stepping, with invar or steel tapes. B p.3 confirms a theodolite (gyro-theodolite) and laser pole unit are used, and adds that for curved-line alignment, offsets are measured from the tangents." },
          { k: "list", items: [
            "Tunnel alignment is carried out by triangulation. (A p.8, tagged IES 2001)",
            "The Weisbach triangle method is used to connect the two ends of an underground tunnel. (A p.8, tagged IES 1995 / ESE 2008) B p.3 states this without an exam tag: the centre line can be transferred by solving the Weisbach triangle.",
          ] },
          { k: "h", t: "Transferring the centre line through shafts" },
          { k: "p", t: "For transfer of the centre line from the surface to underground, shafts are to be constructed at regular intervals along the traverse line — A p.8 gives this interval as <b>500 m</b>. B p.3, for this same step, describes that a rectangular horizontal timber frame is set at the proposed shaft, and the centre line is transferred by solving the Weisbach triangle." },
          { k: "steps", items: [
            "Through the shaft constructed, hang two or more plumb lines in the shaft.",
            "Determine the bearings of the plumb line — i.e. the plumb plane — after it has been carried downward.",
            "When the plumb bob reaches the bottom, the plumb lines are replaced by 22 lb weights on each plumb line.",
            "For higher precaution against vibration affecting the wire, immerse the plumb line (along with the weights) in buckets containing water.",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Surface par alignment set karna easy hai (theodolite + laser), par usko <b>underground</b> transfer karna tricky hai kyunki seedha line-of-sight possible nahi. Isliye plumb-line + shaft ka procedure use hota hai — bearings surface par measure karke shaft ke through neeche transfer kiye jaate hain, aur weights/water isliye ki wire vibrate na kare aur reading galat na aaye." },
        ],
      },
      {
        n: "2.4",
        title: "Grades in a tunnel",
        hi: "सुरंग में ढाल",
        blocks: [
          { k: "h", t: "📘 Notes — A p.9 / B p.4–5" },
          { k: "list", items: [
            "Grades in a tunnel should be lesser than the surface grade. (A p.9, B p.4)",
            "It is not favourable to continue the tunnel approach grades inside the tunnel, especially in railway tunnels. (A p.9)",
            "A nearly level grade, or a 0.2% gradient, is adopted for drainage. (A p.9, B p.4)",
            "It is convenient to have a rising gradient from both portals towards the centre of the tunnel. (A p.9)",
            "To maintain the desired shape of the tunnel, the c/s must be checked at a regular interval of 2 m to 3 m. (A p.9, tagged MES 2018)",
          ] },
          { k: "note", t: "<b>Conflict — the length beyond which the 75% ruling-gradient limit applies.</b> A p.9 states (★): 'for tunnels &gt; <b>3 km</b> length, grade should be provided below 75% of the ruling gradient.' B p.5 states: 'For tunnels exceeding <b>300 m</b> in length, the grade provided should be below 75% of ruling gradient.' This is a genuine, tenfold difference between the two sources on the same rule (both agree on the 75% figure, but disagree sharply on the length threshold that triggers it) — quoted exactly as each source gives it, with no attempt to pick one as correct." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Grades ko surface se kam rakhne ka reason hai drainage aur haulage — agar grade zyada steep hoga toh paani accumulate hoga aur muck-cars ko chadhne mein zyada power lagegi. 75%-of-ruling-gradient wala rule long tunnels ke liye ek safety/efficiency cap hai, bas iska 'kitni lambi tunnel se yeh rule apply hota hai' wala threshold source ke hisaab se alag-alag hai — dono numbers (3 km aur 300 m) yaad rakho aur exam mein source bata kar likho." },
        ],
      },
      {
        n: "2.5",
        title: "Shafts — cuts, size, types and faces of attack",
        hi: "शाफ्ट — कट, आकार, प्रकार और कार्य के मोर्चे",
        blocks: [
          { k: "h", t: "📘 Notes — A p.12–14 / B p.2, 4" },
          { k: "def", term: "Shaft", t: "Vertical tunnels or wells or passages reaching from the ground surface down to the tunnel invert. When the position and course of the tunnel are aligned correctly and accordingly set out on the surface, shafts are sunk at suitable points on this tunnel line to aid tunnelling. (A p.12)" },
          { k: "p", t: "Shafts also help in additional access, removal of muck, and natural ventilation in long tunnels. (A p.13, tagged ESE-08)" },
          { k: "h", t: "Types of cuts (tagged MES 2011)" },
          { k: "list", items: [
            "a) Central wedge cut — square and rectangular sections; most commonly used. (A p.12)",
            "b) Pyramid cut / wedge cut — circular section. (A p.13)",
            "c) Alternate wedge cut — for very large shafts, or stepping. (A p.13)",
          ] },
          { k: "h", t: "Size of shafts (tagged ESE-2001)" },
          { k: "list", items: [
            "Quantity of muck to be handled",
            "Size of muck car",
            "Nature of equipment used in the tunnelling process",
            "Number of labourers",
            "Space required to carry pipes and wires",
            "Nature of the hoisting system",
            "Eventual use of the shaft",
          ] },
          { k: "h", t: "Types of shafts" },
          { k: "cmp", t: "Classification of shafts by location, filling-time and alignment (A p.13–14)", cols: ["Details"], rows: [
            ["By location — shafts over the centre line", "Majority of shafts are of this type; advantage of hoisting materials out of the tunnel easily."],
            ["By location — side shafts", "Shifted to one side of the centre line; need a transverse gallery / pilot tunnel / passage to connect with the main tunnel. The turning of machinery at the sharp curve of the gallery is the greatest drawback."],
            ["By filling time — temporary shafts", "Can be re-filled once their sole purpose (gathering information) is served; mainly provided for supply of construction material and for removal of muck; located in the valley."],
            ["By filling time — permanent shafts", "Left open even after construction of the tunnel; helps in providing ventilation."],
            ["By alignment — vertical shafts", "Laid in the vertical dimension only, as they are easy to construct and cheap."],
            ["By alignment — inclined shafts", "For small depth; inclined shafts with a suitable gradient of 45° or less are constructed to achieve removal of muck by gravity."],
          ] },
          { k: "note", t: "B p.2 independently confirms that shafts can be temporary or permanent, and separately gives the 0.5–1 km c/c spacing for investigation shafts (see Section 2.2) — consistent with A's classification, just far less detailed." },
          { k: "list", items: [
            "It is usual to construct a <b>900 mm</b> high wall round the edge of the shaft opening, to form a protective fencing. This prevents surface water from flowing down the shaft. (A p.14)",
          ] },
          { k: "h", t: "Extra faces to work: shafts and pilot tunnels" },
          { k: "p", t: "Two ways of obtaining extra faces to work at (for tunnelling in rock) are given: by shaft construction, and by driving a pilot tunnel. (B p.4)" },
          { k: "eq", expr: "Total faces of attack (via shaft construction) = 2N + 2", where: [
            ["N", "number of shafts constructed along the tunnel line"],
            ["+2", "the two portal faces (tunnel entrance and exit), always included"],
          ] },
          { k: "note", t: "A's fuller notes state the identical rule under 'system of vertical shafts': 'if n = no. of shafts, then (2n+2) faces of attack are possible including two portals' (A p.16, just outside this chapter's core page range, but directly confirming B p.4's formula — both sources agree here)." },
          { k: "p", t: "<b>Pilot tunnel:</b> used when the horizontal approach to the tunnel line is closer/shorter than reaching it via a deep vertical shaft — a small, parallel-sized tunnel, called a pilot tunnel, is driven first. (B p.4)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Shaft sirf ek 'vertical hole' nahi hai — yeh access, ventilation, aur extra working-face sab dega. 2N+2 formula ka logic simple hai: har shaft ek jagah se do directions mein kaam shuru karne deta hai (isliye 2N), aur dono portals (entry-exit) hamesha kaam karte hain hi (isliye +2). Zyada shafts matlab zyada simultaneous working faces, matlab tunnel jaldi complete hogi — lekin cost bhi badhegi." },
        ],
      },
      {
        n: "2.6",
        title: "Portals and twin tunnels",
        hi: "पोर्टल और जुड़वा सुरंगें",
        blocks: [
          { k: "h", t: "📘 Notes — A p.14–15 / B p.2, 5" },
          { k: "def", term: "Portal", t: "The entrance or exit of a tunnel (B p.2). A p.14 expands this: the actual doorway or main entrance of the tunnels are known as portals — it indicates the intersection point between the underground opening and the ground surface." },
          { k: "list", items: [
            "A portal should be made massive in appearance. (A p.14)",
            "Portals should look beautiful and attractive — such construction encourages a layman to enter the tunnel with confidence of safety. (A p.14–15)",
            "In the case of a railway tunnel, revolving fans should be installed to drive fresh air in before the train enters the tunnel. (A p.15)",
          ] },
          { k: "h", t: "Twin tunnels" },
          { k: "p", t: "Sometimes, in the case of railway double lines, providing two separate tunnels proves more advantageous than a single large tunnel. Twin tunnels need not be of the same dimensions. (B p.5) A p.15 gives the fuller reasoning: each tunnel is excavated separately, and at a sufficient distance so that they cannot disturb each other during construction; they need not have the same dimensions, depending on the geological conditions at the site." },
          { k: "list", items: [
            "Increases the transportation capacity. (A p.15)",
            "Helps when one of the two tunnels is blocked for some reason. (A p.15)",
            "Improves drainage and ventilation. (A p.15)",
            "If there is trouble of hot water, it can be easily and effectively managed. (A p.15)",
            "Avoids head-on collisions, gives separate exit and entrance for the two traffic streams, and gives the facility to carry out repairs — all cited as great advantages of twin tunnels. (A p.15)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Portal ka design sirf functional nahi, 'psychological' bhi hai — massive aur attractive banane ka reason hai ki passenger tunnel mein enter karte waqt confident feel kare. Twin tunnels ka poora concept redundancy ke around hai: agar ek tunnel kisi wajah se block ho jaaye (maintenance, accident), doosra chalu rehta hai — jaisे dual carriageway ka underground version." },
        ],
      },
      {
        n: "2.7",
        title: "Quick revision",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Information needed for investigation: origin of soil, hydrology, gases, temperature, strength, weak geological features.",
            "Three investigation stages: prior to planning (geological/geophysical) → at planning (percussion/rotary percussion/rotary drilling) → at construction (heading vs drift).",
            "Heading = small-length part, no extra cost, info during construction. Drift = full-length part, info before construction.",
            "Setting out in 4 steps (B): ground-surface setting out → transfer to underground → underground setting out → underground levelling. Theodolite + laser pole; Weisbach triangle to connect two tunnel ends; alignment shafts at 500 m (A).",
            "Grade rule: tunnel grade < surface grade; 0.2% for drainage; the 75%-of-ruling-gradient rule applies beyond 3 km (A) or 300 m (B) — a genuine conflict.",
            "Shaft cuts: central wedge, pyramid/wedge, alternate wedge. Shaft types: by location (centre-line / side), by filling-time (temporary / permanent), by alignment (vertical / inclined). Faces of attack = 2N + 2.",
            "Portal: massive, attractive appearance; twin tunnels for railway double lines, need not be same size.",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Heading ≠ Drift: heading is partial-length/no extra cost, drift is full-length/complete info before construction.",
            "2N + 2 is the only real formula in this chapter's page range — remember it as '2 faces per shaft, plus the 2 portals'.",
            "Two separate length-threshold conflicts exist across these two chapters: open-cut depth (18/15/20 m) and the 75%-ruling-gradient trigger length (3 km vs 300 m) — always cite source with the number.",
          ] },
        ],
      },
    ],
  }
);
