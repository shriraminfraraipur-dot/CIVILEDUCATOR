/* ============================================================
   CIVIL EDUCATOR — accounts and cross-device sync
   ------------------------------------------------------------
   Sign-in is entirely optional. The library, the calculators and
   the exam mode all work without an account; signing in only adds
   syncing of saved items, notes and progress across devices.

   Accounts use an email address and a password. The password never
   leaves this file in readable form: derive() runs PBKDF2 over it in
   the browser and only the derived key is sent. That is not a trick
   to save bandwidth — the Workers free plan allows 10 ms of CPU per
   request, which is nowhere near enough for a real PBKDF2 run, so the
   expensive half happens here and the server salts and hashes what it
   receives. See the long note at the top of server/worker.js.

   The app asks once, after five minutes of real use, and then
   leaves the person alone for a week if they say not now.

   Talks to the worker in server/worker.js. When no backend is
   reachable — offline, or the static site deployed without the
   worker — every entry point is hidden and nothing here runs.

   Exposes window.AUTH; app.js calls init / view / act / onSave.
   ============================================================ */

window.AUTH = (function () {
  "use strict";

  const LKEY = "ccl.auth.v1";
  const PROMPT_AFTER_SEC = 300;        // five minutes of use
  const SNOOZE_DAYS = 7;
  const SYNC_DEBOUNCE_MS = 4000;

  let hooks = {};                       // getState / setState / render / esc
  let L = { usedSec: 0, lastTick: 0, promptedAt: 0, snoozeUntil: 0, dismissed: 0, lastSync: 0 };
  let cfg = { providers: [], password: false, passwordReset: false, minPassword: 8,
              pbkdf2: null, ready: false, reachable: false };
  let user = null;
  let syncTimer = null;
  let busy = false;
  let flash = "";                       // message shown at the top of the sheet
  let step = "login";                   // login | signup | forgot | reset
  let pendingEmail = "";
  let form = {};                        // signup fields kept across re-paints

  const esc = (s) => (hooks.esc ? hooks.esc(s) : String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"));
  const $ = (sel, root) => (root || document).querySelector(sel);

  function loadLocal() {
    try { L = Object.assign(L, JSON.parse(localStorage.getItem(LKEY) || "{}")); } catch (e) { }
  }
  function saveLocal() {
    try { localStorage.setItem(LKEY, JSON.stringify(L)); } catch (e) { }
  }

  /* ------------------------------------------------------------- network */

  async function call(path, opts) {
    const o = Object.assign({ credentials: "same-origin", headers: {} }, opts || {});
    if (o.body !== undefined && typeof o.body !== "string") {
      o.headers["content-type"] = "application/json";
      o.body = JSON.stringify(o.body);
    }
    const res = await fetch(path, o);
    let data = null;
    try { data = await res.json(); } catch (e) { }
    if (!res.ok) {
      const err = new Error((data && data.error) || "Request failed (" + res.status + ")");
      err.status = res.status;
      throw err;
    }
    return data || {};
  }

  /* The whole feature is optional, so a missing backend is a normal state,
     not an error: we simply never show the entry points. */
  async function probe() {
    try {
      const c = await call("/api/config");
      cfg = {
        providers: c.providers || [], password: !!c.password, passwordReset: !!c.passwordReset,
        minPassword: c.minPassword || 8, pbkdf2: c.pbkdf2 || null, ready: true, reachable: true,
      };
    } catch (e) {
      cfg = { providers: [], password: false, passwordReset: false, minPassword: 8,
              pbkdf2: null, ready: true, reachable: false };
      return;
    }
    try {
      const me = await call("/api/me");
      user = me.user || null;
    } catch (e) { user = null; }
  }

  const available = () => cfg.reachable && (cfg.password || cfg.providers.length > 0);

  /* ------------------------------------------------- password derivation */

  const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

  /* The salt comes from the email, not from the server, so asking to sign in
     never reveals whether an address is registered. It is a salt, not a
     secret: its job is to stop one rainbow table covering every user. */
  async function derive(password, email) {
    const p = cfg.pbkdf2;
    if (!p) throw new Error("Sign-in is not available right now");
    const enc = new TextEncoder();
    const saltBuf = await crypto.subtle.digest("SHA-256", enc.encode(email.trim().toLowerCase() + "|" + p.pepper));
    const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
    const bits = await crypto.subtle.deriveBits(
      { name: "PBKDF2", salt: saltBuf, iterations: p.iterations, hash: p.hash || "SHA-256" },
      key, p.bits || 256
    );
    return hex(bits);
  }

  /* Rough but useful: length matters far more than symbol soup. */
  function strength(pw) {
    if (!pw) return { n: 0, label: "" };
    let n = 0;
    if (pw.length >= 8) n++;
    if (pw.length >= 12) n++;
    if (pw.length >= 16) n++;
    if (/[^a-zA-Z0-9]/.test(pw) || (/[a-z]/.test(pw) && /[A-Z]/.test(pw) && /\d/.test(pw))) n++;
    if (/^(password|12345678|qwerty|abc12345|civil|iscode)/i.test(pw)) n = 0;
    return { n, label: ["Too weak", "Weak", "Okay", "Good", "Strong"][Math.min(n, 4)] };
  }

  /* ---------------------------------------------------------------- sync */

  /* Only the parts a person would miss. The admin editor and abuse reports
     stay on the device that made them. */
  const SYNC_KEYS = ["saved", "stats", "notes", "views", "recents", "project", "profile", "lang", "theme"];

  function slice(state) {
    const out = {};
    SYNC_KEYS.forEach((k) => { if (state[k] !== undefined) out[k] = state[k]; });
    return out;
  }

  /* One call does both directions. The server merges what we send into what
     it already holds and returns the result, and the merge is a union for
     saved items and a maximum for counters — so an empty new device never
     erases anything, and two devices used offline both keep their work.
     An earlier version pulled first and overwrote the local state with the
     server copy, which silently threw away anything saved since the last
     sync. Never separate the two halves again. */
  async function syncMerge() {
    if (!user) return;
    const r = await call("/api/sync", { method: "PUT", body: { state: slice(hooks.getState()) } });
    if (r.state) hooks.setState(Object.assign({}, hooks.getState(), r.state));
    L.lastSync = Date.now(); saveLocal();
  }

  /* app.js calls this after every local save. Batched, and silent on
     failure — a student on patchy college wifi should never see an error
     for something that will retry by itself. */
  function onSave() {
    if (!user) return;
    clearTimeout(syncTimer);
    syncTimer = setTimeout(() => { syncMerge().catch(() => { }); }, SYNC_DEBOUNCE_MS);
  }

  async function syncNow() {
    if (!user) return;
    busy = true; paint();
    try { await syncMerge(); flash = "Synced just now."; }
    catch (e) { flash = navigator.onLine ? e.message : "You are offline — it will sync when you reconnect."; }
    busy = false; paint(); if (hooks.render) hooks.render();
  }

  /* ------------------------------------------------- the five-minute ask */

  function tick() {
    if (!available() || user) return;
    const t = Date.now();
    if (L.lastTick && t - L.lastTick < 30000) L.usedSec += Math.round((t - L.lastTick) / 1000);
    L.lastTick = t;
    saveLocal();
    if (L.usedSec >= PROMPT_AFTER_SEC && t > (L.snoozeUntil || 0) && !document.getElementById("auth-sheet")) {
      openSheet("prompt");
    }
  }

  function startTimer() {
    L.lastTick = Date.now();
    setInterval(tick, 15000);
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) { L.lastTick = 0; saveLocal(); } else { L.lastTick = Date.now(); }
    });
  }

  function snooze() {
    L.snoozeUntil = Date.now() + SNOOZE_DAYS * 86400000;
    L.dismissed = (L.dismissed || 0) + 1;
    L.usedSec = 0;
    saveLocal();
  }

  /* --------------------------------------------------------------- sheet */

  const BRAND = {
    google: { label: "Google", svg: '<svg viewBox="0 0 48 48" width="18" height="18" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.6 30.2.5 24 .5 14.6.5 6.5 5.9 2.6 13.8l7.8 6c1.9-5.8 7.3-10.3 13.6-10.3z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4 6.9-10 6.9-17.5z"/><path fill="#FBBC05" d="M10.4 28.2a14.6 14.6 0 0 1 0-8.4l-7.8-6a23.5 23.5 0 0 0 0 20.4l7.8-6z"/><path fill="#34A853" d="M24 47.5c6.2 0 11.5-2 15.4-5.6l-7.5-5.8c-2.1 1.4-4.8 2.3-7.9 2.3-6.3 0-11.7-4.5-13.6-10.3l-7.8 6C6.5 42.1 14.6 47.5 24 47.5z"/></svg>' },
    facebook: { label: "Facebook", svg: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="#1877F2" d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.1 10.13 24v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.79-4.69 4.53-4.69 1.31 0 2.68.24 2.68.24v2.96h-1.51c-1.49 0-1.96.93-1.96 1.89v2.26h3.33l-.53 3.49h-2.8V24C19.61 23.1 24 18.1 24 12.07z"/></svg>' },
    linkedin: { label: "LinkedIn", svg: '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="#0A66C2" d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.47-.9 1.63-1.85 3.36-1.85 3.6 0 4.27 2.37 4.27 5.45v6.29zM5.34 7.43a2.07 2.07 0 1 1 0-4.13 2.07 2.07 0 0 1 0 4.13zM7.12 20.45H3.55V9h3.57v11.45zM22.22 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.72V1.72C24 .77 23.2 0 22.22 0z"/></svg>' },
  };

  const ROLES = [["student", "Student"], ["engineer", "Practising engineer"],
                 ["faculty", "Faculty / teacher"], ["other", "Other"]];
  const BRANCHES = ["Civil", "Structural", "Geotechnical", "Transportation",
                    "Environmental", "Construction management", "Other"];

  function socialBlock() {
    const list = cfg.providers.filter((p) => BRAND[p]);
    if (!list.length) return "";
    return `<div class="auth-social">
        ${list.map((p) => `<button type="button" class="auth-prov" data-act="authprov" data-p="${p}">${BRAND[p].svg}<span>Continue with ${BRAND[p].label}</span></button>`).join("")}
      </div>
      <div class="auth-or"><span>or</span></div>`;
  }

  const fv = (k) => esc(form[k] || "");

  function pwField(id, label, hint) {
    return `<label class="field wide"><span class="flabel">${label}</span>
        <span class="pw-wrap">
          <input id="${id}" type="password" autocomplete="${id === "su-pass" ? "new-password" : "current-password"}"
                 minlength="${cfg.minPassword}" required>
          <button type="button" class="pw-eye" data-act="autheye" data-t="${id}" aria-label="Show password">👁</button>
        </span>
        ${hint ? `<span class="fhint" id="${id}-hint">${hint}</span>` : ""}</label>`;
  }

  /* ---- sign in */
  function loginBody() {
    return `${socialBlock()}
      <form data-act="authlogin" class="auth-form">
        <label class="field wide"><span class="flabel">Email</span>
          <input id="li-email" type="email" inputmode="email" autocomplete="email"
                 placeholder="you@example.com" required value="${esc(pendingEmail)}"></label>
        ${pwField("li-pass", "Password")}
        <button class="btn" type="submit"${busy ? " disabled" : ""}>${busy ? "Checking…" : "Sign in"}</button>
      </form>
      <div class="auth-links">
        ${cfg.passwordReset ? `<button type="button" class="linkbtn" data-act="authforgot">Forgot password?</button>` : ""}
        <button type="button" class="linkbtn" data-act="authtosignup">Create an account</button>
      </div>`;
  }

  /* ---- create account. Name, email, mobile, role and password are required;
     the rest helps us but nobody is stopped for leaving it blank. */
  function signupBody() {
    const st = strength(form.pass || "");
    return `${socialBlock()}
      <form data-act="authsignup" class="auth-form">
        <div class="grid inputs">
          <label class="field"><span class="flabel">Full name</span>
            <input id="su-name" autocomplete="name" required maxlength="120" value="${fv("name")}"></label>
          <label class="field"><span class="flabel">I am a</span>
            <select id="su-role" required>
              <option value="">Choose…</option>
              ${ROLES.map(([v, l]) => `<option value="${v}"${form.role === v ? " selected" : ""}>${l}</option>`).join("")}
            </select></label>
          <label class="field wide"><span class="flabel">Email</span>
            <input id="su-email" type="email" inputmode="email" autocomplete="email"
                   placeholder="you@example.com" required value="${fv("email")}"></label>
          <label class="field wide"><span class="flabel">Mobile number</span>
            <input id="su-phone" type="tel" inputmode="tel" autocomplete="tel"
                   placeholder="10-digit number" required maxlength="20" value="${fv("phone")}">
            <span class="fhint">We do not send SMS. It is only so we can reach you if something goes wrong with your account.</span></label>
          ${pwField("su-pass", "Create a password",
            `At least ${cfg.minPassword} characters. A short sentence you will remember beats a clever short one.`)}
          <div class="field wide pw-meter" data-lvl="${st.n}">
            <span class="pw-bar"><i></i><i></i><i></i><i></i></span>
            <span class="pw-label">${esc(st.label)}</span>
          </div>
        </div>

        <details class="auth-more"${form.moreOpen ? " open" : ""}>
          <summary>Add your branch and college <span class="fine">(optional)</span></summary>
          <div class="grid inputs mt">
            <label class="field"><span class="flabel">Branch</span>
              <input id="su-branch" list="su-branches" maxlength="80" value="${fv("branch")}">
              <datalist id="su-branches">${BRANCHES.map((b) => `<option value="${b}">`).join("")}</datalist></label>
            <label class="field"><span class="flabel">Year / experience</span>
              <input id="su-year" placeholder="3rd year, or 6 years" maxlength="40" value="${fv("year")}"></label>
            <label class="field wide"><span class="flabel">College or company</span>
              <input id="su-inst" maxlength="160" value="${fv("institution")}"></label>
            <label class="field"><span class="flabel">City</span>
              <input id="su-city" maxlength="80" value="${fv("city")}"></label>
          </div>
        </details>

        <button class="btn" type="submit"${busy ? " disabled" : ""}>${busy ? "Creating…" : "Create account"}</button>
      </form>
      <div class="auth-links">
        <button type="button" class="linkbtn" data-act="authtologin">I already have an account</button>
      </div>`;
  }

  /* ---- forgot password, step 1: ask for the email */
  function forgotBody() {
    return `<form data-act="authforgotsend" class="auth-form">
        <p class="auth-sent">We will email you a 6-digit code. Enter it on the next screen and choose a new password.</p>
        <label class="field wide"><span class="flabel">Email</span>
          <input id="fg-email" type="email" inputmode="email" autocomplete="email"
                 required value="${esc(pendingEmail)}"></label>
        <button class="btn" type="submit"${busy ? " disabled" : ""}>${busy ? "Sending…" : "Send reset code"}</button>
      </form>
      <div class="auth-links"><button type="button" class="linkbtn" data-act="authtologin">Back to sign in</button></div>`;
  }

  /* ---- forgot password, step 2: code + new password */
  function resetBody() {
    const st = strength(form.pass || "");
    return `<form data-act="authreset" class="auth-form">
        <p class="auth-sent">Code sent to <strong>${esc(pendingEmail)}</strong>. It is valid for 10 minutes.</p>
        <label class="field wide"><span class="flabel">6-digit code</span>
          <input id="rs-code" type="text" inputmode="numeric" autocomplete="one-time-code"
                 pattern="[0-9]*" maxlength="6" placeholder="123456" required
                 value="${esc(form.code || "")}"></label>
        ${pwField("su-pass", "New password", `At least ${cfg.minPassword} characters.`)}
        <div class="field wide pw-meter" data-lvl="${st.n}">
          <span class="pw-bar"><i></i><i></i><i></i><i></i></span>
          <span class="pw-label">${esc(st.label)}</span>
        </div>
        <button class="btn" type="submit"${busy ? " disabled" : ""}>${busy ? "Saving…" : "Set new password and sign in"}</button>
      </form>
      <div class="auth-links">
        <button type="button" class="linkbtn" data-act="authforgot">Send the code again</button>
        <button type="button" class="linkbtn" data-act="authtologin">Back to sign in</button>
      </div>
      <p class="fine">Setting a new password signs you out everywhere else.</p>`;
  }

  function sheetBody(mode) {
    const head = {
      prompt: `<span class="auth-ico" aria-hidden="true">⭐</span>
        <h2>Keep your work</h2>
        <p>You have been reading for a while. Create a free account and your saved codes, notes and quiz progress follow you to any phone or laptop — and come back if you reinstall the app.</p>`,
      signup: `<span class="auth-ico" aria-hidden="true">✍️</span>
        <h2>Create your account</h2>
        <p>Free, and takes a minute. It keeps your saved codes, notes and progress safe across devices.</p>`,
      login: `<span class="auth-ico" aria-hidden="true">👤</span>
        <h2>Sign in</h2>
        <p>Welcome back.</p>`,
      forgot: `<span class="auth-ico" aria-hidden="true">🔑</span>
        <h2>Forgot your password</h2>`,
      reset: `<span class="auth-ico" aria-hidden="true">🔑</span>
        <h2>Choose a new password</h2>`,
    }[step === "signup" && mode === "prompt" ? "prompt" : step] || "";

    const body = step === "signup" ? signupBody()
      : step === "forgot" ? forgotBody()
      : step === "reset" ? resetBody()
      : loginBody();

    return `<div class="auth-card" role="dialog" aria-modal="true" aria-label="Account">
      <button class="auth-x" data-act="authclose" aria-label="Close">✕</button>
      ${head}
      ${flash ? `<p class="auth-flash">${esc(flash)}</p>` : ""}
      ${body}
      <button class="auth-later" data-act="authlater">${mode === "prompt" ? "Not now — keep exploring" : "Cancel"}</button>
      <p class="fine auth-legal">We never post anything anywhere, and never share your details.
        <a href="privacy.html" target="_blank" rel="noopener">Privacy policy</a></p>
    </div>`;
  }

  let sheetMode = "signin";

  function openSheet(mode) {
    if (!available()) return;
    sheetMode = mode || "signin";
    flash = ""; busy = false;
    step = mode === "prompt" ? "signup" : "login";
    let el = document.getElementById("auth-sheet");
    if (!el) {
      el = document.createElement("div");
      el.id = "auth-sheet";
      el.className = "auth-sheet";
      document.body.appendChild(el);
    }
    if (mode === "prompt") { L.promptedAt = Date.now(); saveLocal(); }
    paint();
    setTimeout(() => {
      const f = $("#su-name") || $("#li-email") || $("#fg-email") || $("#rs-code");
      if (f) f.focus();
    }, 60);
  }

  function paint() {
    const el = document.getElementById("auth-sheet");
    if (!el) return;
    el.innerHTML = sheetBody(sheetMode);
  }

  function closeSheet() {
    const el = document.getElementById("auth-sheet");
    if (el) el.remove();
    flash = ""; busy = false; form = {};
  }

  /* Keep what has been typed, so re-painting for the strength meter or an
     error message never wipes a half-filled form. */
  function grabSignup() {
    const g = (id) => { const el = $("#" + id); return el ? el.value : undefined; };
    const map = { name: "su-name", role: "su-role", email: "su-email", phone: "su-phone",
                  pass: "su-pass", branch: "su-branch", year: "su-year",
                  institution: "su-inst", city: "su-city" };
    Object.keys(map).forEach((k) => { const v = g(map[k]); if (v !== undefined) form[k] = v; });
    const d = $(".auth-more");
    if (d) form.moreOpen = d.open;
  }

  /* --------------------------------------------------------------- flows */

  function goStep(next) {
    if (step === "signup") grabSignup();
    step = next; flash = ""; paint();
    setTimeout(() => {
      const f = next === "signup" ? $("#su-name") : next === "login" ? $("#li-email")
        : next === "forgot" ? $("#fg-email") : $("#rs-code");
      if (f) f.focus();
    }, 50);
  }

  async function doSignup(el) {
    grabSignup();
    const v = (k) => String(form[k] || "").trim();
    const email = v("email").toLowerCase();
    const pass = String(form.pass || "");
    if (v("name").length < 2) { flash = "Please enter your name."; return paint(); }
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) { flash = "Please check the email address."; return paint(); }
    if (v("phone").replace(/\D/g, "").length < 10) { flash = "Please enter a 10-digit mobile number."; return paint(); }
    if (!v("role")) { flash = "Please choose whether you are a student or a practising engineer."; return paint(); }
    if (pass.length < cfg.minPassword) { flash = `Password needs at least ${cfg.minPassword} characters.`; return paint(); }
    if (strength(pass).n === 0) { flash = "That password is too easy to guess. Try a short sentence instead."; return paint(); }

    busy = true; flash = ""; paint();
    try {
      const dk = await derive(pass, email);
      const r = await call("/api/auth/signup", {
        method: "POST",
        body: {
          name: v("name"), email, phone: v("phone"), role: v("role"), dk,
          branch: v("branch"), year: v("year"), institution: v("institution"), city: v("city"),
        },
      });
      user = r.user;
      await afterSignIn();
    } catch (e) {
      flash = e.message;
      if (e.status === 409) { pendingEmail = email; step = "login"; }
      busy = false; paint();
    }
  }

  async function doLogin() {
    const email = (($("#li-email") || {}).value || "").trim().toLowerCase();
    const pass = ($("#li-pass") || {}).value || "";
    if (!email || !pass) { flash = "Enter your email and password."; return paint(); }
    pendingEmail = email;
    busy = true; flash = ""; paint();
    try {
      const dk = await derive(pass, email);
      const r = await call("/api/auth/login", { method: "POST", body: { email, dk } });
      user = r.user;
      await afterSignIn();
    } catch (e) {
      flash = e.message; busy = false; paint();
    }
  }

  async function sendResetCode(email) {
    pendingEmail = email; busy = true; flash = ""; paint();
    try {
      await call("/api/auth/reset/request", { method: "POST", body: { email } });
      step = "reset"; form.pass = ""; form.code = "";
    } catch (e) { flash = e.message; }
    busy = false; paint();
    setTimeout(() => { const f = $("#rs-code"); if (f) f.focus(); }, 60);
  }

  async function doReset() {
    const code = ((($("#rs-code") || {}).value) || form.code || "").replace(/\D/g, "");
    const pass = ($("#su-pass") || {}).value || "";
    if (code.length !== 6) { flash = "Enter all six digits."; return paint(); }
    if (pass.length < cfg.minPassword) { flash = `Password needs at least ${cfg.minPassword} characters.`; return paint(); }
    busy = true; flash = ""; paint();
    try {
      const dk = await derive(pass, pendingEmail);
      const r = await call("/api/auth/reset/verify", { method: "POST", body: { email: pendingEmail, code, dk } });
      user = r.user;
      await afterSignIn();
    } catch (e) { flash = e.message; busy = false; paint(); }
  }

  async function afterSignIn() {
    busy = false;
    closeSheet();
    L.usedSec = 0; L.snoozeUntil = 0; saveLocal();
    try { await syncMerge(); } catch (e) { }
    if (hooks.render) hooks.render();
    if (hooks.buildNav) hooks.buildNav();
    location.hash = "#/account";
  }

  function startSocial(p) {
    const w = window.open("/api/auth/" + p + "/start", "ccl_auth", "width=480,height=640");
    if (!w) { location.href = "/api/auth/" + p + "/start"; return; }
    const onMsg = async (ev) => {
      if (ev.origin !== location.origin || !ev.data || ev.data.ccl !== "auth") return;
      window.removeEventListener("message", onMsg);
      if (ev.data.ok) {
        try { const me = await call("/api/me"); user = me.user || null; } catch (e) { }
        if (user) await afterSignIn(); else { flash = "Sign-in did not complete."; paint(); }
      } else { flash = "That sign-in did not complete. Try email and password instead."; paint(); }
    };
    window.addEventListener("message", onMsg);
  }

  async function signOut() {
    try { await call("/api/auth/logout", { method: "POST" }); } catch (e) { }
    user = null;
    if (hooks.buildNav) hooks.buildNav();
    if (hooks.render) hooks.render();
  }

  async function deleteAccount() {
    if (!confirm("Delete your account and everything stored on the server?\n\nYour saved codes, notes and progress on the server are erased and cannot be recovered. What is on this device stays until you clear it.")) return;
    if (!confirm("Last check — this cannot be undone. Delete the account?")) return;
    try {
      await call("/api/me", { method: "DELETE" });
      user = null;
      alert("Account deleted. Nothing about you is left on the server.");
      if (hooks.buildNav) hooks.buildNav();
      location.hash = "#/profile";
      if (hooks.render) hooks.render();
    } catch (e) { alert("Could not delete the account: " + e.message); }
  }

  async function saveProfile(formEl) {
    const val = (id) => { const el = $("#" + id, formEl); return el ? el.value.trim() : ""; };
    busy = true; if (hooks.render) hooks.render();
    try {
      const r = await call("/api/me", {
        method: "POST",
        body: {
          name: val("pf-name"), role: val("pf-role"), branch: val("pf-branch"),
          year: val("pf-year"), institution: val("pf-inst"), city: val("pf-city"), phone: val("pf-phone"),
        },
      });
      user = r.user; flash = "Saved.";
    } catch (e) { flash = e.message; }
    busy = false; if (hooks.render) hooks.render();
  }

  async function changePassword(formEl) {
    const val = (id) => { const el = $("#" + id, formEl); return el ? el.value : ""; };
    const oldPw = val("cp-old"), newPw = val("cp-new");
    if (user.hasPassword && !oldPw) { flash = "Enter your current password."; return hooks.render && hooks.render(); }
    if (newPw.length < cfg.minPassword) { flash = `New password needs at least ${cfg.minPassword} characters.`; return hooks.render && hooks.render(); }
    busy = true; if (hooks.render) hooks.render();
    try {
      const body = { newDk: await derive(newPw, user.email) };
      if (user.hasPassword) body.oldDk = await derive(oldPw, user.email);
      await call("/api/me/password", { method: "POST", body });
      const me = await call("/api/me"); user = me.user;
      flash = "Password updated.";
    } catch (e) { flash = e.message; }
    busy = false; if (hooks.render) hooks.render();
  }

  /* ------------------------------------------------------- account screen */

  function view() {
    if (!available()) {
      return `<header class="page-head"><h1>Account</h1></header>
        <section class="card"><h2>Accounts are not switched on for this site</h2>
        <p>Everything you save is kept on this device only. If this is the live site and you expected sign-in to work, the API worker has not been deployed yet — see the setup guide in the package.</p></section>`;
    }
    if (!user) {
      return `<header class="page-head"><h1>Account</h1>
          <p class="lede">Optional. The whole library works without it.</p></header>
        <section class="card cta-card">
          <div><h2>Create a free account</h2>
            <p>Saved codes, notes, quiz progress and your project list on every device you use — and safe if you lose the phone.</p></div>
          <div class="row-actions">
            <button class="btn" data-act="authsignupopen">Create account</button>
            <button class="btn ghost" data-act="authopen">Sign in</button>
          </div>
        </section>
        <section class="card">
          <h2>What we ask for</h2>
          <div class="rows">
            <div class="row static"><div class="row-main"><div class="row-title">Name, email, mobile and whether you are a student or an engineer</div><div class="row-sub">Required. The email identifies the account; the mobile is only so we can reach you if something goes wrong with it — we do not send SMS.</div></div></div>
            <div class="row static"><div class="row-main"><div class="row-title">Branch, year, college or company, city</div><div class="row-sub">Optional. Helps us see who the app is serving and what to build next.</div></div></div>
            <div class="row static"><div class="row-main"><div class="row-title">A password</div><div class="row-sub">Scrambled in your browser before it is sent. We never see it, and it is not stored anywhere in a form that could be used to sign in.</div></div></div>
          </div>
          <p class="fine">Nothing is shared with anyone. You can delete the account and everything in it from this screen at any time. <a class="link" href="privacy.html" target="_blank" rel="noopener">Privacy policy</a></p>
        </section>`;
    }

    const u = user;
    const last = L.lastSync ? new Date(L.lastSync).toLocaleString() : "not yet";
    const provLabel = { google: "Google", facebook: "Facebook", linkedin: "LinkedIn" }[u.provider];
    return `<header class="page-head"><h1>Account</h1>
        <p class="lede mono">${esc(u.email)}</p></header>
      ${flash ? `<div class="callout-note">${esc(flash)}</div>` : ""}
      <section class="card cta-card">
        <div><h2>Sync</h2><p class="fine">Last synced: ${esc(last)}</p></div>
        <button class="btn ghost" data-act="authsync"${busy ? " disabled" : ""}>${busy ? "Syncing…" : "Sync now"}</button>
      </section>

      <section class="card">
        <h2>Your details</h2>
        <form data-act="authprofile" class="grid inputs mt">
          <label class="field"><span class="flabel">Name</span><input id="pf-name" value="${esc(u.name)}" maxlength="120"></label>
          <label class="field"><span class="flabel">I am a</span>
            <select id="pf-role">${ROLES.map(([v, l]) => `<option value="${v}"${u.role === v ? " selected" : ""}>${l}</option>`).join("")}</select></label>
          <label class="field"><span class="flabel">Branch</span>
            <input id="pf-branch" list="pf-branches" value="${esc(u.branch)}" maxlength="80">
            <datalist id="pf-branches">${BRANCHES.map((b) => `<option value="${b}">`).join("")}</datalist></label>
          <label class="field"><span class="flabel">Year / experience</span><input id="pf-year" value="${esc(u.year)}" placeholder="3rd year, or 6 years" maxlength="40"></label>
          <label class="field wide"><span class="flabel">College or company</span><input id="pf-inst" value="${esc(u.institution)}" maxlength="160"></label>
          <label class="field"><span class="flabel">City</span><input id="pf-city" value="${esc(u.city)}" maxlength="80"></label>
          <label class="field"><span class="flabel">Mobile</span><input id="pf-phone" type="tel" inputmode="tel" value="${esc(u.phone)}" maxlength="20"></label>
          <div class="row-actions wide"><button class="btn" type="submit"${busy ? " disabled" : ""}>Save details</button></div>
        </form>
      </section>

      <section class="card">
        <h2>${u.hasPassword ? "Change password" : "Set a password"}</h2>
        ${u.hasPassword ? "" : `<p class="fine">This account was created with ${esc(provLabel || "a social login")}. Setting a password lets you sign in with your email as well.</p>`}
        <form data-act="authpassword" class="grid inputs mt">
          ${u.hasPassword ? `<label class="field wide"><span class="flabel">Current password</span>
            <span class="pw-wrap"><input id="cp-old" type="password" autocomplete="current-password">
            <button type="button" class="pw-eye" data-act="autheye" data-t="cp-old" aria-label="Show password">👁</button></span></label>` : ""}
          <label class="field wide"><span class="flabel">New password</span>
            <span class="pw-wrap"><input id="cp-new" type="password" autocomplete="new-password" minlength="${cfg.minPassword}">
            <button type="button" class="pw-eye" data-act="autheye" data-t="cp-new" aria-label="Show password">👁</button></span>
            <span class="fhint">At least ${cfg.minPassword} characters.</span></label>
          <div class="row-actions wide"><button class="btn ghost" type="submit"${busy ? " disabled" : ""}>${u.hasPassword ? "Update password" : "Set password"}</button></div>
        </form>
      </section>

      <section class="card">
        <h2>Leaving</h2>
        <div class="row-actions">
          <button class="btn ghost" data-act="authout">Sign out</button>
          <button class="btn ghost danger" data-act="authdelete">Delete account</button>
        </div>
        <p class="fine">Signing out leaves your data on the server. Deleting erases the account, your synced items and your details — permanently, and straight away.</p>
      </section>`;
  }

  function act(el, a, ev) {
    switch (a) {
      case "authopen": openSheet("signin"); return true;
      case "authsignupopen": openSheet("signin"); goStep("signup"); return true;
      case "authclose": closeSheet(); return true;
      case "authlater": snooze(); closeSheet(); return true;
      case "authprov": startSocial(el.dataset.p); return true;
      case "authtologin": goStep("login"); return true;
      case "authtosignup": goStep("signup"); return true;
      case "authforgot":
        pendingEmail = (($("#li-email") || {}).value || pendingEmail || "").trim().toLowerCase();
        if (step === "reset" && pendingEmail) sendResetCode(pendingEmail); else goStep("forgot");
        return true;
      case "autheye": {
        const inp = document.getElementById(el.dataset.t);
        if (inp) {
          const show = inp.type === "password";
          inp.type = show ? "text" : "password";
          el.setAttribute("aria-label", show ? "Hide password" : "Show password");
          el.classList.toggle("on", show);
          inp.focus();
        }
        return true;
      }
      case "authsync": syncNow(); return true;
      case "authout": signOut(); return true;
      case "authdelete": deleteAccount(); return true;
      default: return false;
    }
  }

  /* The strength meter has to react as the person types, which means a repaint,
     which means the form has to be re-read first — grabSignup does that. */
  function input(el) {
    if (!document.getElementById("auth-sheet")) return false;
    if (step === "reset" && el.id === "rs-code") { form.code = el.value; return false; }
    if (el.id !== "su-pass") return false;
    if (step !== "signup" && step !== "reset") return false;
    const before = strength(form.pass || "").label;
    if (step === "signup") grabSignup(); else form.pass = el.value;
    // Compare the label, not the score: blank -> "Too weak" is a change worth
    // showing, and both of those score zero.
    if (strength(form.pass || "").label === before) return false;
    const pos = el.selectionStart, wasText = el.type === "text";
    paint();
    const again = document.getElementById("su-pass");
    if (again) {
      again.value = form.pass || "";
      if (wasText) again.type = "text";
      again.focus();
      try { again.setSelectionRange(pos, pos); } catch (e) { }
    }
    return true;
  }

  function submit(el, a) {
    if (a === "authsignup") { doSignup(el); return true; }
    if (a === "authlogin") { doLogin(); return true; }
    if (a === "authforgotsend") {
      const v = (($("#fg-email", el) || {}).value || "").trim().toLowerCase();
      if (v) sendResetCode(v);
      return true;
    }
    if (a === "authreset") { doReset(); return true; }
    if (a === "authprofile") { saveProfile(el); return true; }
    if (a === "authpassword") { changePassword(el); return true; }
    return false;
  }

  /* A signed-in person gets an Account row; everyone else gets it only when
     the backend is actually there, so the static-only build stays clean. */
  function navItem() {
    if (!available()) return "";
    const label = user ? (user.name ? user.name.split(" ")[0] : "Account") : "Sign in";
    const icon = user ? "👤" : "🔑";
    return `<a href="#/account" data-nav="account" data-act="closenav"><span aria-hidden="true">${icon}</span>${esc(label)}</a>`;
  }

  async function init(h) {
    hooks = h || {};
    loadLocal();
    await probe();
    if (available()) {
      if (hooks.buildNav) hooks.buildNav();
      if (user) { syncMerge().then(() => { if (hooks.render) hooks.render(); }).catch(() => { }); }
      else startTimer();
      if (hooks.render) hooks.render();
    }
    window.addEventListener("online", () => { if (user) syncMerge().catch(() => { }); });
  }

  return {
    init, view, act, submit, input, onSave, navItem, openSheet, tick,
    get user() { return user; },
    get available() { return available(); },
  };
})();
