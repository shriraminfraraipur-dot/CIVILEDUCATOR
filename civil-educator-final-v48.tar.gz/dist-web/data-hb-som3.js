/* ============================================================
   STRENGTH OF MATERIALS · COMPLETE NOTES — Chapter 8
   Strain Energy Methods (Castigliano's theorem, least work,
   unit load method, impact/sudden/gradual loading)

   UNLIKE Chapters 1-7 (sourced from the handbook's original
   17-page handwritten class notes), this chapter is new content
   added under the CivilEducator Phase-1 research pipeline (v26),
   then re-audited through the chapter quality gate in v33: a
   Castigliano naming conflict between sources is now flagged, a
   wrong statement about the gradual-load case was corrected, and
   least work, axial strain energy, a truss example and a figure
   were added. Every formula is cross-checked against at least
   two independent sources (named inline) or derived here.

   Defensive-guard pattern: safe to load in any order relative to
   the shell file and the other SOM chapter files.
   ============================================================ */
window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) { console.error("som handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "som-8", n: 8,
    title: "Strain Energy Methods",
    hi: "स्ट्रेन एनर्जी विधियाँ",
    blurb: "Strain energy in axial, shear, torsion and bending; Castigliano's theorem (with the first/second naming conflict between textbooks explained) and the dummy-load trick; the theorem of least work for statically indeterminate beams; the unit load method for beams and trusses; and gradual, sudden and impact loading — with 5 worked examples, all cross-checked against Chapter 5's deflection table.",
    mins: 35,
    sections: [
      {
        n: "8.1",
        title: "Strain energy — recap, and the bending case",
        hi: "स्ट्रेन एनर्जी — पुनरावलोकन और बेंडिंग केस",
        blocks: [
          { k: "h", t: "📘 Recap from Chapter 6" },
          { k: "p", t: "Chapter 6.4 already gave the strain energy (resilience) stored under axial/direct stress, shear and torsion: U = f²/2E × V, τ²/2G × V, and τ²/4G × V respectively. What those don't cover — and what this chapter needs — is the strain energy stored in a <b>beam under bending</b>." },
          { k: "eq", expr: "Axial member:  U = P²L/(2AE)   ;   Torsion:  U = T²L/(2GJ)   ;   Bending:  U = ∫₀ᴸ M²/(2EI) dx", where: [
            ["P²L/2AE", "same as f²V/2E with f = P/A, V = AL (axial form as given by Purdue ME 323)"],
            ["T²L/2GJ", "same as the τ²V/4G of Chapter 6 for a solid shaft (derived)"],
            ["M", "bending moment at a section, as a function of position x along the beam"],
            ["E, I", "Young's modulus and second moment of area of the section"],
          ] },
          { k: "p", t: "Every form is 'load² × length ÷ (2 × stiffness)', because strain energy = work done by a gradually applied load = ½ × load × deflection. Shear-deformation energy in beams also exists but is negligible for ordinary (slender) beams, so it is left out (consistent with the bending assumptions of <a href=\"#/read/som/4\">Chapter 4.1</a>)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh exactly wahi <b>f²/2E × V</b> wala pattern hai jo Chapter 6 mein tha — (stress)²/(2×modulus) × volume — bas ab stress section ke saath M/Z ki tarah vary karta hai, isliye integral lagana padta hai instead of a single multiplication. Yeh formula Castigliano's theorem aur unit load method dono ka starting point hai, isliye yahan explicitly likh diya." },
          { k: "note", t: "<b>Sources (cross-checked):</b> U = ∫M²/2EI dx is given identically by <a href=\"https://mathalino.com/node/1703\" target=\"_blank\" rel=\"noopener\">Mathalino — Strain Energy Method (Castigliano's Theorem)</a> and by <a href=\"https://roymech.org/Useful_Tables/Beams/Beam_energy_methods.html\" target=\"_blank\" rel=\"noopener\">RoyMech — Energy Methods for Beams</a>; P²L/2AE by <a href=\"https://www.purdue.edu/freeform/me323/wp-content/uploads/sites/2/2022/08/castigliano01-1.pdf\" target=\"_blank\" rel=\"noopener\">Purdue ME 323 — Castigliano</a>." },
        ],
      },
      {
        n: "8.2",
        title: "Castigliano's theorem — deflection as ∂U/∂P",
        hi: "कैस्टिग्लियानो का प्रमेय",
        blocks: [
          { k: "h", t: "📘 Notes — researched & verified" },
          { k: "def", term: "Castigliano's theorem (δ = ∂U/∂P)", t: "The partial derivative of the total strain energy of a linearly elastic structure, with respect to a load (or moment) acting on it, equals the deflection (or rotation) at the point of that load, measured in its own direction." },
          { k: "note", t: "<b>Naming conflict between sources — same result, different number.</b> Many Indian textbooks (and the v26 version of this chapter) call δ = ∂U/∂P <i>Castigliano's first theorem</i> and the least-work condition ∂U/∂R = 0 his second. Purdue's CE 474 notes instead call δ = ∂U/∂P <b>Castigliano's second theorem</b>, reserving 'first theorem' for the converse statement P = ∂U/∂δ (load as the derivative of strain energy with respect to displacement) (<a href=\"https://engineering.purdue.edu/~ce474/Docs/The%20Theorem%20of%20Least%20Work_2012.pdf\" target=\"_blank\" rel=\"noopener\">Purdue CE 474 — Theorem of Least Work</a>). The mathematics is identical; in an exam, write the equation as well as the name." },
          { k: "eq", expr: "δ = ∂U/∂P      (linear deflection under a point load P)\nθ = ∂U/∂M      (rotation under an applied moment M)" },
          { k: "eq", expr: "For a beam, combined with §8.1's U:  δ = ∫₀ᴸ (∂M/∂P) · (M/EI) dx" },
          { k: "p", t: "<b>Dummy-load trick:</b> to find the deflection where no load acts, add a fictitious load P_d there, carry it through, differentiate, and then set P_d = 0 (<a href=\"https://www.purdue.edu/freeform/me323/wp-content/uploads/sites/2/2022/08/castigliano01-1.pdf\" target=\"_blank\" rel=\"noopener\">Purdue ME 323</a>)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Pehle M ko P ke function ke roop mein likho (actual load P ke saath), phir M ko <b>P ke respect mein partial differentiate</b> karo (∂M/∂P) — yeh batata hai ki M, P ke badalne par kitna sensitive hai, which is exactly the leverage a unit change in P has on the deflection. Fir dono ko multiply karke integrate karo. Agar kisi point par deflection chahiye jahan actually koi load nahi hai, to wahan ek <b>dummy/fictitious load</b> laga do, differentiate karke, end mein usse zero rakh do — yeh trick aage §8.4 ka unit-load-method bhi isi idea ka ek direct version hai." },
          { k: "eg", title: "Worked example 8.1 — cantilever free-end deflection via Castigliano's theorem", given: "A cantilever of length L, flexural rigidity EI, carries a point load P at its free end. Find the deflection at the free end using Castigliano's theorem, and check it against the standard cantilever-deflection result.", steps: [
            { t: "Measure x from the free end (0 ≤ x ≤ L); write the bending moment at x due to P", w: "M(x) = P·x" },
            { t: "Differentiate M with respect to P", w: "∂M/∂P = x" },
            { t: "Apply Castigliano's theorem", w: "δ = ∫₀ᴸ x·(Px)/EI dx = (P/EI) ∫₀ᴸ x² dx = (P/EI)·(L³/3)" },
          ], ans: "δ = PL³/(3EI) — exactly the standard cantilever end-deflection value already in Chapter 5's beam-deflection table, confirming the method." },
          { k: "note", t: "<b>Sources (cross-checked):</b> the theorem statement and δ = ∂U/∂P are given in matching substance by <a href=\"https://mathalino.com/node/1703\" target=\"_blank\" rel=\"noopener\">Mathalino</a> (\"the partial derivative of the strain energy with respect to an applied force... is equal to the displacement... along its line of action\") and <a href=\"https://roymech.org/Useful_Tables/Beams/Beam_energy_methods.html\" target=\"_blank\" rel=\"noopener\">RoyMech</a> (\"the displacement corresponding to any force collinear with the force is equal to the partial derivative of the total strain energy with respect to that force\")." },
        ],
      },
      {
        n: "8.3",
        title: "Theorem of least work — statically indeterminate beams",
        hi: "न्यूनतम कार्य का प्रमेय",
        blocks: [
          { k: "def", term: "Theorem of least work", t: "The redundant reactions of a statically indeterminate structure take the values that make its strain energy a <b>minimum</b>: ∂U/∂R = 0 for each redundant R. It follows from Castigliano's theorem, because the deflection at a rigid support (∂U/∂R) must be zero (<a href=\"https://engineering.purdue.edu/~ce474/Docs/The%20Theorem%20of%20Least%20Work_2012.pdf\" target=\"_blank\" rel=\"noopener\">Purdue CE 474</a>)." },
          { k: "steps", items: [
            "Choose the redundant(s) R — e.g. the prop of a propped cantilever (degree of indeterminacy from Chapter 5.1).",
            "Write M everywhere in terms of the loads and R.",
            "Set ∂U/∂R = ∫(M/EI)(∂M/∂R) dx = 0 and solve for R.",
          ] },
          { k: "eg", title: "Worked example 8.2 — prop reaction by least work", given: "Propped cantilever, span L, UDL w, prop at the free end. Find the prop reaction R.", steps: [
            { t: "Moment at distance x from the prop", w: "M = R·x − w·x²/2;  ∂M/∂R = x" },
            { t: "Least work", w: "∂U/∂R = (1/EI)∫₀ᴸ (Rx − wx²/2)·x dx = (1/EI)(R·L³/3 − w·L⁴/8) = 0" },
          ], ans: "R = 3wL/8 — the same value Chapter 5.4 obtained by superposition, by an entirely different route." },
          { k: "trap", t: "Least work sirf <b>redundant</b> reactions ke liye hai — determinate reactions equilibrium se hi aate hain. Aur ∂U/∂R = 0 tabhi jab support rigid ho; agar support settle hota hai to ∂U/∂R = settlement (sign ke saath)." },
        ],
      },
      {
        n: "8.4",
        title: "Unit load method (virtual work)",
        hi: "यूनिट लोड विधि (वर्चुअल वर्क)",
        blocks: [
          { k: "h", t: "📘 Notes — researched & verified" },
          { k: "def", term: "Unit load method", t: "Apply a fictitious unit load (1) at the point and in the direction where the deflection is wanted, find the internal-force diagram that unit load alone produces, and combine it with the real internal-force diagram from the actual loads by an integral (beams) or a member-by-member sum (trusses)." },
          { k: "eq", expr: "Truss joint deflection:  δ = Σ (n·N·L)/(A·E)      [sum over every member]", where: [
            ["N", "axial force in a member due to the real loads"],
            ["n", "axial force in the same member due to the unit load alone"],
            ["L, A, E", "that member's length, cross-section area and Young's modulus"],
          ] },
          { k: "eq", expr: "Beam/frame deflection:  δ = ∫₀ᴸ (m·M)/(EI) dx", where: [
            ["M", "bending moment at x due to the real loads"],
            ["m", "bending moment at x due to the unit load alone"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh Castigliano's theorem ka hi ek shortcut version hai: wahan ∂M/∂P nikalna padta tha, yahan directly ek <b>unit load (=1)</b> laga ke uska apna moment/force diagram (m ya n) nikal lo — differentiate karne ki zarurat nahi, kyunki m/n already \"per unit P\" hi hai. Truss ke liye sum isliye hai kyunki har member mein deformation uniform hota hai (ek hi N, ek hi A); beam ke liye integral isliye kyunki M section ke saath continuously vary karta hai." },
          { k: "eg", title: "Worked example 8.3 — mid-span deflection of a simply supported beam, via the unit load method", given: "A simply supported beam of span L, flexural rigidity EI, carries a point load P at mid-span. Find the mid-span deflection using the unit load method, and check it against the standard result.", steps: [
            { t: "By symmetry, work on the left half (0 ≤ x ≤ L/2) and double the integral. Real moment due to P at mid-span", w: "M(x) = (P/2)·x" },
            { t: "Unit-load moment, same position, load = 1", w: "m(x) = (1/2)·x" },
            { t: "Apply the unit load method and double for symmetry", w: "δ = 2∫₀^(L/2) (x/2)(Px/2)/EI dx = (P/2EI) ∫₀^(L/2) x² dx = (P/2EI)·(L³/24)" },
          ], ans: "δ = PL³/(48EI) — exactly the standard simply-supported, central-point-load deflection already in Chapter 5's beam-deflection table." },
          { k: "dia", id: "hb-som-truss" },
          { k: "eg", title: "Worked example 8.4 — vertical deflection of a truss apex", given: "Triangular truss: tie AB = 6 m, rafters AC = BC = 5 m, height 4 m; pin at A, roller at B; P = 100 kN downward at C. All members A = 1000 mm², E = 2 × 10⁵ N/mm². Find: vertical deflection of C.", steps: [
            { t: "Real forces (joint A: R_A = 50 kN; sinθ = 4/5, cosθ = 3/5)", w: "N_AC = N_BC = −50/(4/5) = −62.5 kN (C);  N_AB = 62.5 × 3/5 = +37.5 kN (T)" },
            { t: "Unit-load forces (1 at C, downward) — real ones ÷ 100", w: "n_AC = n_BC = −0.625;  n_AB = +0.375" },
            { t: "Σ n·N·L (N in N, L in mm)", w: "2 × (−0.625)(−62 500)(5000) + (0.375)(37 500)(6000)\n= 390.6 × 10⁶ + 84.4 × 10⁶ = 475 × 10⁶ N·mm" },
            { t: "Divide by AE", w: "δ_C = 475 × 10⁶ / (1000 × 2 × 10⁵) = 2.375 mm (downward)" },
          ], ans: "δ_C ≈ 2.38 mm. Interpretation: the compressed rafters contribute 82% of the deflection; a stiffer rafter section would cut it most — and the same Σ nNL/AE is how camber is set for steel roof trusses." },
          { k: "note", t: "<b>Source:</b> both formulas given in this exact form (δ = Σ nNL/AE for trusses, δ = ∫mM/EI dx for beams) by <a href=\"https://supertutor.ph/resources/exams/cele-civil-engineering/structural-theory-analysis/deflections-of-structures/cheat-sheet/\" target=\"_blank\" rel=\"noopener\">SuperTutor PH — Structural Theory, Deflections cheat sheet</a>, and cross-checked against this chapter's own Castigliano derivation in §8.2 (both worked examples above reproduce Chapter 5's existing deflection-table values)." },
          { k: "trap", t: "The unit load's internal-force diagram (m or n) is found from the unit load ALONE, with the real loads removed — it is not the real-load diagram scaled down. Mixing the two up is the single most common mistake in this method. (In Worked example 8.4 the two happen to be proportional only because the unit load sits exactly where the single real load acts.)" },
        ],
      },
      {
        n: "8.5",
        title: "Strain energy under gradual, sudden and impact loading",
        hi: "क्रमिक, आकस्मिक और प्रभाव भार में स्ट्रेन एनर्जी",
        blocks: [
          { k: "h", t: "📘 Notes — researched & verified, with one correction" },
          { k: "def", term: "Gradually applied load", t: "A load W built up slowly from zero to its full value, as in ordinary static loading. The bar simply stretches to its static extension with no overshoot." },
          { k: "eq", expr: "Gradual load:  σ_gradual = W/A      ;      δ_gradual = WL/(AE)" },
          { k: "def", term: "Suddenly applied load", t: "The full load W is applied all at once (e.g. released instantly), with no fall height. The bar overshoots its static extension before settling." },
          { k: "eq", expr: "Sudden load:  σ_sudden = 2W/A = 2 × σ_gradual" },
          { k: "def", term: "Impact (falling) load", t: "A weight W falls freely through a height h before striking the bar." },
          { k: "h", t: "Deriving the impact-load formula from energy balance" },
          { k: "steps", items: [
            "Let δ = the bar's maximum instantaneous extension under impact. The weight falls a total distance (h + δ) before the bar brings it to rest, so energy lost by the weight = W(h + δ).",
            "That energy goes entirely into strain energy stored in the bar at its maximum extension δ: strain energy = ½ × (stiffness) × δ² = ½ × (AE/L) × δ².",
            "Equate the two: W(h + δ) = (AE/2L)·δ² — a quadratic in δ.",
            "Solve the quadratic (taking the positive root) and write it in terms of the gradual-load static extension δ_gradual = WL/(AE): δ_impact = δ_gradual · [1 + √(1 + 2h/δ_gradual)].",
            "Since stress is proportional to extension for a prismatic bar, the same bracketed factor multiplies the stress.",
          ] },
          { k: "eq", expr: "σ_impact = (W/A) · [ 1 + √(1 + 2hAE/(WL)) ]      ;      δ_impact = δ_gradual · [1 + √(1 + 2hAE/(WL))]" },
          { k: "p", t: "When h is large compared with δ_gradual, the bracket is ≈ √(2h/δ_gradual), i.e. σ_impact ≈ √(2WhE/(AL)) — the energy W·h is what matters, and a <b>longer or larger bar reduces the impact stress</b> (more volume to store the energy), the opposite of static loading (derived from the formula above)." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Sudden load is the impact formula with <b>h = 0</b>: √(1 + 0) = 1, so the bracket is 2 and σ_sudden = 2σ_gradual. The gradual load is <b>not</b> a limit of this formula — it comes from a different energy balance. When the load is built up slowly, the work done is only ½·W·δ (the average of 0 and W times δ), not W·δ, and that gives δ = WL/AE with no amplification. So yaad rakhne layak do baatein: (1) impact formula ka h = 0 case sudden load hai; (2) gradual load alag case hai jahan load dheere-dheere badhta hai, isliye factor 1." },
          { k: "note", t: "<b>Correction to the v26 version of this chapter:</b> the earlier Samjho said the gradual case is also a 'special case' of the impact formula. It is not — setting h = 0 gives the sudden-load factor 2, and no value of h gives 1. Corrected above." },
          { k: "eg", title: "Worked example 8.5 — maximum stress from a falling weight", given: "A weight W = 1000 N falls freely through h = 10 mm onto a collar at the end of a vertical bar. Bar: length L = 2 m, cross-section A = 1000 mm², E = 200 GPa. Find the maximum instantaneous stress.", steps: [
            { t: "Static (gradual-load) extension", w: "δ_gradual = WL/AE = (1000 × 2)/(1×10⁻³ × 200×10⁹) = 2000/(2×10⁸) = 1×10⁻⁵ m = 0.01 mm" },
            { t: "Amplification factor", w: "1 + √(1 + 2h/δ_gradual) = 1 + √(1 + 2×0.01/0.00001) = 1 + √2001 ≈ 1 + 44.73 = 45.73" },
            { t: "Static stress, then scale up", w: "σ_gradual = W/A = 1000/(1×10⁻³) = 1×10⁶ Pa = 1 MPa" },
            { t: "Approximate check (h ≫ δ)", w: "√(2WhE/(AL)) = √(2 × 1000 × 10 × 200 000/(1000 × 2000)) = √2000 = 44.7 MPa ✔" },
          ], ans: "σ_impact ≈ 1 MPa × 45.73 ≈ 45.7 MPa — a 10 mm drop multiplies the stress 46 times. Interpretation: this is why pile-driving hammers, dropped loads on crane hooks and vehicle impact on bridge railings are checked dynamically, not with the static load." },
          { k: "note", t: "<b>Correction found during verification:</b> one Indian-college source (RCET notes) gave this formula with an extracted form that appeared to drop the cross-section area A from inside the square root — dimensionally inconsistent, almost certainly a transcription/OCR slip in that particular copy, not a real alternative formula. The version given above was re-derived here from first principles (the energy-balance steps shown) and separately confirmed against the dimensionless ratio form σ_impact/σ_gradual = 1 + √(1 + 2h/δ_gradual) published by <a href=\"https://www.engineersedge.com/material_science/impact_loading_approximate_formulas_15357.htm\" target=\"_blank\" rel=\"noopener\">Engineers Edge — Impact Loading Approximate Formulas</a>, which matches exactly once δ_gradual = WL/AE is substituted in. The sudden-load special case (factor of 2) is independently confirmed by the same Engineers Edge page and by the RCET notes." },
          { k: "trap", t: "Do not use the static formula σ = W/A for an impact or sudden load — both give a stress at least twice the static value, and a tall fall height h can make the impact stress many times larger still. Always check which of the three loading types a problem describes before picking a formula." },
        ],
      },
      {
        n: "8.6",
        title: "Quick revision — strain energy methods",
        hi: "त्वरित पुनरावृत्ति — स्ट्रेन एनर्जी विधियाँ",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Strain energy: axial P²L/2AE, torsion T²L/2GJ, bending U = ∫M²/2EI dx (8.1).",
            "Castigliano's theorem: δ = ∂U/∂P, θ = ∂U/∂M; for beams, δ = ∫(∂M/∂P)(M/EI)dx; dummy load set to zero at the end; 'first' vs 'second' naming differs between texts (8.2).",
            "Least work: ∂U/∂R = 0 for each redundant; propped cantilever R = 3wL/8 (8.3).",
            "Unit load method — truss: δ = Σ(nNL/AE); beam: δ = ∫(mM/EI)dx (8.4).",
            "Gradual load σ=W/A; sudden load σ=2W/A; impact load σ=(W/A)[1+√(1+2hAE/WL)] — sudden is impact's h=0 case; gradual is a separate case (8.5).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Castigliano's theorem and the unit load method are the same virtual-work idea in two forms — one differentiates the real-load moment, the other builds a separate unit-load diagram; both reproduce the standard deflection-table results from Chapter 5 exactly, which is why they're trustworthy cross-checks on each other.",
            "Least work turns the same idea into an equation for redundant reactions — no compatibility geometry needed.",
            "Sudden load = impact with h = 0 (factor 2). Under impact, a longer or larger bar is safer — the opposite of static intuition.",
            "Every formula in this chapter was checked against at least two independent published sources or derived here — see each section's source note, including the two corrections made.",
          ] },
          { k: "h", t: "🔗 Related in Civil Educator" },
          { k: "list", items: [
            "<a href=\"#/read/som/5\">Ch. 5 — Deflection table, superposition, propped cantilevers</a> (every result here is checked against it)",
            "<a href=\"#/read/som/6\">Ch. 6.4 — Resilience</a>",
            "<a href=\"#/read/som/1\">Ch. 1.6 — Toughness and resilience from the stress-strain curve</a>",
          ] },
        ],
      },
    ],
  });
})();
