/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   Chapter 3 — Bolted Connections
   Chapter 4 — Welded Connections

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "st"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "st-3",
      n: 3,
      title: "Bolted Connections",
      hi: "बोल्ट जोड़",
      blurb: "Five failure modes, two safety factors, and the reason connections are designed before members rather than after.",
      mins: 46,
      sections: [

        {
          n: "3.1",
          title: "Why connections come first",
          hi: "जोड़ पहले क्यों",
          blocks: [
            { k: "p", t: "A reinforced concrete frame is cast in one piece; its joints are a detailing problem. A steel structure is a kit of parts, and every force in it has to pass through a joint. That changes the order of the work." },
            { k: "list", items: [
              "The connection is very often what <strong>governs</strong>. A member chosen for its own strength will frequently be oversized for what its end connection can deliver.",
              "You cannot design a tension member without knowing its holes. Chapter 5's net-section calculation needs the bolt diameter and arrangement — so the connection has to be settled first, or at least assumed and then checked.",
              "Connections are where structures actually fail. A member is a single piece of mill-certified steel; a joint is holes, fit-up, tightening and workmanship.",
            ]},
            { k: "note", t: "Two families of fastener are in use. <strong>Bearing-type bolts</strong> allow the plates to slip until the hole bears on the shank, and then carry load in shear — simple and cheap. <strong>HSFG bolts</strong> are tensioned so hard that friction between the plates carries the load and no slip occurs at all. §3.7 covers the difference; most ordinary building work uses bearing-type." },
          ],
        },

        {
          n: "3.2",
          title: "The five failure modes",
          hi: "पाँच विफलता प्रकार",
          blocks: [
            { k: "p", t: "A bolted joint has five distinct ways of coming apart, and a design has to check all of them. Missing one is not conservative — the joint will simply fail in the mode that was not checked." },
            { k: "dia", id: "hb-st-boltmodes", cap: "Five modes: bolt shear, bearing, net-section rupture, block shear, and bolt tension." },
            { k: "list", items: [
              "<strong>Shear of the bolt</strong> — the shank shears across the plane between the plates. Brittle, γmb = 1.25.",
              "<strong>Bearing</strong> — the plate crushes in front of the bolt and the hole elongates. Ductile and visible; the joint distorts before it fails.",
              "<strong>Net-section rupture of the plate</strong> — the plate tears across the line of holes. Brittle, γm1 = 1.25. This belongs to the member, and Chapter 5 handles it.",
              "<strong>Block shear / shear-out</strong> — a block of plate tears out towards the edge, shearing along two lines and tearing across one. Brittle, and the reason minimum edge distances exist.",
              "<strong>Tension in the bolt</strong> — where the connection pulls the plates apart rather than sliding them, as in an end-plate connection or a bracket bolted to a column flange.",
            ]},
            { k: "p", t: "Modes 1 and 2 together give the <em>bolt value</em> — the capacity of one bolt, taken as the smaller of its shear capacity and its bearing capacity. That single number is what the rest of the joint design is built on." },
          ],
        },

        {
          n: "3.3",
          title: "Shear capacity of a bolt",
          hi: "बोल्ट की अपरूपण क्षमता",
          blocks: [
            { k: "p", t: "Cl. 10.3.3 gives the nominal shear capacity, and it is von Mises applied to a round bar: the shear strength of a material is its tensile strength divided by √3." },
            { k: "eq", expr: "Vdsb = (fub / √3)(nn Anb + ns Asb) / γmb", where: [
              ["fub", "ultimate tensile strength of the bolt, N/mm²"],
              ["nn", "number of shear planes passing through the THREADED portion"],
              ["ns", "number of shear planes passing through the plain SHANK"],
              ["Anb", "net tensile stress area of the bolt at the threads, mm²"],
              ["Asb", "gross area of the shank = (π/4)d², mm²"],
              ["γmb", "1.25 (Table 5)"],
            ]},
            { k: "dia", id: "hb-st-shearplanes", cap: "How many planes, and whether threads or shank cross them." },
            { k: "def", term: "Bolt grade", t: "Written as x.y — the first number gives fub = 100x N/mm², and the product of the two gives fyb = 10xy. So grade 4.6 has fub = 400 and fyb = 240; grade 8.8 has fub = 800 and fyb = 640. Grade 4.6 is the ordinary black bolt of everyday construction; 8.8 and above are high-strength." },
            { k: "trap", t: "Anb is about <strong>78% of Asb</strong> — the threads cut a real amount of metal away. A design that assumes the shank is in the shear plane, when the bolt is long enough that the threads run through it, overstates the joint by 22%. If the arrangement is not certain, assume threads in the shear plane; that is the conservative choice and it is what most offices do as standard." },
            { k: "note", t: "Two reductions apply to long or thick joints. Cl. 10.3.3.1: in a joint longer than 15d, the end bolts take more than their share, and the capacity is reduced by βlj = 1.075 − lj/(200d), not less than 0.75. Cl. 10.3.3.2: where the grip length exceeds 5d, the bolt bends as well as shears, and βlg = 8d/(3d + lg) applies." },
          ],
        },

        {
          n: "3.4",
          title: "Bearing capacity, and the kb factor",
          hi: "बेयरिंग क्षमता और kb",
          blocks: [
            { k: "p", t: "The other half of the bolt value is what the <em>plate</em> can take where the bolt presses against it. Cl. 10.3.4:" },
            { k: "eq", expr: "Vdpb = 2.5 kb d t fu / γmb", where: [
              ["d", "nominal diameter of the bolt, mm"],
              ["t", "thickness of the thinner plate, or the sum of the plates on the same side, mm"],
              ["fu", "ultimate tensile strength of the PLATE, not the bolt"],
            ]},
            { k: "eq", expr: "kb = least of  e/(3 d0),   p/(3 d0) − 0.25,   fub/fu,   1.0", where: [
              ["e", "end distance, measured along the direction of the load"],
              ["p", "pitch, the spacing of bolts along the direction of the load"],
              ["d0", "hole diameter — larger than d; Table 19 gives the clearances"],
            ]},
            { k: "p", t: "Each term in kb is guarding something specific, and reading them that way makes the formula memorable rather than arbitrary:" },
            { k: "list", items: [
              "<strong>e/(3d0)</strong> — a bolt near an edge will tear the plate out before it can crush it. This term throttles the capacity when the end distance is short, and it is very often the one that governs.",
              "<strong>p/(3d0) − 0.25</strong> — the same idea between two bolts: the plate between them has to survive.",
              "<strong>fub/fu</strong> — you cannot crush a plate with a bolt weaker than the plate. If the bolt goes first, this term stops the calculation pretending otherwise.",
              "<strong>1.0</strong> — an upper bound, because 2.5 fu is already a deliberately high bearing stress, justified only because the material is confined all round the hole.",
            ]},
            { k: "note", t: "Hole diameter d0 is the bolt diameter plus a clearance from Table 19: 1 mm for bolts up to 14 mm, 2 mm for 16 to 24 mm, and 3 mm for 24 mm and above. d0 appears in kb and in the net area of Chapter 5, so getting it wrong affects both the connection and the member." },
          ],
        },

        {
          n: "3.5",
          title: "Spacing, edge distance and the rules behind them",
          hi: "दूरी के नियम",
          blocks: [
            { k: "dia", id: "hb-st-boltspacing", cap: "Pitch along the force, gauge across it, end and edge distances to the free edges." },
            { k: "list", items: [
              "<strong>Minimum pitch = 2.5 d</strong> (Cl. 10.2.2). Closer than that, the plate between two holes cannot develop its own strength, and the bolts cannot be tightened without fouling each other.",
              "<strong>Maximum pitch</strong> (Cl. 10.2.3.1) — 32 t or 300 mm, whichever is less, in general; tighter in tension members (16 t or 200 mm) and tighter still in compression members (12 t or 200 mm), because a compression plate can buckle between its fasteners.",
              "<strong>Minimum edge and end distance</strong> (Cl. 10.2.4.2) — 1.7 d0 for a sheared or hand-flame-cut edge, and 1.5 d0 for a rolled, machine-flame-cut, sawn or planed edge. A rough edge already has micro-cracks, so it needs more.",
              "<strong>Maximum edge distance</strong> — 12 t ε, and for exposed work not more than 40 mm + 4 t, so the plates stay clamped together at their edges and water cannot get between them.",
            ]},
            { k: "trap", t: "The maximum limits look like housekeeping and are not. A plate edge further than 12 t ε from its nearest bolt is unrestrained and will buckle away under compression, and a gap at the edge of an exposed joint is where corrosion starts and then jacks the plates apart. Both limits are structural." },
          ],
        },

        {
          n: "3.6",
          title: "Designing a simple bolted joint",
          hi: "सरल बोल्ट जोड़ का डिज़ाइन",
          blocks: [
            { k: "steps", items: [
              "Choose a bolt diameter and grade — M16 or M20 grade 4.6 covers most ordinary work.",
              "Compute the shear capacity Vdsb, assuming threads in the shear plane unless you know otherwise.",
              "Choose trial spacings, compute kb, and get the bearing capacity Vdpb.",
              "Bolt value = the smaller of the two.",
              "Number of bolts = factored load ÷ bolt value, rounded up.",
              "Lay them out, and check every spacing limit against the values actually used.",
              "Check the plate itself: gross yield, net rupture, and block shear (Chapter 5).",
            ]},
            { k: "eg",
              title: "Example 3.1 — Lap joint in tension",
              given: "Two plates 150 mm wide × 12 mm thick, E250 steel (fy = 250, fu = 410 N/mm²), lapped and bolted, carrying a factored tension of 150 kN. Use M20 grade 4.6 bolts (fub = 400 N/mm², Asb = 314 mm², Anb = 245 mm²), threads in the shear plane. Sheared edges.",
              steps: [
                { t: "Shear capacity of one bolt (Cl. 10.3.3)", w: "Lap joint → single shear, threads in the plane: nn = 1, ns = 0\nVdsb = (400/√3)(1 × 245)/1.25\n     = 230.94 × 245/1.25 = 56,580/1.25\n     = 45,264 N = 45.3 kN" },
                { t: "Trial spacings, and the hole diameter", w: "d0 = 20 + 2 = 22 mm (Table 19)\nTry end distance e = 40 mm and pitch p = 60 mm\nCheck minimums: e ≥ 1.7 × 22 = 37.4 mm ✓   p ≥ 2.5 × 20 = 50 mm ✓" },
                { t: "kb (Cl. 10.3.4)", w: "e/(3d0)        = 40/66      = 0.606   ← least\np/(3d0) − 0.25 = 60/66 − 0.25 = 0.659\nfub/fu         = 400/410    = 0.976\nand            = 1.000\nkb = 0.606" },
                { t: "Bearing capacity", w: "Vdpb = 2.5 × 0.606 × 20 × 12 × 410/1.25\n     = 149,076/1.25 = 119,261 N = 119.3 kN" },
                { t: "Bolt value", w: "least of 45.3 (shear) and 119.3 (bearing) = 45.3 kN\n→ SHEAR governs, which is normal for a single-shear joint in thick plate." },
                { t: "Number of bolts", w: "n = 150/45.3 = 3.31  →  provide 4 bolts" },
                { t: "Check the plate (Chapter 5 methods)", w: "Gross yield:  Tdg = Ag fy/γm0 = (150 × 12) × 250/1.10 = 409 kN  ✓\nNet rupture (bolts in a single line, one hole per section):\nAn = (150 − 22) × 12 = 1536 mm²\nTdn = 0.9 An fu/γm1 = 0.9 × 1536 × 410/1.25 = 453 kN  ✓" },
              ],
              ans: "4 no. M20 grade 4.6 bolts in a single line at 60 mm pitch, with 40 mm end distance. Bolt value 45.3 kN, capacity 181 kN against 150 kN applied.",
            },
            { k: "trap", t: "Bearing came out at 2.6 times the shear capacity, so it was never going to govern here — but notice how it got there: kb was throttled to 0.606 by the <em>end distance</em>. Increase e to 55 mm and the end-distance term rises to 0.833 — but kb is the least of the four terms, so the pitch term (0.659) now governs and bearing rises only to 129.7 kN; to go further the pitch must grow too. In a double-shear joint, where the shear capacity doubles to 90.5 kN, that end distance becomes the thing that decides the joint." },
          ],
        },

        {
          n: "3.7",
          title: "Bolts in tension, and combined shear and tension",
          hi: "तनाव में बोल्ट",
          blocks: [
            { k: "p", t: "Not every connection slides. A beam end plate bolted to a column flange, or a bracket hung off a column, pulls its bolts rather than shearing them. Cl. 10.3.5:" },
            { k: "eq", expr: "Tdb = 0.90 fub An / γmb,   but not more than fyb Asb (γmb/γm0)", where: [
              ["An", "net tensile stress area at the threads, mm²"],
            ]},
            { k: "p", t: "The second limit is there so that a high-strength bolt is not designed to a stress that would have yielded it long before. The factor 0.90 accounts for the stress concentration at the thread root, which is where a tensioned bolt always fails." },
            { k: "p", t: "Where both act at once, Cl. 10.3.6 gives a circular interaction:" },
            { k: "eq", expr: "(V / Vdsb)²  +  (T / Tdb)²  ≤  1.0", where: [] },
            { k: "note", t: "In an end-plate connection there is a further effect the formula does not carry: <strong>prying</strong>. As the plate bends away from the column, it levers on its own edge and increases the bolt tension above the applied value — by 20 to 40% for a flexible plate. Cl. 10.4.7 covers the additional force Q, and the usual practical answer is a thicker end plate rather than a bigger bolt." },
          ],
        },

        {
          n: "3.8",
          title: "Bolt groups in eccentric shear",
          hi: "विकेन्द्रित अपरूपण में बोल्ट समूह",
          blocks: [
            { k: "p", t: "A bracket bolted to a column carries its load some distance out from the bolt group. Move the load to the centroid of the group and you must add a moment; the group then carries a direct force plus a torsional moment, and every bolt takes a different share." },
            { k: "eq", expr: "F1 = P / n        F2 = P e r / Σr²", where: [
              ["F1", "direct force, the same on every bolt, acting in the direction of P"],
              ["F2", "force from the moment, perpendicular to the radius r, largest on the farthest bolt"],
              ["r", "distance of the bolt from the centroid of the group"],
              ["Σr²", "sum of r² over all the bolts — the group's polar second moment, per unit area"],
            ]},
            { k: "p", t: "The two are added as <strong>vectors</strong> on the critical bolt, which is the one where they point most nearly the same way — usually the farthest bolt on the side towards which the moment pushes. Resolving F2 into components and adding them to F1 is easier and safer than working with the angle between them." },
            { k: "eg",
              title: "Example 3.2 — Bracket with six bolts",
              given: "A bracket is bolted to a column flange with 6 bolts in two vertical lines: gauge 100 mm (so x = ±50 mm), pitch 80 mm (so y = +80, 0, −80). A factored vertical load of 100 kN acts 200 mm from the centroid of the group. M20 grade 4.6 bolts in single shear (Vdsb = 45.3 kN from Example 3.1).",
              steps: [
                { t: "Direct force per bolt", w: "F1 = P/n = 100/6 = 16.67 kN, vertical, on every bolt" },
                { t: "Σr² for the group", w: "All six bolts have x = ±50: 6 × 50² = 15,000\nFour bolts have y = ±80:    4 × 80² = 25,600\nΣr² = 15,000 + 25,600 = 40,600 mm²" },
                { t: "Moment", w: "T = P e = 100 × 200 = 20,000 kN·mm" },
                { t: "Components of F2 on a corner bolt (x = 50, y = 80)", w: "horizontal: F2x = T y/Σr² = 20,000 × 80/40,600 = 39.41 kN\nvertical:   F2y = T x/Σr² = 20,000 × 50/40,600 = 24.63 kN" },
                { t: "Resultant on the critical bolt", w: "vertical   = F1 + F2y = 16.67 + 24.63 = 41.30 kN\nhorizontal = F2x              = 39.41 kN\nR = √(41.30² + 39.41²) = √3258.9 = 57.1 kN" },
                { t: "Compare with the bolt value", w: "R = 57.1 kN  >  Vdsb = 45.3 kN   ✗ M20 in single shear FAILS" },
                { t: "Options", w: "M24 grade 4.6 (Anb = 353 mm²): Vdsb = (400/√3) × 353/1.25 = 65.2 kN  >  57.1  ✓\nor put the bolts in double shear: 2 × 45.3 = 90.5 kN  ✓\nor spread the group taller, which raises Σr² and lowers F2." },
              ],
              ans: "Six M20 bolts are not enough — use M24 grade 4.6, or arrange the connection so the bolts are in double shear.",
            },
            { k: "trap", t: "The direct force was 16.7 kN and the resultant was 57.1 kN. The eccentricity more than tripled the demand on the worst bolt. Sizing a bracket's bolts on P/n alone is not a small error — it is the whole design." },
            { k: "note", t: "Notice the third option in the last step. Making the group <em>taller</em> raises Σr² and reduces F2 for the same moment, and it costs nothing. Spreading a bolt group is almost always cheaper than upgrading its bolts." },
          ],
        },

        {
          n: "3.9",
          title: "HSFG bolts",
          hi: "HSFG बोल्ट",
          blocks: [
            { k: "dia", id: "hb-st-hsfg", cap: "A bearing bolt lets the plates slip and then shears; an HSFG bolt clamps them so they never slip." },
            { k: "p", t: "A high-strength friction-grip bolt is tightened to a specified pre-tension — its proof load — so that the plates are clamped hard enough for friction to carry the load. The shank never sees it. Cl. 10.4.3:" },
            { k: "eq", expr: "Vdsf = μf ne Kh Fo / γmf", where: [
              ["μf", "slip factor of the faying surfaces (Table 20) — 0.5 for clean as-rolled steel, less for painted or galvanised"],
              ["ne", "number of effective interfaces offering frictional resistance"],
              ["Kh", "1.0 for standard clearance holes, reduced for oversize and slotted holes"],
              ["Fo", "minimum bolt pre-tension (proof load), taken as 0.7 fub Anb (Cl. 10.4.5)"],
              ["γmf", "1.10 if slip resistance is required at service load, 1.25 if at ultimate load"],
            ]},
            { k: "p", t: "The γmf of 1.10 or 1.25 is a design decision, not a lookup. Ask what slip would actually mean: in a bracing member where a few millimetres of movement is harmless, design against slip at ultimate load (1.25). In a crane gantry, a bridge, or anything carrying reversing or fatigue load, slip at working load is not acceptable at all, so design against it at service load (1.10)." },
            { k: "trap", t: "The slip factor is a property of the <strong>surface</strong>, and paint destroys it. A connection designed for μf = 0.5 and then painted over the faying surfaces can drop to 0.1 and slip immediately. HSFG faying surfaces must be masked before painting — this is a drawing note and a site instruction, and forgetting it has caused real failures." },
            { k: "note", t: "An HSFG bolt is also checked for bearing, because once slip has occurred — which it may, beyond ultimate load — the connection becomes a bearing joint. The clamping is the design mechanism; bearing is the backstop." },
          ],
        },

        {
          n: "3.10",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Bolt value = the smaller of shear (Cl. 10.3.3) and bearing (Cl. 10.3.4).",
              "Vdsb = (fub/√3)(nn Anb + ns Asb)/1.25 — count the planes, and check whether threads or shank crosses each.",
              "Vdpb = 2.5 kb d t fu/1.25, with kb usually throttled by the end distance.",
              "Anb ≈ 0.78 Asb. Assume threads in the plane unless certain.",
              "Minimum pitch 2.5d; minimum edge 1.7d0 sheared or 1.5d0 machined; maximum pitch 32t or 300 mm.",
              "Bolts in tension: Tdb = 0.9 fub An/1.25, with a cap; combined action is a circular interaction.",
              "Eccentric groups: direct force plus F2 = Per/Σr², added as vectors.",
              "HSFG carries load by friction, and is specified where slip itself must be prevented.",
            ]},
            { k: "p", t: "Chapter 4 does the same job for the other way of joining steel — where instead of putting a hole through the member and hoping the remaining metal is enough, the pieces are melted into one." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "st-4",
      n: 4,
      title: "Welded Connections",
      hi: "वेल्डेड जोड़",
      blurb: "The throat, not the leg; why a butt weld needs no calculation and a fillet weld always does.",
      mins: 38,
      sections: [

        {
          n: "4.1",
          title: "Two kinds of weld",
          hi: "दो तरह की वेल्ड",
          blocks: [
            { k: "p", t: "Welding fuses the parts into continuous metal, so there are no holes, no loss of net area, and no slip. It is also permanent, harder to inspect, and only as good as the welder — which is why the code trusts a shop weld more than a site weld." },
            { k: "dia", id: "hb-st-weldtypes", cap: "A butt weld fills a prepared groove; a fillet weld sits in the corner." },
            { k: "def", term: "Butt (groove) weld", t: "The edges are prepared — a V, a U, a bevel — and the groove is filled. With <strong>full penetration</strong>, the joint is as strong as the parent plate, so Cl. 10.5.7.1.1 gives its design strength as that of the parent metal and no separate calculation is needed. Where penetration is partial, only the penetrated depth counts as the throat." },
            { k: "def", term: "Fillet weld", t: "Laid in the corner between two surfaces meeting at an angle, with no edge preparation. Cheaper, faster, and by far the most common weld on a steel job — and unlike a butt weld it always needs a strength calculation, because its throat is much smaller than the plates it joins." },
            { k: "note", t: "A third kind, the plug or slot weld, fills a hole or slot in one plate to join it to the one beneath. Cl. 10.6 covers it. It is used where there is no edge to weld along, and its capacity is modest — normally a supplement, not a main connection." },
          ],
        },

        {
          n: "4.2",
          title: "Size, throat and effective length",
          hi: "आकार, थ्रोट और प्रभावी लंबाई",
          blocks: [
            { k: "p", t: "Everything about a fillet weld turns on the distinction between what is drawn and what carries load." },
            { k: "def", term: "Size s", t: "The leg length — the dimension along the plate face. This is what the drawing specifies and what the welder works to." },
            { k: "def", term: "Throat t", t: "The shortest distance from the root to the face of the weld. For the usual 90° joint, t = 0.7 s (Table 22 gives K = 0.7 for angles between 60° and 90°). <strong>All strength is calculated on the throat</strong>, because that is the plane on which the weld would shear." },
            { k: "eq", expr: "Design strength per unit length = t × fu / (√3 γmw)", where: [
              ["fu", "ultimate strength of the weaker of the parent metal and the weld metal"],
              ["γmw", "1.25 for a shop weld, 1.50 for a site weld (Table 5)"],
            ]},
            { k: "p", t: "The √3 is there because Cl. 10.5.7.1.1 treats the throat as being in shear whatever direction the load came from — a deliberate simplification that is safe and keeps the whole of fillet weld design to a single formula." },
            { k: "h", t: "Limits on size" },
            { k: "list", items: [
              "<strong>Minimum size</strong> (Table 21), set by the thickness of the <em>thicker</em> part being joined: 3 mm up to 10 mm thick, 5 mm for 10–20, 6 mm for 20–32, 8 mm for 32–50. A small weld against a thick plate cools too fast, and cracks.",
              "<strong>Maximum size along the edge of a plate</strong> (Cl. 10.5.8.1): t − 1.5 mm for plate 6 mm or thicker, so the plate's arris is not melted away and the weld's true size can still be seen and measured.",
              "<strong>Effective length</strong> (Cl. 10.5.4.1): the actual length less twice the weld size, to discount the unfilled craters at each end — unless the weld is returned round the corner. Minimum effective length is 4 s.",
            ]},
            { k: "trap", t: "Designing on the leg size instead of the throat overstates every fillet weld by 1/0.7 = 43%. It is the single commonest error in steel connection design, and because a weld is buried behind a fillet nobody sees it until something moves." },
          ],
        },

        {
          n: "4.3",
          title: "A weld carrying direct tension",
          hi: "सीधे तनाव में वेल्ड",
          blocks: [
            { k: "p", t: "The most common welded connection in a truss or bracing system is an angle welded to a gusset by fillet welds along its two edges. There is a subtlety: the angle's force acts through its own centroid, which is not midway between the two welds, so equal welds would apply an unbalanced moment to the joint." },
            { k: "p", t: "The welds are therefore <strong>balanced about the centroid</strong> — more weld on the side nearer the centroid, less on the side further from it — so that their resultant passes through the member's line of action." },
            { k: "eq", expr: "P1 × L = P × (L − cy)        P2 = P − P1", where: [
              ["L", "the leg length of the angle (the distance between the two weld lines)"],
              ["cy", "distance of the angle's centroid from the back of the connected leg"],
              ["P1, P2", "force carried by the weld nearer and further from the centroid"],
            ]},
            { k: "eg",
              title: "Example 4.1 — Balanced fillet welds for an angle in tension",
              given: "ISA 75 × 75 × 8 carrying a factored tension of 150 kN, welded to a gusset plate with side fillets. From the section tables, the centroid is 21.6 mm from the back of the angle. E250 steel (fu = 410 N/mm²), shop weld.",
              steps: [
                { t: "Weld size", w: "Maximum along the edge of the 8 mm leg: 8 − 1.5 = 6.5 mm\nMinimum for an 8 mm thick part (Table 21): 3 mm\nUse s = 6 mm  →  throat t = 0.7 × 6 = 4.2 mm" },
                { t: "Strength per mm of weld", w: "= t fu/(√3 γmw) = 4.2 × 410/(1.732 × 1.25)\n= 4.2 × 189.4 = 795.4 N/mm = 0.795 kN/mm" },
                { t: "Total length required", w: "L total = 150/0.795 = 188.6 mm" },
                { t: "Balance the welds about the centroid", w: "P1 (weld away from the back) = 150 × (75 − 21.6)/75 = 150 × 0.712 = 106.8 kN\nP2 (weld at the back)        = 150 − 106.8 = 43.2 kN" },
                { t: "Lengths", w: "L1 = 106.8/0.795 = 134.3 mm\nL2 =  43.2/0.795 =  54.3 mm" },
                { t: "Add for end craters (Cl. 10.5.4.1)", w: "Add 2s = 12 mm to each unless the weld is returned round the end:\nL1 = 146.3 → provide 150 mm\nL2 =  66.3 → provide  70 mm\nBoth exceed the minimum effective length of 4s = 24 mm  ✓" },
              ],
              ans: "6 mm fillet welds, 150 mm long on the far side and 70 mm on the back of the angle — unequal on purpose, so their resultant passes through the angle's centroid.",
            },
            { k: "note", t: "If the two welds are made equal instead, the joint carries an out-of-balance moment of P × (L/2 − cy). For this angle that is 150 × (37.5 − 21.6) = 2.4 kNm applied to a gusset that was never designed for it. Many practical connections accept this by adding an end weld across the toe of the angle, which balances the group without the awkward unequal lengths." },
          ],
        },

        {
          n: "4.4",
          title: "Weld groups in eccentric load",
          hi: "विकेन्द्रित भार में वेल्ड समूह",
          blocks: [
            { k: "p", t: "A weld group is handled exactly like a bolt group, with one change: instead of discrete bolts at discrete radii, the weld is a continuous line, so its properties are computed as areas and section moduli of the throat." },
            { k: "dia", id: "hb-st-weldecc", cap: "Direct shear is uniform over the weld; the moment varies linearly; the two combine at the worst point." },
            { k: "eq", expr: "q1 = V / A,        q2 = M / Z,        q = √(q1² + q2²)  ≤  fu/(√3 γmw)", where: [
              ["A", "total throat area of the weld group, mm²"],
              ["Z", "section modulus of the throat area about the axis of bending, mm³"],
            ]},
            { k: "p", t: "Where the moment acts <em>in the plane</em> of the weld group — a bracket plate welded flat onto a column flange — the moment is torsional and Z is replaced by the polar quantity Ip/r, exactly as Σr² was used for bolts. Where the moment acts <em>out of plane</em> — a bracket standing off the column — it is ordinary bending and Z is the ordinary section modulus." },
            { k: "eg",
              title: "Example 4.2 — Bracket welded to a column",
              given: "A bracket plate is welded to a column flange by two vertical fillet welds, each 250 mm long, one down each side of the plate. A factored vertical load of 60 kN acts 150 mm out from the weld line. Weld size 6 mm, shop weld, E250 (fu = 410 N/mm²).",
              steps: [
                { t: "Throat and total area", w: "t = 0.7 × 6 = 4.2 mm\nA = 2 × 250 × 4.2 = 2100 mm²" },
                { t: "Direct shear stress", w: "q1 = V/A = 60,000/2100 = 28.57 N/mm²" },
                { t: "Section modulus of the weld group", w: "Two vertical lines, bending about the horizontal centroidal axis:\nZ = 2 × t L²/6 = 2 × 4.2 × 250²/6 = 87,500 mm³" },
                { t: "Bending stress", w: "M = 60 × 150 = 9000 kN·mm = 9 × 10⁶ N·mm\nq2 = M/Z = 9 × 10⁶/87,500 = 102.86 N/mm²" },
                { t: "Resultant at the critical point (top of the weld)", w: "q = √(28.57² + 102.86²) = √(816 + 10,580) = √11,396 = 106.8 N/mm²" },
                { t: "IS 800 combination (Cl. 10.5.10.1.1)", w: "fe = √(fa² + 3q²) = √(102.86² + 3 × 28.57²) = √(10,580 + 2,449) = 114.1 N/mm²" },
                { t: "Permissible", w: "fu/(√3 γmw) = 410/(1.732 × 1.25) = 189.4 N/mm²\n114.1  <  189.4  ✓ safe" },
              ],
              ans: "Two 6 mm fillet welds 250 mm long are adequate — the code's equivalent stress is 114.1 N/mm² (the simple vector resultant 106.8) against a permitted 189.4.",
            },
            { k: "trap", t: "Bending contributed 103 of the 107 N/mm². Because Z goes as L², shortening the welds from 250 mm to 200 mm raises q2 from 103 to 161 and the equivalent stress √(fa² + 3q²) to 172 — still safe, but the margin is nearly gone. <strong>Weld length, not weld size, is the powerful variable</strong> in an eccentric group: doubling the size doubles the capacity, doubling the length quadruples it." },
          ],
        },

        {
          n: "4.5",
          title: "What welding does to the steel",
          hi: "वेल्डिंग का इस्पात पर असर",
          blocks: [
            { k: "p", t: "A weld is a small casting made against a large heat sink, and three consequences follow that no formula in this chapter contains." },
            { k: "list", items: [
              "<strong>Residual stresses.</strong> The weld metal is molten and then contracts as it cools, but it is restrained by the cold plate around it. The result is tension near the weld at close to yield, balanced by compression elsewhere — which is exactly why welded sections have tighter classification limits and a worse buckling curve than rolled ones.",
              "<strong>Distortion.</strong> The same contraction pulls the plates. A long fillet down one side of a plate will bow it, which is why welding sequences are specified and why symmetrical welds are made in balanced pairs.",
              "<strong>The heat-affected zone.</strong> The parent metal beside the weld is not melted but is heated and re-cooled, changing its grain structure. If it cools too fast — thick plate, cold weather, a small weld — it hardens and becomes brittle. That is the reason for minimum weld sizes, for preheating thick material, and for specifying a steel quality with adequate notch toughness.",
            ]},
            { k: "p", t: "Inspection follows from all of this. Visual inspection catches profile and undercut; dye penetrant catches surface cracks; ultrasonic and radiographic testing find internal defects in butt welds. IS 822 covers inspection practice, and the level of testing is a specification decision that should follow the consequence of a failure — a full-penetration butt weld in a tension member deserves far more than a fillet on a bracing cleat." },
            { k: "note", t: "Fatigue, in a welded structure, is almost entirely a question of weld detail rather than weld strength. Chapter 12 returns to this: the same stress range gives wildly different lives depending on the geometry at the weld toe, and IS 800 Section 13 classifies details accordingly." },
          ],
        },

        {
          n: "4.6",
          title: "Choosing between bolts and welds",
          hi: "बोल्ट या वेल्ड",
          blocks: [
            { k: "list", items: [
              "<strong>Shop welded, site bolted</strong> is the standard answer in Indian practice, and it is usually the right one. Welding in a shop is controlled, positioned and inspected; bolting on site is fast, needs no power supply or skilled welder at height, and is checkable by eye.",
              "<strong>Welds</strong> suit connections needing full continuity — moment connections, plate girder webs to flanges, built-up sections — and lose nothing to holes.",
              "<strong>Bolts</strong> suit site connections, anything that may be dismantled, and situations where inspection matters more than efficiency.",
              "<strong>HSFG</strong> where slip cannot be tolerated; <strong>full-penetration butt welds</strong> where the joint must simply be as strong as the member.",
            ]},
            { k: "p", t: "One practical rule is worth stating: do not design a joint that has to be welded overhead on site if any alternative exists. γmw rises from 1.25 to 1.50 for a site weld, and that factor is the code's opinion of the arrangement — it is telling you something about quality, not merely charging you for it." },
          ],
        },

        {
          n: "4.7",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Full-penetration butt weld = parent metal strength; no separate calculation.",
              "Fillet weld: throat t = 0.7 s, and all strength is on the throat.",
              "Strength per mm = t fu/(√3 γmw), with γmw 1.25 shop and 1.50 site.",
              "Effective length = actual − 2s unless returned; minimum 4s.",
              "Minimum size from Table 21 by the thicker part; maximum along an edge = t − 1.5 mm.",
              "Balance side fillets about the angle's centroid, or add an end weld.",
              "Eccentric groups: q1 = V/A, q2 = M/Z, combined as vectors. Length is the powerful variable.",
              "Welding leaves residual stress, distortion and a heat-affected zone — which is why welded sections classify and buckle worse than rolled ones.",
            ]},
            { k: "p", t: "With the joints understood, Chapter 5 returns to the members — starting with the simplest of them, the tension member, where the holes just drilled for Chapter 3's bolts turn out to decide the whole design." },
          ],
        },
      ],
    }

  );
})();
