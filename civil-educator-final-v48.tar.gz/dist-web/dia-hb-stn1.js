/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL STRUCTURES · COMPLETE NOTES
   Redrawn from the figures in the three sets of class notes.
   Uses the shared .dia classes so both themes work.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

(function () {
  const mk = (id) => `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
  </defs>`;
  const arr = (id, x1, y1, x2, y2, cls) => `<line class="${cls || "s"}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-end="url(#${id}-${cls === "hi" ? "m" : "a"})"/>`;
  const box = (x, y, w, h, lines, cls) => `<rect class="${cls || "conc"}" x="${x}" y="${y}" width="${w}" height="${h}" rx="7"/>` +
    lines.map((t, i) => `<text x="${x + w / 2}" y="${y + h / 2 + (i - (lines.length - 1) / 2) * 16 + 4}" text-anchor="middle"${i > 0 ? ' class="lb"' : ""}>${t}</text>`).join("");

  Object.assign(DB.diagrams, {

    /* ------------------------------------------------ 1.2 stress–strain */
    "hb-stn-ss": {
      label: "Stress–strain diagram of mild steel",
      svg: `<svg viewBox="0 0 680 300" role="img" aria-label="Stress strain curve of mild steel: linear O to A, proportional limit A, non-linear A to B, elastic limit B, upper yield C prime, lower yield C at 250 newton per square millimetre, yield plateau C to D, strain hardening D to E, necking E to F, fracture at F.">
        ${mk("ss")}
        <line class="s" x1="70" y1="250" x2="640" y2="250"/><line class="s" x1="70" y1="250" x2="70" y2="30"/>
        <text class="lb" x="640" y="248" text-anchor="end">Strain →</text>
        <text class="lb" x="60" y="40" text-anchor="end">Stress</text>
        <path class="hi" d="M70 250 L150 120"/>
        <path class="hi" d="M150 120 Q168 96 182 92 L196 80 L200 104 L300 104"/>
        <path class="hi" d="M300 104 Q400 40 490 52 Q540 60 585 132"/>
        <line class="gl" x1="70" y1="104" x2="300" y2="104"/>
        <text class="em" x="66" y="100" text-anchor="end">250 = f_y</text>
        ${[["A", 150, 120], ["B", 182, 92], ["C′", 196, 76], ["C", 202, 112], ["D", 300, 112], ["E", 492, 44], ["F", 585, 140]].map(([t, x, y]) =>
          `<circle class="hif" cx="${x}" cy="${y === 112 ? 104 : y === 140 ? 132 : y === 76 ? 80 : y}" r="3"/><text class="em" x="${x + 6}" y="${y}">${t}</text>`).join("")}
        <text class="lb" x="110" y="196">OA linear</text>
        <text class="lb" x="214" y="132">CD yield plateau</text>
        <text class="lb" x="330" y="76">DE strain hardening</text>
        <text class="lb" x="520" y="104">EF necking</text>
        <text class="lb" x="150" y="270">ε</text><text class="lb" x="250" y="270">10–15 ε</text><text class="lb" x="470" y="270">150–200 ε (≈ 0.25)</text>
      </svg>`,
    },

    /* ------------------------------------------------ 3.1 elastic→plastic */
    "hb-stn-plastic": {
      label: "Elastic to fully plastic stress block",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Four stress blocks across the depth of a section: fully elastic triangles below yield, extreme fibre at yield, part plastic with an elastic core, and fully plastic with two rectangular blocks at yield about the equal area axis giving C and T with lever arm.">
        ${mk("pl")}
        ${[["f < f_y", "elastic"], ["f_y", "first yield"], ["f_y", "part plastic"], ["f_y", "fully plastic"]].map(([lab, cap], i) => {
          const x = 30 + i * 165, y = 40, h = 120, w = 90;
          let block = "";
          if (i === 0) block = `<path class="soft-b" d="M${x} ${y} L${x + 48} ${y + h / 2} L${x} ${y + h / 2} Z"/><path class="softa" d="M${x} ${y + h} L${x + 48} ${y + h / 2} L${x} ${y + h / 2} Z"/>`;
          if (i === 1) block = `<path class="soft-b" d="M${x} ${y} L${x + w} ${y + h / 2} L${x} ${y + h / 2} Z"/><path class="softa" d="M${x} ${y + h} L${x + w} ${y + h / 2} L${x} ${y + h / 2} Z"/>`;
          if (i === 2) block = `<path class="soft-b" d="M${x} ${y} L${x + w} ${y} L${x + w} ${y + 30} L${x} ${y + h / 2} Z"/><path class="softa" d="M${x} ${y + h} L${x + w} ${y + h} L${x + w} ${y + h - 30} L${x} ${y + h / 2} Z"/>`;
          if (i === 3) block = `<rect class="soft-b" x="${x}" y="${y}" width="${w}" height="${h / 2}"/><rect class="softa" x="${x}" y="${y + h / 2}" width="${w}" height="${h / 2}"/>`;
          return `${block}<line class="s" x1="${x}" y1="${y}" x2="${x}" y2="${y + h}"/>
            <line class="dash" x1="${x - 14}" y1="${y + h / 2}" x2="${x + w + 14}" y2="${y + h / 2}"/>
            <text class="em" x="${x + w / 2}" y="${y - 10}" text-anchor="middle">${lab}</text>
            <text class="lb" x="${x + w / 2}" y="${y + h + 22}" text-anchor="middle">${cap}</text>`;
        }).join("")}
        ${arr("pl", 620, 70, 560, 70, "hi")}${arr("pl", 560, 130, 620, 130, "hi")}
        <text class="em" x="628" y="74">C</text><text class="em" x="628" y="134">T</text>
        <text class="lb" x="596" y="208" text-anchor="middle">equal area axis</text>
        <text class="lb" x="30" y="234">M_p = f_y · Z_p ,  Z_p = (A/2)(ȳ₁ + ȳ₂)   ·   shape factor S = Z_p/Z_e</text>
      </svg>`,
    },

    /* ------------------------------------------------ 4.1 moment–rotation */
    "hb-stn-mr": {
      label: "Moment–rotation behaviour of connections",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="Moment rotation graph with four curves from the origin: ideally rigid almost vertical, rigid, semi rigid, and flexible nearly horizontal.">
        <line class="s" x1="70" y1="220" x2="520" y2="220"/><line class="s" x1="70" y1="220" x2="70" y2="30"/>
        <text class="lb" x="520" y="242" text-anchor="end">Rotation →</text>
        <text class="lb" x="60" y="40" text-anchor="end">Moment</text>
        <path class="hi" d="M70 220 L96 40"/>
        <path class="ac" d="M70 220 Q150 66 250 56"/>
        <path class="s" d="M70 220 Q170 150 300 132"/>
        <path class="thin" d="M70 220 Q200 200 380 196"/>
        <text class="em" x="104" y="44">Ideally rigid</text>
        <text class="ea" x="258" y="58">Rigid</text>
        <text x="308" y="136">Semi-rigid</text>
        <text class="lb" x="388" y="200">Flexible</text>
        <text class="lb" x="540" y="70">Flexible → shear</text>
        <text class="lb" x="540" y="90">Semi-rigid → partial</text>
        <text class="lb" x="540" y="110">Rigid → full moment</text>
      </svg>`,
    },

    /* ------------------------------------------------ 4.2 bolt terminology */
    "hb-stn-bolt": {
      label: "Pitch, gauge, end and edge distance",
      svg: `<svg viewBox="0 0 680 280" role="img" aria-label="Plan of a bolted lap plate with three rows and four columns of bolt holes, showing pitch measured parallel to the force, gauge measured perpendicular to it, end distance from the plate end and edge distance from the plate edge.">
        ${mk("bt")}
        <rect class="conc" x="120" y="60" width="420" height="160"/>
        ${[0, 1, 2].map((r) => [0, 1, 2, 3].map((c) =>
          `<circle class="soft-b" cx="${190 + c * 90}" cy="${100 + r * 40}" r="9"/><circle class="thin" cx="${190 + c * 90}" cy="${100 + r * 40}" r="9" style="fill:none"/>`).join("")).join("")}
        ${arr("bt", 120, 42, 190, 42)}${arr("bt", 190, 42, 120, 42)}
        <text class="em" x="155" y="34" text-anchor="middle">end</text>
        ${arr("bt", 190, 42, 280, 42)}${arr("bt", 280, 42, 190, 42)}
        <text class="em" x="235" y="34" text-anchor="middle">pitch p</text>
        ${arr("bt", 570, 100, 570, 140)}${arr("bt", 570, 140, 570, 100)}
        <text class="em" x="578" y="124">gauge g</text>
        <line class="gl" x1="460" y1="100" x2="570" y2="100"/><line class="gl" x1="460" y1="140" x2="570" y2="140"/>
        ${arr("bt", 96, 60, 96, 100)}${arr("bt", 96, 100, 96, 60)}
        <text class="em" x="88" y="84" text-anchor="end">edge</text>
        <line class="gl" x1="96" y1="100" x2="190" y2="100"/>
        ${arr("bt", 60, 140, 116, 140, "hi")}${arr("bt", 544, 140, 600, 140, "hi")}
        <text class="em" x="46" y="144" text-anchor="end">P</text><text class="em" x="608" y="144">P</text>
        <text class="lb" x="120" y="250">p ≮ 2.5d · p ≯ 16t or 200 mm (tension), 12t or 200 mm (compression)</text>
        <text class="lb" x="120" y="268">end / edge ≮ 1.5d₀ (machine cut), 1.7d₀ (hand flame cut) · ≯ 12tε</text>
      </svg>`,
    },

    /* ------------------------------------------------ 5.2 fillet weld */
    "hb-stn-fillet": {
      label: "Fillet weld geometry",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="A vertical plate standing on a horizontal plate with a fillet weld in the corner, showing the two legs S1 and S2, the root at the corner, the toes at the weld edges and the throat measured perpendicular from the root to the line joining the toes.">
        ${mk("fw")}
        <rect class="conc" x="40" y="190" width="300" height="40"/>
        <rect class="conc" x="150" y="40" width="40" height="150"/>
        <path class="soft-b" d="M190 190 L190 110 L270 190 Z"/>
        <path class="s" d="M190 110 L270 190"/>
        <line class="dash" x1="190" y1="110" x2="270" y2="190"/>
        <line class="hi" x1="190" y1="190" x2="230" y2="150"/>
        <text class="em" x="236" y="146">throat = K·S</text>
        <circle class="hif" cx="190" cy="190" r="4"/><text class="lb" x="176" y="208" text-anchor="end">Root</text>
        <circle class="hif" cx="190" cy="110" r="4"/><text class="lb" x="182" y="106" text-anchor="end">Toe</text>
        <circle class="hif" cx="270" cy="190" r="4"/><text class="lb" x="276" y="206">Toe</text>
        ${arr("fw", 140, 110, 140, 190)}${arr("fw", 140, 190, 140, 110)}
        <text class="em" x="132" y="154" text-anchor="end">S₁</text>
        ${arr("fw", 190, 246, 270, 246)}${arr("fw", 270, 246, 190, 246)}
        <text class="em" x="230" y="240" text-anchor="middle">S₂</text>
        <text x="400" y="70">Size S = min(S₁, S₂)</text>
        <text x="400" y="96">Throat t_e = K·S  (K = 0.7 for 60–90°)</text>
        <text x="400" y="122">L_eff = actual length − 2S ,  ≮ 4S</text>
        <text x="400" y="148">End return ≥ 2S ,  t_e ≮ 3 mm</text>
        <text class="em" x="400" y="180">S_max = t − 1.5 mm (square edge)</text>
        <text class="em" x="400" y="202">S_max = (3/4) t (round edge)</text>
      </svg>`,
    },

    /* ------------------------------------------------ 6.1 bracket type I */
    "hb-stn-brk": {
      label: "Bracket connection Type I — forces on the bolt group",
      svg: `<svg viewBox="0 0 680 300" role="img" aria-label="A bracket bolted to a column with two vertical rows of bolts. Each bolt carries a downward direct shear force P over n, plus a torsional force perpendicular to the line joining it to the centre of gravity of the group, the two combining with the angle theta into a resultant that is largest in the farthest bolt.">
        ${mk("bk")}
        <rect class="conc" x="40" y="30" width="46" height="250"/>
        <path class="conc" d="M86 50 L320 50 L320 200 L200 250 L86 250 Z"/>
        <line class="dash" x1="86" y1="150" x2="330" y2="150"/><line class="dash" x1="160" y1="40" x2="160" y2="270"/>
        ${[0, 1, 2].map((r) => [0, 1].map((c) => {
          const x = 130 + c * 60, y = 90 + r * 60;
          return `<circle class="soft-b" cx="${x}" cy="${y}" r="8"/>
            <line class="thin" x1="160" y1="150" x2="${x}" y2="${y}"/>
            ${arr("bk", x, y, x, y + 30, "hi")}`;
        }).join("")).join("")}
        <circle class="acf" cx="160" cy="150" r="4"/><text class="ea" x="166" y="146">C.G.</text>
        ${arr("bk", 190, 90, 232, 62, "hi")}
        <text class="em" x="238" y="58">F₂</text>
        <text class="em" x="196" y="128">F₁</text>
        ${arr("bk", 300, 210, 300, 268)}
        <text class="em" x="308" y="252">P</text>
        ${arr("bk", 160, 286, 300, 286)}${arr("bk", 300, 286, 160, 286)}
        <text class="em" x="230" y="280" text-anchor="middle">e</text>
        <text x="380" y="70">F₁ = P / n</text>
        <text x="380" y="98">F₂ = (P·e) r / Σr²</text>
        <text x="380" y="126">F_R = √(F₁² + F₂² + 2F₁F₂cos θ)</text>
        <text class="lb" x="380" y="152">θ = angle between F₁ and F₂</text>
        <text class="em" x="380" y="184">Critical bolt: r maximum, θ minimum</text>
      </svg>`,
    },

    /* ------------------------------------------------ 7.1 shear lag */
    "hb-stn-shearlag": {
      label: "Shear lag in an angle connected by one leg",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="An angle bolted to a gusset through one leg: the connected leg is overstressed while the outstanding leg is not fully stressed, which is shear lag. The shear lag width b s equals w plus g minus t for a bolted connection and w for a welded one.">
        ${mk("sl")}
        <rect class="gl" x="40" y="150" width="260" height="14"/>
        <text class="lb" x="44" y="180">gusset plate</text>
        <path class="conc" d="M120 150 L260 150 L260 134 L136 134 L136 50 L120 50 Z"/>
        <circle class="soft-b" cx="200" cy="142" r="7"/>
        <line class="hi" x1="128" y1="50" x2="128" y2="134"/>
        ${arr("sl", 100, 50, 100, 150)}${arr("sl", 100, 150, 100, 50)}
        <text class="em" x="92" y="104" text-anchor="end">b_s</text>
        ${arr("sl", 136, 118, 200, 118)}${arr("sl", 200, 118, 136, 118)}
        <text class="em" x="168" y="112" text-anchor="middle">g</text>
        <text class="em" x="268" y="146">connected leg</text>
        <text class="lb" x="268" y="164">(overstressed)</text>
        <text class="em" x="146" y="62">outstanding leg</text>
        <text class="lb" x="146" y="80">(not fully stressed)</text>
        <text x="400" y="200">bolted:  b_s = w + g − t</text>
        <text x="400" y="226">welded:  b_s = w</text>
        <text class="em" x="400" y="60">β = 1.4 − 0.076 (w/t)(f_y/f_u)(b_s/l_c)</text>
        <text class="lb" x="400" y="82">β ≥ 0.7</text>
        <text class="lb" x="400" y="110">Connect the LONGER leg of an</text>
        <text class="lb" x="400" y="128">unequal angle; longer connection</text>
        <text class="lb" x="400" y="146">⇒ less shear lag</text>
      </svg>`,
    },

    /* ------------------------------------------------ 8.3 buckling curves */
    "hb-stn-fcd": {
      label: "Column buckling curves a, b, c, d",
      svg: `<svg viewBox="0 0 680 280" role="img" aria-label="Graph of f c d over f y against the non dimensional slenderness lambda e. A plateau up to lambda e of 0.2, then four falling curves a, b, c and d for increasing imperfection, converging near lambda e of 3.">
        <line class="s" x1="80" y1="230" x2="620" y2="230"/><line class="s" x1="80" y1="230" x2="80" y2="30"/>
        <text class="lb" x="600" y="272" text-anchor="end">λ_e = √(f_y/f_cc) →</text>
        <text class="lb" x="72" y="40" text-anchor="end">f_cd/f_y</text>
        <line class="gl" x1="80" y1="60" x2="180" y2="60"/>
        <line class="dash" x1="180" y1="60" x2="180" y2="230"/>
        <text class="lb" x="180" y="248" text-anchor="middle">0.2</text>
        <text class="lb" x="520" y="248" text-anchor="middle">3.0</text>
        <text class="lb" x="72" y="64" text-anchor="end">0.9</text>
        ${[["a", 0, "hi"], ["b", 20, "ac"], ["c", 40, "s"], ["d", 60, "thin"]].map(([t, dy, cls]) =>
          `<path class="${cls}" d="M80 60 L180 60 Q300 ${96 + dy} 420 ${150 + dy * 0.7} Q520 ${186 + dy * 0.4} 600 ${200 + dy * 0.25}"/>
           <text class="${cls === "hi" ? "em" : cls === "ac" ? "ea" : "lb"}" x="296" y="${92 + dy}">${t}</text>`).join("")}
        <text class="lb" x="330" y="60">plateau: λ_e &lt; 0.2, no buckling reduction</text>
        <text x="100" y="272">α = 0.21 (a) · 0.34 (b) · 0.49 (c) · 0.76 (d)</text>
      </svg>`,
    },

    /* ------------------------------------------------ 9.1 laced vs battened */
    "hb-stn-lacing": {
      label: "Laced column and battened column",
      svg: `<svg viewBox="0 0 680 300" role="img" aria-label="Left: a built-up column of two members joined by zig-zag lacing at an angle of 40 to 70 degrees. Right: the same column with horizontal batten plates, end battens deeper than intermediate battens.">
        ${mk("lc")}
        ${[0, 1].map((k) => {
          const x0 = 90 + k * 320;
          let inner = `<rect class="conc" x="${x0}" y="40" width="18" height="230"/><rect class="conc" x="${x0 + 130}" y="40" width="18" height="230"/>`;
          if (k === 0) {
            for (let i = 0; i < 4; i++) {
              const y = 60 + i * 52;
              inner += `<line class="hi" x1="${x0 + 18}" y1="${y}" x2="${x0 + 130}" y2="${y + 26}"/><line class="hi" x1="${x0 + 130}" y1="${y + 26}" x2="${x0 + 18}" y2="${y + 52}"/>`;
            }
            inner += `<path class="thin" d="M${x0 + 18} 112 L${x0 + 18} 86"/><text class="em" x="${x0 + 24}" y="106">θ</text>`;
            inner += `<text class="em" x="${x0 + 74}" y="292" text-anchor="middle">Lacing — λ = 1.05 λ₀</text>`;
            inner += `<text class="lb" x="${x0 + 74}" y="26" text-anchor="middle">40°–70°</text>`;
          } else {
            [[46, 34], [110, 22], [176, 22], [236, 34]].forEach(([y, h]) => {
              inner += `<rect class="soft-b" x="${x0 + 18}" y="${y}" width="112" height="${h}"/>`;
            });
            inner += `<text class="em" x="${x0 + 74}" y="292" text-anchor="middle">Battens — λ = 1.10 λ₀</text>`;
            inner += `<text class="em" x="${x0 - 8}" y="66" text-anchor="end">end batten</text><text class="em" x="${x0 - 8}" y="128" text-anchor="end">intermediate</text>`;
          }
          return inner;
        }).join("")}
        
      </svg>`,
    },

    /* ------------------------------------------------ 10.2 base pressure */
    "hb-stn-base": {
      label: "Base plate pressure for the three eccentricity cases",
      svg: `<svg viewBox="0 0 680 240" role="img" aria-label="Three pressure diagrams under a base plate: for eccentricity less than L over 6 the pressure is trapezoidal and entirely compressive; at exactly L over 6 it is triangular reaching zero at one edge; beyond L over 6 part of the plate lifts off and a shorter triangular block of length x carries the load.">
        ${mk("bs")}
        ${[["e < L/6", 0], ["e = L/6", 1], ["e > L/6", 2]].map(([lab, i]) => {
          const x = 40 + i * 215, w = 170, y = 70;
          let press = "";
          if (i === 0) press = `<path class="soft-b" d="M${x} ${y + 20} L${x + w} ${y + 20} L${x + w} ${y + 76} L${x} ${y + 44} Z"/>`;
          if (i === 1) press = `<path class="soft-b" d="M${x} ${y + 20} L${x + w} ${y + 20} L${x + w} ${y + 82} Z"/>`;
          if (i === 2) press = `<path class="soft-b" d="M${x + 60} ${y + 20} L${x + w} ${y + 20} L${x + w} ${y + 88} Z"/><text class="lb" x="${x + 28}" y="${y + 60}">lift-off</text>`;
          return `<rect class="conc" x="${x}" y="${y}" width="${w}" height="20"/>
            ${press}
            ${arr("bs", x + w - 40, 30, x + w - 40, y - 2)}
            <text class="em" x="${x + w - 32}" y="42">P</text>
            <text class="em" x="${x + w / 2}" y="${y + 116}" text-anchor="middle">${lab}</text>`;
        }).join("")}
        <text class="lb" x="40" y="212">σ = (P/LB)(1 ± 6e/L) ≤ 0.6 f_ck  ·  t = √[2.5 w (α² − 0.3 β²)/(f_y/γ_mo)]</text>
      </svg>`,
    },

    /* ------------------------------------------------ 11.3 web buckling/crippling */
    "hb-stn-webcrip": {
      label: "Web buckling and web crippling",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="Left: web buckling, the load spreading at 45 degrees down to the neutral axis and the web bowing over its full height. Right: web crippling, the load spreading at one vertical to two point five horizontal to the root of the fillet, where the web crumples just under the flange.">
        ${mk("wb")}
        ${[0, 1].map((k) => {
          const x = 60 + k * 330;
          const flange = `<rect class="conc" x="${x}" y="60" width="200" height="16"/><rect class="conc" x="${x}" y="200" width="200" height="16"/>`;
          const web = k === 0
            ? `<path class="s" d="M${x + 100} 76 Q${x + 132} 138 ${x + 100} 200"/><path class="s" d="M${x + 94} 76 Q${x + 62} 138 ${x + 94} 200"/>`
            : `<line class="s" x1="${x + 96}" y1="76" x2="${x + 96}" y2="200"/><line class="s" x1="${x + 104}" y1="76" x2="${x + 104}" y2="200"/><path class="hi" d="M${x + 88} 92 L${x + 112} 84 L${x + 88} 100 L${x + 112} 96"/>`;
          const disp = k === 0
            ? `<line class="dash" x1="${x + 80}" y1="60" x2="${x + 20}" y2="138"/><line class="dash" x1="${x + 120}" y1="60" x2="${x + 180}" y2="138"/><line class="gl" x1="${x}" y1="138" x2="${x + 200}" y2="138"/><text class="em" x="${x + 128}" y="96">45°</text><text class="lb" x="${x + 100}" y="156" text-anchor="middle">B₁ at the NA</text>`
            : `<line class="dash" x1="${x + 80}" y1="60" x2="${x + 40}" y2="92"/><line class="dash" x1="${x + 120}" y1="60" x2="${x + 160}" y2="92"/><line class="gl" x1="${x + 30}" y1="92" x2="${x + 170}" y2="92"/><text class="em" x="${x + 126}" y="80">1 : 2.5</text><text class="lb" x="${x + 100}" y="112" text-anchor="middle">B₁ at the fillet root</text>`;
          return `${flange}${web}${disp}
            ${arr("wb", x + 100, 24, x + 100, 58)}
            <text class="em" x="${x + 108}" y="38">P</text>
            <text class="em" x="${x + 100}" y="244" text-anchor="middle">${k === 0 ? "Web buckling — column action" : "Web crippling — bearing at the root"}</text>`;
        }).join("")}
      </svg>`,
    },

    /* ------------------------------------------------ 12.1 plate girder */
    "hb-stn-pg": {
      label: "Plate girder with its stiffeners",
      svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Elevation of a welded plate girder showing top and bottom flange plates, the web, end bearing stiffeners over the supports, a load bearing stiffener under the point load, intermediate vertical stiffeners at spacing c, and a horizontal stiffener at one fifth of the depth from the compression flange.">
        ${mk("pg")}
        <rect class="conc" x="60" y="60" width="560" height="14"/>
        <rect class="conc" x="60" y="196" width="560" height="14"/>
        <rect class="gl" x="60" y="74" width="560" height="122"/>
        <line class="ac" x1="60" y1="98" x2="620" y2="98"/>
        <text class="ea" x="470" y="116" text-anchor="middle">horizontal stiffener at d/5</text>
        ${[70, 200, 330, 460, 600].map((x, i) =>
          `<rect class="soft-b" x="${x - 6}" y="74" width="12" height="122"/>
           <text class="lb" x="${x}" y="228" text-anchor="middle">${i === 0 || i === 4 ? "end bearing" : i === 2 ? "load bearing" : "intermediate"}</text>`).join("")}
        ${arr("pg", 200, 44, 330, 44)}${arr("pg", 330, 44, 200, 44)}
        <text class="em" x="265" y="38" text-anchor="middle">c = 0.33d – 1.5d</text>
        ${arr("pg", 330, 20, 330, 56)}
        <text class="em" x="348" y="18">load</text>
        <text class="lb" x="200" y="150" text-anchor="middle">flange → BM · web → SF</text>
      </svg>`,
    },

    /* ------------------------------------------------ 13.1 truss */
    "hb-stn-truss": {
      label: "Elements of a roof truss",
      svg: `<svg viewBox="0 0 680 260" role="img" aria-label="A pitched roof truss with principal rafter as top chord, main tie as bottom chord, ridge at the apex, eaves at the ends, web members inside, purlins sitting on the rafter at panel points, the rise and span dimensioned and the slope angle theta at the support.">
        ${mk("tr")}
        <path class="s" d="M80 200 L340 70 L600 200 Z"/>
        <line class="s" x1="80" y1="200" x2="600" y2="200"/>
        ${[[210, 135], [340, 200], [470, 135]].map(([x, y]) => `<line class="thin" x1="${x}" y1="${y}" x2="340" y2="${y === 200 ? 70 : 200}"/>`).join("")}
        <line class="thin" x1="210" y1="135" x2="340" y2="200"/><line class="thin" x1="470" y1="135" x2="340" y2="200"/>
        ${[[145, 168], [210, 135], [275, 102], [405, 102], [470, 135], [535, 168]].map(([x, y]) => `<rect class="soft-b" x="${x - 7}" y="${y - 12}" width="14" height="12"/>`).join("")}
        <circle class="hif" cx="340" cy="70" r="4"/>
        <text class="em" x="340" y="56" text-anchor="middle">ridge</text>
        <text class="em" x="120" y="76">principal rafter (top chord)</text>
        <text class="em" x="340" y="216" text-anchor="middle">main tie (bottom chord)</text>
        <text class="lb" x="120" y="192">eaves</text>
        <text class="lb" x="500" y="122">purlins at panel points</text>
        ${arr("tr", 626, 70, 626, 200)}${arr("tr", 626, 200, 626, 70)}
        <text class="em" x="618" y="140" text-anchor="end">rise</text>
        ${arr("tr", 80, 240, 600, 240)}${arr("tr", 600, 240, 80, 240)}
        <text class="em" x="340" y="254" text-anchor="middle">span</text>
        <text class="em" x="104" y="190">θ</text>
        <text class="lb" x="20" y="40">pitch = rise/span · slope θ = 2 × pitch</text>
      </svg>`,
    },

  });
})();
