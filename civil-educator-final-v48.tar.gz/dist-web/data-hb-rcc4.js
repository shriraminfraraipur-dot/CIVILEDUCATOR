/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   Chapter 7 — Slabs
   Chapter 8 — Columns

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "rcc"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "rcc-7",
      n: 7,
      title: "Slabs",
      hi: "स्लैब",
      blurb: "Why a slab is sized by deflection rather than strength, how a panel decides which way to span, and the corner steel almost everybody forgets.",
      mins: 46,
      sections: [

        {
          n: "7.1",
          title: "A slab is a very wide, very shallow beam",
          hi: "स्लैब एक चौड़ी, उथली बीम है",
          blocks: [
            { k: "p", t: "Everything from Chapters 3 and 5 still applies to a slab. The flexural theory is identical, the stress block is identical, xu,max is identical. Design is carried out on a strip one metre wide, so b = 1000 mm in every formula, and the answer comes out as an area of steel per metre width which is then converted into a bar diameter and a spacing." },
            { k: "p", t: "What changes is which check governs and which details matter." },
            { k: "list", items: [
              "The moment per metre width is small, so <strong>deflection</strong>, not strength, fixes the depth.",
              "Shear is almost never critical, and shear reinforcement in a slab is awkward to place — so slabs are normally made thick enough not to need it at all.",
              "The load may travel in one direction or in two, and deciding which is the first real design decision.",
              "Detailing rules — bar spacing, distribution steel, minimum steel — carry far more of the design than they do in a beam.",
            ]},
            { k: "note", t: "IS 456 Cl. 24 covers solid slabs and largely refers back to the beam clauses. The slab-specific rules are in Cl. 24, Cl. 26.5.2 (reinforcement), Cl. 26.3.3(b) (spacing) and Annex D (two-way slabs)." },
          ],
        },

        {
          n: "7.2",
          title: "One-way or two-way",
          hi: "वन-वे या टू-वे",
          blocks: [
            { k: "p", t: "A slab supported on all four sides can bend in both directions at once. How it shares the load between them follows from a simple physical fact: <strong>load follows stiffness</strong>, and the stiffness of a strip goes as 1/L³." },
            { k: "dia", id: "hb-rcc-slabway", cap: "Load takes the stiffer path. A panel much longer than it is wide sends almost everything the short way." },
            { k: "p", t: "Imagine two strips crossing at the centre of a panel, one of length lx and one of length ly. Both must deflect the same amount where they cross, so the load divides in proportion to their stiffnesses:" },
            { k: "eq", expr: "wx / wy  =  (ly / lx)⁴", where: [
              ["wx", "the share of load carried by the short-span strip"],
              ["wy", "the share carried by the long-span strip"],
            ]},
            { k: "p", t: "The fourth power is what makes the answer so lopsided. At ly/lx = 2 the short strip takes sixteen times as much load as the long one — about 94% of the total. That is why IS 456 Cl. 24.4 draws the line there:" },
            { k: "list", items: [
              "<strong>ly / lx &gt; 2</strong> — treat as <strong>one-way</strong>. Design the main steel for the short span, and provide distribution steel the other way.",
              "<strong>ly / lx ≤ 2</strong> — treat as <strong>two-way</strong>. Design main steel in both directions.",
            ]},
            { k: "trap", t: "In a two-way slab the short-span bars go in the <strong>lower layer</strong>, closest to the soffit. They carry the larger moment, so they need the larger effective depth. Reversing the layers can cost 10–15% of the short-span capacity, and it is an error made on site rather than on paper — which means it has to be marked clearly on the drawing." },
            { k: "note", t: "A slab supported on only two opposite sides is one-way whatever its proportions, because there is nothing to span to in the other direction. The ly/lx test applies to panels supported on all four sides." },
          ],
        },

        {
          n: "7.3",
          title: "Effective span",
          hi: "प्रभावी स्पैन",
          blocks: [
            { k: "p", t: "A slab does not span from wall centre to wall centre, nor exactly from face to face — the reaction concentrates somewhere inside the bearing. Cl. 22.2 settles it:" },
            { k: "list", items: [
              "<strong>Simply supported</strong>: the lesser of (clear span + effective depth) and (centre-to-centre of supports).",
              "<strong>Continuous</strong>, where the support width is less than 1/12 of the clear span: centre to centre of supports.",
              "<strong>Cantilever</strong>: the length to the face of the support, plus half the effective depth (or to the centre of support for a cantilever at the end of a continuous beam).",
            ]},
            { k: "trap", t: "The effective span appears squared in the moment and cubed in the deflection. Using the clear span instead of the effective span understates the moment by 5–8% in a typical slab, which is enough to matter — and it compounds, because the depth chosen from it is then too small as well." },
          ],
        },

        {
          n: "7.4",
          title: "Depth from deflection",
          hi: "गहराई विक्षेपण से",
          blocks: [
            { k: "p", t: "A slab design starts at the deflection rule rather than ending at it. Cl. 23.2.1 controls deflection indirectly, by capping the span to effective depth ratio instead of computing the deflection itself — which is enough for normal members and far quicker." },
            { k: "dia", id: "hb-rcc-spandepth", cap: "For a beam, strength and deflection ask for similar depths. For a slab they do not." },
            { k: "list", items: [
              "<strong>Cantilever</strong> — basic l/d = 7",
              "<strong>Simply supported</strong> — basic l/d = 20",
              "<strong>Continuous</strong> — basic l/d = 26",
            ]},
            { k: "p", t: "The basic value is then multiplied by modification factors: one for the tension steel (Fig. 4, a function of the percentage of steel and its service stress fs), one for compression steel (Fig. 5), and one for flanged sections (Fig. 6). For spans over 10 m the whole ratio is multiplied by 10/span, because the rule was calibrated on ordinary spans." },
            { k: "eq", expr: "fs = 0.58 fy × (Ast required / Ast provided)", where: [
              ["fs", "service stress in the tension steel, N/mm² — the input to the Fig. 4 modification factor"],
            ]},
            { k: "p", t: "Notice what that expression rewards: providing <em>more</em> steel than the calculation asked for lowers fs, which raises the modification factor, which allows a thinner slab. That is a real trade — steel against concrete depth — and it is how a slab that just fails the deflection check is usually rescued." },
            { k: "note", t: "For two-way slabs, Cl. 24.1 permits higher ratios where the shorter span does not exceed 3.5 m and the loading is light: 35 for simply supported and 40 for continuous with mild steel, which become 28 and 32 for Fe 415 after the 0.8 factor. The shorter span is the one used in the ratio." },
          ],
        },

        {
          n: "7.5",
          title: "Designing a one-way slab",
          hi: "वन-वे स्लैब डिज़ाइन",
          blocks: [
            { k: "steps", items: [
              "Estimate d from the span/depth rule, then fix D = d + cover + half the bar diameter, rounded up to a convenient 10 mm.",
              "Compute the effective span (Cl. 22.2) — the self weight now depends on D, so this comes after step 1.",
              "Work out the total load per m², factor it by 1.5, and find Mu = wu l²/8 per metre width (or from the Cl. 22.5 coefficients for a continuous slab).",
              "Find Ast for a 1000 mm wide strip, exactly as in Chapter 3.",
              "Convert to a bar diameter and spacing; check the spacing and minimum-steel limits.",
              "Provide distribution steel across the span direction.",
              "Check shear, and check the deflection rule properly with the steel actually provided.",
            ]},
            { k: "eg",
              title: "Example 7.1 — One-way simply supported slab",
              given: "Clear span 3.5 m between 230 mm brick walls. Live load 3 kN/m², floor finish 1 kN/m². M20 concrete, Fe 415 steel, mild exposure (nominal cover 20 mm).",
              steps: [
                { t: "Trial depth from the span/depth rule", w: "Simply supported basic l/d = 20; expect a modification factor of about 1.4 for a lightly reinforced slab\nl/d ≈ 28  →  d ≈ 3500/28 = 125 mm\nD = 125 + 20 (cover) + 5 (half of a 10 mm bar) = 150 mm" },
                { t: "Effective span (Cl. 22.2)", w: "clear span + d = 3500 + 125 = 3625 mm\ncentre to centre = 3500 + 230 = 3730 mm\nTake the lesser: leff = 3625 mm" },
                { t: "Loads on a 1 m wide strip", w: "self weight  = 0.150 × 25 = 3.75 kN/m²\nfloor finish =              1.00\nlive load    =              3.00\ntotal (service) w = 7.75 kN/m²\nwu = 1.5 × 7.75 = 11.625 kN/m²" },
                { t: "Design moment and shear", w: "Mu = wu l²/8 = 11.625 × 3.625²/8 = 19.10 kNm per metre\nVu = wu l/2 = 11.625 × 3.625/2 = 21.07 kN per metre" },
                { t: "Is a singly reinforced section enough?", w: "Mu,lim = 0.138 × 20 × 1000 × 125² = 43.1 kNm  >  19.10  ✓ (with a large margin — as expected for a slab)" },
                { t: "Area of steel (b = 1000 mm)", w: "19.10 × 10⁶ = 45,131 Ast − 7.4918 Ast²\n7.4918 Ast² − 45,131 Ast + 19.10 × 10⁶ = 0\nAst = [45,131 − 38,270]/14.984 = 457.9 mm² per metre" },
                { t: "Choose bars and check spacing", w: "10 mm bars: spacing = 78.54 × 1000/457.9 = 171 mm  →  provide 10 mm @ 170 mm c/c\nAst provided = 78.54 × 1000/170 = 462 mm²  ✓\nMaximum spacing (Cl. 26.3.3): lesser of 3d = 375 mm and 300 mm → 300 mm  ✓\nMinimum steel (Cl. 26.5.2.1): 0.12% × 1000 × 150 = 180 mm²  ✓" },
                { t: "Distribution steel", w: "0.12% of gross area = 180 mm² per metre\n8 mm @ 270 mm c/c gives 186 mm²  ✓\nMaximum spacing: lesser of 5d = 625 mm and 450 mm → 450 mm  ✓" },
                { t: "Shear check (Cl. 40)", w: "τv = 21,070/(1000 × 125) = 0.169 N/mm²\npt = 100 × 462/(1000 × 125) = 0.37%\nτc (M20, from the Table 19 expression) = 0.42 N/mm²\nSolid slab factor k for D = 150 mm (Cl. 40.2.1.1) = 1.30 → k τc = 0.55 N/mm²\n0.169  ≪  0.55  ✓ no shear reinforcement needed" },
                { t: "Deflection check with the steel provided", w: "pt = 0.37%,  fs = 0.58 × 415 × 457.9/462 = 239 N/mm²\nModification factor from Fig. 4 ≈ 1.45\nPermitted l/d = 20 × 1.45 = 29;  provided l/d = 3625/125 = 29.0  ✓ (just satisfied)" },
              ],
              ans: "150 mm slab. Main steel 10 mm @ 170 mm c/c along the span; distribution steel 8 mm @ 270 mm c/c across it. Alternate main bars may be bent up near the supports or curtailed per Cl. 26.2.3.",
            },
            { k: "trap", t: "The deflection check passed with nothing to spare, and it was the <em>last</em> step — but it was also the <em>first</em>, because the trial depth came from it. That circularity is the shape of every slab design. If the final check fails, increase D by 10 mm and run the whole thing again; do not try to fix it by adding steel alone, because the self weight and hence the moment change too." },
            { k: "h", t: "Continuous slabs — the Cl. 22.5 coefficients" },
            { k: "p", t: "For continuous beams and one-way slabs with at least three spans, uniformly loaded, and with spans differing by no more than 15% of the longest, IS 456 Cl. 22.5 lets the moments and shears be taken from coefficient tables (Tables 12 and 13) instead of running moment distribution (conditions as stated in the <a href=\"https://cec.nic.in/webpath/curriculum/Module/Arch/Paper16/22/downloads/script.pdf\" target=\"_blank\" rel=\"noopener\">CEC (MHRD) lecture on continuous beams</a>). The governing values at the end of the run are:" },
            { k: "cmp", t: "Table 12/13 coefficients at the end span (w × l² for moment, w × l for shear)", cols: ["Dead load", "Imposed load"], rows: [
              ["Moment near middle of end span", "+ 1/12", "+ 1/10"],
              ["Moment at support next to the end support", "− 1/10", "− 1/9"],
              ["Shear at the end support", "0.40", "0.45"],
              ["Shear at the first interior support", "0.60", "0.60"],
            ] },
            { k: "note", t: "End-span values as given by <a href=\"https://www.pw.live/gate/exams/slabs-rcc-gate-civil-engineering-notes\" target=\"_blank\" rel=\"noopener\">Physics Wallah GATE notes</a>. Interior spans and supports get smaller coefficients in the same tables — read them from the code. Imposed load always has the larger coefficients because it can be placed on alternate spans to produce the worst case, while dead load is always everywhere. A slab designed with wl²/8 throughout wastes steel at mid-span and, worse, has no top steel at the supports where the hogging moment −wl²/10 or so actually lives." },
          ],
        },

        {
          n: "7.6",
          title: "Two-way slabs",
          hi: "टू-वे स्लैब",
          blocks: [
            { k: "p", t: "A two-way panel is a genuinely two-dimensional plate problem, and its exact elastic solution is an infinite series. Nobody designs from that. IS 456 Annex D gives coefficients from yield-line analysis, tabulated against the aspect ratio ly/lx, and the moments follow directly:" },
            { k: "eq", expr: "Mx = αx wu lx²        My = αy wu lx²", where: [
              ["αx, αy", "moment coefficients for the short and long spans, from Table 26 (restrained panels) or Table 27 (simply supported panels)"],
              ["lx", "the SHORTER effective span — it appears in both expressions"],
            ]},
            { k: "trap", t: "Both moments use <strong>lx²</strong> — the shorter span — even the moment for the long direction. The coefficient αy carries the whole of the aspect-ratio effect. Using ly² for My is a large and common error, and it is unconservative in the direction that already has less depth." },
            { k: "h", t: "Which table" },
            { k: "list", items: [
              "<strong>Table 27 (Annex D-2)</strong> — panels simply supported on all four sides with corners <em>not held down</em> and no provision for torsion. The corners are free to lift.",
              "<strong>Table 26 (Annex D-1)</strong> — <em>restrained</em> panels, where the corners are held down and torsion reinforcement is provided. There are nine cases depending on which edges are continuous, and both mid-span and support moments are given.",
            ]},
            { k: "p", t: "A real floor slab cast monolithically with its beams is a restrained panel, so Table 26 is the usual one. Table 27 describes a slab resting freely on four walls — rarer than textbooks suggest, and it gives larger mid-span moments precisely because it cannot rely on the corners." },
            { k: "eg",
              title: "Example 7.2 — Two-way slab, simply supported, corners not held down",
              given: "Room 4.0 m × 5.0 m clear. Live load 3 kN/m², finish 1 kN/m². M20, Fe 415, 20 mm cover, 10 mm bars. Assume an overall depth of 175 mm.",
              steps: [
                { t: "Effective depths — two, not one", w: "Short span (lower layer):  dx = 175 − 20 − 5 = 150 mm\nLong span (upper layer):   dy = 150 − 10 = 140 mm" },
                { t: "Effective spans and aspect ratio", w: "lx = 4000 + 150 = 4150 mm\nly = 5000 + 140 = 5140 mm\nly/lx = 1.239  ≤  2  →  two-way  ✓" },
                { t: "Loads", w: "self weight 0.175 × 25 = 4.375;  finish 1.0;  live 3.0\nw = 8.375 kN/m²;  wu = 1.5 × 8.375 = 12.56 kN/m²" },
                { t: "Coefficients (Table 27, interpolated at ly/lx = 1.239)", w: "αx = 0.0875     αy = 0.0575" },
                { t: "Moments", w: "Mx = 0.0875 × 12.56 × 4.15² = 18.92 kNm/m\nMy = 0.0575 × 12.56 × 4.15² = 12.43 kNm/m\n(both use lx², the shorter span)" },
                { t: "Steel for the short span, dx = 150", w: "7.4918 Ast² − 54,158 Ast + 18.92 × 10⁶ = 0\nAst = [54,158 − 48,641]/14.984 = 368 mm²/m\n10 mm @ 210 mm c/c = 374 mm²  ✓ (spacing limit 300 mm  ✓)" },
                { t: "Steel for the long span, dy = 140", w: "7.4918 Ast² − 50,547 Ast + 12.43 × 10⁶ = 0\nAst = [50,547 − 46,717]/14.984 = 256 mm²/m\nMinimum steel = 0.12% × 1000 × 175 = 210 mm²  ✓\n8 mm @ 190 mm c/c = 265 mm²  ✓" },
              ],
              ans: "175 mm slab. Short span: 10 mm @ 210 c/c in the lower layer. Long span: 8 mm @ 190 c/c above it. Because Table 27 is being used, the corners are assumed free to lift — if they are in fact held down by beams, the panel must be designed as restrained, using Table 26 and the corner steel of §7.7.",
            },
          ],
        },

        {
          n: "7.7",
          title: "Corner reinforcement",
          hi: "कोनों का स्टील",
          blocks: [
            { k: "p", t: "Here is the part that is omitted more often than any other detail in Indian slab construction, and the reason those diagonal cracks appear across the corners of ceilings." },
            { k: "p", t: "A two-way panel dishes downwards in the middle. Geometry then forces the corners to rotate <em>upwards</em> — the surface cannot stay attached to the support line and dish at the same time. If the corner is free, it simply lifts. If it is held down by a monolithic beam, it cannot lift, so it twists instead: the corner region goes into pure torsion, with principal tension running diagonally on the top face and at right angles to it on the bottom." },
            { k: "dia", id: "hb-rcc-corner", cap: "The corner lifts if it can; if it is held down, it twists — and torsion needs steel in four layers." },
            { k: "p", t: "Cl. D-1.8 prescribes the answer for a restrained panel whose corner is discontinuous on both edges:" },
            { k: "list", items: [
              "Reinforcement in <strong>four layers</strong> — two at the top, two at the bottom, each running parallel to a side.",
              "Area in each layer: <strong>three-quarters</strong> of the area required for the maximum mid-span moment of the short span.",
              "Extending from the edges over a distance of <strong>lx/5</strong> in each direction, where lx is the shorter span.",
              "Where only one edge is discontinuous, half of this area suffices (Cl. D-1.9).",
            ]},
            { k: "trap", t: "Both the diagonal directions of tension have to be caught, which is why the mesh is in four layers and not two. A top mesh alone catches the tension on the top face and leaves the bottom unreinforced, and the crack will open there instead." },
          ],
        },

        {
          n: "7.8",
          title: "Detailing rules that do the real work",
          hi: "डिटेलिंग नियम",
          blocks: [
            { k: "list", items: [
              "<strong>Minimum steel (Cl. 26.5.2.1)</strong> — 0.15% of gross area for mild steel, 0.12% for high-strength deformed bars, in <em>each</em> direction. This is as much a shrinkage and temperature provision as a flexural one.",
              "<strong>Maximum bar diameter (Cl. 26.5.2.2)</strong> — not more than D/8. A 150 mm slab therefore takes nothing larger than an 18 mm bar, and in practice 8, 10 and 12 mm are what get used.",
              "<strong>Maximum spacing, main steel (Cl. 26.3.3)</strong> — the lesser of 3d and 300 mm.",
              "<strong>Maximum spacing, distribution steel</strong> — the lesser of 5d and 450 mm.",
            ]},
            { k: "p", t: "The spacing limits exist for crack control. A given area of steel provided as many small bars closely spaced controls cracking far better than the same area as a few large bars far apart, because each bar only influences the concrete near it. This is also why slab steel is almost always specified as a diameter and a spacing rather than as a number of bars." },
            { k: "note", t: "Distribution steel in a one-way slab is not decoration. It spreads a concentrated load across several metres of the main steel, resists the shrinkage and temperature stresses along the span direction, and holds the main bars at their spacing while the slab is being cast." },
          ],
        },

        {
          n: "7.9",
          title: "Flat slabs, briefly",
          hi: "फ्लैट स्लैब — संक्षेप में",
          blocks: [
            { k: "p", t: "A flat slab is supported directly on columns with no beams. The advantages are real — a flat soffit, shallower floor-to-floor height, simpler formwork, faster construction — and so is the price: the load has to reach the column through the slab itself, over a very small area." },
            { k: "p", t: "IS 456 Cl. 31 covers it, using the direct design method or the equivalent frame method. The slab is divided into column strips and middle strips and the panel moment is distributed between them, because the slab near the column carries much more than the slab at mid-panel." },
            { k: "def", term: "Punching shear", t: "The governing check for a flat slab. The column tries to push a truncated cone straight through the slab, and the check is made on a perimeter at d/2 from the column face (Cl. 31.6.1). The permitted stress is ks × 0.25 √fck, where ks = 0.5 + βc, not more than 1.0, and βc is the ratio of the short side of the column to the long side (Cl. 31.6.3)." },
            { k: "p", t: "Where punching governs and a thicker slab is uneconomic, the usual remedies are a drop panel (local thickening around the column), a column head or flared capital (enlarging the loaded perimeter), or shear reinforcement in the slab. Chapter 9 uses the same punching check for footings, where the column pushes down through the pad instead." },
          ],
        },

        {
          n: "7.10",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Design a 1 m wide strip: b = 1000 mm throughout.",
              "ly/lx > 2 → one-way; ≤ 2 → two-way (Cl. 24.4).",
              "Depth comes from the span/depth rule first, and is confirmed by it last.",
              "Effective span (Cl. 22.2) — the lesser of clear span + d and centre to centre.",
              "Two-way moments: Mx = αx wu lx², My = αy wu lx² — both with lx².",
              "Short-span bars in the lower layer.",
              "Restrained corners need torsion steel in four layers over lx/5 (Cl. D-1.8).",
              "Spacing: 3d or 300 mm for main steel, 5d or 450 mm for distribution steel; bar diameter ≤ D/8.",
            ]},
            { k: "p", t: "Chapter 8 turns the structure upright. A column carries axial load and moment together, and the interaction between them makes it the one member that cannot be designed from a single closed-form expression." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "rcc-8",
      n: 8,
      title: "Columns",
      hi: "कॉलम",
      blurb: "Why a column's capacity is a curve rather than a number, what makes one slender, and why the ties matter more than they look.",
      mins: 44,
      sections: [

        {
          n: "8.1",
          title: "What makes a column different",
          hi: "कॉलम अलग क्यों है",
          blocks: [
            { k: "p", t: "IS 456 Cl. 25.1.1 defines a compression member as a column when its effective length exceeds three times its least lateral dimension; shorter than that it is a pedestal, and different rules apply. But the real difference from everything so far is not the definition — it is that a column almost never carries pure axial load." },
            { k: "list", items: [
              "The beams framing into it are never loaded symmetrically, so a moment is transferred at every floor.",
              "Construction is never perfect: the column is a little out of plumb and the load a little off centre.",
              "Lateral load — wind, earthquake — puts moment into every column in the frame.",
              "Even a genuinely axial load becomes eccentric once the column deflects sideways, and the deflection grows with the load.",
            ]},
            { k: "p", t: "So a column is a member under combined axial load and bending, and that combination behaves in a way that is not intuitive: below a certain axial load, adding more load makes the column <em>stronger</em> in bending; above it, adding more makes it <em>weaker</em>. §8.6 explains why." },
            { k: "note", t: "A column failure is also the most serious failure in a building. A beam that fails drops one bay; a column that fails removes the support from everything above it, and the collapse propagates. This is why the code's detailing rules for columns are stricter than the calculation alone would suggest, and why IS 13920 tightens them further for seismic design." },
          ],
        },

        {
          n: "8.2",
          title: "Effective length",
          hi: "प्रभावी लंबाई",
          blocks: [
            { k: "p", t: "A column buckles between its points of restraint, and how well it is restrained decides the load at which it does. The effective length le is the length of an equivalent pin-ended column that would buckle at the same load; IS 456 Cl. 25.2 and Table 28 give it as a factor times the unsupported length." },
            { k: "dia", id: "hb-rcc-efflength", cap: "The same physical column, restrained four different ways, with the theoretical effective length for each." },
            { k: "p", t: "Table 28 distinguishes two things that students routinely conflate: whether the end is <strong>held in position</strong> (cannot translate sideways) and whether it is <strong>restrained against rotation</strong>. A column in a braced frame is held in position at every floor; one in an unbraced frame is not, and its effective length can exceed its actual length — the theoretical value for a column fixed at the base and free at the top is 2.0 l." },
            { k: "trap", t: "Table 28's values are theoretical. Cl. 25.2 and Annex E point out that real end conditions are always partial, and the values recommended for design are usually more conservative than the theoretical ones — for example 0.65 l rather than 0.5 l for a column with both ends effectively fixed. Use the design value, not the textbook one." },
            { k: "p", t: "Because the additional moment in a slender column goes as (le/D)², halving the effective length reduces that moment by a factor of four. Bracing a frame is almost always cheaper than making its columns bigger." },
          ],
        },

        {
          n: "8.3",
          title: "Short or slender",
          hi: "छोटा या स्लेंडर",
          blocks: [
            { k: "p", t: "Cl. 25.1.2 draws the line, and it is drawn separately about each axis:" },
            { k: "eq", expr: "SHORT  if  lex/D < 12  and  ley/b < 12        otherwise SLENDER", where: [
              ["lex, ley", "effective lengths about the major and minor axes"],
              ["D, b", "the corresponding lateral dimensions of the section"],
            ]},
            { k: "p", t: "The distinction is about whether the column's own sideways deflection matters. A short column reaches its material capacity while still essentially straight — the moment at mid-height is the moment applied at the ends. A slender column deflects enough under load for the axial force to act at an eccentricity of its own making, producing an <em>additional</em> moment which produces more deflection, which produces more moment. That feedback is what makes slenderness dangerous." },
            { k: "p", t: "Cl. 25.3.1 caps slenderness outright: the unsupported length between restraints must not exceed 60 times the least lateral dimension, and where one end is free, 100 b²/D. Beyond that no calculation is permitted to justify the column." },
          ],
        },

        {
          n: "8.4",
          title: "Minimum eccentricity",
          hi: "न्यूनतम विकेन्द्रता",
          blocks: [
            { k: "p", t: "Because a truly axial load does not exist, Cl. 25.4 requires every column to be designed for at least a minimum eccentricity:" },
            { k: "eq", expr: "emin = l/500 + D/30,   subject to a minimum of 20 mm", where: [
              ["l", "unsupported length of the column, mm"],
              ["D", "lateral dimension in the plane of bending, mm"],
            ]},
            { k: "p", t: "The first term allows for the column being out of plumb over its length, the second for the load not landing where the drawing says. This is checked <strong>about both axes separately</strong>, and for a rectangular column the minor axis is usually the one that binds, because b is smaller while l is the same." },
            { k: "note", t: "The simple axial formula of §8.5 is only permitted while emin does not exceed 0.05 D about either axis. Beyond that the column must be designed for the resulting moment — which, for a slim column, means an interaction check even when no external moment has been applied at all." },
          ],
        },

        {
          n: "8.5",
          title: "Short axially loaded columns",
          hi: "छोटे अक्षीय भारित कॉलम",
          blocks: [
            { k: "p", t: "For the one case where the eccentricity really is negligible, Cl. 39.3 gives a closed-form capacity — concrete and steel simply added:" },
            { k: "eq", expr: "Pu = 0.4 fck Ac + 0.67 fy Asc", where: [
              ["Ac", "area of concrete = gross area − Asc, mm²"],
              ["Asc", "area of longitudinal steel, mm²"],
            ]},
            { k: "p", t: "The coefficients are worth understanding rather than memorising. 0.446 fck was the design strength of concrete in flexure; here it is reduced further to 0.4 fck, which is roughly the stress at the strain the code assumes for a member in pure compression (0.002, not 0.0035). Similarly 0.87 fy becomes 0.67 fy, because at a strain of 0.002 an Fe 415 bar has not reached its design yield stress. The formula already carries the minimum eccentricity of 0.05 D inside those reduced coefficients — which is exactly why it may not be used when emin exceeds that value." },
            { k: "eq", expr: "Helically reinforced column (Cl. 39.4):  Pu = 1.05 × (0.4 fck Ac + 0.67 fy Asc)", where: [] },
            { k: "p", t: "The 5% bonus for a helix is not generosity. A closely wound spiral confines the core laterally, and confined concrete is both stronger and far more ductile than unconfined concrete. The same physics is what IS 13920 exploits with closely spaced ties in seismic design." },
            { k: "note", t: "<b>The bonus has to be earned (v34 addition):</b> the 1.05 factor applies only if the helix is heavy enough — Cl. 39.4.1 requires the volume of helical steel to be at least <b>0.36 (Ag/Ak − 1) fck/fy</b> times the volume of the core, where Ak is the area of the core measured to the outside of the helix — and closely enough pitched (between 25 and 75 mm) (<a href=\"https://engineeringhulk.com/civil/rcc-design/axially-loaded-column/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — axially loaded columns</a>). A circular column with ordinary circular ties gets no 5%." },
            { k: "eg",
              title: "Example 8.1 — Short axially loaded column",
              given: "450 × 450 column, unsupported length 3.0 m, effectively held in position and restrained against rotation at both ends. M25 concrete, Fe 415 steel, factored axial load Pu = 2500 kN.",
              steps: [
                { t: "Effective length and slenderness", w: "le = 0.65 × 3000 = 1950 mm\nle/D = 1950/450 = 4.33  <  12  →  SHORT about both axes  ✓" },
                { t: "Minimum eccentricity (Cl. 25.4)", w: "emin = 3000/500 + 450/30 = 6 + 15 = 21 mm  (> 20 mm minimum)\n0.05 D = 0.05 × 450 = 22.5 mm\n21 mm  <  22.5 mm  ✓ the Cl. 39.3 formula may be used" },
                { t: "Steel required (Cl. 39.3)", w: "Ag = 450 × 450 = 202,500 mm²\n2500 × 10³ = 0.4 × 25 × (202,500 − Asc) + 0.67 × 415 × Asc\n2,500,000 = 2,025,000 − 10 Asc + 278.05 Asc\nAsc = 475,000/268.05 = 1772 mm²" },
                { t: "Check against the limits (Cl. 26.5.3.1)", w: "p = 100 × 1772/202,500 = 0.875%\nMinimum 0.8% = 1620 mm²  ✓;  maximum 6%  ✓" },
                { t: "Choose bars", w: "6 bars of 20 mm = 1885 mm²  >  1772  ✓\nCapacity check: 0.4 × 25 × (202,500 − 1885) + 0.67 × 415 × 1885\n= 2,006,150 + 524,159 = 2530 kN  >  2500 kN  ✓" },
                { t: "Lateral ties (Cl. 26.5.3.2)", w: "Diameter ≥ ¼ × 20 = 5 mm, and not less than 6 mm  →  use 8 mm\nPitch ≤ least of: least lateral dimension = 450 mm\n                 16 × smallest longitudinal bar = 16 × 20 = 320 mm\n                 300 mm\n→ 300 mm" },
              ],
              ans: "450 × 450 column with 6 bars of 20 mm (p = 0.93%) and 8 mm lateral ties at 300 mm centres.",
            },
          ],
        },

        {
          n: "8.6",
          title: "The interaction diagram",
          hi: "इंटरैक्शन डायग्राम",
          blocks: [
            { k: "p", t: "Once there is a moment as well as an axial load, no single formula will do — and the reason is worth following carefully, because it explains the shape of every column chart in SP:16." },
            { k: "dia", id: "hb-rcc-interaction", cap: "Axial load against moment. Every point on the curve is a section that fails; every point inside it is safe." },
            { k: "p", t: "Fix the section, the grades and the steel. Now vary where the neutral axis sits and, for each position, compute the axial force and the moment the section can carry. Each xu gives one pair (Pu, Mu), and plotting them all traces a curve. Three points on it are worth naming:" },
            { k: "list", items: [
              "<strong>Pure axial (top)</strong> — the whole section in compression, no moment. Puz = 0.45 fck Ac + 0.75 fy Asc.",
              "<strong>The balanced point (the nose)</strong> — concrete reaching 0.0035 exactly as the tension steel reaches its yield strain. This is where the moment capacity is <em>greatest</em>.",
              "<strong>Pure bending (bottom)</strong> — no axial load; the section is simply a doubly reinforced beam, as in Chapter 4.",
            ]},
            { k: "h", t: "Why the curve leans out and then back" },
            { k: "p", t: "Below the balanced point the section fails in tension — the steel yields first. Adding axial compression there partly cancels the tension in the steel, so more moment is needed to yield it: the column gets <strong>stronger</strong> in bending as axial load increases. Above the balanced point the section fails in compression — the concrete crushes first. Adding axial load there brings the concrete closer to crushing, so less moment is available: the column gets <strong>weaker</strong>. The nose is exactly where the two mechanisms change places." },
            { k: "p", t: "Constructing such a curve by hand for one section takes an afternoon. SP:16 (Design Aids for IS 456) publishes them as non-dimensional charts, plotted as Pu/(fck b D) against Mu/(fck b D²) for families of p/fck and d′/D, which is why column design in practice is a matter of reading a chart rather than solving an equation." },
            { k: "trap", t: "Every chart is drawn for a particular d′/D and a particular bar arrangement — steel on two faces or distributed on all four. Reading a value off the wrong chart is easy and produces an answer that looks perfectly reasonable. Check the chart's heading before the chart's curve." },
          ],
        },

        {
          n: "8.7",
          title: "Biaxial bending",
          hi: "द्वि-अक्षीय बंकन",
          blocks: [
            { k: "p", t: "A corner column has beams framing into it from two directions and bends about both axes at once. The failure surface is now three-dimensional — an axial load and two moments — and Cl. 39.6 gives an interaction expression rather than asking for it to be computed:" },
            { k: "eq", expr: "(Mux / Mux1)^αn  +  (Muy / Muy1)^αn  ≤  1.0", where: [
              ["Mux1", "the moment capacity about the x axis with the same Pu acting and no moment about y"],
              ["Muy1", "the corresponding capacity about the y axis"],
              ["αn", "an exponent depending on how heavily the column is loaded axially"],
            ]},
            { k: "p", t: "Cl. 39.6 takes αn as 1.0 when Pu/Puz ≤ 0.2 and 2.0 when Pu/Puz ≥ 0.8, varying linearly between, where Puz = 0.45 fck Ac + 0.75 fy Asc." },
            { k: "p", t: "That variation has a physical reading. A lightly loaded column behaves almost like a beam bending about a skewed axis, and the two capacities simply share out linearly — αn = 1 is a straight line between the axes. A heavily loaded column is closer to pure compression, where the two directions interfere much less, and αn = 2 gives a bulging quarter-circle that permits more." },
            { k: "note", t: "The procedure is therefore: assume a section and steel, find Mux1 and Muy1 from the SP:16 charts for the actual Pu, compute Puz, get αn, and check the inequality. If it fails, increase the steel and repeat. Biaxial column design is inherently iterative — there is no way to solve directly for the steel." },
          ],
        },

        {
          n: "8.8",
          title: "Slender columns",
          hi: "स्लेंडर कॉलम",
          blocks: [
            { k: "p", t: "When lex/D or ley/b reaches 12, the sideways deflection of the column adds moment that the frame analysis never saw. Cl. 39.7.1 accounts for it with additional moments derived from the slenderness:" },
            { k: "eq", expr: "Max = Pu D (lex/D)² / 2000        May = Pu b (ley/b)² / 2000", where: [
              ["Max", "additional moment about the major axis, N·mm"],
              ["May", "additional moment about the minor axis, N·mm"],
            ]},
            { k: "p", t: "These are added to the moments from the analysis, and the column is then designed for the total — usually as a biaxial problem, because a slender column rarely has slenderness about only one axis." },
            { k: "eg",
              title: "Example 8.2 — How much slenderness costs",
              given: "300 × 400 column carrying Pu = 1200 kN. Effective length about the major axis lex = 5200 mm, D = 400 mm.",
              steps: [
                { t: "Is it slender?", w: "lex/D = 5200/400 = 13  >  12  →  SLENDER about the major axis" },
                { t: "Additional moment (Cl. 39.7.1)", w: "Max = Pu D (lex/D)²/2000\n    = 1200 × 10³ × 400 × 13²/2000\n    = 1200 × 10³ × 400 × 169/2000\n    = 40.56 × 10⁶ N·mm = 40.56 kNm" },
              ],
              ans: "A moment of 40.6 kNm appears from slenderness alone, before any load has been applied eccentrically. A column just over the slenderness limit is not marginally worse than a short one — it has acquired a significant moment out of nothing.",
            },
            { k: "p", t: "Cl. 39.7.1.1 allows the additional moment to be reduced by a factor k = (Puz − Pu)/(Puz − Pub), not greater than 1, where Pub is the axial capacity at the balanced point. The reason is that the additional moment is largest when the column is on the point of buckling, and a column carrying much less than its balanced load is not close to that state." },
          ],
        },

        {
          n: "8.9",
          title: "Detailing",
          hi: "डिटेलिंग",
          blocks: [
            { k: "h", t: "Longitudinal steel (Cl. 26.5.3.1)" },
            { k: "list", items: [
              "Minimum <strong>0.8%</strong> of the gross area; maximum <strong>6%</strong>, and 4% is the practical maximum wherever bars are lapped.",
              "At least <strong>four</strong> bars in a rectangular column and <strong>six</strong> in a circular one.",
              "Minimum bar diameter <strong>12 mm</strong>.",
              "Spacing of longitudinal bars along the perimeter not more than 300 mm.",
            ]},
            { k: "p", t: "The minimum of 0.8% is there because of creep. Concrete under sustained compression shortens with time, and as it does, load transfers from the concrete onto the steel — so a column with too little steel sees its steel stress climb for years after construction. The maximum is about congestion and about lap splices, which in a column are placed just above floor level where the moment is least." },
            { k: "h", t: "Lateral ties (Cl. 26.5.3.2)" },
            { k: "dia", id: "hb-rcc-ties", cap: "Ties exist to stop the longitudinal bars from buckling outwards and to confine the core." },
            { k: "list", items: [
              "Tie diameter: at least one-quarter of the largest longitudinal bar, and not less than 6 mm.",
              "Pitch: the least of the least lateral dimension, 16 times the smallest longitudinal bar diameter, and 300 mm.",
              "Every corner bar and every alternate bar must be supported by the corner of a tie or by a cross tie; no unsupported bar may be more than 75 mm from a supported one.",
              "Where the longitudinal bars are in compression, the same 16φ pitch rule protects them from buckling — this is the rule Chapter 4 invoked for doubly reinforced beams.",
            ]},
            { k: "trap", t: "The 16φ pitch uses the diameter of the <strong>smallest</strong> longitudinal bar, because it is the slenderest bar that buckles first. Using the largest — the more natural reading — gives a wider pitch and leaves the very bar the rule is protecting unprotected." },
          ],
        },

        {
          n: "8.10",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Effective length from Cl. 25.2 and Table 28 — restraint matters more than size.",
              "Short if lex/D and ley/b are both below 12 (Cl. 25.1.2).",
              "emin = l/500 + D/30, at least 20 mm, checked about both axes (Cl. 25.4).",
              "Pu = 0.4 fck Ac + 0.67 fy Asc — only while emin ≤ 0.05 D (Cl. 39.3).",
              "Otherwise the check is a point against an interaction curve, read from SP:16.",
              "Biaxial: (Mux/Mux1)^αn + (Muy/Muy1)^αn ≤ 1 (Cl. 39.6).",
              "Slender: add Max = Pu D(lex/D)²/2000 (Cl. 39.7.1).",
              "Steel 0.8% to 6%, four bars minimum, 12 mm minimum; ties at the least of b, 16φ and 300 mm.",
            ]},
            { k: "p", t: "Chapter 9 takes the load that has now arrived at the bottom of this column and spreads it into the ground — where the material carrying it is no longer something we specify and test, but whatever happens to be there." },
          ],
        },
      ],
    }

  );
})();
