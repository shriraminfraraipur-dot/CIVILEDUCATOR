/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 1.
   ------------------------------------------------------------
   Same conventions as the other handbook diagram files: strokes
   are currentColor so both themes work, meaning-carrying strokes
   use .hi (marker) or .ac (accent), and every figure gets its own
   marker-id prefix so two figures on one page never collide.
   Strain axes are deliberately NOT to scale — the elastic zone of
   mild steel is ~0.1% strain while fracture is ~20–25%, so a true-
   scale plot would squash the whole elastic zone into one pixel.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function somMk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 1.5  MILD STEEL CURVE */
  "hb-som-ss-mild": {
    label: "Stress-strain curve of mild steel in tension (points A–G)",
    svg: `<svg viewBox="0 0 640 390" role="img" aria-label="Engineering stress-strain curve of mild steel, strain axis not to scale. From the origin O the curve rises as a straight line to A, the proportional limit, then bends slightly to B, the elastic limit. It reaches C, the upper yield point, drops to D, the lower yield point, and runs roughly flat and wavy to E — the yield plateau. From E it rises again through the strain-hardening zone to the peak F, the ultimate stress. After F the engineering curve falls to G, the fracture point, because the bar necks; a dashed true-stress curve continues rising from F to fracture, because true stress uses the shrinking necked area. Bands along the bottom mark the elastic zone O to B, yielding C to E, strain hardening E to F and necking F to G.">
      ${somMk("sm1")}
      <!-- axes -->
      <line class="s" x1="60" y1="320" x2="610" y2="320" marker-end="url(#sm1-a)"/>
      <line class="s" x1="60" y1="320" x2="60" y2="24" marker-end="url(#sm1-a)"/>
      <text x="606" y="340" text-anchor="end">Strain ε (not to scale)</text>
      <text x="70" y="30">Stress σ</text>
      <text class="lb" x="48" y="334" text-anchor="end">O</text>

      <!-- engineering curve -->
      <path class="hi" d="M60 320 L110 170 Q116 156 120 150 L130 128 L140 160 L160 155 L180 161 L200 155 L220 161 L240 155 L260 158 C320 110 380 74 430 70 C480 70 530 96 560 122"/>
      <!-- true stress curve after necking -->
      <path class="ac dash" d="M430 70 C480 60 530 46 560 38" style="stroke:var(--accent)"/>
      <text class="ea" x="566" y="36">true σ</text>
      <text class="em" x="566" y="128">engg σ</text>

      <!-- points -->
      <circle class="hif" cx="110" cy="170" r="3.5"/><text x="96" y="168" text-anchor="end">A</text>
      <circle class="hif" cx="120" cy="150" r="3.5"/><text x="106" y="148" text-anchor="end">B</text>
      <circle class="hif" cx="130" cy="128" r="3.5"/><text x="130" y="118" text-anchor="middle">C</text>
      <circle class="hif" cx="140" cy="160" r="3.5"/><text x="144" y="178">D</text>
      <circle class="hif" cx="260" cy="158" r="3.5"/><text x="262" y="176">E</text>
      <circle class="hif" cx="430" cy="70" r="3.5"/><text x="430" y="58" text-anchor="middle">F</text>
      <circle class="hif" cx="560" cy="122" r="3.5"/><text x="560" y="144" text-anchor="middle">G</text>

      <!-- legend of points -->
      <text class="lb" x="300" y="208">A proportional limit · B elastic limit</text>
      <text class="lb" x="300" y="224">C upper yield · D lower yield</text>
      <text class="lb" x="300" y="240">E start of strain hardening</text>
      <text class="lb" x="300" y="256">F ultimate stress · G fracture</text>

      <!-- zone bands -->
      <line class="thin" x1="60" y1="356" x2="120" y2="356"/><text class="lb" x="90" y="372" text-anchor="middle">elastic</text>
      <line class="thin" x1="128" y1="356" x2="260" y2="356"/><text class="lb" x="194" y="372" text-anchor="middle">yielding</text>
      <line class="thin" x1="268" y1="356" x2="430" y2="356"/><text class="lb" x="349" y="372" text-anchor="middle">strain hardening</text>
      <line class="thin" x1="438" y1="356" x2="560" y2="356"/><text class="lb" x="499" y="372" text-anchor="middle">necking</text>
      <line class="dash" x1="120" y1="150" x2="120" y2="356"/>
      <line class="dash" x1="260" y1="176" x2="260" y2="356"/>
      <line class="dash" x1="430" y1="76" x2="430" y2="356"/>
    </svg>`,
    caption: "Engineering stress-strain curve of mild steel (strain axis not to scale). After F the engineering curve drops only because it keeps dividing by the original area; true stress keeps rising until fracture.",
  },

  /* ---------------------------------------- 1.5  HYSD / BRITTLE + OFFSET */
  "hb-som-ss-proof": {
    label: "No-yield-point steel (0.2% proof stress) vs a brittle material",
    svg: `<svg viewBox="0 0 640 360" role="img" aria-label="Two stress-strain curves on one set of axes. The high-strength deformed (TMT) steel curve rises straight, then bends over smoothly with no sharp yield point and continues to a rounded peak before fracture. Because there is no yield point, a dashed line is drawn parallel to the straight elastic part, starting at 0.002 strain (0.2 percent) on the strain axis; where it cuts the curve is the 0.2 percent proof stress, used as the yield stress. A second, short curve for a brittle material such as cast iron rises with slight curvature and ends abruptly in fracture at small strain, with no yielding and no necking.">
      ${somMk("sm2")}
      <line class="s" x1="60" y1="310" x2="610" y2="310" marker-end="url(#sm2-a)"/>
      <line class="s" x1="60" y1="310" x2="60" y2="24" marker-end="url(#sm2-a)"/>
      <text x="606" y="330" text-anchor="end">Strain ε (not to scale)</text>
      <text x="70" y="30">Stress σ</text>

      <!-- HYSD curve -->
      <path class="hi" d="M60 310 L130 110 C150 85 200 66 300 56 C380 52 440 60 480 80"/>
      <circle class="hif" cx="480" cy="80" r="3.5"/>
      <text class="em" x="486" y="96">HYSD / TMT steel</text>
      <text class="lb" x="486" y="111">(fracture)</text>

      <!-- offset line -->
      <line class="dash" x1="80" y1="310" x2="161" y2="79" style="stroke:var(--accent)"/>
      <circle class="acf" cx="157" cy="90" r="4"/>
      <line class="thin" x1="157" y1="90" x2="60" y2="90"/>
      <text class="ea" x="64" y="84">f0.2</text>
      <text class="ea" x="172" y="148">offset line ∥ elastic part</text>
      <line class="thin" x1="60" y1="318" x2="60" y2="326"/><line class="thin" x1="80" y1="318" x2="80" y2="326"/>
      <text class="ea" x="70" y="342" text-anchor="middle">0.002</text>

      <!-- brittle -->
      <path class="ac" d="M60 310 C90 236 112 196 128 176"/>
      <line class="ac" x1="121" y1="169" x2="135" y2="183"/><line class="ac" x1="135" y1="169" x2="121" y2="183"/>
      <text class="ea" x="200" y="230">Brittle (cast iron):</text>
      <text class="lb" x="200" y="246">fracture near peak, tiny strain,</text>
      <text class="lb" x="200" y="262">no yield, no neck</text>
    </svg>`,
    caption: "When there is no clear yield point (HYSD/TMT bars, aluminium), the 0.2% offset line — drawn parallel to the elastic part from ε = 0.002 — gives the proof stress f0.2, which codes treat as fy. A brittle material simply breaks near its peak.",
  },

  /* ---------------------------------------- 1.3  SINGLE vs DOUBLE SHEAR */
  "hb-som-shear": {
    label: "Bolt in single shear vs double shear",
    svg: `<svg viewBox="0 0 640 250" role="img" aria-label="Left: a lap joint — two plates overlap and one bolt passes through both. The top plate is pulled left with force P and the bottom plate right with force P. The bolt is cut along one plane, at the interface of the plates, so it is in single shear. Right: a butt joint with two cover plates — a main plate in the middle is pulled right with P, and a cover plate above and below it are each pulled left with P/2. The bolt is cut along two planes, one at each interface, so it is in double shear and each plane carries P/2.">
      ${somMk("sm3")}
      <!-- single shear -->
      <rect class="conc" x="40" y="90" width="180" height="20"/>
      <rect class="conc" x="120" y="110" width="180" height="20"/>
      <rect class="steel" x="162" y="76" width="16" height="68" opacity=".75"/>
      <line class="hi" x1="150" y1="110" x2="190" y2="110"/>
      <line class="s" x1="40" y1="100" x2="10" y2="100" marker-end="url(#sm3-a)"/>
      <text x="14" y="90">P</text>
      <line class="s" x1="300" y1="120" x2="330" y2="120" marker-end="url(#sm3-a)"/>
      <text x="318" y="110">P</text>
      <text class="em" x="170" y="172" text-anchor="middle">Single shear — 1 plane</text>
      <text class="lb" x="170" y="190" text-anchor="middle">τ = P / (πd²/4)</text>

      <!-- double shear -->
      <rect class="conc" x="380" y="80" width="170" height="15"/>
      <rect class="conc" x="440" y="95" width="170" height="20"/>
      <rect class="conc" x="380" y="115" width="170" height="15"/>
      <rect class="steel" x="482" y="66" width="16" height="78" opacity=".75"/>
      <line class="hi" x1="470" y1="95" x2="510" y2="95"/>
      <line class="hi" x1="470" y1="115" x2="510" y2="115"/>
      <line class="s" x1="610" y1="105" x2="634" y2="105" marker-end="url(#sm3-a)"/>
      <text x="616" y="96">P</text>
      <line class="s" x1="380" y1="87" x2="352" y2="87" marker-end="url(#sm3-a)"/>
      <line class="s" x1="380" y1="123" x2="352" y2="123" marker-end="url(#sm3-a)"/>
      <text x="340" y="80">P/2</text>
      <text x="340" y="142">P/2</text>
      <text class="em" x="495" y="172" text-anchor="middle">Double shear — 2 planes</text>
      <text class="lb" x="495" y="190" text-anchor="middle">τ = P / (2 · πd²/4)</text>
      <text class="lb" x="320" y="230" text-anchor="middle">Highlighted lines = shear planes cutting the bolt</text>
    </svg>`,
    caption: "Count the shear planes the bolt is cut across: one in a lap joint (single shear), two in a butt joint with two cover plates (double shear) — each plane then carries only P/2.",
  },
});
