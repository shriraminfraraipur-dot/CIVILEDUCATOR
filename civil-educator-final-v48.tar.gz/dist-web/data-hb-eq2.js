/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: EARTHQUAKE ENGINEERING · Ch 3–5
   Base shear & period · Drift, irregularity & separation ·
   Load combinations & dynamic analysis
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "eq");
  if (!hb) { console.error("[eq2] handbook eq not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "eq-3",
      n: 3,
      title: "Design Base Shear and Natural Period",
      hi: "डिज़ाइन बेस शियर और प्राकृतिक अवधि",
      blurb: "The formula that turns the hazard into a force, factor by factor, and a worked base shear from zone, weight and period.",
      mins: 32,
      sections: [
        {
          n: "3.1",
          title: "The base shear, factor by factor",
          hi: "बेस शियर — कारक दर कारक",
          blocks: [
            { k: "p", t: "The design base shear is the total horizontal earthquake force the building is designed for, applied at its base and distributed up its height. It looks like a formula to memorise, but every factor is a plain question with a code answer." },
            { k: "dia", id: "hb-eq-baseshear", cap: "The base shear formula and what each factor asks." },
            { k: "eq", expr: "Vb = Ah × W,   where   Ah = (Z/2) × (I/R) × (Sa/g)", where: [
              ["Vb", "design base shear — the total horizontal force"],
              ["W", "seismic weight (dead load + part of live load)"],
              ["Z", "zone factor — severity of the local hazard"],
              ["I", "importance factor — 1.5 critical and lifeline buildings, 1.2 for the intermediate category, 1.0 for the rest (IS 1893:2016 Table 8)"],
              ["R", "response reduction factor — reward for ductility (it divides)"],
              ["Sa/g", "spectral acceleration at the period T, for the soil"],
            ] },
            { k: "trap", t: "R divides, which surprises people: a higher R gives a smaller design force. It is the code's reward for ductility — a well-detailed ductile frame (high R) is allowed to be designed for a fraction of the force an elastic analysis would demand, because it can bend and absorb energy instead of breaking. But that R is a promise you must keep in the detailing (Chapter 7); take the low force and skip the detailing, and the building is dangerously under-designed." },
          ],
        },
        {
          n: "3.2",
          title: "A worked base shear",
          hi: "एक हल किया गया बेस शियर",
          blocks: [
            { k: "p", t: "Putting the factors together turns the hazard into a number you can design for." },
            { k: "eg", title: "Example 3.1 — Base shear of an RC frame building",
              given: "A special moment-resisting RC frame, 15 m tall, seismic weight W = 10 000 kN, in Zone IV (Z = 0.24), ordinary occupancy (I = 1.0), R = 5, on medium (Type II) soil. Find the design base shear. Use T = 0.075·h^0.75 and the medium-soil spectrum.",
              steps: [
                { t: "Natural period", w: "T = 0.075 × 15^0.75 = 0.075 × 7.62 = 0.572 s" },
                { t: "Spectral acceleration (medium soil)", w: "for 0.55 ≤ T ≤ 4.0: Sa/g = 1.36 / T\n = 1.36 / 0.572 = 2.379" },
                { t: "Seismic coefficient", w: "Ah = (Z/2)(I/R)(Sa/g)\n   = (0.24/2)(1.0/5)(2.379)\n   = 0.12 × 0.2 × 2.379 = 0.0571" },
                { t: "Base shear", w: "Vb = Ah × W = 0.0571 × 10 000 = 571 kN" },
              ],
              ans: "A design base shear of about 571 kN — roughly 5.7% of the building's weight, applied horizontally. Note where the numbers came from: Z and the soil curve from IS 1893, R from the frame type, T from the height formula. Change the zone, the soil, or the ductility and this force moves — but every step is traceable to the code, none invented." },
            { k: "note", t: "<b>Sources disagree on the importance factor list.</b> <a href=\"https://help.autodesk.com/cloudhelp/2027/ENU/RSAPRO-UsersGuide/files/GUID-1DFE3234-1AF0-4A7D-8744-C91C323C827E.htm\" target=\"_blank\" rel=\"noopener\">Autodesk Robot's IS 1893:2016 documentation</a> gives three values (1.5 critical/lifeline, 1.2 business-continuity, 1.0 rest); the <a href=\"https://infralens.in/knowledge/is-1893-earthquake-design-india-2016-step-by-step\" target=\"_blank\" rel=\"noopener\">InfraLens step-by-step summary</a> lists only 1.5 and 1.0. IS 1893:2016 Table 8 introduced the 1.2 category — read its wording for the building in hand. Seismic weight W = full dead load + 25% of imposed load up to 3 kN/m² (50% above that), with no imposed load at the roof (same summary)." },
            { k: "eq", expr: "vertical distribution:   Qi = Vb × Wi hi² / Σ(Wj hj²)", where: [
              ["Wi, hi", "seismic weight of floor i and its height above the base"],
            ]},
            { k: "eg", title: "Example 3.2 — Distributing the base shear",
              given: "The building of Example 3.1: five storeys of 3.0 m, each floor W = 2000 kN, Vb = 571 kN.",
              steps: [
                { t: "Σ Wj hj²", w: "2000 × (3² + 6² + 9² + 12² + 15²) = 2000 × 495 = 990,000" },
                { t: "Floor forces", w: "level 1 (3 m):  571 × 18,000/990,000 = 10.4 kN\nlevel 2 (6 m):  41.5 kN\nlevel 3 (9 m):  93.4 kN\nlevel 4 (12 m): 166.1 kN\nroof (15 m):    259.5 kN\nΣ = 571.0 kN  ✓" },
              ],
              ans: "Almost half the force (45%) is applied at the roof. That is why roof tanks and heavy top storeys are so damaging, and why the storey shear grows rapidly towards the base." },
            { k: "note", t: "The base shear is then distributed up the building's height — more to the upper floors, because (as Chapter 1 showed) the sway and hence the force grow with height. Each floor's share is used to analyse the frame for the earthquake case, alongside gravity loads." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "eq-4",
      n: 4,
      title: "Drift, Irregularity and Separation",
      hi: "ड्रिफ्ट, अनियमितता और पृथक्करण",
      blurb: "Why limiting sway matters as much as strength, the irregularities that concentrate damage, and why buildings need a gap between them.",
      mins: 22,
      sections: [
        {
          n: "4.1",
          title: "Drift — limiting the sway",
          hi: "ड्रिफ्ट",
          blocks: [
            { k: "p", t: "A building can be strong enough not to break yet still sway so much that it damages its own walls, finishes and services — or pounds its neighbour, or simply frightens people into unsafe evacuation. So the code limits storey drift: how far one floor moves sideways relative to the one below." },
            { k: "def", term: "Storey drift", t: "The horizontal displacement of one floor relative to the floor immediately below it, under the earthquake load. IS 1893 limits it to 0.004 times the storey height — so for a 3.5 m storey the drift must not exceed about 14 mm — to protect the infill walls, cladding and services from tearing apart even when the frame itself is safe." },
            { k: "eg", title: "Example 4.1 — Checking a drift",
              given: "Analysis under the design earthquake gives lateral displacements of 18.0 mm at the 3rd floor and 31.5 mm at the 4th floor; storey height 3.5 m.",
              steps: [
                { t: "Storey drift", w: "31.5 − 18.0 = 13.5 mm" },
                { t: "Limit", w: "0.004 × 3500 = 14.0 mm" },
              ],
              ans: "13.5 ≤ 14.0 mm — passes, with almost no margin. Stiffen the frame (deeper beams, larger columns or a wall) rather than strengthen it: drift is a stiffness check." },
            { k: "p", t: "Drift is a stiffness check, not a strength check, and the two are different. A frame can pass its strength design (the members don't fail) and still fail the drift limit (it sways too much), because slender flexible columns are strong but not stiff. Meeting drift often means bigger columns or shear walls — added stiffness, not added strength." },
            { k: "trap", t: "Non-structural damage from excessive drift is what makes a building unusable after a moderate quake even when the frame is intact: shattered infill walls, snapped pipes, jammed doors, fallen cladding. The frame 'survived', but the building cannot be occupied. Controlling drift is what keeps a building not just standing but usable — a large part of the economic loss in earthquakes is drift damage, not collapse." },
          ],
        },
        {
          n: "4.2",
          title: "Irregularity and the soft storey",
          hi: "अनियमितता और सॉफ्ट स्टोरी",
          blocks: [
            { k: "p", t: "Earthquakes find the weak spot. A building that is regular — even in plan, uniform up its height — spreads the demand evenly. A building with an irregularity concentrates the damage at the irregularity, and some irregularities are lethal." },
            { k: "dia", id: "hb-eq-softstorey", cap: "The open ground storey, and why the sway concentrates there." },
            { k: "def", term: "Soft / weak storey", t: "A storey much more flexible (soft) or much weaker than the one above — most commonly an open ground storey (stilt parking) beneath wall-filled upper floors. The earthquake sway concentrates in this one storey and its columns are overwhelmed. It is one of the commonest causes of collapse, and IS 1893 requires the storey to be specially strengthened. A storey is <strong>soft</strong> if its lateral stiffness is less than 70% of the storey above or less than 80% of the average of the three above, and <strong>extremely soft</strong> below 60% / 70% (criteria as implemented in <a href=\"https://docs.bentley.com/LiveContent/web/STAAD.Pro%20Help-v21/en/STD_CHECK_SOFT_STORY.html\" target=\"_blank\" rel=\"noopener\">STAAD.Pro documentation</a>)." },
            { k: "list", items: [
              "<strong>Vertical irregularity</strong> — a soft/weak storey, a setback, a heavy mass high up. Damage concentrates at the discontinuity.",
              "<strong>Plan irregularity</strong> — an L, T or U shape, or an off-centre stiffness, which twists the building in plan (torsion) and overloads one side.",
              "<strong>The remedy</strong> — prefer regular, symmetric, uniform buildings; where irregularity is unavoidable, the code demands dynamic analysis and extra strength at the trouble spot.",
            ] },
            { k: "real", t: "The open-ground-storey collapse is depressingly common in Indian cities, where apartments over stilt parking are everywhere. In moderate quakes, dozens of such buildings have dropped their upper floors straight down onto the parking level while identical-looking regular buildings nearby merely cracked. <strong>The irregularity, not the shaking, is what decided which ones fell.</strong>" },
          ],
        },
        {
          n: "4.3",
          title: "Separation — room to sway",
          hi: "पृथक्करण",
          blocks: [
            { k: "p", t: "Two buildings, or two wings of one building, that sway toward each other in a quake will collide — 'pounding' — hammering each other at floor levels, often with one building's floor slab striking the other's columns mid-height, which is especially destructive. The remedy is simply a gap." },
            { k: "def", term: "Separation gap", t: "A clear gap left between adjacent buildings (or blocks of one building separated by an expansion joint) so each can sway to its design drift without touching the other. The gap must be large enough for the sum of the two buildings' movements — bigger for taller, more flexible buildings." },
            { k: "trap", t: "Pounding is worst when the two buildings have different heights or periods, so they sway out of step and one's floor slab slams into the other's column at mid-height — a column hit side-on at an unbraced point, which can shear it. Matching floor levels and leaving an adequate gap both matter. A too-small gap between neighbours is a hidden hazard invisible until the ground moves." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "eq-5",
      n: 5,
      title: "Load Combinations and Dynamic Analysis",
      hi: "भार संयोजन और गतिक विश्लेषण",
      blurb: "How the earthquake case combines with gravity, why it acts both ways, and when a simple static force will not do.",
      mins: 20,
      sections: [
        {
          n: "5.1",
          title: "Combining earthquake with gravity",
          hi: "भूकंप और गुरुत्व का संयोजन",
          blocks: [
            { k: "p", t: "The earthquake force does not act alone — it acts on a building already carrying its dead and live loads. And crucially it reverses: the ground shakes back and forth, so the earthquake force acts first one way, then the other, many times. The design must cover the worst combination of gravity and earthquake, in both directions." },
            { k: "def", term: "Load combinations", t: "The code-specified mixes of dead (DL), live (LL) and earthquake (EL) loads that the structure must be checked against — including combinations with earthquake added to and subtracted from gravity (e.g. 1.2(DL+LL±EL), 1.5(DL±EL), and 0.9DL±1.5EL). The ± is essential: the reversing force finds different worst cases in different members." },
            { k: "trap", t: "The 0.9DL ± 1.5EL combination catches a case beginners miss: with the dead load reduced (0.9) and the earthquake at full strength, a column or footing that is always in compression under gravity can go into net tension or uplift. A footing designed only for downward load can be lifted; an anchor never checked for tension can pull out. The reversing quake, combined with reduced gravity, is what exposes it." },
            { k: "eg", title: "Example 5.1 — Which combination governs a column?",
              given: "Axial forces in a corner column: dead load 800 kN, imposed 300 kN, earthquake ±600 kN.",
              steps: [
                { t: "1.2(DL + IL ± EL)", w: "1.2(800 + 300 + 600) = 2040 kN;  1.2(800 + 300 − 600) = 600 kN" },
                { t: "1.5(DL ± EL)", w: "1.5(800 + 600) = 2100 kN;  1.5(800 − 600) = 300 kN" },
                { t: "0.9 DL ± 1.5 EL", w: "0.9 × 800 + 1.5 × 600 = 1620 kN;  0.9 × 800 − 1.5 × 600 = −180 kN (tension)" },
              ],
              ans: "Maximum compression 2100 kN from 1.5(DL + EL) — but 0.9 DL − 1.5 EL puts the column and its footing into 180 kN of tension. Splices, footing and anchorage must be checked for uplift, which no gravity combination would reveal." },
          ],
        },
        {
          n: "5.2",
          title: "When a static force is not enough",
          hi: "स्थैतिक बल कब पर्याप्त नहीं",
          blocks: [
            { k: "p", t: "The base-shear method of Chapter 3 treats the earthquake as a single equivalent static force distributed up the height. That is fine for regular, not-too-tall buildings, whose motion is dominated by their first mode of sway. For taller or irregular buildings, it is not enough, and a dynamic analysis is required." },
            { k: "cmp", t: "Equivalent static vs dynamic analysis",
              cols: ["Equivalent static", "Dynamic (response spectrum / time history)"],
              rows: [
                ["Treats quake as", "one static force up the height", "the sum of the building's modes of vibration"],
                ["Good for", "regular, low/medium-rise buildings", "tall, irregular, or important buildings"],
                ["Captures", "the first sway mode only", "higher modes, torsion, real distribution"],
                ["Effort", "a hand calculation", "computer modal analysis"],
              ] },
            { k: "def", term: "Response spectrum analysis", t: "A dynamic method that finds the building's several modes of vibration (its different ways of swaying), reads the spectral acceleration for each mode's period, and combines the modal responses. It captures higher modes and torsion that the single static force misses — which matter more the taller and more irregular the building." },
            { k: "note", t: "The code sets the threshold: below a certain height and for regular buildings, the equivalent static method is allowed; above it, or for any significant irregularity, dynamic analysis is mandatory. The reason is physical — a tall or irregular building's motion is not captured by one sway mode, so a single static force in the shape of that mode misrepresents where the forces really go." },
          ],
        },
      ],
    },

  );
})();
