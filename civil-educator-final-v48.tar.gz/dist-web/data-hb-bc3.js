/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING CONSTRUCTION · Ch 6–8
   Seismic bands · Building components (doors, windows, roofs, stairs)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bc");
  if (!hb) { console.error("[bc3] handbook bc not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "bc-6",
      n: 6,
      title: "Seismic Bands in Masonry Buildings",
      hi: "चिनाई भवनों में भूकंप बैंड",
      blurb: "Why unreinforced masonry is so deadly in an earthquake, and how a set of cheap horizontal bands turns loose walls into one strong box.",
      mins: 30,
      sections: [
        {
          n: "6.1",
          title: "Why masonry is dangerous in a quake",
          hi: "भूकंप में चिनाई ख़तरनाक क्यों",
          blocks: [
            { k: "p", t: "Unreinforced masonry is the building type that kills the most people in earthquakes, and the reason is a property from the very first chapter of materials: brick is strong in compression but has almost no strength in tension. An earthquake shakes the building side to side, which puts the walls into tension and bending — exactly what masonry cannot take." },
            { k: "dia", id: "hb-bc-bands", cap: "Seismic bands tying the walls of a masonry house into one box." },
            { k: "p", t: "The failure is specific and predictable. Shaking pulls the walls apart at the corners, where two walls meet, because there is nothing there in tension to hold them together. Once a corner opens, the walls fall outward independently and the roof drops. It happens in seconds, and it is why so many masonry buildings collapse completely rather than merely crack." },
            { k: "trap", t: "A masonry building can be perfectly sound for gravity loads — walls plumb, mortar strong, foundation good — and still be a death trap in a quake, because vertical strength and lateral (seismic) resistance are different things. Carrying the roof straight down is easy for masonry; resisting sideways shaking is what it cannot do unaided. The two must not be confused." },
          ],
        },
        {
          n: "6.2",
          title: "The bands — turning walls into a box",
          hi: "बैंड — दीवारों को डिब्बा बनाना",
          blocks: [
            { k: "p", t: "The remedy is elegant and cheap: run continuous horizontal reinforced-concrete bands right around the building at key levels, tying all the walls together so they act as one closed box instead of four separate panels. The steel in the bands provides the tension strength the masonry lacks." },
            { k: "cmp", t: "The seismic bands (IS 4326)",
              cols: ["Where and why"],
              rows: [
                ["Plinth band", "at plinth level — ties the base, spans soft soil patches"],
                ["Sill band", "at window-sill level — with the lintel band, protects the corners of openings (EQ Tip 15)"],
                ["Lintel band", "over all openings — the most important, ties walls at opening level"],
                ["Roof/gable band", "at roof/eaves — ties the tops of the walls before the roof; gable band along the sloping top of gable walls"],
              ] },
            { k: "list", items: [
              "<strong>The lintel band is the most important</strong> and is needed in almost all buildings: it ties the walls together at opening level and reduces their unsupported height (<a href=\"https://ddma.delhi.gov.in/sites/default/files/ddma/EQT/eqtip14.pdf\" target=\"_blank\" rel=\"noopener\">Earthquake Tip 14</a>).",
              "<strong>RC band, minimum</strong> (IS 4326:1993 as summarised in Tip 14) — 75 mm thick, at least two 8 mm bars, tied with 6 mm links at 150 mm centres.",
              "<strong>Wooden band</strong> (same source) — runners at least 75 × 38 mm with spacers at least 50 × 30 mm, for places where concrete is not practicable.",
              "<strong>Openings</strong> — keep them small and well away from corners; openings too close to a corner interrupt the flow of force from one wall to the next (<a href=\"https://ddma.delhi.gov.in/sites/default/files/ddma/EQT/eqtip13.pdf\" target=\"_blank\" rel=\"noopener\">IIT Kanpur–BMTPC Earthquake Tip 13</a>). Steel round the openings, with lintel and sill bands above and below them, restricts the diagonal cracks that start at their corners (<a href=\"https://nicee.org/ebook/EQTips_Eng/files/basic-html/page31.html\" target=\"_blank\" rel=\"noopener\">NICEE EQ Tips</a>).",
              "<strong>Vertical bars</strong> at corners and wall junctions, anchored in the foundation and in the roof band, make slender piers bend instead of rocking and delay X-cracking (<a href=\"https://ddma.delhi.gov.in/sites/default/files/ddma/EQT/eqtip15.pdf\" target=\"_blank\" rel=\"noopener\">Earthquake Tip 15</a>).",
            ] },
            { k: "eg", title: "Example 6.1 — What a lintel band costs",
              given: "A single-room masonry building 6.0 m × 4.0 m (centre-line dimensions) with 230 mm walls. Minimum RC lintel band: 75 mm thick, 2 bars of 8 mm, 6 mm links at 150 mm.",
              steps: [
                { t: "Band length", w: "centre-line perimeter = 2 × (6.0 + 4.0) = 20.0 m" },
                { t: "Concrete", w: "20.0 × 0.23 × 0.075 = 0.345 m³" },
                { t: "Longitudinal steel", w: "2 × 20.0 m × 0.395 kg/m = 15.8 kg (plus laps and corner anchorage)" },
                { t: "Links", w: "20.0/0.15 = 134 links; each about 0.55 m of 6 mm bar (0.222 kg/m)\n134 × 0.55 × 0.222 = 16.4 kg" },
              ],
              ans: "About a third of a cubic metre of concrete and roughly 32 kg of steel for the whole room — a trivial fraction of the building's cost for the single most effective life-safety detail it can have." },
            { k: "p", t: "The bands must be continuous — running unbroken around the entire perimeter and across internal walls — because a band with a gap is a chain with a missing link. Vertical reinforcing bars at the corners and around openings complete the cage, tying the horizontal bands together top to bottom so the whole building is wrapped." },
            { k: "real", t: "The difference the bands make is stark and proven in every major earthquake: banded and confined masonry buildings crack but stay standing, giving people time to get out, while identical unbanded buildings next door collapse into rubble. <strong>The bands cost a small fraction of the building and are the single most cost-effective life-safety measure in masonry construction.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "bc-7",
      n: 7,
      title: "Doors, Windows and Roofs",
      hi: "दरवाज़े, खिड़कियाँ और छत",
      blurb: "How openings are framed and spanned, and the two families of roof — the pitched roof that sheds water by slope and the flat roof that must be made watertight.",
      mins: 30,
      sections: [
        {
          n: "7.1",
          title: "Openings — framed and spanned",
          hi: "द्वार — फ़्रेम और स्पैन",
          blocks: [
            { k: "p", t: "Every door and window is a deliberate hole in a load-bearing wall, and two things must be handled: the wall above the hole must be carried, and the shutter (the door or window itself) must be held in a frame." },
            { k: "def", term: "Lintel vs arch", t: "The wall above an opening is carried either by a lintel (a beam across the top, working in bending — the modern default in RCC) or by an arch (which carries the load around the opening in pure compression — the traditional method, needing no tension material). An arch suits masonry's compression strength; a lintel suits reinforced concrete." },
            { k: "list", items: [
              "<strong>Frame</strong> — the fixed timber, steel or aluminium surround, built into the wall, that the shutter hangs on.",
              "<strong>Shutter</strong> — the moving leaf (the door or window itself).",
              "<strong>Sill</strong> — the bottom member of a window opening, sloped and throated to shed water outward.",
              "<strong>Lintel</strong> — the beam over the top carrying the wall above.",
            ] },
            { k: "note", t: "The old arch and the modern lintel solve the same problem with opposite materials. An arch needs only compression strength, so it suited stone and brick and needed no steel — but it pushes outward at its base (thrust) and needs support against that. A lintel bends, so it needs tension strength (steel), but it pushes only straight down. The shift from arches to lintels is really the shift from masonry to reinforced concrete." },
            { k: "list", items: [
              "<strong>Bearing</strong> — at least 150 mm at each end, or the lintel depth if greater.",
              "<strong>Timber lintel depth</strong> — about 1/12 to 1/8 of the span, not less than 80 mm.",
              "<strong>RCC lintel bars (thumb rule for small openings)</strong> — 6 mm bars up to 1 m span, 8 mm for 1–1.5 m, 10 mm for 1.5–2 m, 12 mm for 2–3 m.",
            ] },
            { k: "note", t: "Values from <a href=\"https://blendedlearning.bharatskills.gov.in/pluginfile.php/22239/mod_resource/content/1/DraughtsMan%20Civil-%201%2C%20Week%20-%2019.pdf\" target=\"_blank\" rel=\"noopener\">Bharatskills Draughtsman (Civil) notes</a>. The bar sizes are a trade thumb rule for ordinary domestic openings, not a design; a lintel carrying a slab or a concentrated load must be designed as a beam (RCC handbook, Chapters 3 and 5)." },
            { k: "h", t: "How much wall does a lintel carry?" },
            { k: "p", t: "If there is enough masonry above and beside the opening, bonded brickwork arches over it, and the lintel carries only the wedge of masonry immediately above — conventionally taken as an <strong>equilateral triangle</strong> on the clear span. This is a well-established design assumption (general engineering knowledge, not an IS clause); it does not apply if a slab or beam bears on the wall within that triangle, or if the masonry above is too shallow to arch." },
            { k: "eg", title: "Example 7.1 — Load on a lintel by the triangle rule",
              given: "Clear span 1.2 m in a 230 mm brick wall, masonry 20 kN/m³, enough wall above and beside the opening for arching; no slab within the triangle.",
              steps: [
                { t: "Triangle", w: "area = (√3/4) × 1.2² = 0.623 m²" },
                { t: "Load", w: "W = 0.623 × 0.23 × 20 = 2.87 kN (triangularly distributed)" },
                { t: "Maximum moment (simply supported, triangular load)", w: "M = WL/6 = 2.87 × 1.2/6 = 0.57 kNm" },
              ],
              ans: "A total load under 3 kN and a moment of about 0.6 kNm — which is why small lintels are so lightly reinforced. Put a slab bearing within that triangle and the load can be ten times larger." },
          ],
        },
        {
          n: "7.2",
          title: "Roofs — shed the water or seal it",
          hi: "छत — पानी बहाओ या रोको",
          blocks: [
            { k: "p", t: "Every roof deals with rain, and there are two strategies: give it a slope so water runs off fast (a pitched roof), or make it flat and rely on a waterproof membrane to keep water out (a flat roof). The choice drives the whole roof design." },
            { k: "cmp", t: "The two roof families",
              cols: ["Pitched roof", "Flat roof"],
              rows: [
                ["Keeps water out by", "slope — it runs off", "membrane — it is sealed"],
                ["Best in", "heavy rain, snow", "warm/dry, or where roof is used"],
                ["Space above", "attic / wasted volume", "usable terrace"],
                ["Main risk", "wind uplift on the slope", "ponding & membrane failure"],
                ["Materials", "trusses + tiles/sheets", "RCC slab + waterproofing"],
              ] },
            { k: "cmp", t: "Pitched roof forms and the spans they suit", cols: ["Typical span"], rows: [
              ["Lean-to roof", "up to about 2.4 m"],
              ["Couple roof", "up to about 3.6 m"],
              ["Couple-close roof", "up to about 4.2 m"],
              ["Collar-beam roof", "up to about 4.8 m"],
              ["King-post truss", "about 5 – 8 m"],
              ["Queen-post truss", "about 8 – 12 m"],
              ["Steel truss", "economical beyond about 12 m"],
            ]},
            { k: "note", t: "Spans from <a href=\"https://coursecontent.indusuni.ac.in/wp-content/uploads/sites/8/2020/03/BUILDING-CONSTRUCTION-MATERIALS_CV0312_UNIT-3.pdf\" target=\"_blank\" rel=\"noopener\">Indus University CV0312 notes</a>. The progression is the same idea each time: as the span grows, the rafters need a tie to stop them spreading (couple-close), then a higher tie (collar), then a post to stop the tie sagging (king post), then two posts (queen post) — and finally a different material." },
            { k: "real", t: "In heavy-monsoon and hill regions the pitched roof dominates for a simple reason: a slope sheds water instantly and forgivingly, while a flat roof depends entirely on its waterproofing membrane staying perfect — and any ponding or crack lets water sit and find its way in. <strong>The steeper the roof, the less it asks of its waterproofing</strong>, which is why traditional heavy-rain architecture is full of steep roofs." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "bc-8",
      n: 8,
      title: "Stairs",
      hi: "सीढ़ियाँ",
      blurb: "The one structure whose design is set by the human body — the rise-and-going relationship that makes a stair comfortable or treacherous.",
      mins: 26,
      sections: [
        {
          n: "8.1",
          title: "The parts of a stair",
          hi: "सीढ़ी के भाग",
          blocks: [
            { k: "p", t: "A stair is unusual: its design is governed not by load but by the human body. The dimensions of each step have to match the natural length and lift of a walking stride, or every user feels the stair is wrong — too steep and tiring, or too shallow and tripping." },
            { k: "dia", id: "hb-bc-stair", cap: "The parts of a stair and the rules that make it comfortable." },
            { k: "def", term: "Rise and going", t: "The rise is the vertical height you step up from one tread to the next; the going is the horizontal distance you step forward. The riser is the vertical face of the step; the tread is the horizontal surface you stand on. Rise and going together decide how steep the stair feels." },
            { k: "def", term: "Flight and landing", t: "A flight is an unbroken run of steps; a landing is a level platform between flights. Landings break a long climb for rest, allow the stair to change direction, and limit how far a person could fall. Codes limit the number of steps in a single flight for this reason." },
          ],
        },
        {
          n: "8.2",
          title: "The comfort rules",
          hi: "आराम के नियम",
          blocks: [
            { k: "p", t: "Two old rules of thumb encode a comfortable stride, and a stair that obeys them feels natural to climb while one that breaks them feels wrong to everyone who uses it." },
            { k: "eq", expr: "2 × rise + going ≈ 550–650 mm (Blondel's rule; sources differ on the band)     and     rise × going ≈ 40000–45000 mm²", where: [
              ["rise", "vertical height of one step, typically 150–175 mm"],
              ["going", "horizontal depth of one step, typically 250–300 mm"],
            ] },
            { k: "p", t: "The first rule captures that a stride has a fixed 'budget' — climb higher per step and you must step less far forward, and vice versa. The second keeps the step from becoming either a ladder or a ramp. Together they pin the rise and going to a comfortable band, which is why staircases the world over have broadly similar step dimensions." },
            { k: "trap", t: "An inconsistent stair — a few steps of one rise, then a step of a different rise (often at a landing where the arithmetic did not close) — is a genuine hazard, because people climb on autopilot expecting every step to be identical. The odd step out is where they trip and fall. Every step in a flight must have exactly the same rise and going; the design must make the total height divide evenly." },
          ],
        },
        {
          n: "8.3",
          title: "What the National Building Code asks for",
          hi: "NBC की अपेक्षाएँ",
          blocks: [
            { k: "cmp", t: "Stair dimensions — NBC 2016 Part 4, as summarised by two sources", cols: ["Residential", "Other buildings (public, commercial)"], rows: [
              ["Riser", "max 190 mm", "max 150 mm"],
              ["Tread (going)", "min 250 mm", "min 300 mm"],
              ["Headroom", "min 2.1 m", "min 2.1 m"],
              ["Handrail height", "900–1000 mm above the nosing", "900–1000 mm"],
              ["Risers per flight", "12 (both summaries)", "12 preferred"],
              ["Clear width", "<strong>900 mm</strong> single-family / 1200 mm multi-unit (StudioMatrx) vs <strong>1.0 m</strong> (InfraLens)", "1.5 m for public and educational buildings (InfraLens)"],
            ]},
            { k: "note", t: "Sources: <a href=\"https://www.studiomatrx.org/guides/staircase-design-india\" target=\"_blank\" rel=\"noopener\">StudioMatrx</a> and <a href=\"https://infralens.in/handbook/staircase-design\" target=\"_blank\" rel=\"noopener\">InfraLens</a>. They agree on rise, going, headroom and handrail height, and disagree on minimum width — check the edition of NBC and the local bye-laws that govern the project. Both treat 2R + G (Blondel's rule) as comfort guidance, not a code requirement. Structural design of the stair slab is in the RCC handbook, Chapter 11." },
            { k: "eg", title: "Example 8.1 — Planning a dog-legged stair",
              given: "Residential building, floor-to-floor height 3.15 m. Dog-legged stair with two equal flights and a half landing.",
              steps: [
                { t: "Number of risers", w: "try a 175 mm rise: 3150/175 = 18 risers exactly  (≤ 190 ✓)" },
                { t: "Flights", w: "two flights of 9 risers each (≤ 12 ✓)" },
                { t: "Treads", w: "each flight has one tread fewer than risers: 8 treads\nwith a 250 mm going: 8 × 250 = 2.00 m of going per flight" },
                { t: "Comfort checks", w: "2R + G = 2 × 175 + 250 = 600 mm  ✓\nR × G = 175 × 250 = 43,750 mm²  ✓" },
              ],
              ans: "18 risers of 175 mm in two flights of 9, treads 250 mm, 2.0 m of going per flight plus the landings. Choosing a rise that divides the storey height exactly is what avoids the ‘odd step’ of the trap above." },
          ],
        },
      ],
    },

  );
})();
