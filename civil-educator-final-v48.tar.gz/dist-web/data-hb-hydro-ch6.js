/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 6
   Runoff & Catchment Characteristics
   Sources: S1 p.3-10 (runoff coefficient, worked problems, allied
   terms), S2 p.91-97 (factors affecting the runoff hydrograph,
   catchment shape/form-factor/compactness, drainage & stream
   density, urbanisation, Rational/Dicken's/Ryve's/Inglis's
   formulas), S3 p.28-33 (Dicken's/Ryve's/Inglis's formulas with
   region-wise constants, Inglis's annual-runoff formula).
   Drainage-pattern types and elongation ratio are not covered in
   these page ranges and are given as General Engineering
   Knowledge, clearly labelled.
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-6",
    n: 6,
    title: "Runoff & Catchment Characteristics",
    hi: "अपधावन एवं जलसंग्रहण विशेषताएँ",
    blurb: "Runoff aur runoff coefficient se shuru karke, climatic aur catchment/physiographic factors, basin shape (form factor, compactness coefficient, elongation ratio), drainage patterns, drainage/stream density, urbanisation ka effect, aur chaar empirical flood-peak formulas (Rational, Dicken's, Ryve's, Inglis's) — har formula apne exact constants, units aur applicability region ke saath.",
    mins: 40,
    sections: [

      /* ============================================================ 6.1 */
      {
        n: "6.1",
        title: "Runoff — Definition, Runoff Coefficient and Q = CiA",
        hi: "अपधावन — परिभाषा, अपधावन गुणांक एवं Q = CiA",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.3–10" },
          { k: "def", term: "Runoff (R)", t: "The part of precipitation that is neither evaporated, nor transpired, nor infiltrated into the ground, and which reaches a stream, river or other watercourse. From the catchment water-budget equation (Ch.1), Runoff = Rainfall − Losses, where the losses are the combined effect of infiltration, evaporation and transpiration. (S1 p.3)" },
          { k: "def", term: "Runoff Coefficient (C)", t: "The ratio of runoff volume to the rainfall (precipitation) volume that produced it: C = R/P (dimensionless, R and P in the same volume units, e.g. m³). (S1 p.3)" },
          { k: "def", term: "Pan Coefficient (Cp)", t: "Listed in the source immediately after the runoff coefficient: Cp = E_reservoir/E_pan — the ratio used to convert a pan's measured evaporation to the actual reservoir evaporation. Covered fully, with worked examples, in Ch.4 (Evaporation); included here only because the source states it right alongside the runoff coefficient. (S1 p.3)" },
          { k: "eq", expr: "Discharge:  Q = C · i · A", where: [
            ["Q", "discharge / rate of runoff"],
            ["C", "runoff coefficient"],
            ["i", "rate of rainfall, i = Δh/Δt (depth of rainfall per unit time)"],
            ["A", "catchment (contributing) area"],
          ] },
          { k: "note", t: "This Q = C·i·A relation is the same shape as the <b>Rational formula</b> used for flood-peak estimation (§6.7 below) — here it is simply introduced as the general discharge-from-rainfall relation; §6.7 gives its full peak-discharge form (Qp = KiA) with the time-of-concentration condition and its area limit. (S1 p.7)" },
          { k: "h", t: "Worked Example 1 — loss of water from a catchment (S1 p.3–4)" },
          { k: "eg", title: "Loss of water, dry-before/dry-after stream", given: "A catchment of area 100 hectares receives a rainfall of 10 cm in 2 hours due to a storm. At the outlet, the stream draining the catchment was dry before the storm and experienced a runoff lasting 8 hours, with an average discharge of 2 m³/s. The stream was dry again after the runoff. Find the loss of water.", steps: [
            { t: "Change in storage ΔS = 0, since the stream is dry both before and after the storm", w: "P − R − [G−E−T] = ΔS  ⇒  Loss = P − R − ΔS = P − R  (ΔS = 0)" },
            { t: "Runoff volume, R = Q × t (1 hr = 60×60 s)", w: "R = 2 × (8×60×60) = 2 × 28,800 = 57,600 m³" },
            { t: "Rainfall (precipitation) volume, P = A × depth of rainfall (1 hectare = 10⁴ m²)", w: "P = (100×10⁴ m²) × (10×10⁻² m) = 10⁵ m³" },
            { t: "Loss = P − R − ΔS", w: "Loss = 10⁵ − 57,600 − 0 = 42,400 m³" },
          ], ans: "Loss of water = 42,400 m³ (S1 p.3–4)" },
          { k: "h", t: "Worked Example 2 — discharge from a known runoff/rainfall ratio (S1 p.4)" },
          { k: "eg", title: "Average streamflow from C = 0.40", given: "A catchment has an area of 150 hectares and the runoff-to-rainfall ratio (C) is 0.40. Due to 10 cm rainfall over the catchment, the stream flow at the outlet lasts for 10 hours. Find the average stream flow during that period.", steps: [
            { t: "R = C·P, and R = Q·t, P = A × depth", w: "0.40 × P = Q × (10×60×60)" },
            { t: "Substitute P = A × depth = 150×10⁴ m² × 0.1 m", w: "0.40 × (150×10⁴ × 0.1) = Q × 36,000" },
            { t: "Solve for Q", w: "Q = (0.4 × 150×10⁴ × 0.1) / 36,000 = 60,000 / 36,000" },
          ], ans: "Q = 1.667 m³/s (cumec) (S1 p.4)" },
          { k: "h", t: "Worked Example 3 — water lost and runoff coefficient together (S1 p.7–8)" },
          { k: "eg", title: "Water lost and runoff coefficient, 150-hectare catchment", given: "A catchment area has a surface area of 150 hectares, where the depth of rainfall in 2 hours is 110 mm. The surface runoff in a river lasts 10 hours at an average discharge of 1.5 cumec, after which the river becomes dry. Find (a) the water lost in the catchment, and (b) the runoff coefficient (C).", steps: [
            { t: "Rainfall volume, P = A × depth of rainfall", w: "P = (150×10⁴ m²) × (110×10⁻³ m) = 165,000 m³" },
            { t: "Runoff volume, R = Q × t", w: "R = 1.5 × (10×60×60) = 1.5 × 36,000 = 54,000 m³" },
            { t: "(a) Water lost = Inflow (P) − Outflow (R)", w: "Water lost = 165,000 − 54,000 = 111,000 m³" },
            { t: "(b) Runoff coefficient, C = R/P", w: "C = 54,000 / 165,000 = 0.327" },
          ], ans: "(a) Water lost = 111,000 m³ — the source labels this figure \"111×10³ m³/s\", but it is a volume (m³), not a flow rate; (b) C = 0.327 (S1 p.7–8)" },
          { k: "h", t: "Worked Example 4 — weighted (area-averaged) runoff coefficient (S1 p.9)" },
          { k: "eg", title: "Runoff coefficient from several sub-areas", given: "Find the runoff coefficient with the help of the following data: Area 5 hectares, C = 0.4; Area 6 hectares, C = 0.5; Area 10 hectares, C = 0.45.", steps: [
            { t: "Area-weighted average runoff coefficient", w: "C = (A1C1 + A2C2 + A3C3) / (A1+A2+A3) = (5×0.4 + 6×0.5 + 10×0.45) / (5+6+10)" },
            { t: "Numerator", w: "5×0.4 + 6×0.5 + 10×0.45 = 2 + 3 + 4.5 = 9.5" },
            { t: "Divide by total area", w: "C = 9.5 / 21" },
          ], ans: "C = 0.45 (S1 p.9)" },
          { k: "note", t: "The source gives the same area-weighting for rainfall (and, by the same logic, runoff) across several sub-areas: <b>R̄ = (A₁R₁ + A₂R₂ + A₃R₃)/(A₁+A₂+A₃)</b>, and states this applies equally to P̄ (mean areal rainfall) — the same form as the Thiessen-polygon weighting already used in Ch.3. (S1 p.9)" },
          { k: "h", t: "Worked Example 5 — runoff discharge from Q = CiA (S1 p.9)" },
          { k: "eg", title: "Runoff discharge for a 100-hectare catchment", given: "The depth of rainfall in a catchment area of 100 hectares is 5 cm in 90 minutes. Find the runoff discharge if the runoff coefficient is 0.45.", steps: [
            { t: "Rainfall intensity, i = depth/time", w: "i = (5×10⁻² m) / (90×60 s)" },
            { t: "Apply Q = C·i·A with A = 100×10⁴ m²", w: "Q = 0.45 × [(5×10⁻²)/(90×60)] × 100×10⁴" },
          ], ans: "Q = 4.16 m³/s, as boxed in the source (S1 p.9)" },
          { k: "note", t: "<b>Check:</b> the source defines C = 0.45 for this problem, but its own substitution line writes \"0.95 × (5×10⁻²)/(90×60) × 100×10⁴\" — using 0.95, not 0.45. The boxed final answer of 4.16 m³/s is only consistent with C = 0.45 (0.45 × (5×10⁻²/5400) × 10⁶ ≈ 4.17 m³/s); using 0.95 would give roughly double that. This looks like a slip in copying the coefficient into the substitution line, not in the final boxed answer — the 0.45 value is used here as the one that actually matches 4.16 m³/s. (S1 p.9)" },
          { k: "h", t: "Worked Example 6 — percentage of rainfall that becomes runoff (S1 p.10)" },
          { k: "eg", title: "% runoff for a 210 km² drainage basin", given: "A drainage basin has an area of 210 km². The average depth of rainfall received during a monsoon period is 65 cm, while the runoff measured at its outlet over the same period is 5.68×10⁷ m³. Find the percentage of rainfall that becomes runoff.", steps: [
            { t: "% Runoff = (Runoff/Precipitation) × 100, with P = A × depth", w: "% Runoff = R/P × 100 = [5.68×10⁷ × 100] / [A × depth of rainfall]" },
            { t: "Substitute, as done in the source", w: "= (5.68×10⁷ × 100) / (216×10⁶ × 65×10⁻²)" },
          ], ans: "Runoff = 41.61%, as boxed in the source (S1 p.10)" },
          { k: "note", t: "<b>Check:</b> the question states the basin area A = 210 km², but the denominator substitution uses 216×10⁶ m² (i.e. 216 km²), not 210×10⁶ m². The boxed final answer of 41.61% is consistent only with the 216×10⁶ figure actually used (5.68×10⁷×100 / (216×10⁶×0.65) ≈ 40.5%, closer than the 210 figure gives) — kept here exactly as the source works it, with this mismatch flagged rather than silently corrected. (S1 p.10)" },
          { k: "note", t: "The source also lists a short set of allied-science names right after this topic: the science of river flow behaviour and discharge is called <b>Potamology</b>; the science of lakes and their storage capacity is called <b>Limnology</b>; the science of snow deposits is called <b>Cryology</b>. It states the world's maximum rate of river flow occurs on the <b>Amazon</b> river (≈8000 cumec) — though it labels the Amazon as being in the U.S.A., which is a geographical slip in the source (the Amazon basin is in South America). For India, it states the largest average rate of flow is on the <b>Brahmaputra</b> (Assam), with the <b>Ganga</b> second largest. (S1 p.8)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Runoff coefficient C bilkul simple hai — kitna fraction rainfall ka actually stream tak pahunchta hai (bache hue hissa infiltration/evaporation/transpiration mein \"lost\" ho jaata hai). Har numerical mein pattern same hai: pehle P aur R ko <b>same units</b> (m³) mein convert karo — hectare ko 10⁴ m² se multiply, cm/mm ko metre mein, ghanta/minute ko second mein — phir C = R/P ya Q = C·i·A seedha laga do. Weighted-C formula (Example 4) bilkul Thiessen-weighting jaisa hai — bas area ke hisaab se average le rahe ho, formula same shape ka hai." },
          { k: "trap", t: "Do baar yahan '0.45 vs 0.95' aur '210 vs 216' jaisi copying mistakes dikhi — apna khud ka calculation likho, source ke intermediate substitution line ko blindly copy mat karo, kyunki final boxed answer hi sahi reference hota hai agar substitution line mismatch kare." },
        ],
      },

      /* ============================================================ 6.2 */
      {
        n: "6.2",
        title: "Factors Affecting Runoff — Climatic and Catchment/Physiographic",
        hi: "अपधावन को प्रभावित करने वाले कारक — मौसमी एवं जलसंग्रहण कारक",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.92" },
          { k: "p", t: "The source groups the factors affecting the runoff hydrograph (shape and peak) into two broad heads: (1) characteristics of the rainfall itself, and (2) characteristics of the catchment. (S2 p.92)" },
          { k: "def", term: "1. Climatic (rainfall) factors", t: "The source names <b>intensity of rainfall</b>, <b>direction of storm movement</b> and <b>wind characteristics</b> as the rainfall-side factors affecting the runoff hydrograph. (S2 p.92)" },
          { k: "list", items: [
            "<b>Intensity of rainfall</b> — higher intensity, relative to the infiltration capacity, produces more and faster runoff. (S2 p.92)",
            "<b>Direction of storm movement</b> — a storm moving along the direction of stream flow (toward the outlet) concentrates runoff faster and gives a higher, sharper peak than one moving away from the outlet. (S2 p.92)",
            "<b>Wind characteristics</b> — named by the source as a contributing climatic factor (through its influence on storm movement and on evaporation losses during the event). (S2 p.92)",
          ] },
          { k: "note", t: "<i>General Engineering Knowledge</i> — beyond what S2 p.92 itself lists, the standard additional climatic factors are: type of precipitation (rain vs snow — snow delays runoff until melt), duration of the storm, areal distribution of rainfall over the catchment, antecedent precipitation and soil-moisture condition (a wetter catchment runs off a larger fraction of a new storm), and air temperature/humidity (through evapotranspiration losses). These are not stated in the source transcripts for this chapter and are included for completeness, clearly separate from what S2 itself states." },
          { k: "def", term: "2. Catchment (physiographic) factors", t: "The source's two explicitly worked catchment factors are <b>area</b> and <b>shape</b>; the remaining ones (drainage density, stream density, urbanisation) are developed as their own topics in §6.5–6.6 below, since the source itself treats them as separate numbered points. (S2 p.92–95)" },
          { k: "def", term: "(a) Area", t: "The peak of the hydrograph increases as the catchment area increases. In a <b>small</b> catchment, the overland-flow phase (sheet flow over the ground before reaching a defined channel) is predominant over the channel-flow phase. In a <b>large</b> catchment, the channel-flow phase is predominant over the overland-flow phase (water travels mostly inside defined streams/tributaries, which drain faster into the main basin stream). (S2 p.92)" },
          { k: "def", term: "(b) Shape", t: "The shape of the basin controls the time taken for a drop of water from the most remote part of the catchment to reach the outlet, so the hydrograph (and its peak) are affected by basin shape. The source illustrates three cases: (i) a <b>fan-shaped</b> basin, whose hydrograph is symmetric, with time-to-peak tpk = time of rise ts = half the time base (tpk = ts = tB/2); (ii) a leaf-shaped basin with tributaries concentrated <b>near the outlet</b>, giving an early, unsymmetric peak (tpk < tB/2); and (iii) a leaf-shaped basin with tributaries concentrated <b>away from the outlet</b>, giving a delayed peak (tpk > tB/2). (S2 p.92)" },
          { k: "def", term: "Isochrones", t: "A line joining the points on a catchment map that have an equal time of travel of surface runoff to the outlet. The source's example shows a leaf-shaped basin where all tributaries crossing the same isochrone (e.g. all points on the \"4 h\" line) take an equal time to reach the main channel. (S2 p.93)" },
          { k: "list", items: [
            "<b>Fan-shaped catchment</b> gives a greater (sharper, higher) runoff peak, because its tributaries are of nearly the same size, with nearly the same and smaller time of travel to the outlet. (S2 p.93)",
            "<b>Fern-leaf catchment</b> gives a smaller runoff peak, because its tributaries are of different sizes, with different and larger times of travel. (S2 p.93)",
          ] },
          { k: "note", t: "<i>General Engineering Knowledge</i> — the usual list of catchment/physiographic factors also includes: catchment slope (steeper slope → faster concentration, sharper and earlier peak), land use and vegetation cover (forest/vegetation increases infiltration and reduces peak runoff), soil type and geology (governs infiltration capacity), orientation of the basin (affects snowmelt timing and evapotranspiration), and the presence of lakes, swamps or channel/valley storage (these attenuate — flatten and delay — the peak). These are not stated in the source transcripts for this chapter's page range." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh sab factors essentially ek hi sawaal ka jawab dete hain: <b>paani ko outlet tak pahunchne mein kitna time lagta hai, aur kitna ek saath pahunchta hai?</b> Agar sab tributaries ka travel-time lagbhag same hai (fan shape, chhota catchment, high drainage density) to paani 'ek saath' pahunchta hai aur peak sharp/high hota hai. Agar travel-times bahut alag-alag hain (fern-leaf shape, bada catchment) to paani 'spread out' hoke pahunchta hai aur peak flat/low hota hai, lekin lambe time tak chalta hai." },
          { k: "real", t: "Isochrone maps site par timeofconcentration (tc) estimate karne mein use hote hain — jo rational formula (§6.7) mein directly required hota hai. Catchment ka sabse door wala point jiska travel-time sabse zyada hai, wahi tc decide karta hai." },
        ],
      },

      /* ============================================================ 6.3 */
      {
        n: "6.3",
        title: "Catchment Shape — Form Factor, Compactness Coefficient and Elongation Ratio",
        hi: "जलसंग्रहण आकृति — आकृति गुणांक, सुसंहति गुणांक एवं दीर्घीकरण अनुपात",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.93–94" },
          { k: "def", term: "Catchment", t: "The area of land draining into a stream or watercourse at a given location (fuller treatment, including the term \"divide\", is given in Ch.1). (S2 p.93)" },
          { k: "p", t: "The effect of the shape of a drainage basin is expressed using two named quantities: the <b>form factor</b> and the <b>compactness coefficient</b>. (S2 p.93)" },
          { k: "def", term: "Form Factor (FF)", t: "FF = (average width of catchment) / (axial length of basin) = B/L. Since a basin's area A = B·L, the average width B = A/L, so the form factor can also be written directly in terms of area and length: FF = A/L². (S2 p.93)" },
          { k: "eq", expr: "Form factor:  FF = B/L = A/L²", where: [
            ["B", "average width of the catchment (A/L)"],
            ["L", "axial length of the basin (outlet to the farthest point)"],
            ["A", "catchment area"],
          ] },
          { k: "def", term: "Compactness Coefficient (CC)", t: "CC = (perimeter of the basin, P) / (circumference of a circle whose area equals the basin's area, A). Taking A_circle = A = πr² gives r = √(A/π), and the circle's circumference as 2πr, so: CC = P/(2πr) = P/(2π√(A/π)), which simplifies to CC = P/(2√(πA)). (S2 p.94)" },
          { k: "eq", expr: "Compactness coefficient:  CC = P / (2π·r) = P / (2√(πA)),  with r = √(A/π)", where: [
            ["P", "perimeter of the actual basin"],
            ["r", "radius of a circle of the same area A as the basin"],
            ["A", "catchment area"],
          ] },
          { k: "cmp", t: "Practical significance of FF and CC (S2 p.94)", cols: ["…this flow phase dominates", "Waterlogging"], rows: [
            ["Form factor FF ↑ (shorter, wider basin, for a given area)", "Channel-flow phase predominant", "Less"],
            ["Compactness coefficient CC ↑ (more elongated/irregular basin)", "Overland-flow (sheet-flow) phase predominant", "More"],
          ] },
          { k: "dia", id: "hb-hydro-catchment-shape", cap: "Form factor (left) and compactness coefficient (right), drawn on representative basin shapes." },
          { k: "def", term: "Elongation Ratio (Re)", t: "<i>General Engineering Knowledge</i> — not covered in this chapter's source page ranges. The elongation ratio compares the diameter of a circle with the same area as the basin to the basin's maximum length: Re = (2/Lmax)·√(A/π). Re close to 1 indicates a nearly circular, compact basin (fast concentration, sharp peak); Re well below 1 indicates an elongated basin (slower concentration, flatter and later peak) — the same qualitative reading as a low form factor / high compactness coefficient." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "FF aur CC dono same baat bata rahe hain — catchment kitna 'round/compact' hai ya kitna 'lamba/sprawling' — bas formula alag angle se dekhte hain. FF seedha width/length ka ratio hai (chhota L, bada B → high FF → round-ish). CC thoda clever hai: woh basin ke perimeter ko <b>sabse chhote possible perimeter</b> (same area wale circle ka perimeter) se compare karta hai — isliye CC hamesha ≥1 hota hai, aur CC=1 sirf perfect circle ke liye. Elongation ratio bhi isi family ka member hai, bas diameter/length ka ratio use karta hai." },
          { k: "trap", t: "FF ki formula mein L² hai (square), isliye L ki units double count ho jaati hain agar A aur L ki units consistent na ho (A km² mein ho to L bhi km mein hona chahiye, A ha mein ho to L bhi matching units mein). Isi tarah CC ki formula mein bhi P aur √A ki units match honi chahiye." },
        ],
      },

      /* ============================================================ 6.4 */
      {
        n: "6.4",
        title: "Drainage Pattern Types",
        hi: "अपवाह प्रतिरूप के प्रकार",
        blocks: [
          { k: "note", t: "<i>General Engineering Knowledge</i> — the standard classification of drainage patterns is not covered in this chapter's assigned source page ranges (S1 p.3–10, S2 p.91–97, S3 p.28–33). It is given here in full so the information is not lost, clearly separated from the cited source content elsewhere in this chapter." },
          { k: "list", items: [
            "<b>Dendritic</b> — a tree-branching pattern, the most common type; develops on homogeneous, gently sloping terrain of roughly uniform resistance (e.g. flat sedimentary rock or unconsolidated soil), with tributaries joining the main stream at acute angles.",
            "<b>Parallel</b> — streams run roughly parallel to each other over a fairly steep, uniform slope, joining the main stream at acute angles; often seen on newly uplifted or tilted terrain.",
            "<b>Trellis</b> — a rectangular, lattice-like pattern of short tributaries meeting long parallel main streams at right angles; develops where bands of hard and soft rock alternate, typically in folded (anticline/syncline) sedimentary terrain.",
            "<b>Rectangular</b> — streams and tributaries bend and join at approximately right angles, controlled by joints and faults in the underlying rock rather than by rock-type bands.",
            "<b>Radial</b> — streams radiate outward in all directions from a central high point, such as a volcanic cone or an isolated dome/hill.",
            "<b>Centripetal / Annular</b> — the reverse of radial: streams converge inward toward a central depression or basin (centripetal), or, on a breached dome, circle around it in concentric rings following bands of weaker rock (annular).",
            "<b>Deranged</b> — an irregular, disorganised pattern with no clear relation between tributaries and the main stream, interrupted by numerous lakes and swamps; typical of recently glaciated terrain.",
          ] },
        ],
      },

      /* ============================================================ 6.5 */
      {
        n: "6.5",
        title: "Drainage Density, Stream Order and Stream Density",
        hi: "अपवाह घनत्व, धारा क्रम एवं धारा घनत्व",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.94–95" },
          { k: "def", term: "Drainage Density (DD)", t: "DD = (total length of all channels in the catchment) / (total drainage area) = L/A. As the total channel length L increases (for a fixed area), DD increases, and vice versa. (S2 p.94)" },
          { k: "eq", expr: "Drainage density:  DD = L / A", where: [
            ["L", "total length of all stream channels in the catchment"],
            ["A", "catchment (drainage) area"],
          ] },
          { k: "real", t: "The source illustrates drainage density changing over time on the <b>same</b> fixed catchment area due to urban development of the drain/channel network: it sketches \"1990 Delhi\" with DD = 7/A against a denser \"2020 Delhi\" with DD = 11/A — i.e. more channel length packed into the same area as the city's drainage network was built out. (S2 p.94)" },
          { k: "p", t: "Effect on the hydrograph: a higher drainage density means more pathways carrying water quickly off the land into channels, giving a taller, narrower (more peaked) hydrograph; a lower drainage density gives a flatter, wider hydrograph, for the same rainfall and area. (S2 p.94)" },
          { k: "def", term: "Stream Order", t: "<i>General Engineering Knowledge</i> — the source's sketch of a fern-leaf basin simply numbers its tributaries 1, 2, 3 and 4 and labels them \"stream order\" without stating the ordering rule itself (S2 p.93); the rule is added here for completeness. In the commonly used (Strahler) system: a fingertip tributary that receives no other tributary is a 1st-order stream; where two streams of the same order meet, the resulting stream's order increases by one (two 1st-order streams join to form a 2nd-order stream); where a lower-order stream joins a higher-order one, the higher order is simply continued (a 1st-order stream joining a 2nd-order stream keeps it at 2nd order). The order of the basin as a whole is the order of the main stream at the outlet." },
          { k: "def", term: "Stream Density (SD)", t: "SD = (number of streams of all orders) / (catchment area) = N/A. (S2 p.95)" },
          { k: "eq", expr: "Stream density:  SD = N / A", where: [
            ["N", "number of streams of all orders in the catchment"],
            ["A", "catchment (drainage) area"],
          ] },
          { k: "p", t: "Effect on the hydrograph follows the same pattern as drainage density: a higher stream density gives a taller, narrower (more peaked) hydrograph; a lower stream density gives a flatter, wider one, for the same catchment area. (S2 p.95)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "DD aur SD dono catchment ke 'drainage network kitna dense hai' ko measure karte hain — bas DD channel ki total <b>length</b> use karta hai, SD channels ki total <b>count</b> use karti hai. Dono high ho to matlab paani ko channel tak pahunchne ka distance/time kam hai, isliye runoff fast concentrate hota hai aur hydrograph peaky (tall & narrow) hota hai — jaisa urbanisation ke baad Delhi ke drains ke example mein dikh raha hai." },
        ],
      },

      /* ============================================================ 6.6 */
      {
        n: "6.6",
        title: "Effect of Urbanisation on Runoff",
        hi: "शहरीकरण का अपधावन पर प्रभाव",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.95" },
          { k: "def", term: "Urbanisation (in this runoff context)", t: "The source states it, in this specific context, as being \"to clean the river basin for easy drainage of water\" — i.e. it treats urbanisation here purely as a modification of the catchment's drainage surface and network, not in the general socio-economic sense. (S2 p.95)" },
          { k: "p", t: "The source's hydrograph sketch shows the <b>before-urbanisation</b> curve as flatter and later-peaking, and the <b>after-urbanisation</b> curve as peakier and earlier-peaking, for the same rainfall event. A companion sketch shows a river basin with buildings drawn as obstructions inside it, reducing the room available for water to spread and move laterally. (S2 p.95)" },
          { k: "list", items: [
            "<b>Before urbanisation</b> — more pervious natural ground allows more infiltration and slower overland flow, giving a flatter, delayed hydrograph peak. (S2 p.95)",
            "<b>After urbanisation</b> — impervious surfaces (roads, roofs, paving) and engineered drains concentrate and speed up flow, giving a sharper, earlier, higher hydrograph peak. (S2 p.95)",
            "Buildings and other structures act as <b>obstructions</b> within the river basin, affecting the natural lateral movement of water. (S2 p.95)",
          ] },
          { k: "note", t: "<i>General Engineering Knowledge</i> — beyond what S2 p.95 itself states, urbanisation is generally understood to reduce infiltration and evapotranspiration (impervious cover), increase the total volume of runoff for a given rainfall, shorten the time to peak and reduce base flow/lag time (storm drains and gutters behave like an artificial, very high drainage-density network), and increase the frequency of minor flooding downstream — effects not stated in the source transcripts for this chapter's page range." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Urbanisation ko bas 'artificial high drainage density' jaisa socho — roads, roofs aur drains sab mil kar natural soil/vegetation ki jagah le lete hain, jisse infiltration kam ho jaata hai aur paani drains ke through fast-track seedha stream mein pahunchta hai. Yehi reason hai ki same rainfall se, developed area mein peak <b>jaldi</b> aata hai aur <b>zyada</b> hota hai — exactly weh same trend jo drainage-density section (§6.5) mein Delhi ke 1990 vs 2020 example mein dikha." },
          { k: "real", t: "Isi principle se urban storm-drainage design mein peak discharge nikalne ke liye Rational formula (§6.7) ka runoff coefficient C zyada liya jaata hai developed/paved areas ke liye, kyunki impervious surface se C ≈ 0.7–0.95 tak ho sakta hai, jabki natural/vegetated area ka C bahut kam hota hai." },
        ],
      },

      /* ============================================================ 6.7 */
      {
        n: "6.7",
        title: "Empirical Flood-Peak Formulas — Rational, Dicken's, Ryve's and Inglis's",
        hi: "अनुभवजन्य बाढ़-शिखर सूत्र — रैशनल, डिकेन, रायवेज़ एवं इंग्लिस",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.96–97, S3 p.32–33" },
          { k: "p", t: "The source lists four broad approaches to estimating flood peak: ① the Rational formula; ② empirical (regional) formulas; ③ hydrograph analysis; and ④ flood-frequency analysis (statistical probability method, or the theoretical-probability/Gumbel's method). This chapter covers ① and ②; hydrograph analysis and flood-frequency methods belong to later chapters. (S2 p.96)" },
          { k: "h", t: "① Rational Formula" },
          { k: "def", term: "Rational formula — concept", t: "For a catchment under rainfall of constant intensity i, the rate of runoff rises (concave) as more and more of the catchment's drainage area starts contributing, reaches a constant maximum (= Ki) once the entire catchment is contributing simultaneously — at time t = tc, the time of concentration — and then falls (concave) once rainfall stops. The peak discharge therefore corresponds to the condition that the whole catchment is contributing at once. (S2 p.96)" },
          { k: "eq", expr: "Peak discharge:  Qp = K·i·A   (general form)  ;  Qp = (1/36)·K·i·A, for A in km²", where: [
            ["Qp", "peak discharge, in m³/s"],
            ["K", "runoff coefficient"],
            ["i", "intensity of rainfall, in cm/hr (at the time of concentration, tc)"],
            ["A", "area of catchment"],
          ] },
          { k: "def", term: "Time of concentration (tc)", t: "The minimum time for which the Rational method is applicable — it is the time taken for runoff from the remotest point of the catchment to reach the outlet. The formula requires the storm duration t ≥ tc. If t < tc, the peak discharge Qp by this method cannot be calculated — the source gives the example of a storm of duration t = 2 hr with tc = 4 hr, for which Qp simply cannot be found by the Rational method. (S2 p.96–97)" },
          { k: "def", term: "Equivalent runoff coefficient (Keq)", t: "For a catchment made up of several sub-areas, each with its own runoff coefficient (e.g. by land use): Keq = (K₁A₁ + K₂A₂ + ... + KₙAₙ) / (A₁ + A₂ + ... + Aₙ) — the same area-weighting idea used for the plain runoff coefficient in §6.1 and for mean areal rainfall in Ch.3, now applied to a composite catchment's runoff coefficient. (S2 p.97)" },
          { k: "note", t: "<b>Applicability:</b> the Rational formula is stated as applicable only to a very small catchment, of area up to 50 km². (S2 p.97)" },
          { k: "h", t: "② Empirical (Regional) Formulas" },
          { k: "eq", expr: "Dicken's formula:  Qp = CD · A^(3/4)", where: [
            ["Qp", "peak discharge, in m³/s"],
            ["A", "catchment area, in km²"],
            ["CD", "Dicken's constant"],
          ] },
          { k: "list", items: [
            "<b>General range</b> (all regions where the formula applies): CD = 6 to 30. (S2 p.97)",
            "<b>Region-wise bands</b>: CD = 6 for the plain/North-India zone; CD = 6–11 for a hilly zone; CD = 11–14 for a central zone such as Maharashtra. (S3 p.32–33)",
            "<b>Applicable region:</b> North and Central India. (S2 p.97)",
          ] },
          { k: "note", t: "The S3 region-wise bands (6, 6–11, 11–14) all sit within S2's broader stated range of 6–30 for Dicken's constant — the two are kept together as complementary detail (S3 giving finer regional bands) rather than as a conflict. (S2 p.97; S3 p.32–33)" },
          { k: "eq", expr: "Ryve's formula:  Qp = CR · A^(2/3)", where: [
            ["Qp", "peak discharge, in m³/s"],
            ["A", "catchment area, in km²"],
            ["CR", "Ryve's constant"],
          ] },
          { k: "def", term: "Applicable region (Ryve's)", t: "South India, specifically Tamil Nadu, Andhra Pradesh, Telangana, Karnataka, etc. (S2 p.97)" },
          { k: "note", t: "<b>Conflicting constants — kept, not silently picked:</b> S2 states Ryve's constant CR = 6.8 to 10.2 (S2 p.97), while S3 states CR = 6 to 8 (S3 p.33). These are genuinely different ranges (S3's upper bound of 8 is below S2's own lower bound of 6.8 only by a little, but S2's range extends well above S3's); both are recorded here exactly as each source states them, rather than choosing one." },
          { k: "eq", expr: "Inglis's formula:  Qp = 124·A / (√A + 10.4)   [S2]   or   Qp = 124·A / √(A + 10.4)   [S3]   ;  simplified form:  Qp = 123·√A   [S2]   or   Qp = 124·√A   [S3, for Maharashtra]", where: [
            ["Qp", "peak discharge, in m³/s"],
            ["A", "catchment area, in km²"],
          ] },
          { k: "note", t: "<b>Conflicting formulas — kept, not silently picked:</b> the two sources disagree on the exact shape of Inglis's formula in two places. (1) The denominator: S2 writes it as (√A + 10.4) — the square root of A, plus 10.4; S3 writes it as √(A + 10.4) — the square root of the sum (A + 10.4). These are mathematically different expressions for any A. (2) The simplified √A form: S2 gives Qp = 123√A, while S3 gives Qp = 124√A (for Maharashtra). Both forms, exactly as each source states them, are recorded above rather than silently resolved. (S2 p.97; S3 p.33)" },
          { k: "def", term: "Applicable region (Inglis's)", t: "High-flood-intensity areas such as the Western Ghats region of Maharashtra. (S2 p.97; S3 p.33)" },
          { k: "def", term: "Inglis's annual-runoff formula (separate from the peak-discharge formula above)", t: "R = 0.85·P − 30.5, where R and P are, respectively, the annual runoff and annual total rainfall (both in cm). Stated as applicable to the Western Ghats zone of Maharashtra. This is a distinct relation — annual runoff vs annual rainfall depth — not to be confused with the peak-discharge-vs-area formula above, even though both carry Inglis's name. (S3 p.33)" },
          { k: "cmp", t: "The four flood-peak formulas at a glance", cols: ["Constant", "Applicable region", "Area limit"], rows: [
            ["Rational: Qp = KiA (or (1/36)KiA for A in km², i in cm/hr)", "K = runoff coefficient", "Any (method itself, not formula, is regional)", "A ≤ 50 km² (S2 p.97)"],
            ["Dicken's: Qp = CD·A^(3/4)", "CD = 6–30 (S2); 6 / 6–11 / 11–14 by zone (S3)", "North & Central India", "— (S2 p.97; S3 p.32–33)"],
            ["Ryve's: Qp = CR·A^(2/3)", "CR = 6.8–10.2 (S2) vs 6–8 (S3) — both kept, see note", "South India (TN, AP, Telangana, Karnataka)", "— (S2 p.97; S3 p.33)"],
            ["Inglis's: Qp = 124A/(√A+10.4) [S2] or 124A/√(A+10.4) [S3]; ≈123√A [S2] or 124√A [S3]", "— (see conflict note)", "Western Ghats region, Maharashtra", "— (S2 p.97; S3 p.33)"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh char formulas ek hi kaam karte hain — chhote/medium catchment ke liye Qp estimate karna — bas region-specific calibration alag hai. Rational formula sabse 'physical' hai (i aur tc ka concept use karta hai, tabhi ≤50 km² tak hi reliable hai). Dicken's/Ryve's/Inglis's teeno purely <b>empirical</b> hain — Qp ko seedha A ke power se jodte hain (A^(3/4), A^(2/3), ya A ke roughly between), aur unka constant hi region ka geography/rainfall-intensity encode karta hai: North/Central India mein chhota power (3/4) aur chhota constant (6-30), South India mein chhota power (2/3), aur Western Ghats (sabse zyada flood-prone, orographic rainfall wala region) mein sabse 'aggressive' formula — Inglis's — jahan A khud numerator mein bhi aata hai." },
          { k: "trap", t: "Teeno empirical formula mein A hamesha <b>km²</b> mein lagao, hectare ya m² nahi — yeh bahut common mistake hai. Aur yaad rakho ki inke region-wise constants mein sources khud disagree karte hain (upar ke note blocks dekho) — exam mein jo bhi ek source-specific range diya ho, usi ko consistently use karo, dono ko mix mat karo." },
          { k: "real", t: "Site par yeh formulas chhote-medium pul/culvert/spillway ki design discharge estimate karne ke liye quick check ke taur par use hote hain, jab detailed hydrograph/gauge data available na ho — par jahan bhi detailed rainfall-runoff data ho, hydrograph-based method (agle chapters) zyada reliable maana jaata hai." },
        ],
      },

      /* ============================================================ 6.8 */
      {
        n: "6.8",
        title: "Quick revision — Runoff & Catchment Characteristics",
        hi: "त्वरित पुनरावृत्ति — अपधावन एवं जलसंग्रहण विशेषताएँ",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Runoff = Rainfall − Losses; Runoff coefficient C = R/P; general discharge relation Q = C·i·A (S1 p.3, 7).",
            "Six worked runoff-coefficient problems, including a weighted (area-averaged) C and two \"Check\" notes on substitution slips (S1 p.3–10).",
            "Factors affecting runoff: climatic (intensity, storm direction, wind — plus GEK additions) and catchment/physiographic (area, shape, slope, land use — S2 p.92).",
            "Fan-shaped vs fern-leaf catchment, isochrones, and their effect on hydrograph symmetry/peak timing (S2 p.92–93).",
            "Form factor FF = B/L = A/L²; compactness coefficient CC = P/(2√(πA)); elongation ratio Re (GEK) (S2 p.93–94).",
            "Drainage pattern types — dendritic, parallel, trellis, rectangular, radial, centripetal/annular, deranged (GEK).",
            "Drainage density DD = L/A; stream order (GEK rule); stream density SD = N/A (S2 p.94–95).",
            "Effect of urbanisation on runoff — earlier, sharper, higher hydrograph peak (S2 p.95).",
            "Rational formula Qp = KiA (A ≤ 50 km², t ≥ tc); Dicken's Qp = CD·A^(3/4); Ryve's Qp = CR·A^(2/3); Inglis's Qp = 124A/(√A+10.4) or ≈123–124√A, plus Inglis's separate annual-runoff formula R = 0.85P − 30.5 (S2 p.96–97; S3 p.32–33).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "C = R/P and Q = C·i·A are the two core relations behind every runoff-coefficient numerical in §6.1.",
            "Small catchment → overland-flow phase dominant; large catchment → channel-flow phase dominant (S2 p.92).",
            "FF = A/L² (↑ ⇒ channel flow dominant, less waterlogging); CC = P/(2√(πA)) (↑ ⇒ overland flow dominant, more waterlogging); CC ≥ 1 always, = 1 only for a circle (S2 p.93–94).",
            "DD = L/A, SD = N/A — both ↑ ⇒ taller, narrower (peakier) hydrograph (S2 p.94–95).",
            "Urbanisation ⇒ earlier, sharper, higher peak (less infiltration, faster drains) (S2 p.95).",
            "Rational (A≤50 km²), Dicken's (North/Central India, A^3/4), Ryve's (South India, A^2/3), Inglis's (Western Ghats/Maharashtra) — remember the region each one belongs to, and that the exact constants differ between S2 and S3 for Ryve's and Inglis's (both kept, not merged).",
          ] },
        ],
      },

    ],
  });
})();
