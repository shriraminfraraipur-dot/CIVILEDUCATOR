/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: Structural Analysis, Chapters 2–3
   Trusses · Shear force and bending moment
   Block kinds and writing rules as set out in data-hb-sa.js.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sa"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 2 */
    {
      id: "sa-2",
      n: 2,
      title: "Trusses",
      hi: "ट्रस",
      blurb: "Pin-jointed frameworks: the assumptions that make them work, how to count their determinacy, and the two methods for solving them — with the choice between the two made explicit.",
      mins: 30,
      sections: [
        {
          n: "2.1", title: "What a truss is, and the three assumptions", hi: "ट्रस क्या है, और तीन मान्यताएँ",
          blocks: [
            { k: "def", term: "Truss", t: "A framework of straight members connected at their ends, arranged so that every member carries only axial force — tension or compression — and no bending." },
            { k: "p", t: "That last phrase is the whole point of a truss, and it does not come free. It follows from three assumptions, and every one of them is an idealisation in the sense of §1.3." },
            { k: "steps", items: [
              "<strong>Members are straight</strong> and connected along their centre lines. A kinked member would bend under axial load.",
              "<strong>Joints are frictionless pins.</strong> A pin cannot transmit moment, so nothing can bend a member from its ends.",
              "<strong>Loads act only at the joints.</strong> A load hung from mid-member would bend that member directly.",
            ]},
            { k: "p", t: "Real trusses violate all three. Steel truss joints are welded or bolted gusset plates, which are far closer to rigid than to pinned. Purlins do sometimes sit between panel points. The members do have self-weight distributed along them. So why does the idealisation survive?" },
            { k: "p", t: "Because the bending it neglects is small compared with the axial force it captures. The moments caused by joint rigidity are called <em>secondary stresses</em>, and for a well-proportioned truss with slender members they are a small fraction of the axial stress. The standard practice is to design for the axial force from the pinned analysis and to detail the joints so that the secondary moments have somewhere to go — which is why IS 800 asks for the centroidal axes of members to meet at a point at every joint." },
            { k: "trap", t: "If a load genuinely must be applied between panel points, do not pretend otherwise. Analyse the truss for the equivalent panel-point loads to get the axial forces, then design that one member <em>additionally</em> as a beam spanning between its joints. Two analyses, superposed — not one analysis with the load moved." },
          ],
        },
        {
          n: "2.2", title: "The parts of a truss", hi: "ट्रस के हिस्से",
          blocks: [
            { k: "dia", id: "hb-sa-truss-anatomy" },
            { k: "list", items: [
              "<strong>Chords</strong> — the members along the top and bottom. In a simply supported truss the top chord is in compression and the bottom in tension, for the same reason the top of a simply supported beam is compressed: the truss is a beam with the middle taken out.",
              "<strong>Web members</strong> — the verticals and diagonals between the chords. They carry the shear, again exactly as the web of an I-beam does.",
              "<strong>Panel point (node)</strong> — a joint where members meet and where loads are applied.",
              "<strong>Panel length</strong> — the spacing of the panel points along a chord.",
            ]},
            { k: "p", t: "The analogy with a beam is worth holding on to, because it predicts answers before you calculate them. Chord forces come from bending, so they are largest near mid-span where the moment is largest. Web forces come from shear, so they are largest near the supports. A truss whose diagonals all look the same size near the supports and near the centre has probably not been designed, only drawn." },
            { k: "note", t: "In a Pratt truss the diagonals slope down towards the centre and end up in tension; in a Howe truss they slope the other way and end up in compression. Tension members can be slender, compression members cannot — which is why the Pratt arrangement is usually the more economical one in steel." },
          ],
        },
        {
          n: "2.3", title: "Determinacy of a truss", hi: "ट्रस की निश्चितता",
          blocks: [
            { k: "p", t: "A plane truss joint gives two equilibrium equations, not three, because a pin carries no moment. So the count differs from the frame count of §1.11." },
            { k: "eq", expr: "Ds = m + r − 2j        (plane truss)", where: [
              ["m", "Number of members"],
              ["r", "Number of reaction components"],
              ["j", "Number of joints"],
            ]},
            { k: "list", items: [
              "<strong>Ds = 0</strong> — determinate. Statics alone solves it.",
              "<strong>Ds &gt; 0</strong> — indeterminate. Extra members or extra supports; needs compatibility (Chapter 6).",
              "<strong>Ds &lt; 0</strong> — a mechanism. Not a truss at all; it will distort.",
            ]},
            { k: "eg", title: "Example 2.1 — is this truss determinate?", given: "A simply supported truss: 5 panel points along the bottom chord at A, D, E, F, B and 3 along the top at G, H, I. Members: 4 bottom chord, 2 end inclined, 2 top chord, 3 verticals, 2 diagonals. Hinge at A, roller at B.", steps: [
              { t: "Count the members", w: "bottom chord  4\nend inclined  2\ntop chord     2\nverticals     3\ndiagonals     2\n              ──\nm = 13" },
              { t: "Count joints and reactions", w: "j = 5 bottom + 3 top = 8\nr = 2 (hinge) + 1 (roller) = 3" },
              { t: "Apply the formula", w: "Ds = m + r − 2j\n   = 13 + 3 − 16\n   = 0" },
            ], ans: "Ds = 0 — statically determinate, so the method of joints or sections will solve it completely." },
            { k: "trap", t: "A zero count still does not prove stability (§1.10). A truss can have Ds = 0 and contain a four-sided panel with no diagonal, which will fold into a parallelogram. Count, then <em>look</em> — every panel needs bracing." },
          ],
        },
        {
          n: "2.4", title: "Method of joints", hi: "जोड़ विधि",
          blocks: [
            { k: "p", t: "Isolate one joint. The members meeting there pull or push on it along their own directions, and the joint must be in equilibrium. Two equations are available, ΣFx = 0 and ΣFy = 0, so a joint can be solved only if it has <strong>at most two unknown member forces</strong>." },
            { k: "dia", id: "hb-sa-joints" },
            { k: "steps", items: [
              "Find the support reactions first, from equilibrium of the whole truss.",
              "Find a joint with two or fewer unknown members — usually a support joint.",
              "Draw every unknown force pulling <em>away</em> from the joint, i.e. assume tension throughout.",
              "Write ΣFx = 0 and ΣFy = 0 and solve.",
              "Move to the next joint that now has only two unknowns, and repeat.",
              "A negative answer means compression. Do not redraw anything — just record it as compression and carry the negative sign forward.",
            ]},
            { k: "eg", title: "Example 2.2 — method of joints on a simple truss", given: "Span AB = 8 m, hinge at A (0, 0), roller at B (8, 0), bottom joint D at (4, 0) and apex C at (4, 3). Members AC, CB, AD, DB and the vertical CD. A vertical load of 20 kN acts down at C.", steps: [
              { t: "Reactions", w: "The truss and the load are symmetric about mid-span, so\nVA = VB = 20 / 2 = 10 kN ↑\n(No horizontal load, so HA = 0.)" },
              { t: "Geometry of AC", w: "AC runs from (0,0) to (4,3).\nLength = √(4² + 3²) = 5 m\ncos θ = 4/5 = 0.8   sin θ = 3/5 = 0.6" },
              { t: "Joint A — two unknowns, AC and AD", w: "ΣFy = 0:\n  10 + F(AC) × 0.6 = 0\n  F(AC) = −10 / 0.6 = −16.67 kN\n  negative → 16.67 kN COMPRESSION\n\nΣFx = 0:\n  F(AD) + F(AC) × 0.8 = 0\n  F(AD) = −(−16.67)(0.8) = +13.33 kN\n  positive → 13.33 kN TENSION" },
              { t: "Joint D — the useful one", w: "At D the members AD and DB are both horizontal, i.e. collinear, and the vertical CD is the odd one out. There is no load at D.\n\nΣFy = 0:  F(CD) = 0\n\nΣFx = 0:  F(DB) = F(AD) = 13.33 kN TENSION" },
              { t: "Joint B — check by symmetry", w: "F(CB) = F(AC) = 16.67 kN compression, by symmetry.\nVerify at joint C:\n  ΣFy: 16.67(0.6) + 16.67(0.6) = 20.0 ✓ balances the 20 kN load\n  ΣFx: 16.67(0.8) − 16.67(0.8) = 0 ✓" },
            ], ans: "AC = CB = 16.67 kN compression · AD = DB = 13.33 kN tension · CD = 0" },
            { k: "note", t: "Notice what the answer says physically. The top members push, the bottom members pull, and the vertical under the load does nothing at all for <em>this</em> loading. That last one is the subject of the next section." },
          ],
        },
        {
          n: "2.5", title: "Zero-force members", hi: "शून्य-बल सदस्य",
          blocks: [
            { k: "p", t: "Some members carry no force under a given loading, and they can be identified by inspection before any equation is written. There are three cases and they are all just ΣF = 0 applied at a joint." },
            { k: "dia", id: "hb-sa-zero" },
            { k: "list", items: [
              "<strong>Two non-collinear members, no load at the joint</strong> — both are zero. Neither can balance the other's component perpendicular to it.",
              "<strong>Three members, two of them collinear, no load at the joint</strong> — the odd member is zero, because nothing balances its perpendicular component.",
              "<strong>Two members with a load acting along one of them</strong> — the other is zero.",
            ]},
            { k: "p", t: "Spotting these first can remove a third of the arithmetic on a large truss, and it often unlocks a joint that otherwise had three unknowns." },
            { k: "trap", t: "Zero-force does not mean useless, and a student who says so in a viva loses the mark. Those members hold the compression chord in line and stop it buckling out of plane; they carry real force under a different load pattern, such as wind from the other side or a construction load; and they keep the geometry during erection. <strong>Zero here means zero for this loading only.</strong>" },
          ],
        },
        {
          n: "2.6", title: "Method of sections", hi: "सेक्शन विधि",
          blocks: [
            { k: "p", t: "Cut the truss with an imaginary plane, throw away one side, and apply all three equilibrium equations to what is left. The cut members appear as external forces on the free body. Because there are three equations, the cut should pass through <strong>no more than three unknown members</strong>." },
            { k: "dia", id: "hb-sa-sections" },
            { k: "p", t: "The real power is in the choice of moment centre. Take moments about the point where two of the three cut forces intersect, and both disappear, leaving one equation with one unknown. That is how a member in the middle of a large truss is found in a single line instead of after solving six joints." },
            { k: "eg", title: "Example 2.3 — method of sections on a parallel chord truss", given: "Span 12 m in four panels of 3 m, height 3 m. Bottom joints A(0,0), D(3,0), E(6,0), F(9,0), B(12,0); top joints G(3,3), H(6,3), I(9,3). A load of 30 kN acts down at each of D, E and F. Hinge at A, roller at B. Find the forces in the top chord GH, the bottom chord DE, and the diagonal GE.", steps: [
              { t: "Reactions", w: "Total load = 3 × 30 = 90 kN, symmetric.\nVA = VB = 45 kN ↑" },
              { t: "Take the cut", w: "Cut a vertical plane between x = 3 m and x = 6 m. It crosses exactly three members:\n  top chord GH,  diagonal GE,  bottom chord DE.\nKeep the LEFT portion: it carries VA = 45 kN at A and the 30 kN load at D." },
              { t: "Bottom chord — take moments about G (3, 3)", w: "Both GH and GE pass through G, so both vanish.\n\nΣM about G = 0, taking clockwise as positive:\n  45 × 3      (VA, lever arm 3 m)\n  − 30 × 0    (the load at D is directly below G — zero lever arm)\n  − F(DE) × 3 (bottom chord, lever arm 3 m)\n  = 0\n\n  135 = 3 F(DE)\n  F(DE) = +45 kN  →  TENSION" },
              { t: "Top chord — take moments about E (6, 0)", w: "Both GE and DE pass through E, so both vanish.\n\nΣM about E = 0:\n  45 × 6      (VA, lever arm 6 m)\n  − 30 × 3    (load at D, lever arm 3 m)\n  + F(GH) × 3 (top chord, lever arm 3 m)\n  = 0\n\n  270 − 90 + 3 F(GH) = 0\n  F(GH) = −60 kN  →  60 kN COMPRESSION" },
              { t: "Diagonal — use ΣFy on the same free body", w: "GE runs from (3,3) to (6,0): length √(9+9) = 4.243 m,\nso its vertical component is 3/4.243 = 0.707 of the force.\n\nΣFy = 0:\n  45 − 30 − 0.707 F(GE) = 0\n  F(GE) = 15 / 0.707 = +21.2 kN  →  TENSION" },
              { t: "Sense-check the three answers", w: "Top chord compression, bottom chord tension — as expected for a simply supported truss (§2.2). ✓\nDiagonal in tension — this is a Pratt arrangement, where diagonals slope down towards mid-span and take tension. ✓" },
            ], ans: "GH = 60 kN compression · DE = 45 kN tension · GE = 21.2 kN tension" },
          ],
        },
        {
          n: "2.7", title: "Choosing between the two methods", hi: "दोनों विधियों में से चुनाव",
          blocks: [
            { k: "list", items: [
              "<strong>Every member wanted</strong> → method of joints. It marches through the truss and produces all of them.",
              "<strong>One or two specific members wanted</strong> → method of sections. One cut, one moment equation, done.",
              "<strong>A member deep inside a large truss</strong> → method of sections, always. Joints would mean solving everything before it.",
              "<strong>A joint that will not open because it has three unknowns</strong> → take a section through the region to get one of them, then go back to joints.",
            ]},
            { k: "p", t: "Mixing the two freely is normal practice and not a sign of confusion. Most real solutions use a section to break into the truss and joints to finish." },
          ],
        },
        {
          n: "2.8", title: "Space trusses", hi: "त्रि-आयामी ट्रस",
          blocks: [
            { k: "p", t: "A space truss is the same idea with three dimensions. Each joint is a ball-and-socket that carries no moment, so it supplies three equations rather than two." },
            { k: "eq", expr: "Ds = m + r − 3j        (space truss)", where: [
              ["m, r, j", "Members, reaction components and joints, counted as before"],
            ]},
            { k: "p", t: "The method of joints extends directly — three equations per joint, so a joint with up to three unknown members can be solved. The arithmetic is heavier because every member force has to be resolved into three components using its direction cosines, which is why space trusses are normally handed to software. The concepts do not change at all." },
            { k: "note", t: "Roof space frames, transmission towers and microwave towers are the common Indian examples. The tetrahedron is the basic stable unit in space, exactly as the triangle is in a plane — and for the same reason: it is the smallest arrangement that cannot change shape without changing a member length." },
          ],
        },
      ],
    },

    /* ============================================================ CH 3 */
    {
      id: "sa-3",
      n: 3,
      title: "Shear Force and Bending Moment",
      hi: "अपरूपण बल और बंकन आघूर्ण",
      blurb: "The internal forces every design calculation starts from: what they are, the two derivatives that link them, how to draw the diagrams, and where the maxima sit.",
      mins: 32,
      sections: [
        {
          n: "3.1", title: "Internal forces at a section", hi: "किसी सेक्शन पर आंतरिक बल",
          blocks: [
            { k: "p", t: "Cut a loaded beam at any section and look at the left-hand piece on its own. It is not in equilibrium by itself — the piece you removed was holding it. Whatever that missing piece was doing must be replaced by forces on the cut face, and there are exactly three of them in a plane." },
            { k: "dia", id: "hb-sa-internal" },
            { k: "list", items: [
              "<strong>Axial force N</strong> — along the member. Zero in a beam with only transverse loads, which is why it is usually ignored there and never in a frame.",
              "<strong>Shear force V</strong> — across the member. The algebraic sum of all transverse forces on one side of the section.",
              "<strong>Bending moment M</strong> — the algebraic sum of the moments of all forces on one side, taken about the section.",
            ]},
            { k: "def", term: "Shear force at a section", t: "The algebraic sum of all vertical forces on either side of that section." },
            { k: "def", term: "Bending moment at a section", t: "The algebraic sum of the moments about that section of all forces on either side of it." },
            { k: "p", t: "\"Either side\" is not a loose phrase — it is a free check. The two sides must give the same answer, because the whole beam is in equilibrium. Working from the shorter side is faster; working from the other side afterwards is the cheapest verification in the subject." },
          ],
        },
        {
          n: "3.2", title: "The two relationships that do the work", hi: "दो संबंध जो पूरा काम करते हैं",
          blocks: [
            { k: "p", t: "Take a small element of beam of length dx carrying a distributed load w. Vertical equilibrium of that element gives one relationship and moment equilibrium gives the other." },
            { k: "eq", expr: "dV / dx = − w        dM / dx = V", where: [
              ["w", "Intensity of distributed load at that point, downward positive"],
              ["V", "Shear force at that section"],
              ["M", "Bending moment at that section"],
            ]},
            { k: "p", t: "Read them as statements about slopes and they become a drawing technique rather than calculus. The load is the slope of the shear diagram; the shear is the slope of the moment diagram. Three consequences follow immediately, and between them they let you draw both diagrams without integrating anything." },
            { k: "steps", items: [
              "Where there is <strong>no load</strong>, V is constant and M is a straight line.",
              "Where there is a <strong>uniform load</strong>, V is a straight line and M is a parabola.",
              "Where <strong>V = 0</strong>, M has zero slope — so the maximum moment occurs where the shear crosses zero.",
            ]},
            { k: "dia", id: "hb-sa-relations" },
            { k: "p", t: "The third consequence is the one worth carrying into every problem. Finding the maximum bending moment never requires differentiating the moment expression — it requires finding where the shear diagram crosses the axis, which is usually a single line of arithmetic." },
            { k: "note", t: "A concentrated load has no width, so it makes V jump by the value of the load and puts a kink in M. A concentrated moment applied to the beam makes M jump and leaves V untouched. Both follow from the same two equations applied over a vanishing length." },
          ],
        },
        {
          n: "3.3", title: "Drawing the diagrams", hi: "आरेख बनाना",
          blocks: [
            { k: "steps", items: [
              "Find the reactions from equilibrium of the whole beam, and check them.",
              "Start at the left end and walk right, adding each upward force and subtracting each downward one, to build V.",
              "Mark every point where V crosses zero — those are your candidate maxima for M.",
              "Build M by area: the change in M between two sections equals the <em>area of the shear diagram</em> between them.",
              "Check the ends: M must be zero at a simple support or a free end, and equal to the applied couple where one acts.",
              "Sketch the elastic curve alongside (§1.13) and confirm the points of contraflexure line up with the zeros of M.",
            ]},
            { k: "p", t: "Step 4 is the one students skip and then regret. Because dM/dx = V, integrating gives M(b) − M(a) = ∫V dx, which is just the area under the shear diagram. For a triangle or a rectangle that is mental arithmetic, and it avoids writing a moment expression for each segment." },
            { k: "trap", t: "Signs at the supports. A downward reaction — which happens on the unloaded span of an overhanging beam — is easy to write as upward out of habit, and it inverts the whole diagram. When a reaction comes out negative, mark it on the sketch pointing the way the arithmetic says, not the way it \"should\" go." },
          ],
        },
        {
          n: "3.4", title: "The standard cases", hi: "मानक स्थितियाँ",
          blocks: [
            { k: "p", t: "These three are worth knowing without derivation, because almost everything else is built by superposing them." },
            { k: "dia", id: "hb-sa-standard" },
            { k: "eq", expr: "SS beam, UDL w :        V(max) = wL/2 at the supports,    M(max) = wL²/8 at mid-span", where: [] },
            { k: "eq", expr: "SS beam, central W :     V = W/2 throughout,               M(max) = WL/4 at mid-span", where: [] },
            { k: "eq", expr: "Cantilever, UDL w :      V(max) = wL at the fixed end,     M(max) = wL²/2 at the fixed end", where: [] },
            { k: "eg", title: "Example 3.1 — simply supported beam under UDL, from first principles", given: "Span 6 m, simply supported, carrying a uniformly distributed load of 12 kN/m over the whole span.", steps: [
              { t: "Reactions", w: "Total load = 12 × 6 = 72 kN, symmetric.\nVA = VB = 36 kN ↑" },
              { t: "Shear at distance x from A", w: "V(x) = 36 − 12x\n\nAt x = 0:  V = +36 kN\nAt x = 6:  V = 36 − 72 = −36 kN\nLinear in between — matching dV/dx = −w = −12." },
              { t: "Where does V cross zero?", w: "36 − 12x = 0\nx = 3 m  (mid-span, as symmetry demanded)\nThis is where M is maximum." },
              { t: "Moment at distance x", w: "M(x) = 36x − 12x(x/2) = 36x − 6x²\n\nAt x = 3:\n  M = 36(3) − 6(9) = 108 − 54 = 54 kNm" },
              { t: "Check against the standard formula", w: "wL²/8 = 12 × 36 / 8 = 54 kNm ✓" },
              { t: "Check by the area rule", w: "Area of the shear diagram from 0 to 3 m\n  = ½ × 3 × 36 = 54 kNm\nSame answer without writing M(x) at all. ✓" },
            ], ans: "V(max) = ±36 kN at the supports · M(max) = 54 kNm at mid-span" },
          ],
        },
        {
          n: "3.5", title: "Overhanging beams and the point of contraflexure", hi: "ओवरहैंग बीम और कॉन्ट्राफ्लेक्शर बिंदु",
          blocks: [
            { k: "p", t: "An overhang changes the character of the problem. The cantilevered part hogs, the span sags, and somewhere between them the moment passes through zero. That crossing is the point of contraflexure, and it is where the tension face moves from the bottom of the beam to the top." },
            { k: "dia", id: "hb-sa-overhang" },
            { k: "eg", title: "Example 3.2 — overhanging beam, locating the contraflexure point", given: "Beam ABC. Support A at x = 0, support B at x = 6 m, and the beam continues as an overhang to C at x = 8 m. A uniformly distributed load of 10 kN/m runs over the full 8 m.", steps: [
              { t: "Reactions", w: "Total load = 10 × 8 = 80 kN, acting at the centroid of the load, x = 4 m.\n\nΣM about A = 0:\n  80 × 4 = VB × 6\n  VB = 320 / 6 = 53.33 kN ↑\n\nΣFy = 0:\n  VA = 80 − 53.33 = 26.67 kN ↑" },
              { t: "Moment inside the span (0 ≤ x ≤ 6)", w: "M(x) = 26.67 x − 10 x (x/2)\n     = 26.67 x − 5 x²" },
              { t: "Where is the sagging maximum?", w: "It is where V = 0:\n  V(x) = 26.67 − 10x = 0\n  x = 2.667 m\n\nM = 26.67(2.667) − 5(2.667)²\n  = 71.11 − 35.56\n  = 35.56 kNm  sagging" },
              { t: "Moment at the support B", w: "Easiest from the overhang side — only the 2 m of load beyond B matters:\n  M(B) = − 10 × 2² / 2 = − 20 kNm  hogging\n\nCheck from the left:\n  M = 26.67(6) − 5(36) = 160 − 180 = −20 kNm ✓" },
              { t: "Point of contraflexure", w: "Set the span expression to zero:\n  26.67 x − 5 x² = 0\n  x (26.67 − 5x) = 0\n  x = 0   or   x = 5.333 m\n\nx = 0 is the support itself, so the contraflexure point is at\n  x = 5.33 m from A — that is 0.67 m to the left of support B." },
            ], ans: "VA = 26.67 kN, VB = 53.33 kN · M(max sagging) = 35.56 kNm at 2.67 m · M at B = −20 kNm · point of contraflexure 5.33 m from A" },
            { k: "trap", t: "The hogging moment at B came out of the overhang alone, which is worth noticing: <strong>the overhang's moment does not care about the span at all.</strong> Lengthen the overhang and the hogging at B grows as its square, while the sagging in the span shrinks. Long enough, and the whole span goes into hogging — and a beam detailed for a sagging span will be wrong from end to end." },
          ],
        },
        {
          n: "3.6", title: "Beams with internal hinges", hi: "आंतरिक कब्ज़े वाली बीम",
          blocks: [
            { k: "p", t: "An internal hinge adds one equation, because the bending moment at a hinge is zero by definition. That is exactly what makes some multi-span beams determinate when they look as though they should not be." },
            { k: "eq", expr: "At an internal hinge:   M = 0        (V and N pass through unchanged)", where: [] },
            { k: "steps", items: [
              "Count the unknowns: reactions plus, if the beam is in pieces, the interface forces.",
              "Count the equations: three for the whole beam, plus one extra for every internal hinge.",
              "If they match, the beam is determinate — split it at the hinges and analyse the pieces in order.",
              "Always start with the piece that is supported at both ends. It is stable on its own, and its reaction becomes the load on the next piece.",
            ]},
            { k: "note", t: "This is a real construction form, not an exam device. Cantilever-and-suspended-span bridge decks work exactly this way: two cantilever arms with a simply supported drop-in span hung between them on hinges. The hinges keep the structure determinate, so differential settlement of the piers causes no stress at all (§1.9)." },
          ],
        },
        {
          n: "3.7", title: "Frames — the same three quantities", hi: "फ्रेम — वही तीन राशियाँ",
          blocks: [
            { k: "p", t: "A frame is not a new subject. Every member of it still carries N, V and M, and they are still found by cutting and applying equilibrium. Three practical differences are worth stating." },
            { k: "list", items: [
              "<strong>Axial force stops being negligible.</strong> Columns carry substantial axial load, so N must be tracked in every member.",
              "<strong>Each member needs its own local axes.</strong> \"Vertical shear\" is meaningless in a column; shear is always perpendicular to the member, whatever direction the member runs.",
              "<strong>At a rigid joint, moments must balance.</strong> The member end moments meeting at a joint sum to zero — this is the equation the displacement methods of Chapters 7 and 8 are built on.",
            ]},
            { k: "p", t: "The usual convention for drawing a frame's bending moment diagram is to plot it on the <strong>tension side</strong> of each member. It removes all ambiguity about which way is \"positive\" on a column, and it tells the detailer where the steel goes without any further interpretation — which is the entire reason the diagram is drawn." },
            { k: "trap", t: "Drawing a frame BMD on the compression side, or switching sides between members, produces a drawing that is arithmetically right and practically useless. Fix the tension-side convention at the start and hold it through every member, including the columns." },
          ],
        },
      ],
    }

  );
})();
