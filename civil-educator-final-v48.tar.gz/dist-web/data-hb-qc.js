/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: MATERIAL TESTING & QUALITY CONTROL
   ------------------------------------------------------------
   The thirteenth handbook, and the lab companion: for every
   material, why the test is done, what value it should give, and
   which code governs it. Written for the lab file and the viva as
   much as for the site.

   One idea runs through it: a test judges a whole lot from a tiny
   sample, and a decision (accept or reject) rests on it — so the
   sample must be fair, the method standard, and the acceptance
   rule statistical, not a single lucky or unlucky result.

   Test methods follow IS 4031 (cement), IS 2386 (aggregate),
   IS 516/IS 456 (concrete), IS 2720 (soil) and IS 1077 (brick)
   where they govern, named at the point of use. Confirm against
   the current code before using a value on real work.

   Chapters 1–3 here; later chapters follow in data-hb-qc2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "qc",
  subject: "testing-qc",
  name: "Material Testing & QC",
  hi: "सामग्री परीक्षण एवं गुणवत्ता",
  icon: "🔬",
  blurb: "Har test kyun kiya jata hai, kya value aani chahiye, kis code se — lab file, viva aur site quality control ke liye.",
  note: "Test methods and limits follow IS 4031, IS 2386, IS 516/456, IS 2720 and IS 1077 where they apply, named at the point of use. Acceptance constants must be read from the current code; those quoted are the commonly-cited values and are flagged as such.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "qc-1",
      n: 1,
      title: "Why We Test, and the Fair Sample",
      hi: "हम परीक्षण क्यों करते हैं",
      blurb: "What a test is really for, why a decision rests on it, and why the whole thing collapses if the sample does not represent the lot.",
      mins: 16,
      sections: [
        {
          n: "1.1",
          title: "A test exists to make a decision",
          hi: "परीक्षण निर्णय के लिए है",
          blocks: [
            { k: "p", t: "Testing is not a ritual to fill a lab file — every test exists to answer a question that a decision rests on. Is this cement fit to use? Is this concrete strong enough to accept, or must it be rejected? Is this soil good enough to found on? The test converts a material into a number, and the number decides an action. Keeping that in view is what separates understanding a test from merely performing it." },
            { k: "list", items: [
              "<strong>What is being decided</strong> — accept or reject, this grade or that, use it or send it back.",
              "<strong>What value is expected</strong> — every test has a limit or a range that means 'pass', set by the code or the specification.",
              "<strong>Which code governs</strong> — the standard method (how to test) and often the acceptance value (what passes).",
            ] },
            { k: "note", t: "This is the frame for every test in the handbook, and it is exactly what a viva examiner probes: not 'how do you do the test' but 'why, what should it read, and what do you do with the answer'. A test you can perform but cannot explain the purpose of is a test you do not really know." },
          ],
        },
        {
          n: "1.2",
          title: "The fair sample",
          hi: "निष्पक्ष नमूना",
          blocks: [
            { k: "p", t: "Every test judges a whole lot — a truckload of sand, a day's concrete, a heap of aggregate — from a tiny portion. So before any test method matters, the sample must represent the lot. A biased sample makes even a perfectly performed test worthless, because it tells you about the wrong thing." },
            { k: "dia", id: "hb-qc-sampling", cap: "Taking a representative sample, and reducing it by quartering." },
            { k: "def", term: "Representative sample", t: "A sample whose properties match the whole lot it stands for. It is obtained by taking small increments from many random points across the lot, combining them, and reducing the combined mass by quartering (repeatedly splitting into four and keeping opposite quarters) down to the quantity to be tested." },
            { k: "trap", t: "The tempting shortcut — grabbing the sample from one easy, clean spot, or from the good-looking top of a heap — is exactly how testing goes wrong. Materials segregate: the fines settle, the coarse rolls to the edges, the wet is at the bottom. A sample from one spot measures that spot, not the lot, and no amount of careful lab work rescues it. <strong>Sampling error cannot be undone by testing accuracy.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "qc-2",
      n: 2,
      title: "Cement Tests",
      hi: "सीमेंट परीक्षण",
      blurb: "The four tests that grade a cement, what each answers, and the values that mean pass.",
      mins: 20,
      sections: [
        {
          n: "2.1",
          title: "Four tests, four questions",
          hi: "चार परीक्षण",
          blocks: [
            { k: "p", t: "The cement test suite (IS 4031) is four separate questions, and a cement can pass one while failing another — so all four are run before a cement is trusted." },
            { k: "dia", id: "hb-qc-cement", cap: "The four cement tests and what each answers." },
            { k: "cmp", t: "The cement tests",
              cols: ["Answers / expected"],
              rows: [
                ["Fineness", "how finely ground → speed of hydration, heat"],
                ["Consistency & setting time", "working time — initial ≥ 30 min, final ≤ 600 min (OPC)"],
                ["Soundness (Le Chatelier)", "will it expand later? — expansion within the code limit"],
                ["Compressive strength", "the grade (33/43/53) — 28-day mortar-cube strength"],
              ] },
            { k: "note", t: "The two that catch people in a viva are soundness and setting time. Soundness is not about strength — it checks that free lime or magnesia will not make the set cement expand and crack from within later. Setting time is the working window: initial set (≥ 30 min) is when you must have finished placing; final set (≤ 600 min) is when it has stiffened. Neither is the strength test, and confusing them is a classic slip." },
          ],
        },
        {
          n: "2.2",
          title: "Reading the results",
          hi: "परिणाम पढ़ना",
          blocks: [
            { k: "p", t: "A cement result is judged against the limit for its grade, and the tests interconnect — a very fine cement gains early strength but generates more heat and may set faster, so the numbers are read together, not in isolation." },
            { k: "trap", t: "A field storage check belongs beside the lab tests: cement that has picked up moisture in storage partly hydrates in the bag ('air-set'), forms hard lumps, and loses strength before it is ever tested. A bag with lumps that will not crush to powder between the fingers is rejected on sight — no lab test needed. The best cement, badly stored, fails; and the failure often shows first as lumps, not as a low cube." },
            { k: "real", t: "The 7-day cube is the early-warning test worth running even though 28 days is the acceptance age. Concrete (and cement mortar) gains most of its strength early, so a 7-day result well below the expected fraction of the grade is a red flag you get three weeks before the formal 28-day verdict — time to investigate the cement, the mix or the curing before more is placed. <strong>A good QC regime reads the 7-day result as a warning, not just a formality.</strong>" },
            { k: "note", t: "The IS 269:2015 requirements for each OPC grade — fineness, setting times, soundness and 3/7/28-day strengths — are tabulated, with a worked compliance check, in <a href=\"#/read/ct/2\">Concrete Technology, Chapter 2</a>." },
          ],
        },
      ],
    },

    /* ============================================================ CH 3 */
    {
      id: "qc-3",
      n: 3,
      title: "Aggregate Tests",
      hi: "गिट्टी परीक्षण",
      blurb: "The strength, shape, cleanliness and grading tests on aggregate, and why road aggregate is tested harder than concrete aggregate.",
      mins: 20,
      sections: [
        {
          n: "3.1",
          title: "What aggregate is tested for",
          hi: "गिट्टी किसलिए परखी जाती है",
          blocks: [
            { k: "p", t: "Aggregate is most of the concrete and most of a pavement, so its quality decides most of the result. The tests (IS 2386) fall into four groups — strength, shape, cleanliness and grading — and which you run depends on where the aggregate is going." },
            { k: "cmp", t: "The aggregate tests",
              cols: ["Test & why"],
              rows: [
                ["Strength", "crushing value, impact value — resist load & pounding"],
                ["Shape", "flakiness & elongation index — flat/long pieces are weak"],
                ["Cleanliness", "silt content, deleterious materials — dirt kills the bond"],
                ["Grading", "sieve analysis → fineness modulus — a good size spread"],
                ["Wear (roads)", "Los Angeles abrasion — resist grinding under traffic"],
              ] },
            { k: "def", term: "Flakiness and elongation", t: "A flaky particle is thin relative to its other dimensions; an elongated one is long. Both are weak (they snap under load) and pack poorly, leaving voids. The flakiness and elongation indices measure the proportion of such particles, and specifications cap them — good aggregate is roughly cubical, not slabby or needle-like." },
            { k: "list", items: [
              "<strong>Aggregate crushing value</strong> — not more than 30% for concrete in roads and pavements, 45% for other structures.",
              "<strong>Aggregate impact value</strong> — not more than 30% for wearing surfaces (runways, roads, pavements), 45% for other concrete.",
              "<strong>Elongated particles</strong> — more than 10–15% is generally considered undesirable, though the same source notes no recognised limit.",
            ] },
            { k: "note", t: "Limits as stated in <a href=\"https://www.rcet.org.in/uploads/academics/regulation2024/rohini_63946600966.pdf\" target=\"_blank\" rel=\"noopener\">RCET notes</a> (IS 383 / IS 2386). Los Angeles abrasion and combined flakiness–elongation limits are set in IS 383:2016 and, for roads, in the MoRTH specification; they are not quoted here because a second source could not be checked." },
            { k: "eg", title: "Example 3.1 — Impact and crushing values",
              given: "Impact test: oven-dry sample 350 g; after 15 blows, 52 g passes the 2.36 mm sieve. Crushing test: sample 2950 g; after loading to 400 kN, 620 g passes 2.36 mm.",
              steps: [
                { t: "Aggregate impact value", w: "AIV = 52/350 × 100 = 14.9%" },
                { t: "Aggregate crushing value", w: "ACV = 620/2950 × 100 = 21.0%" },
                { t: "Judge", w: "both ≤ 30% → acceptable even for a wearing surface" },
              ],
              ans: "AIV 14.9%, ACV 21.0% — a tough aggregate, fit for road and pavement concrete. A lower value is better in both tests: they measure how much the stone breaks down." },
          ],
        },
        {
          n: "3.2",
          title: "Road aggregate is tested harder",
          hi: "सड़क की गिट्टी अधिक कड़ाई से",
          blocks: [
            { k: "p", t: "Aggregate for a road surface takes direct, repeated tyre contact and impact, which concrete aggregate (buried in paste) does not — so it faces extra, tougher tests." },
            { k: "list", items: [
              "<strong>Los Angeles abrasion</strong> — tumbles the aggregate with steel balls to measure resistance to the grinding wear of traffic.",
              "<strong>Aggregate impact value</strong> — resistance to the sudden pounding of wheels, more relevant than steady crushing on a road.",
              "<strong>Polished stone value</strong> — how much the aggregate polishes smooth under traffic; a low value keeps the surface skid-resistant.",
              "<strong>Soundness</strong> — resistance to weathering (freeze-thaw, salt), for exposed surfaces.",
            ] },
            { k: "trap", t: "Skid resistance is a separate property from strength, and the polished stone value catches it. An aggregate can be perfectly strong and still polish to a dangerous, slippery smoothness under years of traffic — strong but slick. This is why the wearing course of a road specifies the polished stone value, not just the crushing value: keeping the road intact and keeping vehicles gripping it are two different requirements needing two different tests." },
          ],
        },
      ],
    },

  ],
});
