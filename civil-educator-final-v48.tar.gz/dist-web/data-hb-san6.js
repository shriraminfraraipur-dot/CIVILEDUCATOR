/* ============================================================
   STRUCTURAL ANALYSIS · COMPLETE NOTES — Chapter 12
   Moment Distribution Method (Hardy Cross Method)
   Sources: T = Theory of Structures notes (T p.76–93, CH-04/MDM)
            V = Structural Analysis notes, Vivek Gupta / MADE EASY
                (V p.143–180, Ch.7 "Moment Distribution Method")
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "san");
  if (!hb) { console.error("[san6] handbook san not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 12 */
    {
      id: "san-12",
      n: 12,
      title: "Moment Distribution Method",
      hi: "मोमेंट वितरण विधि (Moment Distribution Method)",
      blurb: "Hardy Cross ki iterative method — stiffness aur joint stiffness se distribution factor, saare carry-over-factor cases, standard fixed-end moments, bina sway wali beams/frames, modified MDM aur symmetry ka shortcut, aur pura sway-frame solution with R aur R′ correction factor — sab worked examples ke saath.",
      mins: 30,
      sections: [

        /* ------------------------------------------------ 12.1 */
        {
          n: "12.1",
          title: "Stiffness, joint stiffness and distribution factor",
          hi: "दृढ़ता (स्टिफनेस), संयुक्त दृढ़ता और वितरण गुणांक",
          blocks: [
            { k: "h", t: "📘 Notes — T p.76–84, V p.143–146" },
            { k: "p", t: "Moment Distribution Method (aka <b>Relaxation method</b>) was developed by <b>Hardy Cross</b>. It is highly suitable for plane frames and continuous beams. In this method we solve the equilibrium equations directly — <b>without</b> first finding θ and δ — and get member end moments straightaway. It is basically <b>iterative</b> in nature (same process repeats). (T p.77–78)" },
            { k: "list", items: [
              "Basic idea (V p.143): the analysis begins by assuming <b>every joint is locked</b> (fixed). Joints are then unlocked and locked in succession, and the internal moments at the joints are distributed and balanced until the joints rotate to their final (or nearly final) position.",
              "If two members meeting at a joint have EI₁ &gt; EI₂, then M_BC &gt; M_BA — the <b>stiffer member attracts more moment</b>. (V p.143)",
            ] },
            { k: "def", term: "Stiffness", t: "Force or moment required to produce a <b>unit</b> displacement (deflection or rotation) is called stiffness. (V p.144)" },
            { k: "h", t: "Member (bending) stiffness — two cases" },
            { k: "eq", expr: "Case 1 — far end FIXED (propped cantilever):  θ = Mℓ/4EI  ⇒  K = M/θ = 4EI/ℓ", where: [
              ["derivation (T p.79)", "K = m/θ = m/(mℓ/4EI) = 4EI/ℓ"],
              ["derivation (V p.144)", "found by strain-energy method: R = −1.5M/ℓ (from Δ₁+Δ₂=0), M_x = M − 1.5Mx/ℓ, then ∫M_x(∂M_x/∂M)dx/EI = θ gives θ = Mℓ/4EI"],
            ] },
            { k: "eq", expr: "Case 2 — far end HINGED/PINNED (simply supported):  θ = Mℓ/3EI  ⇒  K = M/θ = 3EI/ℓ", where: [
              ["T p.79", "θ = mℓ/3EI, K = 3EI/ℓ"],
              ["V p.143", "θ = ML/3EI for a simply supported beam with M applied at one hinged end"],
            ] },
            { k: "cmp", t: "Member stiffness factor — T's summary table (T p.79)", cols: ["Member stiffness factor", "Relative member stiffness factor"], rows: [
              ["Far end is fixed", "4EI/ℓ", "I/ℓ"],
              ["Far end is hinged/pinned", "3EI/ℓ", "3I/4ℓ"],
            ] },
            { k: "h", t: "Joint stiffness factor" },
            { k: "eq", expr: "K_joint = Σ (member stiffness factor of every member meeting at that joint)", where: [
              ["free/unsupported far end", "contributes 0 to the sum"],
            ] },
            { k: "p", t: "Example (V p.145): for a T-frame with AB fixed at A (far end fixed, K=4EI/L), BC roller at C (far end pinned, K=3EI/L) and a vertical member BD also far-end-pinned (K=3EI/L), all of length L meeting at joint B: K_B = K_BA + K_BC + K_BD = 4EI/L + 3EI/L + 3EI/L = <b>10EI/L</b>." },
            { k: "eg", title: "Rotational stiffness of a rigid joint O (T p.81)",
              given: "Rigid frame, EI = constant, four members meet at joint O: OA (length ℓ, fixed at A), OC (length ℓ, fixed at C), OD (length ℓ, free end D — no support), OB (length ℓ, hinged support at B). Find K₀.",
              steps: [
                { t: "Add each member's stiffness factor", w: "OA far-end fixed → 4EI/ℓ\nOC far-end fixed → 4EI/ℓ\nOD free end → 0\nOB far-end hinged → 3EI/ℓ" },
                { t: "Sum", w: "K₀ = 4EI/ℓ + 4EI/ℓ + 0 + 3EI/ℓ" },
              ],
              ans: "K₀ = 11EI/ℓ" },
            { k: "h", t: "Distribution factor" },
            { k: "eq", expr: "DF_(member) = K_(member) / K_joint", where: [
              ["at a joint", "Σ of all DF values meeting there = 1"],
              ["fixed support", "DF = 0 (T p.86 'Most Imp Note ①')"],
              ["hinged/free/roller end support", "DF = 1 (T p.86 'Most Imp Note ②')"],
            ] },
            { k: "eg", title: "Distribution factors and support moment — GATE-style (T p.83–84)",
              given: "Frame with central joint O: OP horizontal, ℓ=3 m, P is a hinge/roller support; OR horizontal, ℓ=4 m, R is a fixed support; a vertical stub of ℓ=2 m up from O to a free end; OQ vertical, ℓ=2 m down, Q is a fixed support. A moment 100 kN·m is applied at joint O. Find the moment at support Q.",
              steps: [
                { t: "Joint stiffness K₀", w: "K₀ = K_OQ (far-fixed, 4EI/2) + K_OR (far-fixed, 4EI/4) + K_OP (far-hinged, 3EI/3) + 0 (free stub)\n= 2EI + EI + EI + 0 = 4EI" },
                { t: "Distribution factors", w: "DF_OP = (3EI/3)/4EI = 1/4\nDF_OR = (4EI/4)/4EI = 1/4\nDF_OQ = (4EI/2)/4EI = 1/2" },
                { t: "Distribute the applied moment", w: "M_OP = 100 × 1/4 = 25 kN·m\nM_OR = 100 × 1/4 = 25 kN·m\nM_OQ = 100 × 1/2 = 50 kN·m" },
                { t: "Carry over to the fixed support Q", w: "M_Q = M_OQ/2 = 50/2 = 25 kN·m   (COF = 1/2 towards a fixed far end)" },
              ],
              ans: "M_Q = 25 kN·m. (M_P = 0 due to the hinge, M at the free stub end = 0.)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Stiffness answers the question 'how much moment do I need to rotate this member by 1 radian?' — a fixed far end resists more (4EI/ℓ) than a pinned far end (3EI/ℓ), because a pinned far end lets some of the rotation 'leak' through as far-end rotation instead of being fully resisted at the near end. Distribution factor is then just each member's <b>share</b> of the joint's total stiffness — exactly like splitting a bill in proportion to how much each person can 'pay' (resist)." },
            { k: "trap", t: "When a beam's far support is a roller/hinge (not the fixed far end of a rigid frame), its <b>relative</b> stiffness for the DF table must use the reduced factor 3I/4ℓ (T p.79), not I/ℓ — mixing the two gives a wrong DF and every following number is wrong." },
          ],
        },

        /* ------------------------------------------------ 12.2 */
        {
          n: "12.2",
          title: "Carry-over factor",
          hi: "कैरी-ओवर गुणांक",
          blocks: [
            { k: "h", t: "📘 Notes — T p.76–77, V p.147–149" },
            { k: "def", term: "Carry-over factor (COF)", t: "The ratio of the moment transferred (carried over) at the far end to the moment applied at the near end: COF = M_far/M_near. (V p.147, T: 'COF = Carry factor load/Applied load')" },
            { k: "eq", expr: "Far end FIXED:  COF = 1/2", where: [
              ["T p.76", "θ = M₀ℓ/4EI at B; the fixed end A takes M_A = M₀/2 ⇒ COF = (M₀/2)/M₀ = 1/2"],
              ["V p.147, Ex.1", "propped cantilever, moment M applied at the hinged end; FBD gives R₃ = M/2 at the fixed end ⇒ COF = 1/2"],
            ] },
            { k: "eq", expr: "Far end HINGED/PINNED:  COF = 0", where: [
              ["T p.76", "'hinge ke vajah se CF = 0' — the hinge cannot transmit any moment"],
            ] },
            { k: "note", t: "<b>A distinct edge case (T p.76, case ③):</b> a rigid frame with both A and B already fixed supports, and the moment M₀ applied directly <i>at</i> the fixed support B (not at a joint that can rotate). Here COF = 0 as well, but for a different reason — 'because fixed support (B) it will take whole (M₀)': since B itself cannot rotate, nothing is available to carry over to A." },
            { k: "eg", title: "Carry-over factor when the hinge sits exactly at mid-span (V p.148–149)",
              given: "Beam A–B, total length L; hinge/roller support at A; internal hinge C at the exact mid-span (L/2 from each end); fixed support at B. Moment M applied at A. Find COF (B/A).",
              steps: [
                { t: "Free body of A–C, ΣM_C = 0 (moment at internal hinge = 0)", w: "M + R₁ × L/2 = 0  ⇒  R₁ = −2M/L" },
                { t: "Free body of whole beam, ΣM_B = 0", w: "R₄ + M + R₁ × L = 0\nR₄ = −M − R₁L = −M + (2M/L)×L = M" },
                { t: "COF", w: "CO_(B/A) = M_B/M_A = R₄/M = M/M" },
              ],
              ans: "COF = 1 (when the internal hinge is exactly at mid-span, the full moment is carried over)." },
            { k: "eq", expr: "General case — internal hinge at distance a from the near support, b from the far fixed end:  COF = b/a  (b > a  ⇒  COF > 1)", where: [
              ["V p.149 ★Note", "'Carry over factor may be positive, negative and greater than 1 also' — quoted verbatim"],
            ] },
            { k: "note", t: "T's mirror-image case (T p.77, case ④) has A fixed, an internal hinge at distance a from A and b from B, with the moment M₀ applied at the far (roller) end B. Free-body of A–C with M_c = 0 at the hinge gives the moment carried into the fixed end A as M_c = (M₀·a)/b, so COF(A/B) = a/b — the same b/a rule as V's, just written for the opposite direction of travel." },
            { k: "eq", expr: "Cantilever (fixed at the far end, free at the near end where the moment is applied):  COF = M_B/M_A = −M/M = −1  (V p.149)" },
            { k: "list", items: [
              "COF = 1/2 — far end fixed (the ordinary, most-used case).",
              "COF = 0 — far end hinged/pinned, OR the moment is applied directly at an already-fixed support.",
              "COF = 1 — internal hinge exactly at the member's mid-span.",
              "COF = b/a (&gt; 1 if b &gt; a) — internal hinge off-centre, general case.",
              "COF = −1 — plain cantilever, moment applied at the free end.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "COF is only ever 1/2 when the far end is a 'normal' fixed support — the moment T-shape has already been derived assuming that. The moment an internal hinge sits away from the middle changes how much of the near-end moment 'survives the trip' to the far end, which is why COF can become 1, greater than 1, or even negative for a cantilever (where the whole moment reappears at the fixed base but with the opposite rotational sense, hence the minus sign)." },
            { k: "trap", t: "Do not assume COF = 1/2 everywhere. Always look at what the far end actually is: fixed support (1/2), hinge/roller (0), internal hinge (use b/a for that specific span), or a plain cantilever base (−1)." },
          ],
        },

        /* ------------------------------------------------ 12.3 */
        {
          n: "12.3",
          title: "Fixed-end moments and the MDM-without-sway procedure",
          hi: "स्थिर सिरा आघूर्ण (FEM) और बिना स्वे MDM की प्रक्रिया",
          blocks: [
            { k: "h", t: "📘 Notes — T p.85, p.88, V p.149–150" },
            { k: "h", t: "Standard fixed-end moments used across both sources' worked examples" },
            { k: "eq", expr: "UDL w over the full span, both ends fixed:  M_AB = −wℓ²/12  ,  M_BA = +wℓ²/12", where: [["ℓ", "span length"]] },
            { k: "eq", expr: "Point load P at mid-span, both ends fixed:  M_AB = −Pℓ/8  ,  M_BA = +Pℓ/8" },
            { k: "eq", expr: "Point load P at distance a from A and b from B (a+b=ℓ), both ends fixed:  M_AB = −Pab²/ℓ²  ,  M_BA = +Pa²b/ℓ²", where: [["worked check (T p.88)", "P=120 kN, a=2 m, b=1 m, ℓ=3 m ⇒ M_A = 120×2×1²/9 = 26.67 kN·m, M_B = 120×2²×1/9 = 53.33 kN·m — matches T's boxed values"]] },
            { k: "note", t: "Sign convention (T p.88): 'सभी clockwise लेते हैं' — all moments are taken clockwise-positive. A hogging (sagging-opposing) end moment from a downward load is therefore written negative at the near end and positive at the far end, matching both T and V throughout." },
            { k: "h", t: "The nine steps of MDM without sway (V p.149)" },
            { k: "steps", items: [
              "Calculate the kinematic indeterminacy (KI) and identify the unknown joint rotations.",
              "Lock every KI (assume all joints fixed) and calculate the FEM for each member.",
              "Calculate the distribution factor corresponding to each KI.",
              "Release one KI at a time and allow it to rotate under the unbalanced moment at that joint; distribute the unbalanced moment as per the distribution factor.",
              "Transfer the carry-over moment to the far ends.",
              "Check the unbalanced moment at every KI again — if any joint is still unbalanced, repeat steps 4–6 till all joints are balanced within the tolerance limit.",
              "Add up all moments (FEM, distribution moment, carry-over moment) at each end of every member.",
              "Draw the BMD using the end moments from step 7, by the method of superposition (free BMD + closing line).",
              "Calculate the other reactions and draw the SFD.",
            ] },
            { k: "list", items: [
              "'Most Imp Note' (T p.86): ① a fixed end has DF = 0. ② a hinged/roller end has DF = 1.",
              "'Continuous hinged/roller supports are treated as fixed [for the FEM step], because they take bending moment' (T p.89) — the FEM formulas above are used first assuming every joint is locked, and the actual support condition (fixed / hinge / roller) is only brought in through the DF and COF of the release steps that follow.",
            ] },
            { k: "eg", title: "Propped cantilever under UDL, solved by MDM (T p.85–86)",
              given: "Beam A–B, span ℓ, EI constant; A fixed, B a hinge/roller support; UDL of intensity ω over the whole span.",
              steps: [
                { t: "DF", w: "Joint A: DF = 0 (fixed). Joint B: DF = 1 (hinged/roller)." },
                { t: "FEM", w: "M_FAB = −ωℓ²/12 ,  M_FBA = +ωℓ²/12" },
                { t: "Balance at B (DF=1, cancel the whole FEM_BA)", w: "Bal_BA = −ωℓ²/12" },
                { t: "Carry over to A (COF = 1/2, far end fixed)", w: "CO_A = −ωℓ²/12 × 1/2 = −ωℓ²/24" },
                { t: "Sum", w: "M_A = −ωℓ²/12 − ωℓ²/24 = −ωℓ²/8\nM_B = ωℓ²/12 − ωℓ²/12 = 0" },
                { t: "Reactions, per the notes", w: "R₁ + R₂ = ωℓ ;  R₂ = ωℓ/8 ,  R₁ = 7ωℓ/8" },
              ],
              ans: "M_A = −ωℓ²/8 (hogging at the fixed end), M_B = 0. Notes' reactions: R_A = 7ωℓ/8, R_B = ωℓ/8." },
            { k: "note", t: "<b>Check:</b> the fixed-end moment M_A = −ωℓ²/8 matches the well-known classical result for a propped cantilever under UDL, and it is used correctly. But the reactions as written (R_B = ωℓ/8, R_A = 7ωℓ/8) do not follow from it. Taking moments about A with M_A = ωℓ²/8 (hogging) acting: ΣM_A = 0 ⇒ R_B·ℓ = ωℓ·(ℓ/2) − ωℓ²/8 ⇒ R_B = ωℓ/2 − ωℓ/8 = <b>3ωℓ/8</b>, and then R_A = ωℓ − R_B = <b>5ωℓ/8</b>. This is the standard textbook result for this classic case; the notes' ωℓ/8 and 7ωℓ/8 are reproduced as written but should be read as 3ωℓ/8 and 5ωℓ/8." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice the loop: FEM is always computed as if <b>both</b> ends were rigidly fixed, no matter what the real support is. The real support only shows up afterwards, through DF (0 for a truly fixed end, 1 for a hinge/roller) and through COF when that unbalanced moment is released and carried onward. This is what lets one set of FEM formulas serve every support combination." },
          ],
        },

        /* ------------------------------------------------ 12.4 */
        {
          n: "12.4",
          title: "Worked numericals — MDM without sway",
          hi: "हल किए गए उदाहरण — बिना स्वे",
          blocks: [
            { k: "h", t: "📘 Notes — T p.86–87, V p.150–152" },
            { k: "eg", title: "Continuous beam with a moment applied directly at the joint (T p.86–87)",
              given: "Beam A–B–C; A fixed; span AB = 4 m (I); at B a moment of 30 kN·m (anticlockwise) is applied; span BC = 3 m (I); C is a support. Analyse by MDM.",
              steps: [
                { t: "Relative stiffness and DF at B", w: "K_BA (far end fixed) = I/4\nK_BC (far end pinned, reduced factor) = (3/4)×(I/3) = I/4\nTotal = I/2  ⇒  DF_BA = DF_BC = 0.5" },
                { t: "FEM", w: "No member loads, only the joint moment ⇒ FEM = 0 for every member end." },
                { t: "Balance the applied moment at B", w: "30 kN·m is split by DF: Bal_BA = 15, Bal_BC = 15" },
                { t: "Carry over", w: "To A (COF = 1/2, far end fixed): CO_A = 15 × 1/2 = 7.5\nTo C: CO_C = 0, because member BC already used the far-end-pinned reduced stiffness factor, so no further carry-over travels past that pinned end" },
                { t: "Sum", w: "M_A = 7.5 ,  M_BA = 15 ,  M_BC = 15 ,  M_C = 0" },
              ],
              ans: "M_A = 7.5 kN·m, M_B = 15 kN·m (both sides), M_C = 0." },
            { k: "eg", title: "Two-span beam: point load + UDL, full non-sway distribution (V p.150–152)",
              given: "Beam A–B–C. A fixed; span AB = 4 m with a 60 kN point load at mid-span; B a roller/hinge support; span BC = 5 m with UDL 5 kN/m; C a roller/hinge support. EI constant on both spans.",
              steps: [
                { t: "FEM", w: "M_FAB = −Pℓ/8 = −(60×4)/8 = −30\nM_FBA = +30\nM_FBC = −wℓ²/12 = −(5×5²)/12 = −10.42\nM_FCB = +10.42" },
                { t: "DF", w: "K_BA = 4EI/4 = EI ; K_BC = 4EI/5 = 0.8EI ; Total = 1.8EI\nDF_BA = 0.55 , DF_BC = 0.45 (rounded so the pair sums to 1.00)\nJoint C (single member, roller) ⇒ DF_CB = 1" },
                { t: "Release B and C (source's single combined balancing row)", w: "Bal at B: −19.58 total (=−(30−10.42)) split as −10.77 (BA) and −8.81 (BC)\nBal at C: −10.42 (cancelling FEM_CB fully, DF=1)" },
                { t: "Carry-over", w: "CO to A (from B's balance, COF=1/2): −10.77×0.5 = −5.38\nCO to BC-side of B (from C's balance, COF=1/2): −10.42×0.5 = −5.21\nCO to C (from B's balance on the BC side, COF=1/2): −8.81×0.5 = −4.40" },
                { t: "Final end moments, read off the source's BMD figure", w: "M_A ≈ −34.45 kN·m ,  M_BA ≈ 21.1 kN·m" },
              ],
              ans: "M_A ≈ −34.45 kN·m, M_BA ≈ 21.1 kN·m (source's own BMD caption, V p.152)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Pattern to lock in: fixed end → DF 0, roller/hinge end → DF 1, and for a beam member whose far end is a roller/hinge use the reduced relative stiffness (3/4)(I/ℓ) — that single choice is what makes carry-over stop at a pinned far end instead of bouncing back and forth. Always start FEM as if every joint were rigidly fixed; the actual support type only enters through DF and COF afterwards." },
            { k: "trap", t: "When a moment is applied directly at a joint (not as a span load), it has <b>no FEM</b> of its own — it is added straight into that joint's first balancing step, on top of whatever FEM imbalance already exists there." },
          ],
        },

        /* ------------------------------------------------ 12.5 */
        {
          n: "12.5",
          title: "Modified MDM and the symmetry shortcut",
          hi: "संशोधित MDM और सममिति शर्त",
          blocks: [
            { k: "h", t: "📘 Notes — V p.152–167" },
            { k: "def", term: "Modified MDM", t: "Used when the far end of a member is discontinuous and pin/roller supported. Using modified MDM, the size of the distribution table is reduced. (V p.152)" },
            { k: "eq", expr: "Modified stiffness at a member whose far end is a discontinuous pin/roller:  K = 3EI/ℓ  (used directly, instead of 4EI/ℓ)", where: [
              ["method", "that far end is released once, permanently, right after the FEM step, and its balancing moment is carried over (COF=1/2) into the adjacent joint before the normal iteration begins — no further carry-over ever returns to that released end"],
            ] },
            { k: "eg", title: "The same two-span beam (12.4), re-solved by modified MDM (V p.152–154)",
              given: "Same beam as the previous section: A fixed, AB=4 m with 60 kN mid-span point load, BC=5 m with UDL 5 kN/m, C a discontinuous roller/pin — so modified MDM can be used at C.",
              steps: [
                { t: "FEM — unchanged", w: "M_FAB=−30, M_FBA=30, M_FBC=−10.42, M_FCB=10.42" },
                { t: "DF using modified stiffness at BC", w: "K_BA = 4EI/4 = EI ; K_BC (modified) = 3EI/5 = 0.6EI ; Total = 1.6EI\nDF_BA = 0.63 , DF_BC = 0.37" },
                { t: "Release C permanently", w: "Bal_CB = −10.42 (cancels FEM_CB fully)\nCO to BC-side of B: −10.42 × 0.5 = −5.21\nModified FEM_BC = −10.42 − 5.21 = −15.63" },
                { t: "Balance joint B (only unbalanced joint left)", w: "Unbalanced = 30 − 15.63 = 14.37\nBal_BA = −14.37×0.63 = −9.05 ; Bal_BC = −14.37×0.37 = −5.32" },
                { t: "Carry over to A", w: "CO_A = −9.05 × 0.5 = −4.52" },
                { t: "Final", w: "M_A = −30 − 4.52 = −34.52\nM_BA = 30 − 9.05 = 20.95\nM_BC = −15.63 − 5.32 = −20.95\nM_C = 0 (fully released)" },
              ],
              ans: "M_A = −34.52 kN·m, M_B = 20.95 kN·m — reached in one balancing cycle instead of the ordinary method's simultaneous release of both joints." },
            { k: "note", t: "<b>Source's own two answers for the same beam differ slightly</b> — ordinary MDM (V p.150–152) gives M_A ≈ −34.45, M_B ≈ 21.1; modified MDM (V p.152–154) gives M_A = −34.52, M_B = 20.95. The gap (≈0.1–0.15 kN·m) comes from DF being rounded to two decimals and from the ordinary method's single combined balancing row not carrying the process through a further iteration — the algebraic result is the same idea, the numbers are simply not identical in the notes. Both are reproduced exactly as given; neither is 'corrected' here." },
            { k: "h", t: "Use of symmetry condition (V p.161–167)" },
            { k: "p", t: "For a structure that is symmetric in geometry, stiffness <b>and</b> loading about an axis, only half the structure needs to be analysed. At the cut, the half-member's stiffness is <b>halved</b> and the cut end is given a guided (symmetry) support that allows translation along the axis but not rotation." },
            { k: "eq", expr: "Stiffness of the half-member at the axis of symmetry:  K_(half) = K_(full)/2", where: [["example (V p.161)", "K_BC′ = K_BC/2 = (4EI/10)/2, for the half of a 10 m symmetric span"]] },
            { k: "eg", title: "Three-span symmetric beam, solved on the half-structure (V p.161–162)",
              given: "Beam A–B–C–D; A and D fixed; B, C roller/hinge; span AB=6 m with a 20 kN point load at mid-span; span BC=10 m with UDL 5 kN/m, symmetric about its own mid-point; span CD=6 m mirrors AB. Analyse the half-structure A–B–C′.",
              steps: [
                { t: "KI on the half-structure", w: "KI = 1 (θ_B only)" },
                { t: "FEM", w: "M_FAB = −Pℓ/8 = −(20×6)/8 = −15 ,  M_FBA = +15\nM_FBC = −wℓ²/12 = −(5×10²)/12 = −41.67   (uses the FULL span BC=10 m even though only half the beam is drawn)" },
                { t: "DF at B", w: "K_BA = 4EI/6 = 0.67EI\nK_BC′ = (4EI/10)/2 = 0.2EI\nTotal = 0.87EI ⇒ DF_BA = 0.77 , DF_BC′ = 0.23" },
                { t: "Balance and carry over", w: "Unbalanced = 15 − 41.67 = −26.67\nBal_BA = 26.67×0.77 = 20.53 ; Bal_BC′ = 26.67×0.23 = 6.13\nCO to A = 20.53×0.5 = 10.26" },
                { t: "Final", w: "M_A = −15+10.26 = −4.74\nM_BA = 15+20.53 = 35.53\nM_BC′ = −41.67+6.13 = −35.53 (by symmetry, the true M_BC of the full beam)" },
              ],
              ans: "M_A = −4.74 kN·m, M_B = 35.53 kN·m; by symmetry M_C = −35.53 kN·m and M_D = +4.74 kN·m for the mirrored half." },
            { k: "note", t: "★ Caveat, quoted from the notes (V p.167): the symmetry shortcut above 'is not applicable if there is no sway in member at axis of symmetry' — e.g. a multi-bay portal frame where the member sitting exactly on the axis of symmetry itself has zero relative stiffness reduction is analysed differently (only the axis column's stiffness is used un-halved, K_BC = 4EI/L_BC, for the half model)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Both shortcuts exist purely to shrink the distribution table: modified MDM permanently 'switches off' a joint the moment it is discontinuous, so it never needs a DF row again; symmetry cuts the whole structure in half and lets one column of numbers stand in for two. Neither changes the physics — they just avoid repeating work the symmetry or the discontinuity already tells you the answer to." },
          ],
        },

        /* ------------------------------------------------ 12.6 */
        {
          n: "12.6",
          title: "Moment distribution with sway",
          hi: "स्वे सहित MDM (मोमेंट वितरण विधि)",
          blocks: [
            { k: "h", t: "📘 Notes — V p.168–180" },
            { k: "def", term: "Sway", t: "If any KI (kinematic indeterminacy) of the structure is <b>translational</b> (a joint can move sideways or vertically, not just rotate), the case is one of sway analysis. (V p.168)" },
            { k: "steps", items: [
              "Calculate KI and identify it; if any KI is translational, this is a sway case.",
              "Divide the structure into two parts: (I) Non-sway — the real loads P are applied, and a holding force R (a temporary prop) is added at the translational joint to prevent it from moving. (II) Sway — no external load, only a force R′ at the same joint, producing an assumed sway.",
              "Perform non-sway analysis for structure I and calculate all end moments.",
              "Write the equilibrium equation corresponding to the translational KI and calculate R (the force the temporary prop must supply to stop the sway under the real loads).",
              "Calculate the FEM for sway Δ of structure II, and get the ratio of all these FEM to each other (they are all proportional to the same unknown Δ).",
              "Select any arbitrary value in that ratio and perform moment distribution for the sway case.",
              "Again write the equilibrium equation for sway and calculate R′ — the force that is responsible for producing the end moments calculated in step 6.",
              "Calculate the correction factor R/R′.",
              "Calculate the final end moment:  M_final = M_(Non-sway) + (R/R′) × M_(sway).",
              "Draw the BMD using the moments of step 9 by the method of superposition, then calculate reactions and draw the SFD.",
            ] },
            { k: "eq", expr: "M_final = M_(Non-sway) + (R/R′) · M_(sway)", where: [
              ["logic (V p.168, green box)", "R′ → M_sway ; 1 → M_sway/R′ ; R → (R/R′)·M_sway — i.e. scale the assumed sway moments so the prop force needed for the assumed case matches the actual prop force R required to prevent sway under the real load"],
            ] },
            { k: "eg", title: "Stepped fixed-fixed beam with sway (V p.169–173) — full worked example",
              given: "Beam A–B–C, both ends fixed. Span AB = 8 m, moment of inertia 2I, UDL 5 kN/m over the whole span. Span BC = 4 m, moment of inertia I. At the step (joint B), because the cross-section changes, a joint is considered there: a downward point load 10 kN and an applied moment 40 kN·m act directly at B.",
              steps: [
                { t: "Step I — KI", w: "KI = 2 (θ_B and Δ_YB, the vertical translation at the step) — this is a sway (translational) case." },
                { t: "Step III — Non-sway DF", w: "K_BA = 4E(2I)/8 = EI ; K_BC = 4EI/4 = EI ; Total = 2EI ⇒ DF_BA = DF_BC = 0.5" },
                { t: "Non-sway FEM (member loads only)", w: "M_FAB = −wℓ²/12 = −(5×8²)/12 = −26.67 ; M_FBA = +26.67 ; M_FBC = M_FCB = 0" },
                { t: "Balance joint B — including the 40 kN·m applied directly at B", w: "Total unbalanced at B = 26.67 (FEM_BA) + 0 (FEM_BC) + 40 (applied moment, added directly here, not as an FEM) = 66.67\nBal_BA = Bal_BC = −33.33 each" },
                { t: "Carry over", w: "CO_A = −33.33×0.5 = −16.67 ; CO_C = −33.33×0.5 = −16.67" },
                { t: "Non-sway final moments", w: "M_AB = −26.67−16.67 = −43.34\nM_BA = 26.67−33.33 = −6.67\nM_BC = 0−33.33 = −33.33\nM_CB = 0−16.67 = −16.67" },
                { t: "Step IV — Calculate R", w: "V_BA = −[(M_AB+M_BA+5×8×4)/8] = −[(−43.34−6.67+160)/8] ≈ −13.75 kN\nV_BC = (M_BC+M_CB)/4 = (−33.33−16.67)/4 = −12.5 kN\n(From the joint's ΣF_y=0 with the 10 kN applied load) ⇒  R = 36.25 kN" },
                { t: "Step V — Sway FEM ratio", w: "M_FAB : M_FBA : M_FBC : M_FCB = −6E(2I)Δ/8² : −6E(2I)Δ/8² : 6EIΔ/4² : 6EIΔ/4²\n= −0.03125 : −0.03125 : 0.0625 : 0.0625" },
                { t: "Step VI — assume 200, sway distribution", w: "FEM (sway) = −6.25, −6.25, 12.5, 12.5\nDF same as non-sway (0.5, 0.5)\nBal_BA = Bal_BC = −3.12 each\nCO_A = CO_C = −1.56 each\nFinal (sway): M_AB=−7.81, M_BA=−9.37, M_BC=9.37, M_CB=10.94" },
                { t: "Step VII — Calculate R′", w: "V_BA = −(M_AB+M_BA)/8 = −(−7.81−9.37)/8 = 2.15 kN\nV_BC = (M_BC+M_CB)/4 = (9.37+10.94)/4 = 5.08 kN\nΣF_y=0 ⇒ R′ = 7.23 kN" },
                { t: "Step VIII — Correction factor", w: "R/R′ = 36.25/7.23 ≈ 5.01" },
                { t: "Step IX — Final moments (M_final = M_NS + (R/R′)·M_sway)", w: "M_AB = −43.34 + 5.01×(−7.81) ≈ −82.57\nM_BA = −6.67 + 5.01×(−9.37) ≈ −53.75\nM_BC = −33.33 + 5.01×9.37 ≈ 13.75\nM_CB = −16.67 + 5.01×10.94 ≈ 38.35" },
              ],
              ans: "M_AB ≈ −82.57 kN·m, M_BA ≈ −53.75 kN·m, M_BC ≈ 13.75 kN·m, M_CB ≈ 38.35 kN·m (V p.172)." },
            { k: "real", t: "V's Ch.7 also carries a second, fuller <b>portal-frame</b> sway example (fixed base A, inclined column AB, horizontal beam BC with UDL 24 kN/m, vertical column CD, fixed base D — V p.173–180). Its non-sway table is worked completely (final moments 9.41, 18.9, −18.9, 22.06, −22.06, −10.96), R = 34.27 kN, the sway-FEM ratio and an assumed-value table are given, R′ = 43.81 kN and the correction factor R/R′ = 0.78 is stated — but the notes themselves leave the intermediate Balance/Carry-over rows of both distribution tables blank, jumping straight from FEM to the Final row. The final combined moments given are M_AB=−14.21, M_BA=−4.83, M_BC=4.83, M_CB=47.81, M_CD=−47.81, M_DC=−38.53 (V p.180). Reproduced here as the notes leave it — the missing intermediate rows are not invented." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "R is 'how much horizontal (or vertical) force is actually needed to hold the joint still under the real loads'; R′ is 'how much force an assumed unit-scale sway pattern would need to produce itself'. Scaling the assumed sway moments by R/R′ converts the made-up sway case into the sway that would actually happen if the prop were removed — that is the entire idea behind superposition here." },
            { k: "trap", t: "The shear equations for R and R′ use the <b>final end moments of that sub-case only</b> (non-sway moments for R, sway moments for R′) — never mix the two tables when writing the ΣF=0 equation at the translating joint." },
          ],
        },

        /* ------------------------------------------------ 12.7 */
        {
          n: "12.7",
          title: "Quick revision — Moment Distribution Method",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Member stiffness: 4EI/ℓ (far end fixed) vs 3EI/ℓ (far end hinged); relative factors I/ℓ and 3I/4ℓ.",
              "Joint stiffness = Σ member stiffness factors meeting there; DF = K_member/K_joint; DF=0 at a fixed end, DF=1 at a hinge/roller end.",
              "COF = 1/2 (far end fixed), 0 (far end hinged, or moment applied directly at an already-fixed support), 1 (internal hinge at mid-span), b/a general, −1 (cantilever).",
              "FEM: −wℓ²/12 & +wℓ²/12 (UDL); −Pℓ/8 & +Pℓ/8 (mid-span point load); −Pab²/ℓ² & +Pa²b/ℓ² (general point load) — always computed as if both ends were fixed.",
              "A moment applied directly at a joint has no FEM — it enters straight into that joint's first Balance step.",
              "Modified MDM: use K=3EI/ℓ directly for a discontinuous pin/roller far end and release it once, permanently.",
              "Symmetry: halve the stiffness at the axis, K_half = K_full/2, and analyse only half the structure — not valid if there is no sway at the axis member.",
              "Sway: split into Non-sway (real loads + prop force R) and Sway (only R′); M_final = M_NS + (R/R′)·M_sway.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "This method solves equilibrium directly, without computing θ or δ first — start by locking every joint, then unlock and balance one at a time.",
              "Propped-cantilever/UDL fixed-end moment M_A = −ωℓ²/8 is a recurring standard result (T p.85–86).",
              "Ordinary MDM and modified MDM can give slightly different rounded final answers on the same problem (V's own two solved versions differ by ≈0.1–0.15 kN·m) — both are valid, the gap is rounding, not error.",
              "In a sway problem, R comes from the non-sway table's shear equilibrium and R′ from the sway table's — never swap them.",
              "Carry-over factor is not always 1/2 — check what the far end actually is before assuming it.",
            ] },
          ],
        },

      ],
    },

  );
})();
