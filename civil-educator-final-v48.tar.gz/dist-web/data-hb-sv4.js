/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   Chapter 7 — Contouring
   Chapter 8 — Theodolite Surveying and Traversing
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "sv-7",
      n: 7,
      title: "Contouring",
      hi: "कंटूरिंग",
      blurb: "Turning a scatter of levels into a picture of the ground — and reading that picture back.",
      mins: 38,
      sections: [

        {
          n: "7.1",
          title: "What a contour is",
          hi: "कंटूर क्या है",
          blocks: [
            { k: "def", term: "Contour", t: "A line on the ground joining points of equal reduced level — and therefore, on a plan, a line along which the ground has a constant height. It is the intersection of a level surface with the ground surface." },
            { k: "dia", id: "an-sv-contour", cap: "Slice the hill at equal heights; each cut is one contour. The steeper the slope, the closer the rings." },
            { k: "def", term: "Contour interval", t: "The vertical distance between successive contours — constant across a plan, always. Chosen from the scale, the nature of the ground and the purpose: 0.2 to 0.5 m for a flat building site at large scale, 1 to 2 m for undulating ground, 5 m or more for hill country at small scale." },
            { k: "cmp", t: "Typical contour intervals by purpose", cols: ["Interval"], rows: [
              ["Building sites, earthwork calculation", "0.2 – 0.5 m"],
              ["Reservoirs, town planning", "0.5 – 2 m"],
              ["Location (route) surveys", "2 – 3 m"],
              ["Small-scale topographic maps", "3, 5, 10 or 25 m"],
            ]},
            { k: "note", t: "Values from <a href=\"https://gcekbpatna.ac.in/assets/documents/lecturenotes/Surveying_Mod3_Contouring.pdf\" target=\"_blank\" rel=\"noopener\">GCE Katihar contouring notes</a>, which also states the governing principle: the interval should be in inverse ratio to the scale — larger-scale plans take smaller intervals. The squares of a grid are typically 5–30 m, and cross-sections are spaced 20–30 m in hilly country and up to 100 m in flat country (same source)." },
            { k: "def", term: "Horizontal equivalent", t: "The horizontal distance between two successive contours. Unlike the interval this <em>varies</em> everywhere on the plan — and that variation is exactly what tells you the slope." },
            { k: "p", t: "So the two quantities carry different information. The interval is a decision you make; the horizontal equivalent is what the ground tells you. <strong>Slope = contour interval / horizontal equivalent</strong>, which is why closely spaced contours mean steep ground." },
            { k: "trap", t: "Choosing too small an interval does not produce a better plan. It produces a plan so dense with lines that nothing can be read, and it implies a precision the levelling does not have. A useful rule of thumb: the interval should be at least twice the likely error in the levels, or the contours are drawing noise." },
          ],
        },

        {
          n: "7.2",
          title: "Reading the ground from the lines",
          hi: "रेखाओं से भू-आकृति पढ़ना",
          blocks: [
            { k: "dia", id: "hb-sv-contour", cap: "The standard landforms, and the pair that look identical." },
            { k: "list", items: [
              "<strong>Close together</strong> — steep. <strong>Far apart</strong> — gentle. <strong>Evenly spaced</strong> — uniform slope.",
              "<strong>Closed rings, values increasing inwards</strong> — a hill. <strong>Closed rings, values decreasing inwards</strong> — a depression. They draw identically; only the figures distinguish them.",
              "<strong>V pointing uphill</strong> — a valley, and the stream runs through the apex of the V.",
              "<strong>U or rounded shape pointing downhill</strong> — a ridge or spur.",
              "<strong>A figure-of-eight between two summits</strong> — a saddle or pass.",
              "<strong>Contours very close, almost touching</strong> — a cliff.",
            ]},
            { k: "h", t: "Rules that follow from the definition" },
            { k: "list", items: [
              "Contours <strong>cannot cross</strong>, because a point cannot have two heights — except at an overhanging cliff, where the ground is above itself and the code for it is a pair of crossing lines.",
              "Contours <strong>cannot merge</strong> except at a vertical cliff.",
              "A contour <strong>must close</strong> on itself, either within the plan or beyond its edge. A contour that simply stops is a drawing error.",
              "Contours are <strong>perpendicular to the line of steepest slope</strong> — which is why water runs across them at right angles.",
            ]},
            { k: "trap", t: "The V-pointing-uphill rule is worth checking on a real plan until it is automatic, because the intuition runs the other way. A stream cuts <em>into</em> the hill, so the contour has to detour upstream to stay at the same height — and the apex of the V therefore points towards the higher ground." },
          ],
        },

        {
          n: "7.3",
          title: "Getting the levels",
          hi: "लेवल कैसे लें",
          blocks: [
            { k: "cmp", t: "Two families of method, and the choice is really about whether the ground or the grid is doing the organising.",
              cols: ["Direct contouring", "Indirect contouring"],
              rows: [
                ["What is located", "Points that are actually ON a chosen contour", "Points on a convenient grid, whose levels then get interpolated"],
                ["Procedure", "Set the instrument, compute the staff reading for that contour, and walk the staff until it reads it", "Level a grid or cross-sections, then draw contours between the values"],
                ["Speed", "Slow", "Fast"],
                ["Accuracy", "High — the contour is traced, not inferred", "Depends entirely on the density of the grid"],
                ["Best for", "Small areas needing accurate contours, reservoir shorelines, earthwork boundaries", "Almost everything else"],
                ["The catch", "Two people walking about, and one contour at a time", "A grid can miss a ridge or gully that falls between its lines"],
              ] },
            { k: "list", items: [
              "<strong>Squares (grid) method</strong> — lay out a grid of 5 to 20 m squares, level every corner, interpolate. Best on reasonably regular ground.",
              "<strong>Cross-sections</strong> — levels along lines at right angles to a centre line at regular chainages. The natural method for a road, railway or canal, and it produces exactly the sections earthwork volumes need (Chapter 10).",
              "<strong>Radial lines</strong> — rays from a central station, with levels at measured distances along each. Suits a hilltop or a site to be surveyed from one commanding point, and pairs naturally with tacheometry.",
            ]},
            { k: "trap", t: "The weakness of every indirect method is stated in the last row of that table, and it is real. A grid records what happens at its nodes and assumes the ground between them is plane. A narrow gully crossing diagonally between four grid points is <strong>invisible</strong> — and it will not appear on the plan, on the sections, or in the earthwork quantity. Break lines along ridges and valleys must be surveyed separately, whatever the grid does." },
          ],
        },

        {
          n: "7.4",
          title: "Interpolation, and what contours are used for",
          hi: "अंतर्वेशन और उपयोग",
          blocks: [
            { k: "p", t: "Between two levelled points, the contour crossing is found by assuming the ground slopes uniformly between them — which is the same assumption the grid already made." },
            { k: "eq", expr: "distance to the contour  =  d × (contour RL − RL₁) / (RL₂ − RL₁)", where: [
              ["d", "horizontal distance between the two levelled points"],
            ]},
            { k: "p", t: "So if two grid points 20 m apart read 96.4 and 98.8, the 97 m contour crosses at 20 × (97 − 96.4)/(98.8 − 96.4) = 20 × 0.25 = 5.0 m from the first. The arithmetic is trivial; doing it by eye once the interval is familiar is faster and quite accurate enough." },
            { k: "eg",
              title: "Example 7.1 — Direct contouring: the staff reading to look for",
              given: "A level is set up with a backsight of 1.235 on a BM of RL 101.230 m. Contours at 1 m interval are to be traced.",
              steps: [
                { t: "Height of instrument", w: "HI = 101.230 + 1.235 = 102.465 m" },
                { t: "Staff reading on each contour = HI − contour RL", w: "102 m contour → 0.465\n101 m contour → 1.465\n100 m contour → 2.465\n99 m contour  → 3.465" },
                { t: "Field procedure", w: "the staffman moves up or down the slope until the reading is, e.g., exactly 1.465;\nthat spot is on the 101 m contour — peg it and locate it in plan" },
              ],
              ans: "Look for 0.465, 1.465, 2.465 and 3.465 m. Once the level is moved, compute a new HI and a new set of target readings.",
            },
            { k: "eg",
              title: "Example 7.2 — Tracing a gradient line on a contour plan",
              given: "A road is to climb at not more than 1 in 30 across ground contoured at 2 m interval on a 1 : 2000 plan.",
              steps: [
                { t: "Horizontal equivalent for the grade", w: "HE = interval × 30 = 2 × 30 = 60 m on the ground" },
                { t: "On the plan", w: "60 m at 1 : 2000 = 60,000/2000 = 30 mm" },
                { t: "Procedure", w: "set dividers to 30 mm; from the start point step to the next contour, then the next;\nwhere the arc cuts a contour twice, either point gives the grade — choose the one that keeps the line direct" },
              ],
              ans: "Dividers at 30 mm. Where contours are farther apart than 30 mm the ground is already flatter than 1 in 30 and the line may go straight.",
            },
            { k: "h", t: "What the plan is then for" },
            { k: "list", items: [
              "<strong>Route selection</strong> — a road on a gradient not steeper than 1 in 30 is traced by stepping a pair of dividers set to the horizontal equivalent for that grade from contour to contour. The line that falls out is the alignment.",
              "<strong>Earthwork volumes</strong> — areas enclosed by successive contours, combined by the end-area or prismoidal rules of Chapter 10.",
              "<strong>Reservoir capacity</strong> — the same calculation, with the contour areas being water-surface areas at each level. This is how a dam's storage curve is produced.",
              "<strong>Catchment area and drainage</strong> — ridge lines separate catchments, and water runs perpendicular to the contours.",
              "<strong>Intervisibility</strong> — whether two points can see each other, checked by drawing the profile between them.",
              "<strong>Site grading</strong> — deciding the formation level that balances cut against fill.",
            ]},
            { k: "real", t: "Every one of those is a job an engineer actually gets handed. The reservoir capacity calculation is the neatest: plan the area inside each contour of the drowned valley, treat those areas as cross-sections stacked at the contour interval, and the prismoidal formula gives the storage. A dam's entire economic case rests on that arithmetic." },
          ],
        },

        {
          n: "7.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "A contour joins points of equal RL — the intersection of a level surface with the ground.",
              "Interval is constant and chosen; horizontal equivalent varies and is measured. Slope = interval / HE.",
              "Contours never cross or merge except at a cliff or overhang, and every contour closes.",
              "V points uphill for a valley; U points downhill for a ridge.",
              "Hills and depressions draw identically — read the figures.",
              "Direct is accurate and slow; indirect is fast and only as good as its grid.",
              "A grid misses anything between its nodes. Survey ridge and valley lines separately.",
            ]},
            { k: "p", t: "Chapters 6 and 7 fixed heights. Chapter 8 returns to plan position with the instrument that measures angles properly — and builds the traverse that most engineering control is founded on." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "sv-8",
      n: 8,
      title: "Theodolite Surveying and Traversing",
      hi: "थियोडोलाइट और ट्रैवर्स",
      blurb: "Measuring an angle properly, and turning a chain of them into coordinates that close.",
      mins: 56,
      sections: [

        {
          n: "8.1",
          title: "The instrument",
          hi: "उपकरण",
          blocks: [
            { k: "p", t: "A theodolite measures horizontal and vertical angles, and it is the instrument that makes precise plan control possible. A twenty-second vernier theodolite reads to 20″; an optical or electronic instrument reads to 1″ or better." },
            { k: "list", items: [
              "<strong>Telescope</strong>, rotating about the horizontal <em>trunnion</em> axis.",
              "<strong>Vertical circle</strong>, fixed to the telescope, for vertical angles.",
              "<strong>Horizontal circle</strong> and <strong>vernier plate</strong>, with upper and lower clamps and tangent screws — the pair that makes the repetition method possible.",
              "<strong>Levelling head and tribrach</strong>, with footscrews.",
              "<strong>Plumb bob or optical plummet</strong>, for centring over the station.",
            ]},
            { k: "h", t: "The three axes, and the relations between them" },
            { k: "p", t: "Every permanent adjustment is a statement about these, and knowing them makes the adjustments obvious rather than a list to memorise:" },
            { k: "list", items: [
              "The <strong>vertical axis</strong> must be truly vertical.",
              "The <strong>line of collimation</strong> must be perpendicular to the trunnion axis. If not, it sweeps a cone instead of a plane — the <em>collimation error</em>.",
              "The <strong>trunnion axis</strong> must be perpendicular to the vertical axis. If not, the plane swept is tilted — the <em>trunnion axis error</em>.",
              "The <strong>altitude bubble axis</strong> must be parallel to the line of collimation when the vertical circle reads zero — otherwise every vertical angle carries an <em>index error</em>.",
            ]},
            { k: "p", t: "<strong>Temporary adjustments</strong> at every station are: setting up and centring over the mark, levelling with the footscrews, and eliminating parallax. Centring matters more than beginners expect — a 5 mm centring error over a 50 m sight is about 20 seconds of arc, which is worse than the instrument's own reading accuracy." },
          ],
        },

        {
          n: "8.2",
          title: "Face left, face right, and why every angle is measured twice",
          hi: "फेस लेफ्ट और फेस राइट",
          blocks: [
            { k: "dia", id: "hb-sv-faces", cap: "Transiting reverses the sign of each instrumental error without changing its size." },
            { k: "p", t: "Observe a direction with the vertical circle on the left of the telescope, then transit the telescope, swing through 180°, and observe the same direction again with the circle on the right. The two readings should differ by exactly 180°. They generally do not — and the mean of the two is free of collimation error, trunnion axis error and vertical circle index error, all at once." },
            { k: "p", t: "It works because each of those errors displaces the reading by the same amount in <em>opposite directions</em> on the two faces, so averaging removes them exactly. It costs one extra pointing and it is the cheapest accuracy available in surveying." },
            { k: "trap", t: "One error that face-averaging does <strong>not</strong> remove is a vertical axis that is not truly vertical, because that error does not reverse when the telescope is transited. It has to be dealt with by careful levelling, and it is worst on steep sights — which is why levelling matters more when you are observing up a hillside than across a flat field." },
            { k: "h", t: "Measuring a horizontal angle" },
            { k: "list", items: [
              "<strong>Repetition method</strong> — the same angle is measured several times, each measurement accumulated mechanically on the circle without resetting, and the total divided by the number of repetitions. The instrument's least count is effectively divided by n, so a 20″ instrument can deliver a few seconds. Uses both clamps, which is what they are for.",
              "<strong>Reiteration (direction) method</strong> — from one station, all the surrounding points are observed in turn, closing back on the first. The horizon should close on the starting reading; the misclosure is distributed. Faster where several directions are needed from one station.",
            ]},
            { k: "eg",
              title: "Example 8.1 — An angle by repetition",
              given: "A 20″ theodolite is set to 0°00′00″ on A. The angle AOB is accumulated six times (three on each face); the final reading on B is 279°38′40″.",
              steps: [
                { t: "Total accumulated", w: "279°38′40″ (the circle did not pass 360°; if it had, add 360°)" },
                { t: "Mean angle", w: "279°38′40″/6 = 46°36′26.7″" },
              ],
              ans: "Angle AOB = 46°36′27″ — read to a fraction of the 20″ least count, because only the first and last readings carry reading error.",
            },
          ],
        },

        {
          n: "8.3",
          title: "Traversing",
          hi: "ट्रैवर्स",
          blocks: [
            { k: "def", term: "Traverse", t: "A series of connected lines whose lengths and directions are measured. It is the standard method of establishing plan control for engineering work — flexible, suits any terrain, and needs no intervisibility beyond consecutive stations." },
            { k: "list", items: [
              "<strong>Closed traverse</strong> — returns to its starting point, or runs between two points of known position. It can therefore be <em>checked</em>, and it is the only kind that should be used for control.",
              "<strong>Open traverse</strong> — starts somewhere and ends somewhere else, with no closure. Unavoidable for a long canal, road or pipeline, and dangerous: there is no check, so blunders survive. Mitigated by cutting off with occasional astronomical or GNSS observations.",
            ]},
            { k: "h", t: "Angles, and the angular check" },
            { k: "p", t: "Angles are measured either as <em>included angles</em> between successive lines, or as <em>deflection angles</em> from the prolongation of the previous line — the latter suits long narrow traverses along a route. Either way there is an immediate check:" },
            { k: "eq", expr: "closed traverse of n sides:   Σ interior angles = (2n − 4) × 90°       Σ exterior angles = (2n + 4) × 90°", where: [] },
            { k: "p", t: "This check is available <strong>before leaving the field</strong>, and it should always be applied there. The angular misclosure is distributed equally among the angles before any coordinate computation begins — because the geometry must be right before the trigonometry is worth doing." },
            { k: "eq", expr: "traverse run anticlockwise, angle measured clockwise from back station to forward station (= interior angle):   θ(next) = θ(previous) + 180° + interior angle   (subtract 360° as needed)", where: [] },
            { k: "eg",
              title: "Example 8.2 — Angular misclosure, then bearings",
              given: "Quadrilateral ABCD run anticlockwise. Measured interior angles: A 87°15′20″, B 92°40′00″, C 88°10′40″, D 91°53′20″. Bearing of AB = 30°00′00″.",
              steps: [
                { t: "Angular check", w: "Σ = 359°59′20″; required (2n − 4) × 90° = 360°00′00″\nmisclosure = −40″ → add +10″ to each angle" },
                { t: "Corrected angles", w: "A 87°15′30″, B 92°40′10″, C 88°10′50″, D 91°53′30″  (Σ = 360°00′00″ ✓)" },
                { t: "Carry the bearings round", w: "BC = 30°00′00″ + 180° + 92°40′10″ − 360° = 302°40′10″\nCD = 302°40′10″ + 180° + 88°10′50″ − 360° = 210°51′00″\nDA = 210°51′00″ + 180° + 91°53′30″ − 360° = 122°44′30″" },
                { t: "Check — back to AB", w: "122°44′30″ + 180° + 87°15′30″ − 360° = 30°00′00″  ✓" },
              ],
              ans: "Bearings AB 30°00′00″, BC 302°40′10″, CD 210°51′00″, DA 122°44′30″. Returning exactly to the starting bearing is the proof that the angles were distributed correctly.",
            },
          ],
        },

        {
          n: "8.4",
          title: "Latitudes, departures and the closing error",
          hi: "अक्षांश, विचलन और समापन त्रुटि",
          blocks: [
            { k: "eq", expr: "latitude  L = l cos θ       departure  D = l sin θ", where: [
              ["l", "length of the line"],
              ["θ", "its whole circle bearing"],
            ]},
            { k: "p", t: "Latitude is the line's projection on the north-south axis and departure its projection east-west. North and east are positive; south and west negative, and the WCB takes care of the signs automatically if the trigonometry is done in whole circle." },
            { k: "dia", id: "hb-sv-traverse", cap: "The gap between where the traverse ends and where it started is the closing error." },
            { k: "p", t: "For a closed traverse the sum of latitudes and the sum of departures must each be zero — you have walked round and come back. They never are, and what is left is the closing error:" },
            { k: "eq", expr: "closing error  e = √( (ΣL)² + (ΣD)² )        accuracy = perimeter / e", where: [] },
            { k: "p", t: "Quoted as a ratio: 1 in 2200, 1 in 8000. That single number is the honest statement of how good the survey was, and it is the reason a closed traverse is worth the extra work — an open one has no such number and never can." },
          ],
        },

        {
          n: "8.5",
          title: "Balancing, and a traverse worked through",
          hi: "संतुलन और हल किया गया उदाहरण",
          blocks: [
            { k: "cmp", t: "Two rules for distributing the closing error. The choice is a statement about which measurements you trust more.",
              cols: ["Bowditch (compass) rule", "Transit rule"],
              rows: [
                ["Assumes", "Angles and distances are equally reliable", "Angles are more reliable than distances"],
                ["Correction to latitude", "e(L) × (length of line / perimeter)", "e(L) × (|latitude of line| / Σ|latitudes|)"],
                ["Correction to departure", "e(D) × (length of line / perimeter)", "e(D) × (|departure of line| / Σ|departures|)"],
                ["Effect", "Long lines take the most correction", "Lines with large latitude/departure take the most"],
                ["Use when", "Lengths chained, angles by theodolite — the normal case", "Angles much better than distances, e.g. stadia distances with a good theodolite"],
              ] },
            { k: "note", t: "Both rules as stated by <a href=\"https://engineeringhulk.com/civil/surveying/theodolite-traversing/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>; <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105107122/modules/module9/html/29-15.htm\" target=\"_blank\" rel=\"noopener\">NPTEL Module 9</a> applies Bowditch's rule equally to coordinates, correcting each station in proportion to its distance round the traverse from the start. The computations are normally laid out in a <strong>Gale's traverse table</strong> — bearing, length, latitude, departure, corrections, corrected values and coordinates in one sheet, Example 8.3 follows the same sequence, column by column." },
            { k: "eg",
              title: "Example 8.3 — Balancing a closed traverse",
              given: "A closed traverse ABCDA, lengths in metres and whole circle bearings:\nAB 232.0 m, 48°00'   ·   BC 190.0 m, 138°30'   ·   CD 261.0 m, 222°00'   ·   DA 219.0 m, 325°45'",
              steps: [
                { t: "Latitudes and departures", w: "AB:  L = 232.0 cos48°00'  = +155.238   D = 232.0 sin48°00'  = +172.410\nBC:  L = 190.0 cos138°30' = −142.302   D = 190.0 sin138°30' = +125.898\nCD:  L = 261.0 cos222°00' = −193.961   D = 261.0 sin222°00' = −174.643\nDA:  L = 219.0 cos325°45' = +181.023   D = 219.0 sin325°45' = −123.254" },
                { t: "The sums, which should be zero", w: "ΣL = −0.001 m (from the unrounded latitudes)\nΣD = +172.410 + 125.898 − 174.643 − 123.254 = +0.411 m" },
                { t: "Closing error and accuracy", w: "e = √(0.001² + 0.411²) = 0.411 m\nperimeter = 232.0 + 190.0 + 261.0 + 219.0 = 902.0 m\naccuracy = 902.0/0.411 = 1 in 2195,  say 1 in 2200" },
                { t: "Bowditch corrections — proportional to length", w: "correction to D for AB = −0.411 × 232.0/902.0 = −0.106\n              for BC = −0.411 × 190.0/902.0 = −0.087\n              for CD = −0.411 × 261.0/902.0 = −0.119\n              for DA = −0.411 × 219.0/902.0 = −0.100\n(latitude corrections are each under 0.3 mm, ΣL being only 1 mm; the adjusted values below are carried from the unrounded computation)" },
                { t: "Adjusted latitudes and departures", w: "AB:  +155.239   +172.304\nBC:  −142.301   +125.811\nCD:  −193.961   −174.762\nDA:  +181.023   −123.353\nΣ:      0.000      0.000   ✓" },
                { t: "Independent coordinates, starting A at (1000.000 E, 1000.000 N)", w: "B:  E 1172.304   N 1155.239\nC:  E 1298.115   N 1012.938\nD:  E 1123.353   N  818.977\nA:  E 1000.000   N 1000.000   ✓ closes exactly" },
              ],
              ans: "Closing error 0.411 m on a 902 m perimeter — 1 in 2200, acceptable for a compass-grade traverse and modest for theodolite work. After Bowditch adjustment the coordinates close exactly on A.",
            },
            { k: "trap", t: "Balancing does not improve the survey. The measurements are what they are; adjusting them makes the figure <em>consistent</em> so that coordinates can be computed, and nothing more. <strong>The information is in the ratio, not in the adjusted numbers</strong> — and if 1 in 2200 is not good enough for the job, no adjustment rule will rescue it. Go back and measure better." },
          ],
        },

        {
          n: "8.6",
          title: "Omitted measurements, and what to carry forward",
          hi: "छूटी हुई माप और सार",
          blocks: [
            { k: "p", t: "Occasionally a line cannot be measured — it crosses a river, or a station was lost. Because ΣL = 0 and ΣD = 0 for a closed traverse, two unknowns can be recovered from those two equations: the length and bearing of one line, or the lengths of two lines, or the bearings of two lines." },
            { k: "trap", t: "The recovered values absorb <strong>all</strong> the error in the rest of the traverse, because they are computed on the assumption that everything else is perfect. There is no closing error left to check against — the closure was used up in the computation. Omitted-measurement results should be treated as the weakest part of the survey and never as a substitute for going back with a tape." },
            { k: "eg",
              title: "Example 8.4 — Recovering an omitted line",
              given: "In the traverse of Example 8.3, suppose DA could not be measured. Use the other three lines.",
              steps: [
                { t: "Sums of the measured lines", w: "ΣL(AB, BC, CD) = 155.238 − 142.302 − 193.961 = −181.025\nΣD(AB, BC, CD) = 172.410 + 125.898 − 174.643 = +123.665" },
                { t: "DA must close the figure", w: "L(DA) = +181.025,  D(DA) = −123.665" },
                { t: "Length and bearing", w: "length = √(181.025² + 123.665²) = 219.23 m\nreduced bearing = tan⁻¹(123.665/181.025) = 34°20.3′ → N 34°20′ W\nWCB = 360° − 34°20.3′ = 325°39.7′" },
              ],
              ans: "DA = 219.23 m at 325°40′ — against the measured 219.0 m at 325°45′. The 0.23 m and 5′ differences are simply the whole traverse's closing error, now hidden inside one line with nothing left to reveal it.",
            },
            { k: "list", items: [
              "A theodolite measures horizontal and vertical angles; four axis relations define its adjustments.",
              "Face left and face right, and take the mean — it removes collimation, trunnion and index errors together.",
              "It does not remove a non-vertical vertical axis; only careful levelling does.",
              "Closed traverses can be checked; open ones cannot, and should be avoided for control.",
              "Angular check first, in the field: Σ interior angles = (2n − 4) × 90°.",
              "L = l cos θ, D = l sin θ. For a closed traverse both sums must be zero.",
              "e = √(ΣL² + ΣD²); quote accuracy as perimeter / e.",
              "Bowditch when angles and distances are equally good; Transit when angles are better.",
              "Balancing makes the figure consistent. It does not make the survey better.",
            ]},
            { k: "p", t: "Chapter 9 removes the tape from the traverse altogether, and gets distance out of the same telescope that has been measuring the angles." },
          ],
        },
      ],
    }

  );
})();
