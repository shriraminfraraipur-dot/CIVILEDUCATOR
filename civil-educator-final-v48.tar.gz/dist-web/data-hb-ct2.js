/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: CONCRETE TECHNOLOGY · Chapters 3–5
   Aggregates, water & admixtures · Fresh concrete · Hardened concrete
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "ct");
  if (!hb) { console.error("[ct2] handbook ct not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "ct-3",
      n: 3,
      title: "Aggregates, Water and Admixtures",
      hi: "गिट्टी, पानी और एडमिक्सचर",
      blurb: "The three-quarters of concrete that is not cement paste — grading, the silt and chloride enemies, and what an admixture buys you.",
      mins: 28,
      sections: [
        {
          n: "3.1",
          title: "Aggregate decides more than you'd think",
          hi: "गिट्टी का महत्व",
          blocks: [
            { k: "p", t: "Aggregate is roughly three-quarters of concrete by volume, so its strength, shape, cleanliness and grading shape most of the result. Good cement cannot rescue dirty or badly graded aggregate — the paste is only the glue." },
            { k: "def", term: "Well-graded aggregate", t: "A spread of particle sizes so the small ones fill the gaps between the large ones. Less void space means less paste needed to fill it — less cement, less water, and a denser, stronger, cheaper concrete." },
            { k: "list", items: [
              "<strong>Shape</strong> — angular crushed stone interlocks and bonds better than smooth rounded gravel, though rounded needs less water.",
              "<strong>Maximum size</strong> — bigger aggregate needs less paste, but must fit between the bars and into the section (typically ≤ 20 mm in RCC).",
              "<strong>Grading</strong> — a good spread of sizes; measured by sieve analysis and summarised by fineness modulus (see the Building Materials handbook).",
              "<strong>Cleanliness</strong> — free of silt, clay, organic matter and salt.",
            ] },
            { k: "h", t: "Grading zones and fineness modulus" },
            { k: "p", t: "IS 383 places a fine aggregate in one of four grading zones, decided mainly by the percentage passing the 600 µm sieve: <strong>Zone I 15–34%</strong> (coarsest), <strong>Zone II 35–59%</strong>, <strong>Zone III 60–79%</strong>, <strong>Zone IV 80–100%</strong> (finest). The fineness modulus (FM) — the sum of cumulative percentages retained on the standard sieves divided by 100 — summarises the same thing in one number; a higher FM is a coarser sand." },
            { k: "eg", title: "Example 3.1 — Sieve analysis of a sand",
              given: "1000 g of sand retained on the sieves: 4.75 mm 30 g, 2.36 mm 90 g, 1.18 mm 150 g, 600 µm 250 g, 300 µm 280 g, 150 µm 150 g, pan 50 g.",
              steps: [
                { t: "Cumulative % retained", w: "4.75: 3.0   2.36: 12.0   1.18: 27.0   0.600: 52.0   0.300: 80.0   0.150: 95.0" },
                { t: "Fineness modulus", w: "FM = (3 + 12 + 27 + 52 + 80 + 95)/100 = 269/100 = 2.69" },
                { t: "Zone", w: "% passing 600 µm = 100 − 52 = 48%  →  Zone II (35–59)" },
              ],
              ans: "FM 2.69, Zone II — the ‘ordinary’ sand most mix-design tables assume. Zone limits on the other sieves must also be checked before the zone is confirmed." },
            { k: "note", t: "Zone limits as tabulated by <a href=\"https://infralens.in/handbook/aggregate-grading\" target=\"_blank\" rel=\"noopener\">InfraLens</a> (IS 383): 600 µm passing 15–34 / 35–59 / 60–79 / 80–100% for Zones I–IV. One teaching note found during research labels these same ranges as percentage <em>retained</em> — that is an error; IS 383 specifies percentage passing." },
          ],
        },
        {
          n: "3.2",
          title: "The enemies: silt, organics and chloride",
          hi: "दुश्मन — गाद, कार्बनिक और क्लोराइड",
          blocks: [
            { k: "p", t: "Contamination of the fine aggregate is a more common cause of weak concrete than bad grading. Three contaminants matter, and each has a check." },
            { k: "cmp", t: "What contaminates a sand",
              cols: ["What it does", "How you catch it"],
              rows: [
                ["Silt / clay", "coats grains → cement can't bond → weak, more water", "field silt test: settle in a jar, ≤ ~8%"],
                ["Organic matter", "delays and weakens the set", "colourimetric (caustic soda) test"],
                ["Chloride / salt", "rusts the reinforcement from within", "chloride test; wash sea sand"],
              ] },
            { k: "trap", t: "Chloride is the one that ruins reinforced concrete quietly and permanently. It drives corrosion of the steel, which expands and spalls the concrete off from inside — often years later. Sea sand, or aggregate stored where salt water reaches it, must be tested and washed; IS 456 caps the total chloride content for exactly this reason." },
          ],
        },
        {
          n: "3.3",
          title: "Admixtures — the fine adjustments",
          hi: "एडमिक्सचर",
          blocks: [
            { k: "p", t: "An admixture is a small addition that tunes one property of the concrete without redesigning the mix. It is an adjustment, not a rescue: it cannot fix a fundamentally wrong mix, only refine a sound one." },
            { k: "cmp", t: "The admixtures you'll meet",
              cols: ["What it does", "When you'd use it"],
              rows: [
                ["Plasticiser", "more flow at the same water", "workability without extra water"],
                ["Superplasticiser", "large flow gain / large water cut", "high-strength, low-w/c mixes"],
                ["Retarder", "delays the set", "hot weather, long transport, big pours"],
                ["Accelerator", "speeds the set", "cold weather, urgent strength"],
                ["Air-entrainer", "tiny stable air bubbles", "frost resistance"],
              ] },
            { k: "real", t: "The superplasticiser is the admixture that made modern high-strength concrete possible. Strength wants a low w/c, but low w/c means concrete too stiff to place. A superplasticiser restores the flow without the water — so you get both. <strong>It broke the old trade-off between strength and workability.</strong>" },
            { k: "note", t: "An air-entrainer looks like it should weaken concrete — it deliberately adds voids — and it does cost a little strength. But the tiny bubbles give freezing water room to expand into, so in a cold climate the concrete survives frost that would otherwise spall it. A small, deliberate strength cost buys durability." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "ct-4",
      n: 4,
      title: "Fresh Concrete — Workability, Placing, Compaction",
      hi: "ताज़ा कंक्रीट",
      blurb: "The few hours when concrete can still be got wrong for free — measuring workability, placing without segregation, and the compaction step that most often lets a good mix down.",
      mins: 30,
      sections: [
        {
          n: "4.1",
          title: "Workability and the slump test",
          hi: "वर्केबिलिटी और स्लंप टेस्ट",
          blocks: [
            { k: "p", t: "Fresh concrete has to be workable enough to place and compact fully, without being so wet it segregates or loses strength. Workability is that balance, and slump is its cheapest field measure." },
            { k: "dia", id: "hb-ct-slump", cap: "The slump test, and the three shapes of slump." },
            { k: "def", term: "Workability", t: "The ease with which concrete can be mixed, placed, compacted and finished without segregation. It is matched to the job: a thin heavily-reinforced section needs high workability; a mass foundation can take a stiff mix." },
            { k: "def", term: "Segregation", t: "The separation of the coarse aggregate from the paste — from over-wet mixes, over-vibration, or dropping concrete from a height. It leaves stone pockets and weak, sandy zones. A cohesive mix resists it." },
            { k: "list", items: [
              "<strong>Test</strong> — a frustum of a cone 300 mm high, 200 mm diameter at the base and 100 mm at the top, filled in four layers each tamped 25 times with a 16 mm rod; the cone is lifted vertically in 5–7 seconds and the drop of the highest point is the slump (<a href=\"https://www.jkcement.com/blog/material-guide/concrete-slump-test/\" target=\"_blank\" rel=\"noopener\">JK Cement</a>; the governing test standard is IS 1199).",
              "<strong>Typical slumps</strong> (same source) — mass concrete 25–50 mm, footings and slabs 50–100 mm, beams and columns 75–100 mm, pumped concrete 100–150 mm.",
              "<strong>Shapes</strong> — a true slump subsides evenly; a shear slump (one side slides off) means a harsh, lean mix and the test should be repeated; a collapse means the mix is far too wet.",
            ] },
            { k: "note", t: "The workability table that used to sit in IS 456 (Cl. 7.1) linked placing conditions to slump and compacting factor; current practice refers to IS 7861 and the project specification. The figures above are practical guidance, not a code table." },
            { k: "trap", t: "The instinct is to make concrete 'more workable' by adding water. That raises slump and workability but wrecks the w/c ratio and invites segregation. Real workability comes from grading, sand content and admixtures — the aim is the lowest slump your placing method can handle." },
          ],
        },
        {
          n: "4.2",
          title: "Batching, mixing and placing",
          hi: "बैचिंग, मिक्सिंग, प्लेसिंग",
          blocks: [
            { k: "p", t: "Between the store and the formwork, concrete is measured, mixed and placed — and each step has a way it commonly goes wrong." },
            { k: "cmp", t: "Volume vs weight batching",
              cols: ["Weigh-batching", "Volume-batching"],
              rows: [
                ["Accuracy", "high — by mass", "poor — sand bulks with moisture"],
                ["Where used", "design mixes, RMC, quality work", "small nominal-mix jobs"],
                ["Main risk", "—", "damp sand fills the box with less sand"],
              ] },
            { k: "def", term: "Bulking of sand", t: "Damp sand swells — a film of water pushes the grains apart — so a boxful of damp sand contains less actual sand than the same box of dry sand, by as much as 20–30%. Volume-batching damp sand therefore under-doses the sand and throws the mix off. Weigh-batching avoids it entirely." },
            { k: "eg", title: "Example 4.1 — Correcting a volume batch for bulking",
              given: "A nominal mix needs 0.42 m³ of (dry) sand per m³ of concrete (Example 6.1). The site sand, at its present moisture, bulks by 20%.",
              steps: [
                { t: "Volume of damp sand to measure", w: "0.42 × 1.20 = 0.504 m³" },
                { t: "What happens if you don't correct", w: "measuring 0.42 m³ of damp sand delivers only 0.42/1.20 = 0.35 m³ of sand\n— 17% short, so the mix is over-cemented and harsh, with too little fines" },
              ],
              ans: "Measure 0.50 m³ of damp sand, not 0.42. Bulking varies with moisture (it falls again as sand approaches saturation), so check it on the day — or weigh-batch and correct for water instead." },
            { k: "list", items: [
              "<strong>Mixing</strong> — long enough for uniform colour and consistency; under-mixing leaves streaks of unbonded material.",
              "<strong>Transport</strong> — without segregation or excessive delay; concrete must be placed before initial set.",
              "<strong>Placing</strong> — in layers, close to its final position, never dropped from a height (the stones separate on the way down).",
            ] },
          ],
        },
        {
          n: "4.3",
          title: "Compaction — the step that pays back most",
          hi: "संघनन",
          blocks: [
            { k: "p", t: "Placing concrete traps air. Compaction drives it out. This is the single most cost-effective step in the whole process, because trapped air is pure lost strength and removing it costs only effort." },
            { k: "dia", id: "hb-ct-voids", cap: "Voids from poor compaction, and what they cost in strength." },
            { k: "p", t: "The numbers are stark: about 5% of trapped voids costs roughly 30% of the strength — a whole grade or more (Neville's figure, cited in an <a href=\"https://www.nbmcw.com/product-technology/construction-chemicals-waterproofing/concrete-admixtures/the-invisible-problem-of-poor-compaction-in-real-structures.html\" target=\"_blank\" rel=\"noopener\">NBM&CW review, citing Neville</a>, whose own tests found ~36% loss with no compaction and ~15% with only 10 tampings per layer). A perfectly designed M30 mix, poorly compacted, can test as M20. Compaction is done by rodding (small work), or by immersion or form vibrators (most structural work)." },
            { k: "trap", t: "Over-vibration is the opposite error and just as real: vibrate too long and the heavy aggregate sinks while paste and water rise, segregating the mix and leaving a weak, laitance-covered top. Vibrate until the air stops rising and the surface just glistens — then stop." },
            { k: "real", t: "Honeycombing — the rough, stony, voided patches you see on a stripped column, especially at the base and around congested bars — is compaction failure made visible. The concrete never flowed around the steel and the air never came out. <strong>It is the most common and most avoidable defect on any site.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "ct-5",
      n: 5,
      title: "Hardened Concrete — Strength, Stiffness, Shrinkage and Creep",
      hi: "कठोर कंक्रीट",
      blurb: "What the grade really means, why the cube test aims above it, how stiff concrete is, and the two slow movements — shrinkage and creep — that act long after it has set.",
      mins: 34,
      sections: [
        {
          n: "5.1",
          title: "The cube test and characteristic strength",
          hi: "क्यूब टेस्ट और अभिलाक्षणिक सामर्थ्य",
          blocks: [
            { k: "p", t: "Concrete strength is measured by crushing standard cubes (150 mm, cured 28 days, in a compression machine) and it always scatters — nominally identical cubes give a spread of results. That scatter is why the grade is defined the way it is." },
            { k: "dia", id: "hb-ct-cube", cap: "Why the target mean strength is set above the grade." },
            { k: "def", term: "Characteristic strength (fck)", t: "The compressive strength below which not more than 5% of test results are expected to fall. It is the grade — M25 means fck = 25 N/mm². It is a floor with a 1-in-20 tolerance, not an average." },
            { k: "eg", title: "Example 5.1 — Target mean strength for a mix",
              given: "You are designing an M25 mix with no site data, so the assumed standard deviation from IS 10262:2019 is used: s = 4.0 N/mm² for M20–M25 (good control). For M20–M25 the code's factor X = 5.5 N/mm². What mean strength must the mix be designed for?",
              steps: [
                { t: "IS 10262:2019 — two expressions, take the higher", w: "f′ck = fck + 1.65 s   (1.65 sets the 5% tail)\nf′ck = fck + X" },
                { t: "Substitute", w: "fck + 1.65 s = 25 + 1.65 × 4.0 = 31.6 N/mm²\nfck + X     = 25 + 5.5 = 30.5 N/mm²\n→ 31.6 N/mm² governs" },
                { t: "If site control is only ‘fair’", w: "the code adds 1 N/mm² to s: s = 5.0 → 25 + 8.25 = 33.25 N/mm²" },
              ],
              ans: "Design the mix to average 31.6 N/mm², not 25. The 6.6 N/mm² cushion is what keeps only 1 result in 20 below the M25 floor. Tighter site control (smaller σ) shrinks that cushion and lets you use less cement — good control is money." },
            { k: "note", t: "The ‘fck + X’ check was added in IS 10262:2019 as a floor on the margin. Values of X and assumed s for M20–M25 (5.5 and 4.0) agree in <a href=\"https://pdfcoffee.com/is-10262-2019-pdf-free.html\" target=\"_blank\" rel=\"noopener\">the standard's text as posted on PDFCOFFEE</a> and <a href=\"https://www.slideshare.net/slideshow/4is102622019newmixdesignpdf/252161443\" target=\"_blank\" rel=\"noopener\">a SlideShare summary</a>; the two disagree on the grade ranges above M25 (one gives s = 6.0 from M50, the other from M65), so read those rows from the published standard." },
            { k: "note", t: "This is why quality control pays for itself. σ measures your site's scatter; a well-run site with a small σ can aim its mix lower and still meet the grade, using less cement per cubic metre. Sloppy control forces a bigger cushion and wastes cement on every pour." },
          ],
        },
        {
          n: "5.2",
          title: "Stiffness — the modulus of elasticity",
          hi: "प्रत्यास्थता गुणांक",
          blocks: [
            { k: "p", t: "Strength is how much load concrete carries; stiffness is how much it deflects under that load. They are related but not the same, and stiffness is what governs deflection and how load shares between members." },
            { k: "eq", expr: "Ec = 5000 √fck   (N/mm², IS 456)", where: [
              ["Ec", "short-term modulus of elasticity of concrete"],
              ["fck", "characteristic compressive strength, N/mm²"],
            ] },
            { k: "p", t: "The square-root form carries a lesson: stiffness grows only with the square root of strength. Double the grade and the concrete is nowhere near twice as stiff. So you cannot solve a deflection problem simply by specifying stronger concrete — a deeper section is far more effective." },
            { k: "note", t: "Ec here is the short-term (instantaneous) modulus. Under sustained load, creep makes concrete effectively much less stiff over time — which the next section takes up, and which is why long-term deflection is always larger than the first-day deflection." },
            { k: "eg", title: "Example 5.2 — Short-term stiffness of three grades",
              given: "Compare Ec for M20, M30 and M40 by IS 456.",
              steps: [
                { t: "Ec = 5000 √fck", w: "M20: 5000 × 4.472 = 22,360 N/mm²\nM30: 5000 × 5.477 = 27,386 N/mm²\nM40: 5000 × 6.325 = 31,623 N/mm²" },
              ],
              ans: "Doubling the grade from M20 to M40 raises stiffness by only 41% — a 20% deeper beam (stiffness ∝ depth³) would do more than that." },
          ],
        },
        {
          n: "5.3",
          title: "Shrinkage and creep — the slow movements",
          hi: "संकुचन और क्रीप",
          blocks: [
            { k: "p", t: "Concrete keeps moving long after it has set, through two slow, permanent processes. Neither is a defect; both must be designed for, because both cause cracking and long-term deflection if ignored." },
            { k: "cmp", t: "Two different slow movements",
              cols: ["Shrinkage", "Creep"],
              rows: [
                ["Cause", "loss of moisture as it dries", "sustained load over time"],
                ["Needs load?", "no — happens unloaded", "yes — only under stress"],
                ["Result", "shortening, cracking if restrained", "extra deflection, stress redistribution"],
                ["Worsened by", "high w/c, rich mix, dry air", "high sustained stress, loading young"],
              ] },
            { k: "def", term: "Drying shrinkage", t: "The gradual shortening of concrete as the excess mixing water leaves. If the member is restrained from shortening (and it usually is), the restraint puts it in tension and it cracks. More water in the mix means more to lose and more shrinkage — another reason to keep w/c low." },
            { k: "p", t: "IS 456 gives working values for both: in the absence of test data the total shrinkage strain may be taken as <strong>0.0003</strong> (Cl. 6.2.4.1), and the creep coefficient depends on the age at loading, as tabulated below." },
            { k: "tbl", id: "tb-creep" },
            { k: "eg", title: "Example 5.3 — Why restrained shrinkage cracks concrete",
              given: "An M25 slab strip, fully restrained against shortening, undergoes the IS 456 shrinkage strain of 0.0003. Ignore creep relief.",
              steps: [
                { t: "Stress if fully restrained", w: "σ = ε Ec = 0.0003 × 25,000 = 7.5 N/mm² (tension)" },
                { t: "Tensile capacity", w: "fcr = 0.7 √25 = 3.5 N/mm² (IS 456 Cl. 6.2.2)" },
              ],
              ans: "The restraint stress is about twice the tensile strength, so the slab cracks. In reality creep relieves part of the stress over time, but not enough — which is why slabs need distribution steel and joints, and why curing (which delays drying while the concrete is weak) matters." },
            { k: "def", term: "Creep", t: "The slow, continued deformation of concrete under sustained load. A column under steady load keeps shortening for years; a beam keeps sagging. It roughly doubles or trebles the initial elastic deflection, so long-term deflection is always the governing check." },
            { k: "real", t: "The two combine in a real slab: shrinkage cracks it as it dries in the first months, and creep goes on increasing its sag for years under the sustained dead load. This is why deflection is checked for the long term, not the first day, and why curing (which limits shrinkage) and not overloading young concrete both matter. <strong>Concrete never quite stops moving.</strong>" },
          ],
        },
      ],
    },

  );
})();
