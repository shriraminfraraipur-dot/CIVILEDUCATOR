/* Surveying class notes — theodolite: types, parts, definitions, fundamental lines, temporary adjustments, repetition and reiteration, notes p.144–160 — inserted into sv chapter 8 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 8; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------------- 1 */
    { n: "", title: "Notes — theodolite and its classification", hi: "थियोडोलाइट और उसका वर्गीकरण", blocks: [
      { k: "h", t: "📘 Notes — p.144–145" },
      { k: "def", term: "Theodolite", t: "A theodolite is an important instrument for measuring <b>horizontal angles</b> as well as <b>vertical angles</b>. (p.144)" },
      { k: "h", t: "Classification (1) — by rotation of the telescope" },
      { k: "def", term: "(i) Transit theodolite", t: "A theodolite is said to be <b>transit</b> if its telescope can be rotated through <b>180° in the vertical plane, about its horizontal axis</b> — thus directing the telescope in exactly the opposite direction. (p.144)" },
      { k: "def", term: "(ii) Non-transit theodolite", t: "A theodolite is said to be <b>non-transit</b> if its telescope <b>cannot</b> be rotated through 180°. This type of theodolite is <b>outdated</b> now. (p.144)" },
      { k: "h", t: "Classification (2) — by the reading system" },
      { k: "def", term: "(1) Vernier theodolite", t: "In a vernier theodolite, <b>verniers</b> are used for taking the readings. These theodolites are the most commonly used. <b>Least count of the theodolite is 20″.</b> (p.144–145)" },
      { k: "def", term: "(2) Precise optical theodolite", t: "Fitted with an <b>optical system</b> which is used to measure horizontal and vertical angles precisely. This type of theodolite has a <b>micrometer</b> for taking readings, and it is also called a <b>micro-optic theodolite</b>. These are used for very precise work and can read the readings up to <b>1 sec or less</b>. (p.145)" },
      { k: "cmp", t: "Two classifications of theodolite (p.144–145)", cols: ["Type 1", "Type 2"], rows: [
        ["By telescope rotation", "Transit — telescope turns 180° in vertical plane about horizontal axis", "Non-transit — cannot turn 180° (outdated)"],
        ["By reading system", "Vernier — verniers, least count 20″, most common", "Precise optical (micro-optic) — micrometer, reads to 1″ or less"],
      ] },
      { k: "note", t: "<b>Note — size of a theodolite:</b> the size of a theodolite is defined by the size of its <b>lower graduated circle</b>, i.e. the lower plate. E.g. a <b>20 cm theodolite</b> means the diameter of the graduated circle of the lower plate is 20 cm. Generally the size of theodolite varies from <b>8 – 25 cm</b>. (p.145)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Do alag sawaal, do alag classification. Pehla: kya telescope ulta (180°) ghoom sakta hai? Ghoom sakta hai to <b>transit</b>, nahi to <b>non-transit</b>. Doosra: reading kaise padhte hain? Vernier se (20″ tak) ya optical micrometer se (1″ ya usse kam). Aaj ke saare theodolite transit hote hain — isliye face left / face right observation (section 8.2) possible hai." },
      { k: "p", t: "Size hamesha <b>lower plate ke graduated circle ka diameter</b> hota hai — telescope ki length nahi, aur upper plate nahi. Bada circle = graduations zyada door-door = padhna aasaan." },
      { k: "trap", t: "\"20 cm theodolite\" ko telescope ki length ya instrument ki height samajhna galat hai. It is the <b>diameter of the lower plate's graduated circle</b> (p.145). Aur 20″ least count ko 20 cm size se mat milao — dono alag cheezein hain." },
    ] },

    /* ---------------------------------------------------------------- 2 */
    { n: "", title: "Notes — the telescope and the diaphragm", hi: "दूरबीन और डायाफ्राम", blocks: [
      { k: "h", t: "📘 Notes — p.145–147" },
      { k: "h", t: "Main parts of theodolite — 1) Telescope" },
      { k: "list", items: [
        "Figure (p.145): longitudinal section of an <b>internal-focusing telescope</b> tube (horizontal cylinder, dashed line along its axis). From the left: <b>eye piece</b> (small rod projecting out of the left end); <b>diaphragm</b> (vertical element with hatched blocks at top and bottom); <b>focusing lens</b> (double-concave lens); a <b>focusing screw</b> (knob on top of the tube, above the focusing lens); at the right end the <b>objective</b> (convex lens).",
      ] },
      { k: "p", t: "The telescope is mounted on a horizontal spindle; it is called the <b>horizontal axis</b> or <b>trunnion axis</b>. The telescope can be rotated in the vertical plane about the horizontal axis for the purpose of sighting the object. (p.145)" },
      { k: "p", t: "The telescope is of the <b>internal focusing</b> type. In an internal focusing telescope the <b>objective lens is fixed</b> in position. By moving the <b>focusing lens</b>, the image of the object formed by the objective is brought into the plane of the cross hairs, i.e. the diaphragm. (p.146)" },
      { k: "p", t: "Due to the internal focusing lens, dust etc. does not enter inside the telescope, because the telescope tube is closed. (p.146)" },
      { k: "h", t: "Diaphragm and cross hairs" },
      { k: "p", t: "The diaphragm consists of a <b>thin glass disc</b> mounted in a circular ring. This ring is held in position in the telescope by <b>four screws</b> arranged at right angles. Lines are etched on the glass disc at right angles to each other; these lines are called <b>cross hairs</b>. (p.146)" },
      { k: "list", items: [
        "Figure (p.146): diaphragm seen end-on — outer circular hatched ring; inner hatched circular glass disc with one vertical and one horizontal line crossing at the centre, labelled <b>cross hair disc</b>; four screws passing radially through the ring at top, bottom, left and right (at right angles), heads outside the ring; caption <b>Capstan screw</b>.",
      ] },
      { k: "p", t: "The <b>eyepiece is focused on the diaphragm</b>, and by using the <b>focusing screw</b> the image is formed at the location of the diaphragm. (p.147)" },
      { k: "p", t: "The telescope is attached to the <b>vertical circle</b>, so when the telescope moves in the vertical plane, the vertical circle also moves in the vertical plane. (p.147)" },
      { k: "note", t: "★ The vertical circle and telescope are attached to the <b>trunnion axis</b>, which is supported on the <b>A-frame</b>. (p.147)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Telescope mein do focusing hoti hain aur dono ka kaam alag hai. <b>Eyepiece</b> ko cross hairs par focus karte hain — taaki tumhari aankh ko hairs sharp dikhein. Phir <b>focusing screw</b> se focusing lens aage-peeche karke object ki image ko usi diaphragm wale plane mein laate hain. Jab dono ek hi plane mein aa jaayein, tab image aur cross hair saath-saath dikhte hain aur parallax khatam ho jaata hai." },
      { k: "p", t: "Internal focusing ka fayda: objective hilta nahi, tube band rehti hai, isliye dhool andar nahi jaati aur line of sight stable rehti hai." },
      { k: "trap", t: "Internal focusing telescope mein <b>objective fixed</b> hota hai — focusing lens move karta hai. Students ulta likh dete hain ki objective aage-peeche hota hai. Aur order yaad rakho: eyepiece pehle (cross hairs ke liye), objective focusing baad mein (object ke liye) — p.158 ki temporary adjustment list bhi yahi order deti hai." },
      { k: "real", t: "Capstan screws (four, at right angles) ko site par sirf permanent adjustment ke time chhedte hain — inhi se diaphragm ko khiska kar line of collimation set ki jaati hai. Routine kaam mein inhe nahi chhoona." },
    ] },

    /* ---------------------------------------------------------------- 3 */
    { n: "", title: "Notes — vertical circle, T-frame, vertical clamp, altitude bubble", hi: "ऊर्ध्व वृत्त, T-फ्रेम और ऊँचाई बुलबुला", blocks: [
      { k: "h", t: "📘 Notes — p.147–149" },
      { k: "h", t: "Vernier frame (T-frame / index frame)" },
      { k: "list", items: [
        "Figure (p.147): the <b>vertical circle</b> (large oval) with the vernier T-frame in front of it — a horizontal <b>index bar</b> with a central pivot and a <b>vernier</b> at each end (left and right); a small rectangular <b>altitude bubble</b> mounted on top of the bar; a vertical leg going down from the bar, labelled <b>T-frame</b>; at its lower end a fork with a screw labelled <b>clipping screw</b>. A dashed horizontal line passes through the bar.",
      ] },
      { k: "p", t: "The vernier frame, also called the <b>T-frame</b> or <b>index frame</b>, consists of a vertical leg called the <b>clipping arm</b> and a horizontal bar called the <b>index arm</b>. (p.147)" },
      { k: "p", t: "The vertical leg of the T-frame is provided with a <b>fork and screw</b>, called the <b>clipping screw</b>, at its lower end. (p.147)" },
      { k: "note", t: "It may be noted that the <b>verniers C and D are stationary</b>, whereas the <b>main vertical scale moves</b> when the telescope is rotated in the vertical plane for measurement of a vertical angle. (p.147)" },
      { k: "p", t: "The <b>index arm is horizontal</b> and becomes the reference for measuring the vertical angle. (p.148)" },
      { k: "list", items: [
        "Figure (p.148): vertical circle graduated <b>0° at left and 0° at right</b> on the horizontal diameter, <b>90° at top and 90° at bottom</b>. The horizontal dashed line through the centre is the <b>index arm</b>. An inclined line through the centre is the <b>line of sight</b>; the curved arrow from the horizontal (right 0°) to the line of sight is marked <b>vertical angle (θ)</b>.",
      ] },
      { k: "p", t: "When the line of sight is horizontal, the index arm reads [zero] on the vertical circle. As the vertical circle rotates [with the telescope], the index arm reads some angle on the vertical circle — that reading is the vertical angle. (p.148)" },
      { k: "h", t: "Vertical clamp screw and vertical tangent screw" },
      { k: "p", t: "The vertical circle and telescope can be clamped at any desired vertical angle by means of the <b>vertical clamp screw</b>. Thus the rotation of the telescope about the horizontal axis is prevented. However, after tightening [the clamp], a small rotation of the telescope in the vertical plane can be given by means of the <b>vertical tangent screw</b>. (p.148)" },
      { k: "def", term: "Altitude bubble", t: "It is attached to the <b>index arm</b>; hence to make the index arm horizontal during temporary adjustment, the altitude bubble is used. (p.149)" },
      { k: "def", term: "Striding level", t: "A very sensitive level which is sometimes mounted <b>at right angles to the telescope</b>. (p.149)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Vertical angle naapne mein <b>circle ghoomta hai, index (verniers C, D) khade rehte hain</b>. Index arm horizontal hai — yahi zero reference hai. Telescope upar uthaya, circle bhi saath uthा, aur fixed index ke saamne jo graduation aaya wahi vertical angle hai. Isliye index arm ka sach mein horizontal hona zaroori hai, aur yeh kaam altitude bubble karta hai." },
      { k: "p", t: "Clamp + tangent screw ki jodi har jagah dikhegi: clamp se rough position lock, tangent screw se fine movement. Vertical ke liye ek jodi, upper plate ke liye ek, lower plate ke liye ek." },
      { k: "trap", t: "Horizontal circle mein ulta hota hai: wahan <b>graduated circle (lower plate) ruka rehta hai aur verniers A, B (upper plate) ghoomte hain</b>. Vertical circle mein <b>circle ghoomta hai, verniers C, D stationary</b> (p.147). MCQ mein yeh adla-badli pakdi jaati hai." },
    ] },

    /* ---------------------------------------------------------------- 4 */
    { n: "", title: "Notes — upper plate, lower plate and the two clamps", hi: "ऊपरी प्लेट, निचली प्लेट और क्लैम्प", blocks: [
      { k: "h", t: "📘 Notes — p.149–152" },
      { k: "h", t: "Upper plate (vernier plate)" },
      { k: "list", items: [
        "Figure (p.149): section of the plates and spindles about a vertical line marked <b>Vertical axis</b>. Top: a wide plate tapering down into a conical <b>inner spindle</b>, labelled <b>upper plate</b>; small steps at its top-left and top-right edges labelled <b>Vernier B</b> (left) and <b>Vernier A</b> (right). Around the inner spindle, a hollow conical sleeve labelled <b>lower plate</b> / <b>outer spindle</b>. A horizontal screw through the upper part on the right labelled <b>upper clamp</b>; screws lower down at the outer spindle, the left one labelled <b>lower clamp</b>.",
      ] },
      { k: "list", items: [
        "At its lower face the upper plate is attached to a vertical spindle which is called the <b>inner spindle</b>. (p.149)",
        "When the upper plate is unclamped, the inner spindle rotates in the <b>outer spindle</b>, attached to the lower plate. (p.149)",
        "The upper plate can be clamped to the lower plate with the <b>upper clamp screw</b>. (p.149)",
        "The <b>upper tangent screw</b> is used for making small movements of the upper plate after tightening the upper clamp screw. (p.149)",
        "After the upper plate is clamped, both the upper and lower plates move together as one unit. (p.150)",
      ] },
      { k: "note", t: "<b>Note:</b> if the upper plate is unclamped, the upper plate rotates w.r.t. the lower plate and the <b>vernier readings change</b>; if the upper plate is tightened, the vernier reading does not change. The upper plate is also called the <b>vernier plate</b>; it supports the <b>standard (A-frame)</b> at its top. (p.150)" },
      { k: "p", t: "Figure (p.150) — \"theodolite pattern\", the parts stacked from top to bottom:<br>Telescope + Vertical circle → (horizontal spindle) Trunnion axis → A-frame → Upper plate → Lower plate → Tribrach → Trivet → Tripod. (p.150)" },
      { k: "h", t: "Lower plate (main plate)" },
      { k: "list", items: [
        "It is also called the <b>main-scale plate</b> or <b>horizontal circle</b>, and is mounted on a hollow tapered spindle called the <b>outer spindle</b> or outer centre. (p.151)",
        "The lower plate is graduated in degrees from <b>0° – 360°</b> with least count <b>20″</b>. (p.151)",
        "The graduation increases in the <b>clockwise</b> direction. (p.151)",
        "The horizontal circle readings are measured by means of <b>verniers A and B</b>. (p.151)",
        "The lower plate is provided with a <b>lower clamp screw</b>. (p.151)",
        "If the lower clamp screw is tightened, the outer spindle is fixed to the tribrach and hence the lower plate is fixed in position. (p.151)",
        "After tightening the lower clamp screw, the lower plate can be rotated slightly by rotation of the [lower] tangent screw. (p.151)",
      ] },
      { k: "h", t: "★★ The clamp combinations (p.151–152)" },
      { k: "cmp", cols: ["Upper clamp", "What happens"], rows: [
        ["(1) Lower clamp tightened", "Tightened", "No movement — no movement in the theodolite."],
        ["(2) Lower clamp tightened", "Unclamped", "Lower plate does not move but the upper plate moves; thus the vernier moves, hence the <b>vernier readings change</b>."],
        ["(3) Lower clamp unclamped", "Tightened", "Upper and lower plates move together; movement of vernier w.r.t. horizontal circle is zero, hence the <b>vernier reading does not change</b>."],
      ] },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Socho do plate ek ke upar ek: neeche <b>scale</b> (lower plate, 0°–360° clockwise), upar <b>sui</b> (upper plate ke verniers A, B). Reading tabhi badalti hai jab sui scale ke saapeksh ghoome. Upper clamp khula aur lower band → sui ghoomti hai, scale ruka → reading badli (angle naapne ka kaam). Upper band aur lower khula → sui aur scale saath ghoomte hain → reading wahi rehti hai (telescope ko set reading ke saath kisi naye point par le jaane ka kaam)." },
      { k: "p", t: "Yahi combination (3) repetition method ki jaan hai — pichla padha hua angle circle par 'pakad' ke rakha jaata hai aur telescope wapas pehle point par le jaate hain (section 8.2 dekho)." },
      { k: "trap", t: "Combination (2) aur (3) ko ulta yaad karna sabse aam galti hai. Rule: <b>reading badalne ke liye upper clamp khulna chahiye</b>. Lower clamp khulne se reading kabhi nahi badalti, kyunki tab poora scale bhi saath ghoomta hai." },
      { k: "real", t: "Field mein: pehle point par 0°00′00″ set karna ho to upper clamp band, lower khula — sight karo, lower band karo, lower tangent screw se exact bisect karo. Phir upper khol kar doosre point par jaao aur upper tangent screw se bisect karo." },
    ] },

    /* ---------------------------------------------------------------- 5 */
    { n: "", title: "Notes — plate level, levelling head, shifting head", hi: "प्लेट लेवल, लेवलिंग हेड और शिफ्टिंग हेड", blocks: [
      { k: "h", t: "📘 Notes — p.152–154" },
      { k: "list", items: [
        "Figure (p.152) — elevation sketch titled <b>Theodolite</b>. From the top: large <b>vertical circle</b> with verniers <b>C</b> and <b>D</b> on arcs at top-left and top-right, and a small <b>altitude level</b> on top of the index bar; the <b>telescope</b> drawn diagonally across the circle — upper-left end <b>objective</b> with the <b>line of sight</b>, lower-right end <b>eyepiece</b>. Below the circle the <b>A-frame</b>, with small clamp screws on both legs. <b>Plate level</b> on top of the <b>upper plate</b>; below it a block with the <b>upper clamp</b> on the right; then the thin <b>lower plate</b> with the <b>lower clamp</b> on the left; then the <b>shifting head</b>; then the wide <b>tribrach</b>; three <b>levelling screws</b> under the tribrach resting on the <b>trivet</b>; then the <b>tripod</b> legs.",
      ] },
      { k: "h", t: "Plate level" },
      { k: "list", items: [
        "A level tube called the <b>plate level</b> is mounted on the upper plate; the bubble is centred with the help of the <b>levelling screws</b>. In some instruments there are <b>two plate levels</b> mounted horizontally at right angles to each other on the upper plate. (p.153)",
        "One of the plate levels is <b>parallel to the trunnion axis</b> and the other one is <b>perpendicular to the trunnion axis</b>. (p.153)",
        "These plate levels are used to make the <b>vertical axis</b> of the instrument truly vertical. (p.153)",
      ] },
      { k: "def", term: "Levelling head", t: "Consists of <b>two parallel plates</b>, separated by <b>three levelling screws</b>. The upper parallel plate of the levelling head is known as the <b>tribrach</b> and the lower one is called the <b>trivet stage</b> or <b>foot plate</b>. The levelling head supports the upper part of the instrument. (p.153)" },
      { k: "def", term: "Shifting head", t: "The shifting head allows slight movement of the instrument in the horizontal direction while the tripod remains at the station. The instrument is first centred <b>approximately</b> over the station by means of the tripod, and <b>exact centring</b> is then achieved by the shifting head. (p.153–154)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Neeche se upar padho: tripod → trivet (foot plate) → teen levelling screws → tribrach → shifting head → lower plate → upper plate → A-frame → trunnion axis → telescope + vertical circle. Har hissa ek kaam karta hai: tripod rough centring, shifting head exact centring, levelling screws + plate level vertical axis ko vertical, aur upar wale hisse angle naapte hain." },
      { k: "p", t: "Do plate levels at right angles isliye ki ek bubble sirf ek direction ka tilt dikhata hai; do perpendicular directions theek ho gayi to poora plate horizontal aur vertical axis vertical." },
      { k: "trap", t: "Tribrach = levelling head ki <b>upper</b> plate; trivet = <b>lower</b> plate (foot plate). Naam ulte mat karo. Aur plate level ka kaam vertical axis ko vertical karna hai — line of sight ko horizontal karna nahi (woh altitude bubble / index arm ka kaam hai)." },
    ] },

    /* ---------------------------------------------------------------- 6 */
    { n: "", title: "Notes — basic definitions (centring to balancing-in)", hi: "मूल परिभाषाएँ", blocks: [
      { k: "h", t: "📘 Notes — p.154–157" },
      { k: "def", term: "1) Centring", t: "The process of setting up the instrument <b>exactly over the station</b> marked. A <b>plumb-bob</b> suspended from a small hook attached to the underside of the inner spindle is used for precise centring. (p.154)" },
      { k: "def", term: "2) Horizontal axis", t: "Also called the <b>trunnion axis</b>. It is the axis about which the telescope rotates in the <b>vertical plane</b>. (p.154)" },
      { k: "def", term: "3) Vertical axis", t: "The axis about which the telescope rotates in the <b>horizontal plane</b>. It is also called the <b>azimuth axis</b>. (p.154)" },
      { k: "def", term: "4) Line of sight", t: "The imaginary line passing through the <b>intersection of the cross hairs</b> of the diaphragm and the <b>optical centre of the objective</b>. (p.154)" },
      { k: "list", items: [
        "Figure (p.154): telescope tube as a horizontal cylinder — left end <b>eye piece</b>; a vertical line inside near the left-middle marked <b>intersection of cross-hair</b>; right end marked <b>optical centre of objective</b>; a horizontal line through the tube along its axis marked <b>line of sight</b>.",
      ] },
      { k: "def", term: "5) Face right", t: "When the vertical circle of the theodolite is on the <b>right-hand side</b> of the observer, the position is called face right, and the observation made is called a face right observation. (p.155)" },
      { k: "def", term: "6) Face left", t: "When the vertical circle of the theodolite is on the <b>left-hand side</b> of the observer, the position is called face left, and the observation made is called a face left observation. (p.155)" },
      { k: "def", term: "7) Telescope normal", t: "The telescope is said to be <b>normal</b> or <b>direct</b> if the vertical circle is to the <b>left-hand side</b> of the observer and the <b>bubble is up</b>. (p.155)" },
      { k: "def", term: "8) Telescope inverted", t: "The telescope is said to be <b>inverted</b> when the vertical circle [notes write \"curve\"] is to the <b>right-hand side</b> of the observer and the <b>bubble is down</b>. (p.155)" },
      { k: "def", term: "9) Transit", t: "Also called <b>plunging</b> or <b>reversing</b>. The operation of revolving the telescope by <b>180° in the vertical plane about the horizontal axis</b>, thus making it point exactly in the opposite direction. (p.155)" },
      { k: "def", term: "10) Swinging", t: "Revolving the telescope in the <b>horizontal plane about the vertical axis</b> is called swinging of the telescope. A <b>right swing</b> means rotation in the <b>clockwise</b> direction and a <b>left swing</b> means rotation in the <b>anti-clockwise</b> direction. (p.156)" },
      { k: "def", term: "11) Changing face", t: "The operation of bringing the telescope from face left to face right or vice-versa. The face is changed by <b>plunging the telescope and swinging it by 180°</b>. (p.156)" },
      { k: "p", t: "★ The errors that are eliminated by changing the face are — (p.156)" },
      { k: "steps", items: [
        "Error due to the <b>horizontal axis not being perpendicular to the vertical axis</b>.",
        "Error due to the <b>line of collimation</b>.",
        "[Error due to axis of altitude level not being] <b>parallel</b> — notes write only \"Parallel to axis of altitude level\". (p.156)",
      ] },
      { k: "def", term: "12) Double sighting", t: "The process of measuring a horizontal angle or vertical angle <b>twice</b> — once with the telescope in the <b>normal</b> condition and once with the telescope in the <b>inverted</b> condition. (p.156)" },
      { k: "def", term: "13) Lining-in", t: "The process of establishing <b>intermediate points</b> with the help of a theodolite on a given straight line whose end points are <b>intervisible</b>. (p.157)" },
      { k: "def", term: "14) Balancing-in", t: "The process of establishing intermediate points with the help of a theodolite on a straight line whose end points are <b>not intervisible</b>. (p.157)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Teen movement words alag rakho: <b>transit / plunging</b> = vertical plane mein 180° (horizontal axis ke around); <b>swinging</b> = horizontal plane mein (vertical axis ke around); <b>changing face</b> = dono — pehle plunge, phir 180° swing. Face left = normal (circle left, bubble up); face right = inverted (circle right, bubble down)." },
      { k: "p", t: "Face badalne se error kyun hatte hain: horizontal-axis ka tilt aur collimation ka error face left par ek taraf aur face right par utna hi doosri taraf padta hai, isliye dono readings ka <b>mean</b> error-free hota hai. Isi baat ko section 8.2 detail mein samjhata hai — wahan yeh bhi likha hai ki vertical axis ka non-vertical hona face change se nahi hatta." },
      { k: "trap", t: "Lining-in vs balancing-in: farak sirf <b>end points intervisible hain ya nahi</b> ka hai. Ends ek-doosre se dikhte hain → lining-in; beech mein pahadi jaisa obstruction, ends nahi dikhte → balancing-in (instrument ko beech mein adjust karke dono ends ke saath 'balance' karte hain)." },
      { k: "real", t: "Road ya pipeline ki straight alignment par pegs lagaane ke liye lining-in roz ka kaam hai; jab alignment kisi tile ke upar se jaati ho aur dono ends ek-doosre ko na dikhen, tab balancing-in." },
    ] },

    /* ---------------------------------------------------------------- 7 */
    { n: "", title: "Notes — fundamental lines and temporary adjustments", hi: "मूल रेखाएँ और अस्थायी समायोजन", blocks: [
      { k: "h", t: "📘 Notes — p.157–158" },
      { k: "p", t: "<b>Fundamental lines of a theodolite</b> are: the <b>vertical axis</b>, the <b>axis of the plate level</b>, the <b>line of collimation</b>, the <b>horizontal axis</b>, and the <b>bubble line of the altitude level</b>. (p.157)" },
      { k: "p", t: "When the theodolite is in proper adjustment, the following conditions should be satisfied — (p.157–158)" },
      { k: "steps", items: [
        "Horizontal circle ⊥ to vertical axis. (p.157)",
        "Vertical circle ⊥ to horizontal axis. (p.157)",
        "Vertical axis must pass through the centre of the graduated horizontal circle. (p.157)",
        "Horizontal axis must pass through the centre of the vertical circle. (p.157)",
        "Tangent to the plate bubble tube must be ⊥ to the vertical axis. (p.157)",
        "Transit axis must be ⊥ to the vertical axis. (p.158)",
        "For the horizontal position of the telescope, with the altitude bubble at centre, the reading on the vertical circle must be zero. (p.158)",
        "★ Line of sight, horizontal axis and vertical axis meet at one point, called the <b>centre of the instrument</b>. (p.158)",
      ] },
      { k: "h", t: "Temporary adjustments of a theodolite (p.158)" },
      { k: "steps", items: [
        "Setting up",
        "Centring",
        "Levelling",
        "Focusing the eyepiece",
        "Focusing the objective",
      ] },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Fundamental lines ka matlab: woh paanch lines jinke aapas ke rishte (⊥, parallel, ek point par milna) sahi hon to instrument sahi angle dega. Conditions ko jodi mein padho: plate level ⊥ vertical axis (taaki bubble centre = axis vertical); transit (horizontal) axis ⊥ vertical axis (taaki telescope plunge karte waqt vertical plane mein ghoome); altitude bubble centre aur telescope horizontal par vertical circle zero (warna index error)." },
      { k: "p", t: "Temporary adjustments har station par hote hain (setting up → centring → levelling → eyepiece → objective); permanent adjustments in fundamental-line conditions ko kabhi-kabhaar workshop/field test se theek karte hain. Existing section 8.1 ki axis list yahi baat chhoti karke kehti hai." },
      { k: "trap", t: "Temporary adjustments ka order MCQ mein aata hai. Eyepiece focusing <b>pehle</b>, objective focusing <b>baad</b> mein — kyunki pehle cross hairs saaf chahiye, tabhi object ki image usi plane mein laayi ja sakti hai. Aur centring levelling se pehle aata hai (p.158)." },
      { k: "real", t: "General Engineering Knowledge: site par centring aur levelling ek-doosre ko bigaadte hain — levelling screws ghumaane se centre thoda khisak sakta hai, isliye levelling ke baad plumb-bob dobara dekho aur shifting head se touch-up karo." },
    ] },

    /* ---------------------------------------------------------------- 8 */
    { n: "", title: "Notes — horizontal angles: repetition and reiteration", hi: "क्षैतिज कोण: पुनरावृत्ति और पुनःपुनरावृत्ति विधि", blocks: [
      { k: "h", t: "📘 Notes — p.158–160" },
      { k: "p", t: "Measurement of horizontal angle — (1) <b>Repetition method</b>, (2) <b>Reiteration method</b>. (p.158)" },
      { k: "def", term: "1) Repetition method", t: "It is used to measure an angle very accurately. In this method the angle is measured <b>several times</b>, and then the value of the angle is equal to (sum of angles) ÷ (no. of observations). (p.158)" },
      { k: "eq", expr: "Angle = (Sum of angles) / (No. of observations)", where: [] },
      { k: "list", items: [
        "Figure (p.158): angle AOB with vertex O at the bottom; line OA going up-left to A, line OB going up-right to B (arrowhead at B); several arcs between OA and OB showing the same angle measured repeatedly.",
      ] },
      { k: "def", term: "2) Reiteration method", t: "This method of reiteration is used when a <b>number of angles</b> are to be measured at <b>one point</b>. The value of each angle is measured successively from the initial point. (p.159)" },
      { k: "list", items: [
        "Figure (p.159): two straight lines crossing at a point — D (top-left) to B (bottom-right, arrowhead at B), and A (top-right) to C (bottom-left). A circle of angles round the intersection: <b>α₁</b> between D and A (top), <b>α₂</b> between A and B (right), <b>α₃</b> between B and C (bottom), <b>α₄</b> between C and D (left).",
        "The angle between the <b>last station and the initial station</b> is also measured, and hereby the <b>horizon is closed</b>. (p.159)",
        "The process of measuring the angles at an instrument station round the point, to obtain a check by their sum being equal to <b>360°</b>, is called [closing the] <b>horizon</b>. (p.159)",
        "If the discrepancy is within the acceptable limit, it is <b>distributed equally</b> in all the angles measured. (p.159)",
        "If the discrepancy is large, then the <b>whole field work is repeated</b>. (p.159)",
        "E.g. if four angles are measured and the initial reading is 0°0′0″ and the final reading on closing the horizon is 0°0′20″, then the small error (20″) is equally distributed. (p.159)",
      ] },
      { k: "list", items: [
        "Figure (p.160): two lines crossing — A (top-left) to C (bottom-right), D (bottom-left) to B (top-right, arrowhead at B). Angles round the intersection: <b>α₁</b> top (between A and B), <b>α₂</b> right (between B and C), <b>α₃</b> bottom (between C and D), <b>α₄</b> left (between D and A).",
      ] },
      { k: "eg",
        title: "Notes example — distributing the closing error of the horizon",
        given: "Initial reading = 0°0′0″. Final reading = 0°0′20″. What will be the correction for each angle, and what will be the correction for α₃?",
        steps: [
          { t: "Error", w: "Error = M.V − T.V\n= 0°0′20″ − 0°0′0″ = 20″" },
          { t: "Total correction", w: "Total correction = −20″" },
          { t: "Correction for each angle", w: "= (−20″)/4 = −5″" },
          { t: "Correction for 3rd angle", w: "= −5″ + (−5″) + (−5″)\n= −15″" },
        ],
        ans: "Correction for each angle = −5″; correction for α₃ (3rd angle) = −15″ (p.160)",
      },
      { k: "note", t: "<b>Check:</b> the arithmetic is right (−20″ ÷ 4 = −5″; 3 × −5″ = −15″). Read the −15″ correctly: it is the correction to the <b>3rd reading (direction) counted from the initial point</b>, because in reiteration each reading is taken successively from the initial point and the corrections accumulate (−5″, −10″, −15″, −20″). The included angle α₃ itself, like every other angle, gets only <b>−5″</b>." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "<b>Repetition</b>: ek hi angle ko baar-baar circle par jodte jaao (clamp combination (3) se pichli reading pakad kar), aakhir mein total ÷ n. Reading error sirf pehli aur aakhri reading mein aata hai, isliye 20″ least count wala instrument bhi kuch seconds tak sahi angle de deta hai — section 8.2 ka Example 8.1 isi ka kaam karke dikhata hai." },
      { k: "p", t: "<b>Reiteration</b>: ek station se kai points — har point ki direction initial point se successively padho, aur aakhir mein wapas initial point par aakar horizon close karo. Saare angles ka sum 360° hona chahiye; jitna bacha woh error. Chhota hai to barabar baanto, bada hai to field work dobara." },
      { k: "trap", t: "\"Correction for α₃\" mein −5″ aur −15″ ka confusion: −5″ har <b>angle</b> ka correction hai; −15″ teesri <b>reading</b> (initial se cumulative) ka. Sawaal dhyan se padho — angle maanga hai ya reading. Aur sign: error = M.V − T.V = +20″, isliye correction = −20″ (ulta sign)." },
      { k: "real", t: "Ek control station se 4–5 points ki directions chahiye hon (triangulation ya traverse junction) to reiteration tez padta hai; ek important angle bahut accurate chahiye ho (jaise bridge ka centre-line angle) to repetition." },
    ] },

    /* ---------------------------------------------------------------- 9 */
    { n: "", title: "Notes revision — theodolite (p.144–160)", hi: "पुनरावृत्ति — थियोडोलाइट", blocks: [
      { k: "h", t: "✅ Key points from the notes" },
      { k: "list", items: [
        "✅ Theodolite measures horizontal and vertical angles. (p.144)",
        "✅ Transit: telescope rotates 180° in vertical plane about horizontal axis; non-transit cannot (outdated). (p.144)",
        "✅ Vernier theodolite — least count 20″, most common; precise optical (micro-optic) — micrometer, reads to 1″ or less. (p.144–145)",
        "✅ Size = diameter of the lower plate's graduated circle; generally 8–25 cm (20 cm theodolite → 20 cm circle). (p.145)",
        "✅ Telescope is internal focusing: objective fixed, focusing lens moves; tube closed, no dust. (p.146)",
        "✅ Diaphragm: glass disc in a ring held by four capstan screws at right angles; cross hairs at right angles. (p.146)",
        "✅ Vertical circle and telescope on the trunnion axis, supported on the A-frame. (p.147)",
        "✅ T-frame (index frame) = clipping arm (vertical leg, clipping screw at bottom) + index arm (horizontal bar). Verniers C, D stationary; vertical circle moves. (p.147)",
        "✅ Index arm horizontal = reference for vertical angle; altitude bubble on the index arm makes it horizontal. (p.148–149)",
        "✅ Vertical clamp screw + vertical tangent screw. Striding level: sensitive level at right angles to telescope. (p.148–149)",
        "✅ Upper (vernier) plate → inner spindle; lower plate → outer spindle. Upper clamp + upper tangent screw. (p.149)",
        "✅ Pattern: telescope + vertical circle → trunnion axis → A-frame → upper plate → lower plate → tribrach → trivet → tripod. (p.150)",
        "✅ Lower (main) plate = horizontal circle, 0°–360° clockwise, least count 20″, read by verniers A and B. (p.151)",
        "✅ Clamps: both tight → no movement; lower tight + upper free → reading changes; lower free + upper tight → reading does not change. (p.151–152)",
        "✅ Plate levels (two at right angles, one ∥ and one ⊥ trunnion axis) make the vertical axis truly vertical. (p.153)",
        "✅ Levelling head: tribrach (upper) + trivet / foot plate (lower), three levelling screws. Shifting head: exact centring after approximate centring with tripod. (p.153–154)",
        "✅ Centring with plumb-bob from hook under inner spindle. Horizontal axis = trunnion axis; vertical axis = azimuth axis. (p.154)",
        "✅ Line of sight: through intersection of cross hairs and optical centre of objective. (p.154)",
        "✅ Face left = circle on observer's left (normal, bubble up); face right = circle on right (inverted, bubble down). (p.155)",
        "✅ Transit = plunging = reversing (180° in vertical plane); swinging = in horizontal plane (right = clockwise, left = anti-clockwise). (p.155–156)",
        "✅ Changing face = plunge + swing 180°; eliminates horizontal-axis-not-⊥-vertical-axis error, line of collimation error, and altitude level axis error. (p.156)",
        "✅ Double sighting = measure once normal, once inverted. (p.156)",
        "✅ Lining-in: end points intervisible; balancing-in: end points not intervisible. (p.157)",
        "✅ Fundamental lines: vertical axis, plate level axis, line of collimation, horizontal axis, altitude bubble line. (p.157)",
        "✅ Eight adjustment conditions; line of sight, horizontal axis and vertical axis meet at the centre of the instrument. (p.157–158)",
        "✅ Temporary adjustments: setting up → centring → levelling → focusing eyepiece → focusing objective. (p.158)",
        "✅ Repetition: angle = sum of angles ÷ no. of observations. (p.158)",
        "✅ Reiteration: many angles at one point, read successively from the initial point; close the horizon (sum = 360°); small discrepancy distributed equally, large → repeat field work. (p.159)",
        "✅ Example: closing error 20″ over 4 angles → −5″ per angle; notes give −15″ for α₃ (cumulative to the 3rd reading). (p.160)",
      ] },
    ] },

  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
