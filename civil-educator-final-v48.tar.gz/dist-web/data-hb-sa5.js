/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: Structural Analysis, Chapters 8–9
   Moment distribution · Arches and cables
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sa"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 8 */
    {
      id: "sa-8",
      n: 8,
      title: "Moment Distribution Method",
      hi: "मोमेंट डिस्ट्रिब्यूशन विधि",
      blurb: "The same physics as slope-deflection, solved by iterating on a table instead of solving equations — the method most worth having in your hand, and the one that keeps its physical meaning all the way through.",
      mins: 32,
      sections: [
        {
          n: "8.1", title: "The idea", hi: "मूल विचार",
          blocks: [
            { k: "p", t: "Hardy Cross's insight was that you do not have to solve the equations of Chapter 7 at all. You can arrive at the same answer by repeatedly correcting a guess, and each correction is smaller than the last." },
            { k: "steps", items: [
              "<strong>Lock</strong> every joint against rotation. Each span now behaves as a fixed-ended beam, so it develops its fixed end moments.",
              "<strong>Release</strong> one joint. The moments meeting there do not balance; the difference is the out-of-balance moment.",
              "<strong>Distribute</strong> it among the members at that joint, in proportion to their stiffnesses, with the sign that restores balance.",
              "<strong>Carry over</strong> half of each distributed moment to the far end of that member, if the far end is fixed.",
              "Lock the joint again, move to the next, and repeat until the out-of-balance moments are negligible.",
            ]},
            { k: "dia", id: "hb-sa-md-cycle" },
            { k: "p", t: "It converges because the carry-over is a half. Each round of corrections that travels outwards is smaller than the round that caused it, so the numbers settle. Three or four cycles is usually more than enough for a continuous beam, and the residual is visible on the page — you stop when it no longer matters at the precision you are working to." },
          ],
        },
        {
          n: "8.2", title: "Stiffness and distribution factors", hi: "कठोरता और वितरण गुणांक",
          blocks: [
            { k: "def", term: "Stiffness k", t: "The moment required at the near end of a member to produce unit rotation there." },
            { k: "eq", expr: "Far end fixed:   k = 4EI/L        Far end pinned:   k = 3EI/L", where: [] },
            { k: "dia", id: "hb-sa-md-stiff" },
            { k: "eq", expr: "DF = k / Σk", where: [
              ["k", "Stiffness of the member at the joint being balanced"],
              ["Σk", "Sum of the stiffnesses of every member meeting at that joint"],
            ]},
            { k: "p", t: "The physical reading matters more than the formula. A joint shares its out-of-balance moment among the members meeting there in proportion to how hard each one resists rotation. A stiff short column takes most of it; a long flexible beam takes little. Watching moment migrate towards the stiff members as the table develops is the intuition that survives long after the arithmetic is forgotten." },
            { k: "tbl", id: "tb-sa-stiff" },
            { k: "trap", t: "<strong>Distribution factors at any joint must add to exactly 1.0.</strong> Check that before you start cycling — it is a one-line test, and it catches a wrong stiffness before it contaminates every row of the table. At a fixed support the DF is 0 (the support absorbs everything); at a simple end support the DF is 1.0 (the joint must end up with zero moment)." },
          ],
        },
        {
          n: "8.3", title: "Worked example — continuous beam", hi: "हल किया उदाहरण — सतत बीम",
          blocks: [
            { k: "eg", title: "Example 8.1 — the Example 6.1 beam again, by moment distribution", given: "Continuous beam ABC, spans AB = BC = 6 m, UDL 20 kN/m over both, A and C simply supported, B continuous, EI constant. Find the moment at B.", steps: [
              { t: "Fixed end moments", w: "FEM = wL²/12 = 20 × 36 / 12 = 60 kNm\n\nClockwise positive:\n  M(AB) = −60      M(BA) = +60\n  M(BC) = −60      M(CB) = +60" },
              { t: "Distribution factors", w: "At B, both members have k = 4EI/6 = 0.667EI, so\n  DF(BA) = DF(BC) = 0.5   (sum = 1.0 ✓)\n\nAt A and C the supports are simple, so those joints must end up with zero moment:\n  DF = 1.0 at each" },
              { t: "Cycle 1 — release A", w: "Out of balance at A = −60\nBalance it by applying +60 at A:\n  M(AB) = −60 + 60 = 0 ✓\n\nCarry over half to B, on member BA:\n  +30" },
              { t: "Cycle 1 — release C", w: "Out of balance at C = +60\nBalance by applying −60:\n  M(CB) = +60 − 60 = 0 ✓\n\nCarry over half to B, on member BC:\n  −30" },
              { t: "Now look at joint B", w: "M(BA) = +60 + 30 = +90\nM(BC) = −60 − 30 = −90\n\nSum at B = +90 − 90 = 0\n\nThe joint is ALREADY balanced — no distribution needed, and nothing further to carry over. The table stops here." },
              { t: "The three methods agree", w: "Force method (Example 6.1):        90 kNm hogging\nSlope-deflection (Example 7.1):    90 kNm hogging\nMoment distribution (this):        90 kNm hogging ✓" },
            ], ans: "M at B = 90 kNm hogging — reached in one cycle, with no simultaneous equations" },
            { k: "note", t: "Joint B balanced itself because the beam is symmetric about it. On an unsymmetrical beam the joint would have an out-of-balance, it would be distributed 0.5 / 0.5, half of each share would carry over to A and C, those joints would need releasing again, and the cycle would repeat — smaller each time." },
          ],
        },
        {
          n: "8.4", title: "The pinned-end modification", hi: "पिन सिरे वाला संशोधन",
          blocks: [
            { k: "p", t: "Example 8.1 spent its first cycle releasing two simple supports that were always going to end up at zero moment. There is a shortcut that skips it, and on a long beam it saves a great deal." },
            { k: "steps", items: [
              "For a span whose far end is a simple support, use the modified stiffness <strong>3EI/L</strong> instead of 4EI/L.",
              "Adjust that span's fixed end moment at the continuous end: add half of the released end's FEM, with its sign reversed.",
              "Then never touch the released end again — it stays at zero and receives no carry-over.",
            ]},
            { k: "eg", title: "Example 8.2 — the same beam, using the modification", given: "Same continuous beam ABC as Example 8.1.", steps: [
              { t: "Modify the fixed end moments at B", w: "Span AB, with A released:\n  FEM(BA), modified = 60 − (−60)/2 = 60 + 30 = +90\n\nSpan BC, with C released:\n  FEM(BC), modified = −60 − (+60)/2 = −60 − 30 = −90" },
              { t: "Check the joint", w: "Sum at B = +90 − 90 = 0\n\nBalanced immediately. No cycles at all." },
            ], ans: "M at B = 90 kNm — same answer, reached in two lines instead of a table" },
          ],
        },
        {
          n: "8.5", title: "Symmetry and antisymmetry", hi: "सममिति और असममिति",
          blocks: [
            { k: "p", t: "When a structure and its loading are both symmetric, half of it is enough to analyse — provided the members crossing the axis of symmetry are given modified stiffnesses that reproduce what the missing half was doing." },
            { k: "list", items: [
              "<strong>Symmetric frame, symmetric load</strong> → the member crossing the axis bends in single curvature with equal and opposite end moments. Use k = 2EI/L and carry-over −1.",
              "<strong>Symmetric frame, antisymmetric load</strong> (a horizontal load, for instance) → that member bends in double curvature with equal end moments. Use k = 6EI/L and carry-over +1.",
            ]},
            { k: "p", t: "Any load on a symmetric structure can be split into a symmetric part and an antisymmetric part, analysed separately with these modifications, and superposed. For a multi-bay frame that turns an impossible hand calculation into a feasible one." },
            { k: "note", t: "There is a free check hiding here. A symmetric frame under symmetric load cannot sway — so if your analysis of such a frame produces a non-zero Δ, the error is upstream of the arithmetic." },
          ],
        },
        {
          n: "8.6", title: "Sway frames", hi: "स्वे फ्रेम",
          blocks: [
            { k: "p", t: "The method as described assumes joints rotate but do not translate. A sway frame needs the same extra condition as in §7.4, applied in two passes." },
            { k: "steps", items: [
              "<strong>Pass 1 — no sway.</strong> Hold the frame against translation with an imaginary prop and distribute normally. Then work out what force that prop had to supply, from the storey shear.",
              "<strong>Pass 2 — sway only.</strong> Remove the loads. Impose an arbitrary sway Δ′, compute the resulting fixed end moments (−6EIΔ′/L² at each end of every column that translates), and distribute those.",
              "<strong>Combine.</strong> Scale the second set so that its storey shear exactly cancels the imaginary prop force from pass 1, then add the two sets.",
            ]},
            { k: "p", t: "It is longer than slope-deflection for a single-storey frame, and it is still the method of choice for multi-storey work by hand, because each pass is arithmetic on a table rather than algebra." },
            { k: "trap", t: "The arbitrary Δ′ in pass 2 is genuinely arbitrary — any convenient number will do, because the scaling in the third step fixes it. Students often waste time trying to find the \"right\" value. There isn't one; pick something that makes the fixed end moments round." },
          ],
        },
        {
          n: "8.7", title: "Reading the table critically", hi: "तालिका को परखना",
          blocks: [
            { k: "p", t: "The reason this method still deserves a place, when software will do the whole job, is that its numbers stay physically meaningful at every stage. That makes it the best available tool for checking whether a computer result is plausible." },
            { k: "list", items: [
              "Distribution factors at each joint sum to 1.0.",
              "Each joint's final moments sum to zero (or to the applied joint moment, if there is one).",
              "Out-of-balance moments shrink cycle by cycle. If they grow, a stiffness or a sign is wrong.",
              "Final moments at a simple end support are zero.",
              "Moment concentrates at stiff members — if a long flexible beam has taken more than a short stiff column, look again.",
            ]},
            { k: "p", t: "Every one of those is a check you can run on software output too, and this is where the habit is learned." },
          ],
        },
      ],
    },

    /* ============================================================ CH 9 */
    {
      id: "sa-9",
      n: 9,
      title: "Arches and Cables",
      hi: "मेहराब और केबल",
      blurb: "Two forms that carry load by thrust and pull rather than by bending — where the horizontal reaction comes from, why the parabola is special, and what happens when the foundations move.",
      mins: 28,
      sections: [
        {
          n: "9.1", title: "Why an arch at all", hi: "मेहराब क्यों",
          blocks: [
            { k: "p", t: "A beam carries transverse load in bending, and bending is an inefficient way to use material — the fibres near the neutral axis do almost nothing. An arch carries the same load mainly in compression along its curve, which uses the whole section. The price is a horizontal thrust at the supports that a beam does not produce." },
            { k: "dia", id: "hb-sa-arch-thrust" },
            { k: "eq", expr: "M(arch) at any section = M(beam) − H · y", where: [
              ["M(beam)", "Bending moment at that section of a simply supported beam of the same span under the same load"],
              ["H", "Horizontal thrust at the springings"],
              ["y", "Height of the section above the springing line"],
            ]},
            { k: "p", t: "That single equation is the whole subject. The arch moment is the beam moment less the relief that the thrust provides, and the relief is greatest where the arch is highest — which is where the beam moment is greatest too. That is why the two can cancel." },
          ],
        },
        {
          n: "9.2", title: "The three-hinged arch", hi: "तीन-कब्ज़ा मेहराब",
          blocks: [
            { k: "p", t: "Hinges at both springings and at the crown. Four reaction components — two at each springing — against three equilibrium equations, plus one extra condition: the bending moment at the crown hinge is zero. Four equations, four unknowns, determinate." },
            { k: "steps", items: [
              "Find the vertical reactions from ΣM about one springing and ΣFy, exactly as for a beam.",
              "Find H from the crown condition: take moments about the crown for the forces on one half of the arch, and set the total to zero.",
              "Find the bending moment anywhere from M(beam) − H·y.",
            ]},
            { k: "eq", expr: "Parabolic arch profile, origin at the left springing:    y = 4h x (L − x) / L²", where: [
              ["h", "Rise of the crown above the springing"],
              ["L", "Span between the springings"],
              ["x", "Horizontal distance from the left springing"],
            ]},
            { k: "eg", title: "Example 9.1 — three-hinged parabolic arch under a point load", given: "Span 24 m, rise 6 m, hinges at both springings and at the crown. A vertical point load of 100 kN acts 6 m from the left springing A. Find the reactions, the thrust, and the bending moment under the load.", steps: [
              { t: "Vertical reactions", w: "ΣM about B = 0:\n  VA × 24 = 100 × (24 − 6) = 1800\n  VA = 75 kN ↑\n\nΣFy = 0:\n  VB = 100 − 75 = 25 kN ↑" },
              { t: "Horizontal thrust from the crown condition", w: "The crown C is at (12, 6). Take the LEFT half as a free body and set the moment about C to zero — the crown hinge cannot carry moment.\n\n  VA × 12  −  100 × (12 − 6)  −  H × 6 = 0\n  75 × 12  −  100 × 6  −  6H = 0\n  900 − 600 = 6H\n  H = 50 kN" },
              { t: "Height of the arch under the load", w: "At x = 6 m:\n  y = 4 h x (L − x) / L²\n    = 4 × 6 × 6 × 18 / 24²\n    = 2592 / 576\n    = 4.5 m" },
              { t: "Beam moment at the same section", w: "M(beam) = VA × 6 = 75 × 6 = 450 kNm" },
              { t: "Arch moment", w: "M(arch) = M(beam) − H · y\n        = 450 − 50 × 4.5\n        = 450 − 225\n        = 225 kNm" },
              { t: "Read the result", w: "The thrust has removed exactly half the bending moment at this section. It does not remove all of it, because a single point load is not the load the parabola is shaped for — that is §9.3." },
            ], ans: "VA = 75 kN, VB = 25 kN, H = 50 kN · M under the load = 225 kNm, against 450 kNm in an equivalent beam" },
          ],
        },
        {
          n: "9.3", title: "The parabola and the funicular shape", hi: "परवलय और फ्यूनिक्युलर आकार",
          blocks: [
            { k: "def", term: "Funicular shape", t: "The shape a flexible cable would naturally take under a given load. An arch built to that shape, inverted, carries the same load in pure compression with no bending at all." },
            { k: "p", t: "For a uniformly distributed load over the whole horizontal span, the funicular shape is a parabola. So a parabolic three-hinged arch under a full-span UDL has zero bending moment everywhere." },
            { k: "eg", title: "Example 9.2 — the cancellation, verified", given: "Three-hinged parabolic arch, span 20 m, rise 4 m, carrying a UDL of 10 kN/m over the whole span. Check the bending moment at mid-span.", steps: [
              { t: "Thrust", w: "For a parabolic arch under a full-span UDL:\n  H = wL² / 8h\n    = 10 × 400 / (8 × 4)\n    = 4000 / 32\n    = 125 kN" },
              { t: "Beam moment at mid-span", w: "M(beam) = wL²/8 = 10 × 400 / 8 = 500 kNm" },
              { t: "Relief from the thrust at mid-span", w: "At mid-span y = h = 4 m\n  H · y = 125 × 4 = 500 kNm" },
              { t: "Arch moment", w: "M = 500 − 500 = 0" },
              { t: "And everywhere else", w: "At any x, y = 4h x(L−x)/L² and M(beam) = w x (L−x)/2.\n\n  H·y = (wL²/8h) × 4h x(L−x)/L² = w x (L−x)/2\n\nwhich is M(beam) exactly. So the moment is zero at EVERY section, not just at mid-span. ✓" },
            ], ans: "M = 0 at every section — the arch carries the whole load in pure axial thrust" },
            { k: "trap", t: "Change the load and the cancellation disappears immediately, as Example 9.1 showed. A real arch carries dead load close to its funicular shape and live load nowhere near it, so <strong>it is the live load that produces the bending an arch has to be designed for.</strong>" },
          ],
        },
        {
          n: "9.4", title: "Two-hinged and fixed arches", hi: "दो-कब्ज़ा और स्थिर मेहराब",
          blocks: [
            { k: "dia", id: "hb-sa-arch-types" },
            { k: "p", t: "Remove the crown hinge and the arch becomes indeterminate to the first degree; fix both springings and it becomes indeterminate to the third. Both are handled by the force method of Chapter 6, with H as the natural redundant for the two-hinged case." },
            { k: "eq", expr: "Two-hinged arch:   H = ∫ (M y / EI) ds  /  ∫ (y² / EI) ds", where: [
              ["M", "Bending moment at a section of the equivalent simply supported beam"],
              ["y", "Height of that section above the springing"],
              ["ds", "Element of length along the arch axis"],
            ]},
            { k: "p", t: "That is nothing more than the compatibility equation of §6.2 written out: the horizontal distance between the springings does not change, so the deflection that H must cancel is the one the load would otherwise cause." },
            { k: "h", t: "The trade-off, stated plainly" },
            { k: "list", items: [
              "<strong>Three-hinged</strong> — determinate, so temperature change, support settlement and rib shortening cause no stress at all. The hinges absorb them. More material, and three hinges to detail and maintain.",
              "<strong>Two-hinged</strong> — stiffer, less material, but now sensitive to all three of those effects.",
              "<strong>Fixed</strong> — stiffest and most economical in material, and the most sensitive of all. It needs foundations that genuinely do not move.",
            ]},
            { k: "note", t: "On soft or uncertain ground the three-hinged arch is often the right choice even though it costs more material, because a fixed arch on a foundation that settles unevenly develops moments nobody designed for. This is §6.5 turned into a design decision." },
          ],
        },
        {
          n: "9.5", title: "Temperature and rib shortening", hi: "तापमान और रिब शॉर्टनिंग",
          blocks: [
            { k: "p", t: "An arch wants to lengthen when it is heated, and its springings will not let it. The result in an indeterminate arch is a change in H — upward with a temperature rise, downward with a fall." },
            { k: "eq", expr: "Two-hinged arch, temperature rise t :    ΔH = α t L / ∫ (y² / EI) ds", where: [
              ["α", "Coefficient of thermal expansion of the material"],
              ["t", "Temperature rise"],
              ["L", "Span"],
            ]},
            { k: "p", t: "<strong>Rib shortening</strong> is the same effect from a different cause: the axial compression in the arch shortens it elastically, which relieves some of the thrust that caused it. It is usually small, and it is usually allowed for by an approximate reduction in H rather than a full analysis. Both effects vanish entirely in a three-hinged arch." },
          ],
        },
        {
          n: "9.6", title: "Cables", hi: "केबल",
          blocks: [
            { k: "p", t: "A cable is an arch turned upside down, with one crucial difference: it has no bending stiffness at all, so it cannot resist bending even in principle. It simply takes the funicular shape of whatever load it carries — and changes shape when the load changes." },
            { k: "dia", id: "hb-sa-cable" },
            { k: "eq", expr: "H = wL² / (8h)        V at support = wL/2        T(max) = √(H² + V²)", where: [
              ["w", "Load per metre of horizontal span"],
              ["L", "Span between level supports"],
              ["h", "Sag at mid-span"],
            ]},
            { k: "p", t: "The horizontal component is the same at every point along the cable — nothing acts horizontally between the supports to change it. So the tension is largest where the cable is steepest, which is at the supports." },
            { k: "eg", title: "Example 9.3 — cable tension", given: "A cable spans 40 m between level supports with a mid-span sag of 4 m, carrying a uniformly distributed load of 5 kN/m of span. Find the horizontal pull and the maximum tension.", steps: [
              { t: "Horizontal pull", w: "H = wL² / 8h\n  = 5 × 40² / (8 × 4)\n  = 5 × 1600 / 32\n  = 250 kN" },
              { t: "Vertical component at the support", w: "V = wL/2 = 5 × 40 / 2 = 100 kN" },
              { t: "Maximum tension", w: "T(max) = √(H² + V²)\n       = √(250² + 100²)\n       = √(62 500 + 10 000)\n       = √72 500\n       = 269.3 kN" },
              { t: "What happens if the sag is halved", w: "h = 2 m:\n  H = 5 × 1600 / 16 = 500 kN — doubled\n  V is unchanged at 100 kN\n  T(max) = √(500² + 100²) = 509.9 kN\n\nA flatter cable is a much more heavily loaded cable." },
            ], ans: "H = 250 kN · T(max) = 269.3 kN at the supports · halving the sag nearly doubles the tension" },
            { k: "trap", t: "Under its own self-weight a cable hangs in a <em>catenary</em>, not a parabola, because the load is uniform along the cable rather than along the span. For sag-to-span ratios below about 1 in 10 the difference is a few per cent and the parabola is used; for a deeply sagging cable it is not good enough." },
          ],
        },
        {
          n: "9.7", title: "Suspension bridges — why the stiffening girder exists", hi: "सस्पेंशन ब्रिज — स्टिफनिंग गर्डर क्यों",
          blocks: [
            { k: "p", t: "A cable takes the funicular shape of its load. Put a heavy vehicle on one quarter of a suspension bridge and the cable would simply change shape to suit — which is intolerable for a road deck." },
            { k: "p", t: "The stiffening girder exists to prevent exactly that. It distributes concentrated live load along the length of the cable so the shape stays close to the one the dead load produced, and it carries the bending that the cable cannot. The dead load goes to the cable; the live load is shared, with the girder taking the local effects." },
            { k: "note", t: "This is worth carrying into any structure that mixes a flexible element with a stiff one. The flexible element takes the load it is shaped for; the stiff element takes whatever is left over, including everything that varies." },
          ],
        },
      ],
    }

  );
})();
