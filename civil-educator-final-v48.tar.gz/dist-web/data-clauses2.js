/* ============================================================
   CIVIL EDUCATOR — clause map, part 2
   ------------------------------------------------------------
   Navigation indexes for the next tier of codes: clause number
   (or part number) and heading only, so a student can find where
   a provision lives. NOT the text of the standard.

   For multi-part standards the index lists the PARTS, which is
   how those standards are actually navigated.

   v: true  = numbering still to be confirmed against the
              published standard (shown to the reader as "verify")
   ============================================================ */

window.DB = window.DB || {};
DB.clauses = DB.clauses || {};

/* Codes whose index is compiled from the standard's published contents listing and
   not yet checked page by page. Shown to the reader as one banner on the map. */
DB.clauseDraft = ["is875-1","is875-2","is875-3","is875-5","is383","is1786","is10262","is516","is1905","is1498","irc37","irc58","nbc2016","is2720","is4031","is2386","is2911","is3370","is1199","is3495"];

Object.assign(DB.clauses, {

  /* ============================================== IS 875 (Part 1) — DEAD LOADS */
  "is875-1": [
    { sec: "Clauses", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Unit weights of building materials", topic: "t-deadload", tbl: "tb-unitweight" },
      { n: "4", t: "Unit weights of building parts and components", topic: "t-deadload" },
      { n: "5", t: "Weights of partition walls", topic: "t-deadload" },
      { n: "6", t: "Weights of floor and roof finishes", topic: "t-deadload" },
    ]},
    { sec: "Tables", items: [
      { n: "Table 1", t: "Unit weights of building materials", topic: "t-deadload", tbl: "tb-unitweight" },
      { n: "Table 2", t: "Unit weights of building parts or components", topic: "t-deadload" },
    ]},
  ],

  /* ============================================== IS 875 (Part 2) — IMPOSED LOADS */
  "is875-2": [
    { sec: "Clauses", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Imposed loads on floors", topic: "t-liveload" },
      { n: "3.1", t: "Imposed floor loads by occupancy", topic: "t-liveload" },
      { n: "4", t: "Imposed loads on roofs", topic: "t-liveload" },
      { n: "5", t: "Loads on balconies, staircases and corridors", topic: "t-liveload" },
      { n: "6", t: "Horizontal loads on parapets, balustrades and handrails" },
      { n: "7", t: "Reduction in imposed loads on floors for columns and foundations", topic: "t-liveload" },
      { n: "8", t: "Loads from machinery, plant and equipment" },
    ]},
    { sec: "Tables", items: [
      { n: "Table 1", t: "Imposed floor loads for different occupancies", topic: "t-liveload" },
      { n: "Table 2", t: "Imposed loads on various types of roofs", topic: "t-liveload" },
      { n: "Table 3", t: "Reduction in total distributed imposed load on floors", topic: "t-liveload" },
    ]},
  ],

  /* ============================================== IS 875 (Part 3) — WIND LOADS */
  "is875-3": [
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Notations" },
      { n: "3", t: "Terminology" },
      { n: "4", t: "General — nature of wind and its effect on structures", topic: "t-windload" },
    ]},
    { sec: "Wind speed and pressure", items: [
      { n: "5", t: "Wind speed and pressure", topic: "t-windload" },
      { n: "5.2", t: "Basic wind speed Vb", topic: "t-windload" },
      { n: "5.3", t: "Design wind speed Vz", topic: "t-windload" },
      { n: "5.3.1", t: "Risk coefficient k1", topic: "t-windload" },
      { n: "5.3.2", t: "Terrain roughness and height factor k2", topic: "t-windload" },
      { n: "5.3.3", t: "Topography factor k3", topic: "t-windload" },
      { n: "5.3.4", t: "Importance factor for cyclonic region k4", topic: "t-windload" },
      { n: "5.4", t: "Design wind pressure pz = 0.6 Vz²", topic: "t-windload" },
      { n: "5.5", t: "Wind directionality, area averaging and combination factors" },
    ]},
    { sec: "Pressures and forces on structures", items: [
      { n: "6", t: "Wind pressures and forces on buildings and structures", topic: "t-windload" },
      { n: "6.2", t: "Pressure coefficients — general", topic: "t-windload" },
      { n: "6.3", t: "External pressure coefficients Cpe", topic: "t-windload" },
      { n: "6.3.2", t: "Internal pressure coefficients Cpi and building permeability", topic: "t-windload" },
      { n: "6.4", t: "Force coefficients for clad and unclad structures" },
    ]},
    { sec: "Dynamic effects", items: [
      { n: "7", t: "Dynamic effects — when a structure must be treated as wind sensitive" },
      { n: "8", t: "Along wind load and the gust factor method" },
      { n: "9", t: "Across wind response and vortex shedding" },
    ]},
    { sec: "Maps and tables", items: [
      { n: "Fig. 1", t: "Basic wind speed map of India", topic: "t-windload" },
      { n: "Table 2", t: "Terrain roughness and height factor k2", topic: "t-windload" },
      { n: "Table 5", t: "External pressure coefficients for rectangular clad buildings" },
    ]},
  ],

  /* ============================================== IS 875 (Part 5) — SPECIAL LOADS */
  "is875-5": [
    { sec: "Clauses", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Temperature effects", topic: "t-shrinkcreep" },
      { n: "4", t: "Hydrostatic and soil pressure" },
      { n: "5", t: "Erection and construction loads" },
      { n: "6", t: "Accidental loads — impact, explosion and vehicle collision" },
      { n: "7", t: "Load combinations", topic: "t-loadcomb", tbl: "tb-loadfactors" },
      { n: "8", t: "Combination of imposed load with wind and snow", topic: "t-loadcomb" },
    ]},
  ],

  /* ============================================== IS 383:2016 — AGGREGATES */
  is383: [
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "References" },
      { n: "3", t: "Terminology" },
      { n: "4", t: "Types of aggregate — natural, manufactured and recycled", mat: "mat-aggregate" },
    ]},
    { sec: "Quality", items: [
      { n: "5", t: "Quality of aggregates", topic: "t-aggtests" },
      { n: "5.1", t: "General characteristics — hard, durable, clean and free from coatings", mat: "mat-aggregate" },
      { n: "5.2", t: "Deleterious materials and their limits", topic: "t-aggtests" },
      { n: "5.3", t: "Soundness and alkali-aggregate reactivity", topic: "t-aggtests" },
      { n: "5.4", t: "Mechanical properties — crushing, impact and abrasion values", topic: "t-aggtests" },
      { n: "5.5", t: "Requirements for recycled concrete aggregate and recycled aggregate", mat: "mat-aggregate" },
    ]},
    { sec: "Size and grading", items: [
      { n: "6", t: "Size and grading of aggregates", topic: "t-aggtests" },
      { n: "6.1", t: "Coarse aggregate — single sized and graded", mat: "mat-aggregate" },
      { n: "6.2", t: "Fine aggregate — grading zones I to IV", topic: "t-aggtests" },
      { n: "6.3", t: "All-in aggregate" },
      { n: "6.4", t: "Manufactured sand", mat: "mat-aggregate" },
    ]},
    { sec: "Sampling and tables", items: [
      { n: "7", t: "Sampling and testing", topic: "t-aggtests" },
      { n: "Table 1", t: "Limits of deleterious materials" },
      { n: "Table 2", t: "Coarse aggregate grading requirements" },
      { n: "Table 4", t: "Grading limits for fine aggregate, Zones I to IV" },
    ]},
  ],

  /* ============================================== IS 1786:2008 — REINFORCEMENT */
  is1786: [
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "References" },
      { n: "3", t: "Terminology" },
      { n: "4", t: "Grades and designation — Fe 415, Fe 500, Fe 550, Fe 600 and the D grades", mat: "mat-steel" },
      { n: "5", t: "Manufacture" },
    ]},
    { sec: "Requirements", items: [
      { n: "6", t: "Chemical composition — carbon, sulphur, phosphorus and carbon equivalent", mat: "mat-steel" },
      { n: "7", t: "Nominal size, nominal mass and tolerance on mass", mat: "mat-steel" },
      { n: "8", t: "Mechanical properties", mat: "mat-steel" },
      { n: "8.1", t: "Tensile properties — yield stress, UTS/YS ratio and elongation", mat: "mat-steel" },
      { n: "8.2", t: "Bend test" },
      { n: "8.3", t: "Rebend test" },
      { n: "9", t: "Surface geometry — ribs, their spacing, height and bond requirement", topic: "t-ld" },
      { n: "10", t: "Weldability and carbon equivalent" },
    ]},
    { sec: "Testing and marking", items: [
      { n: "11", t: "Selection and preparation of test samples" },
      { n: "12", t: "Retest" },
      { n: "13", t: "Marking and identification of the grade on the bar", mat: "mat-steel" },
      { n: "Table 3", t: "Mechanical properties by grade", mat: "mat-steel" },
    ]},
  ],

  /* ============================================== IS 10262:2019 — MIX DESIGN */
  is10262: [
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "References" },
      { n: "3", t: "Terminology" },
      { n: "4", t: "Data required for mix proportioning", topic: "t-nominalmix" },
    ]},
    { sec: "Procedure", items: [
      { n: "5", t: "Procedure for mix proportioning", topic: "t-nominalmix" },
      { n: "5.1", t: "Target strength for mix proportioning — fck + 1.65 s", topic: "t-acceptance" },
      { n: "5.2", t: "Selection of water-cement ratio", topic: "t-exposure", tbl: "tb-exposure" },
      { n: "5.3", t: "Selection of water content for the required workability", topic: "t-workability" },
      { n: "5.4", t: "Calculation of cementitious material content", topic: "t-exposure" },
      { n: "5.5", t: "Estimation of coarse aggregate proportion", mat: "mat-aggregate" },
      { n: "5.6", t: "Combination of different coarse aggregate fractions" },
      { n: "5.7", t: "Estimation of fine aggregate proportion", mat: "mat-aggregate" },
      { n: "5.8", t: "Trial mixes and adjustment of proportions", topic: "t-batching" },
    ]},
    { sec: "Special concretes and annexes", items: [
      { n: "6", t: "Mix proportioning for high strength concrete", mat: "mat-concrete" },
      { n: "7", t: "Mix proportioning for self-compacting concrete", mat: "mat-admixture" },
      { n: "Annex A", t: "Illustrative examples of mix proportioning" },
      { n: "Table 2", t: "Assumed standard deviation for different grades", topic: "t-acceptance" },
    ]},
  ],

  /* ============================================== IS 516 — HARDENED CONCRETE TESTS */
  is516: [
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "References" },
      { n: "3", t: "Terminology" },
    ]},
    { sec: "Specimens", items: [
      { n: "4", t: "Making and curing of compression test specimens in the laboratory", topic: "t-cubetest" },
      { n: "4.1", t: "Moulds — 150 mm and 100 mm cubes, and cylinders", topic: "t-cubetest" },
      { n: "4.2", t: "Compaction of specimens by rodding or vibration", topic: "t-cubetest" },
      { n: "4.3", t: "Curing — full immersion at controlled temperature", topic: "t-curing" },
      { n: "5", t: "Making and curing of specimens in the field", topic: "t-cubetest" },
    ]},
    { sec: "Tests", items: [
      { n: "6", t: "Compressive strength test", topic: "t-cubetest" },
      { n: "6.2", t: "Rate of loading and reporting", topic: "t-cubetest" },
      { n: "7", t: "Flexural strength test — modulus of rupture", topic: "t-ec" },
      { n: "8", t: "Splitting tensile strength test" },
      { n: "9", t: "Determination of density of hardened concrete" },
    ]},
  ],

  /* ============================================== IS 1077:1992 — CLAY BRICKS */
  is1077: [
    /* Verified clause by clause against IS 1077:1992 itself. The earlier
       index had clauses 5, 6 and 7 in the wrong order — it listed 5 as
       dimensions and 7 as general quality, which is the other way round. */
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "References" },
      { n: "3", t: "Terminology" },
      { n: "4", t: "Classification", topic: "t-brick", tbl: "tb-brick" },
    ]},
    { sec: "Quality and dimensions", items: [
      { n: "5", t: "General quality", mat: "mat-brick" },
      { n: "6", t: "Dimensions and tolerances", topic: "t-brick" },
      { n: "6.1", t: "Dimensions", topic: "t-brick" },
      { n: "6.1.1", t: "Standard modular size", topic: "t-brick" },
      { n: "6.1.2", t: "Non-modular sizes", topic: "t-brick" },
      { n: "6.2", t: "Tolerances", topic: "t-brick" },
      { n: "6.2.1", t: "Tolerance measured over a group of twenty bricks", topic: "t-brick" },
    ]},
    { sec: "Physical requirements", items: [
      { n: "7", t: "Physical requirements", topic: "t-brick" },
      { n: "7.1", t: "Compressive strength", topic: "t-brick", tbl: "tb-brick" },
      { n: "7.1.1", t: "Strength of an individual brick", topic: "t-brick" },
      { n: "7.2", t: "Water absorption", mat: "mat-brick" },
      { n: "7.3", t: "Efflorescence", mat: "mat-brick" },
    ]},
    { sec: "Acceptance", items: [
      { n: "8", t: "Sampling and criterion for conformity", mat: "mat-brick" },
      { n: "9", t: "Marking" },
    ]},
  ],

  /* ============================================== IS 1905:1987 — MASONRY DESIGN */
  is1905: [
    { sec: "General and materials", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Materials — units, mortar and their combinations", topic: "t-mortar" },
      { n: "4", t: "Classification of masonry units and mortar grades", topic: "t-masonry" },
    ]},
    { sec: "Design considerations", items: [
      { n: "5", t: "Design considerations", topic: "t-masonry" },
      { n: "5.4", t: "Lateral supports and stability of walls", topic: "t-masonry" },
      { n: "5.5", t: "Effective height of walls and columns", topic: "t-masonry" },
      { n: "5.6", t: "Effective length of walls", topic: "t-masonry" },
      { n: "5.7", t: "Effective thickness", topic: "t-masonry" },
      { n: "5.8", t: "Slenderness ratio and its limits", topic: "t-masonry" },
      { n: "5.9", t: "Eccentricity of vertical loading", topic: "t-masonry" },
    ]},
    { sec: "Structural design", items: [
      { n: "6", t: "Structural design", topic: "t-masonry" },
      { n: "6.3", t: "Permissible compressive stress", topic: "t-masonry" },
      { n: "6.3.1", t: "Basic compressive stress from unit strength and mortar grade", topic: "t-masonry" },
      { n: "6.3.2", t: "Stress reduction factor for slenderness and eccentricity", topic: "t-masonry" },
      { n: "6.3.3", t: "Area reduction factor for small sections", topic: "t-masonry" },
      { n: "6.3.4", t: "Shape modification factor for the unit", topic: "t-masonry" },
      { n: "6.4", t: "Permissible tensile and shear stress", topic: "t-masonry" },
      { n: "7", t: "Design of walls with openings, piers and buttresses", topic: "t-masonry" },
    ]},
    { sec: "Construction", items: [
      { n: "8", t: "General requirements for construction and workmanship", topic: "t-brickwork" },
      { n: "9", t: "Joints, bonding and junctions", topic: "t-brickwork" },
    ]},
  ],

  /* ============================================== IS 1498:1970 — SOIL CLASSIFICATION */
  is1498: [
    { sec: "Clauses", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Basis of classification", topic: "t-soilclass" },
      { n: "3.1", t: "Coarse grained, fine grained and highly organic soils", topic: "t-soilclass" },
      { n: "3.2", t: "Grain size limits for gravel, sand, silt and clay", topic: "t-soilclass" },
      { n: "4", t: "Group symbols and group names", topic: "t-soilclass" },
      { n: "5", t: "Field identification of soils", topic: "t-soilclass" },
      { n: "6", t: "Laboratory classification", topic: "t-soilclass" },
      { n: "6.1", t: "Coarse grained soils — uniformity coefficient and coefficient of curvature", topic: "t-soilclass" },
      { n: "6.2", t: "Fine grained soils — the plasticity chart and the A-line", topic: "t-soilclass" },
      { n: "7", t: "Classification of soils for engineering purposes — boundary classifications" },
    ]},
    { sec: "Charts", items: [
      { n: "Plasticity chart", t: "A-line: Ip = 0.73 (wL − 20), with the low and high plasticity divide", topic: "t-soilclass" },
    ]},
  ],

  /* ============================================== IS 6403:1981 — BEARING CAPACITY */
  is6403: [
    /* Verified against IS 6403:1981. The earlier index put the bearing
       capacity work under clause 4 and invented a clause 7; in the standard
       clause 4 is General, clause 5 is the ultimate net bearing capacity,
       clause 6 is the allowable bearing capacity, and there is no clause 7. */
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "Terminology" },
      { n: "2.1", t: "Terms relating to bearing capacity", topic: "t-bearing" },
      { n: "2.2", t: "General terms" },
      { n: "3", t: "Symbols" },
      { n: "4", t: "General", topic: "t-bearing" },
      { n: "4.2", t: "Position and fluctuation of the water table", topic: "t-bearing" },
    ]},
    { sec: "Ultimate net bearing capacity", items: [
      { n: "5", t: "Ultimate net bearing capacity", topic: "t-bearing" },
      { n: "5.0", t: "General — the three types of shear failure", topic: "t-bearing" },
      { n: "5.0.1", t: "Effect of eccentricity", topic: "t-bearing" },
      { n: "5.1", t: "Soils with cohesion and angle of shearing resistance", topic: "t-bearing" },
      { n: "5.1.1", t: "Formulae for ultimate net bearing capacity", topic: "t-bearing" },
      { n: "5.1.2", t: "Correction for strip and other footing shapes", topic: "t-bearing" },
      { n: "5.2", t: "Cohesionless soils (c = 0)", topic: "t-bearing" },
      { n: "5.2.1", t: "Based on relative density", topic: "t-bearing" },
      { n: "5.2.3", t: "Based on the static cone penetration test", topic: "t-bearing" },
      { n: "5.3.2", t: "Two-layered system", topic: "t-bearing" },
      { n: "5.3.3", t: "Desiccated soil", topic: "t-bearing" },
    ]},
    { sec: "Allowable bearing capacity", items: [
      { n: "6", t: "Allowable bearing capacity", topic: "t-bearing" },
      { n: "6.1", t: "Safe bearing pressure from settlement considerations", topic: "t-settlement" },
    ]},
  ],

  /* ============================================== IS 1200 (Part 1) — EARTHWORK */
  "is1200-1": [
    /* Verified against IS 1200 (Part 1):1992. The earlier index was shifted:
       it called clause 4 "excavation for foundations" and clause 6 "lead and
       lift", whereas the standard has 4 Method of measurement, 5 Lead and
       lift, 6 Planking and strutting, 7 Removing. */
    { sec: "General", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "General", topic: "t-quantities" },
      { n: "2.1", t: "Clubbing of items" },
      { n: "2.2", t: "Booking of dimensions", topic: "t-quantities" },
      { n: "2.3", t: "Measurements", topic: "t-quantities" },
      { n: "2.4", t: "Work to be measured separately", topic: "t-earthwork" },
      { n: "2.5", t: "Bills of quantities" },
      { n: "3", t: "Classification", topic: "t-earthwork" },
    ]},
    { sec: "Method of measurement", items: [
      { n: "4", t: "Method of measurement", topic: "t-earthwork" },
      { n: "4.2", t: "Excavation", topic: "t-earthwork" },
      { n: "4.3", t: "Filling", topic: "t-earthwork" },
      { n: "4.4", t: "Surface dressing", topic: "t-earthwork" },
      { n: "4.5", t: "Rough excavation", topic: "t-earthwork" },
      { n: "4.6", t: "Surface excavation", topic: "t-earthwork" },
      { n: "4.7", t: "Excavation over areas", topic: "t-earthwork" },
      { n: "4.8", t: "Excavation in trenches for foundations", topic: "t-earthwork" },
      { n: "4.9", t: "Post holes" },
      { n: "4.10", t: "Return, fill and ram", topic: "t-earthwork" },
      { n: "4.11", t: "Embankments", topic: "t-earthwork" },
      { n: "4.12", t: "Filling under floors", topic: "t-earthwork" },
    ]},
    { sec: "Lead, lift and site clearance", items: [
      { n: "5", t: "Lead and lift", topic: "t-earthwork" },
      { n: "5.1", t: "Lead", topic: "t-earthwork" },
      { n: "5.2", t: "Lift", topic: "t-earthwork" },
      { n: "6", t: "Planking and strutting" },
      { n: "7", t: "Removing" },
      { n: "7.1", t: "Clearing of shrubs, brushwood and small trees" },
      { n: "7.2", t: "Cutting down hedges and removal of fences" },
      { n: "7.3", t: "Cutting down trees of 300 mm girth and over" },
      { n: "7.4", t: "Digging out of roots" },
    ]},
  ],

  /* ============================================== IS 1200 (Part 2) — CONCRETE */
  "is1200-2": [
    /* Verified against IS 1200 (Part 2):1974. The standard has three working
       clauses — 2 General rules, 3 Lime and mud concrete, 4 Cement concrete
       works — not the eight the earlier index listed. */
    { sec: "General rules", items: [
      { n: "1", t: "Scope" },
      { n: "2", t: "General rules", topic: "t-quantities" },
      { n: "2.1", t: "Clubbing of items" },
      { n: "2.2", t: "Bill of quantities and items of work" },
      { n: "2.3", t: "Description of items" },
      { n: "2.4", t: "Measurements", topic: "t-quantities" },
      { n: "2.5", t: "Booking of dimensions", topic: "t-quantities" },
      { n: "2.6", t: "Works to be measured separately", topic: "t-quantities" },
      { n: "2.7", t: "Measurement in stages" },
    ]},
    { sec: "Concrete works", items: [
      { n: "3", t: "Lime concrete and mud concrete" },
      { n: "4", t: "Cement concrete works", topic: "t-quantities" },
      { n: "4.1", t: "General", topic: "t-quantities" },
      { n: "4.1.2", t: "Units of measurement", topic: "t-quantities" },
      { n: "4.1.3", t: "Formwork", topic: "t-quantities" },
      { n: "4.1.5", t: "Reinforcement", topic: "t-quantities", tbl: "tb-steelwt" },
      { n: "4.2", t: "Reinforced and plain concrete — cast in situ", topic: "t-quantities" },
      { n: "4.2.2", t: "Concrete in columns and beams", topic: "t-quantities" },
      { n: "4.2.3", t: "Concrete in chajjas" },
      { n: "4.2.5", t: "Concrete casing to beams and steel stanchions" },
      { n: "4.2.6", t: "Surface channels" },
      { n: "4.3", t: "Reinforced and plain concrete — precast" },
      { n: "4.3.1", t: "Plain and moulded work" },
      { n: "4.3.2", t: "Finishing on precast components" },
      { n: "4.3.3", t: "Fencing posts" },
    ]},
  ],

  /* ============================================== IRC:37 — FLEXIBLE PAVEMENTS */
  irc37: [
    { sec: "Sections", items: [
      { n: "1", t: "Introduction and scope", topic: "t-pavementlayers" },
      { n: "2", t: "Design approach — mechanistic-empirical method", topic: "t-pavementlayers" },
      { n: "3", t: "Traffic — design traffic in million standard axles", topic: "t-pavementlayers" },
      { n: "3.1", t: "Vehicle damage factor, lane distribution, growth rate and design life", topic: "t-pavementlayers" },
      { n: "4", t: "Subgrade — CBR and resilient modulus", topic: "t-cbr" },
      { n: "5", t: "Pavement composition and material characterisation", topic: "t-pavementlayers" },
      { n: "6", t: "Performance criteria — fatigue cracking and rutting", topic: "t-pavementlayers" },
      { n: "7", t: "Design catalogues and thickness charts", topic: "t-pavementlayers" },
      { n: "8", t: "Internal drainage of the pavement" },
      { n: "9", t: "Design of overlays on existing pavements" },
    ]},
  ],

  /* ============================================== IRC:58 — RIGID PAVEMENTS */
  irc58: [
    { sec: "Sections", items: [
      { n: "1", t: "Introduction and scope", topic: "t-rigidpavement" },
      { n: "2", t: "Design traffic and the axle load spectrum", topic: "t-rigidpavement" },
      { n: "3", t: "Subgrade and sub-base — modulus of subgrade reaction k", topic: "t-rigidpavement" },
      { n: "4", t: "Concrete slab — flexural strength and material properties", topic: "t-rigidpavement" },
      { n: "5", t: "Wheel load stress and temperature differential stress", topic: "t-rigidpavement" },
      { n: "6", t: "Cumulative fatigue damage — bottom-up and top-down cracking", topic: "t-rigidpavement" },
      { n: "7", t: "Slab thickness design procedure", topic: "t-rigidpavement" },
      { n: "8", t: "Joints — contraction, expansion, longitudinal and construction", topic: "t-rigidpavement" },
      { n: "8.1", t: "Dowel bars and tie bars", topic: "t-rigidpavement" },
      { n: "9", t: "Dry lean concrete sub-base and the separation layer" },
      { n: "10", t: "Design of concrete pavements for low volume roads" },
    ]},
  ],

  /* ============================================== NBC 2016 PART 4 — FIRE & LIFE SAFETY */
  nbc2016: [
    { sec: "Section 1 — Fire prevention", items: [
      { n: "1", t: "Scope", topic: "t-firegrading" },
      { n: "2", t: "Terminology" },
      { n: "3", t: "Fire zones and their demarcation", topic: "t-firegrading" },
      { n: "4", t: "Types of construction and fire resistance ratings", topic: "t-firegrading" },
      { n: "5", t: "Classification of buildings by occupancy", topic: "t-firegrading" },
    ]},
    { sec: "Section 2 — Life safety", items: [
      { n: "6", t: "General requirements — occupant load and capacity of exits", topic: "t-egress" },
      { n: "6.1", t: "Means of egress — exits, exit access and exit discharge", topic: "t-egress" },
      { n: "6.2", t: "Travel distance to an exit", topic: "t-egress" },
      { n: "6.3", t: "Staircases, corridors, ramps and doors on escape routes", topic: "t-egress" },
      { n: "6.4", t: "Refuge area in high-rise buildings", topic: "t-egress" },
      { n: "6.5", t: "Exit signage and emergency lighting", topic: "t-egress" },
      { n: "7", t: "Compartmentation and fire stopping of service penetrations", topic: "t-firegrading" },
    ]},
    { sec: "Section 3 — Fire protection", items: [
      { n: "8", t: "Fire detection and alarm systems" },
      { n: "9", t: "Fire extinguishing installations — extinguishers, hydrants and wet risers" },
      { n: "10", t: "Automatic sprinkler systems" },
      { n: "11", t: "Fire water storage, pumps and their capacity" },
      { n: "12", t: "Special requirements — high-rise buildings, basements, atria and assembly", topic: "t-egress" },
      { n: "13", t: "Fire drills, maintenance and the fire safety plan" },
    ]},
  ],

  /* ====================================================================
     MULTI-PART STANDARDS — indexed by PART, which is how they are used
     ==================================================================== */

  /* ============================================== IS 2720 — SOIL TESTS */
  is2720: [
    { sec: "Sample preparation and basic properties", items: [
      { n: "Part 1", t: "Preparation of dry soil samples for various tests", topic: "t-soiltests" },
      { n: "Part 2", t: "Determination of water content", topic: "t-soiltests" },
      { n: "Part 3", t: "Determination of specific gravity", topic: "t-soiltests" },
      { n: "Part 4", t: "Grain size analysis — sieving and hydrometer", topic: "t-soilclass" },
      { n: "Part 5", t: "Determination of liquid limit and plastic limit", topic: "t-soilclass" },
      { n: "Part 6", t: "Determination of shrinkage factors", topic: "t-soilclass" },
    ]},
    { sec: "Compaction and density", items: [
      { n: "Part 7", t: "Water content – dry density relation using light compaction (Standard Proctor)", topic: "t-soiltests" },
      { n: "Part 8", t: "Water content – dry density relation using heavy compaction (Modified Proctor)", topic: "t-soiltests" },
      { n: "Part 14", t: "Determination of density index (relative density) of cohesionless soils" },
      { n: "Part 28", t: "Determination of dry density in place by the sand replacement method", topic: "t-soiltests" },
      { n: "Part 29", t: "Determination of dry density in place by the core cutter method", topic: "t-soiltests" },
    ]},
    { sec: "Strength and deformation", items: [
      { n: "Part 10", t: "Determination of unconfined compressive strength", topic: "t-soiltests" },
      { n: "Part 11", t: "Unconsolidated undrained triaxial compression, without pore pressure measurement", topic: "t-soiltests" },
      { n: "Part 12", t: "Consolidated undrained triaxial compression, with pore pressure measurement", topic: "t-soiltests" },
      { n: "Part 13", t: "Direct shear test", topic: "t-soiltests" },
      { n: "Part 15", t: "Determination of consolidation properties", topic: "t-settlement" },
      { n: "Part 30", t: "Laboratory vane shear test" },
    ]},
    { sec: "Permeability, CBR and special tests", items: [
      { n: "Part 16", t: "Laboratory determination of CBR", topic: "t-cbr" },
      { n: "Part 17", t: "Laboratory determination of permeability", topic: "t-soiltests" },
      { n: "Part 31", t: "Field determination of CBR", topic: "t-cbr" },
      { n: "Part 40", t: "Determination of free swell index of soils", topic: "t-soilclass" },
      { n: "Part 41", t: "Measurement of swelling pressure of soils", topic: "t-soilclass" },
    ]},
    { sec: "Chemical tests", items: [
      { n: "Part 22", t: "Determination of organic matter" },
      { n: "Part 26", t: "Determination of pH value" },
      { n: "Part 27", t: "Determination of total soluble sulphates" },
    ]},
  ],

  /* ============================================== IS 4031 — CEMENT TESTS */
  is4031: [
    { sec: "Parts", items: [
      { n: "Part 1", t: "Determination of fineness by dry sieving", topic: "t-cementtests" },
      { n: "Part 2", t: "Determination of fineness by specific surface — Blaine air permeability", topic: "t-cementtests" },
      { n: "Part 3", t: "Determination of soundness", topic: "t-cementtests" },
      { n: "Part 4", t: "Determination of consistency of standard cement paste", topic: "t-cementtests" },
      { n: "Part 5", t: "Determination of initial and final setting times", topic: "t-cementtests" },
      { n: "Part 6", t: "Determination of compressive strength of hydraulic cement", topic: "t-cementtests" },
      { n: "Part 7", t: "Determination of compressive strength of masonry cement" },
      { n: "Part 8", t: "Determination of transverse and compressive strength of plastic mortar using prism" },
      { n: "Part 9", t: "Determination of heat of hydration", mat: "mat-cement" },
      { n: "Part 10", t: "Determination of drying shrinkage" },
      { n: "Part 11", t: "Determination of density" },
      { n: "Part 12", t: "Determination of air content of hydraulic cement mortar" },
      { n: "Part 13", t: "Measurement of water retentivity of masonry cement" },
      { n: "Part 14", t: "Determination of false set", mat: "mat-cement" },
      { n: "Part 15", t: "Determination of fineness by wet sieving" },
    ]},
  ],

  /* ============================================== IS 2386 — AGGREGATE TESTS */
  is2386: [
    { sec: "Parts", items: [
      { n: "Part 1", t: "Particle size and shape — grading, flakiness and elongation indices", topic: "t-aggtests" },
      { n: "Part 2", t: "Estimation of deleterious materials and organic impurities", topic: "t-aggtests" },
      { n: "Part 3", t: "Specific gravity, density, voids, absorption and bulking", topic: "t-aggtests" },
      { n: "Part 4", t: "Mechanical properties — crushing value, impact value, abrasion value, ten percent fines", topic: "t-aggtests" },
      { n: "Part 5", t: "Soundness by sodium or magnesium sulphate", topic: "t-aggtests" },
      { n: "Part 6", t: "Measuring mortar making properties of fine aggregate" },
      { n: "Part 7", t: "Alkali aggregate reactivity", mat: "mat-aggregate" },
      { n: "Part 8", t: "Petrographic examination" },
    ]},
  ],

  /* ============================================== IS 2911 — PILE FOUNDATIONS */
  is2911: [
    { sec: "Parts", items: [
      { n: "Part 1/Sec 1", t: "Concrete piles — driven cast in-situ piles", topic: "t-pile" },
      { n: "Part 1/Sec 2", t: "Concrete piles — bored cast in-situ piles", topic: "t-pile" },
      { n: "Part 1/Sec 3", t: "Concrete piles — driven precast piles", topic: "t-pile" },
      { n: "Part 1/Sec 4", t: "Concrete piles — bored precast piles", topic: "t-pile" },
      { n: "Part 2", t: "Timber piles", mat: "mat-timber" },
      { n: "Part 3", t: "Under-reamed piles", topic: "t-pile" },
      { n: "Part 4", t: "Load test on piles — initial and routine tests", topic: "t-pile" },
    ]},
  ],

  /* ============================================== IS 3370 — LIQUID RETAINING */
  is3370: [
    { sec: "Parts", items: [
      { n: "Part 1", t: "General requirements — materials, workmanship and testing", topic: "t-exposure" },
      { n: "Part 2", t: "Reinforced concrete structures — crack width and minimum reinforcement", topic: "t-crackwidth" },
      { n: "Part 3", t: "Prestressed concrete structures" },
      { n: "Part 4", t: "Design tables for moments and forces in rectangular and circular tanks" },
    ]},
    { sec: "Key provisions", items: [
      { n: "Crack width", t: "0.2 mm generally, reduced to 0.1 mm where appearance or exposure requires it", topic: "t-crackwidth" },
      { n: "Design method", t: "Working stress retained, to keep steel stress and therefore crack width low", topic: "t-wsm" },
      { n: "Joints", t: "Movement joints, construction joints and water bars", topic: "t-consjoint" },
      { n: "Testing", t: "Watertightness test of the completed structure" },
    ]},
  ],

  /* ============================================== IS 1199 — FRESH CONCRETE TESTS */
  is1199: [
    { sec: "Parts", items: [
      { n: "Part 1", t: "Sampling of fresh concrete", topic: "t-cubetest" },
      { n: "Part 2", t: "Determination of consistency of fresh concrete — slump, compacting factor, vee-bee, flow", topic: "t-workability" },
      { n: "Part 3", t: "Determination of density of fresh concrete" },
      { n: "Part 4", t: "Determination of air content of fresh concrete" },
      { n: "Part 5", t: "Analysis of fresh concrete — cement and water content", topic: "t-batching" },
    ]},
  ],

  /* ============================================== IS 3495 — BRICK TESTS */
  is3495: [
    { sec: "Parts", items: [
      { n: "Part 1", t: "Determination of compressive strength", topic: "t-brick" },
      { n: "Part 2", t: "Determination of water absorption", mat: "mat-brick" },
      { n: "Part 3", t: "Determination of efflorescence", mat: "mat-brick" },
      { n: "Part 4", t: "Determination of warpage", mat: "mat-brick" },
    ]},
  ],

});
