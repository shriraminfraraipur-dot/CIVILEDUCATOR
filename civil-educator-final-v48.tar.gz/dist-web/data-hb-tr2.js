/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: TRANSPORTATION ENGINEERING · Ch 3–5
   Curves & superelevation · Traffic, msa & CBR · Highway materials
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "tr");
  if (!hb) { console.error("[tr2] handbook tr not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "tr-3",
      n: 3,
      title: "Horizontal Curves and Superelevation",
      hi: "क्षैतिज वक्र और अधिउन्नयन",
      blurb: "Why a curve needs banking, how superelevation and friction share the job of resisting centrifugal force, and the IRC rule that caps the tilt.",
      mins: 22,
      sections: [
        {
          n: "3.1",
          title: "Why a curve throws you outward",
          hi: "वक्र बाहर की ओर क्यों धकेलता है",
          blocks: [
            { k: "p", t: "A vehicle going straight wants to keep going straight. To make it follow a curve, something must constantly pull it toward the centre — and the reaction to that is felt as centrifugal force pushing outward. On a flat road only side friction between tyre and surface provides that pull, and friction alone runs out on a sharp or fast curve." },
            { k: "def", term: "Superelevation", t: "Raising the outer edge of the road on a curve so the surface tilts inward. A component of the vehicle's own weight then acts down the slope, toward the centre of the curve, helping resist the centrifugal force — so the tyres need less friction and the vehicle is less likely to skid out." },
            { k: "dia", id: "hb-tr-super", cap: "The banked curve, the forces, and the IRC design rule." },
          ],
        },
        {
          n: "3.2",
          title: "Designing the superelevation",
          hi: "अधिउन्नयन का डिज़ाइन",
          blocks: [
            { k: "p", t: "Superelevation and side friction share the work of holding the vehicle on the curve. But you cannot simply tilt the road as much as the physics wants, because a slow-moving or stationary vehicle on a steeply banked curve would slide inward. So IRC caps the tilt and lets friction take whatever is left." },
            { k: "eq", expr: "e = V² / (225 R)   then cap at 0.07,   with   f = V²/(127 R) − e ≤ 0.15", where: [
              ["e", "superelevation (tilt as a ratio), IRC 0.75-speed method"],
              ["V", "design speed, km/h"],
              ["R", "radius of the curve, m"],
              ["f", "side friction actually required (IRC limit 0.15)"],
            ] },
            { k: "eg", title: "Example 3.1 — Superelevation for a curve",
              given: "A curve of radius R = 360 m carries a design speed of V = 80 km/h. Find the superelevation, applying the IRC rule and its 0.07 cap.",
              steps: [
                { t: "Superelevation by the 0.75 method", w: "e = V²/(225 R) = 80²/(225 × 360)\n  = 6400 / 81000 = 0.079" },
                { t: "Apply the cap", w: "0.079 > 0.07 → provide e = 0.07\n(cannot tilt more; a slow vehicle would slip in)" },
                { t: "Friction must take the rest", w: "f = V²/(127 R) − e\n  = 6400/(127×360) − 0.07\n  = 0.140 − 0.070 = 0.070" },
                { t: "Check f against the limit", w: "0.070 < 0.15  → OK" },
              ],
              ans: "Provide superelevation of 0.07 (the maximum), with the remaining lateral demand met by a side friction of 0.07 — well inside the 0.15 limit. The curve is safe at 80 km/h. Had f come out above 0.15, the curve would be too sharp for the speed and the radius would have to be increased or the speed restricted." },
            { k: "note", t: "The four-step IRC procedure (e for 75% of the speed with no friction; cap at 0.07; check f ≤ 0.15 at full speed; otherwise restrict the speed to √(0.22 g R)) is set out by <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105101087/15-Ltexhtml/p9/p.html\" target=\"_blank\" rel=\"noopener\">NPTEL</a>, whose R = 150 m case at 80 km/h ends in a 64 km/h restriction. The Surveying handbook (<a href=\"#/read/sv/11\">Chapter 11</a>) applies the same procedure to a 500 m curve." },
            { k: "trap", t: "The cap is not bureaucratic caution — it protects the slow vehicle. Design the full calculated tilt of 0.079 (or more on a sharper curve) and a truck crawling uphill, or stopped in traffic on the bend, would slide down the bank toward the inside. Superelevation must be safe for the slowest vehicle as well as the fastest, and that is what the 0.07 cap guarantees." },
          ],
        },
        {
          n: "3.3",
          title: "Extra width and the transition curve",
          hi: "अतिरिक्त चौड़ाई और संक्रमण वक्र",
          blocks: [
            { k: "p", t: "Two more things change on a curve. A vehicle needs a little extra road width (it sweeps a wider path than on a straight, and drivers wander), and the change from straight to fully-banked curve cannot happen instantly." },
            { k: "def", term: "Transition curve", t: "A curve of gradually changing radius (a spiral) inserted between the straight and the circular curve. It lets the radius tighten gradually — so the driver can steer smoothly, and the superelevation can be built up gradually rather than as a sudden edge — instead of the curvature and tilt appearing all at once." },
            { k: "real", t: "You feel the absence of a transition curve as a jolt: on a road where a straight meets a sharp curve directly, the steering and the sideways push arrive suddenly and the car lurches. A well-designed road eases you into the bend — the wheel turns progressively and the bank rises under you gradually. <strong>The transition curve is comfort and safety made geometric.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "tr-4",
      n: 4,
      title: "Traffic, Design Traffic and Subgrade Strength",
      hi: "यातायात, डिज़ाइन ट्रैफ़िक और सबग्रेड",
      blurb: "How today's truck count becomes millions of standard axles, the fourth-power law that makes heavy axles so damaging, and the CBR test that grades the soil the road sits on.",
      mins: 22,
      sections: [
        {
          n: "4.1",
          title: "Design traffic — the pavement is built for trucks",
          hi: "डिज़ाइन ट्रैफ़िक",
          blocks: [
            { k: "p", t: "A pavement is designed for the total damage traffic will do over its whole life — and that damage comes almost entirely from heavy commercial vehicles, not cars. The design traffic is expressed as the cumulative number of standard axles the road must survive, in millions (msa)." },
            { k: "dia", id: "hb-tr-msa", cap: "From today's trucks to msa, and the fourth-power law." },
            { k: "def", term: "The fourth-power law", t: "The damage an axle does to a pavement is roughly proportional to the fourth power of its load. Double the axle load and it does about 2⁴ = 16 times the damage. This is why one overloaded truck can harm a road as much as thousands of cars, and why overloading is so destructive." },
            { k: "eg", title: "Example 4.1 — Cumulative standard axles (msa)",
              given: "Initial commercial traffic A = 1500 vehicles/day, annual growth r = 7.5%, design life n = 10 years, lane distribution factor D = 0.75, vehicle damage factor F = 2.5. Find the design traffic in msa.",
              steps: [
                { t: "Traffic growth over the life", w: "((1+r)ⁿ − 1)/r = (1.075¹⁰ − 1)/0.075\n = (2.061 − 1)/0.075 = 14.147" },
                { t: "Cumulative standard axles", w: "N = 365 × A × 14.147 × D × F\n  = 365 × 1500 × 14.147 × 0.75 × 2.5" },
                { t: "Evaluate", w: "N = 1.452 × 10⁷ axles" },
                { t: "Convert to msa", w: "N = 1.452 × 10⁷ / 10⁶ = 14.52 msa" },
              ],
              ans: "About 14.5 msa. This single number — not the daily count — is what the pavement is designed for, because it captures the whole life's accumulated damage. A higher growth rate, longer life or heavier vehicles (larger F) all push it up and demand a thicker pavement." },
            { k: "note", t: "Lane distribution factors used with this formula (IRC:37, as tabulated by <a href=\"https://engineeringhulk.com/civil/transportation/flexible-pavement-design/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>): single lane 1.0, two-lane undivided 0.75, four-lane divided 0.40, six-lane divided 0.25 — the 0.75 above is the two-lane value. IRC:37:2018 also counts A as the traffic at the end of construction, A = P(1 + r)^x for x years of construction; it is taken as the opening-year count here. The same source's own worked case (3000 CVPD, 7.5%, 15 years, VDF 4.5, LDF 0.75) gives 97 msa." },
          ],
        },
        {
          n: "4.2",
          title: "Subgrade strength — the CBR test",
          hi: "सबग्रेड सामर्थ्य — CBR टेस्ट",
          blocks: [
            { k: "p", t: "A flexible pavement ultimately rests its load on the soil beneath — the subgrade — so the strength of that soil largely decides how thick the pavement must be. Weak soil needs a thick pavement to spread the load; strong soil needs less. That strength is measured by the CBR test." },
            { k: "def", term: "California Bearing Ratio (CBR)", t: "A strength index for subgrade and pavement materials: a plunger is pushed into the soaked, compacted sample and the load it takes is expressed as a percentage of the load a standard crushed stone would take. A higher CBR means stronger soil and a thinner pavement. The sample is soaked first, to test the soil at its weakest — after the monsoon." },
            { k: "p", t: "The design then reads across from the design traffic (msa) and the subgrade CBR to a total pavement thickness, using the IRC 37 design charts. Two dials set the thickness: how much traffic (msa) and how weak the soil (CBR). More traffic or weaker soil, thicker pavement." },
            { k: "trap", t: "The CBR is measured on a soaked sample for a reason: soil is weakest when saturated, after rain, which is exactly when the heaviest damage happens. Designing on the dry, strong CBR would give a pavement that fails every monsoon. Always the soaked value — the soil at its worst, not its best." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "tr-5",
      n: 5,
      title: "Highway Materials — Bitumen and Aggregates",
      hi: "राजमार्ग सामग्री — बिटुमेन और गिट्टी",
      blurb: "The glue and the stone of a flexible pavement — what bitumen has to balance, the tests that grade it, and what a road aggregate must resist.",
      mins: 20,
      sections: [
        {
          n: "5.1",
          title: "Bitumen — the temperature-sensitive glue",
          hi: "बिटुमेन",
          blocks: [
            { k: "p", t: "Bitumen binds the aggregate in a flexible pavement, and its defining trait is that it softens when hot and stiffens when cold. That is both its use — it can be heated to coat stone and laid, then it sets — and its problem: too soft and it rutts under traffic in summer heat; too hard and it cracks in winter cold." },
            { k: "dia", id: "hb-tr-bitumen", cap: "The consistency tests that grade bitumen." },
            { k: "list", items: [
              "<strong>Penetration test</strong> — how far a standard needle sinks in 5 s under 100 g, in 0.1 mm. Measures hardness; the basis of the old penetration grades.",
              "<strong>Softening point</strong> — the temperature at which a steel ball falls through a bitumen disc (ring-and-ball). A higher softening point resists rutting in heat.",
              "<strong>Ductility</strong> — how far a sample stretches before the thread breaks. Too brittle and the road cracks in the cold.",
              "<strong>Viscosity</strong> — the basis of the modern VG (viscosity) grading, VG-10 to VG-40.",
            ] },
            { k: "note", t: "The grade of bitumen is chosen for the climate. A hot region needs a stiffer grade (higher softening point) so the surface does not rut and bleed in summer; a cold region needs a softer, more ductile grade so it does not crack. There is no universally best bitumen — only the right one for the local temperature range." },
            { k: "note", t: "The IS 73:2013 viscosity grades (VG-10 to VG-40) with their viscosity, penetration and softening-point limits are tabulated in <a href=\"#/read/qc/7\">Material Testing, Chapter 7</a>; aggregate crushing and impact limits (30% for wearing courses) in <a href=\"#/read/qc/3\">Chapter 3</a>." },
          ],
        },
        {
          n: "5.2",
          title: "Road aggregate — what it must resist",
          hi: "सड़क की गिट्टी",
          blocks: [
            { k: "p", t: "Aggregate is the load-carrying skeleton of the pavement, and road aggregate is tested harder than concrete aggregate because it takes direct, repeated tyre contact and impact. Four qualities matter, each with its own test." },
            { k: "cmp", t: "What road aggregate must resist",
              cols: ["Quality", "The test"],
              rows: [
                ["Crushing under load", "aggregate crushing value", "strength under steady load"],
                ["Sudden impact", "aggregate impact value", "resists pounding from wheels"],
                ["Wear / abrasion", "Los Angeles abrasion", "survives grinding under traffic"],
                ["Polishing (skid)", "polished stone value", "keeps skid resistance over time"],
              ] },
            { k: "trap", t: "An aggregate that polishes smooth under traffic becomes a skid hazard even while it is still perfectly strong — the surface loses its grip in the wet. This is why the polished stone value matters on the wearing course specifically: strength keeps the road intact, but skid resistance keeps vehicles on it, and they are different properties needing different aggregates." },
            { k: "real", t: "The shape of the aggregate matters as much as its strength: angular, roughly cubical crushed stone interlocks and grips the bitumen, while flaky or elongated pieces break under load and pack poorly. Road specifications limit the flakiness and elongation indices for exactly this reason — <strong>the stone must key together, not lie in slabs.</strong>" },
          ],
        },
      ],
    },

  );
})();
