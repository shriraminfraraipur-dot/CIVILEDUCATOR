/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 5–6
   Tension members · Compression members
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 5.2 TWO MODES */
  "hb-st-tenmodes": {
    label: "Gross yielding against net rupture",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A plate in tension shown two ways: stretching uniformly over its whole length as the gross section yields, which is ductile, and tearing suddenly across the line of bolt holes at the net section, which is brittle">
      ${hbmk("tm")}
      <text class="em" x="168" y="26" text-anchor="middle">GROSS YIELDING — ductile</text>
      <rect class="conc" x="52" y="70" width="232" height="46"/>
      <circle class="soft" cx="200" cy="93" r="9"/><circle class="soft" cx="240" cy="93" r="9"/>
      <line class="hi" x1="52" y1="93" x2="26" y2="93" marker-end="url(#tm-m)"/>
      <line class="hi" x1="284" y1="93" x2="310" y2="93" marker-end="url(#tm-m)"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="thin" x1="${72+i*22}" y1="70" x2="${72+i*22}" y2="116"/>`).join("")}
      <text class="lb" x="168" y="150" text-anchor="middle">the WHOLE length stretches</text>
      <text class="lb" x="168" y="170" text-anchor="middle">— visibly, and for a long time</text>
      <text class="em" x="168" y="204" text-anchor="middle">Tdg = Ag fy / γm0</text>
      <text class="em" x="168" y="228" text-anchor="middle">γm0 = 1.10</text>
      <text class="lb" x="168" y="258" text-anchor="middle">gross area, yield stress,</text>
      <text class="lb" x="168" y="278" text-anchor="middle">small factor — it gives warning</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="286"/>

      <text class="em" x="524" y="26" text-anchor="middle">NET RUPTURE — brittle</text>
      <rect class="conc" x="408" y="70" width="232" height="46"/>
      <circle class="soft" cx="524" cy="93" r="9"/>
      <path class="hi" d="M524 70 L524 84 M524 102 L524 116"/>
      <path class="hi" d="M515 93 L470 93 M533 93 L578 93"/>
      <line class="hi" x1="408" y1="93" x2="382" y2="93" marker-end="url(#tm-m)"/>
      <line class="hi" x1="640" y1="93" x2="666" y2="93" marker-end="url(#tm-m)"/>
      <text class="lb" x="524" y="150" text-anchor="middle">it TEARS across the holes</text>
      <text class="lb" x="524" y="170" text-anchor="middle">— at once, with no warning</text>
      <text class="em" x="524" y="204" text-anchor="middle">Tdn = 0.9 An fu / γm1</text>
      <text class="em" x="524" y="228" text-anchor="middle">γm1 = 1.25</text>
      <text class="lb" x="524" y="258" text-anchor="middle">net area, ULTIMATE stress,</text>
      <text class="lb" x="524" y="278" text-anchor="middle">bigger factor — and a 0.9 on top</text>
    </svg>`,
    caption: "Both are checked and the smaller governs. The design is healthier when gross yielding wins, because then the member stretches and warns before anything tears — and the code's choice of factors quietly pushes designs that way.",
  },

  /* ---------------------------------------- 5.3 STAGGER */
  "hb-st-stagger": {
    label: "Net area, and the staggered failure path",
    svg: `<svg viewBox="0 0 712 280" role="img" aria-label="A plate with staggered bolt holes showing two possible failure paths: a straight line across two holes, and a zig zag line across three holes which is longer but crosses more holes, with the psi squared over four g correction added for each diagonal leg">
      ${hbmk("sg")}
      <text class="em" x="350" y="26" text-anchor="middle">THE TEAR TAKES THE WEAKEST PATH, NOT THE SHORTEST</text>
      <rect class="conc" x="90" y="60" width="440" height="150"/>
      <circle class="soft" cx="200" cy="100" r="11"/>
      <circle class="soft" cx="200" cy="170" r="11"/>
      <circle class="soft" cx="300" cy="135" r="11"/>
      <circle class="soft" cx="400" cy="100" r="11"/>
      <circle class="soft" cx="400" cy="170" r="11"/>

      <path class="acf" d="M200 60 L200 210" stroke-dasharray="4 4"/>
      <text class="ea" x="200" y="52" text-anchor="middle">path A — straight, 2 holes</text>
      <path class="hi" d="M400 60 L400 89 L300 124 L300 146 L400 181 L400 210"/>
      <text class="ea" x="470" y="52">path B — zig-zag, 3 holes</text>
      <text class="lb" x="470" y="232">longer, but it crosses one more hole</text>

      <line class="ac" x1="300" y1="240" x2="400" y2="240" marker-end="url(#sg-c)" marker-start="url(#sg-c)"/>
      <text class="ea" x="350" y="258" text-anchor="middle">psi (stagger)</text>
      <line class="ac" x1="560" y1="100" x2="560" y2="170" marker-end="url(#sg-c)" marker-start="url(#sg-c)"/>
      <text class="ea" x="570" y="139">g (gauge)</text>
      <text class="em" x="90" y="238">An = [ b − n d0 + Σ (psi² / 4g) ] t</text>
      <text class="lb" x="90" y="262">one psi²/4g term for each DIAGONAL leg of the path</text>
      <text class="lb" x="90" y="278">— check every path, and take the smallest An</text>
    </svg>`,
    caption: "A zig-zag path is longer, so it has more metal along it, but it crosses more holes. The psi²/4g term is an empirical credit for that extra length, and the only safe method is to try every plausible path and keep the worst.",
  },

  /* ---------------------------------------- 5.4 SHEAR LAG */
  "hb-st-shearlag": {
    label: "Shear lag in an angle connected through one leg",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="An angle bolted to a gusset through one leg only, with the stress concentrated in the connected leg near the joint and the outstanding leg lagging behind and carrying much less, gradually evening out further along the member">
      ${hbmk("sl")}
      <text class="em" x="350" y="26" text-anchor="middle">ONLY ONE LEG IS BOLTED — SO ONLY ONE LEG STARTS WORKING</text>
      <rect class="conc" x="70" y="88" width="150" height="120"/>
      <text class="lb" x="120" y="148" text-anchor="middle">gusset</text>
      <rect class="steel" x="180" y="128" width="380" height="16"/>
      <rect class="steel" x="180" y="144" width="380" height="14" opacity="0.55"/>
      <circle class="soft" cx="200" cy="136" r="7"/>
      <circle class="soft" cx="240" cy="136" r="7"/>
      <circle class="soft" cx="280" cy="136" r="7"/>
      <line class="hi" x1="560" y1="140" x2="600" y2="140" marker-end="url(#sl-m)"/>
      <text class="ea" x="608" y="144">T</text>
      <text class="lb" x="600" y="124" text-anchor="end">connected leg</text>
      <text class="lb" x="600" y="176" text-anchor="end">outstanding leg</text>

      <text class="em" x="120" y="236">near the joint</text>
      <path class="softa" d="M180 246 L180 288 L280 288 L280 262 Z"/>
      <text class="lb" x="300" y="258">connected leg overloaded,</text>
      <text class="lb" x="300" y="276">outstanding leg barely stressed</text>
      <path class="soft-b" d="M470 250 L470 288 L560 288 L560 250 Z"/>
      <text class="lb" x="470" y="240">far from the joint: even again</text>
    </svg>`,
    caption: "Force enters the angle only through the bolted leg and needs a length of member to spread into the other one. Near the joint the connected leg is overloaded and the outstanding leg is idle — which is why IS 800 Cl. 6.3.3 gives the outstanding leg only a fraction β of its yield capacity.",
  },

  /* ---------------------------------------- 5.5 BLOCK SHEAR */
  "hb-st-blockshear": {
    label: "Block shear — a whole block tearing out",
    svg: `<svg viewBox="0 0 756 290" role="img" aria-label="A bolted end connection where a rectangular block of plate containing the bolts tears out, shearing along two longitudinal planes and tearing across one transverse plane, with the four areas Avg Avn Atg and Atn identified">
      ${hbmk("bl")}
      <text class="em" x="350" y="26" text-anchor="middle">SHEAR ON TWO PLANES, TENSION ACROSS ONE</text>
      <rect class="conc" x="80" y="56" width="420" height="180"/>
      <rect class="soft" x="80" y="96" width="250" height="100"/>
      ${[0,1,2].map(i=>`<circle class="steel" cx="${130+i*80}" cy="116" r="10"/><circle class="steel" cx="${130+i*80}" cy="176" r="10"/>`).join("")}
      <path class="hi" d="M80 96 L330 96"/>
      <path class="hi" d="M80 196 L330 196"/>
      <path class="ac" d="M330 96 L330 196"/>
      <line class="hi" x1="330" y1="146" x2="380" y2="146" marker-end="url(#bl-m)"/>
      <text class="ea" x="390" y="150">pull</text>
      <text class="ea" x="205" y="88" text-anchor="middle">SHEAR plane</text>
      <text class="ea" x="205" y="216" text-anchor="middle">SHEAR plane</text>
      <text class="ea" x="344" y="146">TENSION plane</text>

      <text class="em" x="80" y="260">Tdb = least of</text>
      <text class="lb" x="80" y="282">Avg fy /(√3 γm0) + 0.9 Atn fu/γm1        and        0.9 Avn fu /(√3 γm1) + Atg fy/γm0</text>
      <text class="lb" x="520" y="90">Avg, Avn — gross and net</text>
      <text class="lb" x="520" y="110">area of the two shear planes</text>
      <text class="lb" x="520" y="140">Atg, Atn — gross and net</text>
      <text class="lb" x="520" y="160">area of the tension plane</text>
      <text class="em" x="520" y="196">one expression pairs</text>
      <text class="em" x="520" y="214">shear YIELD with tension RUPTURE,</text>
      <text class="em" x="520" y="232">the other the reverse</text>
    </svg>`,
    caption: "Block shear is the mode students forget and the code puts in its own clause. It gets worse with short end distances and few bolts, and for a small angle connection it very often governs the whole member — which makes it the reason a tension member sometimes needs more bolts than its bolt value suggests.",
  },

  /* ---------------------------------------- 6.2 EULER AND REAL COLUMNS */
  "hb-st-columncurve": {
    label: "Euler, squash, and the real column curve",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A graph of design compressive stress against slenderness showing the horizontal squash line at the yield stress, the falling Euler hyperbola, and the real design curve which lies below both, joining them smoothly and dipping furthest below at intermediate slenderness">
      ${hbmk("cc")}
      <text class="em" x="350" y="24" text-anchor="middle">WHY THE REAL CURVE SITS BELOW BOTH IDEALS</text>
      <line class="s" x1="100" y1="50" x2="100" y2="250"/>
      <line class="s" x1="100" y1="250" x2="620" y2="250"/>
      <text class="lb" x="90" y="56" text-anchor="end">fcd</text>
      <text class="lb" x="618" y="272" text-anchor="end">slenderness KL/r →</text>

      <line class="thin dash" x1="100" y1="86" x2="620" y2="86"/>
      <text class="ea" x="120" y="78">squash: fy/γm0 — material limit</text>
      <path class="thin dash" d="M150 50 C210 130 280 196 620 236"/>
      <text class="ea" x="470" y="212">Euler: π²E/λ² — stability limit</text>

      <path class="hi" d="M100 86 C160 90 210 122 268 158 C330 196 430 222 620 240"/>
      <circle class="hif" cx="268" cy="158" r="5"/>
      <text class="ea" x="278" y="150">the real curve</text>
      <line class="ac" x1="268" y1="112" x2="268" y2="152" marker-end="url(#cc-c)" marker-start="url(#cc-c)"/>
      <text class="lb" x="282" y="126">biggest gap here</text>

      <text class="lb" x="100" y="294">short: strength governs</text>
      <text class="em" x="300" y="294" text-anchor="middle">intermediate: residual stress + initial bow —</text>
      <text class="em" x="300" y="312" text-anchor="middle">this is where most real columns live</text>
      <text class="lb" x="620" y="294" text-anchor="end">slender: stiffness governs</text>
    </svg>`,
    caption: "Euler assumed a perfectly straight, perfectly elastic, perfectly centred column. Real ones are bowed by a millimetre or two, carry residual stress from rolling, and yield in patches long before the average stress reaches fy. The imperfection factor α in Cl. 7.1.2.1 is how IS 800 measures that gap, and Table 10 decides which α a given section gets.",
  },

  /* ---------------------------------------- 6.3 EFFECTIVE LENGTH */
  "hb-st-effK": {
    label: "Effective length factors, braced and unbraced",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Six columns showing effective length factors: both ends fixed, one fixed one pinned, both pinned, fixed at the base and free at the top, and two sway cases where the top can translate, each with the recommended design value from Table 11">
      ${hbmk("ek")}
      <text class="em" x="350" y="24" text-anchor="middle">TABLE 11 — AND NOTE WHAT SWAY DOES</text>
      ${[["fixed–fixed", "0.65", 90, 0],
         ["fixed–pinned", "0.80", 230, 1],
         ["pinned–pinned", "1.00", 370, 2],
         ["fixed–free", "2.00", 510, 3]]
        .map(([lbl, k, x, i]) => `
        <line class="thin dash" x1="${x}" y1="70" x2="${x}" y2="200"/>
        <path class="hi" d="${[
          `M${x} 200 C${x - 22} 172 ${x + 22} 98 ${x} 70`,
          `M${x} 200 C${x - 26} 164 ${x + 16} 104 ${x} 70`,
          `M${x} 200 C${x - 30} 158 ${x - 30} 112 ${x} 70`,
          `M${x} 200 C${x} 148 ${x + 18} 100 ${x + 36} 70`,
        ][i]}"/>
        ${grd(x - 26, 204, 52)}
        ${i === 3 ? "" : `<line class="s" x1="${x - 22}" y1="66" x2="${x + 22}" y2="66"/>`}
        <text class="lb" x="${x}" y="230" text-anchor="middle">${lbl}</text>
        <text class="em" x="${x}" y="254" text-anchor="middle">K = ${k}</text>`).join("")}
      <text class="lb" x="350" y="286" text-anchor="middle">these are the RECOMMENDED design values — more conservative than the theoretical 0.5, 0.7, 1.0, 2.0</text>
      <text class="em" x="620" y="120" text-anchor="middle">a column free</text>
      <text class="em" x="620" y="140" text-anchor="middle">to SWAY can</text>
      <text class="em" x="620" y="160" text-anchor="middle">have K &gt; 1</text>
      <text class="lb" x="620" y="188" text-anchor="middle">— bracing is the</text>
      <text class="lb" x="620" y="206" text-anchor="middle">cheapest steel</text>
      <text class="lb" x="620" y="224" text-anchor="middle">you will ever buy</text>
    </svg>`,
    caption: "Table 11 separates two questions: is the end held against rotation, and is it held against translation? The second matters more. An unbraced frame column can have an effective length longer than the column itself, and since capacity falls roughly as 1/K², bracing buys more than a bigger section does.",
  },

});
