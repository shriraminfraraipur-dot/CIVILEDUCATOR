/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 1–2
   Design philosophy · Materials for design
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 1.2–1.4 THE THREE METHODS */
  "hb-rcc-methods": {
    label: "Working stress, ultimate load and limit state compared",
    svg: `<svg viewBox="0 0 716 300" role="img" aria-label="Three columns comparing the working stress method which keeps stresses low under service load, the ultimate load method which factors the load but ignores serviceability, and the limit state method which checks both collapse and serviceability with separate partial safety factors">
      ${hbmk("rm")}
      <text class="em" x="112" y="28" text-anchor="middle">WORKING STRESS</text>
      <line class="s" x1="34" y1="170" x2="190" y2="170"/>
      <line class="s" x1="34" y1="170" x2="34" y2="60"/>
      <path class="softa" d="M34 170 L34 134 L190 134 L190 170 Z"/>
      <line class="ac" x1="34" y1="134" x2="190" y2="134"/>
      <line class="thin dash" x1="34" y1="70" x2="190" y2="70"/>
      <text class="ea" x="196" y="138">σ(permissible)</text>
      <text class="lb" x="196" y="74">failure</text>
      <text class="lb" x="112" y="196" text-anchor="middle">keep the SERVICE stress low</text>
      <text class="lb" x="112" y="216" text-anchor="middle">one factor of safety on stress</text>
      <text class="em" x="112" y="248" text-anchor="middle">safe, wasteful,</text>
      <text class="em" x="112" y="268" text-anchor="middle">says nothing about collapse</text>

      <line class="gl" x1="228" y1="16" x2="228" y2="288"/>

      <text class="em" x="340" y="28" text-anchor="middle">ULTIMATE LOAD</text>
      <line class="s" x1="262" y1="170" x2="418" y2="170"/>
      <line class="s" x1="262" y1="170" x2="262" y2="60"/>
      <path class="soft" d="M262 170 L262 70 L418 70 L418 170 Z"/>
      <line class="hi" x1="262" y1="70" x2="418" y2="70"/>
      <text class="em" x="424" y="74">collapse</text>
      <text class="lb" x="340" y="196" text-anchor="middle">factor the LOAD up</text>
      <text class="lb" x="340" y="216" text-anchor="middle">to the collapse value</text>
      <text class="em" x="340" y="248" text-anchor="middle">safe against collapse,</text>
      <text class="em" x="340" y="268" text-anchor="middle">ignores cracking and deflection</text>

      <line class="gl" x1="456" y1="16" x2="456" y2="288"/>

      <text class="em" x="574" y="28" text-anchor="middle">LIMIT STATE</text>
      <line class="s" x1="492" y1="170" x2="648" y2="170"/>
      <line class="s" x1="492" y1="170" x2="492" y2="60"/>
      <path class="soft" d="M492 170 L492 70 L648 70 L648 170 Z"/>
      <line class="hi" x1="492" y1="70" x2="648" y2="70"/>
      <path class="softa" d="M492 170 L492 134 L648 134 L648 170 Z"/>
      <line class="ac" x1="492" y1="134" x2="648" y2="134"/>
      <text class="em" x="654" y="74">collapse</text>
      <text class="ea" x="654" y="138">service</text>
      <text class="lb" x="574" y="196" text-anchor="middle">check BOTH, each with its own</text>
      <text class="lb" x="574" y="216" text-anchor="middle">partial safety factors</text>
      <text class="em" x="574" y="248" text-anchor="middle">what IS 456 uses —</text>
      <text class="em" x="574" y="268" text-anchor="middle">and why it needs two sets of loads</text>
    </svg>`,
    caption: "The older two methods each check one thing and assume the other looks after itself. <strong>Limit state checks both, and keeps the two calculations separate</strong> — collapse with factored loads, serviceability with working loads. That separation is why IS 456 asks you to compute the same beam twice.",
  },

  /* ---------------------------------------- 1.5 CHARACTERISTIC STRENGTH */
  "hb-rcc-char": {
    label: "Characteristic strength and the 5% rule",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A normal distribution of cube test results, with the mean marked and the characteristic strength placed 1.65 standard deviations below it, leaving 5 per cent of the area in the lower tail">
      ${hbmk("ch")}
      <line class="s" x1="70" y1="220" x2="640" y2="220" marker-end="url(#ch-a)"/>
      <text class="lb" x="640" y="244" text-anchor="end">test result (N/mm²)</text>
      <path class="soft" d="M110 220 C200 220 230 60 380 60 C530 60 560 220 630 220 Z"/>
      <path class="s" d="M110 220 C200 220 230 60 380 60 C530 60 560 220 630 220"/>
      <path class="softa" d="M110 220 C170 220 200 128 232 106 L232 220 Z"/>
      <path class="ac" d="M232 106 L232 220"/>
      <line class="thin dash" x1="380" y1="60" x2="380" y2="220"/>
      <text class="lb" x="380" y="244" text-anchor="middle">mean  fm</text>
      <text class="ea" x="232" y="244" text-anchor="middle">fck</text>
      <text class="ea" x="170" y="196" text-anchor="middle">5%</text>
      <line class="thin" x1="232" y1="88" x2="380" y2="88" marker-start="url(#ch-a)" marker-end="url(#ch-a)"/>
      <text class="em" x="306" y="80" text-anchor="middle">1.65 s</text>

      <line class="gl" x1="40" y1="260" x2="660" y2="260"/>
      <text class="em" x="350" y="284" text-anchor="middle">fck = fm − 1.65 s        Target mean for mix design:  fm = fck + 1.65 s</text>
    </svg>`,
    caption: "Characteristic strength is not the average and not the minimum — it is the value <strong>below which no more than 5% of results are expected to fall.</strong> This is why a mix has to be designed for a target mean well above its grade, and why one low cube does not by itself condemn the concrete.",
  },

  /* ---------------------------------------- 2.2 CONCRETE DESIGN CURVE */
  "hb-rcc-concrete-curve": {
    label: "Design stress-strain curve for concrete in flexure",
    svg: `<svg viewBox="0 0 760 320" role="img" aria-label="The idealised stress strain curve for concrete used in design: parabolic from zero to 0.002 strain, then constant to 0.0035, with the peak design stress at 0.446 fck">
      ${hbmk("cc")}
      <line class="s" x1="90" y1="250" x2="480" y2="250" marker-end="url(#cc-a)"/>
      <line class="s" x1="90" y1="250" x2="90" y2="60" marker-end="url(#cc-a)"/>
      <text class="lb" x="482" y="274" text-anchor="end">strain ε</text>
      <text class="lb" x="84" y="56" text-anchor="end">stress</text>

      <path class="thin dash" d="M90 84 L440 84"/>
      <path class="soft" d="M90 250 Q150 106 250 100 L440 100 L440 250 Z"/>
      <path class="hi" d="M90 250 Q150 106 250 100 L440 100"/>
      <line class="thin dash" x1="250" y1="100" x2="250" y2="250"/>
      <line class="thin dash" x1="440" y1="100" x2="440" y2="250"/>
      <text class="lb" x="250" y="272" text-anchor="middle">0.002</text>
      <text class="lb" x="440" y="272" text-anchor="middle">0.0035</text>
      <text class="em" x="84" y="104" text-anchor="end">0.446 fck</text>
      <text class="lb" x="84" y="88" text-anchor="end">0.67 fck</text>
      <text class="em" x="170" y="150">parabolic</text>
      <text class="em" x="345" y="90" text-anchor="middle">constant</text>

      <line class="gl" x1="510" y1="50" x2="510" y2="290"/>
      <text class="em" x="528" y="86">Where the numbers come from</text>
      <text x="528" y="122">0.67 fck — the strength of</text>
      <text class="lb" x="528" y="142">concrete in a member, not a cube</text>
      <text x="528" y="176">÷ γm = 1.5 for concrete</text>
      <text class="em" x="528" y="210">= 0.446 fck  ≈ 0.45 fck</text>
      <text class="lb" x="528" y="246">0.0035 is the strain at which</text>
      <text class="lb" x="528" y="266">concrete is taken to crush —</text>
      <text class="lb" x="528" y="286">every flexure formula starts there</text>
    </svg>`,
    caption: "Two numbers do the work of this whole curve. <strong>0.67 fck</strong> converts cube strength into the strength concrete actually shows in a member, and <strong>0.0035</strong> is the crushing strain that fixes the neutral axis in every flexure calculation that follows.",
  },

  /* ---------------------------------------- 2.5 STEEL DESIGN CURVE */
  "hb-rcc-steel-curve": {
    label: "Design stress-strain curves for mild steel and high yield strength deformed bars",
    svg: `<svg viewBox="0 0 710 320" role="img" aria-label="Two design stress strain curves for reinforcement: mild steel with a sharp yield plateau at 0.87 fy, and cold worked deformed bars with a gradual curve reaching 0.87 fy at a strain of 0.87 fy over Es plus 0.002">
      ${hbmk("sc3")}
      <line class="s" x1="80" y1="250" x2="440" y2="250" marker-end="url(#sc3-a)"/>
      <line class="s" x1="80" y1="250" x2="80" y2="60" marker-end="url(#sc3-a)"/>
      <text class="lb" x="442" y="274" text-anchor="end">strain ε</text>
      <text class="lb" x="74" y="56" text-anchor="end">stress</text>
      <path class="thin dash" d="M80 110 L420 110"/>
      <text class="em" x="74" y="114" text-anchor="end">0.87 fy</text>

      <path class="ac" d="M80 250 L190 110 L420 110"/>
      <text class="ea" x="206" y="102">mild steel — sharp yield</text>

      <path class="hi" d="M80 250 L200 140 Q250 110 310 110 L420 110"/>
      <text class="em" x="300" y="146">cold worked (Fe 415, Fe 500)</text>
      <circle class="hif" cx="310" cy="110" r="5"/>
      <line class="thin dash" x1="310" y1="110" x2="310" y2="250"/>
      <text class="lb" x="310" y="272" text-anchor="middle">0.87fy/Es + 0.002</text>
      <line class="thin dash" x1="190" y1="110" x2="190" y2="250"/>
      <text class="lb" x="182" y="272" text-anchor="end">fy/Es</text>

      <line class="gl" x1="480" y1="50" x2="480" y2="290"/>
      <text class="em" x="498" y="86">Why 0.87</text>
      <text x="498" y="120">fy ÷ γm = fy / 1.15</text>
      <text class="em" x="498" y="150">= 0.870 fy</text>
      <text class="lb" x="498" y="188">Es = 2 × 10⁵ N/mm² for all</text>
      <text class="lb" x="498" y="208">reinforcing steel — the slope</text>
      <text class="lb" x="498" y="228">is the same, only the yield</text>
      <text class="lb" x="498" y="248">point differs.</text>
      <text class="lb" x="498" y="282">Fe 415 → 0.87 × 415 = 361 N/mm²</text>
    </svg>`,
    caption: "Mild steel yields sharply; cold-worked bars do not, so the code defines an equivalent yield by adding an inelastic strain of 0.002. The consequence for design is that <strong>Fe 500 needs more strain to reach its design stress than Fe 415 does</strong> — which is exactly why its limiting neutral axis depth is smaller.",
  },

  /* ---------------------------------------- 1.7 LOAD FACTORS */
  "hb-rcc-loadpath": {
    label: "The two calculations a limit state design needs",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A flow chart showing characteristic loads splitting into two branches: factored loads for the collapse check and unfactored service loads for the serviceability check">
      ${hbmk("lf")}
      <rect class="conc" x="248" y="24" width="200" height="56" rx="8"/>
      <text x="348" y="48" text-anchor="middle">Characteristic loads</text>
      <text class="lb" x="348" y="68" text-anchor="middle">IS 875 · IS 1893</text>

      <path class="ac" d="M300 80 L180 120" marker-end="url(#lf-c)"/>
      <path class="ac" d="M396 80 L516 120" marker-end="url(#lf-c)"/>

      <rect class="soft-b" x="58" y="126" width="240" height="70" rx="8"/>
      <text class="em" x="178" y="152" text-anchor="middle">× 1.5 (Table 18)</text>
      <text class="lb" x="178" y="174" text-anchor="middle">LIMIT STATE OF COLLAPSE</text>
      <text class="lb" x="178" y="192" text-anchor="middle">flexure · shear · torsion</text>
      <text x="178" y="226" text-anchor="middle">γm = 1.5 concrete</text>
      <text x="178" y="248" text-anchor="middle">γm = 1.15 steel</text>
      <text class="lb" x="178" y="272" text-anchor="middle">→ decides the SIZE and the STEEL</text>

      <rect class="conc" x="400" y="126" width="240" height="70" rx="8"/>
      <text class="ea" x="520" y="152" text-anchor="middle">× 1.0 — unfactored</text>
      <text class="lb" x="520" y="174" text-anchor="middle">LIMIT STATE OF SERVICEABILITY</text>
      <text class="lb" x="520" y="192" text-anchor="middle">deflection · cracking</text>
      <text x="520" y="226" text-anchor="middle">γm = 1.0 for both</text>
      <text class="lb" x="520" y="252" text-anchor="middle">materials — we are asking what</text>
      <text class="lb" x="520" y="270" text-anchor="middle">really happens, not what could</text>
    </svg>`,
    caption: "The single most common student error in limit state design is checking deflection with factored loads. <strong>Collapse asks \"what if everything goes wrong at once\"; serviceability asks \"what will actually happen on a normal day\"</strong> — so the second one uses the real loads and real material strengths.",
  },

});
