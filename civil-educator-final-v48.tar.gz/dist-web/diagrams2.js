/* ============================================================
   CIVIL EDUCATOR — inline SVG diagrams, part 2
   Uses the mk() / dim() helpers declared in diagrams.js.
   Theme-aware: currentColor plus the accent / marker classes.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------ FOOTING CRITICAL SECTIONS */
  "t-footing": {
    label: "The three critical sections in a footing",
    svg: `<svg viewBox="0 0 500 320" role="img" aria-label="Plan of a square footing showing the bending moment section at the column face, the one-way shear section at a distance d from the face, and the punching shear perimeter at d over 2 all round the column">
      ${mk("ft")}
      <rect class="conc" x="50" y="50" width="240" height="240"/>
      <rect class="soft" x="142" y="142" width="56" height="56"/>
      <rect class="s" x="142" y="142" width="56" height="56"/>
      <text class="lb" x="170" y="175" text-anchor="middle">column</text>

      <rect class="dash" x="118" y="118" width="104" height="104"/>
      <line class="hi" x1="198" y1="50" x2="198" y2="290"/>
      <line class="ac" x1="246" y1="50" x2="246" y2="290" stroke-dasharray="6 5"/>

      <line class="thin" x1="246" y1="70" x2="322" y2="62"/>
      <text class="ea" x="328" y="56">one-way shear</text>
      <text class="ea" x="328" y="71">full-width section</text>
      <text class="ea" x="328" y="86">at d from the face</text>

      <line class="thin" x1="222" y1="124" x2="322" y2="134"/>
      <text x="328" y="129">punching shear</text>
      <text x="328" y="144">perimeter at d/2</text>
      <text x="328" y="159">all round</text>

      <line class="thin" x1="198" y1="264" x2="322" y2="244"/>
      <text class="em" x="328" y="239">bending moment</text>
      <text class="em" x="328" y="254">at the column face</text>

      ${dim("ft", 198, 306, 246, 306)}
      <text class="lb" x="222" y="300" text-anchor="middle">d</text>
      <text class="lb" x="60" y="70">plan</text>
    </svg>`,
    caption: "A footing has no stirrups, so the whole shear capacity is plain concrete — which is why <strong>shear, not flexure, fixes the depth</strong>. Punching on the d/2 perimeter almost always governs for a square footing under a square column.",
  },

  /* ------------------------------------ ONE-WAY vs TWO-WAY SLAB */
  "t-slabtypes": {
    label: "One-way and two-way panels",
    svg: `<svg viewBox="0 0 500 292" role="img" aria-label="Two slab panels in plan: a long narrow panel whose load spans only across the short direction, and a square panel whose load spans in both directions">
      ${mk("sw")}
      <text class="lb" x="90" y="20" text-anchor="middle">one-way panel</text>
      <rect class="conc" x="40" y="30" width="100" height="220"/>
      ${dim("sw", 46, 68, 134, 68)}
      ${dim("sw", 46, 112, 134, 112)}
      ${dim("sw", 46, 156, 134, 156)}
      ${dim("sw", 46, 200, 134, 200)}
      <text class="em" x="90" y="262" text-anchor="middle">lx</text>
      <text class="em" x="26" y="144" text-anchor="middle">ly</text>
      <text class="lb" x="90" y="280" text-anchor="middle">ly / lx = 2.2</text>

      <text class="lb" x="375" y="50" text-anchor="middle">two-way panel</text>
      <rect class="conc" x="300" y="60" width="150" height="150"/>
      ${dim("sw", 306, 98, 444, 98)}
      ${dim("sw", 306, 135, 444, 135)}
      ${dim("sw", 306, 172, 444, 172)}
      ${dim("sw", 338, 66, 338, 204)}
      ${dim("sw", 375, 66, 375, 204)}
      ${dim("sw", 412, 66, 412, 204)}
      <text class="lb" x="375" y="228" text-anchor="middle">ly / lx = 1.0</text>

      <text class="ea" x="220" y="118" text-anchor="middle">IS 456 Cl. 24</text>
      <text x="220" y="140" text-anchor="middle">ly/lx &gt; 2</text>
      <text x="220" y="156" text-anchor="middle">→ one-way</text>
      <text x="220" y="180" text-anchor="middle">ly/lx ≤ 2</text>
      <text x="220" y="196" text-anchor="middle">→ two-way</text>
    </svg>`,
    caption: "The moment is always <strong>α w lx²</strong> — the <em>shorter</em> effective span squared, in both directions. Writing αy w ly² for the long span is the commonest error in two-way slab problems.",
  },

  /* ------------------------------------ EFFECTIVE LENGTH OF COLUMNS */
  "t-efflength": {
    label: "Effective length for four end conditions",
    svg: `<svg viewBox="0 0 500 262" role="img" aria-label="Four columns with different end restraints and their buckled shapes, labelled with the effective length recommended by IS 456 Table 28">
      ${mk("el")}
      <rect class="conc" x="50" y="200" width="40" height="9"/>
      <rect class="conc" x="50" y="31" width="40" height="9"/>
      <line class="thin" x1="70" y1="40" x2="70" y2="200" stroke-dasharray="4 4"/>
      <path class="ac" d="M70 200 C 52 158, 88 84, 70 40"/>
      <text class="em" x="70" y="228" text-anchor="middle">0.65 l</text>
      <text class="lb" x="70" y="246" text-anchor="middle">braced</text>
      <text class="lb" x="70" y="22" text-anchor="middle">fixed – fixed</text>

      <rect class="conc" x="170" y="200" width="40" height="9"/>
      <path class="conc" d="M180 30 L190 40 L200 30 Z"/>
      <line class="thin" x1="190" y1="40" x2="190" y2="200" stroke-dasharray="4 4"/>
      <path class="ac" d="M190 200 C 172 152, 204 84, 190 40"/>
      <text class="em" x="190" y="228" text-anchor="middle">0.80 l</text>
      <text class="lb" x="190" y="246" text-anchor="middle">braced</text>
      <text class="lb" x="190" y="22" text-anchor="middle">fixed – pinned</text>

      <rect class="conc" x="290" y="210" width="40" height="9"/>
      <path class="conc" d="M300 210 L310 200 L320 210 Z"/>
      <path class="conc" d="M300 30 L310 40 L320 30 Z"/>
      <line class="thin" x1="310" y1="40" x2="310" y2="200" stroke-dasharray="4 4"/>
      <path class="ac" d="M310 200 C 284 148, 284 92, 310 40"/>
      <text class="em" x="310" y="228" text-anchor="middle">1.00 l</text>
      <text class="lb" x="310" y="246" text-anchor="middle">braced</text>
      <text class="lb" x="310" y="22" text-anchor="middle">pinned – pinned</text>

      <rect class="conc" x="410" y="200" width="40" height="9"/>
      <line class="thin" x1="430" y1="40" x2="430" y2="200" stroke-dasharray="4 4"/>
      <path class="ac" d="M430 200 C 430 142, 448 88, 470 44"/>
      <text class="em" x="430" y="228" text-anchor="middle">2.00 l</text>
      <text class="lb" x="430" y="246" text-anchor="middle">unbraced</text>
      <text class="lb" x="434" y="22" text-anchor="middle">fixed – free</text>
    </svg>`,
    caption: "Same column, four answers. <strong>Braced</strong> is a question about the frame, not the column — if there is no shear wall, core or bracing, every column in that frame is unbraced and its effective length roughly doubles.",
  },

  /* ------------------------------------ TORSION */
  "t-torsion": {
    label: "Torsion cracking and closed stirrups",
    svg: `<svg viewBox="0 0 500 252" role="img" aria-label="A beam showing spiral cracking caused by torsion, and a cross section showing a closed stirrup with corner bars and side face reinforcement">
      ${mk("tq")}
      <rect class="conc" x="30" y="86" width="180" height="66"/>
      <line class="dash" x1="54" y1="152" x2="90" y2="86"/>
      <line class="dash" x1="90" y1="152" x2="126" y2="86"/>
      <line class="dash" x1="126" y1="152" x2="162" y2="86"/>
      <line class="dash" x1="162" y1="152" x2="198" y2="86"/>
      <path class="hi" d="M252 81 A 38 38 0 1 1 238 83" marker-end="url(#tq-m)"/>
      <text class="em" x="294" y="76">Tu</text>
      <text class="lb" x="120" y="180" text-anchor="middle">cracks spiral right</text>
      <text class="lb" x="120" y="196" text-anchor="middle">around the member</text>
      <text class="lb" x="120" y="220" text-anchor="middle">Ve = Vu + 1.6 Tu / b</text>

      <rect class="conc" x="330" y="56" width="90" height="140"/>
      <rect class="hi" x="344" y="70" width="62" height="112" rx="8"/>
      <circle class="steel" cx="352" cy="78" r="7"/>
      <circle class="steel" cx="398" cy="78" r="7"/>
      <circle class="steel" cx="352" cy="174" r="7"/>
      <circle class="steel" cx="398" cy="174" r="7"/>
      <circle class="steel" cx="352" cy="126" r="5"/>
      <circle class="steel" cx="398" cy="126" r="5"/>
      <text class="em" x="375" y="220" text-anchor="middle">closed stirrup all round</text>
      <text class="lb" x="375" y="238" text-anchor="middle">+ side face bars if D &gt; 450</text>
      <text class="lb" x="375" y="44" text-anchor="middle">section</text>
    </svg>`,
    caption: "Torsion puts a spiral tension field over the <em>whole surface</em> of the beam, so an open stirrup is useless against it — the tension must be carried right around the section, and the longitudinal bars must be distributed around the perimeter.",
  },

  /* ------------------------------------ MOMENT COEFFICIENTS */
  "t-momentcoeff": {
    label: "Bending moment shape for a continuous beam",
    svg: `<svg viewBox="0 0 500 214" role="img" aria-label="A four span continuous beam under uniform load with its bending moment diagram, labelled with the dead load coefficients from IS 456 Table 12">
      ${mk("mc")}
      <line class="thin" x1="50" y1="26" x2="50" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="102" y1="26" x2="102" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="154" y1="26" x2="154" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="206" y1="26" x2="206" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="258" y1="26" x2="258" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="310" y1="26" x2="310" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="362" y1="26" x2="362" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="414" y1="26" x2="414" y2="44" marker-end="url(#mc-a)"/>
      <line class="thin" x1="450" y1="26" x2="450" y2="44" marker-end="url(#mc-a)"/>

      <rect class="conc" x="40" y="48" width="420" height="12"/>
      <path class="s" d="M31 74 L40 60 L49 74 Z"/>
      <path class="s" d="M136 74 L145 60 L154 74 Z"/>
      <path class="s" d="M241 74 L250 60 L259 74 Z"/>
      <path class="s" d="M346 74 L355 60 L364 74 Z"/>
      <path class="s" d="M451 74 L460 60 L469 74 Z"/>

      <line class="gl" x1="40" y1="130" x2="460" y2="130"/>
      <path class="ac" d="M40 130 Q 92 212 145 100 Q 197 192 250 104 Q 302 192 355 100 Q 407 212 460 130"/>

      <text class="em" x="92" y="180" text-anchor="middle">+1/12</text>
      <text class="em" x="145" y="94" text-anchor="middle">−1/10</text>
      <text class="em" x="197" y="164" text-anchor="middle">+1/16</text>
      <text class="em" x="250" y="98" text-anchor="middle">−1/12</text>
      <text class="em" x="302" y="164" text-anchor="middle">+1/16</text>
      <text class="em" x="355" y="94" text-anchor="middle">−1/10</text>
      <text class="em" x="407" y="180" text-anchor="middle">+1/12</text>
      <text class="lb" x="250" y="205" text-anchor="middle">dead load coefficients; imposed load uses 1/10, 1/9, 1/12, 1/9</text>
    </svg>`,
    caption: "Multiply the coefficient by the <strong>total load on the span and by the effective span</strong>. The table may only be used for substantially uniform loading on three or more spans whose lengths differ by no more than 15%.",
  },
});
