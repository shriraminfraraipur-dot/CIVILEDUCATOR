/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING CONSTRUCTION
   ------------------------------------------------------------
   The ninth handbook. Where the Building Materials handbook is
   about the stuff, this one is about putting it together — the
   craft of masonry, the load path through a building, and the
   details that decide whether a wall stands, sheds water and
   survives a shake.

   One idea runs through it: a building is an assembly of
   elements, each handing its load to the one below, and good
   construction is getting each connection and each detail right —
   the bond, the band, the damp course, the lintel.

   Practice and code rules follow IS 1905 (masonry), IS 2212
   (brickwork), IS 4326/13828 (earthquake-resistant construction)
   where they govern, named at the point of use. Confirm against
   the current code before using a value on real work.

   Chapters 1–2 here; later chapters follow in data-hb-bc2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "bc",
  subject: "masonry-construction",
  name: "Building Construction",
  hi: "भवन निर्माण",
  icon: "🏗",
  blurb: "Chinai, bond, load-bearing wall, plaster aur bhukamp band — site par roz kaam aane wali cheezein, ek jagah samjhi hui.",
  note: "Construction practice and rules follow IS 1905, IS 2212 and IS 4326/13828 where they apply, named at the point of use. Values are for learning; confirm against the current code before using one on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "bc-1",
      n: 1,
      title: "A Building as an Assembly of Elements",
      hi: "तत्वों की एक संरचना के रूप में भवन",
      blurb: "The load path from roof to soil, the elements that carry it, and the two quiet details — the damp course and the lintel — that save more buildings than any calculation.",
      mins: 28,
      sections: [
        {
          n: "1.1",
          title: "The load path, top to bottom",
          hi: "भार का रास्ता",
          blocks: [
            { k: "p", t: "A building looks like one object but works as a stack of elements, each carrying the one above and handing the load down until the soil finally takes it all. Learning construction is learning what each element does and how the load passes cleanly from one to the next. A break anywhere in that path is where buildings fail." },
            { k: "dia", id: "hb-bc-elements", cap: "The elements of a building and the load path through them." },
            { k: "list", items: [
              "<strong>Roof</strong> — covers the building and carries its own loads (and wind, and people) to the walls.",
              "<strong>Walls</strong> — carry the roof and floors down, and enclose the space. In load-bearing construction they are the structure.",
              "<strong>Plinth & DPC</strong> — the base of the wall above ground, with a damp-proof course to block rising water.",
              "<strong>Foundation</strong> — spreads the concentrated wall load over enough soil that the ground can bear it.",
              "<strong>Soil</strong> — the final recipient, whose strength decides the foundation size.",
            ] },
            { k: "note", t: "This handbook and the RCC handbook describe two different structural systems. In load-bearing masonry (this handbook) the walls are the structure and carry everything down. In framed construction (RCC) a skeleton of columns and beams carries the load and the walls just fill in. Which system a building uses changes everything about how it is built." },
          ],
        },
        {
          n: "1.2",
          title: "The two quiet protectors",
          hi: "दो मौन रक्षक",
          blocks: [
            { k: "p", t: "Two small details prevent two of the commonest and most damaging problems in a building, and both are cheap and easily skimped — which is exactly why they are worth naming first." },
            { k: "def", term: "Damp-proof course (DPC)", t: "A continuous impervious layer (rich cement mortar, bitumen, or a membrane) laid across the wall at plinth level to stop ground moisture rising up into the wall by capillary action. Without it, water wicks up from the soil, ruining plaster and paint and rotting the wall from the base." },
            { k: "def", term: "Lintel", t: "A beam spanning across the top of a door or window opening, carrying the wall above so it does not collapse into the gap. Every opening in a load-bearing wall needs one; historically an arch did the same job by carrying the load around the opening in compression." },
            { k: "trap", t: "Rising damp is the classic failure of a missing or broken DPC: months after handover, plaster blisters and salts bloom along the bottom of the walls, and no amount of repainting fixes it because the water keeps coming up from below. The cure is a barrier at the base, which is far easier to lay during construction than to insert later." },
            { k: "list", items: [
              "<strong>DPC in practice</strong> — commonly 40–50 mm of rich cement concrete with a waterproofing compound, laid continuous across the full wall thickness at plinth level (<a href=\"https://bseh.org.in/uploads/files/16745d2d95aa8c0274bbbc2e0c3b7235.pdf\" target=\"_blank\" rel=\"noopener\">BSEH construction marking scheme</a>); bitumen layers or membranes are alternatives. It must be unbroken at corners and junctions — a DPC with a gap is a wick.",
              "<strong>Lintel bearing</strong> — the lintel must bear on the wall at each end by at least 150 mm (or the lintel depth, if greater) so the load it collects is passed into solid masonry, not onto the edge of the opening (<a href=\"https://blendedlearning.bharatskills.gov.in/pluginfile.php/22239/mod_resource/content/1/DraughtsMan%20Civil-%201%2C%20Week%20-%2019.pdf\" target=\"_blank\" rel=\"noopener\">Bharatskills Draughtsman (Civil) notes</a>; also the <a href=\"https://infralens.in/formats/site-execution/brickwork-inspection-checklist\" target=\"_blank\" rel=\"noopener\">InfraLens brickwork checklist</a>).",
            ] },
          ],
        },
        {
          n: "1.3",
          title: "The last link: spreading the load into the soil",
          hi: "नींव — भार को फैलाना",
          blocks: [
            { k: "p", t: "Every load in the building ends as a line load along the bottom of the walls, and the soil can only take a limited pressure — its safe bearing capacity (SBC). The foundation's job is purely geometric: widen the base until load ÷ area is no more than the SBC. For a wall, that means a strip footing whose width follows directly from the load per metre run." },
            { k: "eq", expr: "width of strip footing  B = (wall load per metre + footing self-weight) / SBC", where: [
              ["SBC", "safe bearing capacity of the soil, kN/m²"],
            ]},
            { k: "eq", expr: "Rankine's minimum depth   D = (q / γ) × [(1 − sin φ)/(1 + sin φ)]²", where: [
              ["q", "bearing pressure on the soil, kN/m²"],
              ["γ, φ", "unit weight and angle of internal friction of the soil"],
            ]},
            { k: "eg", title: "Example 1.1 — Width and depth of a wall footing",
              given: "A load-bearing wall delivers 60 kN per metre run to its footing. SBC = 120 kN/m². Allow 10% of the wall load for the footing's own weight. Soil γ = 18 kN/m³, φ = 30°.",
              steps: [
                { t: "Load including footing", w: "60 × 1.10 = 66 kN/m" },
                { t: "Width", w: "B = 66/120 = 0.55 m  →  provide 0.60 m" },
                { t: "Pressure actually applied", w: "q = 66/0.60 = 110 kN/m²  (≤ 120 ✓)" },
                { t: "Rankine's minimum depth", w: "(1 − sin 30°)/(1 + sin 30°) = 0.5/1.5 = 1/3\nD = (110/18) × (1/3)² = 6.11 × 0.111 = 0.68 m" },
              ],
              ans: "Footing 0.60 m wide, founded at least about 0.7 m below ground. Rankine's formula gives a minimum from shear considerations only; seasonal moisture change, expansive soil or a nearby drain may require a deeper founding level." },
            { k: "note", t: "Rankine's formula is classical soil mechanics (the passive and active coefficients of Chapter 11 of the RCC handbook, squared) and is treated fully in the Geotechnical handbook. The point here is the chain: wall load → SBC → width → depth. A building's bottom detail is decided by its top." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "bc-2",
      n: 2,
      title: "Masonry Units and Mortar",
      hi: "चिनाई इकाइयाँ और मसाला",
      blurb: "The wall as a system of units and joints, and why the mortar is deliberately made weaker than the units it binds.",
      mins: 30,
      sections: [
        {
          n: "2.1",
          title: "The wall is units plus joints",
          hi: "दीवार = इकाई + जोड़",
          blocks: [
            { k: "p", t: "A masonry wall is two materials working together: the units (brick, block, stone) that carry compression, and the mortar joints that bed them, spread the load between them and seal the gaps. The wall is only as good as the weaker of the two and the bond between them — and, counter-intuitively, that weaker one should be the mortar." },
            { k: "p", t: "The Building Materials handbook covers what the units and mortar are made of; here the concern is how they work together in the wall. The key relationships are the strength of the unit, the strength of the mortar, and the quality of the bond between them — a wall with strong bricks and poor mortar, or good materials badly laid, still fails at the joints." },
            { k: "eg", title: "Example 2.1 — Materials in one cubic metre of brickwork",
              given: "Estimate the bricks, cement and sand for 1 m³ of modular brickwork (190×90×90 mm bricks, 10 mm joints) in 1:6 cement mortar. Take a dry-mortar factor of 1.3, cement density 1440 kg/m³, one bag = 50 kg.",
              steps: [
                { t: "Bricks per m³ (with joints)", w: "one brick + joint = 200×100×100 = 0.002 m³\nbricks = 1 / 0.002 = 500" },
                { t: "Wet mortar = the gaps left", w: "brick volume = 500 × (0.19×0.09×0.09) = 0.770 m³\nwet mortar   = 1 − 0.770 = 0.230 m³" },
                { t: "Dry mortar (materials bulk down)", w: "0.230 × 1.3 = 0.300 m³" },
                { t: "Split 1:6 (sum = 7)", w: "cement = 0.300/7 = 0.0428 m³ = 61.6 kg = 1.23 bags\nsand   = 0.300 × 6/7 = 0.257 m³" },
              ],
              ans: "Per m³ of brickwork: 500 bricks, about 1.2 bags of cement and 0.26 m³ of sand. Roughly a quarter of the wall's volume is mortar — which is why the mortar mix and workmanship matter as much as the bricks." },
            { k: "note", t: "The factor 1.3 converts wet mortar volume to the dry volume of cement and sand that has to be bought, because the voids in dry sand fill as it is wetted; estimators use values from about 1.27 to 1.33, and many add a separate allowance for frogs and wastage. Whatever factor is used should be stated on the estimate." },
            { k: "eg", title: "Example 2.2 — The same cubic metre with non-modular bricks",
              given: "Bricks 230 × 110 × 70 mm (the non-modular size in IS 1077), 10 mm joints, 1:6 mortar, same factors as Example 2.1.",
              steps: [
                { t: "Brick plus joint", w: "240 × 120 × 80 mm = 0.002304 m³\nbricks = 1/0.002304 = 434" },
                { t: "Mortar", w: "brick volume = 434 × 0.23 × 0.11 × 0.07 = 0.769 m³\nwet mortar = 1 − 0.769 = 0.231 m³ → dry 0.300 m³" },
              ],
              ans: "About 434 non-modular bricks per m³ against 500 modular — and almost exactly the same mortar, because the joint volume is set by the 10 mm joint on all faces." },
          ],
        },
        {
          n: "2.2",
          title: "Brick classes and sizes (IS 1077)",
          hi: "ईंट की श्रेणियाँ",
          blocks: [
            { k: "p", t: "Common burnt clay bricks are classified in IS 1077:1992 by their <strong>average compressive strength</strong>: the class number is the minimum average strength in N/mm². The classes run from 3.5 up to 35 (designations 35, 30, 25, 20, 17.5, 15, 12.5, 10, 7.5, 5 and 3.5); bricks of 40 N/mm² and above are covered separately by IS 2180." },
            { k: "list", items: [
              "<strong>Sizes</strong> — modular 190 × 90 × 90 mm and 190 × 90 × 40 mm (200 × 100 × 100 with joints); non-modular 230 × 110 × 70 mm and 230 × 110 × 30 mm.",
              "<strong>Dimensional tolerance</strong> — checked on a stack of 20 bricks, not on one: for the 190 × 90 × 90 brick, 20 lengths must total 3720–3880 mm.",
              "<strong>Water absorption</strong> — not more than 20% by weight up to class 12.5, and 15% for higher classes.",
              "<strong>Efflorescence</strong> — not more than ‘moderate’ up to class 12.5, and ‘slight’ for higher classes.",
              "<strong>Frog</strong> — hand-moulded bricks carry a frog 10–20 mm deep, laid upwards so it fills with mortar.",
            ] },
            { k: "note", t: "Values read from <a href=\"https://law.resource.org/pub/in/bis/S03/is.1077.1992.pdf\" target=\"_blank\" rel=\"noopener\">IS 1077:1992 (Public.Resource.Org)</a>. <b>Conflict noted:</b> some web summaries (e.g. <a href=\"https://infralens.in/handbook/brick-types-strength\" target=\"_blank\" rel=\"noopener\">InfraLens</a>) give the non-modular size as 230 × 115 × 75 mm and attach ‘first/second/third class’ labels with absorption limits of 20/22/25% — those labels come from older trade practice, not from IS 1077. Use the standard's classes and limits for specification." },
            { k: "p", t: "Mortars are graded the same way, by strength. IS 1905 and IS 2250 use designations in three families — H (high), M (medium) and L (low) — with the number inside each family increasing as strength falls: H1 > H2 > M1 > M2 > L1 > L2 (<a href=\"https://prepp.in/question/the-mortar-used-for-masonry-construction-are-class-6633b0720368feeaa586ad01\" target=\"_blank\" rel=\"noopener\">Prepp</a>). IS 1905 then pairs each mortar grade with each brick strength to give the basic compressive stress of the masonry (Chapter 4)." },
          ],
        },
        {
          n: "2.3",
          title: "Why the mortar is the weaker partner",
          hi: "मसाला कमज़ोर क्यों",
          blocks: [
            { k: "p", t: "The rule surprises people: the mortar should be weaker than the bricks it joins, not stronger. The reason is movement. Every wall moves a little — with temperature, moisture, and small settlements — and something has to give. It is far better that fine cracks run through the cheap, repairable mortar joints than through the bricks." },
            { k: "cmp", t: "Matching mortar to the job",
              cols: ["Richer (e.g. 1:4)", "Leaner (e.g. 1:6, 1:8)"],
              rows: [
                ["Strength", "higher", "lower"],
                ["Movement", "rigid — cracks the bricks", "flexible — cracks itself first"],
                ["Where used", "heavy load, damp, below DPC", "ordinary walls above DPC"],
                ["Cost", "more cement", "less cement"],
              ] },
            { k: "trap", t: "A mortar stronger than the brick does not make a stronger wall — it moves the crack from the joint (repairable by raking out and repointing) into the brick (not repairable at all). Overpowering the mortar is a false economy dressed as extra strength. Match the mortar to the unit; do not try to beat it." },
            { k: "note", t: "Lime and gauged mortars are still valued for exactly this reason: they are weaker and more forgiving than pure cement mortar, they accommodate movement, and they even self-heal fine cracks over time as free lime re-carbonates. A little lime in the mix (a gauged mortar) buys workability and forgiveness at a small cost in strength." },
          ],
        },
      ],
    },

  ],
});
