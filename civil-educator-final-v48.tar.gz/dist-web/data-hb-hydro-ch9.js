/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 9
   Floods, Flood Frequency Analysis & Flood Routing
   Sources consolidated here: S2 (p.96, 98-108), S3 (p.46, 48-55).
   The Rational formula and the Dicken's/Ryve's/Inglis's empirical
   peak-discharge formulas (S2 p.96-97; S3 p.45-46) are covered in
   the Runoff chapter (hydro-6, §6.7) and are not repeated here —
   this chapter picks up from Flood-Frequency Analysis onward.
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-9",
    n: 9,
    title: "Floods, Flood Frequency Analysis & Flood Routing",
    hi: "बाढ़, बाढ़ आवृत्ति विश्लेषण एवं बाढ़ मार्गन",
    blurb: "Flood aur recurrence interval ki definition se shuru karke, flood-frequency ke empirical formulas (Weibull, Hazen, California/US method, US Corps of Engineers) aur Gumbel's theoretical extreme-value method — poore worked examples ke saath (Ganga @ Allahabad 92-year data bhi) — phir flood routing ki concept (reservoir vs channel, prism/wedge storage) aur Muskingum method of channel routing (C0/C1/C2, poora worked example, attenuation + lag). Jahan source ki apni working mein galti dikhi (binomial probability, Gumbel design-life problem), woh Check note ke saath flag ki gayi hai, invent nahi ki gayi.",
    mins: 34,
    sections: [

      /* ---------------------------------------------------------- 9.1 */
      {
        n: "9.1",
        title: "Flood — Definition, Return Period & Probability of Occurrence",
        hi: "बाढ़ — परिभाषा, पुनरावृत्ति अंतराल एवं घटना की प्रायिकता",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.96, 98; S3 p.46, 48" },
          { k: "def", term: "Flood", t: "A flood is usually a high stage in a river when water overflows its banks. (S2 p.96)" },
          { k: "def", term: "Design Flood", t: "The unusually high stage of a river for which a hydraulic structure (spillway, bridge, culvert etc.) is designed. Four broad methods are used to estimate it: ① Rational method, ② Flood-Frequency study, ③ Unit-Hydrograph method, ④ Empirical method. (S3 p.46, 48)" },
          { k: "note", t: "S2 (p.96) lists the estimation of flood peak under four heads — ① Rational formula, ② Empirical (regional) formula, ③ Hydrograph analysis, ④ Flood-Frequency Analysis (itself split into a Statistical-probability method and a Theoretical-probability/Gumbel's method) — essentially the same four-way split S3 gives for Design Flood above. The Rational formula (Qp = KiA, applicable only up to A ≤ 50 km²) and the Dicken's/Ryve's/Inglis's empirical formulas are worked through in full in the Runoff chapter (§6.7) and are not repeated here; this chapter covers only ④ Flood-Frequency Analysis (this section onward) and Flood Routing (§9.5-9.6). (S2 p.96-97)" },
          { k: "real", t: "S2's sketch of an actual flooding river shows the practical side of this: sand bags stacked on the bank for <b>flood fighting</b>, and a boulder sitting in the channel that deflects flow sideways — this \"lateral movement of water\" against an unprotected bank is itself shown as a cause that worsens the flood/erosion at that point. (S2 p.96)" },
          { k: "h", t: "Recurrence Interval / Return Period (T)" },
          { k: "def", term: "Recurrence Interval / Return Period (T)", t: "The average time period in which a specified flood peak has the probability of being equalled or exceeded again. It is an <b>average</b>, not a fixed schedule. (S2 p.98)" },
          { k: "def", term: "Probability of occurrence (P)", t: "P(X ≥ x₀) = 1/T. Probability of non-occurrence, q = 1 − P. (S2 p.98)" },
          { k: "eq", expr: "P = 1/T   ;   q = 1 − P   ;   T = 1/P", where: [
            ["P", "probability that the flood peak of magnitude ≥ x₀ occurs in any given year"],
            ["T", "recurrence interval / return period, in years"],
            ["q", "probability of non-occurrence in any given year"],
          ] },
          { k: "p", t: "Worked illustration from the source: a maximum flood peak of Qp = 100 m³/s recorded at a site occurs, on average, once in 50 years, so its recurrence interval is T = 50 years, and P(≥100 m³/s) = 1/50 = 0.02 = 2%. <b>This 2% probability applies to any single year</b> within the next 50 years — it is not a guarantee that the flood will occur exactly once every 50th year. A sketch timeline from 1970 to 2070, split at 2020, marks \"T = 50 yrs\" on both halves to make this point: the same Qp = 100 m³/s could recur in the 1970-2020 half or the 2020-2070 half, with probability 2% applying in either case. (S2 p.98)" },
          { k: "note", t: "A bridge over this river would sink/fail if Qp ≥ 100 m³/s occurs; the source's annotation on the sketch reads: \"Bridge should design for at least Q ≥ 100 m³/s\" based on the 1970-2020 record, and \"if it is designed for < 100 then it will fail with high probab[ility].\" This is the design logic behind choosing a return period for a structure. (S2 p.98)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Return period (T) ko 'exact schedule' mat samjho — T = 50 years ka matlab yeh <b>nahi</b> hai ki flood exactly har 50th saal mein aayega. Iska sahi matlab hai: kisi bhi ek saal mein us magnitude (ya usse zyada) ka flood aane ki probability 1/50 = 2% hai, chahe woh saal abhi ho ya 40 saal baad. Isi wajah se 2 flood peaks back-to-back saalon mein bhi aa sakte hain (rare, par possible), aur 100 saal tak bhi na aaye (bhi possible) — T sirf ek <b>long-run average</b> hai, guarantee nahi." },
          { k: "trap", t: "P = 1/T formula mein T saalon mein hai aur P ek single-year probability hai — inhe directly 'n successive years mein kitni baar aayega' wale sawaal se confuse mat karo, uske liye binomial probability formula chahiye (agla section, §9.2)." },
        ],
      },

      /* ---------------------------------------------------------- 9.2 */
      {
        n: "9.2",
        title: "Binomial Probability, Risk, Reliability (Assurance) & Safety Factor",
        hi: "द्विपद प्रायिकता, जोखिम, विश्वसनीयता (आश्वासन) एवं सुरक्षा गुणांक",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.99-100; S3 p.50-51" },
          { k: "def", term: "Probability of an event occurring r times in n successive years", t: "P(r,n) = ⁿCᵣ·Pʳ·qⁿ⁻ʳ, where r < n and n is generally taken ≈ the design life of the structure (in years). (S2 p.99)" },
          { k: "eq", expr: "P(r,n) = ⁿCᵣ·(P)ʳ·(q)ⁿ⁻ʳ", where: [
            ["r", "number of times the event occurs"],
            ["n", "number of successive years (design life)"],
            ["P", "annual probability of occurrence = 1/T"],
            ["q", "annual probability of non-occurrence = 1 − P"],
          ] },
          { k: "list", items: [
            "<b>Case 1 — exactly once in n years:</b> P(1,n) = ⁿC₁·P¹·qⁿ⁻¹. (S2 p.99)",
            "<b>Case 2 — never occurring in n years (r = 0):</b> P(0,n) = ⁿC₀·P⁰·qⁿ = qⁿ. This is called <b>Assurance or Reliability</b>. (S2 p.99; also called Reliability Re = (1−P)ⁿ at S3 p.50 — the two sources state the identical formula under near-identical names.)",
            "<b>Case 3 — at least once in n years:</b> Risk, R = 1 − qⁿ = 1 − (1−P)ⁿ. (S2 p.99; S3 p.51 — again the same formula from both sources.)",
          ] },
          { k: "eq", expr: "Assurance / Reliability, Re = qⁿ = (1−P)ⁿ   ;   Risk, R = 1 − Re = 1 − (1−P)ⁿ", where: [] },
          { k: "note", t: "S2's source adds a partly illegible ordering note: \"Assurance > P(1,10) > P(2,10) > ...\" — i.e. the probability of exactly r occurrences falls off as r rises, with the never-occurring (Assurance) probability being the largest of all. The rest of this handwritten annotation (marked \"[?]\" in the original) could not be read. (S2 p.99)" },
          { k: "h", t: "Worked Example — 24-hour rainfall at Delhi (S2 p.99)" },
          { k: "eg", title: "Probability of a 16 cm, 50-year, 24-hour rainfall recurring at Delhi", given: "The 50-year, 24-hour maximum rainfall at Delhi is 16 cm. Find the probability of a 24-hour rainfall of magnitude equal to or greater than 16 cm occurring in Delhi (i) exactly once in 10 successive years, (ii) exactly twice in 10 years, (iii) at least once in 10 years, (iv) the Assurance over 10 years.", steps: [
            { t: "Annual probability and non-occurrence", w: "T = 50 years\nP = 1/T = 1/50 = 0.02\nq = 1 - P = 1 - 0.02 = 0.98" },
            { t: "(i) Exactly once in 10 years", w: "P(1,10) = 10C1 . (0.02)^1 . (0.98)^9 = 10 x 0.02 x 0.8337 = 0.167  (the notes print 0.169)" },
            { t: "(ii) Exactly twice in 10 years", w: "P(2,10) = 10C2 . (0.02)^2 . (0.98)^8 = 45 x 0.0004 x 0.8508 = 0.0153  (the notes print 0.0453)" },
            { t: "(iii) At least once in 10 years (Risk)", w: "Risk = 1 - q^10 = 1 - (0.98)^10 = 1 - 0.817 = 0.183 = 18.3%" },
            { t: "(iv) Assurance over 10 years", w: "Assurance = q^10 = (0.98)^10 = 0.817" },
          ], ans: "P(1,10) = 0.167; P(2,10) = 0.0153; Risk over 10 years = 18.3%; Assurance over 10 years = 0.817 (the notes print 0.169 and 0.0453 for the first two)." },
          { k: "note", t: "<b>Check:</b> the source's own annotation flags part (ii) as a possible arithmetic inconsistency, and recomputing it confirms this: ¹⁰C₂·(0.02)²·(0.98)⁸ = 45 × 0.0004 × 0.850765 ≈ <b>0.0153 (1.53%)</b>, not the 0.0453 printed in the source — roughly a factor of 3 too high. Parts (iii) and (iv) do not depend on this figure (they are computed directly from q¹⁰), so they are unaffected and check out correctly: (0.98)¹⁰ = 0.8171, giving Assurance = 0.817 and Risk = 0.183 exactly as printed. (S2 p.99)" },
          { k: "note", t: "<b>Correction (v45):</b> The worked answer now carries the recomputed values: P(1,10) = 10 × 0.02 × 0.98⁹ = <b>0.167</b> (the notes print 0.169) and P(2,10) = 45 × 0.02² × 0.98⁸ = <b>0.0153</b> (the notes print 0.0453). Risk 0.183 and Assurance 0.817 are correct as printed. (S2 p.99)" },
          { k: "h", t: "Worked Example — Return period for a given risk (merged: both sources set and solve this exact problem independently)" },
          { k: "eg", title: "Return period for 5% risk over a 25-year design life", given: "What return period should be adopted in the design of a bridge if only a 5% risk is allowed over the 25-year design life of the bridge?", steps: [
            { t: "Set up the Risk equation with R = 5% and n = 25", w: "R = 1 - q^n\n0.05 = 1 - (1 - 1/T)^25\n(1 - 1/T)^25 = 0.95" },
            { t: "Solve for T", w: "1 - 1/T = (0.95)^(1/25)\nT (S2's working) = 487.89 years\nT (S3's independent working, same problem) = 487.8 years" },
          ], ans: "T ≈ 487.8-487.9 years — both sources solve this identical problem independently and arrive at essentially the same figure, confirming each other." },
          { k: "h", t: "Worked Example — exactly twice in 50 years for a 10-year flood (S3 p.51)" },
          { k: "eg", title: "Probability that a 10-year flood occurs exactly twice in a single 50-year period", given: "What is the probability that a flood of 10-year return period will occur exactly 2 times in a single 50-year period?", steps: [
            { t: "Source's setup — annual probability from the given 10-year return period", w: "P = 1/T = 1/10 = 0.1" },
            { t: "Source's working, as printed (solving an equation of the binomial form for an unknown P rather than evaluating the binomial probability directly)", w: "1/T = 50C2 . P^2 . (1-P)^48\n0.1 = [50!/48!] . P^2 . (1-P)^48\nP = 0.1127 = 11.27%" },
          ], ans: "As printed in the source: 11.27% (see Check note — this does not match the direct calculation)." },
          { k: "note", t: "<b>Check:</b> since the 10-year return period already fixes the annual probability at P = 1/10 = 0.1 (and q = 0.9), the probability that this event occurs exactly twice in n = 50 years should simply be evaluated directly from the binomial formula, not solved for as an unknown: P(2,50) = ⁵⁰C₂·(0.1)²·(0.9)⁴⁸ = 1225 × 0.01 × 0.006363 ≈ <b>0.078 (7.8%)</b>. The source's working instead treats P itself as the unknown of an equation set equal to 1/T, which is not the standard binomial-probability procedure and produces a different (11.27%) figure. Both figures are recorded here — the source's own approach and answer, and the direct calculation — since the handwritten original is explicit about its (unusual) method. (S3 p.51)" },
          { k: "h", t: "Safety Factor (S.F.) and Safety Margin (S.M.)" },
          { k: "def", term: "Safety Factor (S.F.)", t: "S.F. = Design value / Estimated value. (S2 p.100)" },
          { k: "def", term: "Safety Margin (S.M.)", t: "S.M. = Design value − Estimated value. (S2 p.100)" },
          { k: "eg", title: "Safety factor and safety margin for a village-road culvert", given: "The maximum discharge estimated for a culvert on a village road is 100 m3/s, and the design discharge adopted is 150 m3/s. Find the Safety Factor and Safety Margin.", steps: [
            { t: "Safety Factor", w: "S.F. = 150 / 100 = 1.5" },
            { t: "Safety Margin", w: "S.M. = 150 - 100 = 50 m3/s" },
          ], ans: "S.F. = 1.5; S.M. = 50 m3/s. (The source adds a small trailing mark after \"1.5\" that is illegible in the original — possibly a %% or units note — and is left out here rather than guessed.)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Risk/Assurance/Reliability teeno ek hi coin ke do pehlu hain: Assurance (ya Reliability) = structure life bhar fail NA hone ki probability = qⁿ, aur Risk = Assurance ka complement = kam se kam ek baar fail hone ki probability = 1−qⁿ. Design mein hum chahte hain Risk <b>kam</b> ho — jaise upar wale example mein sirf 5% risk allowed hai 25 saal ke liye, isliye bahut bada T (≈488 years) chahiye, kyunki structure ki life lambi hai to chhote T (frequent flood) ka risk bahut zyada ho jaata." },
          { k: "trap", t: "Binomial formula mein 'n' aur 'T' ko mat ulta karo — P = 1/T (T return period se), par n <b>design life</b> hai (kitne saal structure khada rahega), yeh dono alag numbers ho sakte hain. P(r,n) formula mein P hamesha T se aata hai, n hamesha life/record-length se." },
        ],
      },

      /* ---------------------------------------------------------- 9.3 */
      {
        n: "9.3",
        title: "Flood-Frequency Formulas — Weibull, Hazen, California & U.S. Corps of Engineers",
        hi: "बाढ़-आवृत्ति सूत्र — वेइबुल, हेज़न, कैलिफोर्निया एवं यू.एस. कोर ऑफ इंजीनियर्स",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.100; S3 p.46, 48-50" },
          { k: "p", t: "This is the <b>Statistical-probability method</b> branch of Flood-Frequency Analysis: it is generally useful when the sample data (number of years of record) covers a long period and only a small extrapolation is needed. If the sample size is small and a large extrapolation is required, this method gives improper results and the <b>theoretical-probability (Gumbel's) method</b> (§9.4) should be used instead. (S2 p.98; S3 p.48)" },
          { k: "def", term: "Procedure (common to all four formulas below)", t: "Arrange the N recorded values of the given hydrological variable (rainfall, discharge etc.) in <b>decreasing order of magnitude</b> and assign each one an order number m, starting at m = 1 for the largest value. (S2 p.100)" },
          { k: "cmp", t: "The four empirical probability/return-period formulas (m = order number, N = total years of record)", cols: ["Probability of occurrence, P", "Return period, T = 1/P"], rows: [
            ["Weibull's formula", "P = m/(N+1)", "T = (N+1)/m"],
            ["Hazen's formula", "P = (m−0.5)/N", "T = N/(m−0.5)"],
            ["California formula", "P = m/N", "T = N/m"],
            ["U.S. Corps of Engineers formula", "P = (m+1)/N", "T = N/(m+1)"],
          ] },
          { k: "note", t: "<b>Label conflict across the sources — kept, not silently resolved:</b> S3 states the California-type formula (T = N/m) under the heading \"US method\" on one page (\"US method: T = N/m — we will follow only this\"), and then, on the very next page, gives a <i>different</i> formula (T = N/(m+1)) under the heading \"US crop method\" — almost certainly a transcription/OCR corruption of \"U.S. <b>Corps</b> of Engineers\" method. Both formulas are real and distinct, and are recorded above under their standard textbook names (California, and U.S. Corps of Engineers) rather than under S3's inconsistent \"US...\" labels. S2 independently confirms the California formula (P = m/n) by name, but gives no U.S. Corps of Engineers formula at all. (S2 p.100; S3 p.48-49)" },
          { k: "h", t: "Worked Example — Weibull's and Hazen's formulas (S2 p.100)" },
          { k: "cmp", t: "10 years of rainfall data, ranked in decreasing order (N = 10)", cols: ["Rainfall (cm)"], rows: [
            ["m = 1", "14.2"], ["m = 2", "13.6"], ["m = 3", "12.0"], ["m = 4", "12.0"], ["m = 5", "7.9"],
            ["m = 6", "6.0"], ["m = 7", "6.0"], ["m = 8", "4.8"], ["m = 9", "3.7"], ["m = 10", "2.9"],
          ] },
          { k: "eg", title: "Probability of the m = 6 rainfall value (6.0 cm) by Weibull's and Hazen's formulas", given: "For the ranked 10-year rainfall record above (N = 10), find the probability of occurrence of the m = 6 value by (a) Weibull's formula and (b) Hazen's formula.", steps: [
            { t: "(a) Weibull's formula", w: "P = m/(N+1) = 6/(10+1) = 6/11 ~ 0.545" },
            { t: "(b) Hazen's formula", w: "P = (m-0.5)/N = (6-0.5)/10 = 5.5/10 = 0.55" },
          ], ans: "Weibull: P ~ 0.545 (= 6/11); Hazen: P = 0.55 (= 11/20)." },
          { k: "note", t: "The source also attempts the California formula on this same dataset (\"P = m/n = [?] ⇒ d\" ... \"P = 1/T = 11/6 and 11/20 → (d)\"), but this part of the handwritten working is garbled/incomplete and marked illegible (\"[?]\") in the original — it is not reproduced as a number here, per the rule of not inventing a value the source itself could not supply. (S2 p.100)" },
          { k: "h", t: "Worked Example — California formula / \"US method\" (S3 p.48-50)" },
          { k: "cmp", t: "Example 1 — 7 years of discharge data (N = 7), T = N/m", cols: ["Discharge Q (cumec)", "T = N/m"], rows: [
            ["m = 1", "60", "7/1"], ["m = 2", "50", "7/2"], ["m = 3", "45", "7/3"], ["m = 4", "30", "7/4"],
            ["m = 5", "25", "7/5"], ["m = 6", "15", "7/6"], ["m = 7", "10", "7/7"],
          ] },
          { k: "eg", title: "Median (\"P₅₀\") exceedance probability for a second 7-year discharge series", given: "For another 7-year discharge series (60, 50, 25, 80, 65, 40, 20 cumec), ranked m = 1 (80 cumec) to m = 7 (20 cumec), find P₅₀ — the probability associated with the median-ranked value.", steps: [
            { t: "For N = 7, the median rank is m = 4 (the middle value, 50 cumec)", w: "T = N/m = 7/4" },
            { t: "P50 = 1/T", w: "P50 = 1/(7/4) = 4/7 ~ 0.571" },
          ], ans: "P50 = 4/7 ~ 0.571 (i.e. the 50-cumec, m=4 value is exceeded with probability ~57% in any year)." },
          { k: "note", t: "Neither source gives a worked numerical for the U.S. Corps of Engineers formula on its own — only the formula P = (m+1)/N, T = N/(m+1) itself is stated (S3 p.49). This is recorded here plainly rather than inventing a worked example for it." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Char formulas dikhte alag hain par sab ek hi family ke hain — sirf m ya N mein chhota sa adjustment (+1, −0.5) hai jo \"plotting position\" ko thoda smooth karta hai, especially chhote N ke liye (jaise agar m=N aur formula seedha m/N use karo to P=1, matlab 100% certain — jo galat lagta hai ek finite sample ke liye; Weibull jaisa +1 is problem ko thoda theek karta hai). Exam mein sabse zyada Weibull's aur California/US method puchhe jaate hain — formula + m/N ki basic calculation yaad rakhna kaafi hai." },
          { k: "trap", t: "Order number m ka matlab hamesha <b>largest value = m=1</b> hota hai (decreasing order), chhote se bada mat rank karo — ulta rank karne se P aur T dono reverse ho jaayenge." },
        ],
      },

      /* ---------------------------------------------------------- 9.4 */
      {
        n: "9.4",
        title: "Gumbel's Extreme-Value (Theoretical-Probability) Method",
        hi: "गम्बेल की चरम मान (सैद्धांतिक प्रायिकता) विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.101-103; S3 p.52-53" },
          { k: "def", term: "Gumbel's method", t: "A theoretical approach based on an extreme-value probability function; also called Chow's method. P(x ≥ x₀) = 1 − e^(−e^−y), where y is a dimensionless variate. (S2 p.101; S3 p.52)" },
          { k: "eq", expr: "XT = X̄ + KT·σ", where: [
            ["X̄", "mean of the hydrological data for a sample size of N years"],
            ["X̄ = (Σx)/N", ""],
            ["σ", "standard deviation of the sample, σ = √[ (N/(N−1)) · (x̄² − x²) ]"],
            ["XT", "maximum (peak) value of the hydrological data for a return period of T years"],
            ["KT", "frequency factor"],
          ] },
          { k: "eq", expr: "KT = (YT − Ȳn)/Sn   ;   YT = −logₑ·logₑ(T/(T−1))", where: [
            ["YT", "Reduced Variate, for the chosen return period T"],
            ["Ȳn", "Reduced mean — looked up from standard tables, depends on sample size N"],
            ["Sn", "Reduced standard deviation — looked up from standard tables, depends on sample size N"],
          ] },
          { k: "note", t: "As the sample size N → ∞, the Reduced mean Ȳn tends to its maximum value of <b>0.577</b>, and the Reduced standard deviation Sn tends to its maximum value of <b>1.2825</b>. For any finite N, both are looked up from standard Gumbel tables — e.g. the worked examples below use Ȳn = 0.5589, Sn = 1.2020 for N = 92 years, and Ȳn = 0.53622, Sn = 1.11238 for N = 30 years; both pairs sit sensibly below the N→∞ limits, as expected. (S3 p.52)" },
          { k: "def", term: "Confidence Limits (X₁, X₂)", t: "Since the value obtained by Gumbel's method may carry error due to the limited sample size, the confidence interval (X₁, X₂) gives the limits within which the true value can be expected to lie. (S2 p.101)" },
          { k: "eq", expr: "X1,2 = XT ± f(c)·Se   ;   Se = (b·σ)/√N   ;   b = √(1 + 1.3K + 1.1K²)", where: [
            ["Se", "probable error"],
            ["f(c)", "factor of confidence probability c"],
            ["b", "a factor computed from the frequency factor K"],
            ["N", "sample size, in years"],
          ] },
          { k: "cmp", t: "Factor of confidence probability, f(c)", cols: ["f(c)"], rows: [ ["c = 68%", "1"], ["c = 95%", "1.96"] ] },
          { k: "h", t: "Worked Example 1 — River Ganga at Allahabad, 92-year record (S2 p.102-103)" },
          { k: "eg", title: "Flood peak and 95% confidence limits for T = 500 years, from 92 years of Ganga data at Allahabad", given: "92 years of flood data for the river Ganga at Allahabad gives a mean of 6437 m3/s and a standard deviation of 2951 m3/s. Using Gumbel's method, find the flood peak discharge for a return period of T = 500 years, and the 95% confidence limits. Given: for 95% confidence probability, f(c) = 1.96; for a 92-year sample, reduced mean Yn-bar = 0.5589 and reduced standard deviation Sn = 1.2020.", steps: [
            { t: "Reduced variate for T = 500 years", w: "YT = -ln(ln(500/499)) = 6.2136" },
            { t: "Frequency factor", w: "K = (YT - Yn-bar)/Sn = (6.2136 - 0.5589)/1.2020 = 4.7044" },
            { t: "Flood peak for T = 500 years", w: "X500 = X-bar + K.sigma = 6437 + 4.7044 x 2951 = 20319.68 m3/s" },
            { t: "Factor b (for the confidence limits)", w: "b = sqrt(1 + 1.3K + 1.1K^2) = sqrt(1 + 1.3x4.7044 + 1.1x4.7044^2) = sqrt(31.46) = 5.6089" },
            { t: "Probable error Se", w: "Se = (b.sigma)/sqrt(N) = (5.6089 x 2951)/sqrt(92) = 1725.65" },
            { t: "95% confidence limits", w: "X1,2 = XT +/- f(c).Se = 20319.68 +/- 1.96 x 1725.65 = 20319.68 +/- 3382.28\nX2 = 23701.96 m3/s (upper limit)\nX1 = 16937.41 m3/s (lower limit)" },
          ], ans: "X500 = 20,319.68 m3/s, with 95% confidence limits of 16,937.41 to 23,701.96 m3/s. (Every intermediate figure here was independently re-checked and matches the source's arithmetic exactly — no inconsistency in this example.)" },
          { k: "h", t: "Worked Example 2 — finding X500 from two known return-period discharges (S2 p.103)" },
          { k: "eg", title: "Estimate the 500-year flood peak given the 50-year and 100-year flood peaks", given: "For a river, the T-year peak discharges are known: X50 = 20,600 cumec and X100 = 22,150 cumec. Estimate X500, the flood peak for a 500-year return period.", steps: [
            { t: "Reduced variates for T = 50, 100 and 500 years", w: "Y50 = -ln(ln(50/49)) = 3.9019\nY100 = -ln(ln(100/99)) = 4.6001\nY500 = -ln(ln(500/499)) = 6.2136" },
            { t: "Write XT = X-bar + (YT - Yn-bar)(sigma/Sn) for T=50 and T=100, then subtract to eliminate X-bar and Yn-bar", w: "X50 = X-bar + (3.9019 - Yn-bar)(sigma/Sn) = 20600   ...(i)\nX100 = X-bar + (4.6001 - Yn-bar)(sigma/Sn) = 22150   ...(ii)\n(i) - (ii): (Y50 - Y100)(sigma/Sn) = 20600 - 22150 = -1550\nsigma/Sn = -1550 / (3.9019-4.6001) = 1550/0.6982 = 2219.99" },
            { t: "Use the same elimination between the T=500 equation and (ii) to find X500", w: "X500 - X100 = (Y500 - Y100)(sigma/Sn)\nX500 - 22150 = (6.2136 - 4.6001) x 2219.99 = 1.6135 x 2219.99 = 3582.5\nX500 = 22150 + 3582.5" },
          ], ans: "X500 ~ 25,732 cumec (the source boxes 25,731.96)." },
          { k: "h", t: "Worked Example 3 — design discharge for 95% assurance over a design life (S3 p.52-53)" },
          { k: "eg", title: "Design discharge for 95% assurance of no failure in the next 50 years, from 30 years of data", given: "30 years of data at a point on a river give a mean discharge of 1200 cumec and a standard deviation of 650 cumec. For what value of discharge should the structure at this point be designed, so as to provide 95% assurance that the structure will not fail in the next 50 years? Take reduced mean Yn-bar = 0.53622, reduced standard deviation Sn = 1.11238.", steps: [
            { t: "Source's working — reduced variate computed using T = 30 (the sample record length)", w: "YT = -ln(ln(T/(T-1))), with T = 30\n= -ln(ln(30/29)) = 3.38429" },
            { t: "Frequency factor", w: "KT = (YT - Yn-bar)/Sn = (3.38429 - 0.53622)/1.11238 = 2.56031" },
            { t: "Design discharge", w: "XT = X-bar + KT.sigma = 1200 + 2.56031 x 650 = 2864.22 cumec" },
          ], ans: "As printed in the source: XT = 2864.22 cumec (see Check note — this answer does not actually use the 95% assurance / 50-year design-life condition the question asks for)." },
          { k: "note", t: "<b>Check:</b> the question asks for the discharge giving <b>95% assurance over a 50-year design life</b> — i.e. Risk ≤ 5% over n = 50 years — which means the return period T must first be found from the risk relation 0.05 = 1 − (1 − 1/T)⁵⁰, giving T ≈ 976 years, and <i>then</i> YT, KT and XT computed for that T (the sample length N = 30 is used only to look up Ȳn and Sn, never substituted in place of T). The source's working instead plugs T = 30 directly into the YT formula, which answers a different question (\"the 30-year flood\") rather than the one posed. Reworking correctly: T ≈ 976 years ⇒ YT = −ln(ln(976/975)) ≈ 6.88 ⇒ KT = (6.88−0.53622)/1.11238 ≈ 5.70 ⇒ XT ≈ 1200 + 5.70×650 ≈ <b>4908 cumec</b> — substantially higher than the source's printed 2864.22 cumec. Both figures are kept here: the source's own (T=30-based) working and answer above, and this corrected working in this note. (S3 p.52-53)" },
          { k: "h", t: "Safety Factor & Safety Margin, continuing this example (S3 p.53)" },
          { k: "eg", title: "Safety factor and safety margin if a design value of 6000 cumec is adopted", given: "If the design value adopted for the structure in the example above is 6000 m3/s, find the Safety Factor and Safety Margin against the estimated value.", steps: [
            { t: "Using the source's estimated value, XT = 2864.22 cumec", w: "S.F. = 6000/2864.22 = 2.09\nS.M. = 6000 - 2864.22 = 3135.78 cumec" },
          ], ans: "As printed in the source: S.F. = 2.09, S.M. = 3135.78 cumec. If the corrected estimate of ~4908 cumec from the Check note above is used instead, S.F. ~ 1.22 and S.M. ~ 1092 cumec — a materially smaller safety margin, which is exactly why getting T right in the step above matters for design." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Gumbel's method poora ek chain hai: pehle T (return period) decide karo (ya seedha diya hua hai, ya risk/assurance equation se nikalna padega — jaisa Example 3 mein galti se skip ho gaya), uske baad YT formula se reduced variate nikalo, phir KT (frequency factor), aur finally XT = X̄+KTσ se actual design value. Confidence limits ek alag, optional extra step hain jo batate hain ki limited N-year sample ki wajah se asli answer kitna upar-neeche ja sakta hai (±f(c)·Se)." },
          { k: "trap", t: "'K' letter hydrology mein <b>teen alag matlab</b> mein use hota hai — confuse mat karo: Rational formula mein K = runoff coefficient; Gumbel's method mein K (ya KT) = frequency factor; Muskingum method (§9.6) mein K = storage time constant (ghanton/dino mein). Formula likhte waqt context clear rakho." },
        ],
      },

      /* ---------------------------------------------------------- 9.5 */
      {
        n: "9.5",
        title: "Flood Routing — Concept, Purpose, Reservoir Routing vs Channel Routing",
        hi: "बाढ़ मार्गन — अवधारणा, उद्देश्य, रिज़र्वॉयर मार्गन बनाम चैनल मार्गन",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.104-106; S3 p.54-55" },
          { k: "def", term: "Flood Routing", t: "The hydrological technique used to determine the flood hydrograph at a particular section of a river/reservoir, using the flood flow known at an upstream section. When a flood passes through a reservoir (or a channel reach), its outflow rate comes out reduced and delayed compared to the inflow — flood routing is the process of calculating the water level, storage quantity and outflow rate corresponding to a given inflow hydrograph. (S2 p.104; S3 p.54)" },
          { k: "list", items: [
            "Flood routing helps design a <b>spillway</b> and a <b>reservoir</b> (why reservoir routing matters). (S3 p.54)",
            "Channel routing helps predict the flood hydrograph at various downstream sections of a channel, which is used for <b>flood forecasting</b> and <b>flood protection works</b>. (S3 p.54)",
          ] },
          { k: "dia", id: "hb-hydro-routing", cap: "Inflow vs outflow hydrograph through a reservoir/channel reach: the outflow peak (Qp) is lower than the inflow peak (Ip) — attenuation — and occurs later — lag. The shaded region between the two curves is the water temporarily held in storage." },
          { k: "h", t: "Reservoir Routing" },
          { k: "def", term: "Reservoir Routing", t: "Storage is a function of the outflow discharge alone: S = f(Q). Since the outflow rate here is uncontrolled (it is governed purely by the reservoir's own stage-discharge/outlet behaviour), the peak of the outflow hydrograph occurs as a direct function of the inflow and outflow hydrographs together — i.e. once outflow catches up with inflow on the hydrograph, the reservoir level (and so the outflow) stops rising. (S2 p.104)" },
          { k: "h", t: "Channel Routing" },
          { k: "def", term: "Channel Routing", t: "Storage is a function of <b>both</b> inflow and outflow: S = f(I) + f(Q). Because outflow here is not simply determined by the reservoir stage but by the actual water-surface profile along the reach, the outflow peak occurs later, as a function of the combined inflow-and-outflow history. (S2 p.105; S3 p.54-55)" },
          { k: "def", term: "Prism storage (Sp)", t: "The volume that would exist if uniform flow occurred throughout the reach — formed by an imaginary plane, parallel to the channel bottom, drawn at the outflow section's water surface. It is similar to reservoir storage: a function of the outflow discharge only, Sp = f(Q). (S2 p.105)" },
          { k: "def", term: "Wedge storage (Sw)", t: "The extra volume formed between the <b>actual</b> (sloping, backwater-affected) water-surface profile and the top of the prism storage. It is a function of the inflow discharge, Sw = f(I) — positive while the flood wave is rising (the actual surface slopes up above the prism level) and effectively reversing sign during the recession. (S2 p.105)" },
          { k: "eq", expr: "Total channel storage:  S = Sw + Sp = f(I) + f(Q)   ;   general storage equation:  S = K[x·Iᵘ + (1−x)·Qᵘ]", where: [
            ["K", "storage-time constant, dimension of time"],
            ["x", "weighting factor"],
            ["ᵘ (exponent m)", "m = 0.6 for a rectangular channel; m = 1 for a natural river (S2 p.105-106)"],
          ] },
          { k: "note", t: "The two sources give slightly different bands for x: S2 states a general range of 0.3 ≤ x ≤ 0.5, narrowing to 0.1 ≤ x ≤ 0.3 specifically for a natural river channel, while S3 simply states 0 < x < 0.5. These are not in conflict — S3's band is the broader envelope within which S2's tighter, channel-type-specific sub-ranges sit. (S2 p.106; S3 p.55)" },
          { k: "note", t: "<b>Linear reservoir — the limiting case connecting the two:</b> if outflow alone is taken to govern the channel's storage (x = 0, or equivalently I = 0 — a condition the source notes is \"only on paper, not in practical[ity]\"), then with m = 1 the general storage equation collapses to S = K·Q — a straight line through the origin on an S-vs-Q plot. A channel whose storage behaves this way is called a <b>linear reservoir</b>, and this is exactly the storage function used in Reservoir Routing above. (S2 p.106)" },
          { k: "h", t: "Methods of (Flood) Routing" },
          { k: "list", items: [
            "<b>Hydrological method</b> — based on the continuity equation only. (S2 p.106; S3 p.55)",
            "<b>Hydraulic method</b> — based on both the continuity equation and the momentum (equation of motion of unsteady flow / dynamic) equation. (S2 p.106; S3 p.55)",
          ] },
          { k: "note", t: "S2 lists the hydrological routing methods together, without separating reservoir- from channel-routing techniques: (i) Muskingum method (ii) Clark's method (iii) Pulse method (iv) Nash's method (v) Goodrich's method (S2 p.106). S3, by contrast, lists its hydrological methods specifically under <b>Reservoir</b> Routing: ① Modified Puls method ② Goodrich method ③ Standard fourth-order/Runge-Kutta method ④ Graphical method (S3 p.54), and separately introduces Muskingum under Channel Routing. The two lists are complementary rather than conflicting — S3's four are reservoir-routing techniques, Muskingum (common to both lists) is the channel-routing technique worked through in full in §9.6 next, and S2's Clark's/Nash's methods are further unit-hydrograph-based channel/catchment routing techniques not worked out in either source transcript here." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Reservoir vs channel routing ka sabse simple farak: reservoir mein storage sirf <b>outflow</b> ka function hai (S=f(Q)) kyunki reservoir ka water level hi outflow decide karta hai (spillway/gate curve se); channel mein storage <b>inflow aur outflow dono</b> ka function hai (S=f(I,Q)) kyunki running water ki wedge-shaped surface profile khud inflow ke upar depend karti hai. Isi wajah se channel routing (Muskingum jaisa) thoda zyada complex hai — do unknowns (storage ke andar I aur Q dono) solve karne padte hain." },
          { k: "trap", t: "Attenuation (peak height girna) aur lag (peak time delay hona) do alag chezein hain — diagram mein dono dikhai gayi hain. Attenuation hamesha hoti hai jab bhi koi storage beech mein aati hai (reservoir ya channel dono mein); lag bhi dono mein hota hai, par channel routing mein lag ko travel-time/storage-constant K se directly jodte hain (agla section)." },
        ],
      },

      /* ---------------------------------------------------------- 9.6 */
      {
        n: "9.6",
        title: "Muskingum Method of Channel Routing",
        hi: "चैनल मार्गन की मस्कीन्गम विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.106-108; S3 p.54-55" },
          { k: "def", term: "Muskingum Method", t: "A hydrological (continuity-equation-based) method of channel routing, applicable to natural channels only. Its aim is to derive the outflow hydrograph from a given inflow hydrograph, and from the two curves find the <b>attenuation</b> and <b>lag</b>. (S2 p.107)" },
          { k: "eq", expr: "Continuity equation:  Ī = Q̄ + ΔS/Δt   ⇒   (I1+I2)/2 = (Q1+Q2)/2 + ΔS/Δt", where: [
            ["Δt", "routing interval"],
            ["ΔS = S2 − S1", "change in channel storage over the interval"],
          ] },
          { k: "eq", expr: "Storage equation:  S2 − S1 = K[x(I2−I1) + (1−x)(Q2−Q1)]", where: [
            ["K, x", "the same Muskingum storage constant and weighting factor as the general channel-storage equation, §9.5"],
          ] },
          { k: "note", t: "For the best routing result, the routing interval should be chosen such that <b>2Kx < Δt < K</b> (K in hours). (S2 p.107)" },
          { k: "p", t: "Combining the continuity and storage equations, and starting from the assumed initial condition Q1 = I1 (outflow equals inflow before the flood wave arrives), gives the Muskingum routing equation:" },
          { k: "eq", expr: "Qn = C0·In + C1·In−1 + C2·Qn−1   ;   C0 + C1 + C2 = 1", where: [] },
          { k: "eq", expr: "C0 = (−Kx + 0.5Δt) / (K(1−x) + 0.5Δt)   ;   C1 = (Kx + 0.5Δt) / (K(1−x) + 0.5Δt)   ;   C2 = (K(1−x) − 0.5Δt) / (K(1−x) + 0.5Δt)", where: [] },
          { k: "h", t: "Worked Example — deriving the outflow hydrograph (S2 p.108)" },
          { k: "eg", title: "Outflow hydrograph, attenuation and lag by the Muskingum method", given: "An inflow hydrograph is given below (K = 12 hr, x = 0.278). Derive the outflow hydrograph using the Muskingum equation and find the attenuation and lag.\nTime (hr): 0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48\nInflow I (m3/s): 42, 68, 116, 164, 194, 200(peak), 192, 170, 150, 128, 106, 88, 79\n(Routing is carried out at the 8-hourly points: I1=42 at t=0, I2=116 at t=8, I3=194 at t=16, I4=192 at t=24, I5=150 at t=32, I6=106 at t=40, I7=79 at t=48.)", steps: [
            { t: "Check the routing-interval condition 2Kx < Δt < K", w: "2 x 12 x 0.278 = 6.67\nso 6.67 < Dt < 12 is required; the data is tabulated at Dt = 8 hr, which satisfies this." },
            { t: "Routing coefficients", w: "K(1-x) + 0.5.Dt = 12x0.722 + 4 = 8.664 + 4 = 12.664\nC0 = (-12x0.278 + 4)/12.664 = 0.664/12.664 = 0.0524\nC1 = (12x0.278 + 4)/12.664 = 7.336/12.664 = 0.5793\nC2 = (12x0.722 - 4)/12.664 = 4.664/12.664 = 0.3683\ncheck: C0+C1+C2 = 0.0524+0.5793+0.3683 = 1.0000 (OK)" },
            { t: "Initial condition and routing step by step, Qn = C0.In + C1.In-1 + C2.Qn-1", w: "Q1 = I1 = 42\nQ2 = C0.I2 + C1.I1 + C2.Q1 = 0.0524x116 + 0.5793x42 + 0.3683x42 = 45.88\nQ3 = C0.I3 + C1.I2 + C2.Q2 = 0.0524x194 + 0.5793x116 + 0.3683x45.88 = 94.26\nQ4 = C0.I4 + C1.I3 + C2.Q3 = 0.0524x192 + 0.5793x194 + 0.3683x94.26 = 157.16\nQ5 = C0.I5 + C1.I4 + C2.Q4 = 0.0524x150 + 0.5793x192 + 0.3683x157.16 = 176.97  (outflow peak)\nQ6 = C0.I6 + C1.I5 + C2.Q5 = 0.0524x106 + 0.5793x150 + 0.3683x176.97 = 157.6" },
            { t: "Attenuation and lag (reading the full, 4-hourly inflow curve's true peak Ip=200 at t=20 hr against the routed outflow peak)", w: "Outflow peak Qp = 176.97 m3/s occurs at t = 32 hr (same time-step as I5)\nInflow peak Ip = 200 m3/s occurs at t = 20 hr\nLag = 32 - 20 = 12 hr\nAttenuation = 200 - 176.97 = 23.03 m3/s" },
          ], ans: "Lag = 12 hr; Attenuation = 23.03 m3/s. (Every Q2 through Q6 value above was independently recomputed from the stated C0, C1, C2 and matches the source's table exactly.)" },
          { k: "note", t: "The source's table leaves the final row, Q7 (at t = 48 hr), blank (\"......\"). Continuing the same recurrence (not given in the source, but a direct, mechanical continuation of its own method): Q7 = C0.I7 + C1.I6 + C2.Q6 = 0.0524x79 + 0.5793x106 + 0.3683x157.6 ~ 123.6 m3/s." },
          { k: "real", t: "Notice that the computed lag (12 hr) comes out equal to the given K (12 hr) in this example — that is not a coincidence of the Muskingum method in general, but it illustrates K's physical meaning well: K is approximately the <b>travel/translation time</b> of the flood wave through the reach, which is exactly what a peak-to-peak lag measures. This is exactly how a river-gauging authority (e.g. CWC) would route a flood recorded at an upstream gauge (say Allahabad) down to a downstream town (say in Bihar) for flood forecasting and warning — the main sketch in S3 shows precisely this upstream-to-downstream reach. (S2 p.107-108; S3 p.54-55)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Muskingum method yaad rakhne ka tarika: pehle do equations hain (continuity + storage), unhe combine karke seedha ek <b>recurrence formula</b> mil jaata hai Qn ke liye — jisme teen fixed coefficients (C0, C1, C2, jo sirf K, x, Δt par depend karte hain, HAR step ke liye same rehte hain) aur pichhle step ke I, Q values chahiye. Isliye ek baar C0/C1/C2 nikal lo, phir sirf table mein row-by-row multiply-add karte jao — yehi iski sabse badi strength hai (simple, repeatable hand calculation)." },
          { k: "trap", t: "C0+C1+C2 = 1 hamesha check karo — agar yeh sum 1 nahi aa raha, to K, x ya Δt mein calculation mistake hai. Yeh ek built-in self-check hai jo bahut log answer submit karne se pehle bhool jaate hain." },
        ],
      },

      /* ---------------------------------------------------------- 9.7 */
      {
        n: "9.7",
        title: "Quick revision — floods, flood-frequency analysis & flood routing",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Flood definition; Design Flood and its 4 estimation methods; Recurrence Interval T and P=1/T (S2 p.96,98; S3 p.46,48).",
            "Binomial probability P(r,n)=ⁿCᵣPʳqⁿ⁻ʳ; special cases Assurance/Reliability=qⁿ, Risk=1−qⁿ; Safety Factor & Safety Margin (S2 p.99-100; S3 p.50-51).",
            "Four flood-frequency formulas — Weibull P=m/(N+1), Hazen P=(m−0.5)/N, California P=m/N, U.S. Corps of Engineers P=(m+1)/N — all with m=1 for the largest value (S2 p.100; S3 p.48-50).",
            "Gumbel's method: XT=X̄+KTσ, KT=(YT−Ȳn)/Sn, YT=−ln·ln(T/(T−1)); confidence limits X1,2=XT±f(c)Se, Se=bσ/√N, b=√(1+1.3K+1.1K²) (S2 p.101-103; S3 p.52-53).",
            "Flood routing concept; Reservoir Routing S=f(Q) vs Channel Routing S=f(I,Q); prism storage Sp=f(Q), wedge storage Sw=f(I); general storage eqn S=K[xIᵘ+(1−x)Qᵘ]; Hydrological vs Hydraulic routing methods (S2 p.104-106; S3 p.54-55).",
            "Muskingum method: continuity + storage equations combine into Qn=C0In+C1In−1+C2Qn−1, with C0+C1+C2=1; routing-interval rule 2Kx<Δt<K; full worked example with attenuation & lag (S2 p.106-108).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "T = 1/P is a long-run average, not a fixed schedule — use the binomial formula for \"r times in n years\" type questions, not P=1/T directly.",
            "Rank m=1 for the largest value in all four frequency formulas; the +1/−0.5 adjustments mainly matter for small sample sizes N.",
            "Gumbel's YT depends only on the chosen return period T — when a question gives an assurance/design-life condition instead of T directly, solve the risk equation for T FIRST, then compute YT (a step the source itself missed in one worked example — see the Check note in §9.4).",
            "Reservoir routing: storage is a function of outflow alone. Channel routing: storage is a function of both inflow and outflow (prism + wedge) — this is why channel routing (Muskingum) needs two parameters, K and x.",
            "In Muskingum routing, attenuation = Ip−Qp (peak heights) and lag = difference in peak times; K is approximately the reach's own travel time, which is why lag and K often come out close to each other.",
          ] },
        ],
      },

    ],
  });
})();
