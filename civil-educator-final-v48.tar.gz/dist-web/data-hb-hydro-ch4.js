/* ============================================================
   HYDROLOGY · COMPLETE NOTES — Chapter 4
   Evaporation, Transpiration & Evapotranspiration
   Sources consolidated here: S2 (p.29-37, p.47-49), S3 (p.13-18)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-4",
    n: 4,
    title: "Evaporation, Transpiration & Evapotranspiration",
    hi: "वाष्पीकरण, पत्र-वाष्पोत्सर्जन एवं वाष्पन-उत्सर्जन",
    blurb: "Evaporation ki physics (vapour pressure, Dalton's law, Rh, dew/wet-bulb point), factors affecting it, Class-A/I.S. pan measurement with pan coefficient Cp (USA 0.70 vs IS 0.80 aur unka ~14% difference), Water/Energy/Mass-transfer budget methods, evaporation control, aur transpiration/evapotranspiration (PET/AET, Lysimeter, field-plot, Penman's equation).",
    mins: 24,
    sections: [

      /* ---------------------------------------------------------- 4.1 */
      {
        n: "4.1",
        title: "Evaporation — the physics: vapour pressure, Dalton's law, relative humidity, dew point, wet bulb",
        hi: "वाष्पीकरण की भौतिकी",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.29, 39; S3 p.13" },
          { k: "def", term: "Evaporation", t: "A cooling process in which liquid water changes into its gaseous (vapour) phase at the free surface, below boiling-point temperature, through the transfer of heat energy — the heat of evaporation is about 585 cal/gm, supplied by the water body itself (so the water body cools as it evaporates). Loss of water from the surface of a sea, river, canal, barrage etc. is called evaporation. (S2 p.29; S3 p.13)" },
          { k: "list", items: [
            "Evaporation can happen at <b>any</b> temperature below the boiling point; boiling occurs only at the fixed boiling-point (B.P.) temperature. (S2 p.29)",
            "Evaporation is a <b>natural</b> phenomenon; boiling is a <b>man-made</b> phenomenon. (S2 p.29)",
          ] },
          { k: "def", term: "Dalton's Law of evaporation", t: "The rate of evaporation is directly proportional to the saturation deficit (es &minus; ea): <br><b>E = K(es &minus; ea)</b> &nbsp;(mm/day), where es = saturation vapour pressure of the air (mm of Hg), ea = actual vapour pressure of the air (mm of Hg), and K is a constant that accounts for the size of the water body. (S2 p.29)" },
          { k: "eq", expr: "Dalton's law:  E = K(es − ea)   [mm/day]", where: [
            ["es", "saturation vapour pressure of air, mm of Hg"],
            ["ea", "actual vapour pressure of air, mm of Hg"],
            ["es − ea", "saturation deficit"],
            ["K", "constant accounting for the size of the water body"],
          ] },
          { k: "def", term: "Vapour pressure", t: "Water existing in vapour form in the atmosphere exerts a partial pressure — this is the vapour pressure. (S2 p.30)" },
          { k: "def", term: "Saturation vapour pressure (es)", t: "For a given temperature, the pressure exerted when the air holds water vapour to its maximum capacity. (S2 p.30)" },
          { k: "def", term: "Relative Humidity (Rh)", t: "Rh = (ea/es) &times; 100%. (S2 p.29)" },
          { k: "def", term: "Dew point temperature", t: "The temperature at which the saturation vapour pressure becomes equal to the existing (actual) vapour pressure, i.e. ea = es at that temperature. (S2 p.30)" },
          { k: "def", term: "Wet bulb temperature", t: "The temperature at which the air becomes fully saturated. (S2 p.30)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Saari physics ek hi idea ke around ghoomti hai: hawa mein kitna paani-vapour 'fit ho sakta hai' (es, temp-dependent) aur kitna 'abhi hai' (ea). Jab ea < es, hawa mein capacity bachi hai, to evaporation hoga (Dalton's law). Jab ea = es, hawa saturated ho gayi — ab aur evaporate nahi hoga; usi condition ko reach karne ke liye temp girao to woh <b>dew point</b> hai (condensation shuru hoti hai), aur usi saturation ko evaporative cooling se reach karo to woh <b>wet bulb temp</b> hai. Rh sirf ea aur es ka percentage ratio hai — 100% Rh ka matlab hawa already saturated hai." },
          { k: "trap", t: "Evaporation aur boiling ko mix mat karo — evaporation surface par, boiling point se neeche, kisi bhi temp par ho sakta hai; boiling poore liquid mein, ek fixed temp (B.P.) par hota hai. (S2 p.29)" },
        ],
      },

      /* ---------------------------------------------------------- 4.2 */
      {
        n: "4.2",
        title: "Factors affecting evaporation",
        hi: "वाष्पीकरण को प्रभावित करने वाले कारक",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.30–31; S3 p.13" },
          { k: "list", items: [
            "<b>Vapour pressure (saturation deficit):</b> rate of evaporation &prop; (es &minus; ea) — Dalton's law above. (S2 p.29)",
            "<b>Temperature:</b> if other factors remain the same, rate of evaporation increases with increase in temperature. No fixed mathematical relation between evaporation and temperature has been derived — the dependence is known only from practical experience. (S2 p.30; S3 p.13)",
            "<b>Wind speed:</b> rate of evaporation increases with wind speed, but only up to a <b>critical velocity (Vc)</b> — beyond Vc, further increase in wind speed has no additional effect (the rate-vs-wind-speed curve rises steeply then flattens off at Vc). Physically, wind keeps replacing the vapour-saturated air just above the surface with drier air, sustaining the saturation deficit. (S2 p.30; S3 p.13)",
            "<b>Atmospheric pressure:</b> if other factors remain the same, rate of evaporation decreases with increase in atmospheric pressure (i.e. evaporation increases as pressure decreases). Gauge pressure is measured relative to atmospheric pressure; absolute pressure is measured relative to zero pressure. (S2 p.30; S3 p.13)",
            "<b>Presence of soluble salts:</b> dissolved salts reduce the rate of evaporation. Under similar conditions, evaporation from ocean (saline) water is about 2–3% less than from fresh water. (S2 p.31)",
            "<b>Age/area/depth of the water body:</b> <br>(i) <i>Area</i> — evaporation is higher when the exposed surface area is larger (same volume spread thin evaporates faster than the same volume in a narrow container). <br>(ii) <i>Depth</i> — for the same surface area: in <b>summer</b>, a <b>shallow</b> water body evaporates faster (it heats through quickly); in <b>winter</b>, a <b>deep</b> water body evaporates faster (stored heat from depth keeps the surface warmer than a shallow body that has cooled through). (S2 p.31)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Wind ka Vc wala plateau samjhna easy hai: wind ka kaam hi hai saturated air hatana — ek baar jab fresh/dry air surface par itni fast aa rahi ho ki vapour accumulate hone ka mauka hi na mile, to aur tez wind chalane se extra fayda nahi, kyunki bottleneck ab wind nahi, khud evaporation process (heat supply) ban jaata hai. Depth ka seasonal reversal bhi isi 'heat storage' logic se aata hai — gehra paani ek thermal reservoir ki tarah kaam karta hai, jo garmi mein slow garam hota hai (shallow jaldi garam ho jaata hai, evap zyada) aur sardi mein slow thanda hota hai (shallow jaldi thanda, evap kam; deep abhi bhi andar se warm, evap zyada)." },
          { k: "real", t: "Isi wajah se design mein reservoir ki depth aur shape ka evaporation-loss par asar padta hai — ek wide-shallow reservoir same volume ke liye zyada evaporation loss dega ek narrow-deep reservoir se, jo ki Section 4.7 (evaporation control) mein 'reduce surface area' recommendation ka direct basis hai." },
        ],
      },

      /* ---------------------------------------------------------- 4.3 */
      {
        n: "4.3",
        title: "Measurement — Class-A and I.S. evaporation pans, pan coefficient Cp (USA vs IS, the ~14% question)",
        hi: "मापन — वाष्पन पात्र एवं पात्र गुणांक",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.31–33; S3 p.13–16" },
          { k: "p", t: "Evaporation is measured by an <b>evaporimeter</b> (also called an atmometer) — a water-containing pan exposed to the atmosphere, with the water loss measured at regular time intervals. Two standard types are used: the <b>Class-A pan</b> and the <b>Indian Standard (I.S.) pan</b>. (S2 p.31; S3 p.13)" },
          { k: "dia", id: "hb-hydro-pan", cap: "Class-A pan (USA) vs I.S. pan — same tin, different material and lid, hence different Cp." },
          { k: "list", items: [
            "<b>Class-A Pan (USA):</b> 1210 mm diameter, 255 mm depth; water maintained at 180–200 mm depth; made of unpainted galvanized iron sheet; open top; stands on a wooden platform 150 mm high (for free air circulation beneath). (S2 p.31–32)",
            "<b>I.S. Pan:</b> a modified Class-A pan, same 1210 mm dia &times; 255 mm depth; made of <b>copper</b> sheet; also on a 150 mm wooden platform; its flat top is covered with <b>hexagonal galvanized-iron wire netting</b>, which protects the water from birds and helps maintain a uniform pan temperature day and night. Covering the pan this way reduces the observed evaporation by <b>14.1%</b> compared with an identical uncovered pan. (S2 p.32)",
          ] },
          { k: "def", term: "Pan coefficient (Cp)", t: "A pan's evaporation reading is not the same as a real reservoir's evaporation — the pan's material, heat-storing capacity, exposure to wind, and side/bottom slope all differ from a reservoir's. Cp corrects the pan reading to a reservoir-equivalent value: <b>Reservoir evaporation = Cp &times; Pan evaporation</b>. Generally, reservoir evaporation is less than pan evaporation. (S2 p.32–33; S3 p.13)" },
          { k: "eq", expr: "Reservoir evaporation = Cp × Pan evaporation", where: [["Cp", "pan coefficient (dimensionless)"]] },
          { k: "cmp", t: "Pan coefficient ranges (S2 p.33)", cols: ["Cp range", "Average Cp"], rows: [
            ["Class-A Pan", "0.60 – 0.80", "0.70"],
            ["I.S. Pan", "0.65 – 1.10", "0.80"],
          ] },
          { k: "note", t: "<b>Cross-check — S2 vs S3 on Cp:</b> S2's table (p.33) and S3 (p.13) agree exactly on the headline average values — <b>Cp &asymp; 0.70 for the Class-A (USA) pan and Cp &asymp; 0.80 for the I.S. pan</b> — and both define Cp the same way (Reservoir evap = Cp &times; Pan evap, i.e. Cp = Reservoir/Pan). So there is <b>no real conflict</b> in the number or the convention between the two sources here; S2 additionally gives the full ranges (0.60–0.80 and 0.65–1.10) that S3 does not state." },
          { k: "h", t: "The ~14% USA-vs-IS derivation (S3 p.13–14) — and why it must not be confused with the pan's own 14.1% netting effect (S2 p.32)" },
          { k: "p", t: "S3 derives where a commonly quoted '~14%' figure comes from: for the <b>same</b> reservoir evaporation, say ER = 10 cm, work out what each pan type would have to read to give that reservoir value via Cp." },
          { k: "eg", title: "USA Class-A pan reading vs I.S. pan reading, for the same reservoir evaporation", given: "Reservoir evaporation ER = 10 cm (same value, both cases). CpUSA = 0.7, CpIS = 0.8. Find the pan reading Ep each pan type would need to show, and the % difference between them.", steps: [
            { t: "Class-A (USA) pan reading needed", w: "Ep(USA) = ER / CpUSA = 10 / 0.7 = 14.28 cm" },
            { t: "I.S. pan reading needed", w: "Ep(IS) = ER / CpIS = 10 / 0.8 = 12.5 cm" },
            { t: "% difference, IS pan taken as the base", w: "(14.28 / 12.5) × 100 = 114.24% ⟹ 114.24 − 100 = 14.24%" },
          ], ans: "The Class-A (USA) pan would read about 14% higher than the I.S. pan, for the identical reservoir evaporation — because the USA pan's smaller Cp (0.7 vs 0.8) means a bigger raw pan reading is needed to correct down to the same reservoir figure. (S3 p.13–14)" },
          { k: "note", t: "<b>These are two different '14%' numbers — do not merge them:</b><br>(a) S2 p.32's 14.1% is the drop in a <i>single I.S. pan's own reading</i> caused by fitting the wire-netting cover, compared to the same pan left uncovered.<br>(b) S3 p.13–14's ~14.24% is a <i>cross-type</i> comparison — how much higher a Class-A (USA) pan reads than an I.S. pan, when both are made to correspond to the same real reservoir evaporation via their respective Cp values.<br>They happen to land on nearly the same percentage by coincidence of the numbers involved; they are not the same physical effect, and one is not a restatement or proof of the other." },
          { k: "eg", title: "Pan-coefficient application — reservoir evaporation loss from an I.S.-pan reading", given: "Water-surface area of a reservoir on a particular day = 100 hectare. Pan (I.S.) evaporation reading = 4 cm/day. Find the reservoir's evaporation loss (min, max and average), using the I.S. pan's Cp range 0.65–1.10 (avg 0.80).", steps: [
            { t: "Convert pan reading + area to a volume rate", w: "Pan evap. volume-equivalent = 4 cm/d over 100 ha = (4×10⁻² m/d) × (100 × 10⁴ m²) = 4 × 10⁴ m³/day" },
            { t: "Minimum reservoir evaporation (Cp = 0.65)", w: "Res. evap(min) = 0.65 × 4×10⁴ = 2.60 × 10⁴ m³/day" },
            { t: "Maximum reservoir evaporation (Cp = 1.10)", w: "Res. evap(max) = 1.10 × 4×10⁴ = 4.40 × 10⁴ m³/day" },
            { t: "Average reservoir evaporation (Cp = 0.80)", w: "Res. evap(avg) = 0.80 × 4×10⁴ = 3.20 × 10⁴ m³/day" },
          ], ans: "Reservoir evaporation loss ≈ 2.60×10⁴ m³/day (min) to 4.40×10⁴ m³/day (max), average 3.20×10⁴ m³/day. (S2 p.33)" },
          { k: "def", term: "Volume of water lost — reservoir vs canal (S3 p.14)", t: "<b>Reservoir:</b> Volume lost = Cp &times; Ep &times; average surface area of the reservoir. <b>Canal:</b> Volume lost = Cp &times; Ep &times; average width &times; average length of the canal (i.e. average width &times; length stands in for the average surface area, since a canal's area isn't given directly). (S3 p.14)" },
          { k: "eg", title: "Volume of water lost from a canal (S3's formula)", given: "Canal length = 40 km, average surface width = 10 m. Pan evaporation = 2 mm/day. Pan is Class-A/USA type (Cp = 0.7). Find the total volume of water lost from the canal per day.", steps: [
            { t: "Apply V = Cp × Ep × avg width × avg length", w: "V = 0.7 × 2 mm/day × 10 m × 40 km" },
            { t: "Convert to consistent units (m)", w: "V = 0.7 × (2×10⁻³ m/day) × 10 m × 40,000 m" },
            { t: "Compute", w: "V = 0.7 × 2×10⁻³ × 10 × 40,000 = 560 m³/day" },
          ], ans: "V = 560 m³/day. (S3 p.15)" },
          { k: "eg", title: "Volume of water lost from a reservoir, pan evaporation found from a weekly water balance of the I.S. pan itself", given: "Average reservoir surface area = 40 km². Pan used = I.S. pan (Cp = 0.8). Depth of water in the pan initially = 20 cm. Depth of rainfall added = 6 cm. Depth of water removed from the pan (to maintain its reference level) = 4 cm. Depth of water remaining in the pan after 1 week = 16 cm. Find the volume of water lost from the reservoir per day.", steps: [
            { t: "Pan's own water balance over the week: Initial + Rain − Removed − Evaporated = Final", w: "20 + 6 − 4 − Ep(week) = 16  ⟹  Ep(week) = (20+6) − 4 − 16 = 6 cm/week" },
            { t: "Convert to a daily pan evaporation rate", w: "Ep = 6 / 7 ≈ 0.857 cm/day" },
            { t: "Apply V = Cp × Ep × avg. reservoir area (area in cm² so V comes out in cm³)", w: "V = 0.8 × 0.857 cm/day × (40 km² = 40×10¹⁰ cm²) ≈ 2.74 × 10¹¹ cm³/day  (≈ 2.74×10⁵ m³/day)" },
          ], ans: "Working the pan's own water balance directly gives Ep ≈ 0.857 cm/day and V ≈ 2.74×10¹¹ cm³/day (≈ 2.74×10⁵ m³/day) — see the Check note below for how this compares with the source's boxed figure." },
          { k: "note", t: "<b>Check — S3's own transcript flags this step as unclear (p.15–16):</b> after computing the week's pan balance as 6 cm/week, the source's very next line jumps straight to <b>Ep = 19.71 cm/day</b> with the conversion step not shown or illegible — 6 cm/week is 0.857 cm/day by ordinary division, not 19.71 cm/day. The source's final boxed answer, <b>V = 6.30 × 10¹² cm³/day</b>, is internally consistent with its own 19.71 cm/day figure (0.8 × 19.71 × 40×10¹⁰ ≈ 6.30×10¹²), but that 19.71 cm/day cannot be reproduced from the 6 cm/week balance shown on the same page. Both the source's number (V = 6.30×10¹² cm³/day) and the figure obtained by working the stated balance directly (V ≈ 2.74×10¹¹ cm³/day) are given here — the missing step means neither can be confirmed as the one originally intended." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Cp ko ek 'translation factor' ki tarah socho — pan chhota hai, metal ka hai, sides se extra heat leta/deta hai, isliye woh reservoir se zyada evaporate karta hai (per unit area). Cp &lt; 1 hamesha is directionality ko encode karta hai: Reservoir = Cp &times; Pan, aur Cp jitna chhota, pan utna hi 'zyada over-read' karta hai reservoir ke comparison mein. IS pan ka Cp (0.80) class-A (0.70) se bada hai kyunki IS pan ka copper sheet aur wire-netting cover usko reservoir jaisa behave karne mein thoda better banate hain — isi wajah se raw IS-pan reading reservoir ke zyada 'close' hoti hai, aur ek fixed reservoir value ke liye use kam raw pan-evaporation dikhani padti hai (12.5 cm vs 14.28 cm) — yahi upar wala 14% derivation hai." },
          { k: "trap", t: "Pan coefficient ka Cp aur I.S. pan ke wire-netting ka 14.1% — dono alag hi cheez hain (dekho note block upar). Exam mein '14%' sunke seedha ek formula mat laga do — poochho jaa raha hai konsa '14%': single-pan cover-effect ya USA-vs-IS cross comparison." },
        ],
      },

      /* ---------------------------------------------------------- 4.4 */
      {
        n: "4.4",
        title: "Water Budget method",
        hi: "जल संतुलन विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.33–35; S3 p.18" },
          { k: "def", term: "Water Budget method", t: "Based on the <b>conservation of mass</b> principle. It is the simplest analytical method, generally useful for rough calculation work. (S2 p.33)" },
          { k: "eq", expr: "Inflow = Outflow ± ΔS   (mass conservation, per unit time)", where: [["ΔS", "change in storage over the time interval"]] },
          { k: "eq", expr: "Full water-budget equation:  P + Vis + Vig = E + Vos + Vog + TL + ΔS", where: [
            ["P", "daily precipitation on the water surface"],
            ["Vis", "daily surface inflow into the river/reservoir"],
            ["Vig", "daily sub-surface (groundwater) inflow"],
            ["E", "evaporation"],
            ["Vos", "daily surface outflow"],
            ["Vog", "daily sub-surface (groundwater) outflow"],
            ["TL", "transpiration loss"],
            ["ΔS", "change in storage, = + ve if inflow > outflow (level rises), − ve if inflow < outflow (level falls)"],
          ] },
          { k: "p", t: "Sign of ΔS: if I (inflow) &gt; Q (outflow), the water level rises from an initial Si to a higher Sf, so ΔS = +ve (Sf − Si); if I &lt; Q, the level falls and ΔS = −ve (Sf − Si). (S2 p.34)" },
          { k: "eg", title: "Solve for evaporation E from a monthly water budget", given: "Reservoir area A = 20 km²  (month: June). Surface inflow Vi = 10 m³/s. Surface outflow Vo = 15 m³/s. Precipitation P = 1.8 cm. Change in storage ΔS, stated in the source as 16×10⁵ m³ but used in the source's own working as 16×10⁶ m³ (taken over the month — see the Check note below). Find evaporation E.", steps: [
            { t: "Inflow-side depth over the month (30 days)", w: "Vi contribution = (10 m³/s × 30×86400 s × 100) / (20×10⁶ m²) = 129.6 cm" },
            { t: "Total inflow-side depth, I", w: "I = P + 129.6 = 1.8 + 129.6 = 131.4 cm" },
            { t: "Outflow-side depth over the month", w: "Vo contribution = (15 m³/s × 30×86400 s × 100) / (20×10⁶ m²) = 194.4 cm" },
            { t: "Total outflow-side depth, Q (in terms of E)", w: "Q = 194.4 + E" },
            { t: "ΔS as a depth (level fell, since I < Q, so ΔS is −ve), using 16×10⁶ m³", w: "ΔS = −(16×10⁶ / 20×10⁶) × 100 = −80 cm" },
            { t: "Apply I = Q + ΔS and solve for E", w: "131.4 = (194.4 + E) + (−80) ⟹ 131.4 = 114.4 + E ⟹ E = 17.0 cm" },
          ], ans: "E ≈ 17.0 cm for the month (by consistent working from the stated givens, using ΔS = 16×10⁶ m³)." },
          { k: "note", t: "<b>Check — two slips in the source's own working for this problem (S2 p.34):</b><br>(a) ΔS is stated as <b>16×10⁵ m³</b> but the source's own next line converts it to a depth using <b>16×10⁶ m³</b> instead (giving the −80 cm used above) — kept here as 16×10⁶ m³ since that is the figure actually carried forward.<br>(b) the source's 'I' line does not use P = 1.8 cm as stated — it substitutes <b>10 cm</b> in its place (giving I = 10 + 129.6 = 139.6 cm, not 131.4 cm), and a later substitution step writes 129.6 where 139.6 appears to be meant. Carried through <i>exactly as the source wrote it</i>, this chain gives the source's boxed answer <b>E = 23.4 cm</b>. Reworked here instead with P = 1.8 cm applied consistently (and ΔS = 16×10⁶ m³ as above) gives E ≈ 17.0 cm. Both figures are given rather than silently picking one — the source's own chain of substitution does not resolve cleanly enough to say which was 'intended'." },
          { k: "eg", title: "Solve for change in storage ΔS (and new reservoir elevation)", given: "Reservoir area A = 5000 hectare = 5×10⁷ m². Surface elevation (start) = 103.2 m above datum. Surface inflow Vi = 6 m³/s. Surface outflow Vo = 6.5 m³/s. Precipitation P = 145 mm. Evaporation E = 6.1 cm, over 30 days. Find ΔS and the new surface elevation.", steps: [
            { t: "Inflow-side depth", w: "I = P + Vi-depth = 0.145 + [(6 × 30×86400)/(5×10⁷)] = 0.145 + 0.311 = 0.456 m" },
            { t: "Outflow-side depth", w: "Q = E + Vo-depth = 0.061 + [(6.5 × 30×86400)/(5×10⁷)] = 0.061 + 0.337 = 0.398 m" },
            { t: "Apply I = Q ± ΔS", w: "ΔS = I − Q = 0.456 − 0.398 ≈ 0.058 m" },
            { t: "New surface elevation", w: "103.2 + 0.058 = 103.258 m above datum" },
          ], ans: "ΔS ≈ +0.058 m (level rises); new surface elevation ≈ 103.258 m above datum. (S2 p.34)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Water budget method sirf accounting hai — paani kahin gayab nahi hota, bas form/location badalta hai. Har term ko same side (in ya out) par daalke, aur sabko <b>same unit mein</b> (depth-over-area, cm ya m, ya volume, m³) convert karke equate kar do. Zyada exam mistakes unit-conversion mein hoti hain (m³/s ko cm/day mein convert karte waqt seconds-per-day aur area ka exponent sahi lagana), formula khud trivial hai." },
          { k: "trap", t: "ΔS ka sign bhool jaana sabse common mistake hai — pehle check karo inflow &gt; outflow hai ya &lt;, tabhi + ya − lagao; blindly formula mein daal doge to sign ulta aa jaayega. (S2 p.34)" },
        ],
      },

      /* ---------------------------------------------------------- 4.5 */
      {
        n: "4.5",
        title: "Energy Budget method (Bowen's ratio)",
        hi: "ऊर्जा संतुलन विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.35; S3 p.18" },
          { k: "def", term: "Energy Budget method", t: "Based on the <b>conservation of energy</b> principle. The energy available to drive evaporation is found by accounting for all incoming energy, outgoing energy, and energy stored in the water body, over a known time interval. (S2 p.35; S3 p.18)" },
          { k: "p", t: "Incoming solar radiation Hc strikes the water surface. Part of it is reflected (γ·Hc, where γ is the reflection coefficient/albedo) and part is absorbed/refracted into the water ((1 − γ)Hc). The surface also loses heat by back radiation (Hb, due to surface waves). So the net heat received by the water body is: (S2 p.35)" },
          { k: "eq", expr: "Hn = (1 − γ)Hc − Hb", where: [
            ["Hn", "net heat received by the water body"],
            ["Hc", "incoming solar radiation"],
            ["γ", "reflection coefficient of the water surface"],
            ["Hb", "back radiation, caused by wave action on the water surface"],
          ] },
          { k: "p", t: "This net heat Hn is then disposed of among several sinks — heat stored in the water (Hs), heat flux conducted into the ground (Hg), heat advected out by water flowing through the system (Hi), sensible heat transferred from the water surface to the air (Ha), and heat used to drive evaporation (HE):" },
          { k: "eq", expr: "Hn = Hs + Hg + Hi + Ha + HE", where: [
            ["Hs", "heat stored in the water body"],
            ["Hg", "heat flux into the ground"],
            ["Hi", "advected energy — net heat conducted out of the system by water flow"],
            ["Ha", "sensible heat transfer from the water surface to the air"],
            ["HE", "heat energy used in evaporation, HE = ρLE"],
          ] },
          { k: "def", term: "Bowen's Ratio (β)", t: "β = Ha / HE — the ratio of sensible heat transfer to the air, over the heat used for evaporation. (S2 p.35)" },
          { k: "p", t: "Rearranging the energy balance using Bowen's ratio (Ha = β·HE) and HE = ρLE, to isolate the evaporation rate E:" },
          { k: "eq", expr: "Hn − Hg − Hs − Hi = Ha + HE = (β+1)HE = (β+1)ρLE", where: [] },
          { k: "eq", expr: "E = (Hn − Hg − Hs − Hi) / [ρL(β + 1)]", where: [
            ["ρ", "density of water"],
            ["L", "latent heat of evaporation"],
            ["E", "evaporation rate"],
            ["note", "all heat terms are expressed in cal/mm²/day"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Energy budget bhi bilkul water budget jaisa hi 'accounting' hai, bas currency paani nahi, <b>heat (energy)</b> hai. Jo bhi heat water body ko milta hai (Hn), usko kahin-kahin jaana hi hai — kuch ground mein chala jaata hai (Hg), kuch stored ho jaata hai (Hs), kuch flowing water le jaata hai (Hi), aur baaki do raaston se air mein jaata hai: directly (sensible heat, Ha) ya evaporation ke through (latent heat, HE). Bowen's ratio β bata deta hai ki in do raahon (Ha aur HE) mein heat kis ratio mein baant raha hai — isi se formula E nikaal leta hai bina Ha ko alag se measure kiye." },
          { k: "real", t: "Energy budget method field mein lagana mushkil hai kyunki Hg, Hs, Hi sab independently measure/estimate karne padte hain — isliye practice mein zyada tar reservoirs ke liye pan-coefficient (4.3) ya water-budget (4.4) jaisi simpler methods prefer ki jaati hain, energy budget zyada research-grade studies mein use hota hai." },
        ],
      },

      /* ---------------------------------------------------------- 4.6 */
      {
        n: "4.6",
        title: "Mass Transfer method — Meyer's formula and the 1/7th power law",
        hi: "द्रव्यमान स्थानांतरण विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.31, 36; S3 p.13" },
          { k: "def", term: "Mass Transfer method", t: "An analytical method based on the theory of <b>turbulent mass transfer</b> in the boundary layer, used to calculate the mass of water vapour transferred from the water surface into the air. (S2 p.31, 36)" },
          { k: "p", t: "The standard practical (empirical) formula used to implement the mass-transfer approach is <b>Meyer's formula</b>:" },
          { k: "eq", expr: "Meyer's formula:  E = K(es − ea)[1 + Vg/16]   [mm/day]", where: [
            ["E", "rate of evaporation, mm/day"],
            ["K", "constant accounting for the size of the water body — K = 0.36 for a large, deep water body; K = 0.5 for a small, shallow water body"],
            ["es", "saturation vapour pressure of air, mm of Hg"],
            ["ea", "actual vapour pressure of air, mm of Hg"],
            ["Vg", "wind velocity, km/hr, at 9 m above ground level (measured by an anemometer)"],
          ] },
          { k: "def", term: "1/7th power law", t: "Wind velocity varies with height above the ground as Vg &prop; (h)^(1/7). Both S2 (p.36, stated for Meyer's formula's 9 m reference height) and S3 (p.13, given generally for wind over water/canal) state this same relation, so it is carried as one consolidated law here. (S2 p.36; S3 p.13)" },
          { k: "eq", expr: "1/7th power law:  Vg ∝ h^(1/7)", where: [["h", "height above the water/ground surface"]] },
          { k: "note", t: "S3 (p.18) separately names Dalton's basic formula as <b>E (mm/day) = C(ew − ea)</b>, labelling C a 'Runoff coefficient' — in this formula C plays the same role as K in S2's Dalton's-law statement (4.1) and Meyer's formula above: a water-body-size constant, not an actual runoff coefficient. The symbol/label differs across sources; the quantity it represents does not." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Meyer's formula Dalton's law (E = K(es−ea)) ka hi extended version hai — bas wind-speed ka effect explicitly [1 + Vg/16] term se add kar diya gaya hai, taaki sirf 'size of water body' wale K par depend na rahe. K ki do values (0.36 large/deep, 0.5 small/shallow) wahi 4.2 wala 'age/depth' factor capture karti hain — chhote/shallow water bodies deep/large wale se zyada easily evaporate karte hain, isliye unka K bada hai." },
          { k: "trap", t: "Vg specifically <b>9 m</b> height par measured hona chahiye Meyer's formula mein — agar wind-speed data kisi doosri height (jaise Penman's equation ka U2, 2m height — dekho 4.8) se le liya aur seedha Meyer's formula mein daal diya, to jawab galat aayega. 1/7th power law se height correction karo pehle. (S2 p.36)" },
        ],
      },

      /* ---------------------------------------------------------- 4.7 */
      {
        n: "4.7",
        title: "Methods to control (reduce) evaporation losses",
        hi: "वाष्पीकरण हानि नियंत्रण के उपाय",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.36–37; S3 p.15" },
          { k: "list", items: [
            "<b>Reduce surface area, increase depth:</b> a water body with a smaller exposed surface area and greater depth loses less to evaporation for the same stored volume. S3 phrases this as choosing a <b>cup-shaped</b> reservoir or canal section. (S2 p.36; S3 p.15)",
            "<b>Mechanical covers:</b> temporary or permanent roofs over the water surface, or floating covers made of light-weight floating particles, physically block the surface from the atmosphere and prevent evaporation loss. (S2 p.36)",
            "<b>Chemical (monomolecular) films:</b> certain chemicals form a film just <b>one molecule thick</b> (hence 'monomolecular') on the water surface, which suppresses evaporation. The two named are <b>cetyl alcohol</b> (hexadecanol, C16H33OH) and <b>stearyl alcohol</b> (octadecanol, C18H37OH) — S3 gives the same two chemicals (as 'Acetyl/Cetyl Alcohol' and 'Stearyl Alcohol') and additionally quotes a reduction of about <b>40%</b>. (S2 p.36; S3 p.15)",
          ] },
          { k: "def", term: "Properties required of the chemical film", t: "① Should be strong as well as flexible. ② If the film cracks (due to high-intensity rain, hail, or strong wave action), it should be replaced with a fresh film immediately. ③ Should be transparent to oxygen and CO₂ flow (so it doesn't choke the water body's gas exchange). ④ Should be colourless, odourless and non-toxic. (S2 p.37)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno control methods actually Section 4.2 ke factors ko hi reverse-engineer kar rahe hain: area/depth wala upaay seedha 'bada surface area = zyada evaporation' factor ko target karta hai; mechanical cover seedha surface ko atmosphere se isolate kar deta hai (vapour pressure gradient khatam); chemical film thickness ek molecule jitni hone ke bawjood evaporating molecules ke liye physical/energy barrier bana deta hai — gas exchange (O2, CO2) ko block nahi karta isliye aquatic life surviv kar sakti hai." },
        ],
      },

      /* ---------------------------------------------------------- 4.8 */
      {
        n: "4.8",
        title: "Transpiration and Evapotranspiration — PET vs AET, Lysimeter, field-plot method, Penman's equation",
        hi: "पत्र-वाष्पोत्सर्जन एवं वाष्पन-उत्सर्जन",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.47–49; S3 p.16–18" },
          { k: "def", term: "Transpiration", t: "The process by which water leaves the body of a living plant and reaches the atmosphere as water vapour. Water is taken up by the plant's root system and released through the leaves — described in the source via <b>cuticular transpiration</b> (through the leaf cuticle), <b>stomata transpiration</b> (through the stomata, small pores on the leaf surface) and <b>lenticular transpiration</b> (through lenticels on the stem). (S2 p.47)" },
          { k: "list", items: [
            "Transpiration is a <b>discontinuous</b> process — it occurs only during <b>daytime</b> (daylight hours). (S2 p.47; S3 p.16)",
            "The rate of transpiration depends on the rate of growth (age) of the plant/tree. (S3 p.16)",
            "Transpiration loss is measured by a <b>Phytometer</b>; evaporation loss is measured by an <b>Atmometer</b>. (S3 p.16)",
          ] },
          { k: "def", term: "Evapotranspiration (ET)", t: "The sum of water lost through transpiration by plants and evaporation from the soil or surrounding water bodies. Unlike transpiration, evapotranspiration is a <b>continuous</b> process that occurs in both day and night. Also called <b>consumptive use</b>, denoted Cu, and measured by a Lysimeter. (S2 p.47; S3 p.16)" },
          { k: "list", items: [
            "<b>Isopleths</b> — lines joining points on a map having equal depth of evapotranspiration. (S2 p.48)",
            "<b>PET (Potential Evapotranspiration):</b> the evapotranspiration that occurs when a sufficient (unlimited) quantity of water is available for plant growth — it then depends only on climatic factors. <b>AET (Actual Evapotranspiration):</b> the evapotranspiration that occurs when the water supply available to the plant is insufficient. (S2 p.47–48; S3 p.17)",
            "Case AET/PET &le; 1 &rArr; water supply to the plant is insufficient. Case AET/PET &ge; 1 &rArr; water supply is sufficient. (S3 p.17)",
            "In India, the highest recorded PET is about <b>240 cm/year</b>, at Rajkot (Gujarat); normally PET across India runs <b>140–180 cm/year</b>. (S3 p.17)",
          ] },
          { k: "def", term: "Lysimeter method", t: "A lysimeter is a special water-tight container holding a block of soil and silt, with plants grown in it identical to those in the surrounding field, and the soil/plant level inside the container kept the same as outside. The quantity of ET is estimated from the amount of water that must be added to maintain a constant moisture condition within the tank, measured either volumetrically or gravimetrically through an arrangement built into the lysimeter. Lysimeter studies are time-consuming and expensive. (S2 p.48)" },
          { k: "def", term: "Field-plot (water-budget) method", t: "Based on the conservation-of-mass principle — essentially an application of the water budget method (4.4) to a cropped field plot. Precipitation and irrigation input are the inflows; evapotranspiration, runoff and groundwater loss are the outflows, with any increase in soil-moisture storage (Sf − Si) also accounted for: (S2 p.48–49)" },
          { k: "eq", expr: "P + Irrigation input = Runoff + Groundwater loss + ET + ΔS   (ΔS = Sf − Si, change in soil storage)", where: [] },
          { k: "h", t: "★★★★ Penman's equation (for PET)" },
          { k: "p", t: "Penman's equation estimates PET by <b>combining</b> the energy-balance approach and the mass-transfer approach. (S2 p.49)" },
          { k: "eq", expr: "PET = (A·Hn + Ea·γ) / (A + γ)   [mm/day]", where: [
            ["PET", "daily potential evapotranspiration, mm/day"],
            ["A", "slope of the saturation-vapour-pressure vs temperature curve, at mean air temperature, mm of Hg per °C"],
            ["Hn", "net radiation, expressed as mm of evaporable water per day"],
            ["γ", "a constant, 0.49 mm of Hg per °C"],
            ["Ea", "a mass-transfer parameter combining wind velocity and saturation deficit"],
          ] },
          { k: "eq", expr: "Ea = 0.35(es − ea)[1 + U2/160]", where: [["U2", "wind velocity, km/day, at 2 m above ground level"]] },
          { k: "note", t: "S3 (p.18) separately attributes the development of evapotranspiration estimation to '<b>Mr. Penman & Mr. Blaney</b>' without giving a second formula. Penman's own combined equation is the one detailed above (S2 p.49); no Blaney(-Criddle)-type formula is given in either S2 or S3's covered pages for this chapter, so it is not reproduced here — only named, per S3's attribution." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Transpiration aur evaporation ka fundamental difference yaad rakho: transpiration <b>sirf din mein</b> hoti hai (stomata light mein khulte hain, photosynthesis ke saath-saath), evaporation <b>din-raat dono</b> mein ho sakti hai (koi biological 'switch' nahi hai). Isi wajah se evapotranspiration (dono ka sum) continuous process ban jaata hai. PET vs AET ka farak bhi simple hai — PET woh 'demand' hai jo plant lagayega <b>agar paani unlimited mile</b>; AET woh 'actual' hai jo mila paani allow karta hai. AET kabhi PET se zyada nahi ho sakta (AET/PET &le; 1 normal case hai), AET=PET (ratio=1) tabhi hota hai jab supply fully adequate ho." },
          { k: "trap", t: "Penman's equation ka U2 wind velocity <b>2m height</b> par hai (km/day mein), jabki Meyer's formula (4.6) ka Vg <b>9m height</b> par hai (km/hr mein) — dono formulas mein wind-speed data copy-paste mat karo, height aur unit dono alag hain; 1/7th power law se convert karna padega agar ek height ka data doosri formula mein use karna ho. (S2 p.36, 49)" },
        ],
      },

      /* ---------------------------------------------------------- 4.9 */
      {
        n: "4.9",
        title: "Quick revision — evaporation, transpiration and evapotranspiration",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Evaporation = sub-boiling-point surface cooling process (585 cal/gm); Dalton's law E = K(es−ea); Rh, dew point, wet bulb defined (S2 p.29–30).",
            "Factors: vapour pressure, temperature, wind speed (up to critical velocity Vc), atmospheric pressure, soluble salts (2–3% less from saline water), area and depth/age of water body (S2 p.30–31).",
            "Class-A pan (USA, GI sheet, uncovered) vs I.S. pan (copper, hexagonal-netting cover, 14.1% less than uncovered) — both 1210mm dia × 255mm deep (S2 p.31–32).",
            "Pan coefficient Cp: Reservoir evap = Cp × Pan evap; Class-A avg 0.70, I.S. avg 0.80 — S2 and S3 agree; the ~14% USA-vs-IS derivation (S3 p.13–14) is a different quantity from the pan's own 14.1% netting-cover effect (S2 p.32).",
            "Water Budget method: I = Q ± ΔS, full equation P+Vis+Vig = E+Vos+Vog+TL+ΔS (S2 p.33–34).",
            "Energy Budget method: Hn=(1−γ)Hc−Hb; Bowen's ratio β=Ha/HE; E = (Hn−Hg−Hs−Hi)/[ρL(β+1)] (S2 p.35).",
            "Mass Transfer method / Meyer's formula: E=K(es−ea)[1+Vg/16], K=0.36 (large/deep) or 0.5 (small/shallow), Vg at 9m; 1/7th power law Vg∝h^(1/7) (S2 p.36; S3 p.13).",
            "Evaporation control: reduce area/increase depth, mechanical covers, monomolecular chemical films (cetyl & stearyl alcohol, ~40% reduction per S3) (S2 p.36–37; S3 p.15).",
            "Transpiration (daytime only, Phytometer) vs Evapotranspiration (day+night, Lysimeter/Atmometer); PET (unlimited water) vs AET (limited), AET/PET ≤ 1 or ≥ 1; Lysimeter and field-plot methods; Penman's equation for PET (S2 p.47–49; S3 p.16–18).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Reservoir evap = Cp × Pan evap — Cp ≈ 0.70 (Class-A/USA) and ≈ 0.80 (I.S.), confirmed by both S2 and S3; keep the netting-cover 14.1% (S2) separate from the USA-vs-IS ~14% derivation (S3).",
            "Energy budget's E formula and Meyer's mass-transfer formula both ultimately isolate E from a balance equation — one balances heat, the other balances vapour mass with an empirical wind term.",
            "AET ≤ PET always; the ratio AET/PET tells you whether the water supply to a plant is adequate (≥1) or deficient (≤1).",
            "Penman's equation uniquely combines the energy-budget and mass-transfer approaches into one PET formula — note its U2 is at 2m, not the 9m used by Meyer's Vg.",
          ] },
        ],
      },

    ],
  });
})();
