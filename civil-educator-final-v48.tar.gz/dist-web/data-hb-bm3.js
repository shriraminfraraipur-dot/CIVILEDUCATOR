/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING MATERIALS · Chapters 6–8
   Aggregate, sand, water & admixtures · Timber & metals ·
   Mortar, plaster & finishes
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bm");
  if (!hb) { console.error("[bm3] handbook bm not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "bm-6",
      n: 6,
      title: "Aggregate, Sand, Water and Admixtures",
      hi: "गिट्टी, रेत, पानी और एडमिक्सचर",
      blurb: "The three-quarters of concrete that is not cement — why grading matters more than any single size, what fineness modulus tells you, why silt and salt are the enemies, and what an admixture buys.",
      mins: 24,
      sections: [
        {
          n: "6.1",
          title: "Aggregate is most of the concrete",
          hi: "गिट्टी ही अधिकांश कंक्रीट है",
          blocks: [
            { k: "p", t: "By volume, aggregate — coarse (gravel, crushed stone) and fine (sand) — is roughly three-quarters of concrete. The cement paste only glues it together. So the aggregate's strength, cleanliness and grading decide most of what the concrete becomes, and cheap, dirty aggregate cannot be rescued by good cement." },
            { k: "def", term: "Grading", t: "The distribution of particle sizes. A well-graded aggregate has a spread of sizes, so the small particles fill the gaps between the large ones. That leaves less void space for cement paste to fill — less cement, less water, and a denser, stronger concrete." },
            { k: "dia", id: "hb-bm-sieve", cap: "The sieve stack and fineness modulus — one number for how coarse a sand is." },
            { k: "eg", title: "Example 6.1 — Fineness modulus of a sand",
              given: "A sand is sieved. The cumulative percentage retained on the standard sieves (4.75, 2.36, 1.18 mm, 600, 300, 150 µm) is 0, 10, 30, 55, 80, 95. Find the fineness modulus and classify the sand.",
              steps: [
                { t: "Add the cumulative % retained", w: "0 + 10 + 30 + 55 + 80 + 95 = 270" },
                { t: "Divide by 100", w: "FM = 270 / 100 = 2.70" },
                { t: "Classify", w: "2.6 – 2.9 → MEDIUM sand" },
              ],
              ans: "FM = 2.70, a medium sand. A higher FM would be coarser (more retained high in the stack) and would need less water and paste; a lower FM would be finer. Remember FM summarises grading — it is not a particle size." },
          ],
        },
        {
          n: "6.2",
          title: "The enemies: silt, clay and salt",
          hi: "दुश्मन — गाद, मिट्टी और नमक",
          blocks: [
            { k: "p", t: "Fine aggregate fails not usually on grading but on contamination. Three things spoil a sand, and each has a simple check." },
            { k: "cmp", t: "What ruins a sand, and how you catch it",
              cols: ["The problem", "The check"],
              rows: [
                ["Silt / clay", "coats grains, cement can't bond → weak", "field silt test: settle in a jar, silt ≤ ~8%"],
                ["Organic matter", "delays and weakens the set", "colour test with caustic soda"],
                ["Salt (sea sand)", "rusts the reinforcement, causes efflorescence", "wash it; test for chlorides"],
              ] },
            { k: "def", term: "Field silt test", t: "Shake sand with water in a measuring jar and let it settle. Sand sinks first; silt and clay settle as a distinct layer on top. If that layer is more than about 8% of the sand depth, the sand needs washing before use." },
            { k: "trap", t: "Sea sand is free and everywhere on a coast, and it will quietly destroy a reinforced structure. Its salt draws moisture and drives chloride to the steel, which rusts, expands and cracks the concrete off from inside. Unwashed sea sand in RCC is one of the classic causes of premature failure." },
          ],
        },
        {
          n: "6.3",
          title: "Water, and the admixtures that bend the rules",
          hi: "पानी और एडमिक्सचर",
          blocks: [
            { k: "p", t: "The rule for mixing water is short: if it is fit to drink, it is fit for concrete. Water carries the hydration reaction and must be free of oils, acids, salts and organic matter. Sea water is not used in reinforced concrete for the same chloride reason as sea sand." },
            { k: "def", term: "Admixture", t: "A material added in small quantity to change one property of fresh or hardening concrete — flow, set time, strength, durability — without redesigning the mix. It is a fine adjustment, not a substitute for a sound mix." },
            { k: "cmp", t: "The admixtures you will actually meet",
              cols: ["What it does", "Why you'd use it"],
              rows: [
                ["Plasticiser", "more flow at the same water", "workable concrete without adding water"],
                ["Superplasticiser", "big flow gain / big water cut", "high-strength, low-water mixes"],
                ["Retarder", "slows the set", "hot weather, long hauls, big pours"],
                ["Accelerator", "speeds the set", "cold weather, urgent strength"],
                ["Air-entrainer", "tiny air bubbles", "frost resistance"],
              ] },
            { k: "real", t: "The superplasticiser is what makes modern high-strength concrete possible. Strength comes from a low water-cement ratio, but low water means unworkable concrete — you cannot place it. A superplasticiser gives the flow back without the water, so you get both the strength and the workability. <strong>It is the admixture that broke the old trade-off.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "bm-7",
      n: 7,
      title: "Timber and Metals",
      hi: "लकड़ी और धातुएँ",
      blurb: "Why timber is strong along the grain and must be seasoned, how steel and iron differ, and why corrosion is the one property that decides most metal choices in construction.",
      mins: 22,
      sections: [
        {
          n: "7.1",
          title: "Timber — a bundle of straws",
          hi: "लकड़ी",
          blocks: [
            { k: "p", t: "Timber is millions of hollow cellulose tubes glued together, running the length of the tree. Everything about its behaviour follows from that: it is strong and stiff along the grain, weak and splitting across it, and it moves with moisture because the tubes swell and shrink." },
            { k: "dia", id: "hb-bm-timber", cap: "Inside a log — and why direction is everything for timber." },
            { k: "def", term: "Seasoning", t: "Drying timber to a moisture content near what it will meet in service (~12% for indoor use). Green timber is roughly half water; if that water leaves after the piece is in place, it shrinks, warps, checks and invites decay. Seasoning removes the water first, slowly and evenly." },
            { k: "def", term: "Defects", t: "Knots (where branches were), shakes (splits along the grain), and warp (twisting on drying). Each is a plane of weakness or a distortion, and grading rules limit how many a structural piece may carry." },
            { k: "trap", t: "A joint that pulls timber apart across the grain is a joint waiting to split. Timber is designed to be loaded along the grain in tension and compression; across the grain it has almost no tensile strength. Good joinery always works the wood in its strong direction." },
          ],
        },
        {
          n: "7.2",
          title: "Iron and steel — the same element, different carbon",
          hi: "लोहा और स्टील",
          blocks: [
            { k: "p", t: "Iron and steel differ mainly in carbon content, and that small difference decides everything about how they behave and where they are used." },
            { k: "cmp", t: "Cast iron, wrought iron, steel",
              cols: ["Strong in", "Character"],
              rows: [
                ["Cast iron (high carbon)", "compression", "hard, brittle, cheap — columns, pipes"],
                ["Wrought iron (very low carbon)", "tension", "tough, ductile, rust-resistant — old work"],
                ["Mild steel (moderate carbon)", "tension & compression", "strong, ductile, weldable — the structural metal"],
              ] },
            { k: "p", t: "Mild steel is the structural metal because it is strong in both tension and compression, ductile enough to warn before it fails, and weldable. High-carbon steels are harder and stronger but more brittle — good for tools, not for beams that must bend before they break." },
            { k: "note", t: "Ductility is a safety property, not just a number. A ductile steel beam sags visibly and loudly before it fails, giving warning and time. A brittle material — cast iron, glass, over-burnt brick — fails suddenly with no warning. Structural design leans on steel's ductility precisely for that warning." },
          ],
        },
        {
          n: "7.3",
          title: "Corrosion — the property that decides the metal",
          hi: "जंग",
          blocks: [
            { k: "p", t: "For most construction metals, the deciding question is not strength but corrosion — how the metal survives water and air over decades. Steel is strong and cheap but rusts; the whole art is keeping the water and oxygen away from it." },
            { k: "cmp", t: "How the common protections work",
              cols: ["Method", "How it protects"],
              rows: [
                ["Galvanising", "zinc coat", "zinc corrodes first, sacrificially — protects even a scratch"],
                ["Painting", "barrier coat", "keeps water and air off — fails where it chips"],
                ["Cover in RCC", "alkaline concrete", "the concrete's alkalinity passivates the steel"],
                ["Stainless / weathering steel", "alloying", "forms its own stable protective film"],
              ] },
            { k: "real", t: "In reinforced concrete the steel is protected by the concrete around it — the alkaline environment forms a passive film on the bar. That is why cover (the depth of concrete over the steel) is a durability requirement, not just a placement detail: lose the cover, or let chloride or carbonation reach the bar, and it rusts, expands and spalls the concrete. <strong>Corrosion of reinforcement is the number-one durability failure of RCC.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "bm-8",
      n: 8,
      title: "Mortar, Plaster and Finishes",
      hi: "मसाला, प्लास्टर और फिनिश",
      blurb: "What holds a wall together and what covers it — mortar as the flexible partner to the brick, plaster as the sacrificial skin, and the finishes that keep water out and light in.",
      mins: 20,
      sections: [
        {
          n: "8.1",
          title: "Mortar — deliberately weaker than the brick",
          hi: "मसाला — ईंट से कमज़ोर, जानबूझकर",
          blocks: [
            { k: "p", t: "Mortar binds masonry units into a wall, spreads the load between them, and seals the gaps. The counter-intuitive rule is that mortar should be weaker than the units it joins — because a wall must be able to move a little, and it is far better that fine cracks run through the cheap, repairable mortar joints than through the bricks themselves." },
            { k: "cmp", t: "The three mortars",
              cols: ["Made of", "Character"],
              rows: [
                ["Cement mortar", "cement + sand", "strong, sets fast & anywhere — structural masonry"],
                ["Lime mortar", "lime + sand", "weak, workable, breathable — traditional, self-healing"],
                ["Gauged mortar", "cement + lime + sand", "the compromise — workability of lime, strength of cement"],
              ] },
            { k: "trap", t: "A mortar stronger than the brick moves the problem, it does not solve it. When the wall moves, a rigid strong joint forces the crack through the brick instead of the joint — and a cracked brick cannot be raked out and repointed, but a cracked joint can. Match the mortar to the brick; do not overpower it." },
          ],
        },
        {
          n: "8.2",
          title: "Plaster and pointing — the sacrificial skin",
          hi: "प्लास्टर और पॉइंटिंग",
          blocks: [
            { k: "p", t: "Plaster is a thin coat over masonry that gives a smooth surface, evens out the wall, and — most importantly — takes the weathering so the wall behind it does not. It is meant to be renewed; it is the skin, not the structure." },
            { k: "def", term: "Plaster", t: "A cement/lime-sand coat, usually 12–20 mm, applied in one or more coats over the full wall face. It protects the masonry from rain and abrasion and provides the base for paint." },
            { k: "def", term: "Pointing", t: "Finishing just the mortar joints of exposed (fair-faced) masonry, rather than covering the whole wall. Used where the brick or stone itself is meant to show. The joint is raked out and refilled with a weather-shedding profile." },
            { k: "real", t: "External plaster cracking and falling is usually the plaster doing its job — taking the movement and weather that would otherwise have attacked the wall. That is why it is specified as a renewable finish: you re-plaster a face every few decades, but you do not rebuild the wall." },
          ],
        },
        {
          n: "8.3",
          title: "Glass, tiles, paint and waterproofing",
          hi: "काँच, टाइल्स, पेंट और वॉटरप्रूफिंग",
          blocks: [
            { k: "p", t: "The finishing materials each answer a specific service demand rather than a structural one — light, wear, weather, appearance — and they are chosen the same way as everything else: by matching the material's profile to the job." },
            { k: "list", items: [
              "<strong>Glass</strong> — lets light in and weather out. Toughened glass is heat-treated to break into blunt granules, not shards; laminated glass holds together on a plastic interlayer. Both are safety choices, not strength choices.",
              "<strong>Tiles</strong> — a hard, low-absorption, wear-resistant, cleanable skin for floors and wet areas. Vitrified tiles are fired dense enough to barely absorb water; ceramic tiles absorb more and suit walls better than heavy floors.",
              "<strong>Paint</strong> — decoration and a protective barrier. On steel it keeps water off; on plaster it sheds dirt and rain. It is a maintenance layer, renewed on a cycle.",
              "<strong>Waterproofing</strong> — membranes, integral admixtures and coatings that keep water out of roofs, basements and wet areas. The most cost-effective durability spend on a building, because water is the root of most decay.",
            ] },
            { k: "note", t: "The thread that ties the whole handbook together shows here: none of these is chosen for strength. They are chosen for durability and service — resisting water, wear and weather — which, for a finished building, is what decides whether it ages well or badly. Strength gets the building standing; the finishes decide how long it stays good." },
          ],
        },
      ],
    },

  );
})();
