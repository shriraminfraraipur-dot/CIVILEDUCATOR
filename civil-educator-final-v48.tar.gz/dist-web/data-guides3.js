/* ============================================================
   CIVIL EDUCATOR — Code guides, part 3
   Testing, estimation, fire safety, lime, timber, stone,
   bitumen tests, finishes, glass, tiles, gypsum, waterproofing.
   Our own plain-language explanations — not code text.
   ============================================================ */

window.DB = window.DB || {};
DB.guides = DB.guides || {};

Object.assign(DB.guides, {

  /* ---------------------------------------------- TESTING */
  is3495: {
    what: "The four test methods that decide whether a burnt clay brick is acceptable — compressive strength, water absorption, efflorescence and dimensional tolerance. Between them they answer the only questions that matter about a brick: is it strong enough, will it drink the mortar dry, will it stain the finished wall with salt, and is it the size it claims to be.",
    use: "Accepting a brick delivery, and settling an argument about a consignment.",
    inside: [
      "Part 1 — compressive strength on a brick bedded and soaked as the method directs",
      "Part 2 — water absorption by 24-hour immersion in cold water",
      "Part 3 — efflorescence, by standing the brick in water and observing the salt deposit",
      "Part 4 — warpage, measured with a straight edge and a steel rule",
      "Sampling — how many bricks from a lot, and how acceptance is judged",
    ],
    key: [
      ["Water absorption", "Not more than 20% by mass for common burnt clay bricks of the lower classes"],
      ["Efflorescence", "Reported as nil, slight, moderate, heavy or serious; anything above slight is trouble on a finished wall"],
      ["Strength classes", "Bricks are designated by their average compressive strength — 3.5, 5, 7.5, 10 N/mm² and upwards"],
    ],
    watch: [
      "A brick that absorbs too much water pulls the mixing water out of the mortar before the cement can hydrate — which is exactly why bricks are soaked before laying.",
      "Efflorescence shows up weeks after the wall is painted, not on the day the bricks arrive. Test it, do not eyeball it.",
    ],
  },

  is5816: {
    what: "The split cylinder test for the tensile strength of concrete. Concrete cannot be gripped and pulled in direct tension without the grips failing first, so a cylinder is laid on its side and loaded along a line until it splits down the vertical diameter. The tensile strength follows from the load and the cylinder dimensions.",
    use: "Measuring the tensile strength needed for pavement design, for crack width calculation, and wherever the tensile capacity of concrete has to be established rather than assumed.",
    inside: [
      "Specimen — a standard cylinder, cast and cured as for compression testing",
      "Packing strips and the loading arrangement that produces a uniform line load",
      "Rate of loading and the mode of failure looked for",
      "Calculation of the splitting tensile strength from the failure load",
    ],
    key: [
      ["Formula", "fct = 2P / (π L D), with P the failure load, L the length and D the diameter"],
      ["Typical value", "Roughly a tenth of the compressive strength, and it rises much more slowly than compressive strength does"],
      ["IS 456 estimate", "The flexural tensile strength in Cl. 6.2.2 is taken as 0.7 √fck — a different property from the split tensile strength"],
    ],
    watch: [
      "Split tensile, flexural (modulus of rupture) and direct tensile strength are three different numbers for the same concrete. Do not interchange them.",
      "The packing strips are part of the method. Without them the load concentrates and the cylinder crushes locally instead of splitting.",
    ],
  },

  is1608: {
    what: "The tensile test for metals at room temperature — the test that produces the stress-strain curve, the yield stress, the ultimate tensile strength and the percentage elongation on every steel test certificate. For reinforcement and structural steel it is the test that decides whether the material is the grade it is sold as.",
    use: "Testing reinforcement bars against IS 1786, structural steel against IS 2062, and any metal component whose strength is specified.",
    inside: [
      "Test pieces — machined and unmachined, and the gauge length used",
      "Rate of straining and the testing machine requirements",
      "Determination of yield strength, including the proof stress method where there is no distinct yield point",
      "Ultimate tensile strength and percentage elongation after fracture",
      "Reduction of area, and reporting requirements",
    ],
    key: [
      ["Gauge length", "Proportional gauge length of 5.65 √So, where So is the original cross-sectional area"],
      ["Proof stress", "For steels with no sharp yield point, the stress at a stated permanent strain — typically 0.2%"],
      ["What a certificate shows", "fy, fu, percentage elongation, and for reinforcement the fu/fy ratio"],
    ],
    watch: [
      "Percentage elongation depends on the gauge length used, so a number quoted without its gauge length is meaningless.",
      "High strength deformed bars have no sharp yield point — their 'yield' is a proof stress, which is why IS 1786 specifies it that way.",
    ],
  },

  is1203: {
    what: "The penetration test for bitumen — a standard needle under a standard weight is allowed to sink into a bitumen sample for a standard time at a standard temperature, and the depth it reaches, in tenths of a millimetre, is the penetration value. It is the oldest measure of bitumen consistency and the one the old grade names came from.",
    use: "Checking the consistency of a bitumen sample, and reading older specifications written in penetration grades.",
    inside: [
      "Apparatus — penetrometer, needle, sample container and water bath",
      "Sample preparation, conditioning and temperature control",
      "Test conditions — needle load, duration and temperature",
      "Reporting — the mean of several determinations, in units of 0.1 mm",
    ],
    key: [
      ["Standard conditions", "100 g load, 5 seconds, 25 °C"],
      ["Unit", "One penetration unit is 0.1 mm"],
      ["Interpretation", "Higher penetration means softer bitumen"],
    ],
    watch: [
      "Indian paving bitumen is now graded by viscosity (VG grades in IS 73), not by penetration. Penetration is still measured, but it is no longer the grading basis.",
      "Temperature control is everything. A degree or two off and the result is out by several penetration units.",
    ],
  },

  is650: {
    what: "The specification for the standard sand used to test cement. Cement strength is measured on a mortar, and a mortar made with ordinary sand would tell you as much about the sand as about the cement — so the test uses a sand of fixed, certified grading, traditionally from Ennore, supplied in separate size fractions that are combined in fixed proportions.",
    use: "Any laboratory testing cement compressive strength, and any dispute about a cement test result.",
    inside: [
      "Source, composition and purity requirements for the sand",
      "Grading — separate size fractions supplied and blended in fixed proportion",
      "Packing and marking",
    ],
    key: [
      ["Purpose", "To remove the sand as a variable so that the test measures the cement alone"],
      ["Grades", "Supplied in separate size fractions, combined in the proportion the cement test method prescribes"],
      ["Used by", "IS 4031 — the methods of physical tests for hydraulic cement"],
    ],
    watch: [
      "A cement strength result obtained with ordinary sand is not comparable with a standard result and cannot be used for acceptance.",
      "Standard sand is expensive and is sometimes reused. It should not be — the grading changes.",
    ],
  },

  "is1121-1": {
    what: "The method for determining the compressive strength of natural building stone. Cubes or cylinders cut from the stone are tested in both the dry and the saturated condition, because the strength of many stones falls appreciably when they are wet, and a foundation or a retaining wall stone is wet for much of its life.",
    use: "Assessing stone for masonry, for facing and for foundations, and comparing quarries.",
    inside: [
      "Preparation of specimens — size, cutting and surface finish",
      "Conditioning — dry specimens and saturated specimens",
      "Rate of loading and the direction of loading relative to the bedding plane",
      "Calculation and reporting of results",
    ],
    key: [
      ["Two conditions", "Dry and saturated — the saturated value is the one that governs for wet locations"],
      ["Bedding plane", "Sedimentary stone is much weaker across the bed than along it, so the loading direction must be recorded"],
      ["Typical range", "Granite and basalt are very strong; sandstone and limestone vary enormously by quarry"],
    ],
    watch: [
      "A stone strength quoted without saying whether it was dry or saturated, and in which direction relative to bedding, is not usable.",
      "Stone is a natural material — results from one quarry do not transfer to another of the same rock name.",
    ],
  },

  is1124: {
    what: "The method for determining the water absorption, apparent specific gravity and porosity of natural building stone. These three numbers, taken together, are the best single indicator of how durable a stone will be — a stone that takes up a lot of water is a stone that will suffer from frost, from salt crystallisation and from staining.",
    use: "Selecting stone for external facing, for damp locations and for foundations.",
    inside: [
      "Preparation and drying of specimens to constant mass",
      "Immersion procedure and the saturated surface dry condition",
      "Determination of saturated mass and suspended mass",
      "Calculation of water absorption, apparent specific gravity, porosity and the saturation coefficient",
    ],
    key: [
      ["Water absorption", "The percentage gain in mass on immersion — the headline durability indicator"],
      ["Porosity", "The volume of pore space as a percentage of the total volume"],
      ["Rule of thumb", "Low absorption means a dense, durable stone; high absorption means trouble in exposed work"],
    ],
    watch: [
      "Absorption is not the same as permeability. A stone can have many pores that do not connect, and it will then absorb little.",
      "For external cladding, absorption governs staining and frost damage far more than strength does.",
    ],
  },

  is1122: {
    what: "The method for determining the true specific gravity of natural building stone — the specific gravity of the solid material itself, with the pore space excluded, obtained by grinding the stone to a powder. Compared against the apparent specific gravity from IS 1124, it gives the porosity.",
    use: "Characterising a stone in the laboratory, and computing porosity from the pair of values.",
    inside: [
      "Grinding and sieving the sample to the required fineness",
      "Determination using a specific gravity bottle or pycnometer",
      "Temperature correction and calculation",
    ],
    key: [
      ["True specific gravity", "Of the solid material only, pores excluded"],
      ["Apparent specific gravity", "Of the stone as it stands, pores included — from IS 1124"],
      ["Porosity", "Follows from the difference between the two"],
    ],
    watch: [
      "The powder must be fine enough that no sealed pores remain, or the result is not a true specific gravity at all.",
      "This value alone tells you little about performance; it is useful in combination with absorption and porosity.",
    ],
  },

  is1205: {
    what: "The ring and ball test for the softening point of bitumen. Bitumen has no melting point — it softens gradually — so the test defines one: a steel ball rests on a bitumen disc in a ring, the bath is heated at a controlled rate, and the temperature at which the softening bitumen sags a fixed distance is recorded.",
    use: "Checking the temperature susceptibility of a bitumen, and assessing whether it will flow or bleed in service in hot climates.",
    inside: [
      "Apparatus — rings, steel balls, ball guides, bath and thermometer",
      "Preparation and conditioning of the bitumen discs",
      "Heating rate and the end point observed",
      "Reporting as the mean of two determinations",
    ],
    key: [
      ["End point", "When the softening bitumen, carrying the ball, touches the plate a fixed distance below the ring"],
      ["What it indicates", "Resistance to flow at high service temperature"],
      ["With penetration", "Softening point and penetration together describe the temperature susceptibility of the binder"],
    ],
    watch: [
      "The heating rate is part of the method. Heat faster and you get a higher softening point that means nothing.",
      "A low softening point in an Indian summer means bleeding and rutting — this test is more relevant here than in temperate countries.",
    ],
  },

  is1208: {
    what: "The ductility test for bitumen. A briquette of bitumen of standard shape is pulled apart at a standard rate in a water bath at a standard temperature, and the length in centimetres to which it stretches before the thread breaks is the ductility. It is a direct measure of whether the binder can deform with the pavement instead of cracking.",
    use: "Assessing a paving bitumen, and detecting a binder that has aged or been overheated.",
    inside: [
      "Briquette mould, water bath and testing machine",
      "Sample preparation, pouring, trimming and conditioning",
      "Test temperature and rate of pull",
      "Measurement of the distance at which the thread breaks",
    ],
    key: [
      ["Standard conditions", "27 °C, pulled at 50 mm per minute"],
      ["Unit", "Centimetres of elongation before the thread snaps"],
      ["What low ductility means", "A brittle binder that will crack rather than flex"],
    ],
    watch: [
      "Ductility falls sharply when bitumen is overheated in the boiler — this test is the easiest way to catch that on site.",
      "The specific gravity of the bath water must be adjusted so the thread neither sinks nor floats, or the result is wrong.",
    ],
  },

  is1206: {
    what: "The methods for determining the viscosity of bitumen and tar. Viscosity is resistance to flow, and it is the property that matters most because it governs both how the binder behaves in the mixer and the paver, and how it behaves on the road in summer. Indian paving bitumen is now graded on it.",
    use: "Grading bitumen to IS 73, setting mixing and compaction temperatures, and checking a binder on receipt.",
    inside: [
      "Part 1 — industrial viscosity by efflux through an orifice",
      "Part 2 — absolute viscosity, measured with a vacuum capillary viscometer",
      "Part 3 — kinematic viscosity, measured with a capillary viscometer",
      "Test temperatures, apparatus and calibration",
    ],
    key: [
      ["Absolute viscosity", "Measured at 60 °C — close to the hottest pavement service temperature, which is why it is the grading basis"],
      ["Kinematic viscosity", "Measured at 135 °C — close to mixing and laying temperature"],
      ["Grading", "VG 10 to VG 40 in IS 73 are defined on absolute viscosity at 60 °C"],
    ],
    watch: [
      "Mixing and compaction temperatures should come from the viscosity-temperature relationship of the actual binder, not from a fixed number carried over from another job.",
      "Viscosity rises as bitumen ages; a binder stored hot for days is not the binder that was delivered.",
    ],
  },

  is6932: {
    what: "The family of test methods for building limes — one part per property. Lime is a variable natural product, and these tests are what turn a delivery into a classified material: how much of it is actually reactive, how fast it slakes, how fine it is, how much it expands, and what strength a lime mortar develops.",
    use: "Classifying a lime against IS 712, and checking a delivery before it goes into mortar or plaster.",
    inside: [
      "Determination of free lime content and of insoluble residue",
      "Fineness by sieving",
      "Residue on slaking, and the slaking characteristics of quicklime",
      "Soundness, workability and setting time",
      "Compressive and transverse strength of lime mortar",
      "Volume yield of quicklime on slaking",
    ],
    key: [
      ["Reactive content", "The free lime is the part that actually works; the rest is residue"],
      ["Volume yield", "How much putty a given mass of quicklime produces — a direct commercial measure"],
      ["Strength tests", "Run on a lime mortar, over a much longer period than cement, because lime gains strength slowly"],
    ],
    watch: [
      "Quicklime absorbs moisture and carbon dioxide from the air and dies in storage. A sample tested a month after delivery is not the material that was delivered.",
      "Lime strength develops over months, not days. Judging a lime mortar at 28 days understates it.",
    ],
  },

  is13630: {
    what: "The family of test methods for ceramic tiles — one part per property. A tile is judged on dimensions and surface quality, on water absorption, on strength, on how well the glaze resists wear and chemicals, and on slip resistance, and each of those has its own part here.",
    use: "Accepting a tile consignment against IS 15622, and choosing a tile for a particular location on evidence rather than appearance.",
    inside: [
      "Dimensions and surface quality — length, width, thickness, straightness, warpage and visual defects",
      "Water absorption, which is what classifies the tile",
      "Modulus of rupture and breaking strength",
      "Resistance to deep abrasion for unglazed tiles and surface abrasion for glazed tiles",
      "Chemical resistance, stain resistance and crazing resistance",
      "Coefficient of friction, thermal shock and frost resistance",
    ],
    key: [
      ["Water absorption", "The single property that decides the tile class and where it may be used"],
      ["Abrasion resistance", "Graded in classes; a wall tile glaze will not survive a floor"],
      ["Slip resistance", "The property to insist on for bathrooms, kitchens, ramps and external paving"],
    ],
    watch: [
      "Wall tile and floor tile are not interchangeable. A wall tile laid on a floor wears through its glaze within months.",
      "Rectified tiles have tight dimensional tolerances and need narrow joints; ordinary tiles do not and must not be laid the same way.",
    ],
  },

  /* ---------------------------------------------- ESTIMATION */
  "is1200-3": {
    what: "The measurement rules for brickwork — what is measured, in what unit, what is deducted and what is deemed included in the rate. Brickwork is usually measured in cubic metres for walls of more than half brick thickness and in square metres for half brick and thinner walls, and the deduction rules for openings are where most billing disputes arise.",
    use: "Preparing a bill of quantities, checking a running bill, and settling a measurement dispute on masonry.",
    inside: [
      "Classification of brickwork by thickness, by mortar and by situation",
      "Units of measurement for walls, arches, copings and thin partitions",
      "Deductions for openings, bearings of lintels and slabs, and embedded members",
      "Items deemed to be included in the rate — scaffolding, raking out joints, curing",
      "Measurement of brickwork in different positions and heights",
    ],
    key: [
      ["Thick walls", "Measured in cubic metres"],
      ["Half brick and thinner", "Measured in square metres, stating the thickness"],
      ["Small openings", "Openings below a stated area are generally not deducted — the extra work at the jamb offsets the volume saved"],
    ],
    watch: [
      "The 'no deduction below a stated area' rule is the single most argued clause in building measurement. Read it before pricing, not after.",
      "Measurement rules do not change the work — they change who pays for what. That is why they are contractual, not technical.",
    ],
  },

  "is1200-4": {
    what: "The measurement rules for stone masonry — random rubble, coursed rubble, ashlar and stone facing. Stone masonry is measured by volume for walls and by area for facing and veneer, with the classification stating the type of stone, the dressing and the mortar.",
    use: "Billing stone masonry in foundations, retaining walls, compound walls and facing work.",
    inside: [
      "Classification by type of masonry, dressing of stone and mortar",
      "Units of measurement for walls, facing, copings, string courses and quoins",
      "Deductions for openings and embedded items",
      "Items deemed included in the rate",
    ],
    key: [
      ["Walls", "Measured in cubic metres, classified by masonry type and dressing"],
      ["Facing and veneer", "Measured in square metres, stating the thickness"],
      ["Dressing", "A large part of the cost, so it must be stated in the item description"],
    ],
    watch: [
      "The dressing of the stone can cost more than the stone. An item that does not describe the dressing is an item that will be disputed.",
      "Through stones and bond stones are structural requirements, not extras — check they are covered in the item description.",
    ],
  },

  "is1200-5": {
    what: "The measurement rules for formwork — the temporary mould that shapes concrete. Formwork is measured by the area actually in contact with the concrete, which makes it independent of how many times the contractor reuses a panel, and classified by the element it supports and by the height of propping.",
    use: "Billing formwork, which on a framed building is a substantial part of the concrete cost.",
    inside: [
      "Measurement by the area of surface in contact with the concrete",
      "Classification by element — foundations, columns, walls, beams, slabs, stairs, arches",
      "Height of propping and the stages at which extra payment applies",
      "Special formwork — curved, circular, and exposed or architectural finishes",
      "Items deemed included — props, ties, bracing, release agent, cleaning and removal",
    ],
    key: [
      ["Measured as", "Contact area with the concrete, in square metres"],
      ["Not affected by", "The number of times the formwork is reused — that is the contractor's economics"],
      ["Height", "Extra propping height is a separate consideration in the classification"],
    ],
    watch: [
      "Edges of slabs, soffits of beams and the sides of columns are all separate contact areas; missing them understates formwork significantly.",
      "Formwork for an exposed architectural finish is a different item from ordinary formwork and costs far more.",
    ],
  },

  "is1200-11": {
    what: "The measurement rules for paving, floor finishes, dado and skirting. These finishes are measured in area, with the classification stating the material, the thickness, the bedding and the finish, and with separate items for skirting and dado, which are measured in area or in length depending on their height.",
    use: "Billing tiling, terrazzo, stone flooring, cement concrete flooring, skirting and dado.",
    inside: [
      "Units for floor finishes, paving, dado and skirting",
      "Classification by material, thickness, bedding mortar and surface finish",
      "Deductions for openings, columns and projections",
      "Measurement of borders, margins, treads and risers",
      "Items deemed included in the rate",
    ],
    key: [
      ["Floor finishes", "Measured in square metres of finished surface"],
      ["Skirting and dado", "Measured separately, classified by height"],
      ["Bedding", "Stated in the item — the bed is often a bigger cost than the tile"],
    ],
    watch: [
      "Wastage on tile cutting at borders and around obstructions is real and is not measured — it must be in the rate.",
      "Treads, risers and nosings are separate items; lumping them into floor area understates a staircase badly.",
    ],
  },

  "is1200-12": {
    what: "The measurement rules for plastering and pointing — measured by area of the finished surface, classified by the thickness of the coat, the mortar, the number of coats and the surface plastered. The deduction rules for openings are the part that causes disagreement.",
    use: "Billing internal and external plaster, pointing to masonry, and rendering.",
    inside: [
      "Units and classification for plaster — thickness, mortar mix, number of coats, surface",
      "Pointing to brickwork and stone masonry, classified by type of pointing",
      "Deductions for openings, and the treatment of jambs, soffits and reveals",
      "Plaster on curved, moulded and narrow surfaces",
      "Items deemed included in the rate",
    ],
    key: [
      ["Measured as", "Square metres of finished plastered surface"],
      ["Classification", "Thickness, mortar mix and number of coats must all appear in the item"],
      ["Openings", "Deduction rules depend on the size of the opening and on whether the jambs are plastered"],
    ],
    watch: [
      "Where an opening is not deducted, the plaster to the jambs and soffit is usually not paid separately — check which convention the contract uses.",
      "External plaster on a tall elevation carries scaffolding cost that internal plaster does not; the classification should reflect it.",
    ],
  },

  is3861: {
    what: "The standard method of measuring the plinth, carpet and rentable area of a building — the three numbers behind every property transaction and every rent calculation in India. It defines exactly what is inside each area and what is excluded, which is the only way two parties can agree on what a square metre means.",
    use: "Property documentation, rent and lease calculation, municipal approvals and any area statement on a drawing.",
    inside: [
      "Plinth area — the built-up area measured at floor level, including walls",
      "Carpet area — the usable floor area within the walls, excluding specified items",
      "Rentable area and its relationship to the other two",
      "What is included and excluded from each — walls, balconies, shafts, staircases, lifts and services",
      "Rules for covered, semi-covered and open areas",
    ],
    key: [
      ["Plinth area", "Measured on the outer face of the external walls, at floor level"],
      ["Carpet area", "The area you can actually lay a carpet on — walls, shafts and staircases excluded"],
      ["Carpet is always smallest", "Carpet < built-up < super built-up, always"],
    ],
    watch: [
      "'Super built-up area' is a market term, not a defined term in this standard. That gap is where most real estate disputes in India begin.",
      "Real estate regulation now requires carpet area to be declared — and this is the standard that says what carpet area means.",
    ],
  },

  /* ---------------------------------------------- FIRE */
  is1642: {
    what: "The fire safety code covering details of construction — what a building must be built of and how, so that fire is contained rather than spreading freely. It covers fire resistance ratings of elements, compartmentation, fire stopping of service penetrations, protection of structural members and the treatment of shafts, ducts and openings.",
    use: "Designing the fabric of a building for fire safety, and checking an existing building's construction against it.",
    inside: [
      "Fire resistance ratings required of walls, floors, columns, beams and doors",
      "Compartmentation — dividing a building so fire cannot travel the whole floor plate",
      "Protection of structural members, including steel",
      "Fire stopping of penetrations by pipes, cables and ducts",
      "Shafts, staircases, lifts and service ducts",
      "External walls, openings and the spread of fire from floor to floor",
    ],
    key: [
      ["Fire resistance", "Expressed as a period — the time an element continues to perform under a standard fire"],
      ["Compartmentation", "The single most effective passive fire measure in a building"],
      ["Weak point", "Service penetrations — one unsealed cable tray defeats a whole compartment wall"],
    ],
    watch: [
      "Passive fire protection is built in and then hidden. Once the false ceiling goes up nobody sees the unsealed penetration until there is a fire.",
      "The National Building Code Part 4 is the umbrella document; the IS 1642 to 1644 family sits under it.",
    ],
  },

  is1643: {
    what: "The fire safety code covering exposure hazard — the risk that a fire in one building spreads to the next. It deals with the separation between buildings, the treatment of external walls and openings, and the limits on unprotected openings in a facade facing a boundary or another building.",
    use: "Site planning and facade design; checking the separation between blocks on a plot.",
    inside: [
      "Separating distances between buildings, related to occupancy and to the area of unprotected openings",
      "Fire resistance of external walls",
      "Limits on unprotected openings in external walls facing a boundary",
      "Protection of openings and the treatment of projections, balconies and eaves",
      "Roof coverings and their behaviour under an external fire",
    ],
    key: [
      ["Exposure hazard", "Radiation from a burning building igniting the next one across the gap"],
      ["Two variables", "The separation distance and the proportion of the facade that is unprotected opening"],
      ["Trade-off", "A more fire-resistant facade with fewer openings permits a smaller separation"],
    ],
    watch: [
      "Dense urban plots make this the hardest fire clause to satisfy, and it is frequently the one that decides the building footprint.",
      "Glazing is an unprotected opening unless it is fire-rated glazing — ordinary glass fails early in a fire.",
    ],
  },

  is1644: {
    what: "The fire safety code covering exit requirements and personal hazard — everything about getting people out. It sets the number, width and arrangement of exits, travel distances, the design of staircases and corridors, exit signage and lighting, and the protection of escape routes so that they remain usable while the building burns.",
    use: "Planning a building's escape routes, and auditing an existing building for exit adequacy.",
    inside: [
      "Occupant load, and the number and width of exits it demands",
      "Travel distance to an exit, varying by occupancy and by whether the building is sprinklered",
      "Design of staircases, corridors, doors, ramps and exit discharge",
      "Protection of escape routes — enclosure, pressurisation and smoke control",
      "Exit signage, emergency lighting and their maintenance",
      "Assembly areas, high-rise buildings and special occupancies",
    ],
    key: [
      ["Exit width", "Derived from the occupant load in units of width, not chosen by eye"],
      ["Travel distance", "The distance from the furthest point to a protected exit — the key planning constraint"],
      ["Doors on escape routes", "Open in the direction of travel and are never locked while the building is occupied"],
    ],
    watch: [
      "Nearly every fatal building fire in India involves blocked, locked or missing second exits. The clause is not the problem; compliance after occupancy is.",
      "An exit that discharges into an enclosed courtyard with no way out is not an exit.",
    ],
  },

  is2190: {
    what: "The code of practice for selecting, installing and maintaining first-aid fire extinguishers — the portable units that deal with a fire in its first minute, before it becomes a fire brigade problem. It matches the extinguishing medium to the class of fire, and sets how many are needed, where they go and how often they are checked.",
    use: "Specifying extinguishers for a building, and auditing an existing installation.",
    inside: [
      "Classes of fire and the extinguishing media suited to each",
      "Types of extinguisher — water, foam, dry powder, carbon dioxide, wet chemical, clean agent",
      "Number and distribution of extinguishers, and maximum travel distance to one",
      "Mounting height, location and visibility",
      "Inspection, testing, refilling and record keeping",
      "Training of occupants",
    ],
    key: [
      ["Class A", "Ordinary combustibles — wood, paper, cloth"],
      ["Class B", "Flammable liquids"],
      ["Class C", "Flammable gases"],
      ["Electrical fires", "Carbon dioxide or clean agent — never water"],
      ["Travel distance", "Limited so that an extinguisher is reachable within seconds from anywhere"],
    ],
    watch: [
      "The wrong medium makes things worse: water on an electrical or oil fire spreads it or electrocutes the user.",
      "An extinguisher that has not been inspected and refilled on schedule is decoration. The maintenance record is as much part of compliance as the unit.",
    ],
  },

  is15105: {
    what: "The code of practice for fixed automatic sprinkler systems — the single most effective fire protection measure a building can have. The standard covers hazard classification, the type and spacing of sprinkler heads, pipe sizing, water supply and pressure, and the testing and maintenance that keep the system live.",
    use: "Designing or reviewing a sprinkler installation in any building where one is required or chosen.",
    inside: [
      "Classification of occupancy hazard — light, ordinary and high hazard, with sub-groups",
      "Types of sprinkler system — wet pipe, dry pipe, pre-action and deluge",
      "Sprinkler head types, temperature ratings, spacing and area of coverage",
      "Hydraulic design, pipe sizing and the water supply and pump requirements",
      "Water storage capacity and duration",
      "Installation, commissioning, testing and periodic maintenance",
    ],
    key: [
      ["How it works", "Only the heads over the fire operate — a sprinkler system is not a building-wide shower"],
      ["Hazard class", "Drives the design density and the area of operation, and therefore the whole water supply"],
      ["Why it matters", "A sprinklered building is allowed longer travel distances and larger compartments in the exit code"],
    ],
    watch: [
      "Sprinklers fail almost only when the valve was shut or the water supply was not maintained. The system is only as good as its upkeep.",
      "Storing goods too close to the heads, or adding a false ceiling below them, disables the system without anyone noticing.",
    ],
  },

  /* ---------------------------------------------- LIME & TIMBER */
  is712: {
    what: "The specification for building limes. Lime is classified by how hydraulic it is — that is, how much it sets by chemical reaction with water rather than by slowly absorbing carbon dioxide from the air. The more hydraulic the lime, the more it behaves like a weak cement; the fatter the lime, the better it is for plaster and finishing.",
    use: "Ordering lime for mortar, plaster, whitewash or soil stabilisation, and matching the class to the job.",
    inside: [
      "Classes of building lime, from eminently hydraulic through semi-hydraulic to fat lime",
      "Chemical requirements — calcium oxide content, insoluble residue, carbon dioxide",
      "Physical requirements — fineness, soundness, workability and compressive strength",
      "Forms in which lime is supplied — quicklime and hydrated lime",
      "Packing, marking and storage",
    ],
    key: [
      ["Class A", "Eminently hydraulic — used for structural work"],
      ["Class B", "Semi-hydraulic — the general masonry mortar lime"],
      ["Class C", "Fat lime — for finishing coats and whitewashing, not for strength"],
      ["Classes D, E and F", "Magnesium or dolomitic lime for finishing, kankar lime, and siliceous dolomitic lime"],
    ],
    watch: [
      "Fat lime in a structural mortar will never gain the strength expected of it — it sets by absorbing carbon dioxide and can take months in the middle of a thick wall.",
      "Quicklime is caustic and reacts violently with water. It is a safety hazard on site and must be slaked under control.",
    ],
  },

  is1635: {
    what: "The code of practice for field slaking of building lime and the preparation of lime putty — how to convert quicklime into a usable material on site safely and completely. Slaking is a violent exothermic reaction, and if it is done badly the unslaked particles continue to expand inside the finished plaster months later and blow it off the wall.",
    use: "Any site using quicklime rather than ready hydrated lime, particularly in conservation and traditional construction.",
    inside: [
      "Methods of slaking — tank, platform and other field methods",
      "Water requirement, and the sequence of adding lime to water",
      "Screening of the slaked lime and disposal of the residue",
      "Maturing of lime putty and the period it needs before use",
      "Storage and protection of putty",
      "Safety precautions for handling quicklime",
    ],
    key: [
      ["Slaking", "Quicklime plus water gives hydrated lime, with a great deal of heat"],
      ["Maturing", "Putty improves with time; traditional practice matures it for weeks or longer"],
      ["Screening", "Removes unslaked lumps, which are what cause blowing later"],
    ],
    watch: [
      "Unslaked particles left in a plaster expand when they eventually meet moisture and pop craters in the finish — months after handover. Screening is not optional.",
      "Always add lime to water, never water to lime, and keep skin and eyes protected. The reaction can boil.",
    ],
  },

  is883: {
    what: "The code of practice for structural timber design. Timber is anisotropic — very strong along the grain, weak across it — and its strength depends on species, on moisture content, on how long the load is applied and on where the member sits. IS 883 handles this by grouping species, grading each piece, and giving permissible stresses that are then modified for the conditions of use.",
    use: "Designing timber beams, posts, trusses and joints, and checking an existing timber structure.",
    inside: [
      "Grouping of species by strength and stiffness",
      "Grades of structural timber — select grade and lower grades based on permitted defects",
      "Permissible stresses in bending, compression parallel and perpendicular to grain, shear and tension",
      "Modification factors for location — inside, outside and wet locations — and for duration of load",
      "Design of beams, columns, trusses and built-up members",
      "Joints — bolted, nailed and connectored — and their design",
    ],
    key: [
      ["Species groups", "Timber is grouped by modulus of elasticity and strength, so the design need not know every species"],
      ["Moisture", "Strength falls as moisture content rises; permissible stresses are stated for a reference condition and adjusted"],
      ["Duration of load", "Timber carries a short-term load better than a permanent one, and the permissible stress reflects this"],
    ],
    watch: [
      "Knots, slope of grain and shakes are what grading is about — a beautiful board with a knot at the tension face is a poor beam.",
      "Timber is far weaker in compression across the grain than along it. Bearing at supports is a real check, not a formality.",
    ],
  },

  is287: {
    what: "The recommendation for the maximum permissible moisture content of timber, by end use and by climatic zone. Timber shrinks and swells with the moisture in the air around it, so the correct moisture content at the time of fixing is the one that matches where the timber is going to live — and that varies enormously across India.",
    use: "Specifying moisture content for joinery, furniture, flooring and structural timber, and checking it on delivery with a moisture meter.",
    inside: [
      "Division of the country into climatic zones by average humidity",
      "Maximum permissible moisture content for each end use in each zone",
      "End uses covered — structural timber, joinery, flooring, furniture, panelling",
      "Measurement of moisture content",
    ],
    key: [
      ["Why zones", "Coastal Kerala and inland Rajasthan settle at completely different equilibrium moisture contents"],
      ["Joinery", "Requires a lower moisture content than structural timber — a door that shrinks will not close"],
      ["Equilibrium", "Timber will always move towards equilibrium with its surroundings, whatever was specified"],
    ],
    watch: [
      "Fixing joinery at too high a moisture content is the commonest cause of doors and windows that jam in one season and gap in the next.",
      "A moisture meter reading at the surface of a thick section is not the moisture content of the core.",
    ],
  },

  is1141: {
    what: "The code of practice for seasoning timber — drying it in a controlled way to the moisture content it will live at, before it is cut and used. Timber dried too quickly checks, splits, cups and warps; timber not dried at all shrinks after it is fixed. Seasoning is what turns green sawn timber into a usable material.",
    use: "Specifying and supervising the seasoning of timber before joinery or structural use.",
    inside: [
      "Air seasoning — stacking, sticker spacing, protection and the time required",
      "Kiln seasoning — schedules, temperature and humidity control",
      "Pre-treatment, end coating and anti-stain treatment",
      "Seasoning defects and their causes — checks, splits, cupping, bowing, case hardening, collapse",
      "Assessment of seasoning and measurement of moisture content",
    ],
    key: [
      ["Air seasoning", "Cheap and slow — months, and it can only reach the ambient equilibrium moisture content"],
      ["Kiln seasoning", "Fast and controllable, and it can reach lower moisture contents than air seasoning"],
      ["Stickers", "The spacers between layers in a stack; wrong spacing is the commonest cause of bowing"],
    ],
    watch: [
      "Drying too fast is worse than not drying. The surface shrinks while the core is still wet, and the piece checks or case hardens.",
      "End grain loses moisture far faster than the faces, which is why end coating exists.",
    ],
  },

  is401: {
    what: "The code of practice for the preservation of timber — treating it so that fungi, termites and borers cannot destroy it. In most of India untreated sapwood has a very short life, and the standard covers which preservatives to use, how to get them into the timber, and how much has to stay there.",
    use: "Specifying treated timber for structural use, for joinery in contact with masonry, and for anything in ground contact or in a humid environment.",
    inside: [
      "Types of preservative — oil type, organic solvent type and water soluble type",
      "Methods of treatment — pressure and vacuum processes, hot and cold open tank, steeping, diffusion, brushing and spraying",
      "Preparation of timber before treatment, including moisture content and incising",
      "Retention and penetration requirements by end use and hazard class",
      "Handling of treated timber, and re-treatment of cut surfaces",
    ],
    key: [
      ["Pressure treatment", "The only method that gives deep, reliable penetration"],
      ["Brushing and dipping", "Surface treatments only — suitable for low hazard use, not for ground contact"],
      ["Retention", "How much preservative stays in the wood; it is the number that matters, not the treatment name"],
    ],
    watch: [
      "Cutting or drilling treated timber exposes untreated wood. Every cut face must be re-treated on site or the termites simply enter there.",
      "Heartwood of durable species may need no treatment; sapwood of the same log always does.",
    ],
  },

  /* ---------------------------------------------- BITUMEN PRODUCTS */
  is8887: {
    what: "The specification for bitumen emulsions — bitumen dispersed as fine droplets in water with an emulsifier, so it can be sprayed and mixed cold. When the emulsion contacts the aggregate it breaks, the water leaves, and a continuous bitumen film is left behind. It removes the need to heat binder on site, which matters enormously for maintenance work and rural roads.",
    use: "Prime coats, tack coats, surface dressing, slurry seal, micro-surfacing, cold mix and pothole repair.",
    inside: [
      "Types by setting speed — rapid setting, medium setting and slow setting",
      "Cationic and anionic emulsions, and which aggregates each suits",
      "Requirements — residue on sieving, viscosity, storage stability, coating ability and the properties of the residual bitumen",
      "Sampling, packing, marking and storage",
    ],
    key: [
      ["Rapid setting (RS)", "Surface dressing and tack coats — breaks almost on contact"],
      ["Medium setting (MS)", "Premix with coarse aggregate"],
      ["Slow setting (SS)", "Slurry seal, micro-surfacing and fine aggregate mixes, where working time is needed"],
      ["Cationic", "Positively charged droplets, which bond well with the negatively charged surfaces of most Indian aggregates"],
    ],
    watch: [
      "Emulsions can be stored for only a limited time and must not be allowed to freeze or to be over-agitated; a broken drum is waste.",
      "Choosing the wrong setting grade is the commonest field error — a rapid setting emulsion in a premix breaks in the mixer.",
    ],
  },

  is15462: {
    what: "The specification for polymer modified bitumen and crumb rubber modified bitumen. Adding a polymer, or crumb rubber from waste tyres, widens the temperature range over which the binder behaves well — stiffer in summer so the road does not rut, more flexible in winter so it does not crack, and much tougher under repeated heavy loading.",
    use: "Heavy traffic corridors, intersections, toll plazas, steep gradients, and any location where ordinary bitumen ruts or cracks early.",
    inside: [
      "Grades of polymer modified bitumen and of crumb rubber modified bitumen",
      "Requirements — penetration, softening point, elastic recovery, separation on storage and viscosity",
      "Properties of the residue after the thin film oven test",
      "Storage, handling and the higher mixing and compaction temperatures required",
    ],
    key: [
      ["Elastic recovery", "The property that distinguishes a genuinely modified binder from an ordinary one"],
      ["Wider service range", "Higher softening point without becoming brittle at low temperature"],
      ["CRMB", "Uses crumb rubber from waste tyres — cheaper, and it consumes a waste stream"],
    ],
    watch: [
      "Modified binders need higher mixing and laying temperatures and shorter storage times. Treating them like ordinary bitumen wastes the modification entirely.",
      "Separation on storage is a real failure mode — a modified binder held hot and unstirred for days can separate into its components.",
    ],
  },

  /* ---------------------------------------------- FINISHES */
  "is2395-1": {
    what: "The code of practice for painting concrete, masonry and plaster surfaces — the operations and workmanship side. Most paint failures are not paint failures; they are surface preparation failures, moisture failures or alkalinity failures. This standard is about getting those right.",
    use: "Specifying and supervising painting work on any building.",
    inside: [
      "Preparation of the surface — cleaning, removal of laitance and loose material, making good",
      "The drying and curing period a new plaster or concrete surface needs before painting",
      "Alkalinity of fresh cement surfaces and how to deal with it",
      "Priming, and the choice of primer for the surface and the paint system",
      "Application by brush, roller and spray, and the number of coats",
      "Defects — chalking, flaking, blistering, efflorescence and their causes",
    ],
    key: [
      ["Drying period", "New cement plaster must dry out thoroughly before painting; painting too soon traps moisture"],
      ["Alkalinity", "Fresh cement surfaces are strongly alkaline and will attack many paints — hence alkali resistant primers"],
      ["Primer", "Bonds the system to the surface; skipping it is the commonest cause of peeling"],
    ],
    watch: [
      "Painting a damp wall guarantees blistering and peeling, however good the paint is. Moisture must be traced and stopped first.",
      "More coats of a cheap paint is not equal to fewer coats of a good one — the binder quality, not the thickness, decides durability.",
    ],
  },

  is427: {
    what: "The specification for dry distemper — a traditional water-based interior coating supplied as a powder, mixed with water on site and applied to walls and ceilings. It is cheap, breathable and easy to recoat, and it is still widely used for interiors where economy matters more than washability.",
    use: "Economical internal painting of plastered walls and ceilings.",
    inside: [
      "Composition and general requirements for dry distemper",
      "Consistency, drying time and finish requirements",
      "Covering capacity and colour",
      "Packing, marking and storage",
    ],
    key: [
      ["Supplied as", "A dry powder mixed with water on site"],
      ["Advantage", "Cheap, breathable and easily recoated"],
      ["Limitation", "Not washable; it rubs off and will not survive a wet cloth"],
    ],
    watch: [
      "Distemper is an interior finish only. On an external wall it will not last one monsoon.",
      "It cannot be applied over an oil-based paint without preparation — the new coat will not bond.",
    ],
  },

  is428: {
    what: "The specification for oil emulsion distemper — distemper with an oil or resin emulsified into it, which makes the dried film tougher and washable, unlike dry distemper. It occupies the middle ground between dry distemper and a full acrylic emulsion paint.",
    use: "Internal walls and ceilings where a washable finish is wanted at a lower cost than emulsion paint.",
    inside: [
      "Composition and general requirements",
      "Consistency, drying time, finish and flexibility",
      "Washability and resistance to rubbing",
      "Covering capacity, colour and keeping properties",
      "Packing and marking",
    ],
    key: [
      ["Difference from dry distemper", "Contains an emulsified oil or resin, so the film is washable"],
      ["Application", "Supplied ready to use or requiring thinning with water, depending on the product"],
      ["Position", "Between dry distemper and emulsion paint in both cost and durability"],
    ],
    watch: [
      "Still an interior finish. Washable is not the same as weatherproof.",
      "It needs a properly primed and dry surface; applied on a fresh alkaline plaster it will saponify and go patchy.",
    ],
  },

  is15489: {
    what: "The specification for plastic emulsion paint — the acrylic or vinyl-acrylic water-based paint that is now the default finish for Indian buildings, inside and out. The standard separates interior and exterior grades and sets the performance requirements that distinguish them, above all scrub resistance for interiors and weathering resistance for exteriors.",
    use: "Specifying and accepting emulsion paint for internal and external surfaces.",
    inside: [
      "Interior and exterior grades and their different requirements",
      "Consistency, drying time, finish and flexibility",
      "Scrub resistance and resistance to rubbing",
      "Resistance to alkali, to water and, for exterior grades, to accelerated weathering",
      "Covering capacity, opacity and colour retention",
      "Packing and marking",
    ],
    key: [
      ["Scrub resistance", "The headline property for interior grades — how many cycles the film survives"],
      ["Exterior grade", "Adds weathering, alkali and water resistance requirements"],
      ["Water based", "Low odour, quick drying and washable — which is why it replaced oil paints indoors"],
    ],
    watch: [
      "Interior emulsion on an external wall fails within a year or two. The grades are not interchangeable, whatever the shade card suggests.",
      "Covering capacity on the tin assumes a smooth primed surface. A rough or porous surface will take considerably more paint.",
    ],
  },

  is2835: {
    what: "The specification for flat transparent sheet glass — the older drawn or rolled sheet glass, made by drawing a ribbon of glass vertically. Because the surfaces are formed by drawing rather than floating, there is always some distortion in the reflection, which is how you can tell it from float glass.",
    use: "Ordinary glazing in windows and doors where optical quality is not critical; reading older specifications.",
    inside: [
      "Nominal thicknesses and their tolerances",
      "Quality classification and permitted defects — bubbles, seeds, scratches and distortion",
      "Dimensions, squareness and edge condition",
      "Sampling, packing and marking",
    ],
    key: [
      ["Made by", "Drawing a ribbon of glass — hence the characteristic slight optical distortion"],
      ["Position today", "Largely superseded by float glass for all but the most economical work"],
      ["Thickness", "Supplied in a range of nominal thicknesses, each with its own tolerance"],
    ],
    watch: [
      "Sheet glass is not safety glass. Any glazing at low level, in a door, or in a wet area should be toughened or laminated.",
      "Glass must be ordered by thickness calculated from the pane size and the design wind pressure, not by habit.",
    ],
  },

  is14900: {
    what: "The specification for transparent float glass — glass formed by floating molten glass on a bath of molten tin, which produces two perfectly flat, parallel, fire-polished surfaces and therefore distortion-free vision. It is the base product for almost all modern glazing, and for every toughened, laminated, coated and insulated glass product.",
    use: "All modern glazing, and as the substrate for processed glass products.",
    inside: [
      "Nominal thicknesses and thickness tolerances",
      "Optical quality and permitted defects — bubbles, inclusions, scratches and distortion",
      "Dimensions, squareness and edge quality",
      "Sampling, marking and handling",
    ],
    key: [
      ["Made by", "Floating molten glass on molten tin — hence flat, parallel, distortion-free surfaces"],
      ["Thicknesses", "Commonly 3, 4, 5, 6, 8, 10, 12 mm and upwards"],
      ["Base product", "Toughened, laminated, coated, reflective and insulated units all start as float glass"],
    ],
    watch: [
      "Float glass is annealed glass and breaks into large sharp shards. Where safety matters it must be toughened or laminated first.",
      "Glass cannot be cut or drilled after toughening. All processing must be complete before the glass goes into the furnace.",
    ],
  },

  is1237: {
    what: "The specification for cement concrete flooring tiles — the pressed cement tiles, including terrazzo and mosaic tiles, that were the standard Indian floor finish for decades and are still widely used. The standard judges them on wear resistance, water absorption and transverse strength.",
    use: "Specifying and accepting cement tiles, terrazzo tiles and mosaic flooring.",
    inside: [
      "Types — plain cement tiles, coloured tiles and terrazzo or mosaic tiles",
      "Dimensions, thickness of the wearing layer and tolerances",
      "Wear resistance, measured by an abrasion test",
      "Water absorption and transverse strength",
      "Sampling, marking and acceptance",
    ],
    key: [
      ["Wearing layer", "The top layer that carries the traffic; its thickness is specified separately"],
      ["Wear resistance", "The property that decides how long the floor keeps its finish"],
      ["Terrazzo", "Marble or stone chips in a cement matrix, ground and polished after laying"],
    ],
    watch: [
      "The tile is only half the job. Cement tiles are ground and polished in place, and a poor grinding job ruins a good tile.",
      "Cement tiles are porous compared with vitrified tiles and will stain — they need sealing in kitchens and wet areas.",
    ],
  },

  is15622: {
    dia: "g-tilegroup",
    what: "The specification for pressed ceramic tiles — the modern classification that covers everything from porous wall tiles to fully vitrified floor tiles. The classifying property is water absorption, because absorption predicts strength, frost resistance, staining and where the tile may be used better than any other single number.",
    use: "Choosing and accepting ceramic and vitrified tiles for floors, walls and external cladding.",
    inside: [
      "Classification by water absorption into groups, from very low to high absorption",
      "Further division by method of manufacture — dry pressed and extruded",
      "Dimensions, surface quality and permitted deviations",
      "Modulus of rupture and breaking strength requirements by group",
      "Surface abrasion resistance, chemical resistance, stain resistance and thermal shock",
      "Marking and packing",
    ],
    key: [
      ["Group BIa", "Water absorption not more than 0.5% — fully vitrified; the strongest and least porous"],
      ["Group BIb", "Absorption over 0.5% and up to 3%"],
      ["Group BIIa and BIIb", "Absorption over 3% and up to 10% — semi-vitreous"],
      ["Group BIII", "Absorption over 10% — wall tiles, interior use only"],
    ],
    watch: [
      "Low absorption means low porosity, which means adhesive — not cement mortar slurry — is needed to bond a vitrified tile properly.",
      "Group BIII wall tiles laid on a floor will crack and wear through. Check the group, not the picture in the catalogue.",
    ],
  },

  "is2547-1": {
    what: "The specification for gypsum building plaster — the plaster of Paris family used for internal finishing, false ceilings and mouldings. Gypsum plaster sets by recombining with water rather than by hydraulic reaction, sets fast, shrinks very little and gives a hard, smooth surface that needs no putty coat.",
    use: "Internal wall and ceiling plastering as an alternative to cement plaster, and all decorative plasterwork.",
    inside: [
      "Types of gypsum building plaster and their intended uses",
      "Setting time, fineness and mechanical strength requirements",
      "Purity — gypsum content and limits on impurities",
      "Soundness, and freedom from lumps and unset material",
      "Packing, marking and storage",
    ],
    key: [
      ["Sets by", "Recombining with water — a rehydration reaction, not a hydraulic one"],
      ["Advantage", "Very low shrinkage, so a gypsum-plastered wall does not craze the way cement plaster can"],
      ["Finish", "Smooth enough to paint directly, saving the putty coat"],
    ],
    watch: [
      "Gypsum plaster is for internal, dry locations only. In a bathroom, a kitchen splash zone or an external wall it will soften and fail.",
      "It must never be applied over or under a cement-based product in a way that traps moisture between them, and it is not suitable in contact with steel without protection.",
    ],
  },

  "is2095-1": {
    what: "The specification for plain gypsum plaster boards — the factory-made board of a gypsum core faced with paper, used for drywall partitions and suspended ceilings. It replaces wet plastering with a dry, fast, dimensionally stable system that can be dismantled and altered later.",
    use: "Internal partitions, wall linings and false ceilings in dry areas.",
    inside: [
      "Types and nominal thicknesses of plain gypsum plaster board",
      "Dimensions, tolerances and edge profiles",
      "Requirements — breaking load, surface water absorption and moisture content",
      "Marking, handling and storage",
      "Companion parts cover moisture resistant, fire resistant and other specialised boards",
    ],
    key: [
      ["Edge profile", "Tapered edges allow a flush jointed finish; square edges do not"],
      ["Speed", "A drywall partition goes up in a day and needs no curing"],
      ["Specialised boards", "Moisture resistant and fire resistant variants exist — they are different products, not the same board"],
    ],
    watch: [
      "Ordinary plasterboard in a wet area fails. Use the moisture resistant grade, and even that is not a substitute for tiling in a shower.",
      "The performance of a drywall partition — acoustic and fire — comes from the whole system, the studs, the insulation and the board together, not from the board alone.",
    ],
  },

  is3067: {
    dia: "g-waterproof",
    what: "The code of practice for the general design details and preparatory work for damp-proofing and waterproofing of buildings. It is the design-stage document: where the water will come from, which surfaces must be protected, how the damp proof course sits in the wall, how junctions and upstands are formed, and what preparation each surface needs before any membrane goes on.",
    use: "Designing the waterproofing of a roof, a basement, a terrace or a wet area — before choosing the product.",
    inside: [
      "Sources of dampness — rising damp, rain penetration, ground water and condensation",
      "Damp proof course in walls, its position and continuity",
      "Basement waterproofing — tanking, and the treatment of the wall-to-slab junction",
      "Roof and terrace waterproofing — slopes, drainage, upstands, parapets and expansion joints",
      "Preparatory work — surface preparation, curing and the moisture condition required",
      "Treatment of penetrations, outlets and junctions",
    ],
    key: [
      ["First principle", "Drain the water away before trying to seal it out — slope and outlets matter more than membrane"],
      ["Upstand", "Membrane must be turned up at every vertical face and terminated properly, never stopped flat"],
      ["Continuity", "A damp proof course or membrane with one break is not a barrier"],
    ],
    watch: [
      "Almost every waterproofing failure is at a junction, a penetration or an outlet — not in the middle of the field, where everyone concentrates.",
      "Waterproofing applied over a damp or poorly prepared substrate will debond, however good the product is.",
    ],
  },

  is1322: {
    what: "The specification for bitumen felts used in waterproofing and damp-proofing — sheets of hessian, glass fibre or fibre base saturated and coated with bitumen, supplied in rolls. They are the traditional built-up roofing membrane and are still widely used in India.",
    use: "Built-up roof waterproofing, damp proof courses and under-slab protection.",
    inside: [
      "Types of felt by base material — hessian base, fibre base and glass fibre base",
      "Grades by mass per unit area",
      "Requirements — breaking strength, pliability, water absorption, heat resistance and storage sticking",
      "Dimensions of rolls, packing, marking and storage",
    ],
    key: [
      ["Base material", "Decides the strength and the durability — glass fibre base does not rot"],
      ["Grade", "Defined by mass per unit area; a heavier felt is a more durable membrane"],
      ["Used in", "Multi-layer built-up treatments, bonded with hot bitumen"],
    ],
    watch: [
      "Rolls must be stored on end, in the shade. Felt stored flat in the sun sticks together and is unusable.",
      "Organic-base felts can rot where they stay wet; glass fibre base is the safer choice for a roof that ponds.",
    ],
  },

  is1346: {
    what: "The code of practice for waterproofing roofs with bitumen felts — the application side of the felt system. It sets out grades of treatment, from a light single-layer treatment to a heavy multi-layer built-up system, and covers the preparation, laying, lapping and protection that make the difference between a roof that lasts and one that does not.",
    use: "Specifying and supervising a built-up bitumen felt roof treatment.",
    inside: [
      "Grades of waterproofing treatment and where each is appropriate",
      "Preparation of the roof surface, slopes to outlets and the screed",
      "Laying the felt — bonding, laps, and the sequence of layers",
      "Treatment at parapets, upstands, outlets, expansion joints and penetrations",
      "Protective finish over the membrane — tiles, screed or mineral surfacing",
      "Repairs and maintenance",
    ],
    key: [
      ["Grade of treatment", "Chosen from the importance of the building and the exposure — more layers for a longer life"],
      ["Slope", "The membrane keeps water out; the slope keeps it moving. Ponding kills any membrane"],
      ["Protection", "The membrane must be protected from sunlight and foot traffic, or it degrades quickly"],
    ],
    watch: [
      "A membrane laid on a flat roof with no fall will fail regardless of how many layers it has. Fix the slope first.",
      "Laps must run with the flow of water, not against it — a lap laid the wrong way is a funnel.",
    ],
  },

  is733: {
    what: "The specification for wrought aluminium and aluminium alloy bars, rods and sections for general engineering. It defines the alloy designations, the tempers, the mechanical properties and the tolerances — which together decide whether an extruded section is strong enough for the window or the structure it is going into.",
    use: "Specifying aluminium sections for windows, doors, curtain walling, louvres and light structural work.",
    inside: [
      "Alloy designations and their chemical composition",
      "Temper designations, which describe the heat treatment and work hardening",
      "Mechanical properties — tensile strength, proof stress and elongation, by alloy and temper",
      "Dimensional tolerances on extruded sections",
      "Testing, marking and freedom from defects",
    ],
    key: [
      ["Alloy and temper together", "Neither means anything alone — the same alloy in two tempers has very different strength"],
      ["Stiffness", "Aluminium's modulus is about a third of steel's, so aluminium members deflect far more for the same section"],
      ["Corrosion", "Aluminium forms its own protective oxide, but it corrodes badly in contact with cement and with dissimilar metals"],
    ],
    watch: [
      "Aluminium in direct contact with wet cement or with steel corrodes. Isolate it — that is why bituminous paint on embedded frames exists.",
      "Sections are usually chosen for deflection and not for strength, because the low modulus governs.",
    ],
  },

  is1948: {
    what: "The specification for aluminium doors, windows and ventilators — the finished product rather than the extrusion. It covers the types of unit, the sections and thicknesses used, the fittings, glazing and weathering, and the performance the assembled unit must deliver.",
    use: "Specifying and accepting aluminium windows and doors for a building.",
    inside: [
      "Types of window, door and ventilator — fixed, sliding, openable, top hung, louvred",
      "Section dimensions, wall thickness and the alloy and temper required",
      "Fittings, hardware, weather stripping and glazing",
      "Fabrication, jointing and the finish — anodizing or powder coating",
      "Fixing into the opening, and the sealing of the frame to the structure",
      "Tolerances and tests on the assembled unit",
    ],
    key: [
      ["Section thickness", "The commonest place cost is quietly cut; a thin section flexes and the unit leaks"],
      ["Finish", "Anodized or powder coated — the coating thickness is what determines how long it stays looking new"],
      ["Weathering", "Air and water tightness depend on the gaskets and the drainage of the frame, not on the aluminium"],
    ],
    watch: [
      "Most aluminium window leaks are at the frame-to-wall joint, not through the window. The sealant detail and the drainage slots matter more than the section.",
      "Sliding windows are much harder to weatherproof than casements — in a driving-rain location that choice matters.",
    ],
  },

});
