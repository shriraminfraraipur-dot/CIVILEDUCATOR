/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   Chapter 9  — Tacheometry
   Chapter 10 — Areas and Volumes
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 9 */
    {
      id: "sv-9",
      n: 9,
      title: "Tacheometry",
      hi: "टैकियोमेट्री",
      blurb: "Distance and height from the telescope alone — no tape touches the ground.",
      mins: 38,
      sections: [

        {
          n: "9.1",
          title: "Why bother",
          hi: "क्यों ज़रूरी है",
          blocks: [
            { k: "p", t: "Chaining is slow, and on broken, steep or waterlogged ground it is slow and inaccurate at the same time. Tacheometry gets both the horizontal distance and the difference in level from a single telescope observation to a staff, with nobody walking the line at all." },
            { k: "list", items: [
              "<strong>Fast</strong> — one pointing gives distance, direction and height together.",
              "<strong>Works where a tape cannot go</strong> — across a gorge, a marsh, a river or a busy road.",
              "<strong>Ideal for detail and contouring</strong>, which is its main modern survival: radial contouring from a commanding station.",
              "<strong>But the accuracy is modest</strong> — about 1 in 500 to 1 in 1000 for horizontal distance by careful stadia work (<a href=\"https://engineeringhulk.com/civil/surveying/tacheometry-plane-table/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>), worse on steep sights or in shimmer; 1 in 300 is a fair figure for rough work. It is a detail method, not a control method.",
            ]},
            { k: "note", t: "The total station of Chapter 12 has replaced tacheometry for almost all new work, measuring the same distance electronically to a few millimetres. Tacheometry is still worth understanding, because the geometry it rests on is the geometry a total station's height computation still uses — and because the instruments are still in service across the country." },
          ],
        },

        {
          n: "9.2",
          title: "The stadia principle",
          hi: "स्टेडिया सिद्धांत",
          blocks: [
            { k: "dia", id: "hb-sv-stadia", cap: "The cone of sight widens at a fixed rate, so the staff intercept is a direct measure of distance." },
            { k: "p", t: "The diaphragm carries two extra horizontal hairs — <em>stadia hairs</em> — a fixed distance <strong>i</strong> apart, above and below the central hair. They define a narrow cone of sight whose width grows in exact proportion to distance, so the length of staff cut off between them grows in the same proportion." },
            { k: "eq", expr: "D = (f / i) s  +  (f + d)   =   k s  +  C", where: [
              ["s", "staff intercept — the difference between the upper and lower stadia readings"],
              ["k", "multiplying constant = f/i, made equal to 100 by design"],
              ["C", "additive constant = f + d, the distance from the instrument centre to the objective's focal point"],
            ]},
            { k: "p", t: "The constants are properties of the instrument, determined once by observing a staff at known distances and solving for k and C. In a modern internal-focusing telescope, and in any instrument with an <strong>anallatic lens</strong>, C is made zero — so the working formula collapses to the one everybody remembers:" },
            { k: "eq", expr: "D = 100 s", where: [] },
            { k: "real", t: "That is why a staff intercept of 1.200 m means the staff is 120 m away, read in about two seconds. It is the single most satisfying piece of instrument design in surveying — the anallatic lens exists for no other purpose than to make C vanish and leave a formula a chainman can do in his head." },
            { k: "eg",
              title: "Example 9.1 — Finding the tacheometric constants",
              given: "A staff is observed with horizontal sights at two pegs taped at 50.000 m and 100.000 m from the instrument. Staff intercepts: 0.495 m and 0.995 m.",
              steps: [
                { t: "Two equations", w: "50 = k(0.495) + C\n100 = k(0.995) + C" },
                { t: "Subtract", w: "50 = k(0.500)  →  k = 100" },
                { t: "Back-substitute", w: "C = 50 − 100 × 0.495 = 0.50 m" },
              ],
              ans: "k = 100, C = 0.50 m — an external-focusing telescope without an anallatic lens. In practice several distances are used and k, C found by least squares.",
            },
          ],
        },

        {
          n: "9.3",
          title: "Inclined sights",
          hi: "झुकी हुई दृष्टि",
          blocks: [
            { k: "p", t: "A horizontal sight is the easy case and a rare one. When the telescope is inclined at θ, the staff is still held <em>vertical</em> — so it is no longer perpendicular to the line of sight, and the intercept has to be resolved." },
            { k: "eq", expr: "horizontal distance   D = k s cos²θ  +  C cos θ", where: [] },
            { k: "eq", expr: "vertical component    V = k s (sin 2θ)/2  +  C sin θ", where: [
              ["V", "the rise or fall from the instrument axis to the central hair reading"],
            ]},
            { k: "p", t: "The cos²θ has two separate causes and it is worth seeing both: one cos θ resolves the sloping distance into the horizontal, and the second corrects the intercept for the staff not being perpendicular to the line of sight. Students who remember only one of them get cos θ and are wrong by a factor that grows fast with the angle." },
            { k: "eq", expr: "RL of staff station  =  RL of instrument axis  +  V  −  central hair reading", where: [] },
            { k: "p", t: "That expression is the whole of tacheometric levelling, and the sign of V follows the angle: positive for an elevation, negative for a depression. The <em>staff normal</em> variant — holding the staff perpendicular to the line of sight — gives simpler formulae but is awkward in practice, because the staffman cannot judge the angle." },
            { k: "eg",
              title: "Example 9.2 — An inclined tacheometric sight",
              given: "Instrument with k = 100, C = 0. Staff held vertical. Vertical angle +6°30'. Stadia readings 1.150, 1.750, 2.350. Height of instrument axis above the station 1.450 m; the station's RL is 250.000 m.",
              steps: [
                { t: "Staff intercept", w: "s = 2.350 − 1.150 = 1.200 m\n(check: the central reading should be the mean — (2.350 + 1.150)/2 = 1.750  ✓ so no reading was misread)" },
                { t: "Horizontal distance", w: "D = k s cos²θ = 100 × 1.200 × cos²6°30'\n  = 120 × 0.98719 = 118.46 m" },
                { t: "Vertical component", w: "V = k s (sin 2θ)/2 = 120 × sin13°00' / 2\n  = 120 × 0.22495/2 = 13.497 m" },
                { t: "RL of the instrument axis", w: "= 250.000 + 1.450 = 251.450 m" },
                { t: "RL of the staff station", w: "= 251.450 + 13.497 − 1.750 (central hair)\n= 263.197 m" },
              ],
              ans: "Horizontal distance 118.46 m, RL of the staff station 263.197 m — both from one pointing of the telescope, with nobody walking the line.",
            },
            { k: "trap", t: "The check in step 1 is free and catches the commonest tacheometric blunder. The central reading must equal the mean of the two stadia readings; if it does not, one of the three was misread, and you can see it before the staffman moves. <strong>Never book three stadia readings without taking that mean.</strong>" },
          ],
        },

        {
          n: "9.4",
          title: "The other systems, and what to carry forward",
          hi: "अन्य विधियाँ और सार",
          blocks: [
            { k: "list", items: [
              "<strong>Fixed hair (stadia) method</strong> — everything above. The hairs are fixed, the intercept varies. Overwhelmingly the most used.",
              "<strong>Movable hair (subtense) method</strong> — the intercept is fixed by targets on the staff and the hairs are moved to bisect them, the micrometer reading giving the distance. Precise, slow, and now rare.",
              "<strong>Tangential method</strong> — no stadia hairs at all. Two vertical angles α₁ and α₂ are read to two targets a known distance S apart on the staff; for two elevations D = S/(tan α₁ − tan α₂) = S cos α₁ cos α₂/sin(α₁ − α₂), and with one elevation and one depression the difference becomes a sum (<a href=\"https://engineeringhulk.com/civil/surveying/tacheometry-plane-table/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>). Needs two pointings, so it is slower and less accurate.",
              "<strong>Subtense bar</strong> — a horizontal bar of known length, usually 2 m, set up over the far point perpendicular to the line. The horizontal angle it subtends gives the distance, D = b/2 × cot(α/2). Independent of the ground entirely, so it works across a ravine.",
            ]},
            { k: "eg",
              title: "Example 9.3 — Tangential method",
              given: "Vanes 2.000 m apart on a vertical staff; the lower vane is 0.500 m above the foot. Elevation angles: upper vane 8°30′, lower vane 5°12′. RL of the instrument axis 120.500 m.",
              steps: [
                { t: "Horizontal distance", w: "D = S/(tan α₁ − tan α₂) = 2.000/(0.149451 − 0.091007) = 2.000/0.058444 = 34.22 m" },
                { t: "Height of the lower vane above the axis", w: "V = D tan α₂ = 34.22 × 0.091007 = 3.114 m" },
                { t: "RL of the staff station", w: "= 120.500 + 3.114 − 0.500 = 123.114 m" },
              ],
              ans: "D = 34.22 m, RL 123.114 m. Note how small the difference of tangents is — an error of 20″ in either angle changes D by about 0.3%.",
            },
            { k: "list", items: [
              "D = k s + C, and the anallatic lens exists to make C = 0 so that D = 100 s.",
              "Inclined sights: D = k s cos²θ, V = k s sin2θ/2 — and the square on the cosine has two separate reasons.",
              "RL = RL of instrument axis + V − central hair reading.",
              "Check every set of three readings against their mean.",
              "Accuracy about 1 in 500 to 1 in 1000 at best — detail and contouring, never control.",
            ]},
            { k: "p", t: "Chapters 3 to 9 have all been about <em>obtaining</em> measurements. Chapter 10 is about what is done with them: the areas and volumes that a bill of quantities is built from." },
          ],
        },
      ],
    },

    /* =========================================================== CH 10 */
    {
      id: "sv-10",
      n: 10,
      title: "Areas and Volumes",
      hi: "क्षेत्रफल और आयतन",
      blurb: "Turning field measurements into the quantities that get paid for.",
      mins: 46,
      sections: [

        {
          n: "10.1",
          title: "Why this chapter is the one that costs money",
          hi: "यह अध्याय पैसे का है",
          blocks: [
            { k: "p", t: "Everything so far produces positions. This chapter turns positions into <strong>quantities</strong> — square metres of land, cubic metres of earthwork — and those quantities are what appear on a bill and what somebody is paid for." },
            { k: "p", t: "That changes the standard of care. An error of 1 in 500 in a plan position is usually invisible; the same error in an earthwork volume on a 20 km road is thousands of cubic metres and a contractual argument. The arithmetic here is simple, and it is worth doing twice." },
          ],
        },

        {
          n: "10.2",
          title: "Areas from offsets",
          hi: "ऑफसेट से क्षेत्रफल",
          blocks: [
            { k: "p", t: "A plot bounded on one side by an irregular line — a stream, a road edge, a field boundary — is measured by taking offsets from a straight survey line at regular intervals. The area then depends on what you assume the boundary does between the offsets." },
            { k: "dia", id: "hb-sv-simpson", cap: "Straight between offsets, or a parabola through each three — and the second follows a curve much better." },
            { k: "eq", expr: "Trapezoidal rule:   A = d [ (O₁ + Oₙ)/2  +  O₂ + O₃ + … + Oₙ₋₁ ]", where: [
              ["d", "the common interval between offsets"],
              ["O", "the offsets"],
            ]},
            { k: "eq", expr: "Simpson's rule:   A = (d/3) [ O₁ + Oₙ  +  4(O₂ + O₄ + …)  +  2(O₃ + O₅ + …) ]", where: [] },
            { k: "list", items: [
              "<strong>Trapezoidal</strong> assumes the boundary runs straight between offsets. Works with <em>any</em> number of offsets, and under-estimates a convex boundary.",
              "<strong>Simpson's</strong> fits a parabola through each successive group of three. Much more accurate for a genuinely curved boundary — and it requires an <strong>even number of intervals</strong>, hence an odd number of offsets.",
            ]},
            { k: "eg",
              title: "Example 10.1 — The same boundary, both rules",
              given: "Offsets taken at 10 m intervals from a survey line: 2.5, 3.8, 4.6, 5.2, 4.9, 4.1, 3.2 m. Seven offsets, six intervals.",
              steps: [
                { t: "Trapezoidal rule", w: "A = 10 × [ (2.5 + 3.2)/2 + (3.8 + 4.6 + 5.2 + 4.9 + 4.1) ]\n  = 10 × [ 2.85 + 22.60 ]\n  = 10 × 25.45 = 254.50 m²" },
                { t: "Simpson's rule — sort the offsets first", w: "even-numbered offsets O₂, O₄, O₆: 3.8, 5.2, 4.1 → sum 13.1, multiplied by 4\nodd-numbered intermediates O₃, O₅: 4.6, 4.9 → sum 9.5, multiplied by 2\nends: 2.5 + 3.2 = 5.7" },
                { t: "Apply", w: "A = (10/3) × [ 5.7 + 4(13.1) + 2(9.5) ]\n  = (10/3) × [ 5.7 + 52.4 + 19.0 ]\n  = (10/3) × 77.1 = 257.00 m²" },
              ],
              ans: "Trapezoidal 254.50 m², Simpson's 257.00 m² — a difference of 1%. Simpson's is the better figure here, because the boundary is convex and the chords of the trapezoidal rule cut the corners off it.",
            },
            { k: "trap", t: "With an <em>even</em> number of offsets Simpson's rule cannot be applied to the whole figure. The correct treatment is to apply Simpson's to all the strips it will cover and compute the last strip trapezoidally, then add. Silently dropping an offset to make the count work is a real and common error, and it loses a whole strip of area." },
            { k: "note", t: "Where the boundary is defined by coordinates rather than offsets — which is how a total station survey arrives — the <strong>cross-coordinate</strong> or shoelace method is used instead: 2A = Σ[ xᵢ(yᵢ₊₁ − yᵢ₋₁) ]. It is exact for any straight-sided figure, needs no equal intervals, and is what every software package actually runs." },
            { k: "eg",
              title: "Example 10.2 — Area of the traverse in Chapter 8 from its coordinates",
              given: "Adjusted coordinates from Example 8.3 (E, N): A (1000.000, 1000.000), B (1172.304, 1155.239), C (1298.115, 1012.938), D (1123.353, 818.977).",
              steps: [
                { t: "Shoelace sum Σ(xᵢ yᵢ₊₁ − xᵢ₊₁ yᵢ)", w: "A→B: 1000.000 × 1155.239 − 1172.304 × 1000.000 = −17,065.0\nB→C: 1172.304 × 1012.938 − 1298.115 × 1155.239 = −312,161.8\nC→D: 1298.115 × 818.977 − 1123.353 × 1012.938 = −74,760.6\nD→A: 1123.353 × 1000.000 − 1000.000 × 818.977 = +304,376.0\nΣ = −99,611.4 (negative because the order A-B-C-D runs clockwise)" },
                { t: "Area", w: "A = |Σ|/2 = 49,805.7 m²" },
              ],
              ans: "About 49,806 m², or 4.98 ha. Working from coordinates removes the offset-interval assumption entirely; what remains is the accuracy of the coordinates themselves (1 in 2200 in length here, so roughly 1 in 1100 in area).",
            },
          ],
        },

        {
          n: "10.3",
          title: "Volumes from cross-sections",
          hi: "क्रॉस-सेक्शन से आयतन",
          blocks: [
            { k: "p", t: "Earthwork for a road, railway or canal is computed from cross-sections taken at regular chainages. Each section gives an area of cut or fill; the volume between consecutive sections follows from the areas and the spacing." },
            { k: "eq", expr: "End-area (trapezoidal) rule:   V = d [ (A₁ + Aₙ)/2  +  A₂ + A₃ + … + Aₙ₋₁ ]", where: [
              ["A", "cross-sectional areas"],
              ["d", "the common distance between sections"],
            ]},
            { k: "eq", expr: "Prismoidal rule:   V = (d/3) [ A₁ + Aₙ  +  4(A₂ + A₄ + …)  +  2(A₃ + A₅ + …) ]", where: [] },
            { k: "p", t: "The parallel with §10.2 is exact — the end-area rule is the trapezoidal rule applied to areas instead of offsets, and the prismoidal rule is Simpson's. The same condition applies: <strong>an odd number of sections</strong>." },
            { k: "def", term: "Prismoidal correction", t: "The difference between the two results. The prismoidal rule is the more accurate, so the correction is normally subtracted from the end-area figure. For ordinary embankments the end-area rule over-estimates, which is why a contractor paid on end-area quantities is being paid slightly generously." },
            { k: "eg",
              title: "Example 10.3 — Earthwork between five sections",
              given: "Cross-sectional areas at 30 m intervals along an embankment: 20, 28, 48, 60, 75 m². Five sections, four intervals.",
              steps: [
                { t: "End-area rule", w: "V = 30 × [ (20 + 75)/2 + (28 + 48 + 60) ]\n  = 30 × [ 47.5 + 136 ]\n  = 30 × 183.5 = 5505 m³" },
                { t: "Prismoidal rule", w: "even-numbered sections A₂, A₄: 28, 60 → sum 88, × 4 = 352\nodd-numbered intermediate A₃: 48 → × 2 = 96\nends: 20 + 75 = 95\nV = (30/3) × [ 95 + 352 + 96 ] = 10 × 543 = 5430 m³" },
                { t: "Prismoidal correction", w: "5505 − 5430 = 75 m³, to be deducted from the end-area figure" },
              ],
              ans: "5430 m³ by the prismoidal rule, against 5505 m³ by end-area — a difference of 1.4%, or 75 m³, which on a full road contract is a great deal of money.",
            },
            { k: "h", t: "Level sections, and the prismoidal correction per interval" },
            { k: "eq", expr: "level section:  A = (b + s h) h        prismoidal correction per interval:  Cp = d s (h₁ − h₂)² / 6", where: [
              ["b", "formation width"],
              ["s", "side slope, s horizontal : 1 vertical"],
              ["h", "depth of cut or height of bank at the centre line"],
            ]},
            { k: "p", t: "Derivation in one line: with h varying linearly between two sections, A is a quadratic in distance; the end-area rule over-states the volume of the quadratic term by exactly d s (h₁ − h₂)²/6. The correction therefore depends only on the <em>difference</em> of heights — two equal sections need none." },
            { k: "eg",
              title: "Example 10.4 — One interval of a road embankment",
              given: "Formation width 10 m, side slopes 2 : 1. Centre-line heights 2.0 m and 3.2 m at sections 30 m apart.",
              steps: [
                { t: "Areas", w: "A₁ = (10 + 2 × 2.0) × 2.0 = 28.00 m²\nA₂ = (10 + 2 × 3.2) × 3.2 = 52.48 m²" },
                { t: "End-area volume", w: "V = 30 × (28.00 + 52.48)/2 = 1207.2 m³" },
                { t: "Prismoidal correction", w: "Cp = 30 × 2 × (3.2 − 2.0)²/6 = 30 × 2 × 1.44/6 = 14.4 m³" },
                { t: "Check with the true mid-section", w: "hm = 2.6 m → Am = (10 + 5.2) × 2.6 = 39.52 m²\nV = (d/6)(A₁ + 4Am + A₂) = 5 × (28.00 + 158.08 + 52.48) = 1192.8 m³\n= 1207.2 − 14.4  ✓" },
              ],
              ans: "1192.8 m³. Both routes agree exactly, because the prismoidal formula with a true mid-section is exact for a level-section prismoid.",
            },
            { k: "trap", t: "Applying the prismoidal rule to alternate sections (as in Example 10.3) treats the area as <em>one</em> parabola over each pair of intervals. On real ground, where the centre height changes slope at every section, that can be worse than the end-area rule: for heights 2.0, 3.2 and 2.6 m at 30 m spacing on this embankment, the alternate-section rule gives 2774 m³, the end-area rule 2587 m³, and the end-area rule with the per-interval correction 2569 m³ — the last being exact for straight grades between sections. Use the per-interval correction when the sections are level sections." },
            { k: "real", t: "This is why the method of measurement is written into the contract rather than left to whoever does the arithmetic. In India IS 1200 (Part 1) governs how earthwork is measured, and the contract should also state how volumes are to be computed — a bill that says \"end-area\" and a bill that says \"prismoidal\" are different bills for identical ground." },
          ],
        },

        {
          n: "10.4",
          title: "Volumes from contours, and the mass haul diagram",
          hi: "कंटूर से आयतन और मास हॉल",
          blocks: [
            { k: "p", t: "For a reservoir, a spoil heap or a large excavation, cross-sections are the wrong tool. Instead, plan the area enclosed by each contour, treat those areas as horizontal sections stacked at the contour interval, and apply exactly the same two rules with d = the contour interval." },
            { k: "p", t: "That single idea gives a dam its <strong>storage curve</strong> — reservoir capacity against water level — and the whole economic case for a dam rests on it. It is the same arithmetic as Example 10.3 with the sections lying flat instead of standing up." },
            { k: "eg",
              title: "Example 10.5 — Reservoir capacity from contour areas",
              given: "Areas enclosed by the contours of a reservoir basin at 2 m intervals, from the lowest: 1200, 9500, 22,800, 38,600 and 56,200 m².",
              steps: [
                { t: "Trapezoidal (end-area) rule", w: "V = 2 × [(1200 + 56,200)/2 + 9500 + 22,800 + 38,600] = 2 × 99,600 = 199,200 m³" },
                { t: "Prismoidal rule (five sections, four intervals)", w: "V = (2/3) × [1200 + 56,200 + 4(9500 + 38,600) + 2(22,800)]\n  = (2/3) × [57,400 + 192,400 + 45,600] = (2/3) × 295,400 = 196,933 m³" },
              ],
              ans: "About 197,000 m³ (0.197 Mm³) up to the top contour — repeated for each water level, these totals are the storage curve.",
            },
            { k: "h", t: "The mass haul diagram" },
            { k: "p", t: "On a long earthwork the question is not only how much, but <em>where it goes</em>. A mass haul diagram plots the cumulative volume of cut minus fill against chainage, and reading it is a genuinely useful skill:" },
            { k: "list", items: [
              "<strong>Rising curve</strong> — cut exceeds fill in that stretch. <strong>Falling</strong> — fill exceeds cut.",
              "<strong>Maximum or minimum</strong> — the point where cut changes to fill, which is where the earthwork changes character on the ground.",
              "<strong>A horizontal line (balancing line)</strong> cuts the curve at points between which cut exactly balances fill — so material can be moved from one to the other with nothing imported or wasted.",
              "<strong>The area between the curve and the balancing line</strong> measures the haul — volume times distance — which is what the moving actually costs.",
            ]},
            { k: "note", t: "Borrow and spoil are the two ways of admitting the balance failed: <em>borrow</em> is material imported because there was not enough cut, <em>spoil</em> is material carted away because there was too much. Both cost money that a well-chosen formation level avoids, which is why grading a site is an optimisation and not just a drawing." },
          ],
        },

        {
          n: "10.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Trapezoidal assumes straight between offsets; Simpson's fits a parabola through each three.",
              "Simpson's needs an even number of intervals — an odd number of offsets.",
              "With an even number, do the last strip trapezoidally and add. Never drop an offset.",
              "From coordinates, use the cross-coordinate (shoelace) method — exact, and no equal intervals needed.",
              "Volumes: end-area is the trapezoidal rule, prismoidal is Simpson's, applied to cross-sectional areas.",
              "The prismoidal rule is the accurate one; for level sections the correction per interval is Cp = d s (h₁ − h₂)²/6, deducted from end-area.",
              "Reservoir capacity = the same rules applied to contour areas at the contour interval.",
              "A mass haul diagram shows not just quantity but haul — and haul is what costs.",
            ]},
            { k: "p", t: "Chapter 11 sets out the thing the earthwork is being moved for: the curve that joins two straights, horizontally and vertically." },
          ],
        },
      ],
    }

  );
})();
