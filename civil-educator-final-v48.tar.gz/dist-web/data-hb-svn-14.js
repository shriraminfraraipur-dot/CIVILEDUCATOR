/* Surveying class notes — Tacheometry, notes p.205–217 — inserted into sv chapter 9 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 9; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------------- 1 */
    {
      n: "", title: "Tacheometer, stadia diaphragm and stadia rod (notes)", hi: "टैकियोमीटर, स्टेडिया डायाफ्राम और स्टेडिया रॉड",
      blocks: [
        { k: "h", t: "📘 Notes — p.205–206" },
        { k: "def", term: "Tacheometric surveying", t: "Tacheometry is defined as an <b>optical distance measurement method</b>. Other names: <b>Tachymetry</b> or <b>Telemetry</b>. Compared to chaining, on <b>flat ground</b> the accuracy of tacheometric distance is <b>low</b>, but on <b>rough ground</b> its accuracy is <b>more</b> than chain or tape. (p.205)" },
        { k: "list", items: [
          "Flat ground → less accuracy (than chain/tape) (p.205)",
          "Rough ground → more accuracy (than chain/tape) (p.205)",
        ] },
        { k: "def", term: "Tacheometer", t: "A <b>transit theodolite fitted with a stadia diaphragm</b>. The stadia diaphragm consists of <b>2 stadia wires</b> at equal distances, one above and the other below the horizontal cross hair. (p.205)" },
        { k: "p", t: "Figure (p.205): stadia diaphragm — a circle with one vertical line through the centre and three short horizontal lines. The middle line is labelled <b>horizontal cross hair</b>; the upper and lower lines are labelled <b>stadia wires</b>." },
        { k: "h", t: "★ Important characteristics of a tacheometer" },
        { k: "list", items: [
          "Value of multiplying constant <b>K = 100</b> (p.205)",
          "Value of additive constant <b>C = 0</b> (p.205)",
          "Magnification power of the eyepiece is kept <b>high</b>. (p.205)",
        ] },
        { k: "h", t: "Stadia rod (एक तरह का staff — a kind of staff)" },
        { k: "list", items: [
          "Also called a <b>vertical stave</b>. (p.206)",
          "It is a <b>5–15 m long rod</b> graduated in decimals of metres. (p.206)",
          "For small distances <b>up to 100 m</b> a normal levelling staff is used; for long reach the stadia rod is used. When readings on an ordinary levelling staff are indistinct, the stadia rod is used. (p.206)",
        ] },
        { k: "h", t: "Methods of tacheometry (p.206)" },
        { k: "list", items: [
          "1) Stadia hair method (p.206)",
          "2) Movable hair method (p.206)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Tacheometer koi alag machine nahi hai — yeh wahi theodolite hai jiske diaphragm par do extra horizontal wires (stadia wires) lage hain. Ek pointing mein upper, middle aur lower teen readings milti hain; upper − lower = staff intercept <b>s</b>, aur usi se distance nikalta hai. Isliye rough ground (nala, khaai, steep slope) par jahan chain lagana mushkil aur galat hota hai, wahan tacheometry zyada accurate padti hai — flat ground par chain hi behtar hai." },
        { k: "trap", t: "MCQ trap: \"tacheometry is more accurate than chaining\" is <b>only true on rough ground</b>. On flat ground the notes say tacheometric distance is <b>less</b> accurate than chain or tape. Also remember the design values K = 100 and C = 0 — not C = 100 or K = 0." },
        { k: "real", t: "On site the stadia rod is pulled out when the staff is far away and the ordinary levelling-staff graduations blur in the telescope; for short sights (up to about 100 m, as per the notes) the normal levelling staff is enough." },
      ],
    },

    /* ---------------------------------------------------------------- 2 */
    {
      n: "", title: "Stadia hair method — derivation of D = Ks + C (notes)", hi: "स्टेडिया हेयर विधि — D = Ks + C की व्युत्पत्ति",
      blocks: [
        { k: "h", t: "📘 Notes — p.206–209" },
        { k: "eq", expr: "D = Ks + C   ;   K = f / i   ;   C = f + d", where: [
          ["D", "horizontal distance between staff and instrument"],
          ["K", "multiplying constant"],
          ["C", "additive constant"],
          ["s", "staff intercept"],
          ["i", "stadia interval"],
          ["f", "focal length of objective"],
          ["d", "distance from axis of instrument to objective lens"],
        ] },
        { k: "p", t: "Figure (p.206): telescope tube drawn as a cylinder; near the objective end a short vertical line marked <b>i</b> (stadia interval); rays cross at the objective lens and diverge to a vertical staff on the right, where the intercept is marked with a double-headed arrow <b>s</b>." },
        { k: "def", term: "Stadia wires / stadia interval (i)", t: "In a tacheometer the various wires other than the cross hair are known as <b>stadia wires</b>, and the vertical distance between these stadia wires is called the <b>stadia interval (i)</b>. (p.207)" },
        { k: "p", t: "In the <b>stadia hair method</b>, the parallactic angle (α) defined with the help of the stadia wires is kept <b>fixed</b> and the staff intercept is <b>varied</b>. (p.207)" },
        { k: "p", t: "Figure (p.207, first): objective (convex) lens at centre with a horizontal axis line. Left: vertical double-arrow <b>i</b> labelled \"stadia interval (const. in this m/d)\". Rays from the two stadia wires cross at the lens and diverge to the right at angle <b>α</b>, labelled \"parallactic angle (remains const. in stadia hair m/d)\". Two vertical staffs: staff A (nearer) with intercept points S₁ (top) and S₃ (bottom); staff B (farther) with S₁′ and S₃′. Long double-arrow at right: \"s → staff intercept (variable in this m/d)\"." },
        { k: "p", t: "Figure (p.207, second): tacheometer on a tripod; vertical dashed line through the tripod = <b>axis of instrument</b>; eye at the eyepiece (left); inside the telescope a double-arrow <b>i</b> (stadia interval) at distance <b>v</b> behind the objective lens; rays from the stadia wires pass through the lens and through the focal point <b>F</b> and reach a vertical staff at distance <b>u</b> from the lens; staff points S₃ (top), S₂ (middle), S₁ (bottom); intercept <b>s</b>. Below: <b>d</b> = axis of instrument to objective lens; <b>f</b> = objective lens to F." },
        { k: "h", t: "Derivation (p.207–208)" },
        { k: "steps", items: [
          "For the objective lens: 1/f = 1/u + 1/v  —① (p.207)",
          "From similar triangles: s/u = i/v  ⇒  1/v = s/(u·i)  —② (p.207–208)",
          "From ① and ②: 1/f = 1/u + s/(u·i) = (1/u)[1 + s/i] (p.208)",
          "u = f [1 + s/i] (p.208)",
          "Distance between object and instrument: D = u + d (p.208)",
          "D = f(1 + s/i) + d = f + (f·s)/i + d (p.208)",
          "D = (f/i)·s + (f + d) (p.208)",
          "Tacheometric distance equation: <b>D = Ks + C</b>, where f/i = multiplying constant K and f + d = additive constant C. (p.208)",
        ] },
        { k: "def", term: "Multiplying constant K = f/i", t: "Also called the <b>stadia interval factor</b>. Its value depends upon the stadia interval and the principal focal length of the objective. (p.208)" },
        { k: "note", t: "★ <b>Important:</b> for ease in calculation of distance the stadia wires are spaced such that the multiplying constant <b>K = 100</b>. (p.208)" },
        { k: "def", term: "Additive constant C = f + d", t: "Represents the <b>net distance between the instrument and the focus</b>. (p.209)" },
        { k: "eg",
          title: "Notes example — Horizontal distance with a horizontal sight",
          given: "Determine the horizontal distance between instrument and staff station. The following readings were taken with line of sight horizontal and staff held vertical: 0.950, 1.285, 1.620. K = 100, C = 0.15.",
          steps: [
            { t: "Staff intercept", w: "s = 1.620 − 0.950 = 0.67" },
            { t: "Distance equation", w: "D = Ks + C\nD = 0.67 (100) + 0.15 = 67.15" },
          ],
          ans: "D = 67.15 m (p.209)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Poori derivation ka core ek hi baat hai: similar triangles se s/u = i/v. Lens formula usme daalo to u = f(1 + s/i) aata hai, aur instrument ke axis se lens tak ka d jod do. Result ke do hisse hain — ek hissa s ke saath badhta hai (f/i)·s, aur ek hissa fixed hai (f + d). Isliye K ko \"multiplying\" aur C ko \"additive\" constant kehte hain. K = 100 rakhne ka matlab: intercept × 100 = distance, mental maths mein ho jaata hai." },
        { k: "p", t: "Stadia hair method mein <b>i fixed</b> hai (wires diaphragm par fixed hain), isliye parallactic angle α fixed hai; staff jitna door, intercept s utna bada. Free check: middle reading = upper aur lower ka mean hona chahiye — is example mein (0.950 + 1.620)/2 = 1.285 ✓." },
        { k: "trap", t: "s is <b>upper − lower</b> stadia reading, never the middle (cross-hair) reading. Using 1.285 instead of 0.67 here would give a meaningless distance. And C is <b>added after</b> multiplying: D = K·s + C, not K·(s + C)." },
        { k: "real", t: "When the instrument's K and C are not engraved or are in doubt, they are found on site by sighting a staff at two taped distances and solving D = Ks + C twice (see Example 9.1 earlier in this chapter)." },
      ],
    },

    /* ---------------------------------------------------------------- 3 */
    {
      n: "", title: "Inclined line of sight — staff held vertical (notes)", hi: "झुकी दृष्टि रेखा — स्टाफ ऊर्ध्वाधर",
      blocks: [
        { k: "h", t: "📘 Notes — p.209–210" },
        { k: "h", t: "Case 1 — line of sight inclined upward, staff held vertical (p.209–210)" },
        { k: "p", t: "Figure (p.209): instrument on tripod on sloping ground, instrument height marked <b>BS</b> at left; horizontal dashed line through the instrument axis marked <b>HOI</b>; line of sight inclined upward at angle <b>θ</b>. Vertical staff at right with readings S₃ (top, point A), S₂ (middle, point C), S₁ (lower, point B), and staff foot <b>D</b> on the ground. Central sight line from instrument to C labelled <b>L</b>. A line A′B′ through C perpendicular to the line of sight (90° at C), A′ above-left, B′ below-right; angle θ between AB and A′B′ at C. Right side: <b>s</b> = intercept S₃–S₁; <b>h</b> = from C (S₂) down to staff foot D; <b>V</b> = from C down to HOI. Horizontal distance <b>D</b> from instrument to staff at the bottom." },
        { k: "eq", expr: "RL of D = HOI + V − h", where: [
          ["HOI", "height (RL) of instrument axis"],
          ["V", "vertical distance from HOI to central hair point C"],
          ["h", "central hair reading (C to staff foot)"],
        ] },
        { k: "steps", items: [
          "A′B′ = A′C + CB′ = AC cosθ + CB cosθ (p.209)",
          "A′B′ = (AC + CB) cosθ ⇒ <b>A′B′ = s cosθ</b> (p.209)",
          "Inclined distance: L = K s cosθ + C (p.209)",
          "D = L cosθ ⇒ D = (Ks cosθ + C) cosθ (p.209)",
          "<b>D = Ks cos²θ + C cosθ</b> (p.209)",
          "Vertical distance: V = L sinθ = (Ks cosθ + C) sinθ (p.210)",
          "V = Ks cosθ·sinθ + C sinθ = ½ Ks (2 cosθ·sinθ) + C sinθ (p.210)",
          "<b>V = ½ Ks sin2θ + C sinθ</b> (p.210)",
        ] },
        { k: "eq", expr: "D = Ks cos²θ + C cosθ", where: [] },
        { k: "eq", expr: "V = ½ Ks sin2θ + C sinθ", where: [] },
        { k: "h", t: "Case 2 — line of sight inclined downward, staff held vertical (p.210)" },
        { k: "p", t: "Figure (p.210): instrument on tripod on high ground at left, ground sloping down to the right; horizontal line from the instrument labelled <b>HOI</b>, with <b>D</b> (horizontal distance) along it to the staff; line of sight inclined <b>downward</b> at θ below HOI. Vertical staff at right with A (upper), C (middle, on line of sight), B (lower) and foot <b>D</b>; line A′B′ through C perpendicular to the line of sight, angle θ marked. Right side: <b>V</b> = from HOI level down to C; <b>h</b> = from C down to staff foot D." },
        { k: "eq", expr: "RL of D = HOI − V − h", where: [] },
        { k: "list", items: [
          "A′B′ = AB cosθ (p.210)",
          "<b>D = (Ks cosθ + C) cosθ</b> (p.210)",
          "<b>V = (Ks cosθ + C) sinθ</b> (p.210)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Staff vertical hai lekin line of sight jhuki hui hai, isliye staff line of sight ke perpendicular nahi hai. Jo intercept s padha, uska \"effective\" perpendicular hissa A′B′ = s cosθ hai — pehla cosθ yahin se aata hai. Phir inclined distance L ko horizontal mein resolve karne par doosra cosθ aata hai — isliye D mein cos²θ. V ke liye L ko sinθ se resolve karo, aur 2 sinθ cosθ = sin2θ se ½ Ks sin2θ ban jaata hai." },
        { k: "p", t: "Upward aur downward dono cases mein D aur V ke formula same hain; sirf RL ka sign badalta hai — elevation mein HOI + V − h, depression mein HOI − V − h." },
        { k: "trap", t: "Students write D = Ks cosθ (only one cosine) — wrong. With the staff <b>vertical</b> it is <b>cos²θ</b> on the Ks term but only <b>cosθ</b> on C. Second trap: in a depression (downward sight) V is <b>subtracted</b> from HOI; adding it gives a ground RL higher than the instrument, which is impossible for a downhill sight." },
        { k: "real", t: "Staff-vertical is how almost all field tacheometry is done, because a staffman can hold a staff plumb with a bubble but cannot judge 'perpendicular to the line of sight'." },
      ],
    },

    /* ---------------------------------------------------------------- 4 */
    {
      n: "", title: "Inclined line of sight — staff held normal (notes)", hi: "झुकी दृष्टि रेखा — स्टाफ दृष्टि रेखा के लंबवत",
      blocks: [
        { k: "h", t: "📘 Notes — p.210–211" },
        { k: "h", t: "Case 1 — line of sight inclined upward (notes: \"vertically upward\"), staff normal (p.210–211)" },
        { k: "p", t: "Figure (p.211): instrument at <b>O</b> on tripod; horizontal dashed line through O (HOI); line of sight OC inclined upward at θ, length <b>L</b>. Staff held <b>normal</b> to the line of sight (inclined staff) with A (top), C (middle), B (lower) and foot <b>E</b> on the ground; angle θ marked at C between staff and vertical. Verticals dropped from C to F′ and from E to F on the horizontal line; F′F marked <b>h sinθ</b>. <b>s</b> along the staff A to B; <b>h</b> along the staff C to E. Right: <b>V</b> = vertical from C level to HOI; <b>h cosθ</b> = vertical from C level to E level. Horizontal distance <b>D</b> from O to F at the bottom." },
        { k: "steps", items: [
          "OC = L (p.211)",
          "sinθ = lamb/karn (perpendicular/hypotenuse) ⇒ lamb = karn × sinθ ⇒ <b>FF′ = h sinθ</b> (p.211)",
          "Staff normal, so the full intercept is perpendicular to the sight: L = Ks + C (p.211)",
          "D = OF′ + F′F = L cosθ + h sinθ (p.211)",
          "<b>D = (Ks + C) cosθ + h sinθ</b> (p.211)",
          "V = L sinθ ⇒ <b>V = (Ks + C) sinθ</b> (p.211)",
          "RL of point E = HOI + V − h cosθ (p.211)",
        ] },
        { k: "eq", expr: "D = (Ks + C) cosθ + h sinθ ;  V = (Ks + C) sinθ ;  RL of E = HOI + V − h cosθ", where: [
          ["h", "central hair reading (along the inclined staff)"],
        ] },
        { k: "h", t: "Case 2 — line of sight inclined downward (notes: \"vertical downward\"), staff normal (p.211)" },
        { k: "p", t: "Figure (p.211): instrument at <b>O</b> on high ground; horizontal line from O labelled <b>HOI</b> ending at points F and C′ at the staff; line of sight OC inclined downward at θ, length <b>L</b>; ground (hatched) slopes down to the right. Staff normal to the line of sight with A (top), C (middle), B (lower) and foot on the ground; verticals from the staff foot and from C to F and C′; the small horizontal gap between them marked <b>h sinθ</b> at the bottom. Right: <b>V</b> = from HOI down to C; <b>s</b> along staff A to B; <b>h</b> along staff from C to foot. Horizontal distance <b>D</b> from O to the staff foot." },
        { k: "steps", items: [
          "<b>RL of D = HOI − V − h cosθ</b> (p.211)",
          "L = Ks + C (p.211)",
          "OF′ = L cosθ = (Ks + C) cosθ (p.211)",
          "D = OF′ − FF′ ⇒ <b>D = (Ks + C) cosθ − h sinθ</b> (p.211)",
          "V = L sinθ ⇒ <b>V = (Ks + C) sinθ</b> (p.211)",
        ] },
        { k: "cmp", t: "All four inclined-sight cases (p.209–211)", cols: ["Horizontal distance D", "Vertical V", "RL of staff station"], rows: [
          ["Staff vertical, elevation", "Ks cos²θ + C cosθ", "½ Ks sin2θ + C sinθ", "HOI + V − h"],
          ["Staff vertical, depression", "(Ks cosθ + C) cosθ", "(Ks cosθ + C) sinθ", "HOI − V − h"],
          ["Staff normal, elevation", "(Ks + C) cosθ + h sinθ", "(Ks + C) sinθ", "HOI + V − h cosθ"],
          ["Staff normal, depression", "(Ks + C) cosθ − h sinθ", "(Ks + C) sinθ", "HOI − V − h cosθ"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Staff normal ho to staff already line of sight ke perpendicular hai, isliye intercept ko cosθ se correct nahi karna padta — seedha L = Ks + C. Lekin staff jhuka hua hai, to uska foot (E) central hair point C ke theek neeche nahi hai: foot horizontal mein h sinθ khisak jaata hai aur vertical mein sirf h cosθ neeche hota hai. Elevation mein staff peeche (instrument se door) jhukta hai to h sinθ <b>jodo</b>; depression mein foot instrument ki taraf aata hai to h sinθ <b>ghatao</b>." },
        { k: "trap", t: "In the staff-normal case students copy \"− h\" from the staff-vertical RL formula. With the staff normal, the vertical drop from C to the foot is <b>h cosθ</b>, not h. And the extra <b>± h sinθ</b> term in D is easy to forget — it is the only place where the central hair reading enters the distance." },
      ],
    },

    /* ---------------------------------------------------------------- 5 */
    {
      n: "", title: "Notes numericals — staff vertical and staff normal", hi: "संख्यात्मक प्रश्न — स्टाफ ऊर्ध्वाधर व लंबवत",
      blocks: [
        { k: "h", t: "📘 Notes — p.212–213" },
        { k: "p", t: "Figure (p.212): instrument at P on rising ground, instrument height 1.490 marked at left; horizontal line from the instrument to the staff at Q; line of sight inclined upward at 4°30′; vertical staff at Q with readings 1.351 (top), 0.998 (middle), 0.645 (lower); <b>h</b> from 0.998 down to the ground point on the staff; <b>V</b> from the 0.998 level down to the horizontal line (HOI). \"P = 200.410\" below the instrument; D from P to Q at the bottom." },
        { k: "eg",
          title: "Notes example — Staff vertical, angle of elevation (distance and RL)",
          given: "Determine the distance between instrument station P and staff station Q from the following data: B.S = 1.490, vertical angle = +4°30′, staff readings (staff vertical) = 0.645, 0.998, 1.351. Also determine RL of Q if RL of P = 200.410 m. Take K = 100, C = 0.",
          steps: [
            { t: "Staff intercept", w: "s = 1.351 − 0.645 = 0.706" },
            { t: "Horizontal distance", w: "D = Ks cos²θ + C cosθ\nD = 100 × 0.706 cos² 4°30′ = 70.16 m" },
            { t: "Vertical distance", w: "V = ½ Ks sin2θ + C sinθ\n= ½ × 100 × 0.706 sin(2 × 4°30′) + 0\nV = 5.52 m" },
            { t: "RL of Q", w: "RL of Q = HOI + V − h\n= (200.410 + 1.490) + 5.52 − 0.998\n= 206.42 m" },
          ],
          ans: "D = 70.16 m; RL of Q = 206.42 m (p.212)",
        },
        { k: "p", t: "Figure (p.213): instrument on tripod; horizontal line through the instrument marked <b>HOI = 200</b>; line of sight <b>L</b> inclined upward at 29°30′; staff held normal to the line of sight with readings 3.57 (top, A), 2.64 (C, middle), 1.71 (B, lower); θ marked near the staff foot; verticals dropped to F and Q′ on the HOI line; right side <b>h cosθ</b> marked vertically and <b>V</b> from HOI up to the C level." },
        { k: "eg",
          title: "Notes example — Staff held normal, angle of elevation",
          given: "Following observations were taken with a tacheometer at station P to the station Q, with the staff held normal to the line of sight. Staff readings are 1.71, 2.64, 3.57 and angle of inclination α = 29°30′. Determine the horizontal distance between P and Q; also determine RL of Q if the line of collimation is at RL 200 m. Take K = 100, C = 0.5.",
          steps: [
            { t: "Intercept (used in the working)", w: "s = 3.57 − 1.71 = 1.86" },
            { t: "Horizontal distance", w: "D = (Ks + C) cosθ + h sinθ\nD = (100 × 1.86 + 0.5) cos 29°30′ + 2.64 sin 29°30′\nD = 186.5 × 0.870 + 1.29\nD = 163.62 m" },
            { t: "Vertical distance", w: "V = (K × 1.86 + 0.5) sin 29°30′\nV = 91.83 m" },
            { t: "RL of Q", w: "RL = 200 + 91.83 − 2.64 cos 29°30′\nRL = 289.53" },
          ],
          ans: "D = 163.62 m; RL of Q = 289.53 m (p.213)",
        },
        { k: "note", t: "<b>Check:</b> the final answers are right — D = 186.5 × cos29°30′ (0.87036) + 2.64 × sin29°30′ (0.49242) = 162.32 + 1.30 = <b>163.62 m</b>, V = 91.84 m, RL = 200 + 91.84 − 2.30 = <b>289.54 m</b> (≈ 289.53). Only the written intermediate line \"186.5 × 0.870 + 1.29\" is rounded: it evaluates to 163.55; carry cos29°30′ to more decimals to get the notes' 163.62. (p.213)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har numerical mein pehla kaam: s = upper − lower, aur check karo ki middle reading dono ka mean hai — (0.645 + 1.351)/2 = 0.998 ✓, (1.71 + 3.57)/2 = 2.64 ✓. Phir dekho staff <b>vertical</b> hai ya <b>normal</b>, aur sight upar hai ya neeche — isi se table ka sahi row chunna hai. Pehle example mein HOI = RL of P + instrument height (1.490); doosre mein line of collimation ka RL seedha 200 diya hai." },
        { k: "trap", t: "In the staff-normal example the RL uses <b>h cosθ</b> (2.64 cos29°30′), not 2.64 directly; and D carries the extra <b>+ h sinθ</b>. Using the staff-vertical formulas on this data gives the wrong D and RL. Also: in the first example HOI is 200.410 + 1.490, not 200.410." },
        { k: "real", t: "θ near 30° (second example) is a very steep sight; in such terrain the cos θ and sin θ values must be taken to at least four decimals, because any rounding is multiplied by the 186.5 m sight." },
      ],
    },

    /* ---------------------------------------------------------------- 6 */
    {
      n: "", title: "Gradient between two staff stations (notes)", hi: "दो बिंदुओं के बीच ढाल",
      blocks: [
        { k: "h", t: "📘 Notes — p.213–215" },
        { k: "eg",
          title: "Notes example — Average gradient between A and B from a tacheometer at C",
          given: "To determine the gradient between two points A and B, a tacheometer was set up at a point C and the following observations were taken keeping the staff vertical. Staff at A: vertical angle +4°20′00″, stadia readings 1.300, 1.610, 1.920. Staff at B: vertical angle +0°10′40″, stadia readings 1.100, 1.410, 1.720. If the horizontal angle ∠ABC is 35°20′, determine the average gradient between A and B. K = 100, C = 0.",
          steps: [
            { t: "Vertical distance for A (s = 0.62)", w: "V = (Ks cosθ + C) sinθ\nV = (100 × 0.62 × 0.9971 + 0) sin 4°20′\nV_CA = 4.67 m" },
            { t: "Vertical distance for B (s = 0.62)", w: "V = (Ks cosθ + C) sinθ\nV = (100 × 0.62 cos 0°10′40″ + 0) sin 0°10′40″\nV_CB = 0.192" },
            { t: "Horizontal distance for A", w: "H_CA = D = Ks cos²θ + C cosθ\nD = 100 × 0.62 cos²(4°20′) = 61.64 m" },
            { t: "Horizontal distance for B", w: "H_CB = D = Ks cos²θ + C cosθ\n= 100 × 0.62 cos²(0°10′40″) = 61.99 m" },
            { t: "Triangle ACB — cosine rule (\"उनका दुगना जिनके बीच में angle है\")", w: "2(x₁ × x₂) cosθ = x₁² + x₂² − x₃²\ncosθ = (x₁² + x₂² − x₃²)/(2x₁x₂)\ncos 35°20′ = (61.64² + 61.69² − x₃²)/(2 × 61.64 × 61.69)\nx₃ = 37.52 m" },
            { t: "Gradient (first way)", w: "Gradient = V_AB/H_AB = (4.67 − 0.192)/37.52 = 0.1193 m" },
            { t: "RL of A and B (HOI taken as 100)", w: "RL of A = HOI + V − h = 100 + 4.67 − 1.61 = 103.06\nRL of B = HOI + V − h = 100 + 0.192 − 1.41 = 98.782" },
            { t: "Gradient (from RLs)", w: "Gradient = (103.06 − 98.782)/37.52 = 0.113 m" },
          ],
          ans: "AB = 37.52 m; gradient = 0.113 (notes' final working) (p.213–215)",
        },
        { k: "p", t: "Figure (p.215): triangle ACB with the angle at <b>C = 35°20′</b>; side CA = 61.64 m (x₁); side CB = 61.99 m (x₂); side AB = x₃." },
        { k: "note", t: "<b>Check:</b> (1) The cosine-rule line writes 61.69, but the notes' own H_CB is 61.99 m and x₃ = 37.52 m only comes out with 61.99 (61.69 would give 37.43 m) — read 61.69 as 61.99. (2) The 35°20′ is used as the angle at the instrument station C (∠ACB), as the figure shows, although the question text says ∠ABC. (3) Final gradient: (103.06 − 98.782)/37.52 = 4.278/37.52 = <b>0.114</b> (about 1 in 8.8), not 0.113. (4) The first way, (V_A − V_B)/AB = 0.1193, ignores the different central-hair readings at A (1.61) and B (1.41), so it is the slope between the two sighted staff points, not between the ground points; the RL method is the correct one. (5) A gradient is a ratio, so it has no unit (\"m\" is not needed). HOI = 100 is an assumed value — it cancels in the RL difference. (p.215)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Instrument C par hai aur A, B dono ko dekha gaya. Har staff se do cheezein milti hain — horizontal distance (CA, CB) aur RL. Plan mein triangle ACB banta hai jiska angle C par measured hai, to cosine rule se AB nikalta hai. Gradient = (RL of A − RL of B) / AB. HOI kuch bhi maan lo (yahan 100), difference mein cancel ho jaata hai." },
        { k: "trap", t: "Do not take gradient = (V_A − V_B)/AB. V is measured to the <b>central-hair point</b> on the staff; the two staffs read different middle readings (1.61 and 1.41), so the h values must be subtracted first — i.e. always go via RLs. And AB is the horizontal distance found by the cosine rule, not CA − CB." },
        { k: "real", t: "This is exactly how the grade of a proposed road or drain line between two points across a nala is checked from one instrument station, without chaining either line." },
      ],
    },

    /* ---------------------------------------------------------------- 7 */
    {
      n: "", title: "Movable hair method and the micrometer (notes)", hi: "मूवेबल हेयर विधि और माइक्रोमीटर",
      blocks: [
        { k: "h", t: "📘 Notes — p.215–217 (marked \"not-imp\" in the notes)" },
        { k: "p", t: "Figure (p.215, first): objective lens with stadia interval <b>i</b> (double-arrow) on the left; three sets of rays from the lens diverging at parallactic angles <b>α₁, α₂, α₃</b> (increasing) to three vertical staffs at increasing distances; all three staffs show the <b>same intercept s</b> between the top line S₃ and bottom line S₁." },
        { k: "p", t: "Figure (p.215, second): movable-hair diaphragm — rectangular frame with screws at top and bottom; inner sliding frames carrying the stadia wires and a fixed central horizontal line. Labels: \"stadia wires (इन्हें change करते हैं — these are changed)\" and \"central crosshair (इसे const रखते हैं — this is kept constant)\"." },
        { k: "list", items: [
          "In the movable hair method, the <b>staff intercept is kept fixed</b> and the <b>parallactic angle (α₁, α₂, α₃) changes</b> with the horizontal distance between staff and instrument. (p.216)",
          "The diaphragm has an arrangement for measuring the stadia interval (i) accurately. Each hair of the stadia diaphragm can be moved easily and independently by a separate sliding frame. (p.216)",
        ] },
        { k: "note", t: "★ <b>Important:</b> in this method <b>s is fixed and i changes</b>, whereas in the stadia method <b>i remains constant and s changes</b>. (p.216)" },
        { k: "p", t: "The stadia interval (i) is measured with an instrument called <b>micrometer screws</b>. If the pitch of the screw is <b>p</b> and <b>m</b> revolutions of the micrometer are made: (p.216)" },
        { k: "eq", expr: "i = m p   ⇒   D = Ks + C = (f / (m p)) s + C", where: [
          ["m", "number of revolutions of the micrometer"],
          ["p", "pitch of the micrometer screw"],
          ["f", "focal length of the object glass"],
        ] },
        { k: "eg",
          title: "Notes example — Movable hair (micrometer) tacheometer: K, C and D",
          given: "A theodolite was used to determine the horizontal distance of a point from the instrument station. The micrometer readings of the drum were respectively 3.425 and 3.930 when the staff intercept was 3 m. The micrometer screw had 100 threads to 1 cm. The focal length of the object glass was 225 mm. The distance of the instrument axis from the object glass was measured as 200 mm. Determine K, C and D.",
          steps: [
            { t: "Revolutions", w: "m = 3.425 + 3.930 = 7.355" },
            { t: "Pitch and intercept", w: "p = 1/100 cm = 0.01 cm\ns = 3 m" },
            { t: "Multiplying constant", w: "K = f/(mp) = 22.5 cm/(7.355 × 0.01) = 305.91" },
            { t: "Additive constant", w: "C = f + d = 22.5 + 20 = 42.5 cm" },
            { t: "Distance", w: "D = Ks + C ⇒ 305.91 × 3 + 42.5 × 10⁻² m" },
          ],
          ans: "K = 305.91; C = 42.5 cm; D = 918.125 m (p.217)",
        },
        { k: "note", t: "<b>Check:</b> 305.91 × 3 + 0.425 = 917.73 + 0.425 = <b>918.155 m</b>, not 918.125 m (K = 22.5/0.07355 = 305.914, so D ≈ 918.17 m without rounding K). K = 305.91 and C = 42.5 cm (0.425 m) are correct. The notes take m as the <b>sum</b> of the two drum readings, i.e. each reading is the displacement of one stadia hair from the central hair; if both readings were of the same drum on one hair, the difference would be used instead. (p.217)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Stadia method ulta karke socho: wahan wires fixed, staff par intercept badalta hai. Movable hair method mein staff par do targets fixed doori (s) par lage hain, aur observer micrometer screw ghuma kar stadia wires ko un targets par bisect karta hai. Jitne revolution (m) ghumaye, utna i = m × p. Staff door ho to wires ko kam kholna padega (i chhota), isliye K = f/i bada ho jaata hai — har reading ke liye K alag hai, aur D = (f/mp)·s + C." },
        { k: "trap", t: "Unit mix-up is the usual loss of marks here: f in mm, p in cm, C in cm, D in m. Convert f = 225 mm to 22.5 cm before dividing by mp (in cm), and convert C = 42.5 cm to 0.425 m before adding it to Ks (in m)." },
        { k: "real", t: "Because every sight needs careful micrometer turning, this method is slow and, as the notes mark it, \"not-imp\" for exams compared with the stadia method; it appears mainly as a theory question on what is fixed (s) and what varies (i, α)." },
      ],
    },

    /* ---------------------------------------------------------------- 8 */
    {
      n: "", title: "Notes revision — Tacheometry (p.205–217)", hi: "पुनरावृत्ति — टैकियोमेट्री",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "✅ Tacheometry = optical distance measurement (tachymetry / telemetry); less accurate than chain on flat ground, more accurate on rough ground. (p.205)",
          "✅ Tacheometer = transit theodolite + stadia diaphragm (2 stadia wires equally above and below the horizontal cross hair). (p.205)",
          "✅ Characteristics: K = 100, C = 0, high eyepiece magnification. (p.205)",
          "✅ Stadia rod (vertical stave): 5–15 m, graduated in decimals of m; normal levelling staff up to 100 m, stadia rod for long reach / indistinct readings. (p.206)",
          "✅ Methods: stadia hair method; movable hair method. (p.206)",
          "✅ D = Ks + C; K = f/i (multiplying constant, stadia interval factor); C = f + d (additive constant, net distance between instrument and focus). (p.206–209)",
          "✅ Derivation: 1/f = 1/u + 1/v, s/u = i/v ⇒ u = f(1 + s/i); D = u + d. (p.207–208)",
          "✅ Stadia hair method: i and α constant, s varies. (p.207)",
          "✅ Horizontal sight example: s = 0.67, D = 67.15 m. (p.209)",
          "✅ Staff vertical, elevation: D = Ks cos²θ + C cosθ; V = ½ Ks sin2θ + C sinθ; RL = HOI + V − h. (p.209–210)",
          "✅ Staff vertical, depression: D = (Ks cosθ + C) cosθ; V = (Ks cosθ + C) sinθ; RL = HOI − V − h. (p.210)",
          "✅ Staff normal, elevation: D = (Ks + C) cosθ + h sinθ; V = (Ks + C) sinθ; RL = HOI + V − h cosθ. (p.211)",
          "✅ Staff normal, depression: D = (Ks + C) cosθ − h sinθ; V = (Ks + C) sinθ; RL = HOI − V − h cosθ. (p.211)",
          "✅ Example: θ = +4°30′, s = 0.706 → D = 70.16 m, V = 5.52 m, RL of Q = 206.42 m. (p.212)",
          "✅ Example (staff normal): θ = 29°30′, s = 1.86, K = 100, C = 0.5 → D = 163.62 m, V = 91.83 m, RL = 289.53. (p.213)",
          "✅ Gradient example: CA = 61.64 m, CB = 61.99 m, angle at C 35°20′ → AB = 37.52 m; RL A = 103.06, RL B = 98.782; notes' gradient 0.113 (re-worked 0.114). (p.213–215)",
          "✅ Movable hair method: s fixed, i (and α) changes; each hair moved by a separate sliding frame. (p.215–216)",
          "✅ i = mp; D = (f/mp)s + C. (p.216)",
          "✅ Micrometer example: m = 7.355, p = 0.01 cm, K = 305.91, C = 42.5 cm; notes' D = 918.125 m (re-worked 918.155 m). (p.217)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
