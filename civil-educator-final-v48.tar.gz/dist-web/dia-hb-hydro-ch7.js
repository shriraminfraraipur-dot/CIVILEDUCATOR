/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook, Chapter 7
   (Streamflow Measurement).
   ------------------------------------------------------------
   Same conventions as dia-hb-sa1.js: strokes are currentColor so
   both themes work, meaning-carrying strokes use .hi (marker) or
   .ac (accent), unique marker-id prefix so figures never collide.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hymk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 7.4 MID-SECTION METHOD */
  "hb-hydro-midsection": {
    label: "Mid-section (area-velocity) method — sub-areas at each velocity vertical",
    svg: `<svg viewBox="0 0 680 310" role="img" aria-label="A river cross-section with the water surface at top and a bowl shaped bed below. Four velocity verticals divide the section into four shaded sub-areas a1 to a4, each bounded by the midpoint between neighbouring verticals, except the two end sub-areas which extend out to the bank. A small rightward velocity arrow sits at 0.6 of the depth on each vertical, and the discharge of each sub-area is its effective width times its depth times its velocity, summed to give the total discharge.">
      ${hymk("ms")}

      <text class="lb" x="340" y="20" text-anchor="middle">CROSS-SECTION DIVIDED INTO SUB-AREAS, ONE PER VELOCITY VERTICAL</text>

      <!-- width labels along the top -->
      <line class="thin" x1="40" y1="52" x2="40" y2="60"/>
      <line class="thin" x1="140" y1="52" x2="140" y2="60"/>
      <line class="thin" x1="240" y1="52" x2="240" y2="60"/>
      <line class="thin" x1="360" y1="52" x2="360" y2="60"/>
      <line class="thin" x1="480" y1="52" x2="480" y2="60"/>
      <line class="thin" x1="600" y1="52" x2="600" y2="60"/>
      <text class="lb" x="90" y="48" text-anchor="middle">W1</text>
      <text class="lb" x="190" y="48" text-anchor="middle">W2</text>
      <text class="lb" x="300" y="48" text-anchor="middle">W3</text>
      <text class="lb" x="420" y="48" text-anchor="middle">W4</text>
      <text class="lb" x="540" y="48" text-anchor="middle">W5</text>

      <!-- water surface -->
      <line class="dash" x1="40" y1="60" x2="600" y2="60"/>
      <text class="lb" x="615" y="64">▽ W.S.</text>

      <!-- sub-area fills (end segments soft, interior softa, alternating for clarity) -->
      <path class="soft" d="M40,60 L140,111.6 L190,136.8 L190,60 Z"/>
      <path class="softa" d="M190,60 L190,136.8 L240,162 L300,139.2 L300,60 Z"/>
      <path class="soft" d="M300,60 L300,139.2 L360,116.4 L420,96.6 L420,60 Z"/>
      <path class="softa" d="M420,60 L420,96.6 L480,76.8 L600,60 Z"/>

      <!-- bed profile -->
      <path class="s" d="M40,60 L140,111.6 L240,162 L360,116.4 L480,76.8 L600,60"/>

      <!-- bank markers -->
      <circle class="acf" cx="40" cy="60" r="3.5"/>
      <circle class="acf" cx="600" cy="60" r="3.5"/>
      <text class="lb" x="40" y="76" text-anchor="middle">v=0</text>
      <text class="lb" x="600" y="76" text-anchor="middle">v=0</text>

      <!-- interior verticals (dashed) -->
      <line class="thin dash" x1="140" y1="60" x2="140" y2="111.6"/>
      <line class="thin dash" x1="240" y1="60" x2="240" y2="162"/>
      <line class="thin dash" x1="360" y1="60" x2="360" y2="116.4"/>
      <line class="thin dash" x1="480" y1="60" x2="480" y2="76.8"/>
      <circle class="acf" cx="140" cy="111.6" r="3.5"/>
      <circle class="acf" cx="240" cy="162" r="3.5"/>
      <circle class="acf" cx="360" cy="116.4" r="3.5"/>
      <circle class="acf" cx="480" cy="76.8" r="3.5"/>

      <!-- velocity arrows at 0.6y on each vertical -->
      <line class="hi" x1="140" y1="91" x2="166" y2="91" marker-end="url(#ms-m)"/>
      <line class="hi" x1="240" y1="121.2" x2="266" y2="121.2" marker-end="url(#ms-m)"/>
      <line class="hi" x1="360" y1="93.8" x2="386" y2="93.8" marker-end="url(#ms-m)"/>
      <line class="hi" x1="480" y1="70.1" x2="506" y2="70.1" marker-end="url(#ms-m)"/>
      <text class="em" x="172" y="95">v1</text>
      <text class="em" x="272" y="125">v2</text>
      <text class="em" x="392" y="98">v3</text>
      <text class="em" x="512" y="74">v4</text>

      <!-- depth labels -->
      <text class="lb" x="118" y="110" text-anchor="end">y1</text>
      <text class="lb" x="218" y="160" text-anchor="end">y2</text>
      <text class="lb" x="338" y="115" text-anchor="end">y3</text>
      <text class="lb" x="458" y="76" text-anchor="end">y4</text>

      <!-- sub-area labels -->
      <text class="em" x="115" y="90" text-anchor="middle">a1</text>
      <text class="em" x="245" y="115" text-anchor="middle">a2</text>
      <text class="em" x="360" y="90" text-anchor="middle">a3</text>
      <text class="em" x="500" y="60" text-anchor="middle" dy="14">a4</text>

      <!-- effective-width callout -->
      <text class="lb" x="115" y="200" text-anchor="middle">W̄1 (edge: squared-mean formula)</text>
      <text class="lb" x="245" y="222" text-anchor="middle">W̄2, W̄3 (interior: plain average)</text>
      <text class="lb" x="500" y="200" text-anchor="middle">W̄4 (edge: squared-mean formula)</text>

      <line class="gl" x1="20" y1="248" x2="660" y2="248"/>
      <text class="em" x="340" y="276" text-anchor="middle">aᵢ = W̄ᵢ · yᵢ · vᵢ        Q = Σ aᵢ</text>
      <text class="lb" x="340" y="296" text-anchor="middle">vᵢ is the point velocity read at 0.6y on that vertical (one-point method, shallow stream)</text>
    </svg>`,
    caption: "Each measured vertical “owns” a slice of the channel: its own depth, its own velocity, and an effective width shared with its neighbours. The two end verticals' width formula reaches all the way out to the bank, which is why it looks different from the plain average used for the interior ones &mdash; but every sub-area is still just <strong>width &times; depth &times; velocity</strong>, and the total discharge is just their sum.",
  },

});
