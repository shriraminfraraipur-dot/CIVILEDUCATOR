/* MACE Academy SOM notes — Pressure vessels: thin cylindrical and spherical shells, axial force, thick shells (Lamé), M p.224–225 — inserted into som chapter 7 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 7; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------- M p.224 (stresses) */
    {
      n: "",
      title: "MACE notes — Pressure vessels (shells): thin cylindrical shell stresses",
      hi: "दाब पात्र (शेल) — पतले बेलनाकार शेल के प्रतिबल",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.224" },
        { k: "p", t: "<b>★ Pressure Vessels (Shells) :- (Thick &amp; Thin)</b> (M p.224)" },
        { k: "def", term: "Thin shell (as in the notes)", t: "If the thickness of steel = <b>6 to 10% of diameter</b> of steel ------ <b>thin shell</b>. (M p.224)" },
        { k: "cmp", t: "Thin shells (M p.224)", cols: ["Type"], rows: [
          ["i)", "Cylindrical shell"],
          ["ii)", "Spherical shell (the notes first wrote \"Longitudinal\", struck it out and wrote \"spherical\")"],
        ] },
        { k: "h", t: "i] Cylindrical shell (M p.224)" },
        { k: "p", t: "Figure (M p.224): a thin cylinder drawn in perspective with one open end showing the circular wall section; the internal pressure <b>P</b> is marked inside the bore." },
        { k: "eq", expr: "σ_c = circumferential OR Hoop stress = Pd/2t", where: [
          ["P", "internal pressure"],
          ["d", "diameter of the shell"],
          ["t", "thickness of the shell wall"],
        ] },
        { k: "eq", expr: "σ_L = Longitudinal stress = Pd/4t" },
        { k: "eq", expr: "σ_R = Radial stress ≈ 0" },
        { k: "list", items: [
          "σ₁ = major principal stress",
          "σ₂ = intermediate principal stress",
          "σ₃ = minor principal stress",
          "(★) <b>σ_c &gt; σ_L &gt; σ_R</b> &nbsp;i.e.&nbsp; <b>σ₁ &gt; σ₂ &gt; σ₃</b> (boxed) — so σ₁ = σ_c, σ₂ = σ_L, σ₃ = σ_R. (M p.224)",
        ] },
        { k: "h", t: "★ Ratio of circumferential and longitudinal stress (M p.224)" },
        { k: "eq", expr: "σ_c/σ_L = (Pd/2t)/(Pd/4t) = 2   ;   σ_L/σ_c = 1/2 = 0.5", where: [
          ["σ_c/σ_L = 2", "(★) boxed in the notes"],
          ["σ_L/σ_c = 0.5", "(★) boxed in the notes"],
        ] },
        { k: "h", t: "★ Maximum shear stress in cylindrical shell (M p.224)" },
        { k: "eq", expr: "(★) τmax = Pd/4t   --- same as σ_L", where: [
          ["τmax", "maximum shear stress in the cylindrical shell (boxed in the notes)"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the MACE notes give τmax = <b>Pd/4t</b> (M p.224), while the older notes in this chapter give τ_max = (σ_h − σ_l)/2 = <b>Pd/8t</b> (p.17). Re-deriving with the three principal stresses σ₁ = Pd/2t, σ₂ = Pd/4t, σ₃ = σ_R ≈ 0: the <b>absolute</b> maximum shear = (σ₁ − σ₃)/2 = (Pd/2t − 0)/2 = <b>Pd/4t</b>, and the <b>in-plane</b> maximum (in the plane of the wall) = (σ₁ − σ₂)/2 = (Pd/2t − Pd/4t)/2 = <b>Pd/8t</b>. Both are correct for what they measure; the MACE value Pd/4t is the true (absolute) maximum shear and is the one to quote when a question asks for 'maximum shear stress' without saying 'in-plane'." },
        { k: "note", t: "<b>Source difference:</b> the MACE notes call a shell thin when t = 6 to 10% of d (M p.224); the older notes in this chapter use <b>t &lt; d/20</b>, i.e. t below 5% of d (p.17). Re-derivation: comparing the thin formula Pd/2t (internal d) with Lamé's bore hoop stress p(b² + a²)/(b² − a²), the thin formula reads about 5% low at t = 0.05d, 6% low at t = 0.06d and about 10% low at t = 0.10d. So t &lt; d/20 is the stricter, safer criterion and the one this handbook keeps; the 6–10% range of the notes is a looser practical limit where the thin formulas are still roughly usable (the error is small if the mean diameter d + t is used in place of d). In an exam, use the criterion the question states; if none, use t &lt; d/20 (d/t &gt; 20)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Thin shell me teen stress hote hain — hoop (σ_c), longitudinal (σ_L) aur radial (σ_R). Radial stress andar P se bahar 0 tak jaata hai, jo thin wall me hoop stress ke saamne bahut chhota hai, isliye ≈ 0 maan lete hain. Bache do stresses me hoop hamesha double hota hai (σ_c/σ_L = 2), isliye cylinder lambai ke along (longitudinal seam par) phatta hai, ends par nahi — derivation ke liye upar section 7.1 ka 'two cuts' wala explanation dekho." },
        { k: "p", t: "τmax = Pd/4t yaad rakhne ka trick notes me hi likha hai: <b>'same as σ_L'</b>. Ye isliye kyunki absolute τmax = (σ_c − 0)/2 = σ_c/2, aur σ_c/2 = σ_L." },
        { k: "trap", t: "Students mix up the two maximum shears. Pd/8t = (σ_c − σ_L)/2 is only the in-plane value; the absolute maximum, using σ_R ≈ 0 as σ₃, is Pd/4t. Read the question: 'maximum shear stress in the shell' (MACE answer) → Pd/4t." },
        { k: "real", t: "Boilers, water mains, penstocks and gas cylinders are all thin cylindrical shells: the longitudinal welded seam carries the hoop stress, so it is the seam inspected most carefully." },
      ],
    },

    /* ---------------------------------------------------- M p.224 (strains) */
    {
      n: "",
      title: "MACE notes — Strains and volumetric strain of a thin cylindrical shell",
      hi: "पतले बेलनाकार शेल की विकृतियाँ और आयतनिक विकृति",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.224" },
        { k: "eq", expr: "★ circumferential strain  ε_c = (Pd/4tE)(2 − μ)", where: [
          ["E", "Young's modulus of the shell material"],
          ["μ", "Poisson's ratio"],
        ] },
        { k: "eq", expr: "★ Longitudinal strain  ε_L = (Pd/4tE)(1 − 2μ)" },
        { k: "eq", expr: "★ volumetric strain for ★ incompressible fluid  ε_vol = (Pd/4tE)(5 − 4μ)" },
        { k: "eq", expr: "★ volumetric strain for ★ compressible fluid  ε_vol = (Pd/4tE)(5 − 4μ) − P/K", where: [
          ["K", "bulk modulus of the fluid"],
        ] },
        { k: "p", t: "Side note (M p.224): <b>K (Bulk mod) = P/ε_vol</b> &nbsp;⇒&nbsp; <b>ε_vol = P/K</b>." },
        { k: "p", t: "Re-derivation (matches the notes): ε_c = (σ_c − μσ_L)/E = (Pd/2t − μPd/4t)/E = (Pd/4tE)(2 − μ); ε_L = (σ_L − μσ_c)/E = (Pd/4tE)(1 − 2μ); ε_vol = 2ε_c + ε_L = (Pd/4tE)(4 − 2μ + 1 − 2μ) = (Pd/4tE)(5 − 4μ). The same three results appear in the older notes of this chapter (section 'Thin cylinders — shear, joint efficiency, strains…')." },
        { k: "note", t: "<b>Check:</b> the shell's own volumetric strain is (Pd/4tE)(5 − 4μ) whatever fluid it holds — it depends only on P. The term P/K is the <b>fluid's</b> volumetric strain (the notes' side note, ε_vol = P/K). The two are combined according to what is asked: <b>General Engineering Knowledge</b> — the extra volume of fluid that must be pumped in to raise the pressure to P is δV = V[(Pd/4tE)(5 − 4μ) + P/K] (the vessel grows <i>and</i> the fluid compresses, so the two strains <b>add</b>); the notes' '(5 − 4μ) − P/K' form is the difference of the two strains, i.e. the vessel's expansion less the fluid's compression. Use the sign that fits the quantity the question asks for." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Hoop strain se diameter badhta hai, longitudinal strain se length. Volume ∝ d²·L, isliye ε_vol = 2ε_c + ε_L — diameter wala strain do baar aata hai. (2 − μ) aur (1 − 2μ) me μ isliye aata hai kyunki dono stresses ek doosre ki direction me Poisson contraction dete hain." },
        { k: "p", t: "Fluid compressible ho to pressure badhane ke liye sirf vessel ka phailna hi nahi, fluid ka sikudna bhi bharna padta hai — isliye bulk modulus K wala term P/K aata hai." },
        { k: "trap", t: "Writing ε_vol = ε_c + 2ε_L (swapping the factor 2) is a common slip. The diameter appears squared in the volume, so it is 2ε_c + ε_L = (Pd/4tE)(5 − 4μ). Also: ε_L uses (1 − 2μ), not (1 − μ)." },
        { k: "real", t: "In a hydraulic pressure test, the pump keeps delivering water after the vessel is full before the gauge rises — that extra water fills the volume the shell gains (5 − 4μ term) plus the water's own compression (P/K term)." },
      ],
    },

    /* ---------------------------------------------------- M p.225 (sphere) */
    {
      n: "",
      title: "MACE notes — Thin spherical shell",
      hi: "पतला गोलाकार शेल",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.225" },
        { k: "h", t: "ii] Spherical shell (M p.225)" },
        { k: "eq", expr: "(★) σ_c = σ_L = Pd/4t   i.e.  σ_c/σ_L = 1  OR  σ_L/σ_c = 1", where: [
          ["σ_c, σ_L", "the two in-plane stresses of the sphere wall — equal in every direction"],
        ] },
        { k: "eq", expr: "(★) σ_c = σ_L > σ_R   --   σ_R ≈ 0" },
        { k: "eq", expr: "(★) ε_vol = 3·ε_d   --- 3 times of diametric strain", where: [
          ["ε_d", "diametric strain of the sphere"],
        ] },
        { k: "eq", expr: "★ ε_vol = (3Pd/4tE)(1 − μ)   ----- for incompressible fluid" },
        { k: "eq", expr: "★ ε_vol = (3Pd/4tE)(1 − μ) − P/K   --- for compressible fluid" },
        { k: "p", t: "Re-derivation (matches the notes): ε_d = (σ − μσ)/E = (Pd/4tE)(1 − μ); volume ∝ d³, so ε_vol = 3ε_d = (3Pd/4tE)(1 − μ). The older notes of this chapter give the same σ = pd/4t and ε_v = 3(1 − μ)·pd/(4tE)." },
        { k: "note", t: "<b>Check:</b> as for the cylinder, the P/K term is the fluid's own volumetric strain; for the extra volume of fluid to be pumped in, the vessel strain and the fluid strain add (General Engineering Knowledge) — see the note in the previous section." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Sphere ko kisi bhi direction me centre se kaato, har cut ek jaisa circle deta hai — isliye har direction me stress same, aur woh cylinder ke longitudinal stress (Pd/4t) jitna hai. Matlab same d aur t par sphere ka stress cylinder ke hoop stress ka aadha hota hai." },
        { k: "p", t: "Volume ∝ d³, isliye volumetric strain = 3 × diametric strain (cylinder me 2ε_c + ε_L tha, kyunki wahan length aur diameter alag the)." },
        { k: "trap", t: "Don't write Pd/2t for a sphere. Sphere: σ = Pd/4t (ratio σ_c/σ_L = 1); cylinder: hoop Pd/2t (ratio 2). And the sphere's volumetric strain is 3(1 − μ)·Pd/4tE, not (5 − 4μ)·Pd/4tE." },
        { k: "real", t: "Because a sphere needs only half the wall stress, large LPG and gas storage vessels (Horton spheres) are spherical, and cylindrical vessels are given hemispherical ends." },
      ],
    },

    /* ---------------------------------------------------- M p.225 (axial force) */
    {
      n: "",
      title: "MACE notes — Pressure vessel subjected to axial force (pull and push)",
      hi: "अक्षीय बल के अधीन दाब पात्र (खिंचाव और धक्का)",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.225" },
        { k: "p", t: "<b>★ Pressure vessel subjected to axial force</b> (M p.225)" },
        { k: "cmp", t: "Effect of an axial force on a closed pressure vessel (M p.225)", cols: ["What happens", "Circumferential stress"], rows: [
          ["• Axial pull", "→ suction effect<br>• internal pressure ↓↓", "(★) <b>σ_c = Compressive</b>"],
          ["• Axial push", "→ +ve hydrostatic pressure develops<br>• internal pressure ↑↑", "(★) <b>σ_c = Tensile</b>"],
        ] },
        { k: "list", items: [
          "Figure 1 (M p.225, axial pull): a rectangle (the vessel in elevation) with arrows at both ends pointing <b>outward</b> (pull); small red arrows on the top and bottom walls point <b>inward</b>, towards each other — the walls are drawn in (suction).",
          "Figure 2 (M p.225, axial push): the same rectangle with arrows at both ends pointing <b>inward</b> (push); small red arrows on the top and bottom walls point <b>outward</b> — the walls are pushed out by the raised internal pressure.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Vessel band hai aur fluid se bhara hai. <b>Pull</b> karne par vessel lamba hota hai, uska andar ka volume badhne ki koshish karta hai, lekin fluid utna hi hai — andar suction (pressure girta hai), walls andar khinchti hain, isliye hoop stress <b>compressive</b>. <b>Push</b> karne par vessel chhota hota hai, fluid dab jaata hai, andar ka pressure badhta hai, walls bahar dhakelti hain — hoop stress <b>tensile</b>." },
        { k: "trap", t: "Do not reason 'pull = tension everywhere'. An axial pull makes the <b>longitudinal</b> stress tensile, but the <b>circumferential</b> stress it induces through the trapped fluid is compressive; an axial push gives tensile hoop stress. The notes box exactly this opposite pairing." },
        { k: "real", t: "A sealed, liquid-filled pipe or hydraulic cylinder that is pulled or pushed along its axis (by thermal movement, settlement or a jack) has its internal pressure changed by that load, so the hoop stress in its wall changes sign with the direction of the axial force — worth remembering before pressure-testing or jacking a closed, full vessel." },
      ],
    },

    /* ---------------------------------------------------- M p.225 (Lamé) */
    {
      n: "",
      title: "MACE notes — Thick shells by Lamé's theory",
      hi: "मोटे शेल — लामे का सिद्धांत",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.225" },
        { k: "p", t: "<b>Thick shells → Lamé's theory</b> (M p.225)" },
        { k: "def", term: "i) Hoop stress", t: "• <b>maximum @ internal face</b><br>• <b>minimum @ external face</b><br>[i.e. internal to external stress चं जं transition OR stress distribution असतं ते <b>Hyperbolic</b> असतं] — Marathi memory line; English: \"the transition, or distribution, of stress from the internal face to the external face is <b>hyperbolic</b>\". (M p.225)" },
        { k: "def", term: "ii) Longitudinal stress", t: "<b>Uniform &amp; Tensile</b>. (M p.225)" },
        { k: "def", term: "iii) Radial stress", t: "Exists due to <b>pressure difference (Δp)</b>. (M p.225)" },
        { k: "p", t: "Figure (M p.225): cross-section of a thick cylinder — two concentric circles; internal pressure <b>P₁</b> marked in the inner bore and <b>P₂</b> at the outer face. Across the wall thickness a red hatched curved (hyperbolic) stress diagram is drawn, tallest at the inner face and smallest at the outer face. Note beside it: \"<b>ΔP Results → Radial Stress</b>\"." },
        { k: "note", t: "<b>Link to the existing section:</b> the hyperbolic shape is the Lamé equation σ_θ = A + B/r² given earlier in this chapter (section 'Thick cylinders — Lamé's theory') — hoop stress falls off as 1/r² from the bore to the outside, which is why it is maximum at the internal face. <b>General Engineering Knowledge:</b> for a thick cylinder with closed ends, the longitudinal stress equals Lamé's constant A, the same at every radius — the 'uniform &amp; tensile' of the notes." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Thick wall me stress thickness ke across uniform nahi rehta. Andar wali layer pressure ko pehle 'mehsoos' karti hai aur sabse zyada khinchti hai, isliye hoop stress andar max, bahar min — aur beech me curve hyperbola jaisa (1/r² wala). Radial stress tabhi banta hai jab andar aur bahar ke pressure me antar (Δp = P₁ − P₂) ho; andar woh −P₁ aur bahar −P₂ ke barabar hota hai." },
        { k: "trap", t: "Do not use the thin-shell result σ_c/σ_L = 2 or σ_R ≈ 0 for a thick shell. In a thick shell the radial stress is not negligible, the hoop stress varies across the wall (max at the internal face), and only the longitudinal stress is uniform." },
        { k: "real", t: "Hydraulic press cylinders, gun barrels and high-pressure pipes are thick shells; because the inner layer is the most stressed, they are often built up by shrink-fitting one tube over another (compounding) so the stress is shared more evenly." },
      ],
    },

    /* ---------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Pressure vessels: thin and thick shells (M p.224–225)",
      hi: "पुनरावृत्ति — दाब पात्र: पतले और मोटे शेल",
      blocks: [
        { k: "h", t: "✅ MACE notes — key points (M p.224–225)" },
        { k: "list", items: [
          "✅ Thin shell (MACE): thickness = 6 to 10% of diameter (M p.224); older notes / this handbook: t &lt; d/20 (p.17) — see Source difference.",
          "✅ Thin shells: i) cylindrical, ii) spherical (M p.224).",
          "✅ Cylinder: σ_c = hoop = Pd/2t; σ_L = Pd/4t; σ_R ≈ 0 (M p.224).",
          "✅ σ_c &gt; σ_L &gt; σ_R ⇔ σ₁ &gt; σ₂ &gt; σ₃ (M p.224).",
          "✅ σ_c/σ_L = 2; σ_L/σ_c = 1/2 = 0.5 (M p.224).",
          "✅ τmax in cylindrical shell = Pd/4t — same as σ_L (absolute max; in-plane value Pd/8t) (M p.224).",
          "✅ ε_c = (Pd/4tE)(2 − μ); ε_L = (Pd/4tE)(1 − 2μ) (M p.224).",
          "✅ ε_vol (incompressible fluid) = (Pd/4tE)(5 − 4μ); (compressible fluid) = (Pd/4tE)(5 − 4μ) − P/K (M p.224).",
          "✅ K = P/ε_vol ⇒ ε_vol = P/K (M p.224).",
          "✅ Sphere: σ_c = σ_L = Pd/4t; σ_c/σ_L = 1; σ_c = σ_L &gt; σ_R, σ_R ≈ 0 (M p.225).",
          "✅ Sphere: ε_vol = 3·ε_d; ε_vol = (3Pd/4tE)(1 − μ) incompressible; − P/K for compressible (M p.225).",
          "✅ Axial pull → suction, internal pressure ↓ → σ_c compressive (M p.225).",
          "✅ Axial push → +ve hydrostatic pressure, internal pressure ↑ → σ_c tensile (M p.225).",
          "✅ Thick shells → Lamé's theory (M p.225).",
          "✅ Thick: hoop stress max at internal face, min at external face, hyperbolic distribution (M p.225).",
          "✅ Thick: longitudinal stress uniform &amp; tensile; radial stress exists due to pressure difference Δp (M p.225).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
