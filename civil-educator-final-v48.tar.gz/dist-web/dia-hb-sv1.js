/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: SURVEYING handbook, Chapters 1–4
   Principles · Errors · Chain and tape · Compass
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.2 WHOLE TO PART */
  "hb-sv-whole2part": {
    label: "Working from the whole to the part",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="On the left a survey started from a large framework of a few accurately measured control points, inside which the detail is filled in, so any error stays local. On the right a survey built up point by point from one end, where each small error is passed on to every point after it and accumulates.">
      ${hbmk("wp")}
      <text class="em" x="168" y="26" text-anchor="middle">WHOLE → PART  ·  right</text>
      <path class="hi" d="M60 200 L170 62 L280 200 Z"/>
      <path class="hi" d="M60 200 L280 200"/>
      <circle class="hif" cx="60" cy="200" r="6"/>
      <circle class="hif" cx="170" cy="62" r="6"/>
      <circle class="hif" cx="280" cy="200" r="6"/>
      ${[[110,150],[170,120],[225,152],[128,182],[212,180],[170,168]].map(([x, y]) =>
        `<circle class="thin" cx="${x}" cy="${y}" r="4" fill="none"/>`).join("")}
      ${[[110,150],[170,120],[225,152],[128,182],[212,180]].map(([x, y]) =>
        `<line class="thin dash" x1="${x}" y1="${y}" x2="170" y2="168"/>`).join("")}
      <text class="ea" x="168" y="228" text-anchor="middle">a few points, measured well, FIRST</text>
      <text class="lb" x="168" y="250" text-anchor="middle">then everything else fitted inside them</text>
      <text class="em" x="168" y="278" text-anchor="middle">an error stays where it was made</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">PART → WHOLE  ·  wrong</text>
      ${[0, 1, 2, 3, 4, 5, 6].map(i => `<circle class="hif" cx="${404 + i * 36}" cy="${130 + i * i * 2.2}" r="5"/>
        ${i ? `<line class="hi" x1="${368 + i * 36}" y1="${130 + (i - 1) * (i - 1) * 2.2}" x2="${404 + i * 36}" y2="${130 + i * i * 2.2}"/>` : ""}`).join("")}
      <line class="thin dash" x1="404" y1="130" x2="620" y2="130"/>
      <line class="ac" x1="620" y1="130" x2="620" y2="210" marker-end="url(#wp-c)" marker-start="url(#wp-c)"/>
      <text class="ea" x="612" y="176" text-anchor="end">accumulated</text>
      <text class="lb" x="524" y="240" text-anchor="middle">each point set out from the last one</text>
      <text class="lb" x="524" y="262" text-anchor="middle">— so every error is inherited</text>
      <text class="em" x="524" y="286" text-anchor="middle">and the end of the chain is nowhere near right</text>
    </svg>`,
    caption: "This is the first principle of surveying and the reason a job starts with a control framework rather than with the interesting part. <strong>Errors in a framework stay in the framework; errors in a chain of measurements travel</strong> — and by the far end they are no longer small.",
  },

  /* ------------------------------------------- 1.3 FIXING A POINT */
  "hb-sv-fixpoint": {
    label: "The four ways of fixing a point from a known line",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A known base line AB with four ways of locating a new point P from it: two distances from A and from B, a perpendicular offset at a measured chainage, one distance and one angle, and two angles measured at A and at B.">
      ${hbmk("fp")}
      <text class="em" x="350" y="24" text-anchor="middle">TWO INDEPENDENT MEASUREMENTS — NEVER ONE</text>
      ${[["two distances", 108, "d1", "d2", 0],
         ["offset at a chainage", 286, "chainage", "offset", 1],
         ["a distance and an angle", 464, "θ", "d", 2],
         ["two angles", 632, "α", "β", 3]]
        .map(([t, x, a, b2, k]) => `
        <line class="s" x1="${x - 60}" y1="180" x2="${x + 60}" y2="180"/>
        <circle class="hif" cx="${x - 60}" cy="180" r="5"/>
        <circle class="hif" cx="${x + 60}" cy="180" r="5"/>
        <text class="lb" x="${x - 60}" y="200" text-anchor="middle">A</text>
        <text class="lb" x="${x + 60}" y="200" text-anchor="middle">B</text>
        <circle class="acf" cx="${x}" cy="96" r="5"/>
        <text class="ea" x="${x}" y="86" text-anchor="middle">P</text>
        ${k === 0 ? `<line class="hi" x1="${x - 60}" y1="180" x2="${x}" y2="96"/><line class="hi" x1="${x + 60}" y1="180" x2="${x}" y2="96"/>`
          : k === 1 ? `<line class="hi" x1="${x}" y1="180" x2="${x}" y2="96"/><line class="hi" x1="${x - 60}" y1="180" x2="${x}" y2="180"/>
                       <path class="thin" d="M${x - 12} 180 L${x - 12} 168 L${x} 168"/>`
          : k === 2 ? `<line class="hi" x1="${x - 60}" y1="180" x2="${x}" y2="96"/>
                       <path class="ac" d="M${x - 34} 180 A26 26 0 0 0 ${x - 42} 158" fill="none"/>`
          : `<line class="hi" x1="${x - 60}" y1="180" x2="${x}" y2="96"/><line class="hi" x1="${x + 60}" y1="180" x2="${x}" y2="96"/>
             <path class="ac" d="M${x - 34} 180 A26 26 0 0 0 ${x - 42} 158" fill="none"/>
             <path class="ac" d="M${x + 34} 180 A26 26 0 0 1 ${x + 42} 158" fill="none"/>`}
        <text class="lb" x="${x}" y="230" text-anchor="middle">${t}</text>`).join("")}
      <text class="lb" x="350" y="262" text-anchor="middle">a third measurement is not waste — it is the CHECK that tells you the first two were right</text>
    </svg>`,
    caption: "The second principle. One measurement puts P somewhere on a line or a circle; it takes two to pin it down. Every method in this handbook — chain, compass, theodolite, plane table, GNSS — is one of these four patterns, and the good surveyor always takes a <strong>third</strong> measurement so that a blunder announces itself.",
  },

  /* ------------------------------------------- 1.4 PLANE vs GEODETIC */
  "hb-sv-planegeo": {
    label: "When the earth's curvature starts to matter",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A curved earth surface with a chord drawn between two points on it, showing that the arc along the surface is slightly longer than the straight chord, with the difference being a few millimetres over eighteen kilometres, and the spherical excess of a triangle on the curved surface.">
      ${hbmk("pg2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE EARTH IS CURVED — THE QUESTION IS WHETHER IT MATTERS YET</text>
      <path class="s" d="M60 200 A560 560 0 0 1 480 200"/>
      <path class="hi" d="M60 200 L480 200"/>
      <circle class="hif" cx="60" cy="200" r="5"/>
      <circle class="hif" cx="480" cy="200" r="5"/>
      <text class="ea" x="270" y="148" text-anchor="middle">arc — the true distance along the ground</text>
      <text class="em" x="270" y="222" text-anchor="middle">chord — what plane surveying assumes</text>
      <line class="thin dash" x1="60" y1="200" x2="270" y2="330"/>
      <text class="lb" x="270" y="256" text-anchor="middle">arc − chord ≈ s³ / 24R²</text>
      <text class="lb" x="270" y="278" text-anchor="middle">over 18 km that is about 6 mm</text>

      <line class="gl" x1="520" y1="44" x2="520" y2="272"/>
      <text class="em" x="612" y="80" text-anchor="middle">PLANE survey</text>
      <text class="lb" x="612" y="102" text-anchor="middle">curvature ignored</text>
      <text class="lb" x="612" y="122" text-anchor="middle">areas up to ~250 km²</text>
      <text class="lb" x="612" y="142" text-anchor="middle">almost all civil work</text>
      <text class="em" x="612" y="182" text-anchor="middle">GEODETIC survey</text>
      <text class="lb" x="612" y="204" text-anchor="middle">curvature allowed for</text>
      <text class="lb" x="612" y="224" text-anchor="middle">national control networks,</text>
      <text class="lb" x="612" y="244" text-anchor="middle">long tunnels, large dams</text>
    </svg>`,
    caption: "The honest test is not the area but the <em>accuracy you need</em>. A triangle's angles on a curved surface add to more than 180°, by about one arc-second for every 196 km² of area — which is below the precision of an ordinary theodolite, and is exactly why plane surveying is legitimate for almost everything a civil engineer does.",
  },

  /* ------------------------------------------- 2.2 ACCURACY vs PRECISION */
  "hb-sv-accprec": {
    label: "Accuracy and precision are not the same thing",
    svg: `<svg viewBox="0 0 764 280" role="img" aria-label="Four targets showing the four combinations: shots scattered and off centre, shots tightly grouped but off centre, shots scattered around the centre, and shots tightly grouped on the centre, illustrating that precision is repeatability and accuracy is closeness to the true value.">
      ${hbmk("ap")}
      <text class="em" x="350" y="24" text-anchor="middle">A SYSTEMATIC ERROR MAKES YOU PRECISELY WRONG</text>
      ${[["neither", 100, [[8, -14], [-16, 10], [18, 16], [-6, -20]], "random errors, and a bias"],
         ["precise, not accurate", 290, [[26, -22], [30, -16], [24, -12], [30, -21]], "a SYSTEMATIC error — the deadly one"],
         ["accurate, not precise", 480, [[14, -12], [-15, 9], [7, 15], [-11, -9]], "random errors only — averaging helps"],
         ["both", 638, [[3, -4], [-4, 2], [2, 5], [-2, -3]], "what careful work looks like"]]
        .map(([t, cx, pts, note]) => `
        <circle class="thin" cx="${cx}" cy="120" r="46" fill="none"/>
        <circle class="thin" cx="${cx}" cy="120" r="30" fill="none"/>
        <circle class="thin" cx="${cx}" cy="120" r="15" fill="none"/>
        <circle class="acf" cx="${cx}" cy="120" r="3"/>
        ${pts.map(([dx, dy]) => `<circle class="hif" cx="${cx + dx}" cy="${120 + dy}" r="4.5"/>`).join("")}
        <text class="lb" x="${cx}" y="192" text-anchor="middle">${t}</text>
        <text class="lb" x="${cx}" y="226" text-anchor="middle">${note.split(" — ")[0]}</text>
        ${note.includes(" — ") ? `<text class="em" x="${cx}" y="248" text-anchor="middle">${note.split(" — ")[1]}</text>` : ""}`).join("")}
      <text class="lb" x="350" y="274" text-anchor="middle">taking more readings fixes the third case and does nothing at all for the second</text>
    </svg>`,
    caption: "The second target is the one to be afraid of. Every reading agrees with the last, the work looks meticulous, and it is all wrong by the same amount — a tape that is 5 mm short, an uncorrected temperature, an uncompensated local attraction. <strong>Repetition exposes random error and hides systematic error</strong>.",
  },

  /* ------------------------------------------- 3.2 CHAIN SURVEY */
  "hb-sv-chain": {
    label: "The skeleton of a chain survey",
    svg: `<svg viewBox="0 0 716 300" role="img" aria-label="A chain survey framework of well conditioned triangles over a plot, with the longest line marked as the base line, a check line drawn across one triangle to verify it, a tie line picking up detail, and perpendicular offsets taken from a chain line to a building.">
      ${hbmk("cs2")}
      <text class="em" x="350" y="24" text-anchor="middle">TRIANGLES, BECAUSE ONLY A TRIANGLE IS FIXED BY ITS SIDES ALONE</text>
      <path class="s" d="M70 240 L250 70 L470 120 L560 250 Z"/>
      <path class="s" d="M70 240 L470 120"/>
      <path class="hi" d="M70 240 L560 250"/>
      <path class="ac dash" d="M250 70 L320 205"/>
      ${[[70, 240, "A"], [250, 70, "B"], [470, 120, "C"], [560, 250, "D"]].map(([x, y, n]) =>
        `<circle class="hif" cx="${x}" cy="${y}" r="6"/><text class="em" x="${x + (n === "A" ? -14 : 12)}" y="${y + (n === "B" ? -10 : 18)}">${n}</text>`).join("")}
      <text class="em" x="300" y="272" text-anchor="middle">BASE LINE — the longest, measured most carefully</text>
      <text class="ea" x="300" y="200" text-anchor="end">check line</text>
      <rect class="conc" x="330" y="128" width="72" height="40"/>
      ${[0, 1, 2].map(i => `<line class="thin" x1="${340 + i * 30}" y1="168" x2="${340 + i * 30}" y2="${186 + i * 4}"/>
        <path class="thin" d="M${334 + i * 30} 168 L${334 + i * 30} 174 L${340 + i * 30} 174"/>`).join("")}
      <text class="lb" x="366" y="122" text-anchor="middle">building</text>
      <text class="lb" x="430" y="196">offsets, at right angles to the chain line</text>
      <text class="lb" x="70" y="290">a well-conditioned triangle has no angle below 30° or above 120°</text>
    </svg>`,
    caption: "A chain survey measures only <em>distances</em>, so the framework must be made of triangles — the one shape whose form is settled by its side lengths alone. The <strong>check line</strong> is not optional: it is the third measurement that proves the triangle was measured correctly, and without it a blunder is invisible.",
  },

  /* ------------------------------------------- 3.5 TAPE CORRECTIONS */
  "hb-sv-tapecorr": {
    label: "The five tape corrections, and which way each one goes",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Five sketches showing the corrections applied to a taped distance: a tape longer than standard, a tape measured along a slope, a tape expanded by heat, a tape stretched by extra pull, and a tape sagging between supports, with the sign of each correction indicated.">
      ${hbmk("tc")}
      <text class="em" x="350" y="24" text-anchor="middle">EACH ONE HAS A SIGN — AND GETTING IT WRONG DOUBLES THE ERROR</text>

      <text class="em" x="150" y="62">① STANDARDISATION</text>
      <line class="s" x1="60" y1="84" x2="230" y2="84"/>
      <line class="hi" x1="60" y1="96" x2="244" y2="96"/>
      <text class="lb" x="60" y="118">tape longer than nominal → fewer tape-lengths</text>
      <text class="ea" x="60" y="136">needed → measured length is TOO SMALL → +</text>

      <text class="em" x="430" y="62">② SLOPE</text>
      <line class="hi" x1="400" y1="98" x2="520" y2="70"/>
      <line class="s" x1="400" y1="98" x2="520" y2="98"/>
      <path class="thin dash" d="M520 70 L520 98"/>
      <text class="lb" x="400" y="118">you measured along the ground, but the plan</text>
      <text class="ea" x="400" y="136">needs the horizontal → always −</text>

      <text class="em" x="150" y="176">③ TEMPERATURE</text>
      <line class="s" x1="60" y1="196" x2="200" y2="196"/>
      <line class="hi" x1="60" y1="208" x2="222" y2="208"/>
      <text class="lb" x="60" y="230">hotter than standard → tape expands → it</text>
      <text class="ea" x="60" y="248">reads short → + (and − if colder)</text>

      <text class="em" x="430" y="176">④ PULL</text>
      <line class="s" x1="400" y1="196" x2="540" y2="196"/>
      <line class="hi" x1="400" y1="208" x2="556" y2="208"/>
      <line class="ac" x1="560" y1="208" x2="584" y2="208" marker-end="url(#tc-c)"/>
      <text class="lb" x="400" y="230">more pull than standard → tape stretches →</text>
      <text class="ea" x="400" y="248">+ (and − if slacker)</text>

      <text class="em" x="150" y="286">⑤ SAG</text>
      <path class="hi" d="M60 300 C110 318 160 318 210 300"/>
      <line class="s" x1="60" y1="300" x2="210" y2="300"/>
      <text class="lb" x="230" y="292">a hanging tape follows a curve, which is longer</text>
      <text class="ea" x="230" y="310">than the straight line it spans → always −</text>
    </svg>`,
    caption: "Two of the five have a fixed sign — slope and sag are <strong>always subtractive</strong>, because both mean the tape travelled further than the distance you want. The other three depend on which side of standard the conditions were. The test that never fails: <em>did the tape read more or fewer tape-lengths than it should have?</em>",
  },

  /* ------------------------------------------- 4.2 BEARINGS */
  "hb-sv-bearings": {
    label: "Whole circle bearing and reduced bearing",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A compass rose showing a whole circle bearing measured clockwise from north through the full 360 degrees, beside the same directions expressed as reduced or quadrantal bearings measured from north or south towards east or west within each quadrant, with the conversion rule for each quadrant.">
      ${hbmk("br2")}
      <text class="em" x="168" y="26" text-anchor="middle">WHOLE CIRCLE (WCB)</text>
      <circle class="thin" cx="168" cy="150" r="80" fill="none"/>
      <line class="s" x1="168" y1="60" x2="168" y2="240"/>
      <line class="s" x1="78" y1="150" x2="258" y2="150"/>
      <text class="lb" x="168" y="54" text-anchor="middle">N 0°</text>
      <text class="lb" x="268" y="154">E 90°</text>
      <text class="lb" x="168" y="258" text-anchor="middle">S 180°</text>
      <text class="lb" x="70" y="154" text-anchor="end">270° W</text>
      <line class="hi" x1="168" y1="150" x2="230" y2="207" marker-end="url(#br2-m)"/>
      <path class="ac" d="M168 90 A60 60 0 0 1 211 192" fill="none" marker-end="url(#br2-c)"/>
      <text class="ea" x="196" y="118">137°</text>
      <text class="lb" x="168" y="286" text-anchor="middle">one number, clockwise from north, 0° to 360°</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">REDUCED / QUADRANTAL (QB)</text>
      <circle class="thin" cx="524" cy="150" r="80" fill="none"/>
      <line class="s" x1="524" y1="60" x2="524" y2="240"/>
      <line class="s" x1="434" y1="150" x2="614" y2="150"/>
      <text class="lb" x="524" y="54" text-anchor="middle">N</text>
      <text class="lb" x="624" y="154">E</text>
      <text class="lb" x="524" y="258" text-anchor="middle">S</text>
      <text class="lb" x="426" y="154" text-anchor="end">W</text>
      <line class="hi" x1="524" y1="150" x2="586" y2="207" marker-end="url(#br2-m)"/>
      <path class="ac" d="M524 210 A60 60 0 0 0 567 192" fill="none" marker-end="url(#br2-c)"/>
      <text class="ea" x="536" y="206">43°</text>
      <text class="em" x="524" y="286" text-anchor="middle">S 43° E — measured from N or S, never past 90°</text>
      <text class="lb" x="470" y="102">NE: QB = WCB</text>
      <text class="lb" x="470" y="120">SE: 180 − WCB</text>
      <text class="lb" x="470" y="138">SW: WCB − 180</text>
    </svg>`,
    caption: "Both describe the same direction. A prismatic compass reads WCB directly and a surveyor's compass reads QB, and computations want whichever form makes the trigonometry simple. The conversions are not worth memorising — <strong>sketch the quadrant and read it off</strong>, which takes five seconds and is never wrong.",
  },

  /* ------------------------------------------- 4.4 LOCAL ATTRACTION */
  "hb-sv-localattr": {
    label: "How local attraction announces itself",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A traverse in which the fore bearing and back bearing of one line differ by exactly one hundred and eighty degrees so both its stations are free of local attraction, while another line's bearings differ by more than that, showing that one of its stations is disturbed by nearby iron.">
      ${hbmk("la")}
      <text class="em" x="350" y="24" text-anchor="middle">THE TEST: DOES FB − BB COME OUT AT EXACTLY 180°?</text>

      <line class="s" x1="90" y1="120" x2="290" y2="120"/>
      <circle class="hif" cx="90" cy="120" r="7"/><circle class="hif" cx="290" cy="120" r="7"/>
      <text class="em" x="90" y="106" text-anchor="middle">A</text>
      <text class="em" x="290" y="106" text-anchor="middle">B</text>
      <text class="lb" x="190" y="150" text-anchor="middle">FB 45°30'   ·   BB 225°30'</text>
      <text class="ea" x="190" y="174" text-anchor="middle">difference = 180°00'  ✓</text>
      <text class="lb" x="190" y="196" text-anchor="middle">BOTH stations are clean —</text>
      <text class="lb" x="190" y="216" text-anchor="middle">and this is where the correction starts</text>

      <line class="gl" x1="348" y1="44" x2="348" y2="272"/>

      <line class="s" x1="410" y1="120" x2="610" y2="120"/>
      <circle class="hif" cx="410" cy="120" r="7"/><circle class="hif" cx="610" cy="120" r="7"/>
      <text class="em" x="410" y="106" text-anchor="middle">B</text>
      <text class="em" x="610" y="106" text-anchor="middle">C</text>
      <path class="ac" d="M610 134 C626 150 640 166 640 186"/>
      <rect class="steel" x="630" y="186" width="20" height="26"/>
      <text class="lb" x="640" y="228" text-anchor="middle">iron pole</text>
      <text class="lb" x="500" y="150" text-anchor="middle">FB 124°45'   ·   BB 306°00'</text>
      <text class="em" x="500" y="174" text-anchor="middle">difference = 181°15'  ✗</text>
      <text class="lb" x="500" y="196" text-anchor="middle">B is known clean, so the whole</text>
      <text class="lb" x="500" y="216" text-anchor="middle">1°15' belongs to C</text>
      <text class="em" x="350" y="266" text-anchor="middle">correct every bearing observed AT the affected station by that station's error — never the line's</text>
    </svg>`,
    caption: "Local attraction is a <em>station</em> property, not a line property, and that single sentence solves every problem of this type. Find one line whose fore and back bearings differ by exactly 180° — both its ends are clean — and then work outwards from there, carrying the error to whichever station it belongs to.",
  },

});
