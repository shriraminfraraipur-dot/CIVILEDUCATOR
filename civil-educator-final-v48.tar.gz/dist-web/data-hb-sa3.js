/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: Structural Analysis, Chapters 4–5
   Influence lines and rolling loads · Deflections
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sa"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 4 */
    {
      id: "sa-4",
      n: 4,
      title: "Influence Lines and Rolling Loads",
      hi: "प्रभाव रेखा और चलायमान भार",
      blurb: "What to do when the load will not stand still: how to build an influence line, how Muller-Breslau gets it without any equations, and how to position a load train for the worst case.",
      mins: 30,
      sections: [
        {
          n: "4.1", title: "What an influence line is", hi: "प्रभाव रेखा क्या है",
          blocks: [
            { k: "def", term: "Influence line", t: "A diagram showing how one response quantity at one fixed section — a reaction, a shear, a moment — varies as a unit load travels across the structure." },
            { k: "p", t: "Everything so far has assumed the load stays where you put it. Bridges, gantry girders and crane runways do not have that luxury: the load moves, and the question changes from <em>what is the moment</em> to <em>where should the load stand to make the moment worst</em>. The influence line answers the second question directly." },
            { k: "dia", id: "hb-sa-ild-concept" },
            { k: "p", t: "The comparison is worth dwelling on, because the two diagrams look alike and mean opposite things. On a bending moment diagram the load is fixed and the section varies; on an influence line the section is fixed and the load varies. A BMD ordinate is a moment in kNm. An influence-line ordinate for moment is a <strong>length, in metres</strong> — multiply it by a load to get a moment." },
            { k: "trap", t: "Reading an influence-line ordinate as though it were a force is the single most common error in this chapter, and the units catch it instantly. If your \"bending moment\" has come out in metres, you have forgotten to multiply by the load." },
          ],
        },
        {
          n: "4.2", title: "The three basic influence lines", hi: "तीन बुनियादी प्रभाव रेखाएँ",
          blocks: [
            { k: "p", t: "Take a simply supported beam of span L with a section at C, a distance a from A and b from B. Put a unit load at distance x from A and write the response — that <em>is</em> the influence line." },
            { k: "h", t: "Reaction at A" },
            { k: "eq", expr: "RA = (L − x) / L", where: [["x", "Position of the unit load, measured from A"]] },
            { k: "p", t: "A straight line from 1.0 at A down to 0 at B. The ordinate is dimensionless." },
            { k: "h", t: "Shear at C" },
            { k: "p", t: "With the load to the right of C, the left segment carries only RA, so V at C equals +RA. With the load to the left of C, the left segment carries RA and the load, so V equals RA − 1. The two expressions differ by exactly 1, which is why the diagram jumps by one unit as the load crosses the section." },
            { k: "eq", expr: "Load right of C:  V = + (L − x)/L        Load left of C:  V = − x/L", where: [] },
            { k: "h", t: "Bending moment at C" },
            { k: "eq", expr: "Load right of C:  M = a (L − x)/L        Load left of C:  M = b x/L        Peak at C:  ab/L", where: [
              ["a, b", "Distances from C to the two supports"],
            ]},
            { k: "dia", id: "hb-sa-ild-basic" },
            { k: "note", t: "All three are straight lines. That is not a coincidence — it is the signature of a determinate structure, where the response is a linear function of the load position. For an indeterminate beam the influence lines are curved." },
          ],
        },
        {
          n: "4.3", title: "Muller-Breslau's principle", hi: "म्यूलर-ब्रेस्लाउ सिद्धांत",
          blocks: [
            { k: "def", term: "Muller-Breslau's principle", t: "The influence line for any force quantity has the same shape as the deflected form obtained by removing the restraint corresponding to that quantity and imposing a unit displacement in its direction." },
            { k: "dia", id: "hb-sa-muller" },
            { k: "steps", items: [
              "Decide which quantity you want — reaction at A, shear at C, moment at C.",
              "Remove the restraint that produces it: the vertical support for a reaction, continuity of displacement across the cut for a shear, continuity of rotation for a moment.",
              "Impose one unit of the displacement that restraint used to prevent — lift by 1, slide by 1, rotate by 1 radian.",
              "Sketch the resulting shape. That shape, to scale, is the influence line.",
            ]},
            { k: "p", t: "The principle follows from virtual work: the work done by the released force through its unit displacement must equal the work done by the unit load through the deflection at its position, and the shape falls out of that equality. What matters in practice is that it produces the diagram without writing a single equilibrium equation." },
            { k: "trap", t: "For the moment influence line, the unit displacement is a <strong>relative rotation of one radian across the hinge</strong> — the two faces rotate apart by 1, not each by 1. Get that wrong and every ordinate is out by a factor of two." },
          ],
        },
        {
          n: "4.4", title: "Using an influence line", hi: "प्रभाव रेखा का उपयोग",
          blocks: [
            { k: "dia", id: "hb-sa-ild-use" },
            { k: "list", items: [
              "<strong>A single point load W</strong> → response = W × ordinate under the load.",
              "<strong>Several point loads</strong> → response = Σ (W × its own ordinate).",
              "<strong>A distributed load w</strong> → response = w × the area of the influence line beneath the loaded length.",
              "<strong>To maximise</strong> → cover only the parts of the diagram with the sign you want, and leave the rest bare.",
            ]},
            { k: "p", t: "That last rule is the one with practical consequences. An influence line with both positive and negative parts says that a load on one stretch increases the response and a load on another stretch reduces it. So the worst case for a continuous beam is not \"all spans loaded\" — it is a particular pattern, which is precisely why IS 456 asks for alternate spans loaded and for adjacent spans loaded as separate load cases." },
            { k: "eg", title: "Example 4.1 — maximum moment at a section under different loadings", given: "Simply supported beam of span 10 m. Section C is 4 m from A, so a = 4 m and b = 6 m. Find the moment at C for (i) a single 50 kN load placed to give the worst effect, (ii) a UDL of 20 kN/m over the whole span, and (iii) two wheels of 100 kN and 50 kN, 3 m apart, positioned for the worst effect.", steps: [
              { t: "Draw the influence line for M at C", w: "Peak ordinate at C = ab/L = 4 × 6 / 10 = 2.4 m\nStraight from 0 at A up to 2.4 at C, then down to 0 at B." },
              { t: "(i) Single point load", w: "Put it where the ordinate is greatest — at C itself.\nM = 50 × 2.4 = 120 kNm" },
              { t: "(ii) UDL over the whole span", w: "Area of the influence line = ½ × base × height\n                           = ½ × 10 × 2.4 = 12 m²\nM = w × area = 20 × 12 = 240 kNm\n\nCheck against the direct formula for a UDL:\n  M at x = w x (L − x) / 2 = 20 × 4 × 6 / 2 = 240 kNm ✓" },
              { t: "(iii) Load train — try the heavy wheel on the peak", w: "100 kN at C (x = 4 m): ordinate 2.4\n50 kN then sits at x = 7 m. For x > a the ordinate is a(L − x)/L:\n  = 4 × (10 − 7) / 10 = 1.2 m\n\nM = 100(2.4) + 50(1.2) = 240 + 60 = 300 kNm" },
              { t: "Try the other arrangement before accepting it", w: "50 kN at C (ordinate 2.4), 100 kN then at x = 1 m.\nFor x < a the ordinate is b x / L = 6 × 1 / 10 = 0.6 m\n\nM = 50(2.4) + 100(0.6) = 120 + 60 = 180 kNm\n\nSmaller. So the first arrangement governs." },
            ], ans: "(i) 120 kNm · (ii) 240 kNm · (iii) 300 kNm, with the 100 kN wheel standing at C" },
            { k: "note", t: "Step 5 is not optional politeness. With a load train there is no formula for the worst position — you try the candidate positions and compare. The influence line is what makes each trial one line of arithmetic instead of a full analysis." },
          ],
        },
        {
          n: "4.5", title: "Maximum shear and moment under a moving system", hi: "चलायमान भार में अधिकतम अपरूपण और आघूर्ण",
          blocks: [
            { k: "p", t: "Two different maxima are wanted in design and they are found differently." },
            { k: "list", items: [
              "<strong>Maximum at a given section</strong> — draw the influence line for that section and position the train on it, as in Example 4.1.",
              "<strong>Absolute maximum anywhere in the span</strong> — the section itself is now unknown too, so it has to be searched for.",
            ]},
            { k: "h", t: "Absolute maximum bending moment" },
            { k: "p", t: "For a single moving load the answer is easy: the moment is greatest when the load is at mid-span, and equals WL/4. For a system of loads the standard result is that the absolute maximum occurs under one of the loads, when <strong>the mid-point of the span lies halfway between that load and the resultant of the whole system</strong>. Test each heavy load in turn as the candidate and take the largest." },
            { k: "p", t: "Maximum shear behaves more simply: it is greatest at the supports, and the worst position brings the load system as close to a support as the spacing allows, with the leading wheel just inside the span." },
            { k: "trap", t: "The absolute maximum moment does <em>not</em> occur at mid-span for a load system, and assuming it does is a standard way to under-design. It occurs under a wheel, near mid-span but not at it, and the difference is worth several per cent — exactly the margin a serviceability check does not have to spare." },
          ],
        },
        {
          n: "4.6", title: "Influence lines for trusses", hi: "ट्रस के लिए प्रभाव रेखाएँ",
          blocks: [
            { k: "p", t: "A truss carries load only at its panel points, so the influence line for a member force is made of straight segments between panel points — the load cannot be anywhere else. That single fact makes the construction quick." },
            { k: "steps", items: [
              "Put the unit load at one panel point at a time.",
              "Find the member force for that position, using a section cut (§2.6) — one equation each time.",
              "Plot the value at that panel point.",
              "Join the plotted points with straight lines.",
            ]},
            { k: "note", t: "When the load travels on a floor system that delivers it to the panel points through stringers and cross-girders, the truss still sees only panel-point loads. The influence line for the truss member stays straight between panel points even though the load itself moves continuously along the deck." },
          ],
        },
        {
          n: "4.7", title: "Where this is used in practice", hi: "व्यवहार में इसका उपयोग",
          blocks: [
            { k: "p", t: "Influence lines are not an exam construction. They are how bridge and crane structures are actually assessed." },
            { k: "list", items: [
              "<strong>Road bridges</strong> — IRC 6 specifies the vehicle load trains (Class A, Class 70R and the rest). Positioning them for the worst effect on a given girder section is an influence-line exercise.",
              "<strong>Gantry girders</strong> — the crane wheels move along the girder, and both the maximum moment and the maximum reaction at the column have to be found for the worst wheel position.",
              "<strong>Railway bridges</strong> — the loading standards give the axle trains directly.",
            ]},
            { k: "note", t: "This app does not reproduce the IRC load trains, and neither should any summary — the loads are defined in the published standards and are revised. The method here is what carries across; the numbers must come from the current edition of the relevant code." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "sa-5",
      n: 5,
      title: "Deflections",
      hi: "विक्षेपण",
      blurb: "Strain energy, Castigliano, the unit load method, moment-area and conjugate beam — the tools for finding how far a structure moves, and the engine the force method runs on.",
      mins: 36,
      sections: [
        {
          n: "5.1", title: "Why deflection has to be calculated", hi: "विक्षेपण निकालना क्यों ज़रूरी है",
          blocks: [
            { k: "p", t: "Strength decides whether a structure stands up. Deflection decides whether it is usable — and the two limits are independent. A beam that is safe in flexure can still crack the partition walls under it, bounce underfoot, or pond water on a flat roof." },
            { k: "list", items: [
              "<strong>Serviceability.</strong> IS 456 Cl. 23.2 caps the final deflection below the level of casting at span/250, and the deflection occurring after partitions are built at span/350 or 20 mm, whichever is less.",
              "<strong>The force method.</strong> Chapter 6 builds its compatibility equations out of deflections, so nothing there works until this chapter does.",
              "<strong>The displacement methods.</strong> Chapters 7 and 8 take joint displacements as unknowns. Knowing what those displacements mean physically starts here.",
            ]},
            { k: "note", t: "IS 456 lets you satisfy deflection either by the span-to-effective-depth ratio of Cl. 23.2.1 or by calculation. The ratio route is a shortcut calibrated for ordinary cases; when a beam is unusually loaded, unusually slender, or carrying brittle finishes, the calculation route is the honest one — and it needs the methods below." },
          ],
        },
        {
          n: "5.2", title: "Strain energy", hi: "विकृति ऊर्जा",
          blocks: [
            { k: "def", term: "Strain energy U", t: "The work done by the external loads in deforming the structure, stored in it and recoverable on unloading." },
            { k: "p", t: "Apply a load gradually to a linear structure. It starts at zero and grows to P while the deflection grows from zero to δ, so the work done is the area under the load-deflection line — a triangle." },
            { k: "eq", expr: "U = ½ P δ", where: [["P", "Final value of the gradually applied load"], ["δ", "Deflection at the load, in its direction"]] },
            { k: "dia", id: "hb-sa-strain" },
            { k: "p", t: "Written in terms of the internal actions, the same energy takes one form per action. For beams and frames the bending term dominates so completely that the others are normally dropped — but that is a decision to state, not a rule to forget. In a deep beam or a short bracket the shear term is not negligible at all." },
            { k: "eq", expr: "Bending: U = ∫ M² dx / (2EI)        Axial: U = ∫ N² dx / (2AE)        Torsion: U = ∫ T² dx / (2GJ)", where: [] },
          ],
        },
        {
          n: "5.3", title: "Castigliano's theorems", hi: "कास्टिग्लियानो की प्रमेयें",
          blocks: [
            { k: "eq", expr: "Second theorem:   δ(i) = ∂U / ∂P(i)", where: [
              ["δ(i)", "Displacement at the point of load P(i), in the direction of P(i)"],
              ["U", "Total strain energy of the structure, written as a function of the loads"],
            ]},
            { k: "p", t: "In words: differentiate the strain energy with respect to a load and you get the displacement under that load. It is exact, it is easy to state, and it has one practical limitation — it gives the displacement only where a load happens to act, and only in that load's direction." },
            { k: "h", t: "The dummy load trick" },
            { k: "p", t: "If you want the deflection at a point with no load on it, apply an imaginary load Q there, carry it symbolically through the analysis, differentiate with respect to Q, and only then set Q = 0. What survives is exactly the unit load method of §5.4, which is why most people skip straight to that form." },
            { k: "note", t: "Castigliano's <em>first</em> theorem is the mirror image: ∂U/∂δ(i) = P(i), the load required to produce a given displacement. It is the theoretical parent of the stiffness method in Chapter 10." },
          ],
        },
        {
          n: "5.4", title: "The unit load method", hi: "यूनिट लोड विधि",
          blocks: [
            { k: "p", t: "This is the workhorse. It comes from the principle of virtual work: for a structure in equilibrium, the external virtual work done by a virtual force system moving through the real displacements equals the internal virtual work done by the virtual internal forces moving through the real deformations." },
            { k: "eq", expr: "1 × δ = ∫ (M m / EI) dx           beams and frames", where: [
              ["δ", "The wanted displacement"],
              ["M", "Bending moment from the REAL loads on the real structure"],
              ["m", "Bending moment from a UNIT load alone, applied at the point and in the direction of δ"],
            ]},
            { k: "eq", expr: "1 × δ = Σ (P k L / AE)            pin-jointed trusses", where: [
              ["P", "Member force from the real loads"],
              ["k", "Member force from the unit load alone"],
              ["L, A, E", "Length, area and modulus of that member"],
            ]},
            { k: "dia", id: "hb-sa-unitload" },
            { k: "steps", items: [
              "Analyse the real structure under the real loads. Record M(x) segment by segment, or P for every truss member.",
              "Remove the real loads. Apply a single unit load at the point where you want the displacement, in the direction you want it. For a rotation, apply a unit couple instead.",
              "Analyse again for m(x) or k — same structure, same supports, unit load alone.",
              "Integrate M m / EI over every segment, or tabulate P k L / AE for every member, and add.",
              "A positive answer means the displacement is in the direction you assumed for the unit load. A negative one means the opposite way.",
            ]},
            { k: "eg", title: "Example 5.1 — mid-span deflection of a simply supported beam", given: "Span L, simply supported, carrying a single point load W at mid-span. EI constant. Find the mid-span deflection.", steps: [
              { t: "Real system", w: "Reactions W/2 at each end.\nFor 0 ≤ x ≤ L/2, measuring x from the left support:\n  M(x) = (W/2) x" },
              { t: "Unit system", w: "Remove W, apply 1 kN downward at mid-span.\nReactions ½ at each end.\nFor 0 ≤ x ≤ L/2:\n  m(x) = (1/2) x" },
              { t: "Integrate over half the span and double", w: "The beam and both systems are symmetric about mid-span, so:\n\nδ = 2 × ∫₀^(L/2) (M m / EI) dx\n  = 2 × ∫₀^(L/2) (W x / 2)(x / 2) / EI dx\n  = (W / 2EI) ∫₀^(L/2) x² dx" },
              { t: "Evaluate", w: "∫₀^(L/2) x² dx = [x³/3]₀^(L/2) = L³ / 24\n\nδ = (W / 2EI) × (L³ / 24)\n  = W L³ / 48 EI" },
              { t: "Check it against the standard result", w: "WL³/48EI is the textbook value for this case. ✓\nObtained here without remembering it — which is the point of having the method." },
            ], ans: "δ = W L³ / 48 EI, downward" },
            { k: "trap", t: "Both M and m must come from the <strong>same structure with the same supports</strong>. A very common error is to compute m on a released or simplified version of the structure. The unit load is a different <em>loading</em>, never a different structure." },
          ],
        },
        {
          n: "5.5", title: "Deflection of trusses", hi: "ट्रस का विक्षेपण",
          blocks: [
            { k: "p", t: "For a truss the integral becomes a sum, because each member has constant force along its length. Set it out as a table — one row per member, columns for P, k, L, AE and the product — and the arithmetic stays visible instead of hiding inside an expression." },
            { k: "eg", title: "Example 5.2 — vertical deflection of the apex of a truss", given: "The truss of Example 2.2: span 8 m, apex C at (4, 3), bottom joint D at (4, 0). A 20 kN load acts down at C. Member forces already found: AC = CB = 16.67 kN compression, AD = DB = 13.33 kN tension, CD = 0. Take AE = 2.4 × 10⁵ kN for every member.", steps: [
              { t: "Real forces P — already known", w: "AC = CB = −16.67 kN   (compression taken as negative)\nAD = DB = +13.33 kN\nCD = 0" },
              { t: "Unit forces k", w: "The unit load is 1 kN downward at C — the same point and direction as the real 20 kN load.\nThe structure is linear, so every k is simply P / 20:\n\n  k(AC) = k(CB) = −0.8333\n  k(AD) = k(DB) = +0.6667\n  k(CD) = 0" },
              { t: "Member lengths", w: "AC = CB = √(4² + 3²) = 5 m\nAD = DB = 4 m\nCD = 3 m" },
              { t: "Tabulate P k L", w: "AC:  (−16.67)(−0.8333)(5) =  69.44\nCB:  (−16.67)(−0.8333)(5) =  69.44\nAD:  ( 13.33)( 0.6667)(4) =  35.55\nDB:  ( 13.33)( 0.6667)(4) =  35.55\nCD:  0                    =   0\n                            ───────\n            Σ P k L       = 209.98 kN²·m" },
              { t: "Divide by AE", w: "δ = Σ P k L / AE\n  = 209.98 / (2.4 × 10⁵)\n  = 8.75 × 10⁻⁴ m\n  = 0.875 mm  downward" },
            ], ans: "δ at C = 0.875 mm downward" },
            { k: "note", t: "Every product in that table came out positive, and that is not a coincidence — when the unit load sits at the same point and direction as the real load, every member's P and k share a sign, so nothing cancels. Put the unit load somewhere else and negative products appear, which is a useful sanity signal that the table is behaving." },
          ],
        },
        {
          n: "5.6", title: "Moment-area method", hi: "मोमेंट-एरिया विधि",
          blocks: [
            { k: "p", t: "A geometric reading of the same integral, and for simple cases the fastest of the lot. Both theorems work on the M/EI diagram." },
            { k: "eq", expr: "Theorem 1:  θ(AB) = area of the M/EI diagram between A and B", where: [["θ(AB)", "Change in slope of the elastic curve between A and B"]] },
            { k: "eq", expr: "Theorem 2:  t(B/A) = (area between A and B) × x̄", where: [
              ["t(B/A)", "Vertical distance of B from the tangent drawn at A"],
              ["x̄", "Distance from the centroid of that area to B"],
            ]},
            { k: "dia", id: "hb-sa-momentarea" },
            { k: "p", t: "It works best where a tangent is known for free. At a fixed support the tangent is horizontal, so t(B/A) measured from there <em>is</em> the deflection — a cantilever's tip deflection comes out in one line. On a simply supported beam neither tangent is known, so you work with two deviations and a bit of geometry." },
            { k: "trap", t: "x̄ is measured <strong>to the point whose deviation you want</strong>, not from it. Swapping the two is the classic error, and on an unsymmetrical M/EI diagram it changes the answer rather than just its sign." },
          ],
        },
        {
          n: "5.7", title: "Conjugate beam method", hi: "संयुग्मी बीम विधि",
          blocks: [
            { k: "p", t: "A restatement of moment-area that removes the geometry entirely. Notice that dθ/dx = M/EI has exactly the same form as dV/dx = −w. So if you build an imaginary beam and load it with the real beam's M/EI diagram, the shear in that imaginary beam behaves like slope and its bending moment behaves like deflection." },
            { k: "eq", expr: "Shear in the conjugate beam = slope of the real beam        Moment in the conjugate beam = deflection of the real beam", where: [] },
            { k: "p", t: "The catch is the supports: the imaginary beam must be given supports that enforce the right conditions on slope and deflection. That is what the conversion table does." },
            { k: "dia", id: "hb-sa-conjugate" },
            { k: "steps", items: [
              "Draw the real beam's bending moment diagram and divide it by EI.",
              "Draw the conjugate beam with converted supports.",
              "Load it with the M/EI diagram as if that were a distributed load.",
              "Find its reactions, then its shear and moment at the section you care about.",
              "Read the shear as slope and the moment as deflection.",
            ]},
            { k: "note", t: "The conversion has a satisfying logic. A real fixed end has zero slope and zero deflection, so the conjugate needs zero shear and zero moment there — which is a free end. A real free end has both slope and deflection, so the conjugate needs both shear and moment — a fixed end. The table is not arbitrary; it is forced." },
          ],
        },
        {
          n: "5.8", title: "Which method to reach for", hi: "कौन-सी विधि चुनें",
          blocks: [
            { k: "list", items: [
              "<strong>One deflection at one point, any structure</strong> → unit load method. It always works and it is the one that carries into Chapter 6.",
              "<strong>Cantilever, or any beam with a known tangent</strong> → moment-area. Often a single line.",
              "<strong>Whole deflected shape, or a beam with varying EI</strong> → conjugate beam.",
              "<strong>Truss</strong> → unit load, tabulated. Nothing else is competitive.",
              "<strong>Deflection at a point where a load already acts</strong> → Castigliano is quickest, since no dummy load is needed.",
            ]},
            { k: "p", t: "All of them come from the same integral. Having more than one is not redundancy — it means you can pick the one whose bookkeeping suits the problem, and check an answer by getting it a second way." },
          ],
        },
      ],
    }

  );
})();
