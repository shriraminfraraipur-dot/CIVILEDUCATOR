/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: EARTHQUAKE ENGINEERING · Ch 6–8
   Ductility & capacity design · Ductile detailing of RC frames ·
   Masonry and steel under earthquake
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "eq");
  if (!hb) { console.error("[eq3] handbook eq not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "eq-6",
      n: 6,
      title: "Ductility and Capacity Design",
      hi: "तन्यता और क्षमता डिज़ाइन",
      blurb: "Why bending without breaking is the whole game, and the strong-column/weak-beam rule that chooses where a building is allowed to yield.",
      mins: 22,
      sections: [
        {
          n: "6.1",
          title: "Ductility — bending without breaking",
          hi: "तन्यता",
          blocks: [
            { k: "p", t: "The response reduction factor R let us design for a fraction of the elastic force — but only because the building can bend, yield and absorb energy instead of breaking. That ability is ductility, and it is the single property that separates a building that survives a great quake from one that shatters." },
            { k: "def", term: "Ductility", t: "The ability of a structure to undergo large deformations beyond its elastic limit without losing much strength — to bend, crack and yield without breaking. A ductile building absorbs the earthquake's energy by deforming; a brittle one has nowhere to put that energy and fails suddenly. Ductility is what R is paying for." },
            { k: "cmp", t: "Ductile versus brittle failure",
              cols: ["Ductile (wanted)", "Brittle (avoid)"],
              rows: [
                ["Warning", "large visible sway and cracking first", "sudden, no warning"],
                ["Energy", "absorbs it by deforming", "cannot — snaps"],
                ["Example", "well-detailed RC beam hinge", "unreinforced masonry, plain shear failure"],
                ["Outcome", "survives, repairable", "collapse"],
              ] },
            { k: "trap", t: "A brittle failure mode anywhere in the load path defeats all the ductility everywhere else. A ductile beam is worthless if the joint it frames into, or the column below, or the footing under that, fails suddenly first. This is why the next rule is about the whole chain — the weakest, most brittle link decides the building's fate, so every link must be made ductile or protected from ever reaching its limit." },
          ],
        },
        {
          n: "6.2",
          title: "Strong column, weak beam",
          hi: "मज़बूत कॉलम, कमज़ोर बीम",
          blocks: [
            { k: "p", t: "In a big quake a frame will yield somewhere — that is accepted. Capacity design is the art of choosing where, so that the yielding is survivable. The rule is to force the hinges into the beams, never the columns." },
            { k: "dia", id: "hb-eq-scwb", cap: "Beam hinges versus column hinges, and why the columns must be stronger." },
            { k: "def", term: "Capacity design (strong column, weak beam)", t: "Deliberately proportioning the frame so the columns are stronger in flexure than the beams framing into them (IS 13920). Then, when the frame is overloaded, the beams hinge at their ends first while the columns stay elastic — the building sags and cracks but keeps standing. A column hinge, by contrast, removes support from everything above and can collapse the storey. IS 13920:2016 makes it quantitative: at every joint, ΣMc ≥ 1.4 ΣMb in each direction (as summarised by <a href=\"https://infralens.in/handbook/ductile-detailing\" target=\"_blank\" rel=\"noopener\">InfraLens IS 13920 summary</a>)." },
            { k: "eg", title: "Example 6.1 — Strong-column/weak-beam check",
              given: "At an interior joint the beams framing in have moment capacities of 250 kNm (hogging, one side) and 180 kNm (sagging, other side) for sway in one direction. The columns above and below each have a capacity of 290 kNm at the axial load considered.",
              steps: [
                { t: "Required", w: "ΣMc ≥ 1.4 × (250 + 180) = 1.4 × 430 = 602 kNm" },
                { t: "Provided", w: "ΣMc = 290 + 290 = 580 kNm  <  602  ✗" },
              ],
              ans: "Fails by 22 kNm — the columns must be made stronger (more steel or a larger section). Note the trap: making the beams stronger than the design needs, for example by adding steel ‘to be safe’, makes this check harder to pass." },
            { k: "real", t: "Picture the two failures side by side. If the columns hinge at a storey, that storey folds and the whole building above drops onto it — a pancake collapse that kills. If the beams hinge at their ends, the frame sags into a leaning but standing shape, cracked but intact, and people walk out. <strong>The engineer cannot prevent the yielding, only choose its address</strong> — and the strong-column/weak-beam rule addresses it to the beams, on purpose." },
            { k: "note", t: "This is why columns in a seismic frame are so much larger than gravity alone would need. They are not carrying more load — they are deliberately kept stronger than the beams so the beams give way first. A frame where the columns are the slender members is a frame designed to fail the worst possible way, however strong each member looks on its own." },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "eq-7",
      n: 7,
      title: "Ductile Detailing of RC Frames",
      hi: "आर.सी. फ्रेम की डक्टाइल डिटेलिंग",
      blurb: "Where ductility is actually created — the closely-spaced ties that confine the concrete at the hinge zones, and the rules that keep the promise R made.",
      mins: 22,
      sections: [
        {
          n: "7.1",
          title: "Confinement — keeping the promise",
          hi: "परिरोध",
          blocks: [
            { k: "p", t: "Ductility is not something the concrete has — it is something the detailing gives it. The response reduction factor R shrank the design force on the promise that the frame would be ductile; this chapter is where that promise is physically kept, in the arrangement of the steel." },
            { k: "dia", id: "hb-eq-ductile", cap: "Closely spaced ties in the hinge zones, and why they matter." },
            { k: "def", term: "Confinement", t: "Wrapping the core concrete tightly with closely-spaced closed stirrups (ties) so that, as the member is bent hard, the concrete is held together and cannot burst outward. Confined concrete can deform far more before failing — it is what turns a brittle member into a ductile one. IS 13920 specifies close tie spacing over a 'confining length' at the ends of beams and columns, where the hinges form." },
            { k: "list", items: [
              "<strong>Close ties at the ends</strong> — over a defined confining length near each joint, the stirrup spacing is roughly halved.",
              "<strong>Closed hoops with 135° hooks</strong> — the ties are closed loops with hooks bent 135° into the core, so they cannot open under load (a 90° hook straightens and releases).",
              "<strong>Continuous, anchored bars</strong> — main bars anchored properly into the joints, laps kept out of the hinge zones.",
              "<strong>Strong joints</strong> — the beam-column joint itself confined and strong, since it must transfer the hinge forces.",
            ] },
            { k: "trap", t: "The 135° hook on a seismic tie is not a detailing fussiness — it is life-or-death. Under severe cyclic loading, a 90° hook (fine for gravity) straightens out and the tie opens, the concrete core bursts, and the member fails brittle exactly when ductility was needed most. IS 13920 requires 135° hooks on confining ties for precisely this reason. The difference between the two hooks is the difference between a ductile column and a collapsed one." },
            { k: "cmp", t: "IS 13920:2016 — key detailing numbers", cols: ["Beams", "Columns"], rows: [
              ["Special zone", "2d from each joint face", "lo = max(D, clear height/6, 450 mm) at each end"],
              ["Hoop spacing there", "≤ d/4, 8 × smallest bar Ø, 100 mm (first hoop ≤ 50 mm from face)", "≤ B/4, 6 × smallest bar Ø, 100 mm (not less than 75 mm)"],
              ["Elsewhere", "≤ d/2", "per design"],
              ["Hooks", "135°, extension ≥ 10d (summary)", "135°, extension ≥ 6d (summary)"],
            ]},
            { k: "note", t: "Values from <a href=\"https://infralens.in/handbook/ductile-detailing\" target=\"_blank\" rel=\"noopener\">InfraLens IS 13920 summary</a>. The hook extensions are where sources disagree — IIT Kanpur's EQ Tip 19 (written to the 1993 edition) asks for 10d, not less than 75 mm, for column ties — see the note in RCC Chapter 12. Confirm against the published IS 13920:2016." },
            { k: "eg", title: "Example 7.1 — Confinement for a beam and a column",
              given: "Beam 300 × 500 mm, effective depth 450 mm, smallest longitudinal bar 16 mm. Column 400 × 400 mm, clear height 3.0 m, smallest bar 20 mm.",
              steps: [
                { t: "Beam — zone and spacing", w: "zone = 2d = 900 mm from each column face\ns ≤ min(450/4 = 112, 8 × 16 = 128, 100) = 100 mm; first hoop within 50 mm" },
                { t: "Column — confining length", w: "lo = max(400, 3000/6 = 500, 450) = 500 mm at top and bottom" },
                { t: "Column — spacing", w: "s ≤ min(400/4 = 100, 6 × 20 = 120, 100) = 100 mm (≥ 75 mm)" },
              ],
              ans: "Beam hoops at 100 mm over 900 mm at each end; column hoops at 100 mm over 500 mm at each end. These short zones are where the earthquake's energy is meant to be absorbed — and where site congestion makes them most likely to be skimped." },
          ],
        },
        {
          n: "7.2",
          title: "Why the whole chain must be ductile",
          hi: "पूरी श्रृंखला तन्य क्यों",
          blocks: [
            { k: "p", t: "Ductile detailing is applied to every part of the lateral system — beams, columns, joints and shear walls — because a single brittle link defeats the rest. IS 13920 exists to make each part deform in a controlled, ductile way rather than fail suddenly." },
            { k: "cmp", t: "Ordinary (IS 456) vs ductile (IS 13920) detailing",
              cols: ["IS 456 (gravity)", "IS 13920 (seismic)"],
              rows: [
                ["Tie spacing at ends", "uniform, wider", "closely spaced over confining length"],
                ["Hooks on ties", "90° acceptable", "135° hooks into the core, mandatory"],
                ["Design intent", "carry gravity safely", "yield in a ductile, controlled way"],
                ["Where used", "non-seismic members", "the entire lateral-force system"],
              ] },
            { k: "note", t: "A frame can be designed to IS 456 for its member strengths and still be a seismic death trap if it is not detailed to IS 13920 — the members are strong but brittle, so they fail without warning and without absorbing energy. The two codes are not alternatives; in a seismic zone the member is designed for strength to IS 456 and detailed for ductility to IS 13920, and skipping the second is the commonest hidden defect in earthquake-vulnerable buildings." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "eq-8",
      n: 8,
      title: "Masonry and Steel Under Earthquake",
      hi: "भूकंप में चिनाई और स्टील",
      blurb: "The two other common structures in a quake — why unreinforced masonry is so deadly and how bands rescue it, and why steel is naturally the most forgiving.",
      mins: 18,
      sections: [
        {
          n: "8.1",
          title: "Masonry — deadly unless tied together",
          hi: "चिनाई",
          blocks: [
            { k: "p", t: "Unreinforced masonry kills more people in earthquakes than any other building type, for the reason met in the very first materials handbook: brick and stone are strong in compression but have almost no tension strength, and earthquake shaking puts the walls into tension and bending — exactly what they cannot take." },
            { k: "p", t: "The failure is fast: the shaking tears the walls apart at the corners, where there is nothing in tension to hold them, and the separated walls fall outward as the roof drops. The remedy, covered in <a href=\"#/read/bc/6\">Chapter 6 of the Building Construction handbook</a>, is to tie the walls together into a single box with continuous horizontal reinforced-concrete seismic bands (plinth, sill, lintel, roof) plus vertical bars at corners — providing the tension strength the masonry lacks." },
            { k: "real", t: "The evidence is written into every major Indian earthquake: banded, confined masonry buildings crack but stand, while identical unbanded buildings next door collapse into rubble. The bands cost a small fraction of the building. <strong>For the vast stock of masonry housing, seismic bands are the single most cost-effective life-safety measure that exists</strong> — and their absence is why so much of that stock is dangerous." },
          ],
        },
        {
          n: "8.2",
          title: "Steel — naturally forgiving",
          hi: "स्टील",
          blocks: [
            { k: "p", t: "Steel is, by nature, the most earthquake-friendly of the common structural materials, because the property earthquakes most demand — ductility — is steel's defining strength. A steel member yields, stretches and absorbs energy visibly before it fails, giving both warning and energy absorption for free." },
            { k: "cmp", t: "Why steel suits earthquakes",
              cols: ["Steel", "The seismic demand"],
              rows: [
                ["Ductility", "very high, inherent", "exactly what a quake needs"],
                ["Weight", "light for its strength", "less mass → less inertia force"],
                ["Tension", "as strong as in compression", "handles the reversing force"],
                ["Warning", "yields visibly before failing", "life-safety warning built in"],
              ] },
            { k: "trap", t: "Steel's Achilles heel in a quake is not the material but its connections and its slender members. A brittle or poorly-designed connection can fail suddenly and rob the frame of all the ductility the steel would have provided, and slender members can buckle under the reversing compression. So seismic steel design focuses on the connections and on preventing buckling — making sure the ductile material is not betrayed by a brittle joint or a member that folds. <strong>The steel is forgiving; the details must not squander that.</strong>" },
          ],
        },
      ],
    },

  );
})();
