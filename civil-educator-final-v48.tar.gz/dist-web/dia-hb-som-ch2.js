/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 2.
   Conventions as in dia-hb-som-ch1.js (currentColor strokes, .hi
   marker / .ac accent, per-figure marker-id prefix).
   The Mohr's circle is drawn TO SCALE for Worked example 2.9
   (σx = 80, σy = −40, τxy = 30 N/mm²) at 2.5 px per N/mm².
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 2.5  ELEMENT + INCLINED PLANE */
  "hb-som-incl": {
    label: "Plane-stress element and an inclined plane at angle θ",
    svg: `<svg viewBox="0 0 640 330" role="img" aria-label="Left: a square stress element with normal stress sigma x pulling outward on its left and right faces, sigma y pulling outward on its top and bottom faces, and shear stress tau xy acting upward on the right face, downward on the left face, rightward on the top face and leftward on the bottom face. Right: the same element cut by a plane whose normal n is rotated counter-clockwise by theta from the x axis; on that cut face the normal stress sigma n acts along n and the shear stress tau acts along the face.">
      ${somMk("sm4")}
      <!-- element -->
      <rect class="conc" x="110" y="105" width="120" height="120"/>
      <line class="hi" x1="230" y1="165" x2="290" y2="165" marker-end="url(#sm4-m)"/>
      <line class="hi" x1="110" y1="165" x2="50" y2="165" marker-end="url(#sm4-m)"/>
      <text class="em" x="294" y="160">σx</text><text class="em" x="30" y="160">σx</text>
      <line class="hi" x1="170" y1="105" x2="170" y2="50" marker-end="url(#sm4-m)"/>
      <line class="hi" x1="170" y1="225" x2="170" y2="280" marker-end="url(#sm4-m)"/>
      <text class="em" x="178" y="58">σy</text><text class="em" x="178" y="284">σy</text>
      <line class="ac" x1="242" y1="200" x2="242" y2="128" marker-end="url(#sm4-c)"/>
      <line class="ac" x1="98" y1="130" x2="98" y2="202" marker-end="url(#sm4-c)"/>
      <line class="ac" x1="135" y1="93" x2="207" y2="93" marker-end="url(#sm4-c)"/>
      <line class="ac" x1="205" y1="237" x2="133" y2="237" marker-end="url(#sm4-c)"/>
      <text class="ea" x="248" y="122">τxy</text>
      <text class="lb" x="170" y="316" text-anchor="middle">Element: σx, σy, τxy (+ as drawn)</text>

      <!-- wedge cut by inclined plane -->
      <path class="conc" d="M400 225 L520 225 L400 105 Z"/>
      <line class="dash" x1="400" y1="225" x2="560" y2="225"/>
      <text class="lb" x="566" y="229">x</text>
      <!-- normal to inclined face (face from (400,105) to (520,225), normal points up-right at 45°) -->
      <line class="hi" x1="460" y1="165" x2="520" y2="105" marker-end="url(#sm4-m)"/>
      <text class="em" x="524" y="100">σn (along n)</text>
      <line class="ac" x1="460" y1="165" x2="418" y2="123" marker-end="url(#sm4-c)"/>
      <text class="ea" x="420" y="112" text-anchor="end">τ</text>
      <line class="dash" x1="460" y1="165" x2="515" y2="165"/>
      <path class="thin" d="M490 165 A 30 30 0 0 0 481.2 143.8"/>
      <text class="lb" x="494" y="156">θ</text>
      <text class="lb" x="480" y="316" text-anchor="middle">Plane whose normal n is at θ (CCW) from x</text>
    </svg>`,
    caption: "θ is measured counter-clockwise from the x-axis to the normal n of the cut plane. σn acts along n, τ along the plane. Every formula in §2.5 uses this convention.",
  },

  /* ---------------------------------------- 2.6  MOHR'S CIRCLE (to scale) */
  "hb-som-mohr": {
    label: "Mohr's circle for σx = 80, σy = −40, τxy = 30 N/mm² (to scale)",
    svg: `<svg viewBox="0 0 640 420" role="img" aria-label="Mohr's circle drawn to scale. The horizontal axis is normal stress sigma, the vertical axis is shear stress tau, positive downward. Point X at (80, 30) lies below the axis on the right; point Y at (minus 40, minus 30) lies above the axis on the left; the line XY passes through the centre C at sigma equals 20. The circle of radius 67.1 cuts the sigma axis at sigma 1 equals 87.1 on the right and sigma 2 equals minus 47.1 on the left. The top and bottom of the circle are at tau equals plus and minus 67.1, the maximum shear stress. The angle 2 theta p of 26.6 degrees is marked between line CX and the sigma axis.">
      ${somMk("sm5")}
      <line class="s" x1="40" y1="210" x2="610" y2="210" marker-end="url(#sm5-a)"/>
      <text x="606" y="200" text-anchor="end">σ</text>
      <line class="s" x1="250" y1="24" x2="250" y2="404" marker-end="url(#sm5-a)"/>
      <text x="258" y="400">τ (+ down)</text>
      <text class="lb" x="244" y="226" text-anchor="end">0</text>

      <circle class="soft" cx="300" cy="210" r="167.7"/>
      <circle class="hi" cx="300" cy="210" r="167.7"/>
      <line class="ac" x1="150" y1="135" x2="450" y2="285"/>
      <circle class="hif" cx="300" cy="210" r="3.5"/><text x="300" y="232" text-anchor="middle">C (20, 0)</text>
      <circle class="acf" cx="450" cy="285" r="4.5"/><text class="ea" x="458" y="300">X (80, 30)</text>
      <circle class="acf" cx="150" cy="135" r="4.5"/><text class="ea" x="142" y="126" text-anchor="end">Y (−40, −30)</text>
      <circle class="hif" cx="467.7" cy="210" r="4"/><text class="em" x="474" y="204">σ1 = 87.1</text>
      <circle class="hif" cx="132.3" cy="210" r="4"/><text class="em" x="126" y="204" text-anchor="end">σ2 = −47.1</text>
      <line class="dash" x1="300" y1="210" x2="300" y2="42.3"/>
      <circle class="hif" cx="300" cy="42.3" r="3.5"/><text x="308" y="38">τmax = 67.1 (= R)</text>
      <circle class="hif" cx="300" cy="377.7" r="3.5"/>
      <path class="thin" d="M360 210 A 60 60 0 0 1 353.7 236.8"/>
      <text class="lb" x="366" y="236">2θp = 26.6°</text>
    </svg>`,
    caption: "Worked example 2.9 to scale: centre C = (σx+σy)/2 = 20, radius R = √(60² + 30²) = 67.1 = τmax. On the circle the angle is 2θ — the principal plane is 13.3° from x on the element.",
  },

  /* ---------------------------------------- 2.7  FAILURE ENVELOPES */
  "hb-som-failure": {
    label: "Failure envelopes in the σ1–σ2 plane (plane stress)",
    svg: `<svg viewBox="0 0 640 400" role="img" aria-label="Axes sigma 1 over sigma y horizontally and sigma 2 over sigma y vertically, each from minus 1 to plus 1. The maximum principal stress theory (Rankine) is a square with corners at plus and minus 1. The maximum shear stress theory (Tresca) is a hexagon inside it, touching the square at (1,0), (1,1), (0,1), (minus 1, 0), (minus 1, minus 1) and (0, minus 1). The distortion energy theory (von Mises) is an ellipse along the 45-degree line that passes through all six hexagon corners and bulges outside the hexagon between them. In the second and fourth quadrants, where the two stresses have opposite signs, the square extends well beyond the hexagon and ellipse, showing Rankine is unsafe for ductile materials there. A dot marks the stress state of worked example 2.10, 0.48 and minus 0.32, inside all three envelopes.">
      <line class="s" x1="160" y1="200" x2="490" y2="200"/>
      <line class="s" x1="320" y1="40" x2="320" y2="360"/>
      <text x="494" y="204">σ1/σy</text>
      <text x="326" y="36">σ2/σy</text>
      <text class="lb" x="436" y="216">1</text><text class="lb" x="200" y="216">−1</text>
      <text class="lb" x="326" y="86">1</text><text class="lb" x="326" y="326">−1</text>
      <rect class="s" x="210" y="90" width="220" height="220" style="stroke-dasharray:6 4"/>
      <path class="ac" d="M430 200 L430 90 L320 90 L210 200 L210 310 L320 310 Z"/>
      <ellipse class="hi" cx="320" cy="200" rx="155.6" ry="89.8" transform="rotate(-45 320 200)"/>
      <line class="dash" x1="190" y1="70" x2="450" y2="330"/>
      <text class="lb" x="456" y="342">pure shear (σ2 = −σ1)</text>
      <circle class="hif" cx="372.8" cy="235.2" r="4"/>
      <text class="em" x="380" y="250">EG 2.10</text>
      <text x="24" y="60">— — Rankine (square)</text>
      <text class="ea" x="24" y="80">Tresca (hexagon)</text>
      <text class="em" x="24" y="100">von Mises (ellipse)</text>
      <text class="lb" x="24" y="380">Inside = safe. Quadrants II &amp; IV: Rankine square goes far beyond the others.</text>
    </svg>`,
    caption: "For a ductile material with equal tension and compression yield. All three agree in uniaxial tension (1, 0); they differ most when the principal stresses have opposite signs — exactly the pure-shear case of a twisted shaft.",
  },
});
