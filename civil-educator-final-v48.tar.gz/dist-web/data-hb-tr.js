/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: TRANSPORTATION ENGINEERING
   ------------------------------------------------------------
   The eighth handbook. This one is built on IRC codes, not IS
   codes — highway geometry and pavement design are governed by
   the Indian Roads Congress, and the app keeps them clearly
   labelled as IRC, never as IS.

   One idea runs through it: a road carries two things it must be
   designed against at once — the MOVING vehicle (geometry: can it
   see, can it corner, can it stop?) and the REPEATED wheel load
   (pavement: will the surface last the traffic?). Geometry keeps
   people safe; the pavement keeps the road alive.

   Geometric and pavement values follow IRC 38, IRC 37, IRC 73 and
   related codes, named at the point of use. IRC codes are not IS
   codes. Confirm against the current published IRC document before
   using a value on real work.

   Chapters 1–2 here; later chapters follow in data-hb-tr2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "tr",
  subject: "transport",
  name: "Transportation Engineering",
  hi: "परिवहन अभियांत्रिकी",
  icon: "🛣",
  blurb: "Geometry se pavement tak — road ko dekhne, mudne aur rukne layak kaise banate hain, aur surface ko traffic ke laayak kaise. Yeh IRC ka hissa hai, IS nahi.",
  note: "Geometric and pavement design here follow the IRC codes (IRC 38, IRC 37, IRC 73 and related), named where they apply. IRC documents are NOT IS codes. Values are quoted for learning; confirm against the current IRC document before using one on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "tr-1",
      n: 1,
      title: "The Road as a System",
      hi: "एक तंत्र के रूप में सड़क",
      blurb: "The two demands a road answers at once — the moving vehicle and the repeated wheel load — and why alignment is the decision everything else follows from.",
      mins: 18,
      sections: [
        {
          n: "1.1",
          title: "Two demands, two halves of the subject",
          hi: "दो माँगें",
          blocks: [
            { k: "p", t: "A road has to do two quite different things at once, and the subject splits neatly along that line. It must let a moving vehicle travel safely — see far enough ahead, corner without skidding, stop in time. And it must carry the repeated pounding of wheel loads for years without breaking up. The first is geometric design; the second is pavement design." },
            { k: "cmp", t: "The two halves",
              cols: ["Geometric design", "Pavement design"],
              rows: [
                ["Deals with", "the moving vehicle", "the repeated wheel load"],
                ["Keeps", "people safe", "the road alive"],
                ["Governed by", "sight, speed, cornering", "traffic, subgrade, materials"],
                ["Failure looks like", "crashes, skidding", "cracks, ruts, potholes"],
              ] },
            { k: "note", t: "Keep the two halves separate as you read. A road can be geometrically perfect and still fail as a pavement (it cracks up under traffic), or structurally sound and still dangerous (a blind curve). Both have to be right, and they are designed by different rules." },
          ],
        },
        {
          n: "1.2",
          title: "Alignment — the decision everything follows",
          hi: "संरेखण",
          blocks: [
            { k: "p", t: "Before any of the detailed design, a route is chosen on the ground — the alignment. Every later cost, curve and gradient follows from it, and a bad alignment cannot be fixed by good detailing. It is the highest-leverage decision in the whole project." },
            { k: "def", term: "Alignment", t: "The position of the road's centre-line on the ground, in plan (horizontal alignment — the straights and curves) and in profile (vertical alignment — the gradients and summits). A good alignment is short, easy, safe and cheap to build and maintain — and those pull against each other." },
            { k: "list", items: [
              "<strong>Short & direct</strong> — less length, less cost, less travel time — but a straight line may cross hills and rivers expensively.",
              "<strong>Easy gradients</strong> — gentle slopes for heavy vehicles — but avoiding steep ground means going around, adding length.",
              "<strong>Safe</strong> — gentle curves, clear sight lines — which can conflict with the shortest route.",
              "<strong>Economical to build and maintain</strong> — avoiding bad soil, high embankments, deep cuts and waterlogged ground.",
            ] },
            { k: "real", t: "In hilly country the alignment problem is at its sharpest: a direct line means steep grades no truck can climb, so the road is deliberately lengthened, looping along the contours to keep the gradient walkable. <strong>The zig-zag mountain road is not bad design — it is the alignment trading length for gradient</strong>, exactly the balance this section is about." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "tr-2",
      n: 2,
      title: "Geometric Design — Cross-section and Sight Distance",
      hi: "ज्यामितीय डिज़ाइन — क्रॉस-सेक्शन और दृष्टि दूरी",
      blurb: "The shape of the road across its width and why every part sheds water, and the sight distance a driver needs to stop — reaction plus braking.",
      mins: 24,
      sections: [
        {
          n: "2.1",
          title: "The cross-section and camber",
          hi: "क्रॉस-सेक्शन और कैम्बर",
          blocks: [
            { k: "p", t: "Cut across a road and every feature you see has a purpose, and most of them are about water — because water, soaking into the layers below, is what destroys a pavement from underneath." },
            { k: "dia", id: "hb-tr-xsection", cap: "The cross-section, and why the surface is crowned." },
            { k: "def", term: "Camber (crossfall)", t: "The slope given to the road surface from the crown down to the edges so rainwater runs off quickly instead of soaking in. Steeper for rough surfaces (earth, gravel), flatter for smooth ones (bitumen ~1.7–2.5%, concrete ~1.7–2%), because a smooth surface drains at a gentler slope." },
            { k: "def", term: "Carriageway, shoulder, formation", t: "The carriageway is the paved part vehicles run on; the shoulder is the strip beside it for stopping and edge support; the formation (or subgrade level) is the prepared earth surface the whole pavement is built on." },
            { k: "trap", t: "Too little camber and water ponds and seeps into the pavement, softening the layers and the subgrade — the start of most pavement failure. Too much and vehicles feel the drag toward the edge and steer to the crown. The camber is a balance, and it is tied to how smooth (and therefore how free-draining) the surface is." },
          ],
        },
        {
          n: "2.2",
          title: "Stopping sight distance",
          hi: "रुकने की दृष्टि दूरी",
          blocks: [
            { k: "p", t: "The most basic safety requirement is that a driver can always see far enough ahead to stop before hitting something in the road. That distance — the stopping sight distance — is the sum of two separate parts." },
            { k: "dia", id: "hb-tr-ssd", cap: "The two parts of stopping sight distance." },
            { k: "def", term: "Stopping sight distance (SSD)", t: "The minimum clear distance ahead a driver needs to stop safely: the lag distance covered during the reaction time (at full speed), plus the braking distance covered while decelerating. SSD = v·t + v²/(2gf), with v the speed, t the reaction time (~2.5 s), f the longitudinal friction and g gravity." },
            { k: "eg", title: "Example 2.1 — SSD at highway speed",
              given: "Find the stopping sight distance for a design speed of 80 km/h. Take reaction time t = 2.5 s, longitudinal friction f = 0.35, g = 9.81 m/s².",
              steps: [
                { t: "Convert speed to m/s", w: "v = 80 / 3.6 = 22.22 m/s" },
                { t: "Lag distance (reaction)", w: "v·t = 22.22 × 2.5 = 55.6 m" },
                { t: "Braking distance", w: "v²/(2gf) = 22.22² / (2 × 9.81 × 0.35)\n         = 493.7 / 6.867 = 71.9 m" },
                { t: "Add them", w: "SSD = 55.6 + 71.9 = 127.5 m" },
              ],
              ans: "About 127.5 m of clear sight is needed. Notice the reaction part alone is 55.6 m — before the brakes even bite — which is why sight distance so often governs the geometry on fast roads, and why blind curves and crests are dangerous." },
            { k: "note", t: "Overtaking sight distance — the far longer distance needed to safely pass a slower vehicle on a two-lane road — is a separate and much larger requirement. SSD keeps you from hitting a stationary obstacle; overtaking sight distance decides where passing is allowed at all." },
          ],
        },
      ],
    },

  ],
});
