/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 11–12
   Bases, trusses, industrial buildings · Gantry girders, fatigue
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 11.1 COLUMN BASE */
  "hb-st-base": {
    label: "Slab base and gusseted base",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A slab base where the column sits on a thick plate spreading the load onto the concrete, beside a gusseted base where gussets and angles spread the load over a larger plate, with the projection dimensions a and b marked and the uniform pressure under the plate">
      ${hbmk("cb")}
      <text class="em" x="168" y="26" text-anchor="middle">SLAB BASE</text>
      <rect class="conc" x="130" y="52" width="76" height="86"/>
      <rect class="steel" x="66" y="138" width="204" height="22"/>
      <rect class="soft" x="46" y="160" width="244" height="44"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<line class="ac" x1="${80+i*26}" y1="186" x2="${80+i*26}" y2="164" marker-end="url(#cb-c)"/>`).join("")}
      <text class="lb" x="168" y="226" text-anchor="middle">concrete pedestal</text>
      <line class="ac" x1="66" y1="120" x2="130" y2="120" marker-end="url(#cb-c)" marker-start="url(#cb-c)"/>
      <text class="ea" x="98" y="114" text-anchor="middle">a</text>
      <line class="ac" x1="290" y1="138" x2="290" y2="160" marker-end="url(#cb-c)" marker-start="url(#cb-c)"/>
      <text class="ea" x="300" y="156">ts</text>
      <text class="lb" x="168" y="256" text-anchor="middle">the plate CANTILEVERS out from the</text>
      <text class="lb" x="168" y="276" text-anchor="middle">column face, carrying uniform pressure</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">GUSSETED BASE</text>
      <rect class="conc" x="496" y="52" width="56" height="70"/>
      <rect class="steel" x="466" y="52" width="10" height="70"/>
      <rect class="steel" x="572" y="52" width="10" height="70"/>
      <path class="steel" d="M466 52 L448 122 L466 122 Z"/>
      <path class="steel" d="M582 52 L600 122 L582 122 Z"/>
      <rect class="steel" x="424" y="122" width="200" height="20"/>
      <rect class="soft" x="408" y="142" width="232" height="44"/>
      <text class="lb" x="524" y="210" text-anchor="middle">gussets and cleats spread the load</text>
      <text class="lb" x="524" y="232" text-anchor="middle">further, so the plate can be thinner</text>
      <text class="em" x="524" y="262" text-anchor="middle">used for heavy loads, and wherever</text>
      <text class="em" x="524" y="284" text-anchor="middle">the base has to resist a moment</text>
    </svg>`,
    caption: "The base plate's job is to spread a very concentrated column load onto concrete that can take about 9 N/mm². Its thickness follows from treating the projection as a cantilever carrying the uniform bearing pressure — which is exactly what the Cl. 7.4.3.1 formula is.",
  },

  /* ---------------------------------------- 11.3 TRUSS */
  "hb-st-truss": {
    label: "A roof truss and what each member does",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A Fink roof truss in elevation with the top chord in compression, the bottom chord in tension, and the web members alternating between tension and compression, with purlins sitting on the top chord at panel points">
      ${hbmk("tr2")}
      <text class="em" x="350" y="24" text-anchor="middle">EVERY MEMBER IS A CHAPTER 5 OR A CHAPTER 6 PROBLEM</text>
      <path class="soft-b" d="M70 190 L350 66 L630 190"/>
      <path class="softa" d="M70 190 L630 190"/>
      <path class="s" d="M210 128 L210 190 M350 66 L350 190 M490 128 L490 190"/>
      <path class="s" d="M210 128 L280 190 M490 128 L420 190"/>
      ${[0,1,2,3,4].map(i=>`<rect class="steel" x="${64+i*140}" y="${182-i*24}" width="14" height="12" transform="rotate(-24 ${71+i*140} ${188-i*24})"/>`).join("")}
      ${grd(52, 196, 40)}
      ${grd(608, 196, 40)}
      <text class="em" x="200" y="100">TOP CHORD — compression</text>
      <text class="lb" x="200" y="118">(and local bending if purlins</text>
      <text class="lb" x="200" y="136">land between panel points)</text>
      <text class="em" x="350" y="216" text-anchor="middle">BOTTOM CHORD — tension</text>
      <text class="lb" x="350" y="236" text-anchor="middle">Chapter 5: gross yield, net rupture, block shear</text>
      <text class="lb" x="350" y="258" text-anchor="middle">web members alternate tension and compression — check both, and check the wind-reversal case</text>
      <text class="lb" x="80" y="56">purlins sit on the top chord</text>
    </svg>`,
    caption: "A truss is not a new subject — it is a collection of tension and compression members with connections between them. What makes truss design its own topic is the load reversal under wind: a member in tension under gravity can be in compression under uplift, and it must be checked for both.",
  },

  /* ---------------------------------------- 11.5 BRACING */
  "hb-st-bracing": {
    label: "Why an industrial building needs bracing in three planes",
    svg: `<svg viewBox="0 0 726 300" role="img" aria-label="An industrial shed frame shown in three dimensions with roof plan bracing between the trusses, vertical side wall bracing between the columns, and gable end bracing, with a note that without them the frame is a mechanism in the longitudinal direction">
      ${hbmk("br")}
      <text class="em" x="350" y="24" text-anchor="middle">THE FRAMES CARRY ACROSS — BRACING CARRIES ALONG</text>
      <path class="s" d="M90 220 L90 120 L230 70 L370 120 L370 220"/>
      <path class="s" d="M250 240 L250 140 L390 90 L530 140 L530 240"/>
      <path class="thin" d="M90 120 L250 140 M230 70 L390 90 M370 120 L530 140 M90 220 L250 240 M370 220 L530 240"/>
      <path class="hi" d="M90 120 L390 90 M230 70 L530 140"/>
      <path class="ac" d="M90 220 L250 140 M90 140 L250 240"/>
      ${grd(74, 224, 32)}
      ${grd(354, 224, 32)}
      ${grd(234, 244, 32)}
      ${grd(514, 244, 32)}
      <text class="ea" x="560" y="96">roof plan bracing</text>
      <text class="lb" x="560" y="114">— takes wind on the gable</text>
      <text class="lb" x="560" y="132">back to the side walls</text>
      <text class="ea" x="120" y="278">side wall bracing</text>
      <text class="lb" x="120" y="296">— takes it down to the foundations</text>
      <text class="em" x="430" y="200">without both, the shed is a</text>
      <text class="em" x="430" y="220">MECHANISM along its length</text>
      <text class="lb" x="430" y="242">— the frames are stiff across,</text>
      <text class="lb" x="430" y="260">and hinged along</text>
    </svg>`,
    caption: "A portal or truss frame is stiff in its own plane and has almost no stiffness perpendicular to it. Roof bracing collects wind from the gable and carries it to the side walls; side-wall bracing takes it to the ground. Both are structure, not accessories.",
  },

  /* ---------------------------------------- 12.1 CRANE LOADS */
  "hb-st-crane": {
    label: "The three crane loads on a gantry girder",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A gantry girder carrying a crane, with the vertical wheel loads increased by an impact factor, a lateral surge acting across the rail as the crab starts and stops, and a longitudinal drag along the rail as the crane itself brakes">
      ${hbmk("cr")}
      <text class="em" x="350" y="24" text-anchor="middle">THREE DIRECTIONS, THREE CAUSES</text>
      <rect class="conc" x="96" y="140" width="420" height="20"/>
      <rect class="steel" x="96" y="128" width="420" height="12"/>
      <rect class="soft" x="240" y="78" width="140" height="50"/>
      <text class="lb" x="310" y="108" text-anchor="middle">crab + load</text>
      <circle class="steel" cx="252" cy="122" r="8"/>
      <circle class="steel" cx="368" cy="122" r="8"/>
      <line class="hi" x1="252" y1="164" x2="252" y2="196" marker-end="url(#cr-m)"/>
      <line class="hi" x1="368" y1="164" x2="368" y2="196" marker-end="url(#cr-m)"/>
      <text class="ea" x="310" y="216" text-anchor="middle">① VERTICAL wheel loads × impact factor</text>
      <text class="lb" x="310" y="236" text-anchor="middle">the load is snatched off the ground, not lowered onto the rail</text>
      <line class="ac" x1="380" y1="100" x2="440" y2="100" marker-end="url(#cr-c)"/>
      <text class="ea" x="450" y="104">② LATERAL surge</text>
      <text class="lb" x="450" y="122">the crab starts and stops —</text>
      <text class="lb" x="450" y="140">and the girder has no</text>
      <text class="lb" x="450" y="158">lateral restraint at all</text>
      <line class="ac" x1="150" y1="134" x2="96" y2="134" marker-end="url(#cr-c)"/>
      <text class="ea" x="96" y="116">③ LONGITUDINAL drag</text>
      <text class="lb" x="96" y="98">the whole crane brakes</text>
      <text class="em" x="350" y="268" text-anchor="middle">and all of it happens tens of thousands of times — so FATIGUE applies</text>
      ${grd(80, 160, 32)}
      ${grd(504, 160, 32)}
    </svg>`,
    caption: "A gantry girder is the hardest common beam in steel design: biaxial bending from the surge, no lateral restraint because the crane runs on the top flange, dynamic amplification on every lift, and a fatigue check on top. It is where every chapter of this handbook arrives at once.",
  },

  /* ---------------------------------------- 12.3 FATIGUE */
  "hb-st-fatigue": {
    label: "Fatigue depends on the stress range, not the stress",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="On the left a stress history showing that what matters is the range between maximum and minimum rather than the peak value, and on the right an S N curve on logarithmic axes falling as a straight line with a cube law relationship between stress range and number of cycles">
      ${hbmk("fa")}
      <text class="em" x="168" y="26" text-anchor="middle">IT IS THE RANGE THAT COUNTS</text>
      <line class="s" x1="56" y1="56" x2="56" y2="210"/>
      <line class="s" x1="56" y1="210" x2="290" y2="210"/>
      <text class="lb" x="48" y="62" text-anchor="end">σ</text>
      <path class="hi" d="M56 160 C80 100 104 100 128 160 C152 220 176 220 200 160 C224 100 248 100 272 160"/>
      <line class="thin dash" x1="56" y1="104" x2="290" y2="104"/>
      <line class="thin dash" x1="56" y1="216" x2="290" y2="216"/>
      <line class="ac" x1="230" y1="104" x2="230" y2="216" marker-end="url(#fa-c)" marker-start="url(#fa-c)"/>
      <text class="ea" x="240" y="164">Δσ</text>
      <text class="lb" x="168" y="246" text-anchor="middle">a detail cycling 40 → 120 N/mm²</text>
      <text class="lb" x="168" y="266" text-anchor="middle">and one cycling 0 → 80 N/mm²</text>
      <text class="em" x="168" y="290" text-anchor="middle">have the SAME fatigue life</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">S–N CURVE (log–log)</text>
      <line class="s" x1="410" y1="56" x2="410" y2="210"/>
      <line class="s" x1="410" y1="210" x2="650" y2="210"/>
      <text class="lb" x="402" y="62" text-anchor="end">Δσ</text>
      <text class="lb" x="648" y="232" text-anchor="end">log N →</text>
      <path class="hi" d="M420 74 L560 168 L650 190"/>
      <circle class="hif" cx="560" cy="168" r="5"/>
      <text class="ea" x="440" y="110">slope 1 : 3</text>
      <text class="lb" x="570" y="160">5 × 10⁶ cycles</text>
      <text class="lb" x="524" y="250" text-anchor="middle">halve the stress range →</text>
      <text class="em" x="524" y="272" text-anchor="middle">EIGHT times the life</text>
      <text class="lb" x="524" y="292" text-anchor="middle">(and the detail's geometry sets the whole curve)</text>
    </svg>`,
    caption: "Fatigue cracks start at a stress concentration and grow a little on every cycle, so the driver is the size of the swing, not its height above zero. The cube law is why a small reduction in stress range buys a very large increase in life — and why a better weld detail is worth more than a bigger section.",
  },

  /* ---------------------------------------- 12.4 FIRE */
  "hb-st-fire": {
    label: "What heat does to steel",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A graph of the fraction of yield strength retained against temperature, showing little loss up to about 400 degrees, a steep fall through 500 to 700 degrees, and very little strength left beyond, with the usual critical temperature marked around 550 degrees">
      ${hbmk("fi")}
      <text class="em" x="350" y="24" text-anchor="middle">STEEL DOES NOT BURN — IT SOFTENS</text>
      <line class="s" x1="100" y1="52" x2="100" y2="214"/>
      <line class="s" x1="100" y1="214" x2="620" y2="214"/>
      <text class="lb" x="92" y="58" text-anchor="end">fy retained</text>
      <text class="lb" x="618" y="236" text-anchor="end">temperature →</text>
      <line class="thin dash" x1="100" y1="66" x2="620" y2="66"/>
      <text class="ea" x="626" y="70">100%</text>
      <path class="hi" d="M100 66 L250 70 C300 78 330 116 370 148 C420 184 500 204 620 210"/>
      <line class="acf" x1="352" y1="66" x2="352" y2="214" stroke-dasharray="3 3"/>
      <circle class="hif" cx="352" cy="136" r="5"/>
      <text class="ea" x="362" y="120">≈ 550 °C — the usual</text>
      <text class="lb" x="362" y="138">critical temperature</text>
      <text class="lb" x="180" y="258" text-anchor="middle">little loss below 400 °C</text>
      <text class="em" x="420" y="258" text-anchor="middle">the steep part — an unprotected section reaches it</text>
      <text class="em" x="420" y="276" text-anchor="middle">in fifteen to twenty minutes of a real fire</text>
    </svg>`,
    caption: "Concrete protects its own reinforcement with cover; a bare steel section has none, and heats quickly because it is thin and conducts well. Fire protection — boarding, spray, intumescent paint, or concrete encasement — is what buys the time, and IS 800 Section 16 is where the requirement is set.",
  },

});
