/* ============================================================
   CIVIL EDUCATOR — Code guides, part 1
   RCC, cement, aggregate, reinforcement, admixtures, handbooks.

   A "guide" is our own plain-language explanation of what a
   standard is for, what is inside it, and the values a student
   most often needs. It is NOT the text of the standard and is
   not a clause-by-clause paraphrase of one.
   ============================================================ */

window.DB = window.DB || {};
DB.guides = DB.guides || {};

DB.guideNote =
  "This guide is written for this app. It explains what the standard covers and the values most often needed — it is not the text of the standard. Confirm every value against the latest published edition before using it in design.";

Object.assign(DB.guides, {

  is10262: {
    what: "The recipe book for design mix concrete. IS 456 tells you what the concrete must achieve; IS 10262 tells you how to arrive at proportions that achieve it. It takes you from the specified grade, the exposure condition and the workability required, through a target mean strength, a water-cement ratio, a water content and an aggregate proportion, to a trial mix that is then adjusted on the basis of actual trial results.",
    use: "Any time concrete is specified as a design mix rather than a nominal mix — which, above M20, IS 456 requires. It is also the standard behind every mix design sheet a batching plant issues.",
    inside: [
      "Target mean strength — the design is never aimed at fck itself but at fck plus a margin, so that the characteristic strength is actually met",
      "Selection of the water-cement ratio, capped by the durability requirement of IS 456 Table 5",
      "Estimation of water content for the chosen workability and aggregate size, with corrections for admixtures and aggregate shape",
      "Calculation of cement content, and a check against the minimum cement content required for the exposure",
      "Proportion of coarse to fine aggregate, from the aggregate size and the fine aggregate zone",
      "Trial mixes and adjustment; guidance for high strength and self-compacting concrete",
    ],
    key: [
      ["Target mean strength", "fck + 1.65 s, where s is the standard deviation from the table — the 2019 revision also requires a check against fck + X and takes whichever is higher"],
      ["Assumed standard deviation", "M10–M15: 3.5 · M20–M25: 4.0 · M30 and above: 5.0 N/mm²"],
      ["Durability override", "The w/c ratio and cement content from IS 456 Table 5 always govern if they are stricter than the strength calculation"],
    ],
    watch: [
      "The mix design is a starting point, not an answer — the trial mix and its 28-day cubes are what settle the proportions.",
      "Field moisture in the aggregate must be deducted from the mixing water and added to the aggregate weight every single day, otherwise the designed w/c ratio never reaches the mixer.",
    ],
  },

  is383: {
    what: "The specification that says what may be called coarse or fine aggregate for concrete. It fixes the grading — how much of the material passes each sieve — the permitted nominal sizes, shape indices, and the limits on deleterious material such as clay lumps, coal, shale and material finer than 75 microns. The 2016 revision is the one that formally recognised manufactured sand and, within limits, recycled concrete aggregate.",
    use: "Whenever aggregate arrives on site and you have to decide whether to accept it, and whenever a mix design asks which grading zone the sand belongs to.",
    inside: [
      "Grading requirements for coarse aggregate by nominal size, single-sized and graded",
      "Four grading zones for fine aggregate, from Zone I (coarsest) to Zone IV (finest)",
      "Manufactured sand accepted as fine aggregate, with its own requirements",
      "Recycled concrete aggregate and recycled aggregate permitted within stated limits and applications",
      "Limits on deleterious materials, clay lumps and material passing the 75 micron sieve",
      "Flakiness and elongation indices, soundness and alkali-aggregate reactivity",
    ],
    key: [
      ["Common nominal sizes", "40 mm, 20 mm, 12.5 mm and 10 mm"],
      ["Fine aggregate zones", "Zone I to Zone IV — Zone II is the usual, well-graded natural sand"],
      ["Grading matters because", "A poorly graded sand needs more water for the same workability, and more water means less strength"],
    ],
    watch: [
      "Zone IV sand is very fine and should be used with caution in reinforced concrete — it pushes up the water demand.",
      "Bulking of damp sand can increase its volume by 20–30%, so volume batching without a bulking test quietly under-doses the sand.",
      "Recycled aggregate is permitted, but only in the applications and percentages the standard states — not as a general substitute.",
    ],
  },

  is1786: {
    what: "The specification for the high strength deformed bars that almost all Indian reinforced concrete uses. It fixes the strength grades, the minimum elongation, the ratio of ultimate to yield strength, the chemical composition, the rib geometry that creates the bond, and the rolling and marking requirements. The D grades — Fe 415D, Fe 500D, Fe 550D — are the same strength with a higher ductility requirement.",
    use: "Whenever steel is ordered, tested or accepted on site, and whenever a design calls for a particular grade. IS 13920 also restricts which grades may be used in earthquake-resistant frames.",
    inside: [
      "Grades Fe 415, Fe 500, Fe 550 and Fe 600, each with a plain and a D (higher ductility) variant",
      "Minimum yield stress, minimum percentage elongation and the minimum ratio of ultimate to yield stress",
      "Chemical composition limits — carbon, sulphur, phosphorus, and carbon equivalent for weldability",
      "Rib geometry and spacing, which is what produces the bond the development length formula assumes",
      "Nominal mass per metre, tolerances on mass, and bend and rebend test requirements",
      "Marking of the bar so the grade and maker can be identified after delivery",
    ],
    key: [
      ["Minimum elongation", "Fe 415: 14.5% · Fe 500: 12% · Fe 550: 10% — the D grades are substantially higher"],
      ["Ultimate to yield ratio", "Fe 500: not less than 1.08; the D grade requires more"],
      ["Design strength in IS 456", "0.87 fy — 361 N/mm² for Fe 415 and 435 N/mm² for Fe 500"],
    ],
    watch: [
      "Grade is not visible by eye. Ask for the test certificate and check the rolling marks — substituting Fe 415 for a design made in Fe 500 leaves the member about 20% short.",
      "Bars sold by length but paid by weight is where under-weight steel hides. Check mass per metre against the tolerance.",
      "IS 13920 requires the reinforcement in a ductile frame to satisfy ductility requirements — a plain high-grade bar is not automatically acceptable there.",
    ],
  },

  is1199: {
    what: "The test methods for concrete while it is still fresh — how to take a representative sample from a batch, and how to measure workability, density, air content and the actual cement or water content of a mix. The 2018 revision split the old single standard into parts, one per property.",
    use: "Every slump test on site is this standard. So is every set of cubes, because the sampling rules that decide whether the cubes represent the batch live here.",
    inside: [
      "Sampling fresh concrete from the mixer, the truck or the placed batch so the sample is representative",
      "Slump cone test, compacting factor test, vee-bee consistometer and flow table",
      "Determination of the density of fresh concrete",
      "Air content of fresh concrete",
      "Analysis of fresh concrete to determine cement and water content",
    ],
    key: [
      ["Slump cone", "Base 200 mm, top 100 mm, height 300 mm; filled in four layers, 25 strokes each"],
      ["What slump measures", "Workability — not strength. Two mixes with the same slump can differ by two grades"],
      ["Sampling rule", "The sample must come from several portions of the batch and be remixed before testing"],
    ],
    watch: [
      "A slump taken from the first concrete out of the truck is not representative — that is usually the wettest part of the load.",
      "Adding water on site after the slump test invalidates every cube already taken and every strength number in the design.",
    ],
  },

  is269: {
    what: "The current specification for Ordinary Portland Cement. The 2015 revision is the important one: it brought the 33, 43 and 53 grades together into a single standard, so IS 269 is now the reference for all three rather than only for 33 grade as it was historically.",
    use: "Whenever OPC is ordered or accepted. Test certificates for a modern OPC bag reference this standard.",
    inside: [
      "OPC of 33, 43 and 53 grade in one specification",
      "Chemical requirements — lime saturation factor, alumina-iron ratio, insoluble residue, magnesia, sulphuric anhydride and loss on ignition",
      "Physical requirements — fineness, soundness, setting times and compressive strength at 3, 7 and 28 days",
      "Packing, marking and storage requirements",
    ],
    key: [
      ["Grade means", "The 28-day compressive strength in N/mm² on standard mortar cubes — 33, 43 or 53"],
      ["Initial setting time", "Not less than 30 minutes"],
      ["Final setting time", "Not more than 600 minutes (10 hours)"],
      ["Fineness (specific surface)", "Not less than 225 m²/kg"],
    ],
    watch: [
      "The grade is the strength of a standard mortar cube, not of your concrete. A 53 grade cement does not make M53 concrete.",
      "Because IS 269:2015 now covers all three grades, an old bag or an old specification citing IS 8112 or IS 12269 is referring to a superseded standard — the material is the same, the reference has moved.",
    ],
  },

  is8112: {
    what: "The historical specification for 43 grade Ordinary Portland Cement — the workhorse grade for general building construction in India. Its requirements have been absorbed into IS 269:2015, but the standard is still widely quoted and still appears on older drawings, bags and test certificates.",
    use: "Reading an older specification, an old test certificate, or a bill of quantities written before the 2015 consolidation.",
    inside: [
      "Chemical requirements for 43 grade OPC",
      "Fineness, soundness by Le Chatelier and autoclave, and setting times",
      "Compressive strength requirements at 3, 7 and 28 days on standard sand mortar cubes",
      "Sampling, packing and marking",
    ],
    key: [
      ["3-day strength", "Not less than 23 N/mm²"],
      ["7-day strength", "Not less than 33 N/mm²"],
      ["28-day strength", "Not less than 43 N/mm²"],
      ["Soundness", "Le Chatelier expansion not more than 10 mm; autoclave expansion not more than 0.8%"],
    ],
    watch: [
      "43 grade is the right default for most building work. 53 grade is not automatically better — it generates more early heat and can increase shrinkage cracking in thin members.",
      "Cement gains strength from the day it is made. A bag stored for three months has already lost a significant part of its 28-day strength even if it looks perfectly dry.",
    ],
  },

  is12269: {
    what: "The historical specification for 53 grade Ordinary Portland Cement — the higher strength grade used for high grade concrete, precast, prestressed work and anywhere early strength matters. Like IS 8112, its requirements now sit inside IS 269:2015.",
    use: "High grade concrete, precast and prestressed elements, and any reading of an older specification that names this standard.",
    inside: [
      "Chemical requirements for 53 grade OPC",
      "Fineness, soundness and setting times",
      "Compressive strength at 3, 7 and 28 days",
      "Sampling, packing and marking",
    ],
    key: [
      ["3-day strength", "Not less than 27 N/mm²"],
      ["7-day strength", "Not less than 37 N/mm²"],
      ["28-day strength", "Not less than 53 N/mm²"],
      ["Fineness (specific surface)", "Not less than 225 m²/kg"],
    ],
    watch: [
      "53 grade sets up more heat of hydration. In thick sections or in hot weather that heat is a real cracking risk, and a blended cement is often the better choice.",
      "Using 53 grade does not let you reduce the cement content below the minimum that IS 456 Table 5 requires for the exposure condition.",
    ],
  },

  is1343: {
    what: "The code of practice for prestressed concrete — concrete that is deliberately put into compression by tensioned tendons before it carries any load, so that the tension a beam would otherwise develop simply cancels out part of that pre-compression. It covers both pre-tensioning, where the tendons are stressed before the concrete is cast, and post-tensioning, where ducts are cast in and the tendons stressed afterwards.",
    use: "Long span beams, bridge girders, precast hollow-core slabs, water tanks and any member where an ordinary reinforced section would be too deep or would crack.",
    inside: [
      "Materials — high tensile steel, ducts, anchorages and the higher concrete grades required",
      "Permissible stresses at transfer and at service, and the limit states approach",
      "Loss of prestress — elastic shortening, creep and shrinkage of concrete, relaxation of steel, friction and anchorage slip",
      "Design for flexure, shear and torsion in prestressed members",
      "Grouting of ducts, cover, and protection of tendons against corrosion",
      "Transmission length, end block design and anchorage zone reinforcement",
    ],
    key: [
      ["Minimum concrete grade", "M30 for post-tensioned work and M40 for pre-tensioned work"],
      ["Why higher grades", "The anchorage zone carries an enormous concentrated force, and the concrete must also resist creep, which directly costs prestress"],
      ["Losses", "Typically 15–20% in pre-tensioning and 20–25% in post-tensioning — never negligible"],
    ],
    watch: [
      "Corrosion of a tendon is a completely different problem from corrosion of a reinforcing bar — the tendon is highly stressed and its failure is sudden. Grouting quality is a structural issue, not a finishing one.",
      "The section must be checked at transfer as well as in service; at transfer the concrete is young and the prestress is at its highest.",
    ],
  },

  is3370: {
    what: "The code for concrete structures that hold liquids — water tanks, reservoirs, sumps, treatment plant structures. Its whole purpose is different from IS 456: strength is rarely the problem, leakage is. So the design is driven by crack width, and the code tightens the permissible crack widths, raises the minimum grade, increases minimum reinforcement and restricts the stress in the steel.",
    use: "Any overhead or underground tank, sump, swimming pool or sewage treatment structure.",
    inside: [
      "Part 1 — general requirements, materials, workmanship and testing",
      "Part 2 — reinforced concrete structures, including crack width control and minimum reinforcement",
      "Part 3 — prestressed concrete liquid retaining structures",
      "Part 4 — design tables for moments and forces in rectangular and circular tanks",
      "Joints — movement joints, construction joints and water bars",
      "Testing of the completed structure for watertightness",
    ],
    key: [
      ["Permissible crack width", "0.2 mm generally, reduced to 0.1 mm where appearance or aggressive exposure requires it"],
      ["Why working stress is still used", "Keeping the steel stress low keeps the cracks fine, which is the actual design objective"],
      ["Minimum grade", "Higher than ordinary RCC, because permeability rather than strength is the limit state"],
    ],
    watch: [
      "Minimum reinforcement in a liquid retaining wall is there to control shrinkage and thermal cracking, not to carry load — reducing it because the calculation does not need it is how tanks start leaking.",
      "Most tank leaks start at construction joints and at the wall-to-base junction. Detail the water bar and the joint before worrying about the wall thickness.",
    ],
  },

  is9103: {
    what: "The specification for chemical admixtures added to concrete — the dose is small but the effect is large. It classifies admixtures by what they do, and sets uniformity requirements so that a drum bought today behaves like the one tested last month, together with performance requirements measured against a control mix.",
    use: "Any concrete with a superplasticizer, retarder, accelerator or air-entraining agent, which today means almost all ready-mixed concrete.",
    inside: [
      "Types — accelerating, retarding, water reducing, air entraining, superplasticizing, and combinations",
      "Uniformity requirements — dry material content, ash content, relative density, chloride ion content and pH",
      "Performance requirements measured against a control mix — water reduction, setting time, compressive strength and bleeding",
      "Sampling, packing, marking and storage",
    ],
    key: [
      ["Water reduction", "A superplasticizer lets you cut water at the same workability, which directly raises strength"],
      ["Chloride content", "Limited by the standard, and it counts towards the total chloride limit of IS 456 Cl. 8.2.5"],
      ["Dose", "Always established by trial with your actual cement — the same admixture behaves differently with a different cement"],
    ],
    watch: [
      "Overdosing a retarder can delay setting by many hours; overdosing a superplasticizer causes segregation and bleeding. More is not better.",
      "An admixture is not a substitute for a proper mix design, and it must never be used to rescue a mix that has already been over-watered.",
    ],
  },

  sp16: {
    what: "Not a code — a handbook of design aids. SP 16 turns the design equations of IS 456 into charts and tables so that a section can be designed or checked without solving a quadratic or iterating an interaction equation by hand. It is the single most used reference in an Indian RCC design office and in the examination hall.",
    use: "Flexural design of beams and slabs, and above all column design, where the interaction charts save an amount of work that is hard to overstate.",
    inside: [
      "Tables for singly and doubly reinforced rectangular sections — Mu/bd² against percentage of steel, for each grade combination",
      "Interaction diagrams for rectangular and circular columns, for different steel distributions and cover ratios",
      "Charts for flanged sections",
      "Tables of development length, anchorage and lap length",
      "Areas of bar groups, and bar areas per metre width for slabs",
    ],
    key: [
      ["Most used pages", "The column interaction charts, entered with Pu/fck bD and Mu/fck bD² to read off p/fck"],
      ["Second most used", "Table of Mu/bd² against pt, which converts a moment straight into a steel percentage"],
      ["Status", "A Special Publication — a handbook, not a mandatory standard"],
    ],
    watch: [
      "SP 16 was published in 1980 and is keyed to the 1978 edition of IS 456. Most of the flexural material is unchanged, but bond, development length and some detailing values were revised in IS 456:2000 — check those against the current code rather than the handbook.",
      "Reading an interaction chart for the wrong d'/D ratio is the most common examination error; the charts are grouped by that ratio.",
    ],
  },

  sp34: {
    what: "The handbook on concrete reinforcement and detailing — the companion to SP 16 that deals not with how much steel but with where it goes, how it is bent, how it is anchored and how it is supported. It is where a drawing office learns to turn a design into a bar bending schedule that can actually be built.",
    use: "Preparing or checking reinforcement drawings and bar bending schedules; resolving the detailing questions IS 456 states but does not illustrate.",
    inside: [
      "Standard bends, hooks and their dimensions, with the allowances used in bar bending schedules",
      "Anchorage and lap details for beams, slabs, columns and walls",
      "Typical detailing of beams, slabs, columns, footings, staircases, corbels and openings",
      "Spacers, chairs and cover blocks — how the cover is actually maintained during concreting",
      "Congestion, bar placing sequence and practical buildability guidance",
    ],
    key: [
      ["Why it matters", "IS 456 gives the rules; SP 34 shows the details that satisfy them and can be built"],
      ["Bar bending", "Standard hook and bend allowances used in every BBS come from this family of documents"],
      ["Status", "A handbook, not a mandatory standard"],
    ],
    watch: [
      "The handbook predates IS 456:2000, so where a detail depends on a value the 2000 revision changed, the code wins.",
      "A detail that is theoretically correct but physically impossible at a congested joint will be changed on site by the bar bender. Draw the joint before issuing it.",
    ],
  },

  is2502: {
    what: "The standard behind every bar bending schedule. It covers the bending and fixing of reinforcement — the shapes bars are bent to, the dimensions of standard hooks and bends, the allowances that convert a drawn shape into a cut length, and the tolerances on the finished bar.",
    use: "Preparing a bar bending schedule, cutting and bending steel on site, and checking a steel quantity claim.",
    inside: [
      "Standard bar shapes and the way each is dimensioned",
      "Hook and bend allowances — the extra length a hook adds and the length a bend saves",
      "Minimum internal radius of bends, so the bar is not damaged by bending",
      "Tolerances on cut and bent bars, and on their fixed position",
      "Fixing, tying and supporting reinforcement in position",
    ],
    key: [
      ["Standard hook", "Adds about 9 times the bar diameter to the cut length"],
      ["Bend deductions", "About 1d for a 45° bend, 2d for 90° and 3d for 135° — a bent bar is shorter than the sum of its outside dimensions"],
      ["Why deductions exist", "Steel takes the short path around the inside of a bend; the outside dimensions on the drawing overstate the length required"],
    ],
    watch: [
      "Cut length is not the sum of the dimensions on the drawing. Forgetting the bend deductions inflates a steel estimate by a few percent across a whole building, which is a large number.",
      "Bending a bar too tightly, or re-bending a bar that has already been bent, can crack it — the standard sets minimum radii for a reason.",
    ],
  },

  "is3812-1": {
    what: "The specification for pulverized fuel ash — fly ash — when it is used as a pozzolana in cement, mortar and concrete. A pozzolana has little cementing value on its own, but reacts with the calcium hydroxide that cement hydration releases to form more binder. Part 1 covers this pozzolanic use; the companion part covers its use as an admixture.",
    use: "Any blended cement, any concrete with part of the cement replaced by fly ash, and any mix design aiming at lower heat, lower permeability or lower cost.",
    inside: [
      "Chemical requirements — silica plus alumina plus iron oxide, loss on ignition, sulphuric anhydride, magnesia and alkalis",
      "Physical requirements — fineness, lime reactivity, compressive strength of a blended mortar and soundness",
      "Sampling, packing, marking and storage",
    ],
    key: [
      ["Fineness (specific surface)", "Not less than 320 m²/kg"],
      ["Lime reactivity", "Not less than 4.5 N/mm²"],
      ["Loss on ignition", "Not more than 5% — high LOI means unburnt carbon, which wrecks air entrainment and darkens the concrete"],
      ["What it gives you", "Lower heat of hydration, better workability, denser and less permeable concrete in the long term"],
    ],
    watch: [
      "Fly ash concrete gains strength slowly. Judging it by a 7-day cube leads people to reject perfectly good concrete; specify and judge it at 28 or 56 days.",
      "Not all fly ash is the same. Ash from different sources, or from the same plant on different days, varies — test it, do not assume it.",
    ],
  },

  is1344: {
    what: "The specification for calcined clay pozzolana — clay fired at a controlled temperature so that it becomes reactive, then ground. It is the traditional alternative to fly ash as a pozzolana, and is graded by how strongly it reacts with lime.",
    use: "Blended cements and mortars, particularly where fly ash is not available, and in conservation or low-carbon work where a clay pozzolana suits the mix.",
    inside: [
      "Grades of calcined clay pozzolana, distinguished mainly by lime reactivity",
      "Chemical requirements including loss on ignition and sulphuric anhydride",
      "Physical requirements — fineness, lime reactivity, compressive strength and soundness",
      "Sampling and marking",
    ],
    key: [
      ["What a pozzolana does", "Reacts with the free lime released by cement hydration to form additional binder"],
      ["Benefit", "Denser, less permeable paste and lower heat of hydration"],
      ["Grading basis", "Lime reactivity — how much strength a lime-pozzolana mortar develops"],
    ],
    watch: [
      "Calcination temperature decides everything. Under-fired clay is inert, over-fired clay is inert — only material fired in the right range is reactive.",
      "Like fly ash, it slows early strength gain, which matters for formwork striking times.",
    ],
  },

  is2645: {
    what: "The specification for integral waterproofing compounds — the materials added into the mix, rather than applied to the surface afterwards. They work mainly by blocking or reducing the capillary pores through which water travels, and the standard tests whether they actually do that without damaging the concrete in other ways.",
    use: "Basement and retaining walls, water tanks, roof slabs and any concrete or mortar that must resist water penetration from within the mix.",
    inside: [
      "Types of integral waterproofing compound and their general requirements",
      "Permeability requirement, measured against a control mix without the compound",
      "Requirement that compressive strength is not reduced below that of the control mix",
      "Effect on setting time, and limits on chloride content",
      "Sampling, packing and marking",
    ],
    key: [
      ["How it is judged", "Reduced permeability compared with a control mix, without loss of strength"],
      ["Chloride", "Limited, and it counts towards the total chloride limit of IS 456"],
      ["What it does not do", "It does not bridge cracks and it does not compensate for poor compaction"],
    ],
    watch: [
      "An integral compound is not a waterproofing system. Most water gets into concrete through cracks, honeycombs and joints — dense, well-compacted, well-cured concrete and proper joint details do far more than any additive.",
      "Some compounds are chloride-bearing; in reinforced work that is a corrosion risk, so check the certificate.",
    ],
  },

});
