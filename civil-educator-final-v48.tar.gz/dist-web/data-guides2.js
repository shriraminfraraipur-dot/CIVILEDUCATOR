/* ============================================================
   CIVIL EDUCATOR — Code guides, part 2
   Structural, masonry, soil & foundation, highway, water.
   Our own plain-language explanations — not code text.
   ============================================================ */

window.DB = window.DB || {};
DB.guides = DB.guides || {};

Object.assign(DB.guides, {

  /* ---------------------------------------------- STRUCTURAL */
  "is875-4": {
    what: "The snow load part of the loading code. Snow is treated as a load that accumulates on a roof, so the design value is the ground snow load for the location multiplied by a shape coefficient that depends on the roof geometry. A steep roof sheds snow and gets a smaller coefficient; a shallow roof, a valley between two pitches, or the low side of a step in a roof collects drifted snow and gets a larger one.",
    use: "Any structure in the Himalayan belt and other high-altitude regions of India where snow accumulates — in the plains the clause does not arise.",
    inside: [
      "Ground snow load for the location, and how it is established",
      "Shape coefficients for flat, single-pitch, multi-pitch and curved roofs",
      "Drifting and unbalanced snow — valleys, roof steps, and obstructions",
      "Combination of snow load with other loads",
    ],
    key: [
      ["Basic form", "Design snow load on the roof = shape coefficient × ground snow load"],
      ["Steep roofs", "Shed snow, so the shape coefficient falls as the pitch increases"],
      ["Worst case", "Drifted snow against a parapet, a valley, or the lower roof of a stepped building"],
    ],
    watch: [
      "Snow and wind are both governed by the roof shape but in opposite ways — a shallow roof is good for wind uplift and bad for snow accumulation.",
      "Unbalanced snow, where one slope is loaded and the other is clear, is often worse for a truss than a full symmetric load.",
    ],
  },

  "is1893-2": {
    what: "The earthquake code for liquid retaining tanks. A tank is not a building: part of the water moves with the tank as if it were rigidly attached, and part sloshes back and forth at its own much longer period. IS 1893 Part 2 replaces the single-mass building model with a two-mass model — an impulsive mass rigidly attached and a convective mass on a spring — and designs the tank for both.",
    use: "Overhead service reservoirs, ground-supported tanks, sumps and any liquid retaining structure in a seismic zone.",
    inside: [
      "Two-mass idealisation — impulsive and convective (sloshing) components of the contained liquid",
      "Time period for each of the two modes, calculated separately",
      "Hydrodynamic pressure distribution on the wall and base",
      "Design of the staging of an elevated tank, which is usually the critical element",
      "Sloshing wave height and the freeboard required to accommodate it",
    ],
    key: [
      ["Two masses", "Impulsive — moves with the tank; convective — sloshes at a much longer period"],
      ["Critical element", "The staging of an elevated tank, not the container"],
      ["Freeboard", "Provided so the sloshing wave does not damage the roof or spill"],
    ],
    watch: [
      "A tank must be checked both full and empty. Empty is often worse for the staging under uplift, and a full tank is worse for base shear.",
      "Elevated tank stagings failed repeatedly in Indian earthquakes because they were detailed as ordinary frames — the bracing and the column detailing matter more than the container does.",
    ],
  },

  "is1893-3": {
    what: "The earthquake code for bridges and retaining walls. Bridges respond differently from buildings: the mass is concentrated in the deck, the substructure is a small number of tall piers, and the connection between deck and pier decides everything. The part covers the seismic design of the substructure, the bearings and the connections, and the dynamic earth pressure on retaining walls.",
    use: "Any road or rail bridge in a seismic zone, and the seismic check of retaining walls and abutments.",
    inside: [
      "Seismic coefficients and the response reduction factors appropriate to bridge components",
      "Design of piers, abutments and foundations for seismic forces",
      "Bearings, seismic restrainers and the seat width needed to prevent the deck unseating",
      "Dynamic increment of earth pressure on retaining walls and abutments",
      "Liquefaction considerations for bridge foundations",
    ],
    key: [
      ["Dominant mass", "The deck — it drives the inertia force delivered to every pier"],
      ["Classic failure", "The deck falling off its bearing — which is why minimum seat width and restrainers matter"],
      ["Retaining walls", "Earth pressure increases dynamically during shaking, above the static active pressure"],
    ],
    watch: [
      "Span unseating is a displacement problem, not a strength problem. A pier can be perfectly strong and the bridge still collapse because the deck moved further than the seat allowed.",
      "Skew and curved bridges rotate during shaking and are considerably more vulnerable than straight ones.",
    ],
  },

  "is1893-4": {
    what: "The earthquake code for industrial structures, including stack-like structures such as chimneys, silos and towers. Industrial structures differ from buildings in three ways the code addresses: heavy equipment gives them very concentrated masses, they are often irregular or open framed, and a chimney or silo behaves as a slender cantilever rather than a shear building.",
    use: "Plant structures, pipe racks, boiler and turbine buildings, silos, chimneys, cooling towers and equipment supports.",
    inside: [
      "Classification of industrial structures and their importance factors",
      "Seismic design of frames supporting heavy equipment and machinery",
      "Stack-like structures — chimneys, silos and towers treated as slender cantilevers",
      "Design of equipment supports and anchorages",
      "Non-building structures that do not fit the building model of Part 1",
    ],
    key: [
      ["Why separate", "Concentrated equipment masses and open, irregular framing break the assumptions of Part 1"],
      ["Stack-like structures", "Behave as a cantilever with distributed mass — higher modes matter"],
      ["Importance factor", "Raised for structures whose failure would cause a hazard beyond the plant"],
    ],
    watch: [
      "Equipment anchorage is the item most often under-designed and most often damaged. A vessel that slides off its saddle is a plant shutdown even if the structure is intact.",
      "Mass from stored material in a silo participates in the earthquake response — an empty silo and a full one are different structures.",
    ],
  },

  is801: {
    what: "The code for cold-formed light gauge steel — members made by bending thin sheet rather than hot rolling. Because the plate is so thin, local buckling of the individual flat elements happens long before the member yields, so the code works with an effective width of each element rather than its full width, and with form factors that account for the loss.",
    use: "Purlins, side rails, roof and floor decking, light steel framing, storage racking and pre-engineered building secondary members.",
    inside: [
      "Effective width of stiffened and unstiffened compression elements",
      "Form factor and its effect on the allowable stress",
      "Design of members in tension, compression, bending and combined actions",
      "Web crippling of thin webs under concentrated load",
      "Connections — bolts, screws, welds and their behaviour in thin material",
      "Lateral bracing requirements for light gauge members",
    ],
    key: [
      ["Governing failure", "Local buckling of a thin flat element, well before the member yields"],
      ["Design basis", "This standard is written on the working stress method, unlike IS 800:2007"],
      ["Efficiency", "Very high strength to weight ratio, which is why purlins are cold-formed and not rolled"],
    ],
    watch: [
      "Do not mix IS 801 with IS 800:2007 in one calculation — one is allowable stress, the other is limit state.",
      "A cold-formed section is only as good as its bracing. An unbraced Z-purlin will twist and fail at a fraction of its calculated capacity.",
    ],
  },

  is808: {
    what: "The dimension standard for hot rolled steel sections — beams, columns, channels and angles. It is not a design code; it is the table every steel design depends on. Every section property you use — area, moment of inertia, section modulus, radius of gyration, mass per metre — comes from here, and the designations ISMB, ISLB, ISMC and ISA are defined here.",
    use: "Every steel design, every steel take-off and every fabrication drawing. Open it the moment you have chosen a trial section.",
    inside: [
      "Designations and dimensions of I-sections — ISMB, ISLB, ISHB, ISWB and their families",
      "Channels — ISMC, ISLC and their dimensions",
      "Equal and unequal angles — ISA designations",
      "Sectional properties — area, mass, moment of inertia, section modulus and radius of gyration about both axes",
      "Rolling tolerances on dimensions and mass",
    ],
    key: [
      ["ISMB 400 means", "Indian Standard Medium weight Beam, 400 mm nominal depth"],
      ["What you read off", "A, Ixx, Iyy, Zxx, Zyy, rxx, ryy and mass per metre"],
      ["Note", "Modern parallel flange beams and columns are covered by their own standard, not by IS 808"],
    ],
    watch: [
      "rmin for an angle is about the axis through the heel, not about either leg — using the wrong one is the classic truss design error.",
      "Availability is a real constraint. A section that exists in the table may not exist in the local market; check before issuing the drawing.",
    ],
  },

  is2062: {
    what: "The material specification behind every hot rolled structural steel section and plate in India. It defines the grades by yield strength — E 250 upwards — and, separately, the quality sub-grades by impact toughness. The grade tells you how strong the steel is; the sub-grade tells you how it behaves at low temperature and under impact, which is what protects against brittle fracture.",
    use: "Ordering structural steel, checking a mill test certificate, and choosing material for thick welded plate or for dynamically loaded members.",
    inside: [
      "Grades designated E followed by the yield strength — E 250, E 275, E 300, E 350, E 410, E 450 and above",
      "Quality sub-grades A, BR, B0 and C, distinguished by impact test requirements",
      "Chemical composition limits and the carbon equivalent, which governs weldability",
      "Mechanical properties — yield stress, tensile strength and percentage elongation, tabulated by thickness",
      "Tolerances, testing, marking and certification",
    ],
    key: [
      ["E 250", "fy 250, fu 410 N/mm² — the default structural steel"],
      ["E 350", "fy 350, fu 490 N/mm² — heavier frames and towers"],
      ["Sub-grade", "A has no impact requirement; BR, B0 and C add progressively more demanding impact tests"],
      ["fy falls with thickness", "Always read the yield stress for the plate thickness you are actually using"],
    ],
    watch: [
      "Stronger steel is no stiffer. E is 2 × 10⁵ N/mm² for every grade, so deflection and buckling do not improve with grade.",
      "For thick welded plates, cold regions or impact loading, the sub-grade matters as much as the grade — specify it.",
    ],
  },

  is13935: {
    what: "The guideline for what to do with a masonry building that already exists and is not earthquake safe. It covers how to evaluate the building, and then the repair and strengthening techniques — from crack stitching and grouting to splints and bandages, jacketing, containment reinforcement and the introduction of new seismic bands.",
    use: "Retrofitting existing houses, schools and public buildings; post-earthquake assessment and repair.",
    inside: [
      "Seismic evaluation of an existing masonry building — what to look for and how to judge it",
      "Repair of cracks — stitching, grouting and injection",
      "Strengthening — splints and bandages, reinforced concrete or ferrocement jacketing",
      "Insertion of horizontal seismic bands and vertical reinforcement into an existing building",
      "Strengthening of openings, corners and gable walls",
      "Improving the connection between walls, and between walls and roof",
    ],
    key: [
      ["First priority", "Tying the building together — wall-to-wall and wall-to-roof connections"],
      ["Splint and bandage", "Vertical splints at corners and junctions plus horizontal bandages at lintel and eaves level"],
      ["Repair is not strengthening", "Filling a crack restores appearance; it does not add seismic capacity"],
    ],
    watch: [
      "Most of India's earthquake risk sits in buildings already standing, not in new ones — which is why this guideline matters more in practice than its low profile suggests.",
      "A partial retrofit can be worse than none if it stiffens one part of a building and leaves the rest flexible.",
    ],
  },

  /* ---------------------------------------------- MASONRY */
  is12894: {
    what: "The specification for fly ash-lime bricks — bricks made by reacting fly ash with lime and a binder and curing them, rather than by firing clay. They consume an industrial waste, save topsoil and fuel, and come out more dimensionally accurate than burnt clay bricks, which saves plaster.",
    use: "Load bearing and non-load bearing masonry as an alternative to burnt clay brick, particularly near thermal power stations where fly ash is abundant.",
    inside: [
      "Classification by compressive strength class",
      "Dimensions and permitted tolerances",
      "Compressive strength, water absorption, dry density and drying shrinkage requirements",
      "Efflorescence requirement",
      "Sampling, marking and acceptance",
    ],
    key: [
      ["Advantage", "Much better dimensional accuracy than burnt clay brick, so thinner and more even plaster"],
      ["Environmental", "Uses fly ash instead of topsoil, and needs no kiln firing"],
      ["Judged by", "Compressive strength class, water absorption and drying shrinkage"],
    ],
    watch: [
      "These bricks are thirsty. Soak them properly before laying or they will pull the water straight out of the mortar and leave it unhydrated.",
      "Drying shrinkage is higher than for burnt clay; expect and detail for shrinkage cracking in long walls.",
    ],
  },

  is2185: {
    what: "The specification for concrete masonry units — hollow and solid concrete blocks. Blocks are larger than bricks, so a wall goes up faster with less mortar, and hollow blocks are lighter and give better thermal performance. The standard classifies them by whether they are load bearing, by density, and by compressive strength.",
    use: "Block masonry in buildings, boundary walls and infill walls in framed construction.",
    inside: [
      "Hollow and solid blocks, load bearing and non-load bearing",
      "Grades and density classifications",
      "Compressive strength requirements, reported on the gross or net area as the standard directs",
      "Dimensions, tolerances and the face shell and web thickness of hollow units",
      "Water absorption, drying shrinkage and moisture movement",
    ],
    key: [
      ["Why hollow", "Lighter walls, faster laying, less mortar, and the cores can take vertical reinforcement"],
      ["Strength basis", "Read carefully whether the quoted strength is on the gross or the net area — for hollow units they differ greatly"],
      ["Companion parts", "Other parts of IS 2185 cover lightweight and autoclaved aerated units"],
    ],
    watch: [
      "Concrete blocks shrink as they dry; clay bricks expand slightly as they take up moisture. Blocks must be well cured and then allowed to dry before laying, or the wall cracks.",
      "Do not soak concrete blocks before laying the way you soak clay bricks — dampen the surface only.",
    ],
  },

  "is1597-1": {
    what: "The code of practice for rubble stone masonry — walls built from stone broadly as it comes from the quarry rather than from dressed blocks. It covers random rubble, coursed rubble and their variants, and sets the rules that make such a wall behave as one wall rather than as two independent skins with rubble between them.",
    use: "Foundations, retaining walls, compound walls, and traditional load bearing construction in stone-bearing regions.",
    inside: [
      "Types of rubble masonry — random rubble uncoursed and coursed, square rubble, polygonal work",
      "Requirements for the stones, the mortar and the joints",
      "Through stones (bond stones), quoins and jamb stones",
      "Laying, bonding, wall thickness and the treatment of corners and junctions",
      "Pointing, curing and protection",
    ],
    key: [
      ["Through stones", "Stones running the full thickness of the wall at regular intervals — the single most important rule"],
      ["Joint thickness", "Kept as small as the stone shape allows; a thick mortar joint is a weak joint"],
      ["Chips and spalls", "Used to fill interstices, never to replace the stone that should be there"],
    ],
    watch: [
      "Rubble masonry without through stones is two thin skins with loose hearting between them; in an earthquake it delaminates, and this has killed more people in Indian earthquakes than almost any other detail.",
      "Rounded river boulders are poor material for a wall — they cannot interlock. Use quarried stone with rough faces.",
    ],
  },

  /* ---------------------------------------------- SOIL & FOUNDATION */
  is1080: {
    what: "The code of practice for shallow foundations — isolated footings, combined footings and strip footings on soil. It covers how deep a footing has to go, what to check, and how to proportion it, and it is the standard that sits behind the phrase 'safe bearing capacity' on a drawing.",
    use: "Every ordinary building footing. It is the first foundation code a student meets and the one most site work rests on.",
    inside: [
      "Minimum depth of foundation, and the factors that decide it — soil type, moisture variation, frost, scour and adjacent construction",
      "Determination of allowable bearing pressure from bearing capacity and from permissible settlement",
      "Proportioning of isolated, combined and strip footings",
      "Foundations on made-up ground, expansive soil and sloping ground",
      "Construction requirements — dewatering, inspection of the founding stratum and protection of the excavation",
    ],
    key: [
      ["Minimum depth", "Generally not less than 500 mm below natural ground level"],
      ["Allowable bearing pressure", "The lesser of the value from shear failure with a factor of safety, and the value that keeps settlement within the permitted limit"],
      ["Settlement usually governs", "In sands and soft clays it is settlement, not shear failure, that limits the pressure"],
    ],
    watch: [
      "'Safe bearing capacity' on a drawing is meaningless without saying which of the two criteria produced it and what settlement was assumed.",
      "In black cotton and other expansive soils the minimum depth rule is not enough — the footing must sit below the zone of seasonal moisture change, or be designed to tolerate the movement.",
    ],
  },

  "is8009-1": {
    what: "The standard for calculating how much a shallow foundation will settle under a symmetrical static vertical load. Bearing capacity asks whether the soil will fail; this asks how far the building will go down, and how unevenly, which is usually the question that actually governs the design.",
    use: "Any foundation where settlement matters — which is most of them, particularly on clays and on loose to medium sands.",
    inside: [
      "Components of settlement — immediate (elastic), consolidation and secondary compression",
      "Stress distribution beneath a loaded area, and the depth of significant stress",
      "Calculation of immediate settlement from elastic parameters",
      "Consolidation settlement from oedometer test parameters",
      "Time rate of consolidation settlement",
      "Permissible total and differential settlement for different structures",
    ],
    key: [
      ["Three components", "Immediate, consolidation and secondary — in sand the first dominates, in clay the second"],
      ["What damages buildings", "Differential settlement, not total settlement — a building that goes down evenly is largely unharmed"],
      ["Significant depth", "Stress from a footing dies away with depth; the settlement calculation only needs the zone where it is significant"],
    ],
    watch: [
      "Consolidation settlement in a thick clay can continue for years. The structure must be designed for the final value, not the value at handover.",
      "Adjacent footings of very different size on the same soil settle by different amounts even under the same pressure — that is a differential settlement the calculation must catch.",
    ],
  },

  is1892: {
    what: "The code of practice for subsurface investigation — how to find out what is under the site before anything is designed. It covers the planning of the investigation, the number and spacing of boreholes, how deep to go, what samples to take and how to preserve them, the field tests to run, and what the report must contain.",
    use: "The very first activity on any project. Every bearing capacity, every settlement estimate and every pile length rests on it.",
    inside: [
      "Planning an investigation — desk study, site reconnaissance and the scope of exploration",
      "Methods of exploration — trial pits, augering, wash boring, rotary drilling",
      "Number, spacing and depth of boreholes for different types of structure",
      "Disturbed and undisturbed sampling, sample preservation and labelling",
      "Field tests — standard penetration, cone penetration, vane shear, plate load",
      "Groundwater observation and the contents of the investigation report",
    ],
    key: [
      ["Depth of exploration", "Generally taken to the depth at which the stress from the foundation becomes insignificant — commonly of the order of one and a half times the width of the loaded area"],
      ["Undisturbed samples", "Needed for strength and consolidation tests on clay; a disturbed sample can only give classification"],
      ["Groundwater", "Recorded during and after boring — the standing level days later is the one that matters"],
    ],
    watch: [
      "Skimping on investigation is the most expensive saving in civil engineering. A surprise at foundation level costs many times what the extra boreholes would have.",
      "A borehole is a point. Between two boreholes anything can happen, which is why spacing rules and site geology both matter.",
    ],
  },

  is2131: {
    what: "The method for the standard penetration test — the field test that produces the N value on every borehole log in India. A split spoon sampler is driven into the bottom of a borehole by a standard hammer falling a standard height, and the number of blows required is counted. It is crude, it is operator-sensitive, and it is by far the most used soil test in the world.",
    use: "Reading or specifying any borehole log. N correlates with relative density in sands, with consistency in clays, and with bearing capacity, settlement and liquefaction potential.",
    inside: [
      "The split spoon sampler and its dimensions",
      "The hammer, its mass, the height of free fall and the driving procedure",
      "Counting blows over three successive 150 mm penetrations, and which two count",
      "Refusal criteria",
      "Corrections applied to the field value before it is used in design",
    ],
    key: [
      ["Hammer", "63.5 kg falling freely through 750 mm"],
      ["Penetration", "Driven 450 mm in three 150 mm increments; N is the blows for the last 300 mm"],
      ["First 150 mm", "Ignored as seating drive — the bottom of the borehole is disturbed"],
      ["Refusal", "50 blows without achieving the required penetration"],
    ],
    watch: [
      "The field N is not the design N. Overburden correction and dilatancy correction are applied first, and a report that does not say which corrections were used is incomplete.",
      "SPT in gravel is unreliable — a single large particle can stop the sampler and give a meaningless high N.",
    ],
  },

  is1888: {
    what: "The method for the plate load test — a rigid steel plate is loaded on the soil at foundation level in increments, and the settlement is recorded at each increment. The resulting load-settlement curve gives the bearing capacity and the modulus of subgrade reaction directly, in the field, on the real soil.",
    use: "Confirming a design bearing pressure before construction, and determining the modulus of subgrade reaction for a raft or a pavement design.",
    inside: [
      "Plate sizes and the test pit dimensions",
      "Loading arrangement — kentledge or reaction truss",
      "Load increments, the duration of each and the settlement readings taken",
      "Plotting and interpretation of the load-settlement curve",
      "Correction of plate results to the size of the actual foundation",
    ],
    key: [
      ["Plate", "Rigid steel plate, commonly 300 to 750 mm square"],
      ["Test pit", "Excavated to foundation level, with a width several times the plate size"],
      ["Output", "Ultimate bearing capacity and the modulus of subgrade reaction"],
    ],
    watch: [
      "The test only stresses the soil to a depth of about twice the plate width. A weak layer below that is completely invisible to it — which is exactly how plate load tests have led to settlement failures.",
      "Scaling the result from a small plate to a large footing is not a simple proportion, and it is different for sand and for clay.",
    ],
  },

  /* ---------------------------------------------- HIGHWAY */
  irc73: {
    what: "The geometric design standard for rural, non-urban highways — the document that fixes the shape of the road itself rather than its structure. Design speed, carriageway and shoulder widths, camber, sight distances, horizontal curve radii and superelevation, vertical curves and gradients all come from here.",
    use: "Laying out a highway alignment and checking an existing one for geometric adequacy.",
    inside: [
      "Classification of rural highways and the design speed for each terrain type",
      "Cross-section elements — carriageway width, shoulders, roadway width and right of way",
      "Camber for different surface types",
      "Sight distance — stopping, intermediate and overtaking",
      "Horizontal alignment — curve radii, superelevation, transition curves and widening on curves",
      "Vertical alignment — gradients, summit and valley curves",
    ],
    key: [
      ["Design speed", "Set by highway class and terrain — plain, rolling, mountainous or steep"],
      ["Camber", "Steeper on earth and gravel surfaces, flattest on bituminous and cement concrete"],
      ["Superelevation", "Limited by the risk to slow-moving vehicles, not only by the fast ones"],
    ],
    watch: [
      "Geometry is a safety standard, not an aesthetic one. Sight distance and curve radius decide whether a driver can stop in time.",
      "Do not mix this with the structural design of the pavement — that is IRC:37 for flexible and IRC:58 for rigid pavements.",
    ],
  },

  "irc-sp20": {
    what: "The Rural Roads Manual — the single reference for village road projects, and the document the Pradhan Mantri Gram Sadak Yojana is built on. It brings survey and investigation, geometric design, pavement design, drainage, cross-drainage structures, construction, quality control and maintenance for low-volume rural roads into one place.",
    use: "Any rural road project: alignment, pavement composition, culverts, drainage and quality control.",
    inside: [
      "Survey, investigation and alignment of rural roads",
      "Geometric design standards appropriate to low traffic volumes",
      "Pavement design for low-volume roads, including options in local and marginal materials",
      "Drainage, and the design of small cross-drainage structures",
      "Construction practice and quality control for rural roads",
      "Maintenance planning",
    ],
    key: [
      ["Design traffic", "Very low compared with a national highway, which changes both geometry and pavement thickness"],
      ["Local materials", "Deliberately accommodated — the manual is written for what is available near the village"],
      ["Drainage", "The most common cause of rural road failure, and treated accordingly"],
    ],
    watch: [
      "A rural road fails from water far more often than from traffic. Side drains and cross drainage are not optional extras.",
      "Rural geometry standards are lower than highway standards by design — applying IRC:73 values to a village road wastes money without adding safety.",
    ],
  },

  irc6: {
    what: "The loading standard for road bridges — Section II of the IRC bridge code. It defines the standard vehicle loadings that every Indian road bridge is designed for, together with impact, wind, water current, earth pressure, temperature, braking, centrifugal and collision forces, and the combinations in which they act.",
    use: "Every road bridge design and every load rating of an existing bridge.",
    inside: [
      "Standard live loadings — Class AA (tracked and wheeled), Class 70R, Class A and Class B trains of vehicles",
      "Impact factor, and how it varies with span and with the type of loading",
      "Reduction in longitudinal effect for multi-lane loading",
      "Braking, centrifugal, wind, water current, buoyancy and earth pressure forces",
      "Temperature effects, seismic force by reference to IS 1893, and vehicle collision loads",
      "Load combinations for working stress and limit state design",
    ],
    key: [
      ["Class A", "The standard loading for all permanent bridges on main roads"],
      ["Class AA and 70R", "Heavier loadings for bridges on specified routes — usually the ones that govern"],
      ["Class B", "A lighter loading for temporary structures and specified minor roads"],
      ["Impact factor", "Reduces as the span increases"],
    ],
    watch: [
      "IRC and MoRTH documents are not Indian Standards. They are published by the Indian Roads Congress and the Ministry, and should never be cited as IS codes.",
      "The critical loading is found by placing the vehicle train in the worst position, which is rarely the middle of the span.",
    ],
  },

  irc112: {
    what: "The unified code of practice for concrete road bridges — the document that replaced the separate reinforced and prestressed concrete bridge codes and put both on a single limit state basis. It is the bridge world's equivalent of the shift IS 800:2007 made in steel buildings.",
    use: "Design of reinforced and prestressed concrete road bridges and their substructures.",
    inside: [
      "Limit state design philosophy, partial safety factors and load combinations",
      "Material properties for concrete, reinforcing steel and prestressing steel",
      "Design for flexure, shear, torsion and punching, including the strut-and-tie method",
      "Serviceability — stress limits, crack width and deflection",
      "Prestressed concrete, losses, and anchorage zone design",
      "Detailing rules, durability and cover requirements for bridge exposure conditions",
      "Fatigue and, in the associated documents, seismic design",
    ],
    key: [
      ["Scope", "Reinforced and prestressed concrete together in one limit state code"],
      ["Durability", "Bridge exposure is harsher than building exposure, so cover and grade requirements are stricter"],
      ["Analysis tool", "Strut-and-tie is formally recognised for disturbed regions such as pier caps and diaphragms"],
    ],
    watch: [
      "Loads come from IRC:6 and workmanship from MoRTH — IRC:112 is the design code and does not stand alone.",
      "Its notation and partial factors differ from IS 456; do not carry a coefficient across from one to the other.",
    ],
  },

  morth: {
    what: "The Specifications for Road and Bridge Works — not a design code but the construction specification that every highway contract in India is written against. It says what materials are acceptable, how each layer is to be built, what tolerances apply and what tests must be run at what frequency. When a contract says 'as per MoRTH', this is the document.",
    use: "Construction and quality control of road and bridge works; writing or checking a bill of quantities; settling a site dispute about acceptability.",
    inside: [
      "Series 100 — general, site clearance and preliminary works",
      "Series 200 — site clearance, and 300 — earthwork, erosion control and drainage",
      "Series 400 — sub-bases, bases (non-bituminous) and shoulders",
      "Series 500 — bases and surface courses (bituminous)",
      "Series 600 — cement concrete pavement",
      "Series 700 onwards — geosynthetics, structures, foundations, substructures, superstructures and bearings",
      "Series 900 — quality control: test procedures, frequencies and acceptance criteria",
    ],
    key: [
      ["What it is", "A construction specification, not a design code"],
      ["The 900 series", "The part most often needed on site — test frequency and acceptance"],
      ["Publisher", "Ministry of Road Transport and Highways — not the Bureau of Indian Standards"],
    ],
    watch: [
      "MoRTH is not an Indian Standard and must not be labelled as one.",
      "Most contractual arguments about road quality are settled by the test frequency table, not by opinion — know which clause covers the layer in dispute.",
    ],
  },

  is73: {
    what: "The specification for paving bitumen. The important thing about the current standard is that Indian bitumen is now graded by viscosity, not by penetration — VG 10, VG 20, VG 30, VG 40 — because viscosity at the temperature the material is actually mixed and laid at predicts performance far better than a needle penetrating a sample at 25 °C.",
    use: "Specifying and accepting bitumen for any bituminous road layer.",
    inside: [
      "Viscosity grades VG 10, VG 20, VG 30 and VG 40",
      "Requirements — absolute viscosity at 60 °C, kinematic viscosity at 135 °C, penetration, flash point, solubility and ductility",
      "Thin film oven test residue requirements, which model what happens during mixing",
      "Sampling, packing and marking",
    ],
    key: [
      ["VG 10", "Spraying applications — surface dressing, paving in very cold climates"],
      ["VG 30", "The general purpose paving grade for most of India"],
      ["VG 40", "Heavy traffic, high stress locations, intersections and toll plazas"],
      ["Grading basis", "Viscosity at 60 °C, which is close to the hottest pavement service temperature"],
    ],
    watch: [
      "The old penetration grades — 60/70, 80/100 — still appear in conversation and in old specifications. They are not the current designation; do not put them on a new specification.",
      "Overheating bitumen in the boiler ages it permanently. A grade correct on the delivery note can be effectively a different material by the time it reaches the paver.",
    ],
  },

  /* ---------------------------------------------- WATER & SERVICES */
  is2065: {
    what: "The code of practice for water supply in buildings — the plumbing side of building services. It covers the estimation of demand, the sizing and layout of pipework, storage, pumping, hot water systems, and the requirements that keep the supply safe from contamination.",
    use: "Designing or checking the internal water supply of any building, and sizing tanks and pumps.",
    inside: [
      "Estimation of water demand for different building types and occupancies",
      "Storage requirements — underground sump and overhead tank capacities",
      "Pipe materials, sizing, layout and permissible velocities",
      "Pumping systems, and pressure required at the fixture",
      "Hot water supply and its distribution",
      "Prevention of contamination — air gaps, backflow prevention and cross-connection control",
    ],
    key: [
      ["Typical domestic demand", "Of the order of 135 litres per head per day for residences with full flushing systems"],
      ["Storage", "Usually split between an underground sump and an overhead tank, sized for a stated hours of supply"],
      ["Cross-connection", "Never permit a direct connection between the potable system and any other source"],
    ],
    watch: [
      "Oversized pipes are wasteful and undersized pipes are noisy and starve the top floor. Velocity limits are what keep the sizing honest.",
      "Backflow into the potable system is the one plumbing failure that can make people ill; air gaps at tank inlets are not a detail to value-engineer away.",
    ],
  },

  is5329: {
    what: "The code of practice for sanitary pipe work above ground — the drainage side of building plumbing. It covers soil and waste pipes, traps, ventilation of the system, and the layout rules that keep the water seal in every trap intact while the system is in use.",
    use: "Designing or checking the drainage of a building; diagnosing a smell or gurgling complaint in an existing one.",
    inside: [
      "Systems of plumbing — one-pipe, two-pipe and single stack, and where each is appropriate",
      "Soil pipes, waste pipes, vent pipes and anti-siphonage pipes",
      "Traps, their water seal depth and the causes of seal loss",
      "Sizing and gradient of horizontal branches and stacks",
      "Access — inspection openings, cleanouts and testing of the installed system",
    ],
    key: [
      ["Trap seal", "The water in a trap is the only barrier between the building and the drain"],
      ["Seal loss", "Caused by self-siphonage, induced siphonage, back pressure, evaporation and capillary action"],
      ["Ventilation", "Exists to protect the seal, not to remove smell from the pipe"],
    ],
    watch: [
      "A smell complaint is nearly always a lost trap seal, and a lost seal is nearly always a ventilation or gradient problem — not a problem with the trap itself.",
      "Too steep a gradient is as bad as too flat: the water runs away and leaves the solids behind.",
    ],
  },

  is10500: {
    what: "The specification for drinking water — the standard that decides whether a water supply is fit to drink in India. It gives, for each parameter, an acceptable limit and a second limit permissible only in the absence of an alternate source, together with the health or aesthetic reason behind each.",
    use: "Assessing a borewell, a municipal supply or a treatment plant output; specifying the quality a water treatment scheme must achieve.",
    inside: [
      "Organoleptic and physical parameters — colour, odour, taste, turbidity, pH and total dissolved solids",
      "General parameters — hardness, chloride, sulphate, nitrate, fluoride, iron and residual chlorine",
      "Toxic substances — arsenic, cadmium, chromium, lead, mercury and others",
      "Pesticide residues and radioactive substances",
      "Bacteriological requirements",
      "Two-tier limits: acceptable, and permissible in the absence of an alternate source",
    ],
    key: [
      ["pH", "6.5 to 8.5"],
      ["Turbidity", "1 NTU acceptable, 5 NTU permissible in the absence of an alternate source"],
      ["Total dissolved solids", "500 mg/l acceptable, 2000 mg/l permissible in the absence of an alternate source"],
      ["Total hardness (as CaCO₃)", "200 mg/l acceptable, 600 mg/l permissible in the absence of an alternate source"],
      ["Fluoride", "1.0 mg/l acceptable, 1.5 mg/l permissible in the absence of an alternate source"],
      ["Bacteriological", "No coliform organisms detectable in the stated sample volume"],
    ],
    watch: [
      "The second column is not a design target. It is what may be tolerated when there is genuinely no alternative source, and toxic parameters such as arsenic and lead have no such relaxation in practice.",
      "Fluoride cuts both ways — too little causes dental caries, too much causes fluorosis, which is endemic in parts of India.",
    ],
  },

  is3025: {
    what: "The family of test methods for water and wastewater — the procedures behind every number on a water analysis report. Each part covers one parameter or group of parameters, from sampling and pH through hardness, chlorides, dissolved oxygen, BOD and COD to heavy metals.",
    use: "Running or interpreting a water quality test; checking that a laboratory report used the right method.",
    inside: [
      "Sampling, preservation and transport of water and wastewater samples",
      "Physical parameters — colour, odour, turbidity, temperature, conductivity and solids",
      "Chemical parameters — pH, acidity, alkalinity, hardness, chlorides, sulphates, nitrogen forms",
      "Oxygen demand — dissolved oxygen, biochemical oxygen demand and chemical oxygen demand",
      "Metals and trace elements",
      "Each part is a separate standard for one parameter or method",
    ],
    key: [
      ["BOD", "The oxygen micro-organisms consume breaking down organic matter — conventionally measured over 5 days at 20 °C"],
      ["COD", "The oxygen equivalent of what a strong chemical oxidant can oxidise — always higher than BOD, and much faster to measure"],
      ["Sampling", "Preservation and holding time decide whether the result means anything"],
    ],
    watch: [
      "A sample taken carelessly cannot be rescued by a good laboratory. Container type, preservation and time to analysis are part of the method, not administrative detail.",
      "BOD and COD are not interchangeable, and their ratio is itself diagnostic of how biodegradable a wastewater is.",
    ],
  },

  is9401: {
    what: "The method of measurement of works in river valley projects — dams, barrages, canals, tunnels, powerhouses and their associated works. It plays the same role for water resources projects that IS 1200 plays for buildings: it defines what is measured, in what unit, and what is deemed included in the rate.",
    use: "Preparing or checking bills of quantities and running bills on irrigation and hydropower projects.",
    inside: [
      "Excavation in different materials and classifications, including rock",
      "Tunnelling, shafts and underground works",
      "Concrete in dams and appurtenant structures",
      "Grouting, drilling and foundation treatment",
      "Canal works, lining and earthwork",
      "Each part covers one class of work, with its own units and deductions",
    ],
    key: [
      ["Why it exists", "So that contractor and client measure the same work the same way"],
      ["Classification of excavation", "Where most disputes on these projects begin and end"],
      ["Unit of measurement", "Defined per item, along with what the rate is deemed to include"],
    ],
    watch: [
      "The definition of 'rock' for payment purposes is a measurement question, not a geological one — read the classification clause before pricing.",
      "Items deemed included in a rate are as important as the item measured; that is where a bill quietly transfers risk.",
    ],
  },

  is4985: {
    what: "The specification for unplasticized PVC pipes for potable water supply — the white or grey rigid plastic pipe used for cold water mains, distribution and underground service connections. Pipes are classified by the pressure they can sustain and identified by outside diameter.",
    use: "Specifying and accepting uPVC pipe for cold water supply, and matching pipe class to the working pressure.",
    inside: [
      "Classification by pressure rating",
      "Dimensions — outside diameter, wall thickness and tolerances",
      "Material requirements, including suitability for potable water",
      "Tests — hydrostatic pressure, reversion, opacity, impact and effect on water quality",
      "Marking, jointing and handling",
    ],
    key: [
      ["Identified by", "Outside diameter — unlike steel tube, which is designated by a nominal bore"],
      ["Class", "Chosen from the working pressure, including surge, not from the average pressure"],
      ["Cold water only", "uPVC softens with heat; hot water needs CPVC"],
    ],
    watch: [
      "uPVC degrades under sunlight. Pipe stored in the open for months, or run exposed on a terrace, becomes brittle.",
      "Solvent-cemented joints need the right cement, clean dry surfaces and a proper curing time before pressure is applied.",
    ],
  },

  is15778: {
    what: "The specification for chlorinated PVC pipes for hot and cold potable water distribution. CPVC is PVC with extra chlorine, which raises the temperature it can handle, so it is the standard internal plumbing pipe for buildings that carry hot water. Pipes are designated by a standard dimension ratio, which fixes wall thickness relative to diameter.",
    use: "Internal hot and cold water plumbing in buildings.",
    inside: [
      "Standard dimension ratio designations and their pressure ratings",
      "Dimensions, wall thickness and tolerances",
      "Material requirements and suitability for potable water",
      "Tests — hydrostatic, thermal, impact and effect on water quality",
      "Marking, solvent cement jointing and support spacing",
    ],
    key: [
      ["SDR", "Standard dimension ratio — outside diameter divided by wall thickness; a lower SDR means a thicker, higher pressure pipe"],
      ["Hot water", "The reason CPVC exists; ordinary uPVC is not suitable"],
      ["Pressure rating", "Falls as the operating temperature rises — always read the rating at the actual temperature"],
    ],
    watch: [
      "CPVC expands noticeably with temperature. Long hot water runs need expansion loops or offsets and correctly spaced supports, or the pipe will buckle and the joints will be stressed.",
      "Use CPVC solvent cement, not PVC cement. They are not interchangeable and the joint will fail.",
    ],
  },

  is4984: {
    what: "The specification for polyethylene pipes for water supply — the black coiled pipe used for buried mains and rural water supply. Its great advantages are that it comes in long coils with far fewer joints, it tolerates ground movement, and a properly fused joint is as strong as the pipe itself.",
    use: "Buried water mains, rural water supply schemes, and service connections where flexibility and few joints matter.",
    inside: [
      "Material designations by long-term strength — PE 63, PE 80 and PE 100",
      "Pressure ratings and the corresponding wall thicknesses",
      "Dimensions and tolerances",
      "Tests — hydrostatic, melt flow rate, carbon black content, oxidation induction time",
      "Jointing by butt fusion and electrofusion, and marking",
    ],
    key: [
      ["PE 100", "The highest of the common grades — a thinner wall for the same pressure than PE 80"],
      ["Coils", "Small diameters come in long coils, so a buried main can run hundreds of metres without a joint"],
      ["Carbon black", "Provides the ultraviolet protection that lets the pipe be stored and handled in the open"],
    ],
    watch: [
      "Fusion jointing is a skilled operation with controlled temperature, pressure and cooling time. A poorly fused joint looks perfect and fails later.",
      "Pressure rating falls with temperature, and PE is more sensitive to this than metal pipe.",
    ],
  },

  "is1239-1": {
    what: "The specification for mild steel tubes — the galvanised or black steel pipe used for water, gas and general engineering, and identified by nominal bore rather than outside diameter. Tubes are supplied in three classes distinguished by wall thickness and, on site, by the colour band painted on them.",
    use: "Specifying and identifying GI pipe for plumbing, fire fighting and general services.",
    inside: [
      "Light, medium and heavy classes and their wall thicknesses",
      "Dimensions by nominal bore, with tolerances on thickness, mass and straightness",
      "Galvanizing requirement and the mass of zinc coating",
      "Tests — hydrostatic, bend, flattening and tensile",
      "Screwed and socketed ends, threading, and marking including the colour code",
    ],
    key: [
      ["Colour code", "Yellow for light, blue for medium, red for heavy"],
      ["Designation", "By nominal bore — a 25 mm pipe is not 25 mm outside diameter"],
      ["Typical use", "Medium class for general water supply; heavy class where pressure or mechanical damage demands it"],
    ],
    watch: [
      "Never use light class for a pressure application — it exists for conduit and structural uses, and site staff read colours faster than certificates.",
      "Threading cuts through the galvanizing. The cut threads must be protected or the pipe will corrode from the joints outward.",
    ],
  },

});
