/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: TRANSPORTATION ENGINEERING handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   Note: geometric/pavement values follow IRC (not IS) — named as IRC.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 2.1 CROSS-SECTION */
  "hb-tr-xsection": {
    label: "The road cross-section and camber",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A road cross-section showing the crowned carriageway with camber sloping to both sides, shoulders, side drains, the embankment, and the layers of the pavement from wearing course down to the subgrade, with the reason camber exists to shed rainwater.">
      ${hbmk("xs")}
      <text class="em" x="350" y="24" text-anchor="middle">EVERY SHAPE ON A ROAD SHEDS WATER OR CARRIES LOAD</text>
      <path class="conc" d="M120 130 Q350 108 580 130 L580 158 Q350 136 120 158 Z"/>
      <path class="s" d="M120 130 Q350 108 580 130"/>
      <line class="s" x1="60" y1="176" x2="120" y2="158"/>
      <line class="s" x1="580" y1="158" x2="640" y2="176"/>
      <path class="soft" d="M60 176 L120 158 L120 200 L60 210 Z"/>
      <path class="soft" d="M640 176 L580 158 L580 200 L640 210 Z"/>
      <text class="lb" x="350" y="100" text-anchor="middle">CROWN (highest point)</text>
      <line class="ac" x1="350" y1="116" x2="480" y2="126" marker-end="url(#xs-c)"/>
      <text class="ea" x="470" y="120">camber slopes each way</text>
      <text class="lb" x="90" y="196" text-anchor="middle">shoulder</text>
      <text class="lb" x="610" y="196" text-anchor="middle">shoulder</text>
      <path class="hi" d="M44 210 L58 196 L72 210 Z" fill="none"/>
      <path class="hi" d="M628 210 L642 196 L656 210 Z" fill="none"/>
      <text class="lb" x="58" y="228" text-anchor="middle">side drain</text>
      <text class="lb" x="642" y="228" text-anchor="middle">side drain</text>

      <line class="gl" x1="120" y1="250" x2="580" y2="250"/>
      <text class="em" x="350" y="244" text-anchor="middle">CAMBER = the crossfall that drains rain off the surface</text>
      <text class="lb" x="350" y="272" text-anchor="middle">too little camber → water soaks in and softens the layers below; too much → vehicles drift to the edge</text>
      <text class="lb" x="350" y="292" text-anchor="middle">bitumen ~1.7–2.5%, concrete ~1.7–2%, earth/gravel steeper — smoother surface, flatter camber</text>
    </svg>`,
    caption: "A road cross-section is not arbitrary — every feature does a job, and most of them are about water. The carriageway is crowned so rain runs off to the sides rather than soaking in; the shoulders give a recovery space and support the edge; the side drains carry the water away. <strong>Water is the enemy of every pavement</strong>, because it weakens the layers beneath, so shedding it fast is the first thing the geometry is designed to do.",
  },

  /* ------------------------------------------- 2.2 SIGHT DISTANCE */
  "hb-tr-ssd": {
    label: "Stopping sight distance — reaction plus braking",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A vehicle approaching a stationary obstacle, with the stopping sight distance split into two parts: the lag distance travelled during the driver's reaction time at constant speed, and the braking distance travelled while decelerating to a stop.">
      ${hbmk("sd2")}
      <text class="em" x="350" y="24" text-anchor="middle">CAN THE DRIVER STOP IN TIME? — TWO DISTANCES, ADDED</text>
      <line class="s" x1="50" y1="150" x2="650" y2="150"/>
      <rect class="steel" x="70" y="128" width="46" height="22" rx="3"/>
      <circle class="s" cx="82" cy="152" r="6"/><circle class="s" cx="106" cy="152" r="6"/>
      <path class="hi" d="M600 118 L600 150" /><path class="hif" d="M592 118 L608 118 L600 104 Z"/>
      <text class="lb" x="600" y="170" text-anchor="middle">obstacle</text>

      <line class="ac" x1="120" y1="196" x2="330" y2="196" marker-end="url(#sd2-c)" marker-start="url(#sd2-c)"/>
      <text class="em" x="225" y="188" text-anchor="middle">LAG distance</text>
      <text class="lb" x="225" y="214" text-anchor="middle">driver reacts (t ≈ 2.5 s)</text>
      <text class="lb" x="225" y="232" text-anchor="middle">still at full speed = v·t</text>
      <line class="ac" x1="330" y1="196" x2="600" y2="196" marker-end="url(#sd2-c)" marker-start="url(#sd2-c)"/>
      <text class="em" x="465" y="188" text-anchor="middle">BRAKING distance</text>
      <text class="lb" x="465" y="214" text-anchor="middle">brakes on, decelerating</text>
      <text class="lb" x="465" y="232" text-anchor="middle">= v² / (2 g f)</text>

      <text class="em" x="350" y="264" text-anchor="middle">SSD = v·t + v² / (2 g f)</text>
      <text class="lb" x="350" y="284" text-anchor="middle">the road must give AT LEAST this much clear sight ahead — the driver spends the first 2.5 s just reacting</text>
    </svg>`,
    caption: "Stopping sight distance is how far ahead a driver must be able to see to stop safely, and it has two quite separate parts. During the reaction time — about 2.5 seconds — the vehicle keeps going at full speed, covering the lag distance before the brakes even engage. Only then does the braking distance begin. <strong>At highway speed the reaction part alone is over fifty metres</strong>, which is why sight distance, not braking, often governs the geometry.",
  },

  /* ------------------------------------------- 2.3 SUPERELEVATION */
  "hb-tr-super": {
    label: "Superelevation — banking a curve against skidding",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A vehicle on a banked road curve, with the outer edge raised so that the road is tilted, and the forces shown: the centrifugal force outward balanced by a component of the vehicle's weight down the slope plus side friction, with the design rule capping superelevation and then relying on friction.">
      ${hbmk("se")}
      <text class="em" x="350" y="24" text-anchor="middle">TILT THE ROAD SO THE CURVE HELPS HOLD THE CAR IN</text>
      <path class="conc" d="M120 210 L520 130 L520 158 L120 238 Z"/>
      <path class="s" d="M120 210 L520 130"/>
      <line class="ac" x1="120" y1="250" x2="520" y2="170" marker-end="url(#se-c)" marker-start="url(#se-c)"/>
      <text class="lb" x="320" y="234" text-anchor="middle" transform="rotate(-11 320 234)">outer edge RAISED by e·B</text>

      <g class="an-sway" style="--amp:8;--dur:5s">
        <rect class="steel" x="300" y="150" width="52" height="26" rx="4" transform="rotate(-11 326 163)"/>
        <line class="ac" x1="326" y1="163" x2="386" y2="163" marker-end="url(#se-c)"/>
        <text class="ea" x="392" y="160">centrifugal → out</text>
        <line class="ac" x1="326" y1="163" x2="326" y2="210" marker-end="url(#se-c)"/>
        <text class="ea" x="332" y="204">weight ↓</text>
      </g>

      <line class="gl" x1="470" y1="60" x2="470" y2="258"/>
      <text class="em" x="488" y="86">the design rule (IRC):</text>
      <text class="lb" x="488" y="112">e = V² / (225 R)</text>
      <text class="lb" x="488" y="132">(V km/h, R m — the 0.75 method)</text>
      <text class="ea" x="488" y="162">if e &gt; 0.07 → provide 0.07,</text>
      <text class="lb" x="488" y="180">let side friction take the rest:</text>
      <text class="lb" x="488" y="200">f = V²/(127R) − e   (limit 0.15)</text>
      <text class="lb" x="488" y="230">if even that fails, the curve is</text>
      <text class="lb" x="488" y="248">too sharp — restrict the speed</text>
      <text class="lb" x="350" y="286" text-anchor="middle">superelevation and friction share the job; the code caps how much tilt you may use</text>
    </svg>`,
    caption: "On a curve, centrifugal force tries to push the vehicle outward and off the road. Superelevation — raising the outer edge — tilts the road so a component of the vehicle's own weight pulls it back in, sharing the work with side friction. But you cannot tilt without limit (a slow or stopped vehicle would slide inward on a steep bank), so IRC caps superelevation at 0.07 and leaves the rest to friction. <strong>When both together are not enough, the curve is simply too sharp for the speed.</strong>",
  },

  /* ------------------------------------------- 3.2 DESIGN TRAFFIC / MSA */
  "hb-tr-msa": {
    label: "Design traffic — from today's trucks to msa",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Today's commercial vehicle count growing year on year over the design life, each truck axle counted by its damaging effect, accumulated into millions of standard axles, with the fourth-power law showing that a heavy axle does vastly more damage than a light one.">
      ${hbmk("ms")}
      <text class="em" x="350" y="24" text-anchor="middle">PAVEMENTS ARE DESIGNED FOR TRUCKS, NOT CARS</text>
      ${[0,1,2,3,4,5].map(i=>`<rect class="soft" x="${90+i*40}" y="${180-i*18}" width="28" height="${60+i*18}"/>`).join("")}
      <line class="s" x1="80" y1="240" x2="330" y2="240"/>
      <text class="lb" x="205" y="262" text-anchor="middle">traffic grows each year (rate r)</text>
      <text class="lb" x="205" y="280" text-anchor="middle">over the design life (n years)</text>
      <line class="ac" x1="90" y1="196" x2="290" y2="112" marker-end="url(#ms-c)"/>

      <line class="gl" x1="356" y1="52" x2="356" y2="290"/>
      <text class="em" x="374" y="78">cumulative standard axles:</text>
      <text class="lb" x="374" y="104">N = 365 × A × [((1+r)ⁿ − 1)/r]</text>
      <text class="lb" x="374" y="124">          × D × F   ÷ 10⁶ = msa</text>
      <text class="ea" x="374" y="152">A = initial commercial vehicles/day</text>
      <text class="lb" x="374" y="172">D = lane distribution · F = vehicle damage factor</text>
      <text class="em" x="374" y="202">the FOURTH-POWER law:</text>
      <text class="lb" x="374" y="224">damage ∝ (axle load / standard load)⁴</text>
      <text class="lb" x="374" y="248">double the axle load → 16× the damage.</text>
      <text class="lb" x="374" y="268">one overloaded truck can do the harm</text>
      <text class="lb" x="374" y="286">of thousands of cars — so cars barely count</text>
    </svg>`,
    caption: "A pavement is designed for the damage traffic will do over its whole life, not for today's count — so you grow the current commercial traffic year on year and accumulate it as millions of standard axles (msa). The startling part is the fourth-power law: a heavy axle does not do a little more damage than a light one, it does dramatically more. <strong>Doubling an axle load multiplies its damage roughly sixteenfold</strong>, which is why overloading destroys roads and why private cars are essentially ignored in the design.",
  },

  /* ------------------------------------------- 6.1 FLEXIBLE VS RIGID */
  "hb-tr-flexrigid": {
    label: "Flexible vs rigid — two ways to carry a wheel",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A wheel load on a flexible pavement spreading through granular layers in a widening cone to the subgrade, beside the same load on a rigid concrete slab that bridges over the subgrade like a beam, showing that the flexible pavement passes stress to the soil while the rigid slab carries it in bending.">
      ${hbmk("fr")}
      <text class="em" x="350" y="24" text-anchor="middle">TWO PHILOSOPHIES FOR THE SAME WHEEL</text>
      <text class="em" x="180" y="46" text-anchor="middle">FLEXIBLE (bitumen)</text>
      <rect class="steel" x="160" y="66" width="40" height="16" rx="3"/>
      <line class="ac" x1="180" y1="50" x2="180" y2="64" marker-end="url(#fr-c)"/>
      ${[["wearing",84,"soft"],["base",104,"conc"],["sub-base",128,"soft"],["subgrade",158,"softa"]].map(([t,y,c])=>
        `<rect class="${c}" x="80" y="${y}" width="200" height="${t==='subgrade'?40:18}"/>
         <text class="lb" x="290" y="${y+13}">${t}</text>`).join("")}
      <path class="hi" d="M170 82 L120 196 M190 82 L240 196" />
      <path class="hi dash" d="M120 196 L240 196"/>
      <text class="lb" x="180" y="232" text-anchor="middle">load spreads in a widening cone,</text>
      <text class="lb" x="180" y="250" text-anchor="middle">each layer weaker than the one above</text>
      <text class="lb" x="180" y="272" text-anchor="middle">the SUBGRADE finally carries it —</text>
      <text class="lb" x="180" y="290" text-anchor="middle">so its CBR strength decides the thickness</text>

      <line class="gl" x1="350" y1="44" x2="350" y2="290"/>
      <text class="em" x="520" y="46" text-anchor="middle">RIGID (concrete)</text>
      <rect class="steel" x="500" y="66" width="40" height="16" rx="3"/>
      <line class="ac" x1="520" y1="50" x2="520" y2="64" marker-end="url(#fr-c)"/>
      <rect class="conc" x="410" y="84" width="220" height="34"/>
      <rect class="softa" x="410" y="118" width="220" height="46"/>
      <text class="lb" x="520" y="106" text-anchor="middle">concrete slab</text>
      <text class="lb" x="520" y="145" text-anchor="middle">subgrade</text>
      <path class="hi" d="M410 118 Q520 138 630 118"/>
      <text class="lb" x="520" y="192" text-anchor="middle">the slab BRIDGES like a beam,</text>
      <text class="lb" x="520" y="210" text-anchor="middle">carrying the load in bending</text>
      <text class="lb" x="520" y="232" text-anchor="middle">and spreading it wide before it</text>
      <text class="lb" x="520" y="250" text-anchor="middle">reaches the soil — so the CONCRETE'S</text>
      <text class="lb" x="520" y="268" text-anchor="middle">flexural strength decides the thickness</text>
    </svg>`,
    caption: "The two pavement types answer the same question in opposite ways. A flexible pavement has no bending strength of its own; it passes the wheel load down through successively weaker granular layers, spreading it until the soil can bear it — so the subgrade's strength (its CBR) sets the design. A rigid pavement is a concrete slab that bridges over the soil like a beam, carrying the load in flexure and barely stressing the ground beneath. <strong>One leans on the soil; the other spans over it.</strong>",
  },

  /* ------------------------------------------- 4.2 BITUMEN TESTS */
  "hb-tr-bitumen": {
    label: "Grading bitumen — the consistency tests",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="Three bitumen tests: the penetration test where a needle sinks into bitumen under a standard load, the softening point where a ball falls through a ring of bitumen as it is heated, and ductility where a sample is stretched into a thread, with the idea that bitumen must be soft enough to work but stiff enough to hold in service.">
      ${hbmk("bi")}
      <text class="em" x="350" y="24" text-anchor="middle">BITUMEN: SOFT ENOUGH TO LAY, STIFF ENOUGH TO LAST</text>
      ${[["PENETRATION", 130, "how hard?"], ["SOFTENING POINT", 350, "how hot before it flows?"], ["DUCTILITY", 570, "how much can it stretch?"]]
        .map(([t, x, q]) => `<text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="78" text-anchor="middle">${q}</text>`).join("")}
      <rect class="softa" x="96" y="150" width="68" height="40"/>
      <line class="hi" x1="130" y1="100" x2="130" y2="150" marker-end="url(#bi-m)"/>
      <text class="lb" x="130" y="210" text-anchor="middle">needle sinks under 100 g, 5 s</text>
      <text class="lb" x="130" y="228" text-anchor="middle">depth in 0.1 mm = the grade</text>
      <text class="lb" x="130" y="246" text-anchor="middle">(VG-10, VG-30 …)</text>

      <path class="s" d="M320 150 A30 12 0 0 0 380 150" fill="none"/>
      <line class="s" x1="320" y1="150" x2="320" y2="130"/><line class="s" x1="380" y1="150" x2="380" y2="130"/>
      <circle class="steel" cx="350" cy="140" r="8"/>
      <path class="ac" d="M350 150 L350 186" marker-end="url(#bi-c)"/>
      <text class="lb" x="350" y="210" text-anchor="middle">heat until the ball drops</text>
      <text class="lb" x="350" y="228" text-anchor="middle">through — that temperature is</text>
      <text class="lb" x="350" y="246" text-anchor="middle">the softening point (°C)</text>

      <path class="hi" d="M520 150 Q570 140 620 150"/>
      <line class="ac" x1="520" y1="168" x2="500" y2="168" marker-end="url(#bi-c)"/>
      <line class="ac" x1="620" y1="168" x2="640" y2="168" marker-end="url(#bi-c)"/>
      <text class="lb" x="570" y="210" text-anchor="middle">pull until the thread breaks</text>
      <text class="lb" x="570" y="228" text-anchor="middle">length at break = ductility (cm)</text>
      <text class="lb" x="570" y="246" text-anchor="middle">too brittle = cracks in cold</text>
      <text class="lb" x="350" y="278" text-anchor="middle">soft bitumen rutts in summer; a hard one cracks in winter — grading picks the one for the climate</text>
    </svg>`,
    caption: "Bitumen is the glue of a flexible pavement and its whole behaviour is a balance of consistency: soft enough to coat the aggregate and be laid, stiff enough not to flow and rut under traffic on a hot day. The tests measure exactly that balance — how far a needle penetrates, how hot it must get before a ball falls through it, how far it stretches before breaking. <strong>The right grade is the one that neither rutts in the summer nor cracks in the winter of its location.</strong>",
  },

});
