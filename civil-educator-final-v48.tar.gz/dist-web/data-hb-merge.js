/* ============================================================
   CIVIL EDUCATOR — HANDBOOK CONSOLIDATION
   ------------------------------------------------------------
   One notebook per subject. Two subjects had been carrying two
   notebooks each:

     building-materials : bm  (short, written for the app)
                          bmn (complete notes, from the class PDF)
     steel              : st  (short, written for the app)
                          stn (complete notes, from three class PDFs)

   This file folds the short one into the complete one. Chapters
   and sections that the complete notes already cover in more
   depth are dropped; everything the complete notes do NOT cover
   is carried across and slotted into the right chapter. The
   short handbook is then removed from DB.handbooks, so the
   Handbooks list shows each subject exactly once.

   Nothing unique is lost — see the drop lists in the comments.
   Runs after every data-hb-*.js file and before app.js.
   ============================================================ */
(function () {
  var H = (window.DB && DB.handbooks) || [];
  if (!H.length) return;

  var by = function (id) { return H.filter(function (h) { return h.id === id; })[0]; };
  var ch = function (h, n) { return h.chapters.filter(function (c) { return c.n === n; })[0]; };
  var sc = function (h, n, sn) {
    var c = ch(h, n);
    return c ? (c.sections || []).filter(function (s) { return String(s.n) === String(sn); })[0] : null;
  };
  /* put sections in just before the chapter's closing "Quick revision" /
     "What to carry forward" section, so the recap stays last */
  var fold = function (c, list) {
    if (!c) return;
    var add = list.filter(Boolean);
    if (!add.length) return;
    var at = Math.max(0, (c.sections || []).length - 1);
    c.sections.splice.apply(c.sections, [at, 0].concat(add));
  };
  var mk = function (id, title, hi, blurb, mins, sections) {
    var s = sections.filter(Boolean);
    return s.length ? { id: id, n: 0, title: title, hi: hi, blurb: blurb, mins: mins, sections: s } : null;
  };
  var drop = function (id) {
    for (var i = 0; i < H.length; i++) if (H[i].id === id) { H.splice(i, 1); return; }
  };
  var renumber = function (h) {
    h.chapters = h.chapters.filter(Boolean);
    h.chapters.forEach(function (c, ci) {
      c.n = ci + 1;
      c.id = h.id + "-" + c.n;
      (c.sections || []).forEach(function (s, si) { s.n = c.n + "." + (si + 1); });
      if (!c.mins) {
        var b = (c.sections || []).reduce(function (a, s) { return a + (s.blocks || []).length; }, 0);
        c.mins = Math.max(6, Math.round(b * 0.4));
      }
      if (!c.blurb) c.blurb = "";
    });
  };

  /* ---------- BUILDING MATERIALS : bm -> bmn ----------
     Dropped from bm as already covered, in more detail, by bmn:
       1.x is kept · 2.1 (stone classification) · 3.1-3.3 (brick
       anatomy, manufacture, tests) · 4.1-4.3 (cement) · 7.1 (timber).
     Carried across: 1 (all), 2.2, 2.3, 3.4, 5 (all), 6.1-6.3,
       7.2, 7.3, 8 (all).                                        */
  var bm = by("bm"), bmn = by("bmn");
  if (bm && bmn) {
    fold(ch(bmn, 1), [sc(bm, 2, "2.2"), sc(bm, 2, "2.3")]);
    fold(ch(bmn, 2), [sc(bm, 3, "3.4")]);
    fold(ch(bmn, 6), [sc(bm, 6, "6.1"), sc(bm, 6, "6.2"), sc(bm, 6, "6.3")]);

    var agg = ch(bmn, 6);
    if (agg) {
      agg.title = "Aggregates, Sand, Water and Admixtures";
      agg.hi = "मोटा-महीन संग्रह, बालू, जल और मिश्रक";
      agg.blurb = "Classification of aggregates, angular number, fineness modulus and specific gravity of a mix — plus the silt, clay and salt that spoil sand, and the water and admixtures that go in with them.";
    }

    bmn.chapters = [
      ch(bm, 1),                       /* What Makes a Material Fit to Build With */
      ch(bmn, 1), ch(bmn, 2), ch(bmn, 3), ch(bmn, 4), ch(bmn, 5),
      ch(bm, 5),                       /* Lime, Pozzolana and Gypsum */
      ch(bmn, 6),
      ch(bmn, 7),
      mk("bmn-metals", "Metals and Corrosion", "धातुएँ और संक्षारण",
         "Iron and steel are the same element at different carbon levels — and corrosion is the property that decides which metal goes where.",
         10, [sc(bm, 7, "7.2"), sc(bm, 7, "7.3")]),
      ch(bmn, 8), ch(bmn, 9), ch(bmn, 10),
      ch(bm, 8)                        /* Mortar, Plaster and Finishes */
    ].filter(Boolean);

    bmn.name = "Building Materials";
    bmn.hi = "भवन सामग्री";
    bmn.icon = "🧱";
    bmn.blurb = "Patthar se lekar concrete tak — poore class notes (56 pages) page-by-page, plus lime, gypsum, metals, mortar aur finishes ke chapters. Ek hi jagah, koi repeat nahi.";
    bmn.note = (bmn.note || "") + " Is handbook mein pehle ka chhota 'Building Materials' notebook bhi mila diya gaya hai — jo chapters notes mein pehle se detail mein the, wo hata diye; jo nahi the (lime/pozzolana/gypsum, metals & corrosion, mortar/plaster/finishes, sand ke silt-clay tests, admixtures, stone ka natural bed aur tests, blocks) wo jod diye gaye.";
    drop("bm");
    renumber(bmn);
  }

  /* ---------- STEEL : st -> stn ----------
     Dropped from st as already covered by stn: 1 (material),
       2.1/2.5-2.7, 3 (bolts, incl. HSFG and prying), 4 (welds),
       5 (tension), 6 (compression, built-up), 7 (beams, web
       buckling/crippling, deflection), 10.1/10.2/10.5/10.6
       (plate girder web and stiffeners), 11.1 (bases), 11.2
       (trusses), 12.1 (gantry).
     Carried across: 2.2-2.4 (the four classes and their limits),
       8 (lateral-torsional buckling), 9 (beam-columns), 10.3
       (shear buckling), 10.4 (tension field action), 11.3
       (industrial buildings and bracing), 12.2-12.4 (fatigue,
       fire, corrosion, fabrication and erection).              */
  var st = by("st"), stn = by("stn");
  if (st && stn) {
    fold(ch(stn, 8),  [sc(st, 2, "2.2"), sc(st, 2, "2.3"), sc(st, 2, "2.4")]);
    fold(ch(stn, 12), [sc(st, 10, "10.3"), sc(st, 10, "10.4")]);
    fold(ch(stn, 13), [sc(st, 11, "11.3")]);

    stn.chapters = [
      ch(stn, 1), ch(stn, 2), ch(stn, 3), ch(stn, 4), ch(stn, 5),
      ch(stn, 6), ch(stn, 7), ch(stn, 8), ch(stn, 9), ch(stn, 10),
      ch(stn, 11),
      ch(st, 8),                       /* Lateral-Torsional Buckling */
      ch(st, 9),                       /* Beam-Columns: Combined Forces */
      ch(stn, 12), ch(stn, 13),
      mk("stn-fab", "Fatigue, Fire, Corrosion and Fabrication", "थकान, अग्नि, संक्षारण और निर्माण",
         "The four things that decide whether a steel structure survives its service life, after the member sizes are already fixed.",
         14, [sc(st, 12, "12.2"), sc(st, 12, "12.3"), sc(st, 12, "12.4")]),
      ch(stn, 14)                      /* Formula sheet — always last */
    ].filter(Boolean);

    stn.name = "Steel Structures";
    stn.hi = "इस्पात संरचनाएँ";
    stn.icon = "🔩";
    stn.blurb = "Teen class notes (254 pages) topic-wise jode hue, plus lateral-torsional buckling, beam-columns, tension field action aur fatigue/fire/fabrication ke chapters. Ek hi steel notebook.";
    stn.note = (stn.note || "") + " Is handbook mein pehle ka 'Design of Steel Structures' notebook bhi mila diya gaya hai — duplicate chapters hata diye, aur jo topics notes mein nahi the (section classification ke limits, lateral-torsional buckling, beam-columns, shear buckling aur tension field action, industrial buildings & bracing, fatigue, fire, corrosion, fabrication) wo jod diye gaye.";
    drop("st");
    renumber(stn);
  }

  /* ---------- STRUCTURAL ANALYSIS : sa -> san ----------
     sa   (12 ch, general notebook written for the app)
     san  (17 ch, "Complete Notes" — page-cited from two full class-note
          PDFs: Theory of Structures (T, 171 pp) and Structural Analysis /
          Vivek Gupta-MADE EASY (V, 269 pp))
     san covers everything sa covers and in far more depth (with source
     page citations sa never had), except three chapters sa has as their
     own dedicated chapter and san does not: Shear Force and Bending
     Moment (sa-3), Deflections (sa-5) and Plastic Analysis (sa-11).
     Those three are carried across whole; the other nine sa chapters
     are dropped as strictly superseded by san's page-cited versions. */
  var sa = by("sa"), san = by("san");
  if (sa && san) {
    san.chapters = [
      ch(san, 1), ch(san, 2), ch(san, 3), ch(san, 4), ch(san, 5),
      ch(sa, 3),                      /* Shear Force and Bending Moment */
      ch(san, 6), ch(san, 7), ch(san, 8),
      ch(sa, 5),                      /* Deflections */
      ch(san, 9), ch(san, 10), ch(san, 11), ch(san, 12), ch(san, 13), ch(san, 14),
      ch(san, 15),
      ch(sa, 11),                     /* Plastic Analysis */
      ch(san, 16), ch(san, 17)        /* Structural Dynamics, then PYQ+Formula sheet last */
    ].filter(Boolean);

    san.note = (san.note || "") + " Is handbook mein pehle ka 'Structural Analysis' notebook (12 chapters) bhi mila diya gaya hai — jo chapters yahan page-cited notes mein pehle se detail mein the, wo hata diye; jo nahi the (Shear Force & Bending Moment, Deflections, Plastic Analysis) wo apne poore chapter ki tarah jod diye gaye.";
    drop("sa");
    renumber(san);
  }

  /* subject -> handbook map must follow the surviving id */
  (DB.subjects || []).forEach(function (s) {
    if (s.hb === "bm") s.hb = "bmn";
    if (s.hb === "st") s.hb = "stn";
    if (s.hb === "sa") s.hb = "san";
  });
  (DB.semesters || []).forEach(function (sem) {
    (sem.subjects || []).forEach(function (s) {
      if (s.hb === "sa") s.hb = "san";
    });
  });
  (DB.courseExtra || []).forEach(function (s) {
    if (s.hb === "sa") s.hb = "san";
  });
})();
