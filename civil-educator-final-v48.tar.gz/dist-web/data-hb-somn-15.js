/* MACE Academy SOM notes — Theory of columns (compression members, failure modes, equilibrium, slenderness ratio, effective length, radius of gyration, Euler's and Rankine's theories), M p.198–209 — inserted into som chapter 5 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 5; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------- M p.198–199 */
    {
      n: "",
      title: "MACE notes — Compression members: types and modes of failure",
      hi: "संपीडन अवयव: प्रकार और विफलता के तरीके",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.198–199" },
        { k: "p", t: "<b>V-1 Ch. Theory of column — Introduction</b> (M p.198)" },
        { k: "p", t: "Compression members are subjected to compressive loads. A compressive load can be either <b>concentric</b> or <b>eccentric</b>; based upon this the compression member can be subjected to: (M p.198)" },
        { k: "list", items: [
          "1] <b>Direct stresses</b> (axial load)",
          "2] <b>Direct + bending stresses</b> (for eccentric load)",
        ] },
        { k: "h", t: "Types of compression members (M p.198)" },
        { k: "def", term: "1) Column", t: "The <b>vertical</b> compression member supporting the beams in a building frame. (M p.198)" },
        { k: "def", term: "2) Strut", t: "<b>Inclined or vertical</b> compression members of a truss, particularly a roof truss. (M p.198)" },
        { k: "def", term: "3) Stanchion", t: "Steel column of <b>rolled steel sections</b> used in buildings. (M p.198)" },
        { k: "def", term: "4) Post", t: "Compression member of a <b>trussed bridge girder</b>, in which the end members are called posts. (M p.198)" },
        { k: "def", term: "5) Boom", t: "Arms of mechanical equipment like <b>cranes</b> are called booms. (A boom is a compression member.) (M p.198)" },
        { k: "note", t: "<b>Source difference:</b> the older notes in this chapter (p.14, §5.5) define a strut as a compression member in any position <i>other than vertical</i>; the MACE notes (M p.198) call struts the <i>inclined or vertical</i> compression members of a truss. Both describe the same member — the MACE wording defines it by <i>where it is</i> (inside a truss), the older wording by <i>orientation</i> (to separate it from a building column). In a roof truss a vertical compression member is still called a strut, so the MACE wording is the more complete one." },
        { k: "h", t: "★ Various modes of failure of a column (M p.198)" },
        { k: "def", term: "1) Crushing mode (yielding)", t: "The actual material fails even before buckling of the column. This type of failure is seen in <b>short columns or pedestals (stub columns)</b>. (M p.198)" },
        { k: "p", t: "Figure (M p.198): a short pedestal / stub column standing on a footing (label \"footing\")." },
        { k: "def", term: "2) Buckling (elastic instability)", t: "Lateral deflection occurs before crushing of the material. This type of failure is frequent in <b>slender (लांबट) or long columns</b>. (M p.198)<br>लांबट (Marathi) — \"elongated, long and thin\"." },
        { k: "def", term: "3) Mixed mode of buckling and crushing", t: "When columns are neither too short nor too long, they fail by buckling and crushing occurring <b>simultaneously</b>. This type of failure is observed in <b>intermediate columns</b>. (M p.198)" },
        { k: "h", t: "Summary — just keep in mind (M p.199)" },
        { k: "p", t: "Mild steel ⇒ <b>σ_c = 250 MPa</b> ← crushing value of mild steel (i.e. maximum permissible value till yielding). (M p.199)" },
        { k: "list", items: [
          "Column failure depends on <b>dimensions &amp; material</b> → elastic instability, or → crushing. (M p.199)",
          "1) <b>Crushing</b> of column (crushing failure) ⇒ if the material is weak (i.e. σ_c ↓↓). (M p.199)",
          "2) <b>Buckling</b> of column (buckling failure) ⇒ if the column is too slender. (M p.199)",
          "Slenderness ratio (λ) = (length)/(lateral dimension). (M p.199)",
          "Failure is of 2 types: <b>serviceability</b> and <b>collapse</b>. (M p.199)",
        ] },
        { k: "p", t: "Figure (M p.199): three columns — ① height 100 mm, width 1 mm, λ = 100; ② height 100 mm, width 10 mm, λ = 10; ③ height 300 mm, width 10 mm, λ = 30. <b>Column ① is the most slender.</b> A second sketch shows a column of length L under P → pure axial load (concentric, dashed centre line) — a stub column of square cross-section b × d." },
        { k: "cmp", t: "Failure mode vs slenderness and material (M p.199)", cols: ["λ", "Material"], rows: [
          ["Crushing", "↓↓ (low)", "Weak"],
          ["Mixed mode", "not defined", "not defined"],
          ["Buckling", "↑↑ (high)", "Strong"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek column do tarah se haar sakta hai: ya to material hi kuchal jaye (crushing), ya material theek ho par column side mein jhuk jaye (buckling). Kaunsa pehle hoga, yeh do cheezon par depend karta hai — column kitna patla-lamba hai (λ) aur material kitna strong hai. Mota-chhota column aur kamzor material → crushing. Patla-lamba column aur strong material (jaise steel) → buckling, kyunki material ki strength use hone se pehle hi column jhuk jaata hai." },
        { k: "p", t: "Isi liye table mein buckling ke saamne \"strong\" likha hai: strong material ka crushing stress itna zyada hota hai ki patle column mein uss tak pahunchne se pehle hi buckling ho jaati hai. Beech wale (intermediate) columns mein dono effect saath chalte hain — yahi range Rankine's theory (aage) cover karti hai." },
        { k: "trap", t: "Students often think buckling means the material has failed. It has not — buckling is a <b>stability</b> failure (elastic instability); the stress in the steel can still be well below 250 MPa when the column buckles. Crushing is the <b>strength</b> failure. Don't mix the two." },
        { k: "real", t: "Short RCC pedestals under steel columns and stub columns fail by crushing; tall steel stanchions, truss struts and crane booms are checked mainly for buckling." },
      ],
    },

    /* ---------------------------------------------------- M p.199–200 */
    {
      n: "",
      title: "MACE notes — Equilibrium conditions of a column (stable, unstable, neutral)",
      hi: "स्तंभ की साम्यावस्था — स्थिर, अस्थिर और उदासीन",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.199–200" },
        { k: "p", t: "<b>V-2 ★ Equilibrium conditions of column</b> (M p.199)" },
        { k: "list", items: [
          "P_cr = critical load at which the column will fail",
          "P = actual applied load on the column",
          "M_o = overturning moment",
          "M_R = restoring / resisting moment",
        ] },
        { k: "p", t: "Example in the notes: if P_cr = 20 kN, then P &lt; 20 → <b>stable</b>; P &gt; 20 → <b>unstable</b>. (M p.199)" },
        { k: "p", t: "Figures (M p.199): a cantilever column fixed at its base with load P &lt; P_cr at the top and a small lateral deflection (red) at the top; and a vertical column fixed at the base with M_o (overturning moment) shown at the top and M_R (restoring moment) at the base." },
        { k: "cmp", t: "Three equilibrium cases (M p.200)", cols: ["Load condition", "Moment condition"], rows: [
          ["Case 1) <b>Stable</b> equilibrium", "P &lt; P_cr", "M_o &lt; M_R"],
          ["Case 2) <b>Unstable</b> equilibrium", "P &gt; P_cr", "M_o &gt; M_R"],
          ["Case 3) <b>Neutral</b> equilibrium", "P = P_cr", "M_o = M_R"],
        ] },
        { k: "list", items: [
          "Figure, Case 1 (M p.200): a ball at the bottom of a concave bowl, arrows pointing back to the centre; a column fixed at the base with P &lt; P_cr; the same column with a small lateral force P′ at the top producing M_o, and the restoring moment M_R at the base.",
          "Figure, Case 2 (M p.200): a ball on top of a convex surface, arrows pointing away; a column fixed at the base with P &gt; P_cr; with lateral force P′ at the top the column shows a large deflection, with M_o and M_R marked.",
          "Figure, Case 3 (M p.200): a ball on a flat surface; a column fixed at the base with P = P_cr; with lateral force P′ at the top, M_o = M_R.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Column ko ek chhota sa side push (P′) do aur dekho kya hota hai. Load chhota hai (P &lt; P_cr) to column ki stiffness (restoring moment M_R) usse wapas seedha kar deti hai — jaise katori ke andar rakhi ball wapas beech mein aa jaati hai. Load bada hai (P &gt; P_cr) to P × deflection wala overturning moment M_o, M_R se zyada ho jaata hai aur deflection badhta hi jaata hai — jaise ulti katori par rakhi ball. Theek P = P_cr par column jahan dhakelo wahin ruk jaata hai — neutral equilibrium. Isi load ko Euler ne critical / buckling load kaha." },
        { k: "trap", t: "P_cr is the load at <b>neutral</b> equilibrium — the borderline, not a 'safe' load. A column carrying exactly P_cr is on the verge of buckling; the working load must be P_cr divided by a factor of safety (see §5.5)." },
      ],
    },

    /* ---------------------------------------------------- M p.200–202 */
    {
      n: "",
      title: "MACE notes — Slenderness and slenderness ratio for steel and RCC columns",
      hi: "पतलापन और स्टील व आरसीसी स्तंभों का पतलापन अनुपात",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.200–202" },
        { k: "h", t: "★ Slenderness (M p.200)" },
        { k: "list", items: [
          "Slenderness is the <b>dominance of the length</b> of a column over its width, as compared to its lateral dimension.",
          "<b>Prismatic column</b> ⇒ a column having <b>constant EI</b> is called a prismatic column.",
          "The term slenderness gives rise to an important parameter which is more significant for compression members. This parameter is the <b>slenderness ratio (λ)</b>.",
        ] },
        { k: "cmp", t: "Slenderness ratio — general (M p.200)", cols: ["Height / cross-section", "λ = length / lateral dimension"], rows: [
          ["A]", "100 cm; 10 cm × 10 cm", "100/10 = 10"],
          ["B]", "10 cm; 10 cm × 10 cm", "10/10 = 1 <b>[least slender]</b>"],
          ["C]", "160 cm; 8 cm × 8 cm", "160/8 = 20 <b>[most slender]</b>"],
        ] },
        { k: "p", t: "Figure (M p.200): three columns fixed at the base — A] 100 cm tall, c/s 10 cm × 10 cm; B] 10 cm tall, c/s 10 cm × 10 cm; C] 160 cm tall, c/s 8 cm × 8 cm." },
        { k: "p", t: "As compared above, in case C] the ratio of length to lateral dimension is 20. This ratio is called the slenderness ratio. Thus, out of A, B and C, <b>column C is the most slender</b>. (M p.201)" },
        { k: "p", t: "Based upon the material of the column, the slenderness ratio is defined in two different ways: (M p.201)" },
        { k: "eq", expr: "1) Steel columns:  λ = (effective length of column)/(minimum radius of gyration) = Leff / r_min", where: [
          ["Leff", "effective length, which depends upon the end conditions"],
          ["r_min", "√(I_min / A) = √(minimum moment of inertia / area)"],
        ] },
        { k: "eq", expr: "2) RCC columns:  λ = (unsupported length)/(least lateral dimension)" },
        { k: "p", t: "Figure (M p.201): a column between a slab/beam above and a hatched masonry wall at the bottom; the height of column above the wall is marked \"unsupported length\"; label \"masonry wall\". Column cross-section is a rectangle b × d with <b>b = least lateral dimension</b>." },
        { k: "eg", title: "MACE notes example — RCC column braced by masonry on its 200 mm face", given: "Que 1) An RCC column 8 m long is 400 × 200 mm in c/s. If a stone masonry construction supports the column on its 200 mm wide face on half of its length, what will be the slenderness ratio of this RCC column?", steps: [
          { t: "Sketch (M p.201)", w: "3-D sketch: column 400 × 200 with the masonry wall against its 200 face; marked \"unsupported = 8 m\"." },
          { t: "Slenderness ratio", w: "λ = (8 m)/(0.2 m) = 40" },
        ], ans: "λ = 40 (M p.201)" },
        { k: "eg", title: "MACE notes example — same column braced on its 400 mm face", given: "Q. In the same question, if the masonry wall supports the column on its 400 mm face up to half length, then λ = ?", steps: [
          { t: "Sketch (M p.201)", w: "3-D sketch: column 400 × 200 with the wall against its 400 face up to 4 m; the 4 m above the wall is marked \"4 m = unsupported\"; the lower 4 m is supported." },
          { t: "Slenderness ratio", w: "λ = (4 m)/(0.2 m) = 20" },
        ], ans: "λ = 20 (M p.201)" },
        { k: "h", t: "Numerical trick — NOTE (M p.202)" },
        { k: "list", items: [
          "If there is no construction around the column and the entire length of the column is unsupported, then the length of the column is nothing but the unsupported length.",
          "If masonry wall construction is there but the faces are not specified/mentioned, simply assume that the wall is resisting bending, and hence the unsupported length is found by <b>subtracting the height of the wall</b>.",
        ] },
        { k: "eg", title: "MACE notes example — slenderness ratio from reduced levels (MMRDA-16)", given: "Que 2) For an RCC column, the following details are available:\nRL of bottom of column = 305 m\nRL of top of beam = 311 mm\nRL of bottom of beam on left side = 309.9 m\nRL of bottom of beam on right side = 310.2 m\nColumn dimension = 300 mm × 300 mm.\nSlenderness ratio λ = ?", steps: [
          { t: "Figure (M p.202)", w: "Column from RL 305 m at the bottom; beam top at 311 m; beam bottom on the left at 309.9 m and on the right at 310.2 m." },
          { t: "Formula", w: "λ = L_unsupported / least lateral dimension" },
          { t: "Substitute", w: "λ = (309.9 − 305)/0.3\nλ = 4.9/0.3 = 49/3 = 16.33" },
        ], ans: "λ = 16.33 (M p.202)" },
        { k: "note", t: "<b>Check:</b> \"311 mm\" in the data is a unit slip for <b>311 m</b> (the figure shows 311 m); it is not used in the answer. The arithmetic 4.9/0.3 = 16.33 is right. But IS 456:2000 (cl. 25.1.3) takes the unsupported length, in beam-and-slab construction, as the clear distance from the floor to the underside of the <b>shallower</b> beam framing into the column. The shallower beam is the one whose bottom is higher, RL 310.2 m, so by the code l = 310.2 − 305 = 5.2 m and <b>λ = 5.2/0.3 = 17.33</b>. The notes measured to the deeper beam (309.9 m). Use 17.33 unless the exam key states otherwise." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "λ batata hai column kitna 'patla-lamba' hai. Steel column mein λ = Leff/r_min isliye ki steel sections (I, channel, angle) ka shape complex hota hai — sirf width se kaam nahi chalta, isliye radius of gyration lete hain. RCC column zyaatar rectangle hota hai, to seedha unsupported length ÷ chhoti side (b) le lete hain." },
        { k: "p", t: "Que 1 aur Q ka logic: wall jis face se chipki hai, column ko us face ke perpendicular direction mein hilne nahi deti. 200 mm face par wall → column ki 400 wali direction mein support mila, par patli 200 wali direction mein poore 8 m free → 8/0.2 = 40. 400 mm face par wall (aadhi height) → patli direction mein neeche ke 4 m bandhe hain, sirf upar ke 4 m free → 4/0.2 = 20 (aur dusri direction 8/0.4 = 20 bhi same aata hai)." },
        { k: "trap", t: "Always divide by the <b>least</b> lateral dimension (b), never the larger one — and check which direction the wall actually restrains. A wall on the wide face braces the column in its weak direction; a wall on the narrow face does not." },
        { k: "real", t: "On a building, a ground-floor column with a brick wall built against it up to sill level is braced only up to that height in the wall's direction; the part above the wall, up to the beam soffit, is the unsupported length the designer must check." },
      ],
    },

    /* ---------------------------------------------------- M p.202–203 */
    {
      n: "",
      title: "MACE notes — Effective length and end conditions of columns",
      hi: "प्रभावी लंबाई और स्तंभ की सिरा-स्थितियाँ",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.202–203" },
        { k: "h", t: "★ Effective length or equivalent length of column (M p.202)" },
        { k: "list", items: [
          "In simple words, the effective length is the length which <b>actually participates in bending</b>.",
          "Basically it is the distance between <b>two successive points of contraflexure</b>, or points of zero bending moment.",
          "Effective length depends upon the <b>boundary conditions</b>, i.e. support conditions. (M p.203)",
        ] },
        { k: "list", items: [
          "Figure 1 (M p.202): a beam fixed at the left (with end moment) and hinged at the right; its elastic curve is drawn; the \"portion of beam which actually bends\" = Leff is marked from the point of contraflexure to the right support; label \"elastic curve\".",
          "Figure 2 (M p.202): a column fixed at both ends; L′ or Leff is marked between the two points of contraflexure (arrows \"points of contraflexure\").",
          "Figure 3 (M p.202): a column hinged at both ends; Leff = full length between the hinges; the \"points of contraflexure\" are at the hinges.",
        ] },
        { k: "h", t: "Support / end / boundary conditions usually encountered (M p.203)" },
        { k: "cmp", cols: ["Movement", "Description"], rows: [
          ["1) Hinge / pinned support", "No translation, only rotation", "Effectively held in position but <b>not restrained</b> against rotation."],
          ["2) Fixed support", "No translation, only rotation (as written in the notes)", "Effectively held in position <b>and restrained</b> against rotation."],
          ["3) Free end", "Both translation and rotation take place", "<b>Neither</b> effectively held in position <b>nor</b> restrained against rotation."],
        ] },
        { k: "note", t: "<b>Check:</b> for the fixed support the notes repeat \"No translation only Rotation\" (M p.203), copied from the hinge line. A fixed support allows <b>neither translation nor rotation</b> — as the notes' own right-hand column says (\"held in position and restrained against rotation\")." },
        { k: "p", t: "Figures (M p.203): 1) a beam end on a hinge support; 2) a beam end built into a wall; 3) a beam fixed at the left and free at the right end." },
        { k: "h", t: "Imp ★ Effective length of column with different end conditions (M p.203)" },
        { k: "cmp", cols: ["Diagram", "Effective length (Le or Leff or L′)"], rows: [
          ["1) Effectively held in position but not restrained against rotation at both ends <b>[both hinged]</b>", "Hinged top, hinged bottom; length L; buckled shape a single curve, Le = L", "Leff = L &amp; Leff/L = 1"],
          ["2) Effectively held in position as well as restrained against rotation at both ends <b>[both fixed]</b>", "Fixed top, fixed bottom; length L; Le = the central portion", "Leff = L/2 = 0.5L &amp; Leff/L = 0.5"],
          ["3) Effectively held in position at both ends but restrained against rotation at only one end <b>[one hinged, other fixed]</b>", "Hinged top, fixed bottom; length L; Le marked on the curve", "Leff = L/√2 = 0.71L &amp; Leff/L ≈ 0.7 (ratio cut at the page edge)"],
          ["4) Effectively held in position as well as restrained against rotation at one end, but neither effectively held in position nor restrained against rotation at the other end <b>[one fixed, other free]</b>", "Free top, fixed base; real length L with its mirror image L drawn below the base; Le = 2L over the full mirrored curve", "Leff = 2L &amp; Leff/L = 2"],
        ] },
        { k: "p", t: "These four theoretical values match the older notes (p.14) and the table in §5.5, which also lists the larger IS 456 recommended values (0.65L, 0.80L, L, 2L) used in design." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Effective length = column ka woh hissa jo asal mein ek 'pin-ended' column jaisa jhukta hai. Dono ends fix ho to ends par column ghoom nahi sakta, isliye sirf beech ka aadha hissa (do contraflexure points ke beech) free curve banata hai → L/2. Cantilever (neeche fix, upar free) ka curve aadha hi hota hai; use poora karne ke liye neeche mirror image lagao, to pura bow 2L ka banta hai → Leff = 2L." },
        { k: "trap", t: "Don't mix up 'held in position' (translation) with 'restrained against rotation'. A hinge is held in position but free to rotate; a free end is neither. Reading the long-form descriptions carelessly is how students swap 0.5L and 2L in MCQs." },
        { k: "real", t: "A column cast monolithically into a deep footing and a stiff beam is close to 'fixed–fixed'; a steel column on a base plate with two anchor bolts is closer to 'hinged'. Since real joints are never perfectly rigid, codes use the larger recommended values shown in §5.5." },
      ],
    },

    /* ---------------------------------------------------- M p.204 */
    {
      n: "",
      title: "MACE notes — Radius of gyration and a slenderness-ratio numerical",
      hi: "परिभ्रमण त्रिज्या और पतलापन अनुपात का उदाहरण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.204" },
        { k: "h", t: "★ Radius of gyration (r) (M p.204)" },
        { k: "list", items: [
          "Radius of gyration is an important parameter which shows <b>resistance against bending</b>.",
          "If the radius of gyration is more, then buckling of the column is less.",
        ] },
        { k: "eq", expr: "r = √(I / A)", where: [
          ["I", "moment of inertia about any axis"],
          ["A", "cross-sectional area of the column"],
        ] },
        { k: "eq", expr: "r_xx = √(Ixx / A),  r_yy = √(Iyy / A)  → take the minimum, called r_min  ⇒  r_min = √(I_min / A)" },
        { k: "p", t: "Thus, <b>buckling behaviour is governed by the minimum radius of gyration</b>. (M p.204)" },
        { k: "list", items: [
          "Buckling depends upon: i) <b>Leff</b> → end condition; ii) <b>r_min</b> → MI or c/s dimension. (M p.204)",
          "Buckling = fⁿ(λ) = fⁿ(Leff / r_min). (M p.204)",
        ] },
        { k: "eg", title: "MACE notes example — λ of a 200 × 400 mm column, one end fixed, other hinged", given: "★ Que 1) A 200 mm × 400 mm column of length 4 m is effectively held in position at both ends but restrained against rotation at only one end. What will be the slenderness ratio of the column?", steps: [
          { t: "Figures (M p.204)", w: "Column hinged at top, fixed at bottom, buckled shape dashed. Rectangular c/s of width b and depth d; x–x axis horizontal, y–y axis vertical." },
          { t: "Effective length", w: "Leff = L/√2 = 4000/√2\nLeff = (4/√2) × 10³ mm" },
          { t: "Minimum radius of gyration", w: "Ixx = bd³/12, Iyy = db³/12 → minimum is Iyy\nr_min = √((db³/12)/(b × d)) = √(b²/12) = b/√12\n= 200/√(4 × 3) = 200/(2√3)\nr_min = 100/√3 mm" },
          { t: "Slenderness ratio", w: "λ = Leff/r_min = ((4/√2) × 10³)/(100/√3) = (4√3)/(100√2) × 10³\n= 0.04 × 1.73 × 0.707 × 10³\n= 4 × 173 × 7 × 10⁻⁵ × 10³\n= 4 × (170 + 3)7 × 10⁻⁵ × 10³\n= 4 × (1190 + 21) × 10⁻⁵ × 10³\n= 4760 + 84 × 10⁻⁵ × 10³ = 4844 × 10⁻⁵ × 10³ = 0.04844 × 10³" },
        ], ans: "λ = 48.44 (M p.204)" },
        { k: "note", t: "<b>Check:</b> the method is right, but in the third line 0.707 was rounded to 0.7 (written as 7). Exactly: Leff = 2828.4 mm, r_min = 57.74 mm, so <b>λ = 2828.4/57.74 = 48.99 ≈ 49</b> (0.04 × 1.73 × 0.707 × 10³ = 48.92 with the rounded √3). The notes' 48.44 is about 1% low." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Radius of gyration ek 'effective distance' hai — area ko ek ring mein maan lo jo axis se r door hai aur jiska I wahi hai. r jitna bada, section utna bending ke against stiff, aur buckling utni mushkil. Rectangle ki do r hoti hain: patli side (b) ke across chhoti r = b/√12. Column hamesha usi kamzor direction mein buckle karta hai, isliye λ mein r_min hi lagta hai." },
        { k: "trap", t: "For a b × d rectangle, r_min = b/√12 where b is the <b>smaller</b> side — not d/√12, and not b/12. Also convert Leff and r to the same unit (both mm here) before dividing." },
      ],
    },

    /* ---------------------------------------------------- M p.205–206 */
    {
      n: "",
      title: "MACE notes — Euler's theory: assumptions, critical stress and limit of validity",
      hi: "यूलर का सिद्धांत: मान्यताएँ, क्रांतिक प्रतिबल और वैधता की सीमा",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.205–206" },
        { k: "h", t: "V-4 ★ Euler's theory — buckling of long columns: assumptions (M p.205)" },
        { k: "list", items: [
          "Material is <b>linear elastic</b>, i.e. it obeys Hooke's law.",
          "Material is <b>homogeneous and isotropic</b>.",
          "Column is <b>slender or long, and prismatic</b>.",
          "Column should be <b>loaded axially</b>, i.e. no intentional buckling is done.",
          "Failure is purely due to <b>elastic instability</b>, i.e. buckling, because it is assumed that long columns fail due to buckling only; hence <b>direct stresses are neglected</b>.",
          "<b>Self weight</b> of the column is neglected.",
          "Axis of the column is <b>perfectly straight</b>. (If not, eccentricity of load may be generated at the base of the column, hence an overturning moment may be induced, and thus intentional buckling takes place because bending moment is generated.)",
          "Note that Euler developed the theory for <b>long columns only</b>. He defined the critical load for the column as given below.",
        ] },
        { k: "eq", expr: "★ Euler's critical load:  P_cr = π²EI / Leff²   ——①", where: [
          ["P_cr", "critical load required for buckling of the column = minimum load required for buckling = failure load for a long column as per Euler"],
          ["EI", "flexural rigidity"],
          ["Leff", "effective or equivalent length, as given earlier"],
          ["I = A·r²", "I = MI, A = area, r = radius of gyration"],
        ] },
        { k: "steps", items: [
          "① ⇒ P_cr = π²E(A·r²) / Leff²",
          "If P ⇒ P_cr and r ⇒ r_min: P_cr = π²E·A·r_min² / Leff²",
          "∴ P_cr = π²AE / (Leff²/r_min²)",
          "∴ ★ <b>P_cr = π²(AE) / λ²</b>",
          "P_cr / A = π²E / λ²",
          "∴ ★ <b>σ_cr = π²E / λ²</b> — σ_cr = Euler's critical stress; λ = critical slenderness ratio. (M p.205)",
        ] },
        { k: "h", t: "★ Validity of Euler's formula (M p.206)" },
        { k: "p", t: "For mild steel, Euler's critical stress formula can be applied and the critical slenderness ratio limit found as under: σ_y = 250 MPa ← σ_cr for a long column; E = 2 × 10⁵ MPa. Since σ_cr = π²E/λ², σ_cr ∝ 1/λ² (σ_cr ↓ as λ ↑). (M p.206)" },
        { k: "eg", title: "MACE notes example — limiting slenderness ratio for mild steel (MES mains-19)", given: "Find the critical slenderness ratio above which Euler's formula is valid for a mild steel column. σ_y = 250 MPa, E = 2 × 10⁵ MPa.", steps: [
          { t: "Set Euler stress equal to yield", w: "250 = (π² × 2 × 10⁵)/λ²" },
          { t: "Solve", w: "λ = 88.86 (MES mains-19)" },
        ], ans: "★ λ ≈ 89 ⇐ λ_cr (M p.206)" },
        { k: "p", t: "Figure (M p.206): graph of σ_cr (vertical axis) against λ (horizontal axis). The hyperbolic \"Euler's failure curve\" falls as λ increases; a point on it is marked \"stress level for buckling\" with a dashed line across to the σ_cr axis. A horizontal line at \"250 MPa\" meets the curve; a dashed vertical line from that point drops to the λ axis at \"λ_cr = 89\" (boxed, ★). The λ axis left of 89 is marked \"short\", right of it \"long column\"." },
        { k: "h", t: "V.Imp Conclusion — for mild steel λ_cr = 89 (M p.206)" },
        { k: "list", items: [
          "If λ &lt; 89 (λ &lt; λ_cr) → the mild steel column is said to be <b>short</b> [Euler's theory not applicable].",
          "If λ &gt; 89 (λ &gt; λ_cr) → the mild steel column is said to be <b>long</b> [Euler's theory applicable].",
        ] },
        { k: "h", t: "Imp NOTES (M p.206)" },
        { k: "list", items: [
          "σ_cr = π²E / λ_cr²",
          "If λ ↓↓ then σ_cr ↑↑: for short columns more critical stress is required for buckling, and if σ_crushing &lt; σ_cr the column fails by <b>crushing even before buckling</b>.",
          "If λ ↑↑ then σ_cr ↓↓, and if σ_cr &gt; σ_crushing (as written) the column fails by <b>buckling even before crushing</b>.",
        ] },
        { k: "note", t: "<b>Check:</b> the last line of M p.206 is written \"if σ_cr &gt; σ_crushing — column fails by buckling\". The sign is reversed: buckling governs when the Euler stress is <b>below</b> the crushing stress (σ_cr &lt; σ_crushing), which is what happens when λ is large — the notes' own graph shows this (curve below the 250 MPa line to the right of λ = 89)." },
        { k: "note", t: "<b>Source difference:</b> the older notes in this chapter (p.14, §5.5) classify columns as short for λ &lt; 80 and long for λ &gt; 120, and §5.5 quotes λ_lim = 78.5 (σ_c = 320) and 88.9 (fy = 250). The MACE notes give a single dividing line, λ_cr = 89, for mild steel. Re-deriving: λ_lim = π√(E/σ) = π√(2 × 10⁵/250) = 88.86 — the MACE value — and π√(2 × 10⁵/320) = 78.5. So both come from the same formula; they differ only in the stress used (yield 250 MPa vs crushing 320 MPa). The 80/120 split is a classroom convention with an intermediate band between, where Rankine is used. For a mild-steel question that gives fy = 250 MPa, use 89." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Euler's formula batata hai ki column kis stress par buckle karega — λ badhao to yeh stress λ² ke hisaab se girta hai. Par ek chhote, mote column ke liye yeh formula 250 MPa se bhi zyada stress de dega — jo material sah hi nahi sakta; woh to pehle hi yield/crush ho jayega. Isliye Euler sirf wahan valid hai jahan σ_cr material ki strength se kam ho, yaani λ &gt; 89 (mild steel). Graph mein 250 MPa ki line aur Euler curve ka cut-point hi short aur long column ki boundary hai." },
        { k: "trap", t: "λ_cr = 89 is for <b>mild steel</b> with σ_y = 250 MPa and E = 2 × 10⁵ MPa only. A different material or a different σ gives a different limit (π√(E/σ)). Don't quote 89 for timber or cast iron." },
        { k: "real", t: "Even for long columns, Euler's load is an upper bound because real members are never perfectly straight or axially loaded (the assumptions above). Steel design codes therefore use buckling curves that fall below the Euler curve (see §5.5)." },
      ],
    },

    /* ---------------------------------------------------- M p.207 */
    {
      n: "",
      title: "MACE notes — Euler's critical load for various end conditions",
      hi: "विभिन्न सिरा-स्थितियों के लिए यूलर क्रांतिक भार",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.207" },
        { k: "cmp", t: "Imp ★ Euler's critical load for various end conditions, P_cr = π²EI/Leff² (M p.207)", cols: ["Leff", "P_cr"], rows: [
          ["1) Both ends hinged", "L", "P_cr = π²EI/L²"],
          ["2) Both ends fixed", "L/2", "P_cr = π²EI/(L/2)² ⇒ <b>P_cr = 4π²EI/L²</b>"],
          ["3) One end hinged (top), other fixed (bottom)", "L/√2", "P_cr = π²EI/(L/√2)² ⇒ <b>P_cr = 2π²EI/L²</b>"],
          ["4) One end fixed (bottom), other free (top)", "2L", "P_cr = π²EI/(2L)² ⇒ P_cr = π²EI/4L (as written)"],
        ] },
        { k: "note", t: "<b>Check:</b> case 4 simplifies to <b>P_cr = π²EI/(4L²)</b> — the square on L was dropped in the notes (\"π²EI/4L\"). (2L)² = 4L²." },
        { k: "list", items: [
          "Figures (M p.207): 1) column of length L pinned at top and bottom, deflected shape a single bow (dashed); 2) column of length L fixed at top and bottom, deflected shape dashed; 3) column of length L hinged at top and fixed at bottom; 4) column of length L fixed at the bottom and free at the top (leaning deflected line), with a dashed mirror image continued below the base.",
        ] },
        { k: "h", t: "Conclusion (M p.207)" },
        { k: "list", items: [
          "P_cr depends upon: i) <b>modulus of elasticity</b> of the material (E) ⇒ material property; ii) <b>moment of inertia</b> of the column c/s (I) ⇒ dimensions of the column — together E and I form the <b>flexural rigidity (EI)</b>; iii) <b>effective length</b> of the column (Le) ⇒ boundary condition, or end condition, or degree of fixity, or restraint of the column.",
          "If EI is doubled, P_cr gets doubled.",
          "If Le is doubled, P_cr becomes 1/4th.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek hi column, sirf ends badlo: hinged–hinged ko 1 maano to fixed–fixed 4 guna, fixed–hinged 2 guna, aur fixed–free (cantilever) sirf 1/4 load par buckle hota hai. Yaani fixed–fixed aur fixed–free mein 16 guna ka fark — sirf end conditions se. P_cr ∝ EI aur P_cr ∝ 1/Leff² — length ka asar square mein hai, isliye bracing se length aadhi karna sabse sasta tareeka hai capacity chaar guna karne ka." },
        { k: "trap", t: "Writing the cantilever case as π²EI/4L (as on M p.207) gives the wrong units — P_cr must be force, so L must be squared: π²EI/(4L²). A quick unit check catches this kind of slip in the exam." },
      ],
    },

    /* ---------------------------------------------------- M p.208–209 */
    {
      n: "",
      title: "MACE notes — Rankine's theory, Rankine's constants and a crushing-load numerical",
      hi: "रैंकाइन सिद्धांत, रैंकाइन स्थिरांक और उदाहरण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.208–209" },
        { k: "p", t: "<b>V-5 Rankine's theory</b> (M p.208)" },
        { k: "list", items: [
          "P_c = crushing load → σ_c = crushing stress",
          "P_cr = critical load (Euler's) → σ_cr = Euler's critical stress",
          "P = Rankine's failure load → σ = Rankine's stress",
        ] },
        { k: "eq", expr: "★ 1/P = 1/P_cr + 1/P_c    — Rankine's empirical relationship" },
        { k: "eq", expr: "★ 1/P = (P_c + P_cr)/(P_cr · P_c)   ⇒   ★ P = (P_cr · P_c)/(P_cr + P_c)   ⇒   ★ P = P_c / (1 + P_c/P_cr)   ——①" },
        { k: "steps", items: [
          "But σ_c = P_c/A and P_cr = π²EI/Leff² ∴ P_c = σ_c·A. Put in ①:",
          "P = σ_c·A / [1 + P_c/(π²EI/Leff²)]",
          "P = σ_c·A / [1 + P_c(Leff²/π²EI)]",
          "P = σ_c·A / [1 + P_c(Leff²/(π²E(A·r_min²)))]",
          "P = σ_c·A / [1 + (P_c/A)[(1/π²E)(Leff/r_min)²]]",
          "P = σ_c·A / [1 + (σ_c·λ²)/(π²E)]",
          "σ_c/(π²E) = <b>α = Rankine's constant</b>. (M p.208)",
        ] },
        { k: "eq", expr: "★ P = σ_c·A / (1 + α·λ²)   → Rankine's failure load", where: [
          ["α", "Rankine's constant = σ_c/(π²E)"],
          ["λ", "slenderness ratio = Leff/r_min"],
        ] },
        { k: "eq", expr: "★ σ = σ_c / (1 + α·λ²)   → Rankine's failure stress" },
        { k: "cmp", t: "Rankine's constants (M p.208)", cols: ["σ_c or σ_y (MPa)", "α = σ_c/(π²E)"], rows: [
          ["1) Mild steel", "330", "1/7500"],
          ["2) Medium carbon steel", "500", "1/500"],
          ["3) Cast iron", "550", "1/1600"],
          ["4) Wrought iron", "250", "1/9000"],
          ["5) Strong timber", "50", "1/750"],
        ] },
        { k: "note", t: "<b>Check:</b> the α for medium carbon steel, <b>1/500</b>, cannot be right. With E = 2 × 10⁵ MPa the theoretical α = σ_c/(π²E) = 500/(9.87 × 2 × 10⁵) = <b>1/3948</b>; α = 1/500 is about eight times larger and would make α·λ² dominate even for short columns. It is most likely a slip for <b>1/5000</b>, the value commonly printed in Indian SOM textbook tables (General Engineering Knowledge — confirm against your textbook). Note also that the tabulated α values are empirical: for mild steel the theoretical value is 330/(π² × 2 × 10⁵) = 1/5982, while the table gives 1/7500." },
        { k: "note", t: "<b>Source difference:</b> crushing stress of mild steel is 330 MPa in this MACE table (M p.208), 320 MPa in the older notes' table (§5.5) and 250 MPa (yield) on M p.199/206. The 250 MPa is the yield stress fy of Fe 250 steel used for the Euler limit; 320 and 330 are empirical 'crushing' values that go with α = 1/7500 in Rankine's formula — different books print slightly different figures. Timber also differs: α = 1/750 with σ_c = 50 MPa here (strong timber) against 1/1800 in §5.5. Neither can be re-derived without E for timber, which the notes do not give. In an exam, use the σ_c and α given in the question; if none are given, state which table you used." },
        { k: "eg", title: "MACE notes example — failure load of a hollow square medium-carbon-steel column", given: "Que 1) A steel column of hollow square section was to be analysed for failure. Consider the following data and find the failure load of the column made of medium carbon steel of crushing value 500 MPa, neglecting overall as well as local buckling.\nExternal dimensions: 600 mm × 600 mm\nInternal dimensions: 550 mm × 550 mm", steps: [
          { t: "Rankine with buckling neglected", w: "1/P = 1/P_c + 1/P_cr, and with buckling neglected 1/P_cr → 0\n∴ P = P_c = σ_c·A   (since σ_c = P_c/A)" },
          { t: "Crushing load", w: "P_c = 500 × [ext. area − int. area]\n= 500 × [(600)² − (550)²]\n= [360000 − 302500] × 500\n= 10² [3600 − 3025] × 500\n= 100 × 575 × 500\n= 575 × 5 × 10⁴\n= (500 + 70 + 5) × 5 × 10⁴\n= 2875 × 10⁴ N\n= 28750 × 10³ N" },
        ], ans: "P = 28750 kN (M p.208–209)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Rankine ne do failure modes ko 'series' mein jod diya: 1/P = 1/P_cr + 1/P_c. Jo load chhota hai wahi zyada asar karta hai. Chhota-mota column → P_cr bahut bada → 1/P_cr ≈ 0 → P ≈ P_c (crushing). Lamba-patla column → P_cr chhota → P ≈ P_cr (Euler). Beech wale column mein dono ka asar → P dono se kam. Isi liye Rankine 'har tarah ke column' ke liye chalta hai, aur Que 1 mein 'buckling neglect karo' ka seedha matlab hai 1/P_cr = 0, yaani P = σ_c × A." },
        { k: "p", t: "α·λ² wala form yaad rakhna aasaan hai: numerator mein crushing load σ_c·A, aur denominator (1 + αλ²) slenderness ki 'penalty' hai. λ = 0 par penalty zero → pura crushing load." },
        { k: "trap", t: "In hollow sections, take the <b>net</b> area (outer² − inner²), never the outer area alone. And remember α already contains σ_c/π²E — don't multiply by π² again when you use α·λ²." },
        { k: "real", t: "Hollow square (box) sections are popular for steel columns because, for the same area, they give a large r_min in both directions — which keeps λ and the Rankine penalty small." },
      ],
    },

    /* ---------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Theory of columns (M p.198–209)",
      hi: "पुनरावृत्ति — स्तंभ सिद्धांत",
      blocks: [
        { k: "h", t: "✅ Key points from the MACE notes" },
        { k: "list", items: [
          "Compression members: column (vertical, building frame), strut (inclined/vertical, truss), stanchion (rolled steel section), post (end member of trussed bridge girder), boom (crane arm). (M p.198)",
          "Concentric load → direct stress; eccentric load → direct + bending stress. (M p.198)",
          "Failure modes: crushing (short/stub column), buckling = elastic instability (slender/long — लांबट), mixed (intermediate). (M p.198)",
          "Mild steel σ_c = 250 MPa; crushing ↔ low λ, weak material; buckling ↔ high λ, strong material. (M p.199)",
          "Equilibrium: stable P &lt; P_cr, M_o &lt; M_R; unstable P &gt; P_cr, M_o &gt; M_R; neutral P = P_cr, M_o = M_R. (M p.199–200)",
          "Prismatic column = constant EI. (M p.200)",
          "λ (steel) = Leff/r_min, r_min = √(I_min/A); λ (RCC) = unsupported length/least lateral dimension. (M p.201)",
          "Masonry wall on 200 face of 8 m, 400 × 200 column → λ = 40; on 400 face up to half height → λ = 20. (M p.201)",
          "Faces not specified → subtract wall height to get unsupported length. (M p.202)",
          "RL example: λ = (309.9 − 305)/0.3 = 16.33 as in notes; IS 456 shallower-beam rule gives 17.33. (M p.202)",
          "Effective length = length that actually bends = distance between successive points of contraflexure. (M p.202)",
          "Hinge: held in position, free to rotate; fixed: held and restrained; free: neither. (M p.203)",
          "Leff: both hinged L; both fixed L/2; fixed–hinged L/√2 = 0.71L; fixed–free 2L. (M p.203)",
          "Buckling = fⁿ(Leff/r_min); governed by r_min. (M p.204)",
          "200 × 400 mm, 4 m, fixed–hinged: r_min = 100/√3, λ = 48.44 in notes (exact 48.99). (M p.204)",
          "Euler assumptions: linear elastic, homogeneous, isotropic, long and prismatic, axial load, straight axis, self weight neglected, failure by buckling only. (M p.205)",
          "P_cr = π²EI/Leff² = π²AE/λ²; σ_cr = π²E/λ². (M p.205)",
          "Validity: 250 = π² × 2 × 10⁵/λ² → λ_cr = 88.86 ≈ 89; mild steel λ &lt; 89 short (Euler not applicable), λ &gt; 89 long. (M p.206)",
          "P_cr: hinged–hinged π²EI/L²; fixed–fixed 4π²EI/L²; fixed–hinged 2π²EI/L²; fixed–free π²EI/(4L²). (M p.207)",
          "EI doubled → P_cr doubled; Le doubled → P_cr becomes 1/4. (M p.207)",
          "Rankine: 1/P = 1/P_cr + 1/P_c; P = σ_c·A/(1 + αλ²); σ = σ_c/(1 + αλ²); α = σ_c/(π²E). (M p.208)",
          "Rankine constants: mild steel 330, 1/7500; medium carbon steel 500, 1/500 (see Check); cast iron 550, 1/1600; wrought iron 250, 1/9000; strong timber 50, 1/750. (M p.208)",
          "Hollow square 600/550 mm, σ_c = 500 MPa, buckling neglected → P = P_c = 28750 kN. (M p.208–209)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
