/* MACE Academy SOM notes — SFD and BMD, M p.14–30 — inserted into som chapter 3 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 3; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------------- M p.14 */
    {
      n: "",
      title: "MACE notes — Shear force, bending moment and sign conventions",
      hi: "कर्तन बल, बंकन आघूर्ण और चिह्न परिपाटी",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.14" },
        { k: "p", t: "<b>Ch. SFD and BMD</b> (class lecture V-1). (M p.14)" },
        { k: "p", t: "Figure (M p.14): a beam AB drawn as a rectangular strip with the <b>axis of beam</b> as a dashed centre line; a point load P acts downward at section x–x (dashed vertical line); support reactions R<sub>A</sub> ↑ at the left end A and R<sub>B</sub> ↑ at the right end B. (M p.14)" },
        { k: "list", items: [
          "Beam → in service it <b>should be stable &amp; in equilibrium</b>: (M p.14)",
          "• <b>Force equilibrium</b> (M p.14)",
          "• <b>Rotational equilibrium</b> (M p.14)",
        ] },
        { k: "p", t: "Figure (M p.14): the left part of the beam cut at section x–x — R<sub>A</sub> ↑ at the left end and, at the cut face, a downward force <b>S<sub>x</sub> = R<sub>A</sub></b>, labelled \"Parallel (tangential) (shear)\". The body stays in <b>force equilibrium</b> because a tangential (shear) force S<sub>x</sub> develops at the cut. A second sketch shows R<sub>A</sub> ↑ at the left end and R<sub>A</sub> ↓ at the right end of a small element forming a couple (anticlockwise curved arrow) → <b>M<sub>x</sub> = bending moment</b>. (M p.14)" },
        { k: "def", term: "Shear force (★)", t: "The shear force at any section is the <b>internal transverse force</b> which is developed to maintain the <b>force equilibrium</b> of the body, i.e. to maintain the free-body equilibrium. Shear force is also defined as the <b>algebraic sum of all forces at a section perpendicular to the cross-section</b>. (M p.14)" },
        { k: "list", items: [
          "<b>Sign convention of S.F (★):</b> clockwise direction of S.F = <b>+ve</b>; anticlockwise direction = <b>−ve</b>. (M p.14)",
          "Figure (M p.14): (+) element with ↑ on its left face and ↓ on its right face (clockwise pair); (−) element with ↓ on its left face and ↑ on its right face (anticlockwise pair).",
        ] },
        { k: "def", term: "Bending moment (★)", t: "The <b>internal moment</b> generated to maintain <b>rotational equilibrium</b> (algebraic sum of all moments at any section). (M p.14)" },
        { k: "cmp", t: "Sign convention of B.M (M p.14)", cols: ["Shape of the bent beam", "Sign"], rows: [
          ["Sagging (smiling)", "Upward concave OR downward convex — beam bends into a smile; end moments: left end anticlockwise ↺, right end clockwise ↻", "<b>+ve</b>"],
          ["Hogging", "Upward convex OR downward concave — beam bends into a frown; end moment arrows reversed", "<b>−ve</b>"],
        ] },
        { k: "p", t: "Figure (M p.14): a straight beam drawn as a thin rectangle, then the same beam bent as a smile (sagging, marked + in red) and as a frown (hogging, marked − in red), each with its pair of curved end-moment arrows." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Beam ko kahin bhi kaato — kata hua tukda gir nahi raha, ghoom nahi raha. Girne se jo rokta hai woh cut face par develop hone wala <b>shear force</b> hai (force equilibrium), aur ghoomne se jo rokta hai woh <b>bending moment</b> hai (rotational equilibrium). Isliye SF aur BM 'internal' forces hain — load ke jawab mein beam ke andar paida hote hain." },
        { k: "p", t: "Sign yaad rakhne ka shortcut: SF ke liye element ke dono faces ki forces ka jodi (couple) clockwise ghuma raha hai to +; BM ke liye beam smile kare (sagging) to +. Yahi convention chapter ke §3.5 mein bhi use hua hai, isliye dono jagah answers same sign mein aayenge." },
        { k: "trap", t: "SF ka sign 'upward force = +' se mat nikaalo. Sign is baat par depend karta hai ki force section ke <b>left</b> side par hai ya <b>right</b> side par: left part par upward force (+) hai, par right part par wahi upward force (−) deta hai. Hamesha clockwise/anticlockwise pair se check karo. (M p.14)" },
      ],
    },

    /* ---------------------------------------------------------------- M p.15–16 */
    {
      n: "",
      title: "MACE notes — Relations between load, shear force and bending moment",
      hi: "भार, कर्तन बल और बंकन आघूर्ण के बीच संबंध",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.15–16" },
        { k: "p", t: "<b>★ For distributed load.</b> Figure (M p.15): a simply supported beam of span L (pin at left, roller at right) carrying a UDL W kN/m over the whole length; two sections ① and ② a small distance dx apart. Free body of the element between ① and ②, width dx, carrying W kN/m on top: left face — shear S ↑ and moment M (clockwise curved arrow); right face — shear S + ds ↓ and moment M + dm (anticlockwise curved arrow). (M p.15)" },
        { k: "steps", items: [
          "ΣF<sub>y</sub> = 0 — equilibrium condition. (M p.15)",
          "+S − (S + ds) − W·dx = 0 (M p.15)",
          "+S − S − ds − W·dx = 0 (M p.15)",
          "★ ① → <b>(−ds)/dx = W</b> — relation between loading intensity and rate of change of shear force. (M p.15)",
        ] },
        { k: "steps", items: [
          "ΣM about section ①–① = 0 — rotational equilibrium. (M p.15)",
          "+M + (S + ds)·dx − (M + dm) − W·dx·(dx/2) = 0 (M p.15)",
          "+M̸ + S·dx + ds·dx [→ 0] + M̸·dm − W·dx²/2 [→ 0] = 0 — the M terms cancel; ds·dx and W·dx²/2 are dropped (because dx, ds very small). (M p.15)",
          "S·dx − dm = 0 (M p.15)",
          "② → <b>S = dm/dx</b> — relation between shear force and bending moment. (M p.15)",
        ] },
        { k: "note", t: "<b>Check:</b> the third line as written shows \"+M̸·dm\"; expanding −(M + dm) gives <b>−M − dm</b>. The M cancels with +M and the −dm survives, which is exactly what the next line S·dx − dm = 0 uses — so the result S = dm/dx is correct; only the sign/operator in that one line is a slip." },
        { k: "eq", expr: "① −dS/dx = W     ② dM/dx = S", where: [
          ["W", "intensity of the distributed load at the point (kN/m)"],
          ["S", "shear force at the section"],
          ["M", "bending moment at the section"],
        ] },
        { k: "list", items: [
          "From ①: <b>−ve slope of SFD at any point = load intensity at that point.</b> (M p.15)",
          "Rate of change of S.F = magnitude of load intensity; e.g. if W = 10 kN/m then the rate of change of S.F = 10 kN/m. (M p.15)",
          "Figure (M p.15): a small triangular (UVL) load diagram rising from W = 0 at the left to W<sub>max</sub> at the right, with the note \"W = 0, SFD चा slope = 0\" (Marathi: where W = 0, the slope of the SFD = 0).",
          "From ②: <b>slope of BMD at any point = magnitude of shear force at that point.</b> dm/dx (+ve) ⇒ S<sub>x</sub> (+ve); dm/dx (−ve) ⇒ S<sub>x</sub> (−ve). (M p.15)",
          "When BMD changes its sign, SF also changes its sign. (M p.15)",
          "If S<sub>x</sub> = 0, dm/dx = 0 ⇐ thus <b>M = maximum / M = minimum</b>. (M p.15)",
        ] },
        { k: "note", t: "<b>Source difference:</b> the older notes in this chapter (§3.5, p.9) write W = dF/dx, while the MACE notes (M p.15) write <b>−dS/dx = W</b>. Re-deriving with ΣF<sub>y</sub> on the element (S up on the left face, S + dS down on the right face, downward load W·dx): S − (S + dS) − W·dx = 0 ⇒ dS/dx = −W. So for a <b>downward</b> load and the clockwise-positive shear convention used in both notes, the MACE form −dS/dx = W is right; W = dF/dx is true only if W is taken positive upward (or as a magnitude statement). §3.5 already flags this sign." },
        { k: "h", t: "📘 Why SFD and BMD are drawn — M p.16" },
        { k: "list", items: [
          "★ SFD and BMD are important to find out: ① maximum shear force, ② maximum B.M, ③ point of contraflexure, ④ to decide where to leave <b>construction joints</b>, ⑤ to decide the location of <b>lapping</b>. (M p.16)",
          "<b>★ Shear force equation and bending moment equation:</b> these equations are written by simply finding the shear force and bending moment at any particular section x–x lying at a distance 'x' from a support or end of the beam. (M p.16)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Do relations, teen diagrams: load diagram ka <b>area</b> SF ka change deta hai, aur SFD ka <b>area</b> BM ka change deta hai. Ulta chalo to slope milta hai: SFD ka slope = −(load intensity), BMD ka slope = SF. Isi se 'jahan SF = 0 wahan BM max/min' seedha nikal aata hai — derivative zero, function ka peak." },
        { k: "p", t: "Site ki baat: construction joint aur lap wahan rakhe jaate hain jahan SF aur BM kam ho — isliye notes kehte hain SFD/BMD se hi decide hota hai ki concrete kahan roka jaaye aur bars kahan lap kiye jaayein." },
        { k: "trap", t: "−dS/dx = W mein minus bhool jaana sabse common galti hai. Downward UDL ke neeche SFD hamesha left se right <b>girta</b> hai; agar aapka SFD UDL ke neeche upar ja raha hai to sign convention mein galti hai. (M p.15)" },
        { k: "real", t: "Laps aur construction joints ko maximum BM aur maximum SF wale zones se door rakha jaata hai — jaise simply supported slab mein mid-span (max BM) aur support ke paas (max SF) se bachkar. (General Engineering Knowledge)" },
      ],
    },

    /* ---------------------------------------------------------------- M p.16–19 */
    {
      n: "",
      title: "MACE notes — Cantilever beams: point load, UDL and UVL (cases I–IV)",
      hi: "कैंटिलीवर धरन — बिंदु भार, UDL और UVL",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.16–19" },
        { k: "h", t: "(I) Cantilever with point load P at the free end (M p.16)" },
        { k: "p", t: "Figure (M p.16): cantilever fixed at the left end (hatched wall), free at the right end; point load P ↓ at the free end; section X–X at distance x measured from the free end; total length L. SFD: rectangle, +P at the fixed end and +P at the free end — \"straight Hz (0°)\". BMD: triangle, PL at the fixed end reducing to 0 at the free end, marked −, \"linear (1°)\"." },
        { k: "steps", items: [
          "S.F equation: <b>S<sub>x</sub> = +P</b>. At free end x = 0: S<sub>x</sub> = P; at fixed end x = L: S<sub>x</sub> = P. (M p.16)",
          "B.M equation: <b>M<sub>x</sub> = −P·x¹</b>. At free end x = 0: M<sub>x</sub> = 0; at fixed end x = L: M<sub>x</sub> = −P·L. (M p.16)",
          "M<sub>x</sub> ∝ x¹ — linear equation, of the form y = ax. (M p.16)",
        ] },
        { k: "list", items: [
          "Conclusion — cantilever with concentrated load P at the free end: ① SFD → rectangular, i.e. SF = constant; ② BMD → triangular; ③ SF<sub>max</sub> → P at fixed support; ④ BM<sub>max</sub> → PL at fixed support; ⑤ BM = 0 at free end. (M p.16)",
          "\"cantilever Beam मध्ये जे काही max असेल ते fixed end ला.\" (Marathi: in a cantilever beam, whatever is maximum occurs at the fixed end.) (M p.16)",
        ] },
        { k: "note", t: "<b>Check:</b> the conclusion line in the notes reads \"BM<sub>max</sub> → P @ fixed support\"; from the notes' own equation M<sub>x</sub> = −P·x at x = L, the maximum B.M is <b>PL</b> (hogging) at the fixed support. P is the maximum <i>shear force</i>." },
        { k: "h", t: "(II) Cantilever with UDL W over the entire span (M p.17)" },
        { k: "p", t: "Figure (M p.17): cantilever AB fixed at A (left), free at B (right); UDL W N/m over the whole length L (load line marked 0°); section X–X at distance x from free end B. SFD: triangle, WL at the fixed end reducing linearly to 0 at the free end, marked +, \"1° (linear)\"; at the free end \"SF = 0, so dm/dx = 0\". BMD: curve, WL²/2 at the fixed end reducing to 0 at the free end with a horizontal tangent, marked −, \"2° parabola\"." },
        { k: "steps", items: [
          "S.F equation: <b>S<sub>x</sub> = +W·x¹</b>. Free end x = 0: S<sub>x</sub> = 0; fixed end x = L: S<sub>x</sub> = +WL. (M p.17)",
          "B.M equation: M<sub>x</sub> = W·x × (x/2) ⇒ <b>M<sub>x</sub> = −Wx²/2</b> — parabolic (2°). Free end x = 0: M<sub>x</sub> = 0; fixed end x = L: M<sub>x</sub> = −WL²/2. (M p.17)",
          "Side check (M p.17): dm/dx = S<sub>x</sub> and −ds/dx = W — at the free end S = 0, so the BMD must meet the axis with a horizontal tangent (✓); a curve meeting it with a slope there would be wrong (✗).",
        ] },
        { k: "list", items: [
          "Conclusion — cantilever with UDL on entire span: ① SFD → triangular OR straight inclined line; ② BMD → 2° parabolic; ③ S.F<sub>max</sub> = W·L at fixed support; ④ BM<sub>max</sub> = WL²/2 at fixed support; ⑤ SF = 0 &amp; BM = 0 at free end. (M p.17)",
        ] },
        { k: "h", t: "(III) Cantilever with UVL — intensity W at the fixed end, zero at the free end (M p.17–18)" },
        { k: "p", t: "Figure (M p.17): cantilever AB fixed at A (left), free at B (right), triangular load with intensity W kN/m at fixed end A reducing to zero at free end B (load line \"1° (linear)\"); section X–X at distance x from free end B, intensity at the section = W′. SFD: curve from WL/2 at the fixed end to 0 at the free end, \"2° parabola\"; at the free end \"SF = 0, dm/dx = 0 ∴ slope = 0\". BMD: curve from WL²/6 at the fixed end to 0 at the free end with horizontal tangent, \"3° parabola\"." },
        { k: "steps", items: [
          "To find W′ — use similar triangles: W/L = W′/x ⇒ <b>W′ = W(x/L)</b>. (M p.17)",
          "S.F equation: S<sub>x</sub> = +(total load) = ½W′·x = ½(W·x/L)·x = <b>Wx²/(2L)</b> ← 2° parabola. Free end x = 0: S<sub>x</sub> = 0; fixed end x = L: S<sub>x</sub> = WL/2. (M p.17)",
          "B.M equation: M<sub>x</sub> = −(½W′x) × x/3 = −(½ × W(x/L)·x)·x/3 ⇒ <b>M<sub>x</sub> = −Wx³/(6L)</b> — 3° parabola (cubic). Free end x = 0: M<sub>x</sub> = 0; fixed end x = L: M<sub>x</sub> = −WL²/6. (M p.17)",
        ] },
        { k: "list", items: [
          "Conclusions — cantilever with UVL of intensity W at fixed end and zero at free end: ① S.F.D → 2° parabolic; ② BMD → 3° parabolic (cubic); ③ SF<sub>max</sub> = WL/2 at fixed support; ④ BM<sub>max</sub> = −WL²/6 at fixed support; ⑤ SF = 0 &amp; BM = 0 at free support/end. (M p.18)",
        ] },
        { k: "h", t: "IMP NOTES (M p.18)" },
        { k: "list", items: [
          "The vertical reaction of a cantilever beam is nothing but the max S.F, and the moment at the fixed support gives the max B.M; at the free end BM = 0. (M p.18)",
          "<b>BMD is always 1° higher than SFD.</b> (M p.18)",
          "<b>SFD is always 1° higher than the load diagram.</b> (M p.18)",
        ] },
        { k: "cmp", t: "Degree of the curves (M p.18)", cols: ["SFD", "BMD"], rows: [
          ["Point load", "0°", "1°"],
          ["UDL", "1°", "2°"],
          ["UVL", "2°", "3°"],
        ] },
        { k: "p", t: "In the table the notes also draw diagonal arrows from the BMD of each row to the SFD of the next row (Pt. load BMD 1° ↙ UDL SFD 1°; UDL BMD 2° ↙ UVL SFD 2°) — each step down the table raises the degree by one. (M p.18)" },
        { k: "h", t: "(IV) Cantilever with UVL — zero at the fixed end, intensity W at the free end (M p.18–19)" },
        { k: "p", t: "Figure (M p.18): cantilever AB fixed at A (left), free at B (right), triangular UVL increasing from zero at A to W at B; section X–X at distance x <b>from A</b>, intensity W′ at the section; the resultant of the load over length x acts at 2x/3 from A (x/3 from the section). Reactions at A: fixing moment WL²/3 and R<sub>A</sub> = WL/2 ↑. SFD: curve from WL/2 at A to 0 at B, marked +, \"2° parabola\"; at B \"SF = 0, dm/dx = 0\". BMD: curve from WL²/3 at A (where dm/dx ≠ 0) to 0 at B (where dm/dx = 0, horizontal tangent), marked −, \"3° parabola\"." },
        { k: "steps", items: [
          "S.F equation: S<sub>x</sub> = +WL/2 − (½W′x) = WL/2 − (½(Wx/L)·x) ⇒ <b>S<sub>x</sub> = WL/2 − Wx²/(2L)</b> — parabolic (2°). At fixed end x = 0 (from A): S<sub>x</sub> = WL/2; at free end x = L: S<sub>x</sub> = 0. (M p.18)",
          "B.M equation: M<sub>x</sub> = −M + (WL/2)x − [½(W′)x](x/3), where M is the support moment and WL/2 is R<sub>A</sub>. (M p.18)",
          "= −WL²/3 + WLx/2 − [½(W(x/L))·x](x/3) (M p.18)",
          "<b>M<sub>x</sub> = −WL²/3 + WLx/2 − Wx³/(6L)</b> — cubic parabola — B.M equation. (M p.18)",
          "At fixed end x = 0: M<sub>x</sub> = −WL²/3; at free end x = L: M<sub>x</sub> = 0. (M p.18)",
        ] },
        { k: "p", t: "Figure (M p.18, small): the portion of the beam from A to the section — fixing moment WL²/3 at ① (A), reaction WL/2 ↑ at ②, triangular load up to section ③ X–X at distance x; its resultant at x/3 from the section. The exponent of L in the boxed −WL²/3 is overwritten on the page (a 2 written over a 3); the value is WL²/3. (M p.18)" },
        { k: "note", t: "<b>Check:</b> total load = WL/2 acting at 2L/3 from A, so the fixing moment = (WL/2)(2L/3) = <b>WL²/3</b> ✓. Putting x = L in the B.M equation: −WL²/3 + WL²/2 − WL²/6 = 0 ✓; and d(M<sub>x</sub>)/dx = WL/2 − Wx²/(2L) = S<sub>x</sub> ✓." },
        { k: "list", items: [
          "Conclusion — cantilever with UVL of intensity W at the free end and zero at the fixed end: ① SFD → 2° parabolic; ② BMD → 3° parabolic (cubic); ③ SF<sub>max</sub> = WL/2 at fixed end; ④ BM<sub>max</sub> = −WL²/3 at fixed end; ⑤ SF = 0 &amp; BM = 0 at free end. (M p.19)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Case III aur IV mein total load same hai (WL/2), isliye fixed end par shear bhi same (WL/2). Par moment alag hai: jab load ka bhaari hissa free end ki taraf hai (case IV), resultant fixed end se 2L/3 door hai → WL²/3; jab bhaari hissa wall ki taraf hai (case III), resultant sirf L/3 door → WL²/6. Load jitna door, moment utna bada." },
        { k: "p", t: "Degree rule (load → SFD → BMD har step mein +1) se diagram ki shape bina calculation bata sakte ho: UDL ke neeche SFD seedhi inclined line, BMD parabola; UVL ke neeche SFD parabola, BMD cubic." },
        { k: "trap", t: "Cantilever mein x kahan se naapa, yeh pehle fix karo. Free end se naapoge to reaction equation mein nahi aata (cases I–III); fixed end se naapoge to support moment aur reaction dono equation mein daalne padte hain (case IV: −WL²/3 + WLx/2 − …). Dono sahi hain, par mix karoge to galat answer aayega. (M p.16–18)" },
        { k: "real", t: "Chajja, balcony slab aur retaining wall ka stem — sab cantilever hain; max BM aur max SF wall/footing ke joint par hota hai, isliye wahin section sabse mota aur main steel tension (upar/earth side) face par rakha jaata hai." },
      ],
    },

    /* ---------------------------------------------------------------- M p.19–20 */
    {
      n: "",
      title: "MACE notes — Cantilever beams: couple, distributed moment, two loads and questions (cases V–VII)",
      hi: "कैंटिलीवर — युग्म, वितरित आघूर्ण, दो भार एवं प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.19–20" },
        { k: "h", t: "(V) Cantilever with an external couple M at the free end (M p.19)" },
        { k: "p", t: "Figure (M p.19): cantilever AB fixed at A (left), free at B (right), length L; external couple M at free end B (clockwise curved arrow); reaction moment −M at A; section X–X at distance x from B. SFD: zero line (0 —— 0). BMD: rectangle of constant value −M, labelled M at both ends." },
        { k: "list", items: [
          "① S<sub>x</sub> = 0 — independent of 'x'. (M p.19)",
          "② M<sub>x</sub> = −M — independent of 'x'. (M p.19)",
          "Conclusion: <b>SFD is independent of external moment &amp; couple.</b> (M p.19)",
        ] },
        { k: "h", t: "★ (VI) Cantilever with a uniformly distributed moment (M p.19)" },
        { k: "p", t: "Heading in the notes: \"UDL नसून हे → [Uniformly distributed mmt]\" (Marathi: this is not a UDL — it is a uniformly distributed moment). Figure (M p.19): cantilever AB fixed at A (left), free at B (right), length L, carrying a uniformly distributed moment m kN·m/m drawn as a row of small curved moment arrows; reaction moment ML at A; section X–X at distance x from free end B. SFD: zero line. BMD: triangle, ML at fixed end A reducing linearly to 0 at free end B, marked −." },
        { k: "steps", items: [
          "Total moment = M·L. (M p.19)",
          "M kN/m → 1 m; x → L m ⇒ <b>ML = x</b> (i.e. the total moment over length L is M·L). (M p.19)",
          "① S<sub>x</sub> = 0 — independent of 'x'. (M p.19)",
          "② <b>M<sub>x</sub> = −M·x¹</b> — linear variation. x = 0 at free end ⇒ BM = 0; x = L at fixed end ⇒ BM = −ML. (M p.19)",
        ] },
        { k: "h", t: "(VII) Cantilever with P at mid-span and 2P at the free end (M p.19–20)" },
        { k: "p", t: "Figure (M p.19): cantilever fixed at A (left), free end C (right); point load P ↓ at B (L/2 from A) and point load 2P ↓ at free end C (L/2 from B); reaction 3P ↑ at A. SFD: stepped rectangle, + : 3P from A to B, drops at B from 3P to 2P, constant 2P from B to C. BMD: − , linear from 5PL/2 at A to PL at B to 0 at C." },
        { k: "steps", items: [
          "(S<sub>x</sub>)<sub>C–B</sub> = +2P; (S<sub>x</sub>)<sub>B–A</sub> = +P + 2P — independent of 'x', i.e. horizontal straight lines. (M p.19)",
          "(M<sub>x</sub>)<sub>C–B</sub> = −2Px — linear. x = 0: BM = 0 at free end; x = L/2: BM = −PL at centre. (M p.20)",
          "(M<sub>x</sub>)<sub>B–A</sub> = −P·x¹ − 2P(x¹ + L/2) (x measured from B). x = 0: BM = −PL at centre; x = L/2: BM = −PL/2 − 2P(L) = <b>−5PL/2</b> at fixed end. (M p.20)",
        ] },
        { k: "list", items: [
          "Conclusion: <b>a vertical line in the SFD shows the presence of a load OR a reaction at that point</b>; at such a point we get two values of S.F — one to the left and one to the right. (M p.19)",
        ] },
        { k: "eg", title: "MACE notes example — BM at point C of a cantilever with an end load and an end couple", given: "Find out the BM at point C in the beam shown. (Cantilever AB fixed at A, free at B, AC = 2 m, CB = 2 m; point load 2 N at B and a couple 3 N·m at B; x measured from B.)", steps: [
          { t: "B.M equation (x from free end B)", w: "M_x = −2 × x − 3" },
          { t: "At point C, x = 2 m", w: "(BM) at x = 2 m = −2 × 2 − 3 = −7 N·m at centre" },
          { t: "At free end, x = 0", w: "(BM) at x = 0 = −3 N·m at free end" },
          { t: "At fixed end, x = 4 m", w: "(BM) at x = 4 m = −2 × 4 − 3 = −8 − 3 = −11 N·m at fixed end" },
          { t: "Diagrams (figure)", w: "Reactions at A: R_A = 2 ↑ and fixing moment 11.\nBMD: trapezium marked −, 11 at A, 7 N·m at C, 3 at B.\nSFD: rectangle marked +, P = 2 N from A to B." },
        ], ans: "BM at C = −7 N·m (hogging); −3 N·m at the free end and −11 N·m at the fixed end. (M p.20)" },
        { k: "eg", title: "MACE notes example — axial load on a cantilever (Que 7)", given: "★ Cantilever AB fixed at A, length 2 m, with a horizontal axial force 2 kN applied at free end B along the beam axis. Find SF, BM and the reaction.", steps: [
          { t: "Nature of the load", w: "Axial load on beam — it cannot produce SF and BM." },
          { t: "Result", w: "SF = 0 and BM = 0\nVertical reaction at A = 0" },
          { t: "Horizontal reaction", w: "H_A = 2 kN (←)" },
        ], ans: "SF = 0 and BM = 0 everywhere; H_A = 2 kN (←). (M p.20)" },
        { k: "eg", title: "MACE notes example — shear stress at a cantilever section (Que 8)", given: "Following is a cantilever beam of cross-sectional area 200 mm × 400 mm subjected to 3 kN load at its free end. Find out the maximum shear stress at x–x. (Figure: span 3 m, load marked 30 kN at free end B; cross-section width × depth = 200 × 400.)", steps: [
          { t: "Shear stress", w: "shear stress = shear force / area of c/s\nτ = S.F / (b·d)  ∴  τ = S / bd" },
          { t: "Shear force at x–x", w: "S at x–x = +30 kN = 30,000 N" },
          { t: "Substitute (width written as 300 in the working)", w: "τ = 30,000 / (300 × 400) = 1/4 = 0.25 N" },
        ], ans: "Shear stress (τ) = 0.25 N (M p.20)" },
        { k: "note", t: "<b>Check:</b> the notes are inconsistent in three places. (1) The question says 3 kN but the figure and working use <b>30 kN</b>. (2) The width is written 200 in the question and figure (the digit is overwritten, it can also be read as 300) but the working uses 300: 30 000 / (300 × 400) = <b>0.25 N/mm²</b>, while with 200 mm, 30 000 / (200 × 400) = <b>0.375 N/mm²</b>. (3) The unit of stress is <b>N/mm²</b>, not N. Also, τ = S/bd is the <i>average</i> shear stress; <b>General Engineering Knowledge:</b> the maximum shear stress in a rectangular section is 1.5 × average (at the neutral axis), i.e. 0.375 N/mm² for 300 × 400 — see Chapter 4." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Couple (moment) beam ko ghumata hai par kisi direction mein dhakelta nahi — isliye SFD par uska koi asar nahi, sirf BMD mein jump ya constant value aati hai. Uniformly distributed moment har metre par thoda-thoda moment jodta hai, isliye BMD UDL ke SFD jaisa linear triangle ban jaata hai, aur SFD zero hi rehta hai." },
        { k: "p", t: "Axial load beam ke axis ke along hai — na woh section ko slide karata hai, na bend karata hai. Woh sirf axial stress deta hai (P/A), SF/BM nahi." },
        { k: "trap", t: "Shear stress ka unit N/mm² hota hai, sirf N nahi; aur S/bd sirf average value hai — rectangle mein max shear stress 1.5 guna hota hai. Question mein 'maximum shear stress' likha ho to yeh factor mat bhoolo. (M p.20)" },
      ],
    },

    /* ---------------------------------------------------------------- M p.21–22 */
    {
      n: "",
      title: "MACE notes — Simply supported beams: point loads, UDL and UVL (cases I–IV)",
      hi: "शुद्धालंबित धरन — बिंदु भार, UDL और UVL",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.21–22" },
        { k: "p", t: "<b>★ SFD &amp; BMD for simply supported beam</b> (class lecture V-4). In a S.S. beam, <b>first find the support reactions.</b> (M p.21)" },
        { k: "h", t: "(I) Unsymmetric point load P at C (a from A, b from B) (M p.21)" },
        { k: "p", t: "Figure (M p.21): simply supported beam AB, pin at A, roller at B, span L; point load P ↓ at C, distance a from A and b from B; one section at distance x from A (in AC) and one at distance x from B (in CB); reactions Pb/L ↑ at A and Pa/L ↑ at B. SFD: rectangle +Pb/L from A to C, then −Pa/L from C to B; note \"max S.F = Pb/L (because P is near to A)\". BMD: triangle, 0 at A and B, peak Pab/L under the load (max B.M), marked +." },
        { k: "steps", items: [
          "(S<sub>x</sub>)<sub>B–C</sub> = −P·a/L; (S<sub>x</sub>)<sub>A–C</sub> = +P·b/L — independent of 'x'. (M p.21)",
          "(BM<sub>x</sub>)<sub>B–C</sub> = (P·a/L)·x¹ — linear. x = 0: (BM)<sub>B</sub> = 0; x = b: (BM)<sub>C</sub> = Pab/L. (M p.21)",
          "(BM<sub>x</sub>)<sub>A–C</sub> = (Pb/L)·x¹ — linear. x = 0: (BM)<sub>A</sub> = 0; x = a: (BM)<sub>C</sub> = Pab/L. (M p.21)",
        ] },
        { k: "list", items: [
          "Conclusion — S.S beam with unsymmetric point load: 1) maximum S.F occurs at one of the supports; ★ 2) <b>B.M at simple supports is always zero</b>; 3) BMD is triangular with base = L and height = Pab/L. (M p.21)",
        ] },
        { k: "h", t: "(II) UDL W over the full span (M p.21–22)" },
        { k: "p", t: "Figure (M p.21): simply supported beam AB (pin A, roller B), span L, UDL W kN/m over the full span; section X–X at distance x from B; reactions WL/2 ↑ at A and at B. SFD: straight inclined line from +WL/2 at A to −WL/2 at B, crossing zero at L/2 (marked \"SF = 0\", \"pt. of contraflexure\", x = L/2), labelled <b>skew symmetric</b>. BMD: parabola, 0 at A and B, max WL²/8 at the centre, labelled <b>symmetric</b>." },
        { k: "steps", items: [
          "(SF)<sub>x</sub> = +W·x¹ − WL/2 ← linear ⇒ 0 = W(x) − WL/2 ⇒ <b>x = L/2</b>. (M p.21)",
          "(BM)<sub>x</sub> = −Wx(x/2) + (WL/2)(x) = −W·x²/2 + WLx/2 ← parabola (x²). (M p.21)",
          "x = 0: (BM)<sub>B</sub> = 0; x = L/2: (BM)<sub>centre</sub> = −W(L/2)²/2 + W·L(L/2)/2 = −WL²/8 [+] WL²/4 = <b>WL²/8</b>; x = L: (BM)<sub>A</sub> = 0. (M p.21)",
          "Conclusion: at the mid-point, x = L/2, <b>SF = 0</b>; thus dm/dx = S<sub>x</sub> = 0. (M p.22)",
        ] },
        { k: "note", t: "<b>Check:</b> the sign between −WL²/8 and WL²/4 is unclear on the page (it can be read as −). It must be <b>+</b>: −WL²/8 + WL²/4 = +WL²/8 ✓, which is the notes' answer." },
        { k: "list", items: [
          "When a S.S. beam is subjected to UDL on the entire span: ① load diagram — symmetric; ② BMD — symmetric; ③ SFD — skew symmetric. (M p.22)",
          "When SF = 0, BM is either maximum OR minimum. (M p.22) [The notes add \"(Pt. of contraflexure)\" here and on the SFD label.]",
        ] },
        { k: "note", t: "<b>Check:</b> the point where SF = 0 is the point of <b>maximum BM</b>, not a point of contraflexure. Contraflexure is where the <b>BM</b> is zero or changes sign (§3.5). In this beam the BM is zero only at the supports, so there is no point of contraflexure." },
        { k: "h", t: "(III) Central point load P (M p.21)" },
        { k: "p", t: "Figure (M p.21): simply supported beam AB (pin A, roller B), central point load P ↓; a = L/2, b = L/2; reactions P/2 ↑ at A and at B. SFD: +P/2 from A to the centre, drop of P at the centre, −P/2 from the centre to B. BMD: triangle, 0 at the ends, apex at the centre: <b>BM<sub>max</sub> = Pab/L = P(L/2)(L/2)/L = PL/4</b>, marked +." },
        { k: "h", t: "(IV) UVL — intensity W at A, zero at B (M p.22)" },
        { k: "p", t: "Figure (M p.22): simply supported beam AB (pin A, roller B), triangular UVL with intensity W kN/m at A reducing to zero at B; total load WL/2 ↓ acting at L/3 from A; section X–X at distance x from B with intensity W′ = W(x/L) and its resultant at x/3 from the section; reactions WL/3 ↑ at A and WL/6 ↑ at B. SFD: 2° parabola from +WL/3 at A, crossing zero (SF = 0) at L/√3 from B (i.e. L − L/√3 from A), to −WL/6 at B. BMD: cubic parabola, 0 at both ends, marked +, BM<sub>max</sub> = WL²/(9√3)." },
        { k: "steps", items: [
          "(SF)<sub>x</sub> = +½W′x − WL/6, with W′ = W(x/L) ⇒ <b>SF<sub>x</sub> = Wx²/(2L) − WL/6</b> — parabolic. (M p.22)",
          "When SF = 0: 0 = W·x²/(2L) − WL/6 ⇒ Wx²/(2L) = WL/6 ⇒ x² = L²/3 ⇒ ★ <b>x = L/√3 from B</b>. (M p.22)",
          "(BM)<sub>x</sub> = −(Wx²/(2L))(x/3) + (WL/6)·x ⇒ <b>(BM)<sub>x</sub> = −Wx³/(6L) + WLx/6</b> — cubic parabola. (M p.22)",
          "At x = L/√3: (BM)<sub>x</sub> = −(W/6L)(L/√3)³ + (WL/6)(L/√3) = −WL²/(6 × 3√3) + WL²/(6√3) (multiply the second term by 3/3) (M p.22)",
          "(BM)<sub>max</sub> = 2WL²/(6 × 3√3) = ★ <b>WL²/(9√3)</b>. (M p.22)",
        ] },
        { k: "list", items: [
          "Conclusion: SFD → 2° parabolic; BMD → cubic parabola. (M p.22)",
        ] },
        { k: "note", t: "<b>Source difference / cross-check with §3.5:</b> worked example 3.7 in §3.5 puts the zero load at A and the peak at B and finds the maximum at L/√3 = 3.464 m from <b>A</b> (the light end) with M<sub>max</sub> = wL²/(9√3). The MACE case has the peak at A and finds x = L/√3 from <b>B</b> — again from the light end. Both agree: the maximum BM of a triangular load on a simple span is WL²/(9√3) ≈ 0.064WL², located L/√3 ≈ 0.577L from the zero-intensity end." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Simply supported beam mein pehla kaam hamesha reactions. Uske baad har segment ke liye ek SF equation aur ek BM equation likho; SF ko zero rakh kar max BM ki location nikalo. UDL symmetric hai to answer mid-span (WL²/8); UVL mein max BM bhaari end se door, halke end se L/√3 par aata hai." },
        { k: "p", t: "Point load beech mein na ho (a ≠ b) to badi reaction load ke paas wale support par aati hai — isliye max SF bhi wahin (Pb/L jab load A ke paas ho)." },
        { k: "trap", t: "'SF = 0' wala point max BM ka point hai, contraflexure ka nahi. Contraflexure = jahan BM zero ho kar sign badle. Simply supported beam (sirf neeche ke loads ke saath) mein BM poore span mein sagging rehta hai — koi contraflexure nahi. (M p.21–22)" },
        { k: "real", t: "RCC slab aur beam design mein simply supported span ka moment WL²/8 sabse pehle nikalte hain; floor beams par wall ka triangular share (UVL jaisa) aaye to max moment WL²/(9√3) wala result use hota hai." },
      ],
    },

    /* ---------------------------------------------------------------- M p.22–23 */
    {
      n: "",
      title: "MACE notes — Simply supported beams with couples: pure bending and pure shear (cases V–VII)",
      hi: "युग्म वाले शुद्धालंबित धरन — शुद्ध बंकन और शुद्ध कर्तन",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.22–23" },
        { k: "h", t: "(V) Couple M at C (a from A, b from B) (M p.22–23, class lecture V-5)" },
        { k: "p", t: "Figure (M p.22): simply supported beam AB (pin A, roller B), point C at distance a from A and b from B; clockwise couple M at C; sections at distance x from A (in AC) and from B (in CB); reactions M/L ↓ at A and M/L ↑ at B. SFD: rectangle of constant value −M/L over the full span, marked −. BMD: linear from 0 at A down to −(M/L)a just left of C (marked −, linear), vertical jump at C up to +(M/L)b, then linear back to 0 at B (marked +, linear)." },
        { k: "steps", items: [
          "(S<sub>x</sub>)<sub>B–C</sub> = −M/L; (S<sub>x</sub>)<sub>A–C</sub> = −M/L — independent of 'x'. (M p.22)",
          "(M<sub>x</sub>)<sub>B–C</sub> = +(M/L) × x¹ — linear. x = 0: M<sub>B</sub> = 0; x = b: (M<sub>C</sub>)<sub>Right</sub> = +Mb/L. (M p.22)",
          "(M<sub>x</sub>)<sub>A–C</sub> = −(M/L) × x¹. x = 0: M<sub>A</sub> = 0; x = a: (M<sub>C</sub>)<sub>Left</sub> = −Ma/L. (M p.22)",
        ] },
        { k: "list", items: [
          "Conclusion: maximum +ve BM = maximum −ve BM — if a = b. (M p.23)",
          "<s>Net B.M at point C = Mb/L − Ma/L = (M/L)(b − a)</s> — this line is struck through in the notes; under it: if b &gt; a → net BM = +ve; if b &lt; a → net BM = −ve. (M p.23)",
        ] },
        { k: "note", t: "<b>Check:</b> the struck-out line is rightly struck out. The <b>jump</b> in the BMD at C is Mb/L − (−Ma/L) = M(a + b)/L = <b>M</b>, the applied couple — as example ① below shows (12 − (−6) = 18). (M/L)(b − a) is only the algebraic sum of the two side values, not a moment at C. What the b vs a comparison does tell you: the larger of the two peaks is on the longer side." },
        { k: "eg", title: "MACE notes example ① — clockwise couple 18 kN·m on a 3 m simple span", given: "Simply supported beam AB, span 3 m; couple M = 18 kN·m (clockwise) applied at C, 1 m from A and 2 m from B. Draw SFD and BMD.", steps: [
          { t: "Reactions", w: "R_A = M/L = 18/3 = 6 kN (↓ at A), R_B = 6 kN (↑ at B)" },
          { t: "SFD", w: "Rectangle marked −, value 6 kN throughout" },
          { t: "BM just left of C (hogging over AC)", w: "−6 × 1 = −6 kN·m" },
          { t: "BM just right of C (sagging over CB)", w: "(M/L)·b = 6 × 2 = 12 kN·m" },
          { t: "Net moment (jump at C)", w: "12 − (−6) = 18 kN·m" },
        ], ans: "BMD: 0 at A → −6 kN·m just left of C → jump to +12 kN·m just right of C → 0 at B; jump = 18 kN·m = applied couple. (M p.23)" },
        { k: "eg", title: "MACE notes example ② — the same couple, anticlockwise", given: "Same beam (C at 1 m from A, 2 m from B, span 3 m) with the 18 kN·m couple anticlockwise. Draw SFD and BMD.", steps: [
          { t: "Reactions", w: "6 kN ↑ at A, 6 kN ↓ at B" },
          { t: "SFD", w: "Rectangle marked +, 6 kN throughout" },
          { t: "BMD", w: "From 0 at A rising to +6 kN·m at C (sagging)\nJump down to −12 kN·m at C (hogging)\nLinear back to 0 at B" },
        ], ans: "SF = +6 kN throughout; BM = +6 kN·m just left of C and −12 kN·m just right of C. (M p.23)" },
        { k: "h", t: "(VI) Equal and opposite end couples M (M p.23)" },
        { k: "p", t: "Figure (M p.23): simply supported beam AB, span L; equal and opposite end couples M at A and at B; reactions 0 at A and 0 at B; section at x from B. SFD: zero line. BMD: rectangle marked −, value M constant throughout." },
        { k: "list", items: [
          "<b>S<sub>x</sub> = 0</b> — throughout zero. (M p.23)",
          "(BM)<sub>x</sub> = 0 − M = <b>−M</b> — independent of 'x'. (M p.23)",
          "This is the case of <b>pure bending OR simple bending</b> because M is constant throughout. (M p.23)",
        ] },
        { k: "h", t: "★ (VII) Uniformly distributed moment (UDM) m kN·m/m (M p.23)" },
        { k: "p", t: "Figure (M p.23): simply supported beam AB, span L, carrying UDM m kN·m/m (a row of small curved arrows); section at x from B. Reactions: R<sub>A</sub> = total moment / span = m·L/L = M (↓ at A), R<sub>B</sub> = M (↑ at B) — the notes write M for m here. SFD: rectangle marked −, value M constant from A to B. BMD: zero line." },
        { k: "list", items: [
          "<b>S<sub>x</sub> = −M</b> — independent of 'x'. (M p.23)",
          "M<sub>x</sub> = −M·x + M·x¹ (reaction moment minus applied distributed moment) — <b>M<sub>x</sub> = 0</b>, zero throughout. (M p.23)",
          "★ When BM = 0 and SF = constant throughout → this is the case of <b>pure shear</b>. (M p.23)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Couple ke liye supports ek <b>couple</b> hi bana kar balance karte hain: ek reaction upar, doosra neeche, dono M/L. Isliye SF poore span mein constant (M/L) aur BMD mein couple ki jagah par ek seedha vertical jump — jump ka size = applied couple." },
        { k: "p", t: "Do extreme cases yaad rakho: dono ends par barabar-ulte couples → SF = 0, BM constant = <b>pure bending</b>. Poore span par distributed moment → BM = 0, SF constant = <b>pure shear</b>. Ek doosre ke bilkul ulte." },
        { k: "trap", t: "Couple wale beam mein reaction ka direction load ki tarah mat socho — ek reaction neeche (downward) hota hai. Clockwise couple ke liye A par M/L neeche, B par upar; anticlockwise ho to ulta. Couple ki direction badli to SFD aur BMD dono ka sign palat jaata hai (examples ① aur ②). (M p.22–23)" },
      ],
    },

    /* ---------------------------------------------------------------- M p.24–25 */
    {
      n: "",
      title: "MACE notes — Overhanging beams (cases I–IV) and points of contraflexure",
      hi: "प्रलंबी धरन और प्रतिनमन बिंदु",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.24–25 (class lecture V-5)" },
        { k: "h", t: "(I) Point load P at the end of the overhang (M p.24)" },
        { k: "p", t: "Figure (M p.24): overhanging beam — pin at A, roller at B at distance L from A; overhang BC of length a with point load P ↓ at free end C; section 2–2 at distance x from A in span AB, section 1–1 at distance x from C in the overhang; red dashed deflected shape rising over AB and dipping beyond B. Reactions V<sub>A</sub> = Pa/L ↓ at A, V<sub>B</sub> = P(L + a)/L ↑ at B. SFD: − rectangle Pa/L from A to B, jump at B up to + rectangle P from B to C. BMD: −, linear from 0 at A to Pa at B, linear back to 0 at C." },
        { k: "steps", items: [
          "Find reactions first: −V<sub>B</sub>·L + P(L + a) = 0 ⇒ P(L + a) = V<sub>B</sub>·L ⇒ <b>V<sub>B</sub> = P(L + a)/L</b>; <b>V<sub>A</sub> = Pa/L ↓</b>. (M p.24)",
          "Max load on the overhang portion: −Pa/L + V<sub>B</sub> = −Pa/L + PL/L + Pa/L = <b>P</b>. (M p.24)",
          "(SF)<sub>1</sub> = +P; (SF)<sub>2</sub> = −Pa/L — independent of 'x'. (M p.24)",
          "(BM)<sub>1</sub> = −Px¹. x = a: (BM)<sub>B-Right</sub> = <b>−Pa</b> ← maximum BM on the overhang beam; x = 0: (BM)<sub>C</sub> = 0. (M p.24)",
          "(BM)<sub>2</sub> = (−P·a/L)·x¹ — linear. x = L: (BM)<sub>B-left</sub> = −Pa; x = 0: (BM)<sub>A</sub> = 0. (M p.24)",
        ] },
        { k: "list", items: [
          "Conclusion: ① maximum positive S.F = +P; ② maximum negative S.F = Pa/L; ③ maximum negative BM = Pa. (M p.24)",
        ] },
        { k: "h", t: "(II) Central point load P in the span, overhang unloaded (M p.24)" },
        { k: "p", t: "Figure (M p.24): pin A, roller B; point load P ↓ at C, mid-way between A and B (L/2, L/2); unloaded overhang of length a beyond B. Reactions P/2 ↑ at A and at B. SFD: + rectangle P/2 from A to C, − rectangle from C to B (P/2 − P = −P/2); SF = 0 on the overhang. BMD: triangle +, 0 at A, PL/4 at C, 0 at B; BM = 0 on the overhang." },
        { k: "list", items: [
          "(BM)<sub>overhang</sub> = 0; (BM)<sub>A–C</sub> = +(P/2)·x¹ — linear. (M p.24) [written \"+P·x¹\" in the notes; with reaction P/2 at A the slope is P/2, giving PL/4 at x = L/2 as in the figure.]",
        ] },
        { k: "h", t: "(III) UDL W on the overhang only (M p.24)" },
        { k: "p", t: "Figure (M p.24): pin A, roller B, span L; overhang BC of length a carrying UDL W kN/m; reactions V<sub>A</sub> ↓ at A and V<sub>B</sub> ↑ at B. SFD: − rectangle Wa²/(2L) from A to B, jump at B to +W·a, decreasing linearly to 0 at C. BMD: −, linear from 0 at A to Wa²/2 at B (\"linear because no load on beam\" in AB), then 2° parabola back to 0 at C." },
        { k: "steps", items: [
          "ΣM<sub>A</sub> = 0: −V<sub>B</sub>·L + W·a(L + a/2) = 0 ⇒ <b>V<sub>B</sub> = W(a/L)(L + a/2)</b>. (M p.24)",
          "ΣM<sub>B</sub> = 0: −V<sub>A</sub>·L + W·a·(a/2) = 0 ⇒ <b>V<sub>A</sub> = Wa²/2</b> [as boxed in the notes]. (M p.24)",
        ] },
        { k: "note", t: "<b>Check:</b> from −V<sub>A</sub>·L + Wa²/2 = 0, <b>V<sub>A</sub> = Wa²/(2L)</b> (downward). The boxed value drops the L; the SFD in the same figure correctly shows Wa²/(2L). Check: V<sub>B</sub> − V<sub>A</sub> = Wa + Wa²/(2L) − Wa²/(2L) = Wa = total load ✓." },
        { k: "p", t: "<b>NOTE:</b> if there is no load on the overhang portion, then SF &amp; BM at the free end (C) are zero, and also SF &amp; BM at support B = 0; vice versa when the overhang portion is loaded, i.e. at B ≠ 0 but at C = 0. (M p.24)" },
        { k: "h", t: "(IV) UDL W over the whole length, equal overhangs a on both sides (M p.25)" },
        { k: "p", t: "Figure (M p.25): beam with UDL W over its entire length; overhang a to the left of support A (hinge), span L between A and B (B roller), overhang a to the right of B. Section 3–3 in the left overhang (x from the left free end), 2–2 in span AB, 1–1 in the right overhang (x from the right free end). Reactions at A and B each = W(L + 2a)/2 ↑." },
        { k: "steps", items: [
          "SF<sub>1</sub> = +W·x′ ← linear; SF<sub>2</sub> = +W·x′ − W(L + 2a)/2; SF<sub>3</sub> = −Wx′. (M p.25)",
          "BM<sub>1</sub> = −Wx²/2 ← parabolic; BM<sub>2</sub> = −W(x + a)²/2 + [W(L + 2a)/2]·x; BM<sub>3</sub> = −Wx²/2. (M p.25)",
          "(SF)<sub>A</sub> = +W·L − WL/2 − Wa = WL/2 − W·a = W(L/2 − a) ⇒ <b>(SF)<sub>A</sub> = W(L − 2a)/2</b>. (M p.25)",
          "When SF is zero, find 'x': 0 = Wx − WL/2 − Wa ⇒ <b>x = (L + 2a)/2</b>. (M p.25)",
          "(★) <b>BM (centre) = W(L² − (2a)²)/8</b>. (M p.25)",
        ] },
        { k: "p", t: "Figure (M p.25) — SFD: starts at 0 at the left free end, linear down to −W·a just left of A (− region); jumps up to +W(L − 2a)/2 at A; linear decreasing through zero at mid-span (distance x marked to B) to a value written W(L + 2a)/2 just left of B (− region); jumps up to +W·a at B; linear down to 0 at the right free end." },
        { k: "note", t: "<b>Check:</b> the shear values at the supports in the notes do not balance. Just right of A: SF = −Wa + W(L + 2a)/2 = <b>+WL/2</b> (not W(L − 2a)/2); just left of B, by symmetry, SF = <b>−WL/2</b> (not W(L + 2a)/2). The notes' working subtracts Wa twice. SF<sub>2</sub> = Wx′ − W(L + 2a)/2 is right if x′ is measured from the <b>right free end</b>; then SF = 0 at x′ = (L + 2a)/2 = a + L/2, i.e. exactly at <b>mid-span</b> (L/2 from B), as symmetry requires. BM<sub>2</sub> uses x from B; putting x = L/2 gives W(L + 2a)(L − 2a)/8 = W(L² − 4a²)/8 ✓ — the notes' boxed centre moment is correct. BM at each support = −Wa²/2 ✓." },
        { k: "p", t: "Figure (M p.25) — BMD: starts at 0 at the left free end, hogging (−) curve down to −Wa²/2 at A; for L &gt; 2a a sagging (+) parabola rises to W(L² − (2a)²)/8 at the centre, crossing zero at two points (\"2 pt. of contraflexure\"); a red curve labelled L = 2a touches zero at the centre (\"only 1 pt\"); a blue curve below the axis labelled L &lt; 2a (\"no pt. of contraflexure\"); −Wa²/2 at B; hogging curve back to 0 at the right free end." },
        { k: "cmp", t: "BM in the mid-span portion depends on L vs 2a (M p.25)", cols: ["BM at centre", "Points of contraflexure"], rows: [
          ["i) L &gt; 2a", "maximum +ve BM at centre", "2"],
          ["ii) L &lt; 2a", "maximum −ve BM at centre [as written]", "0"],
          ["iii) L = 2a", "zero BM at centre", "1"],
        ] },
        { k: "note", t: "<b>Check:</b> for L &lt; 2a the centre BM W(L² − 4a²)/8 is negative but it is <b>not</b> the maximum hogging moment — its magnitude W(4a² − L²)/8 is less than Wa²/2 = 4Wa²/8 at the supports. The centre is where the hogging is <i>least</i> (SF = 0 there gives a local extreme); the maximum −ve BM is Wa²/2 over the supports." },
        { k: "list", items: [
          "Figure, Case (i) L &gt; 2a (M p.25): a = 1 m, L = 4 m, a = 1 m; red deflected shape sagging between supports with the ends curling up — \"sag at mid span\". BMD: hogging (−) at the supports, sagging (+) hump in the middle with maximum W(L² − (2a)²)/8; two points of contraflexure marked 1 and 2.",
          "Figure, Case (ii) L = 2a (M p.25): a = 1 m, L = 2 m, a = 1 m — \"no sag or hog at mid-span; here a = L/2, BM = 0\". BMD: two hogging (−) cusps at the supports touching zero at the centre (one point, marked 1).",
          "Figure, Case (iii) L &lt; 2a (M p.25): a = 2 m, L = 1 m, a = 2 m — \"hogging at mid-span\". BMD entirely hogging (−); centre value W(L² − (2a)²)/8; 0 points of contraflexure.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Overhang ek chhota cantilever hai jo support ke upar se latka hai — woh support par hogging moment (−Pa ya −Wa²/2) paida karta hai, aur span ke andar ka load sagging. Dono ki ladai se BMD ka shape tay hota hai: span lamba (L &gt; 2a) to beech mein sagging jeet jaata hai → 2 contraflexure points; overhang bade (L &lt; 2a) to poora beam hogging → koi contraflexure nahi." },
        { k: "p", t: "Overhang par load ho to span ka ek reaction <b>neeche</b> ki taraf ho sakta hai (case I aur III mein V<sub>A</sub> ↓) — yaani support ko beam ko neeche pakad kar rakhna padta hai, warna woh uth jaayega." },
        { k: "trap", t: "Overhang wale beam mein max BM mid-span par maan lena galat hai — case I aur III mein max BM support B par (−Pa, −Wa²/2) hai. Aur symmetric overhang (case IV) mein SF = 0 mid-span par hi aata hai; agar aapka x mid-span nahi de raha to x kahan se naapa, woh check karo. (M p.24–25)" },
        { k: "real", t: "Contraflexure points batate hain ki steel top se bottom kahan shift hoga — overhanging RCC beam (jaise canopy ke saath porch beam) mein support ke upar top steel aur span mein bottom steel; ek symmetric overhang ko L = 2a rakhne se mid-span moment zero ho jaata hai." },
      ],
    },

    /* ---------------------------------------------------------------- M p.26–27 */
    {
      n: "",
      title: "MACE notes — Shortcut rules A–J and the 10-case SFD/BMD chart",
      hi: "SFD/BMD शॉर्टकट नियम और 10 मानक स्थितियाँ",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.26–27 (class lecture V-7)" },
        { k: "h", t: "IMP NOTES for shortcut drawing of SFD & BMD (M p.26)" },
        { k: "cmp", t: "Rules A–F (M p.26)", cols: ["SFD", "BMD"], rows: [
          ["A] Between two point loads", "straight horizontal line", "straight inclined line"],
          ["B] Over UDL", "straight inclined line", "2° parabola"],
          ["C] Over UVL", "2° parabola", "3° (cubic parabola)"],
          ["D] At location of point load", "vertical line (two values/magnitudes of S.F)", "only a single value of BM"],
          ["E] At location of external moment applied", "nothing changes — not affected (only one value of S.F)", "vertical line (two magnitudes of B.M)"],
          ["F] At location of internal hinge", "not affected", "BM is zero"],
        ] },
        { k: "list", items: [
          "<b>G] In cantilever beams:</b> i) max S.F → total (net) vertical load on the beam, or the vertical reaction at the support; ii) max B.M → moment reaction at the fixed end; iii) max SF &amp; max BM always occur at the fixed end. (M p.26)",
          "<b>H] Overhang beams:</b> i) if the overhang is unloaded, then SF &amp; BM at the support near the overhang ⇒ zero (both SF &amp; BM); ii) if the overhang is loaded, then at the free end of the overhang S.F and BM are zero if there is no load or moment at the free end. (M p.26)",
          "<b>I] Where there are support reactions</b>, the change of SF is either i) from 0 to +ve value, ii) from −ve to +ve value, or iii) from a lower to a higher value. (M p.26)",
          "<b>J] Where there are downward loads</b>, the change of SF is either i) from +ve to 0, ii) from +ve to −ve, or iii) from a higher to a lower value. (M p.26)",
        ] },
        { k: "note", t: "Rule G(ii)/(iii) holds for an ordinary cantilever (no internal hinge). In chart cases ⑨ and ⑩ below (fixed end with an internal hinge) the maximum <i>sagging</i> moment PL/8 occurs in the span, though the largest magnitude is still at the fixed end." },
        { k: "h", t: "Chart of standard SFD & BMD cases ① to ⑩ (M p.27)" },
        { k: "cmp", t: "Cases ①–⑧ (M p.27)", cols: ["Reactions", "SFD", "BMD"], rows: [
          ["① Cantilever, P at free end", "P ↑, moment PL", "+ rectangle, P throughout", "− triangle, PL at fixed end → 0"],
          ["② Cantilever A–B–C, P at B (AB = BC = L/2)", "P ↑, moment PL/2", "+ rectangle P from A to B, zero B to C", "− triangle PL/2 at A → 0 at B; zero B to C"],
          ["③ Cantilever, UDL W over L", "WL ↑, moment WL²/2", "+ triangle WL → 0 (dm/dx = 0 at free end)", "− 2° curve WL²/2 → 0"],
          ["④ Cantilever, UVL W at fixed end → 0 at free end", "WL/2 ↑, moment WL²/6", "+ 2° parabola WL/2 → 0 (SF = 0, dm/dx = 0 at free end)", "− 3° parabola WL²/6 → 0"],
          ["⑤ S.S., central P (symmetric)", "P/2, P/2", "skew symmetric: +P/2 left half, −P/2 right half", "symmetric + triangle, max PL/4 at centre"],
          ["⑥ S.S., P at a from left, b from right", "Pb/L left, Pa/L right", "+Pb/L to load, −Pa/L after", "+ triangle, max Pab/L under the load"],
          ["⑦ S.S., UDL W over span (symmetric)", "WL/2, WL/2", "skew symmetric: +WL/2 → 0 at L/2 → −WL/2", "symmetric 2° parabola, max WL²/8"],
          ["⑧ S.S., UVL w at left → 0 at right", "WL/3 left, WL/6 right", "+WL/3 → zero at L/√3 from the right end → −WL/6", "curve, max WL²/(9√3)"],
        ] },
        { k: "p", t: "Figure ④ writes the fixing moment as \"WL/6 with ² above\", i.e. WL²/6, matching case (III). Figure ⑧ notes ds/dx = 0 at the right support, where the load intensity is zero. (M p.27)" },
        { k: "h", t: "⑨ Fixed at A, internal hinge H, roller at B (M p.27)" },
        { k: "p", t: "Figure (M p.27): beam fixed at A (left), internal hinge H at L/2 from A, point load P at L/4 beyond H, roller support B at a further L/4. Reactions: P/2 ↑ at A, P/2 ↑ at B. Free body H–B: P at its centre, reactions P/2 ↑ at H and P/2 ↑ at B. Free body A–H (length L/2): P/2 ↓ at H, fixed-end reaction P/2 ↑ and moment PL/4. SFD: + P/2 from A to the load; − P/2 from the load to B. BMD: −PL/4 at A, linear through zero at H, + peak PL/8 under the load, 0 at B." },
        { k: "h", t: "⑩ Fixed at A, P at L/4, internal hinge at L/2, P at 3L/4, support at C (M p.27)" },
        { k: "p", t: "Figure (M p.27): beam fixed at A, end C supported; points spaced L/4, L/4, L/4, L/4: P at L/4 from A, internal hinge H at L/2, P at 3L/4, C at L. Free body H–C: P at its middle, reactions P/2 ↑ at H and P/2 ↑ at C. Free body A–H: fixed at A, P at L/4, P/2 ↓ at H. Reactions at A: 3P/2 ↑ and moment PL/2. SFD: 3P/2 (= 1.5P) from A to the first load (+); then 0.5P = P/2 to the second load; then −P/2 (−) to C. BMD: −PL/2 at A, rising linearly, through zero, + peak PL/8 under the second load, 0 at C." },
        { k: "steps", items: [
          "Fixing moment (ΣM about A for A–H): −M + P·(L/4) + (P/2)·(L/2) = 0 ⇒ M = 2·(PL/4) ⇒ <b>M = PL/2</b>. (M p.27)",
          "BM at the first load point: −PL/2 + (3P/2) × (L/4) = −4PL/8 + 3PL/8 = <b>−PL/8</b> (the notes head this line \"PL/8 =\"; the result is −PL/8, hogging). (M p.27)",
        ] },
        { k: "note", t: "<b>Check (⑨, ⑩):</b> ⑨ fixing moment = (P/2)(L/2) = PL/4 ✓; peak under the load = (P/2)(L/4) = PL/8 ✓. ⑩ M<sub>A</sub> = P(L/4) + (P/2)(L/2) = PL/2 ✓; BM at the first load = −PL/8 ✓; BM at the hinge = −PL/2 + (3P/2)(L/2) − P(L/4) = 0 ✓ (rule F); peak under the second load = (P/2)(L/4) = PL/8 ✓." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Rules A–J ek hi baat ke alag roop hain: point force → SFD mein jump, couple → BMD mein jump, distributed load → SFD mein slope. Reaction (upar) SFD ko upar uchhalta hai, load (neeche) neeche girata hai — left se right chalte hue bas yeh karte jao, SFD khud ban jaata hai." },
        { k: "p", t: "Internal hinge wale beam (⑨, ⑩) ko hinge par kaat kar do alag beams bana do: hinge ke aage wala hissa simply supported ki tarah solve karo, uska hinge-reaction pichhle hisse (cantilever) par load ban jaata hai. Hinge par BM hamesha zero." },
        { k: "trap", t: "Rule D aur E ko ulta mat yaad karo: <b>point load</b> → SFD mein vertical line (do values), BMD mein ek hi value; <b>couple</b> → BMD mein vertical line, SFD par koi asar nahi. (M p.26)" },
      ],
    },

    /* ---------------------------------------------------------------- M p.28–30 */
    {
      n: "",
      title: "MACE notes — Load diagram and maximum BM from a given SFD or BMD",
      hi: "दिए गए SFD/BMD से भार आरेख और अधिकतम BM",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.28–30 (class lecture V-8)" },
        { k: "cmp", t: "Reading the SFD back into loads (M p.28)", cols: ["Load"], rows: [
          ["\"—\" horizontal line", "No load (between point loads)"],
          ["\"|\" vertical line", "At the location of a point load: SF jumps up ⇒ load ↑; SF drops ⇒ load ↓"],
          ["\"\\\" inclined line", "UDL"],
          ["2° curve", "UVL"],
        ] },
        { k: "list", items: [
          "Intensity of UDL: −(ds/dx) = W, i.e. slope of SFD = W. (M p.28)",
          "At a point: −ds = [W·dx] ⇒ −(change of SF) = load at that point. (M p.28)",
          "Checks: i) force equilibrium — ΣF<sub>x</sub> = 0 (no horizontal load on the beam, so the beam is in equilibrium in the horizontal direction) and ΣF<sub>y</sub> = 0; ii) rotational equilibrium — ΣM = 0. (M p.28)",
          "Short trick for BM: dm/dx = S ⇒ dm = [S·dx] ⇒ <b>M<sub>2</sub> − M<sub>1</sub> = area of SFD between the two points</b>. (M p.29–30)",
        ] },
        { k: "p", t: "Figure, Que 1 (M p.28): given SFD over beam A–B–C–D–E, AB = 2 m, BC = 1 m, CD = 1 m, DE = 1 m: +3 kN from A to B; drops to −3 kN at B; −3 kN from B to C; straight line from −3 kN at C down to −9 kN at D; jumps up to +2 kN at D; +2 kN from D to E; drops to 0 at E. Answer figure (load diagram): 3 kN ↑ at A; 6 kN ↓ at B (3 − (−3) = 6 kN); UDL 6 kN/m from C to D; 11 kN ↑ at D; 2 kN ↓ at E (2 − 0 = 2 kN)." },
        { k: "eg", title: "MACE notes example — Que 1: load diagram from a given SFD", given: "For the given shear force diagram draw the corresponding load diagram. (SFD: +3 kN over AB = 2 m; −3 kN over BC = 1 m; linear from −3 to −9 kN over CD = 1 m; +2 kN over DE = 1 m; 0 at E.)", steps: [
          { t: "Point loads from the vertical lines", w: "A: SF rises 0 → 3: point load 3 kN ↑\nB: SF drops 3 → −3: −[3 − (−3)] = −6 kN, i.e. 6 kN ↓\nD: −(9 − (2)) = +11 kN, i.e. 11 kN ↑ [as written]\nE: 2 − 0 = 2 kN ↓" },
          { t: "Intensity of UDL over CD", w: "−(ds/dx) = W\n−(3 − (−9)) = W\n−6 kN/m = W\nSlope of SFD = (9 − 3)/1 = 6 kN/m" },
          { t: "Check ΣFy = 0", w: "+3 − 6 − 6 × 1 + 11 − 2 = 0 ... o.k." },
          { t: "Check ΣM about A", w: "ΣM_A = +6 × 2 + 6 × 1 × (3 + 1/2) − 11 × 4 + 2 × 5\n= 12 + 21 − 44 + 10\n= 43 − 44\n= −1 kN·m (anticlockwise)" },
          { t: "Conclusion from the moment check", w: "The beam is rotationally unstable due to a moment of 1 kN·m in the anticlockwise direction.\n∴ apply a moment of 1 kN·m in the clockwise direction." },
        ], ans: "Load diagram: 3 kN ↑ at A, 6 kN ↓ at B, UDL 6 kN/m on CD, 11 kN ↑ at D, 2 kN ↓ at E, plus a 1 kN·m clockwise couple for rotational equilibrium. (M p.28)" },
        { k: "note", t: "<b>Check:</b> two lines of the working are written with wrong signs but reach the right numbers. UDL: the SF goes from −3 (at C) to −9 (at D), so −ds/dx = −[(−9) − (−3)]/1 = <b>+6 kN/m</b> (downward load); the written \"−(3 − (−9))\" equals −12, not −6. At D: change of SF = 2 − (−9) = +11, so the load is <b>11 kN ↑</b>; the written \"−(9 − (2))\" equals −7. Equilibrium checks ΣF<sub>y</sub> = 0 and ΣM<sub>A</sub> = −1 kN·m re-work correctly. A couple does not show in an SFD (rule E), so its position cannot be found from the SFD alone — the BMD would be needed." },
        { k: "p", t: "Figure, Que 2 (M p.29): given SFD — +30 kN at A, inclined line crossing zero at D, reaching −10 kN at C (AC = 4 m); constant −10 kN from C to B (CB = 4 m); 10 kN at B. Load diagram: UDL 10 kN/m from A to C (x = 3 m to D marked), V<sub>A</sub> = 30 kN ↑, V<sub>B</sub> = 10 kN ↑. Similar-triangle sketch: 30 at left, x to the zero crossing, 4 − x, 10 at right." },
        { k: "eg", title: "MACE notes example — Que 2: maximum BM from a given SFD", given: "Find out the maximum B.M for the beam corresponding to the following shear force diagram. (SFD: +30 kN at A falling linearly to −10 kN at C, AC = 4 m; constant −10 kN from C to B, CB = 4 m.)", steps: [
          { t: "Theory points", w: "Point of zero S.F = D, i.e. max BM occurs at point D.\nFind the location of max BM by the similar-triangle method." },
          { t: "Location of D", w: "30/x = 10/(4 − x)\n30(4 − x) = 10x\n120 − 30x = 10x\nx = 3 m" },
          { t: "UDL intensity, A to C", w: "(−ds)/dx = W\n−[+30 − (−10)]/4 m = W\n−10 kN/m = W\nOR A to D: −[(+30 − 0)/3] = W → −10 kN/m = W" },
          { t: "Max BM at D", w: "(BM)_D = +30 × 3 − 10 × 3 × 3/2\n= 90 − 45\n= 45 kN·m" },
          { t: "Checks", w: "ΣFy: +30 − 10(4) + 10 = 0 ... o.k.\nΣM: +10 × 4 × 4/2 − 10 × 8 = 0 ... ok." },
          { t: "Short trick", w: "dm/dx = S → dm = [S·dx]\nM_D − M_A (= 0) = area of SFD between A and D\n(M_D)max = 1/2 × 3 × 30 = 45 kN·m" },
        ], ans: "Maximum BM = 45 kN·m at D, 3 m from A. (M p.29)" },
        { k: "note", t: "<b>Sign note:</b> the working writes −[30 − (−10)]/4 = W and gets \"−10 kN/m\"; as a magnitude the UDL is 10 kN/m acting <b>downward</b> (−ds/dx = −(−10 − 30)/4 = +10). The final answer 45 kN·m re-works correctly." },
        { k: "eg", title: "MACE notes example — Que 3: maximum BM from a stepped SFD", given: "For the given SFD, find out the maximum BM. (SFD: +2 kN over AB = 1.5 m; zero over BC = 2 m; −2 kN over CD = 1.5 m.)", steps: [
          { t: "Load diagram (figure)", w: "2 kN ↑ at A, 2 kN ↓ at B (1.5 m), 2 kN ↓ at C (a further 2 m), 2 kN ↑ at D (a further 1.5 m)" },
          { t: "Where BM is maximum", w: "In BC, SF = 0\n∴ in BC, BM = maximum" },
          { t: "BM at B from the SFD area", w: "In portion AB, dm/dx = S\nM_B − M_A (= 0) = S·dx\nM_B = area of SFD = 2 × 1.5" },
        ], ans: "M_B = 3 kN·m (constant over BC — the maximum BM). (M p.30)" },
        { k: "eg", title: "MACE notes example — Que 4: load from a given BMD", given: "Following is the BMD; find out the maximum load applied on the beam. (BMD: triangle over A–C–B, AC = 2 m, CB = 2 m, peak 20 kN·m at C.)", steps: [
          { t: "Using the central point-load result", w: "20 kN·m = BM_max = PL/4 = (P × 4)/4\n20 kN·m = P [as written]" },
          { t: "OR from the SFD area", w: "dm/dx = S → dm = [S·dx]\nM_C − M_A (= 0) = area under SFD\n20 = S_A × 2\nS_A = 10 kN" },
          { t: "Figure", w: "Load 20 kN ↓ at the centre; R_A = 10 kN ↑, R_B = 10 kN ↑\nSFD: +10 for the left half, −10 kN for the right half" },
        ], ans: "P = 20 (kN); S_A = 10 kN. (M p.30)" },
        { k: "note", t: "<b>Check:</b> the boxed line reads \"20 kN·m = P\"; P is a force, so <b>P = 20 kN</b> (20 kN·m × 4 / 4 m). Each reaction = P/2 = 10 kN ✓." },
        { k: "p", t: "Figure, Que 5 (M p.30): SFD — at A +14 kN, decreasing linearly to +2 kN at B (AB = 2 m, +); drops to −13 kN at B; linear to −19 kN at C (BC = 1 m, −); rises to 0 at C. \"Location of max BM (M<sub>B</sub>)\" points to B. Load diagram: 14 kN ↑ at A; UDL over A to C; 15 kN ↓ at B (+2 − (−13) = 15 kN); 19 kN ↑ at C; UDL intensity A–B = 12/2 = (14 − 2)/2 = 6, B–C = (19 − 13)/1 = 6 (written \"6 kN.m\")." },
        { k: "eg", title: "MACE notes example — Que 5: maximum BM from a trapezoidal SFD area", given: "For the given SFD, determine the maximum BM. (SFD: +14 kN at A falling linearly to +2 kN at B, AB = 2 m; drops to −13 kN at B; linear to −19 kN at C, BC = 1 m; back to 0 at C.)", steps: [
          { t: "Location of maximum BM", w: "SF changes sign at B → maximum BM at B" },
          { t: "BM from the SFD area", w: "dm/dx = S → dm = S·dx\nM_B − M_A (= 0, simple support) = area of SFD between B and A\n= area of trapezoid\n= [(sum of parallel sides)/2] × distance between parallel sides\n= [(14 + 2)/2] × 2" },
        ], ans: "M_B = 16 kN·m (M p.30)" },
        { k: "note", t: "<b>Check:</b> UDL intensity is 6 <b>kN/m</b> (the notes write \"6 kN.m\"). Equilibrium: up 14 + 19 = 33 kN; down 6 × 3 + 15 = 33 kN ✓. BM at C = 16 − area(B to C) = 16 − (13 + 19)/2 × 1 = 0 ✓, consistent with a simple support at C." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ulta sawaal (SFD diya hai, load nikalo) mein bas SFD ko left se right padho: har vertical jump ek point force hai (upar jump = upward force), har slope ek UDL hai (slope ka magnitude = intensity), aur horizontal stretch = koi load nahi. Akhir mein ΣF<sub>y</sub> aur ΣM se check — moment balance na ho to beam par kahin ek couple bhi hai jo SFD mein dikhta nahi." },
        { k: "p", t: "Max BM ka sabse tez tareeka: SF jahan zero ho ya sign badle, wahan tak SFD ka area jod lo (simple support par M = 0 se shuru). Triangle, rectangle, trapezium — area formula hi kaafi hai, BM equation likhne ki zaroorat nahi." },
        { k: "trap", t: "SFD ke area mein signs ka dhyan rakho — positive area M badhata hai, negative area ghatata hai. Aur area 'support se' tabhi shuru karo jab wahan M = 0 ho (simple support ya free end); fixed end se shuru karoge to wahan ka fixing moment pehle jodna padega. (M p.29–30)" },
      ],
    },

    /* ---------------------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — SFD and BMD (M p.14–30)",
      hi: "पुनरावृत्ति — SFD और BMD",
      blocks: [
        { k: "h", t: "✅ Key points from M p.14–30" },
        { k: "list", items: [
          "✅ Shear force = internal transverse force for force equilibrium = algebraic sum of forces perpendicular to the section; clockwise +ve. (M p.14)",
          "✅ Bending moment = internal moment for rotational equilibrium; sagging (smiling) +ve, hogging −ve. (M p.14)",
          "✅ −dS/dx = W (−ve slope of SFD = load intensity); dM/dx = S (slope of BMD = SF); S = 0 ⇒ M max/min. (M p.15)",
          "✅ SFD/BMD are used for max SF, max BM, contraflexure, construction joints and lap locations. (M p.16)",
          "✅ Cantilever, P at free end: S = P, M = −Px, M<sub>max</sub> = PL at fixed end. (M p.16)",
          "✅ Cantilever, UDL W: S = Wx, M = −Wx²/2, max WL and WL²/2 at fixed end. (M p.17)",
          "✅ Cantilever, UVL W at fixed end: W′ = Wx/L, S = Wx²/(2L), M = −Wx³/(6L); max WL/2 and WL²/6. (M p.17–18)",
          "✅ Cantilever, UVL W at free end: S = WL/2 − Wx²/(2L), M = −WL²/3 + WLx/2 − Wx³/(6L); max WL/2 and WL²/3. (M p.18–19)",
          "✅ Degree ladder: load → SFD → BMD, each 1° higher (point load 0°/1°, UDL 1°/2°, UVL 2°/3°). (M p.18)",
          "✅ Couple at a cantilever end: S = 0, M = −M constant; SFD is independent of couples. Uniformly distributed moment m: S = 0, M = −mx, max mL. (M p.19)",
          "✅ Vertical line in SFD = load or reaction there (two SF values). Axial load gives no SF or BM. (M p.19–20)",
          "✅ τ = S/(bd) (average shear stress) — Que 8 answer 0.25 (N/mm²) for 30 kN on 300 × 400. (M p.20)",
          "✅ S.S. beam, P at a/b: reactions Pb/L, Pa/L; M<sub>max</sub> = Pab/L; BM at simple supports always zero. Central P: PL/4. (M p.21)",
          "✅ S.S. beam, UDL: reactions WL/2; SF = 0 at L/2; M<sub>max</sub> = WL²/8; load and BMD symmetric, SFD skew symmetric. (M p.21–22)",
          "✅ S.S. beam, UVL W at A: reactions WL/3, WL/6; SF = 0 at L/√3 from the zero end; M<sub>max</sub> = WL²/(9√3). (M p.22)",
          "✅ S.S. beam, couple M at C: SF = −M/L constant; BM −Ma/L and +Mb/L either side of C; jump = M. (M p.22–23)",
          "✅ Equal opposite end couples → SF = 0, BM constant = pure bending; UDM on S.S. beam → BM = 0, SF constant = pure shear. (M p.23)",
          "✅ Overhang with P at its end: V<sub>A</sub> = Pa/L ↓, V<sub>B</sub> = P(L + a)/L; max −ve BM = Pa at B. (M p.24)",
          "✅ Overhang with UDL on the overhang: V<sub>B</sub> = W(a/L)(L + a/2), V<sub>A</sub> = Wa²/(2L) ↓; BM at B = −Wa²/2. (M p.24)",
          "✅ UDL on whole beam with equal overhangs a: each reaction W(L + 2a)/2; BM at supports −Wa²/2; BM at centre W(L² − 4a²)/8; L &gt; 2a → 2, L = 2a → 1, L &lt; 2a → 0 points of contraflexure. (M p.25)",
          "✅ Rules A–J: point load → SFD jump; couple → BMD jump, SFD unchanged; internal hinge → BM = 0; reactions raise SF, downward loads lower it. (M p.26)",
          "✅ Chart ⑨: fixed–hinge–roller, P at L/4 beyond the hinge: fixing moment PL/4, span peak PL/8. ⑩: fixing moment PL/2, −PL/8 at first load, +PL/8 under second load. (M p.27)",
          "✅ SFD → load: horizontal = no load, vertical = point load, inclined = UDL, 2° curve = UVL; −(change of SF) = load. (M p.28)",
          "✅ M<sub>2</sub> − M<sub>1</sub> = area of SFD between the points — Que 2: 45 kN·m; Que 3: 3 kN·m; Que 4: P = 20 kN; Que 5: 16 kN·m. (M p.29–30)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
