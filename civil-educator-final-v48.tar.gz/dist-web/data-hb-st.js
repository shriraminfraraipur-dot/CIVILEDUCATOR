/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   ------------------------------------------------------------
   The third handbook. Built on IS 800:2007 (limit state), and
   like the RCC handbook it cites a clause for every design value.

   Copyright line, as everywhere in this app: clause number and
   heading are navigation facts. The explanations, the derivations,
   the worked arithmetic and the traps are written for this app.
   The code's own text is never reproduced, and section property
   tables are never copied — a worked example states the properties
   it uses so the reader can check them against IS 808 / SP:6(1).

   Chapters 1–2 follow in this file; later chapters are pushed by
   data-hb-st2.js onwards.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "st",
  subject: "steel",
  name: "Design of Steel Structures",
  hi: "इस्पात संरचना डिज़ाइन",
  icon: "⛓",
  blurb: "IS 800:2007 ka poora limit state course — steel ke behaviour se lekar connection, column, beam aur plate girder tak, har clause ke saath.",
  note: "Every design value in this handbook names the IS 800:2007 clause it comes from, and section properties used in examples are stated rather than reproduced from the tables. Confirm any value against the published standard and against IS 808 / SP:6(1) before using it in design.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "st-1",
      n: 1,
      title: "Steel, and Why It Is Designed Differently",
      hi: "इस्पात और इसका अलग डिज़ाइन",
      blurb: "What changes when the material is ductile, equally strong in tension and compression, and thin enough to buckle.",
      mins: 32,
      sections: [

        {
          n: "1.1",
          title: "Coming to steel from concrete",
          hi: "कंक्रीट से इस्पात तक",
          blocks: [
            { k: "p", t: "If you have worked through the RCC handbook, almost every instinct you built there needs adjusting. Not discarding — the limit state framework is the same, the idea of factored loads against factored resistance is the same — but the questions a steel design has to answer are different ones." },
            { k: "list", items: [
              "Concrete is <strong>strong in compression and useless in tension</strong>; steel is equally strong in both. So there is no neutral axis to find, no steel to place where the tension is, no cracked section.",
              "Concrete is <strong>cast into whatever shape you draw</strong>; steel arrives as rolled sections in fixed sizes. Design is choosing from a catalogue, not specifying dimensions.",
              "Concrete members are <strong>stocky</strong> and fail by crushing; steel members are slender and fail by <strong>buckling</strong> — of the member, of a plate within it, or by twisting sideways.",
              "Concrete is <strong>monolithic</strong>; a steel structure is pieces bolted or welded together, and the connections are where most of the design effort and most of the failures are.",
              "Concrete is made on site and tested by cube; steel is made in a mill to IS 2062 and comes with a test certificate. Its properties are known far better — which is why its partial safety factors are smaller.",
            ]},
            { k: "note", t: "That last point is worth holding on to. γm on concrete is 1.5 and on reinforcement 1.15; in IS 800 the factor on yielding is 1.10. The material is not safer — it is better <em>known</em>, and a partial safety factor is a statement about uncertainty, not about danger." },
          ],
        },

        {
          n: "1.2",
          title: "What the stress-strain curve tells you",
          hi: "स्ट्रेस-स्ट्रेन वक्र क्या बताता है",
          blocks: [
            { k: "p", t: "Mild steel in tension does something no other common construction material does: after it yields, it goes on stretching at almost constant stress for a long way before it strengthens again. That plateau is the single most important feature of the material." },
            { k: "dia", id: "hb-st-curve", cap: "The plateau is the ductility. Design sits well down the elastic line; the plateau is the reserve." },
            { k: "list", items: [
              "<strong>Elastic range</strong> — stress proportional to strain, with E = 2 × 10⁵ N/mm² (Cl. 2.2.4.1). This is where every member is designed to sit under load.",
              "<strong>Upper and lower yield</strong> — the stress at which the material starts to flow. fy is taken as the lower yield value, which is the repeatable one.",
              "<strong>The yield plateau</strong> — strain increases roughly ten to fifteen times the yield strain at constant stress. This is what lets an overstressed member shed load to its neighbours.",
              "<strong>Strain hardening</strong> — the material stiffens again and stress rises to fu.",
              "<strong>Necking and fracture</strong> — the bar thins locally and breaks, typically at around 23% elongation for structural steel.",
            ]},
            { k: "p", t: "Design never enters the plateau under working conditions. Its value is what happens if something is worse than assumed: a plastic section can rotate at its plastic moment while the rest of the frame picks up the difference, and a bolt group can redistribute among its bolts instead of failing at the most heavily loaded one. Ductility is not spare strength — it is the freedom to be slightly wrong." },
            { k: "trap", t: "High-strength steel is not simply better steel. As fy rises the plateau shortens and the elongation at fracture falls, so the ductility you are relying on shrinks. That is why IS 2062 specifies a <em>minimum percentage elongation</em> as well as a minimum yield stress, and why the code will not let you design a plastic mechanism in a section that cannot rotate." },
          ],
        },

        {
          n: "1.3",
          title: "Grades, and the properties that never change",
          hi: "ग्रेड और वे गुण जो नहीं बदलते",
          blocks: [
            { k: "p", t: "Structural steel in India is specified to IS 2062. The grade designation gives the yield stress directly: E250 has fy = 250 N/mm² and fu = 410 N/mm², E350 has fy = 350 and fu = 490, and so on up through E410, E450 and beyond." },
            { k: "tbl", id: "tb-800-steel" },
            { k: "p", t: "Two things about that table matter more than the numbers themselves." },
            { k: "list", items: [
              "<strong>fy falls as the plate gets thicker.</strong> E250 is 250 N/mm² up to 20 mm, and less above it. Thick plate cools more slowly and its grain structure is coarser. A design that assumes 250 for a 40 mm flange is overstating the strength.",
              "<strong>The grade also carries a quality suffix</strong> — A, BR, B0, C — which is about notch toughness at low temperature, not about strength. It matters for welded structures, for anything carrying impact or fatigue, and for cold climates.",
            ]},
            { k: "h", t: "What does not change with grade" },
            { k: "p", t: "Cl. 2.2.4.1 fixes these for all structural steels, and they are worth memorising because they appear in every buckling calculation in the book:" },
            { k: "list", items: [
              "Modulus of elasticity <strong>E = 2.0 × 10⁵ N/mm²</strong>",
              "Modulus of rigidity <strong>G = 0.769 × 10⁵ N/mm²</strong>",
              "Poisson's ratio <strong>μ = 0.3</strong>",
              "Coefficient of thermal expansion <strong>α = 12 × 10⁻⁶ per °C</strong>",
              "Unit mass <strong>ρ = 7850 kg/m³</strong>, so unit weight 78.5 kN/m³",
            ]},
            { k: "trap", t: "E does not improve with grade. A column made of E350 is no stiffer than the same column in E250 — and since buckling depends on E and not on fy, a slender column gets <strong>no benefit at all</strong> from the higher grade. Paying for E350 in a slender compression member is money spent on nothing, and §6.6 shows exactly where the benefit disappears." },
          ],
        },

        {
          n: "1.4",
          title: "Buckling is the recurring theme",
          hi: "बकलिंग ही मुख्य विषय है",
          blocks: [
            { k: "p", t: "In the RCC handbook, failure meant a material reaching its limit — concrete crushing or steel yielding. In steel design that is often the least likely outcome. Steel is strong enough that the sections are thin, and thin things buckle." },
            { k: "dia", id: "hb-st-buckle", cap: "Three columns of the same steel and the same area, failing at three completely different loads." },
            { k: "p", t: "Four distinct buckling problems run through this handbook, and it is worth naming them now so that each chapter can be placed against one:" },
            { k: "list", items: [
              "<strong>Flexural buckling of a member</strong> — a column bows sideways. Chapter 6.",
              "<strong>Local buckling of a plate</strong> — a flange outstand ripples, or a web ripples. Chapter 2 classifies sections by whether this happens, and Chapter 10 designs webs that will.",
              "<strong>Lateral-torsional buckling</strong> — a beam's compression flange kicks sideways and drags the section into a twist. Chapter 8.",
              "<strong>Web buckling and crippling</strong> — the web fails locally under a concentrated load or a reaction. Chapter 7.",
            ]},
            { k: "p", t: "There is a general shape to all four. Each has a theoretical elastic buckling load, from Euler or from plate theory; each is reduced below that by imperfections, residual stresses and eccentricity; and IS 800 handles each with a <strong>reduction factor χ</strong> applied to the material strength. Once you have understood the column curve of Chapter 6, the beam curve of Chapter 8 is the same machinery with different constants." },
            { k: "note", t: "Residual stresses deserve a word, because they are invisible and matter a great deal. A hot-rolled section cools unevenly — flange tips and web centre cool first — so the finished section carries locked-in stresses of 70 to 100 N/mm² before any load is applied. Parts of it therefore yield earlier than fy would suggest, and that is why real columns are weaker than the Euler curve says." },
          ],
        },

        {
          n: "1.5",
          title: "The limit state framework in IS 800",
          hi: "IS 800 का लिमिट स्टेट ढाँचा",
          blocks: [
            { k: "p", t: "IS 800:2007 replaced the working stress method of the 1984 edition with limit state design, and the structure is the same one Chapter 1 of the RCC handbook set out: factored loads on one side, factored resistance on the other, checked at collapse and at serviceability separately." },
            { k: "eq", expr: "Design action (factored loads)  ≤  Design strength (characteristic strength / γm)", where: [] },
            { k: "p", t: "Cl. 5.3.3 and Table 4 give the load combinations and their partial safety factors — 1.5(DL + LL) for the common case, with different values where wind or earthquake acts, and 0.9 on dead load where dead load is <em>resisting</em> (uplift, overturning, sliding). For serviceability all the factors are 1.0." },
            { k: "h", t: "One factor per failure mode" },
            { k: "dia", id: "hb-st-gamma", cap: "IS 800 Table 5 sets a separate γm for each way a component can fail." },
            { k: "list", items: [
              "<strong>γm0 = 1.10</strong> — resistance governed by <em>yielding</em>, of a member or of the gross section. Ductile, gradual, and the property is mill-certified.",
              "<strong>γm1 = 1.25</strong> — resistance governed by <em>ultimate stress</em>: rupture at a net section, tearing at a bolt hole, block shear. These are brittle and give no warning.",
              "<strong>γmb = 1.25</strong> — bolts, in shear or bearing.",
              "<strong>γmw = 1.25</strong> for shop welds and <strong>1.50</strong> for site welds — the same weld, differently trusted, because of the conditions it is made in.",
            ]},
            { k: "trap", t: "Choosing γm0 where γm1 belongs is the most common systematic error in steel design, and it always errs unsafely. The test is simple: ask <em>what actually fails</em>. If the whole cross-section yields and stretches, it is γm0. If something tears — at a hole, along a line of bolts, across a net section — it is γm1. Chapter 5 uses both in the same member, for two different modes." },
            { k: "p", t: "Serviceability is covered by Cl. 5.6 and the deflection limits of Table 6, which are given per member type and per cladding type. Brittle cladding gets a tighter limit than elastic cladding, for exactly the reason Chapter 10 of the RCC handbook gave: the limit is set by what the deflection will damage, not by the member itself." },
          ],
        },

        {
          n: "1.6",
          title: "The sections you will be choosing from",
          hi: "उपलब्ध सेक्शन",
          blocks: [
            { k: "p", t: "Rolled sections are standardised in IS 808, and their properties are tabulated in SP:6(1). Design means selecting from that catalogue — so it helps to know what each shape is good at before opening it." },
            { k: "list", items: [
              "<strong>ISMB / ISLB / ISWB</strong> — I-sections. Medium, light and wide-flange beams. Most of the material is in the flanges, far from the neutral axis, which is exactly what bending wants. Poor in torsion, and weak about the minor axis.",
              "<strong>ISHB</strong> — heavy beam sections, with wider flanges. The wider flange gives a larger ry, so these are the usual choice for <em>columns</em> rather than beams.",
              "<strong>ISMC / ISLC</strong> — channels. Used for purlins, for bracing, and in pairs to make up built-up columns. The shear centre lies outside the section, so a single channel twists when loaded through its web.",
              "<strong>ISA</strong> — angles, equal and unequal. Truss members, bracing, connection cleats. Nearly always connected through one leg, which is why Chapter 5 spends so long on shear lag.",
              "<strong>Tubes and hollow sections</strong> — excellent in compression and in torsion because the material is distributed around the perimeter, and the same radius of gyration in every direction. Harder and more expensive to connect.",
              "<strong>Plates</strong> — for built-up sections, gussets, base plates and plate girders, where no rolled section is deep enough.",
            ]},
            { k: "trap", t: "Never use a section property from memory, and never carry one over from another example. Every worked example in this handbook <strong>states</strong> the properties it uses, because that is what a designer does — opens SP:6(1), reads the row, and writes it down. A wrong Zp or ry propagates silently through an entire design." },
          ],
        },

        {
          n: "1.7",
          title: "What this handbook does next",
          hi: "आगे क्या",
          blocks: [
            { k: "list", items: [
              "<strong>Ch 2</strong> — section classification: whether the plates will stay flat long enough for the section to deliver what the tables promise.",
              "<strong>Ch 3–4</strong> — connections, bolted and welded. Placed early, deliberately: in steel, the connection is usually what governs, and it is impossible to design a tension member sensibly without knowing what the bolt holes will do to it.",
              "<strong>Ch 5</strong> — tension members: the simplest case, and the one where γm0 and γm1 first appear side by side.",
              "<strong>Ch 6</strong> — compression members and the column curve.",
              "<strong>Ch 7–8</strong> — beams: first laterally supported, then the lateral-torsional buckling that governs when they are not.",
              "<strong>Ch 9</strong> — members carrying bending and axial force together.",
              "<strong>Ch 10</strong> — plate girders, where the web is deliberately allowed to buckle and then relied on afterwards.",
              "<strong>Ch 11–12</strong> — column bases, trusses, industrial buildings, gantry girders, and fatigue.",
            ]},
            { k: "p", t: "One thread runs through all of it. In reinforced concrete the designer decides the section and the reinforcement, and the question is how much. In steel the designer selects a section and then spends most of the effort proving it will not buckle, tear, or come apart at the joints — and that is a different kind of work." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "st-2",
      n: 2,
      title: "Section Classification",
      hi: "सेक्शन वर्गीकरण",
      blurb: "Four classes, two ratios, and the reason a section's own catalogue value is sometimes not available to you.",
      mins: 30,
      sections: [

        {
          n: "2.1",
          title: "Why a section has to be classified at all",
          hi: "वर्गीकरण की ज़रूरत क्यों",
          blocks: [
            { k: "p", t: "A steel section is not a solid block. It is an assembly of thin plates welded or rolled together, and each of those plates is in compression over part of the member. A thin plate in compression does not wait to be crushed — it ripples out of plane, and once it has, it stops carrying what it was carrying." },
            { k: "dia", id: "hb-st-local", cap: "The flange outstand and the web each have their own ratio, and either can go first." },
            { k: "p", t: "So before any strength calculation, one question has to be settled: <strong>will the plates stay flat long enough for the section to reach the strength the theory promises?</strong> That is what classification answers, and it is why it comes before everything else." },
            { k: "def", term: "ε (epsilon)", t: "The yield stress ratio, ε = √(250/fy). Every classification limit in Table 2 is a number times ε. It is 1.0 for E250, 0.845 for E350 and 0.781 for E410 — so a higher-grade steel has <em>tighter</em> limits, because a plate that yields at a higher stress reaches local buckling sooner relative to that stress." },
          ],
        },

        {
          n: "2.2",
          title: "The four classes",
          hi: "चार वर्ग",
          blocks: [
            { k: "dia", id: "hb-st-class", cap: "Each class is defined by how far along the moment-rotation curve the section can get before its plates give up." },
            { k: "def", term: "Class 1 — Plastic", t: "Reaches the plastic moment Mp and then goes on rotating at that moment, long enough for a plastic hinge to form and for the structure to redistribute. This is the <strong>only class permitted in plastic analysis</strong> (Cl. 4.5.2)." },
            { k: "def", term: "Class 2 — Compact", t: "Reaches Mp, but local buckling starts soon after, so it cannot rotate much. Fine for elastic design at full plastic moment; not enough rotation capacity for a plastic mechanism." },
            { k: "def", term: "Class 3 — Semi-compact", t: "Reaches the yield moment My — first yield at the extreme fibre — but buckles locally before the section can yield through its depth. Design is limited to the elastic section modulus." },
            { k: "def", term: "Class 4 — Slender", t: "Buckles locally <em>before</em> even reaching My. Design must use an effective reduced section (Cl. 3.7.2), discarding the parts of the plate that will have buckled. Rolled sections are almost never class 4; welded plate girders routinely are, and Chapter 10 makes deliberate use of that." },
            { k: "eq", expr: "Md = βb Zp fy / γm0,   with βb = 1.0 for classes 1 and 2,  βb = Ze/Zp for class 3", where: [
              ["Zp", "plastic section modulus, mm³"],
              ["Ze", "elastic section modulus, mm³"],
            ]},
            { k: "note", t: "That single expression is how classification enters design. It is the same formula for all three usable classes; βb simply switches which section modulus you are allowed to use. Class 4 falls outside it and needs an effective section instead." },
          ],
        },

        {
          n: "2.3",
          title: "The limits, and what they are measuring",
          hi: "सीमाएँ और उनका अर्थ",
          blocks: [
            { k: "p", t: "Table 2 gives the limits for every plate element in every common section. Two of them cover most of what you will do:" },
            { k: "list", items: [
              "<strong>Outstand of a compression flange, b/tf</strong> — for a <em>rolled</em> section: 9.4ε plastic, 10.5ε compact, 15.7ε semi-compact. For a <em>welded</em> section the limits are tighter — 8.4ε, 9.4ε, 13.6ε — because welding leaves larger residual stresses and less favourable ones.",
              "<strong>Web of an I-section in bending, with the neutral axis at mid-depth, d/tw</strong> — 84ε plastic, 105ε compact, 126ε semi-compact.",
            ]},
            { k: "p", t: "The definitions of b and d matter as much as the limits themselves:" },
            { k: "list", items: [
              "<strong>b</strong> for a flange outstand is measured from the face of the web to the tip of the flange — that is, half the flange width for a symmetric I-section, <em>not</em> the whole flange.",
              "<strong>d</strong> for the web is the clear depth between flanges, less the root fillets for a rolled section: d = D − 2(tf + r).",
            ]},
            { k: "trap", t: "Using the full flange width bf instead of the outstand b doubles the ratio and will wrongly classify almost every rolled beam as slender. Forgetting the root radius r in the web depth goes the other way and makes a web look better than it is. Both are copying errors rather than understanding errors, and both are common." },
            { k: "note", t: "Table 2 also covers webs where the neutral axis is <em>not</em> at mid-depth — which happens whenever axial load is present, as in Chapter 9. The limits then depend on the fraction of the web in compression, and the more of it is compressed the tighter they become. The same web can be compact in pure bending and semi-compact under bending plus axial compression." },
          ],
        },

        {
          n: "2.4",
          title: "Classifying a section",
          hi: "एक सेक्शन का वर्गीकरण",
          blocks: [
            { k: "steps", items: [
              "Read the section's dimensions from IS 808 / SP:6(1): D, bf, tf, tw and the root radius r.",
              "Compute ε = √(250/fy) for the grade in use.",
              "Flange: b = bf/2, then compare b/tf with 9.4ε, 10.5ε and 15.7ε.",
              "Web: d = D − 2(tf + r), then compare d/tw with 84ε, 105ε and 126ε.",
              "The section takes the <strong>worse</strong> of the two classifications.",
            ]},
            { k: "eg",
              title: "Example 2.1 — Classify an ISMB 400",
              given: "ISMB 400 in E250 steel (fy = 250 N/mm²). From the section tables: D = 400 mm, bf = 140 mm, tf = 16.0 mm, tw = 8.9 mm, root radius r = 14 mm.",
              steps: [
                { t: "Yield stress ratio", w: "ε = √(250/fy) = √(250/250) = 1.0" },
                { t: "Flange outstand", w: "b = bf/2 = 140/2 = 70 mm\nb/tf = 70/16.0 = 4.38\nLimit for plastic = 9.4ε = 9.4\n4.38  <  9.4  →  flange is PLASTIC" },
                { t: "Web", w: "d = D − 2(tf + r) = 400 − 2(16 + 14) = 340 mm\nd/tw = 340/8.9 = 38.2\nLimit for plastic = 84ε = 84\n38.2  <  84  →  web is PLASTIC" },
                { t: "Classification", w: "Both elements are plastic → the section is CLASS 1 (PLASTIC)\nSo βb = 1.0 and the full Zp may be used, and the section is eligible for plastic analysis." },
              ],
              ans: "ISMB 400 in E250 is a plastic (Class 1) section, with a large margin on both ratios.",
            },
            { k: "p", t: "That margin is typical. Indian rolled beams in E250 are almost all plastic — they were proportioned in an era of working stress design, when nobody was trying to make them as thin as possible. Classification becomes a real constraint in three situations: <strong>higher-grade steel</strong> (ε falls), <strong>welded built-up sections</strong> (tighter limits, and the designer chooses the plate thickness), and <strong>webs under bending plus axial load</strong>." },
            { k: "eg",
              title: "Example 2.2 — The same section in E410",
              given: "The same ISMB 400 dimensions, but in E410 steel (fy = 410 N/mm²).",
              steps: [
                { t: "Yield stress ratio", w: "ε = √(250/410) = √0.6098 = 0.781" },
                { t: "Flange", w: "b/tf = 4.38 against a plastic limit of 9.4 × 0.781 = 7.34\n4.38  <  7.34  →  still plastic" },
                { t: "Web", w: "d/tw = 38.2 against a plastic limit of 84 × 0.781 = 65.6\n38.2  <  65.6  →  still plastic" },
              ],
              ans: "Still Class 1 — but every limit has tightened by 22%. For a deeper, thinner-webbed section the same change of grade can move a web from plastic to semi-compact, and with it the available moment capacity from Zp fy to Ze fy.",
            },
          ],
        },

        {
          n: "2.5",
          title: "Zp, Ze and the shape factor",
          hi: "Zp, Ze और आकार गुणक",
          blocks: [
            { k: "p", t: "Classification decides which section modulus you may use, so it is worth being precise about what the two of them mean." },
            { k: "dia", id: "hb-st-zpze", cap: "The same section, two questions: when does the first fibre yield, and how much can it take once they all have?" },
            { k: "eq", expr: "Ze = I / ymax        Zp = (A/2) × (ȳ1 + ȳ2)", where: [
              ["I", "second moment of area about the bending axis"],
              ["ymax", "distance to the extreme fibre"],
              ["ȳ1, ȳ2", "distances from the equal-area axis to the centroids of the two half-areas"],
            ]},
            { k: "p", t: "Ze comes from elastic bending, where stress varies linearly and only the extreme fibre has reached fy. Zp comes from the fully plastic condition, where every fibre has yielded — compression above the equal-area axis, tension below it — so the section is carrying two rectangular stress blocks and the moment is simply force times lever arm." },
            { k: "def", term: "Shape factor", t: "The ratio Zp/Ze — how much more moment the section can take between first yield and full plasticity. It depends only on the <em>shape</em>: about 1.5 for a rectangle, 1.7 for a solid circle, and only about 1.12 to 1.15 for a rolled I-section." },
            { k: "p", t: "The I-section's low shape factor is not a weakness — it is the point of the shape. An I-section already has nearly all its material at the extreme fibres, so when the extreme fibre yields, most of the section is close behind it. There is not much left to gain. A rectangle, by contrast, has half its material near the neutral axis doing almost nothing elastically, which is why it gains 50%." },
            { k: "note", t: "For a plastic or compact section, using Ze instead of Zp throws away 12 to 15% of the capacity. That is not catastrophic but it is real, and it is a common slip when moving between IS 800 (which uses Zp) and older working-stress practice (which used Ze). Cl. 8.2.1.2 also caps Md at 1.2 Ze fy/γm0 for a simply supported member, which prevents excessive deformation at service load — so the two moduli appear together in the same check." },
          ],
        },

        {
          n: "2.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Classify the section before designing it — the class decides which section modulus is available.",
              "ε = √(250/fy); every Table 2 limit is a multiple of it, and higher grades have tighter limits.",
              "Flange outstand b = bf/2; web depth d = D − 2(tf + r).",
              "Rolled flange limits 9.4ε / 10.5ε / 15.7ε; web-in-bending limits 84ε / 105ε / 126ε. Welded sections are tighter.",
              "The section takes the worse of its elements' classifications.",
              "Md = βb Zp fy/γm0, with βb = 1 for classes 1 and 2 and Ze/Zp for class 3.",
              "Only Class 1 may be used in plastic analysis.",
            ]},
            { k: "p", t: "Chapter 3 leaves the members and goes to the joints. It comes this early because in steel design the connection is usually what governs, and because you cannot sensibly design a tension member — Chapter 5 — without first knowing what the bolt holes are going to do to it." },
          ],
        },
      ],
    },

  ],
});
