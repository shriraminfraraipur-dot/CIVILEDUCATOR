/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: ESTIMATION & COSTING
   ------------------------------------------------------------
   The tenth handbook, and the most practical of all: this is the
   subject a working engineer uses every single day. It answers
   one question — what will this cost? — and it does it the same
   way every time: measure the quantity of each item, multiply by
   its rate, and add up.

   One idea runs through every chapter: cost = quantity × rate.
   The measuring chapters get the quantity right; the rate-analysis
   chapter gets the rate right; and accuracy comes from method and
   care, not cleverness.

   Measurement practice follows IS 1200 (methods of measurement)
   and IS 2502 (bar bending) where they govern, named at the point
   of use. Confirm against the current code and the project's own
   specification before using a value on real work.

   Chapters 1–3 here; later chapters follow in data-hb-es2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "es",
  subject: "estimation",
  name: "Estimation & Costing",
  hi: "आकलन एवं लागत",
  icon: "📊",
  blurb: "Cost = quantity × rate — har item naapo, rate lagao, jodo. Quantity takeoff, bar bending schedule, rate analysis aur valuation, step-by-step.",
  note: "Measurement rules follow IS 1200 and IS 2502 where they apply; unit rates in worked examples are illustrative assumptions, not published rates. Always confirm methods against the current code and rates against the project's own schedule.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "es-1",
      n: 1,
      title: "What an Estimate Is For",
      hi: "आकलन किसलिए",
      blurb: "The one equation the whole subject rests on, the kinds of estimate and when each is used, and why an estimate is a decision tool, not just a number.",
      mins: 22,
      sections: [
        {
          n: "1.1",
          title: "Cost = quantity × rate",
          hi: "लागत = मात्रा × दर",
          blocks: [
            { k: "p", t: "Estimating has a reputation for being tedious, but its idea is simple and never changes. The cost of a piece of work is the quantity of each item multiplied by the rate for that item, summed over every item in the job. Everything in this handbook is detail on those two numbers: how to measure the quantity accurately, and how to build up the rate honestly." },
            { k: "dia", id: "hb-es-cost", cap: "The whole subject in one equation." },
            { k: "p", t: "That is why estimating is the most-used subject a site engineer has. Before anything is built, someone must say what it will cost — to decide whether to build it, to arrange the money, to invite tenders, to check a contractor's bill. All of it comes back to measuring quantities and applying rates." },
            { k: "note", t: "Keep the two halves clear as you read. Chapters 2 to 7 are about the quantity — measuring each kind of work accurately and consistently. Chapter 8 is about the rate — what one unit of finished work actually costs. Neither is useful without the other: a perfect quantity at a wrong rate, or a right rate on a wrong quantity, both give a wrong cost." },
          ],
        },
        {
          n: "1.2",
          title: "The kinds of estimate",
          hi: "आकलन के प्रकार",
          blocks: [
            { k: "p", t: "Not every estimate needs the same precision. Early on you need a quick figure to decide whether a project is worth pursuing; later you need an exact one to build and pay from. The type of estimate matches the decision it serves." },
            { k: "cmp", t: "Rough versus detailed",
              cols: ["Approximate (preliminary)", "Detailed estimate"],
              rows: [
                ["How", "per unit (per m², per bed, per km)", "every item measured off drawings"],
                ["Accuracy", "rough — for a go/no-go decision", "exact — to build and pay from"],
                ["When", "before design, for feasibility", "after design, for execution"],
                ["Effort", "minutes", "days"],
              ] },
            { k: "list", items: [
              "<strong>Plinth-area estimate</strong> — built-up area × a rate per m². The commonest quick estimate for a building.",
              "<strong>Detailed estimate</strong> — every item of work measured and rated; the basis for tendering and payment.",
              "<strong>Revised estimate</strong> — a fresh detailed estimate when the original is exceeded or the scope changes.",
              "<strong>Supplementary estimate</strong> — for additional work added to a running project.",
            ] },
            { k: "real", t: "A client asking 'roughly what will my house cost?' at the sketch stage wants a plinth-area estimate — built-up area times a per-square-metre rate — in minutes, not a week's detailed takeoff. Giving them a detailed estimate they didn't ask for wastes days; giving a detailed job a plinth-area estimate to build from invites disaster. <strong>Match the estimate to the decision it has to support.</strong>" },
            { k: "eg", title: "Example 1.1 — A plinth-area estimate, both ways round",
              given: "A recently completed building of similar specification, with a plinth area of 84 m², cost ₹5,00,000. A new building of the same kind is planned with a plinth area of 120 m².",
              steps: [
                { t: "Plinth-area rate from the completed building", w: "5,00,000/84 = ₹5,952 per m²" },
                { t: "Estimate for the new building", w: "120 × 5,952 = ₹7,14,240 — say ₹7.15 lakh" },
              ],
              ans: "About ₹7.15 lakh at the old price level. The rate carries everything that differs between the two buildings — specification, site, date — so it must be adjusted for price rise and for any difference in specification before it is used. (Rate figure from the RCET valuation notes; the numbers are illustrative of method, not current prices.)" },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "es-2",
      n: 2,
      title: "Units and Modes of Measurement",
      hi: "इकाई और मापन विधि",
      blurb: "Why each kind of work is measured in the unit it is, the standard modes of measurement, and the deductions that separate a careful takeoff from a sloppy one.",
      mins: 30,
      sections: [
        {
          n: "2.1",
          title: "Each item, its own unit",
          hi: "हर काम की अपनी इकाई",
          blocks: [
            { k: "p", t: "Every kind of work is measured in the unit that reflects how it consumes material and labour. It is not arbitrary: concrete and earthwork vary with volume, so they are measured in cubic metres; plaster and painting cover a surface, so they go in square metres; a bar or a pipe is priced by its length; doors and fittings by number." },
            { k: "cmp", t: "The unit follows the work",
              cols: ["Measured in", "Because"],
              rows: [
                ["Earthwork, concrete", "cubic metre (m³)", "cost varies with volume"],
                ["Plaster, painting, flooring", "square metre (m²)", "cost varies with area"],
                ["Reinforcement, pipes", "length (m) → mass (kg/quintal)", "priced by run, then weight"],
                ["Doors, windows, fittings", "number (each)", "counted units"],
              ] },
            { k: "note", t: "Reinforcement is the one that trips people: it is measured by length on the drawing (each bar's cutting length), but paid for by weight (kilograms or quintals), because steel is bought and sold by weight. So a bar schedule always converts length to mass through the d²/162 rule — the bridge between how it is drawn and how it is paid." },
          ],
        },
        {
          n: "2.2",
          title: "Modes of measurement and deductions",
          hi: "मापन विधि और कटौती",
          blocks: [
            { k: "p", t: "So that every estimator measures the same work the same way, IS 1200 lays down standard modes of measurement — what to include, what to deduct, and to what accuracy. Consistency is the point: a quantity is only meaningful if everyone measures it by the same rules." },
            { k: "def", term: "Deductions", t: "Openings and voids that must be subtracted — a door reduces the brickwork and the plaster around it; a beam displaces the slab concrete. The mode of measurement says which deductions to make and, importantly, which small ones to ignore (deducting a tiny opening costs more effort than it saves, so the code sets thresholds below which you don't bother)." },
            { k: "trap", t: "The two opposite errors are both common: forgetting to deduct large openings (over-measuring the brickwork and plaster, so the estimate is too high), and fussing over tiny deductions the code says to ignore (wasting hours for pennies). The mode of measurement exists precisely to settle both — it tells you what to deduct and what to leave, so different estimators reach the same figure." },
            { k: "real", t: "A plastered wall with a large window: you measure the whole wall area, then deduct the window opening — but the code may say to measure plaster on both faces and deduct the opening once, or apply a rule for the reveals. Knowing the mode is what makes two estimators, measuring the same wall, arrive at the same number. <strong>Estimating disputes are almost always about mode of measurement, not arithmetic.</strong>" },
            { k: "cmp", t: "Key IS 1200 rules for walls", cols: ["Rule"], rows: [
              ["Precision", "dimensions to the nearest 0.01 m, areas to 0.01 m², volumes to 0.01 m³"],
              ["Brickwork — no deduction", "openings up to 0.1 m²; ends of dissimilar materials up to 0.1 m² in section; pipes up to 300 mm diameter; chases up to 50 cm girth"],
              ["Plaster — opening ≤ 0.5 m²", "no deduction, and nothing added for jambs, soffits or sills"],
              ["Plaster — opening 0.5–3 m²", "same plaster both faces: deduct one face only; jambs etc. not added"],
              ["Plaster — opening > 3 m²", "deduct on each face, and measure jambs, soffits and sills separately"],
            ]},
            { k: "note", t: "Brickwork rules from <a href=\"https://law.resource.org/pub/in/bis/S03/is.1200.3.1976.pdf\" target=\"_blank\" rel=\"noopener\">IS 1200 (Part 3):1976</a> (Cl. 2.3, 4.1.4) and plaster rules from <a href=\"https://dn710709.ca.archive.org/0/items/gov.in.is.1200.12.1976/is.1200.12.1976.txt\" target=\"_blank\" rel=\"noopener\">IS 1200 (Part 12):1976</a> (Cl. 2.4, 3.8), both via public copies of the 1976 texts; <a href=\"https://www.studiomatrx.org/students/estimation-specification/methods-of-measurement\" target=\"_blank\" rel=\"noopener\">StudioMatrx</a> summarises the same thresholds. The 1976 plaster clause also has special cases (different finishes on the two faces, frames flush with one face) — read the clause for those." },
            { k: "eg", title: "Example 2.1 — Plaster on a wall with four openings",
              given: "A wall 5.0 m long and 3.0 m high, 230 mm thick, plastered alike on both faces. Openings: door 1.0 × 2.1 m, window 1.2 × 1.0 m, ventilator 0.6 × 0.45 m, and an archway 2.0 × 2.0 m (no frame).",
              steps: [
                { t: "Gross area, both faces", w: "2 × 5.0 × 3.0 = 30.00 m²" },
                { t: "Classify each opening", w: "ventilator 0.27 m² (≤ 0.5): no deduction\ndoor 2.10 m² and window 1.20 m² (0.5–3): deduct ONE face → 3.30 m²\narchway 4.00 m² (> 3): deduct BOTH faces → 8.00 m²" },
                { t: "Add the archway's reveals", w: "two jambs 2 × 2.0 × 0.23 + soffit 2.0 × 0.23 + sill 2.0 × 0.23 = 1.84 m²" },
                { t: "Net plaster", w: "30.00 − 3.30 − 8.00 + 1.84 = 20.54 m²" },
              ],
              ans: "20.54 m². Deducting every opening on both faces would have given 30.00 − 2 × 7.57 = 14.86 m² — 28% low; deducting none, 30 m² — 46% high. The thresholds exist because finishing the reveals of a small opening takes about as much work as the plaster saved." },
          ],
        },
      ],
    },

    /* ============================================================ CH 3 */
    {
      id: "es-3",
      n: 3,
      title: "Taking Out Quantities — the Two Methods",
      hi: "मात्रा निकालना — दो विधियाँ",
      blurb: "The centre-line and long-wall/short-wall methods for measuring a building, why they must agree, and the worked takeoff that shows they do.",
      mins: 28,
      sections: [
        {
          n: "3.1",
          title: "Centre-line and long-wall/short-wall",
          hi: "सेंटर-लाइन और लंबी-छोटी दीवार",
          blocks: [
            { k: "p", t: "The heart of a building takeoff is getting the wall (and foundation) lengths right, and there are two standard methods. They look different but must give the same answer — which makes each a check on the other." },
            { k: "dia", id: "hb-es-centreline", cap: "The centre-line and long-wall/short-wall methods." },
            { k: "def", term: "Centre-line method", t: "Measure the total length once, running along the centre of all the walls, then multiply by thickness and height for the quantity. For a simple rectangular building the centre-line length is just the perimeter measured through the wall centres. Fast, and it handles the corners automatically — but at junctions of walls it needs a correction." },
            { k: "def", term: "Junction correction", t: "Where a cross wall meets a main wall (a T-junction), the centre-line of the cross wall runs into the main wall by half its thickness, so half a breadth is deducted from the total length for each T-junction, for each layer (footing, plinth, wall) at that layer's breadth. A cross-junction (+) needs one full breadth. Corners of a plain rectangle need no correction. (Same rule in <a href=\"https://www.studiomatrx.org/students/estimation-specification/methods-of-measurement\" target=\"_blank\" rel=\"noopener\">StudioMatrx</a>.)" },
            { k: "def", term: "Long-wall / short-wall method", t: "Measure the long walls out-to-out and the short walls in-to-in (or vice versa), so the corner overlaps are counted exactly once. More steps, but transparent — you can see each wall — and it is the traditional cross-check on the centre-line figure." },
          ],
        },
        {
          n: "3.2",
          title: "A worked takeoff — and the built-in check",
          hi: "एक हल किया गया takeoff",
          blocks: [
            { k: "p", t: "The two methods agreeing is not a coincidence — it is arithmetic — and using both is the cheapest error-check in estimating." },
            { k: "eg", title: "Example 3.1 — Brickwork of a room, both ways",
              given: "A room measures 4.0 m × 3.0 m internally. The walls are 0.30 m thick and 3.0 m high. Find the brickwork volume by the centre-line method and check it by long-wall/short-wall. (Ignore openings.)",
              steps: [
                { t: "Centre-line dimensions", w: "add the wall thickness to each internal dim:\ncentre-line = (4.0+0.3) × (3.0+0.3) = 4.3 × 3.3" },
                { t: "Centre-line length", w: "= 2 × (4.3 + 3.3) = 2 × 7.6 = 15.2 m" },
                { t: "Brickwork volume", w: "= 15.2 × 0.30 × 3.0 = 13.68 m³" },
                { t: "Check by long-wall / short-wall", w: "long walls out-to-out: 2 × 4.6 × 0.3 × 3.0 = 8.28\nshort walls in-to-in: 2 × 3.0 × 0.3 × 3.0 = 5.40\ntotal = 8.28 + 5.40 = 13.68 m³" },
              ],
              ans: "13.68 m³ by both methods — they agree exactly, confirming the takeoff. This agreement is the point: whenever the two methods differ, there is an arithmetic slip to find, and doing both is far cheaper than discovering the error after the concrete is poured." },
            { k: "eg", title: "Example 3.2 — Two rooms and a cross wall",
              given: "Two rooms side by side, 4.0 × 3.0 m and 3.0 × 3.0 m internally, separated by a cross wall. All walls 0.30 m thick, 3.0 m high. Ignore openings.",
              steps: [
                { t: "Outer centre-line rectangle", w: "internal overall length = 4.0 + 0.3 + 3.0 = 7.3 m; width 3.0 m\ncentre-line dims = 7.6 × 3.3 → perimeter 2(7.6 + 3.3) = 21.8 m" },
                { t: "Cross wall, with two T-junction corrections", w: "centre-line length 3.3 m − 2 × 0.15 = 3.0 m" },
                { t: "Volume", w: "(21.8 + 3.0) × 0.30 × 3.0 = 24.8 × 0.9 = 22.32 m³" },
                { t: "Check — long walls out-to-out, short walls in-to-in", w: "long: 2 × 7.9 = 15.8 m;  short: 3 × 3.0 = 9.0 m\n(15.8 + 9.0) × 0.30 × 3.0 = 22.32 m³  ✓" },
              ],
              ans: "22.32 m³ by both methods. Without the junction correction the centre-line method would give (21.8 + 3.3) × 0.9 = 22.59 m³ — 0.27 m³ too much, the classic over-measurement, and it grows at every junction and with every wider layer below." },
            { k: "note", t: "Openings (doors, windows) are deducted next, and the same brickwork quantity feeds straight into the mortar and material estimate from the Building Construction handbook (500 bricks and about 1.2 bags of cement per cubic metre). The quantity you measure here is the input to every cost that follows — which is why getting it right, and checking it, matters so much." },
          ],
        },
      ],
    },

  ],
});
