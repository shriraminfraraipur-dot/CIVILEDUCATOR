/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: CONCRETE TECHNOLOGY
   ------------------------------------------------------------
   The seventh handbook. Where the RCC handbook designs concrete
   members, this one is about the material itself — how concrete
   is made, tested and controlled, from the water-cement ratio to
   the cube test.

   One idea runs through every chapter: concrete is only as good
   as the weakest step in making it. A perfect mix, badly
   compacted or badly cured, gives weak concrete — so the craft
   is getting every step right, not just the recipe.

   Values follow IS 456, IS 10262 and IS 516 where they govern,
   named at the point of use. Confirm against the current code
   before using a value on real work.

   Chapters 1–2 here; later chapters follow in data-hb-ct2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "ct",
  subject: "concrete-tech",
  name: "Concrete Technology",
  hi: "कंक्रीट प्रौद्योगिकी",
  icon: "🧊",
  blurb: "Cement aur pani se lekar cube test tak — kaise banti hai, kaise test hoti hai, aur ek achhe mix ko site par kya cheez kamzor kar deti hai.",
  note: "Test methods and limits follow IS 456, IS 10262 and IS 516, named where they apply. They are quoted for learning; confirm against the current code before using a value on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "ct-1",
      n: 1,
      title: "What Concrete Is, and the One Ratio That Rules It",
      hi: "कंक्रीट क्या है और वह एक अनुपात",
      blurb: "Concrete as a made material, why every step matters, and the water-cement ratio — the single number that decides strength more than any other.",
      mins: 32,
      sections: [
        {
          n: "1.1",
          title: "A material you manufacture on site",
          hi: "साइट पर बनने वाली सामग्री",
          blocks: [
            { k: "p", t: "Steel arrives certified; concrete does not. Concrete is manufactured at the moment of placing, from four ingredients — cement, water, fine and coarse aggregate — that a labourer proportions, mixes, places and compacts. Every one of those steps can spoil it. So concrete technology is less about a recipe and more about control: getting each step right, every time, on a real site." },
            { k: "def", term: "Concrete", t: "A composite of aggregate bound by a cement paste. The aggregate (about three-quarters by volume) gives bulk and strength in compression; the cement paste glues it and fills the gaps; water drives the hydration that hardens the paste." },
            { k: "p", t: "Its great virtue is that it is strong in compression, mouldable to any shape, durable, fire-resistant and made from cheap local materials. Its great weakness is that it is weak in tension (which is why we add steel) and utterly dependent on how it was made. The same mix can give M25 or M15 depending on the water added and the compaction done." },
            { k: "note", t: "Keep this handbook and the RCC handbook separate in your mind: RCC is about designing members — beams, columns, slabs — from concrete and steel. This one is about the concrete itself: making it, testing it, controlling it. One is the recipe and kitchen; the other is the architecture." },
          ],
        },
        {
          n: "1.2",
          title: "The water-cement ratio",
          hi: "जल-सीमेंट अनुपात",
          blocks: [
            { k: "p", t: "If you learn one thing about concrete, learn this. The ratio of water to cement, by weight, decides strength more than the cement grade, the brand or almost anything else. It is the master variable." },
            { k: "dia", id: "hb-ct-wc", cap: "Strength against water-cement ratio, and why the curve falls." },
            { k: "def", term: "Water-cement ratio", t: "The weight of mixing water divided by the weight of cement. Only about 23% of the cement's weight is chemically combined during hydration; more is held physically in the gel pores, so a paste needs a w/c of roughly 0.38 before it can hydrate without leaving capillary voids. Water added beyond what the paste can use is there for workability — and evaporates later, leaving voids." },
            { k: "note", t: "<b>Correction (v38):</b> an earlier version said cement needs ‘about 0.25 of its own weight in water to hydrate fully’. That is roughly the chemically bound water only. The <a href=\"https://faculty.kfupm.edu.sa/ce/sud/Teaching/CE%20401-112/CE-401-LEC-%209.pdf\" target=\"_blank\" rel=\"noopener\">KFUPM CE 401 lecture</a> gives non-evaporable water ≈ 23% of the hydrated cement, w/c ≈ 0.38 for a paste with no capillary pores, and quotes about 0.46–0.50 as the minimum for full hydration in its own model — published figures differ with curing conditions, but every one of them is well above 0.25." },
            { k: "def", term: "Abrams' law", t: "Stated by Duff Abrams in 1918: for given materials and a fully compacted, workable mix, strength depends only on the water-cement ratio — S = A/B<sup>x</sup>, where x is the w/c and A, B are empirical constants for those materials. The more water, the weaker the concrete." },
            { k: "trap", t: "Adding water on site to make stiff concrete 'flow' better is the most common and most damaging thing a labourer does. It buys a few minutes of easier placing and permanently costs a grade of strength. The right answer to stiff concrete is a plasticiser or better grading — never more water." },
            { k: "real", t: "This is why the whole rest of concrete technology exists. Every admixture, every grading rule, every compaction technique is there to let you place a stiff, low-water mix that would otherwise be too hard to work. <strong>The industry spends its ingenuity on avoiding that extra bucket of water.</strong>" },
            { k: "h", t: "Why w/c matters so much: the gel/space ratio" },
            { k: "p", t: "Powers explained Abrams' law physically. Strength depends on how much of the available space in the paste is filled by hydration product (gel). With C grams of cement, W₀ grams of water and a degree of hydration α:" },
            { k: "eq", expr: "gel/space ratio  x = 0.657 C α / (0.319 C α + W₀)        theoretical strength ≈ 240 x³  N/mm²", where: [
              ["α", "fraction of the cement that has hydrated (1 = complete)"],
              ["240", "intrinsic strength of the gel, N/mm²"],
            ]},
            { k: "eg", title: "Example 1.1 — What extra water costs, by Powers' model",
              given: "Compare a paste at w/c 0.45 with one at w/c 0.60, both 70% hydrated; also find the ceiling for w/c 0.45 at full hydration. (Formula as given in the ACE Engineering College notes.)",
              steps: [
                { t: "w/c 0.45, α = 0.7 (per gram of cement)", w: "x = 0.657 × 0.7/(0.319 × 0.7 + 0.45) = 0.460/0.673 = 0.683\nstrength ≈ 240 × 0.683³ = 76.5 N/mm²" },
                { t: "w/c 0.60, α = 0.7", w: "x = 0.460/(0.223 + 0.60) = 0.559\nstrength ≈ 240 × 0.559³ = 41.8 N/mm²" },
                { t: "w/c 0.45, α = 1.0", w: "x = 0.657/(0.319 + 0.45) = 0.854 → 240 × 0.854³ ≈ 150 N/mm²" },
              ],
              ans: "Raising w/c from 0.45 to 0.60 cuts the paste's strength by about 45%. These are paste strengths, far above concrete cube results, but the ratio is the lesson: because strength goes as x³, small changes in water make large changes in strength." },
            { k: "note", t: "Equations and the w/c 0.45 full-hydration value (x = 0.854, ≈ 149.5 N/mm²) are from the <a href=\"https://www.aceec.ac.in/wp-content/uploads/2025/07/Unit-3.pdf\" target=\"_blank\" rel=\"noopener\">ACE Engineering College notes</a>; the 0.7-hydration comparison is computed here. The model explains the trend; mix design still uses measured strength–w/c relationships for the actual materials." },
          ],
        },
        {
          n: "1.3",
          title: "The chain of steps, and its weakest link",
          hi: "चरणों की श्रृंखला",
          blocks: [
            { k: "p", t: "Concrete passes through a chain of operations, and its final strength is set by the worst of them, not the average. It is worth seeing the whole chain once so you know where strength is won and lost." },
            { k: "steps", items: [
              "<strong>Proportioning</strong> — fixing the mix (w/c, cement, aggregate). Sets the potential strength.",
              "<strong>Batching & mixing</strong> — measuring and combining. Weigh-batching beats volume-batching because sand bulks with moisture.",
              "<strong>Placing</strong> — getting it into the formwork without segregating (the coarse aggregate separating from the paste).",
              "<strong>Compaction</strong> — driving out trapped air. The step most often skimped, and the one that most often wrecks a good mix.",
              "<strong>Curing</strong> — keeping it wet so hydration continues. Strength keeps climbing for weeks only if the water stays.",
            ] },
            { k: "trap", t: "Notice that four of the five steps happen after the mix is designed. A designer can specify M30, but a site that under-compacts and under-cures will hand back M20. Concrete is the one structural material whose quality is decided mostly by labour, not by the drawing." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "ct-2",
      n: 2,
      title: "Cement for Concrete",
      hi: "कंक्रीट के लिए सीमेंट",
      blurb: "The types of cement you actually choose between, what the grade number means, the tests that matter for concrete, and why storage is a real risk.",
      mins: 28,
      sections: [
        {
          n: "2.1",
          title: "Which cement, and why",
          hi: "कौन-सा सीमेंट",
          blocks: [
            { k: "p", t: "For most work the choice is between ordinary Portland cement (OPC) in its grades, and blended cements (PPC, PSC) that mix in fly ash or slag. Each is Portland cement adjusted for a purpose — the same idea as the special cements in the Building Materials handbook." },
            { k: "cmp", t: "The everyday choices",
              cols: ["OPC 43 / 53", "Blended (PPC / PSC)"],
              rows: [
                ["Early strength", "faster, higher", "slower early, catches up"],
                ["Heat of hydration", "higher", "lower — better for big pours"],
                ["Durability", "good", "denser, less permeable — often better"],
                ["Where it wins", "precast, fast schedules", "mass concrete, aggressive exposure"],
              ] },
            { k: "def", term: "Grade of cement (33 / 43 / 53)", t: "The minimum 28-day compressive strength of a standard cement-sand mortar cube in N/mm² — not a mix proportion and not a quality rank. A 53-grade gains strength faster and hotter; for ordinary work a 43-grade is often the better balance. Since 2015 all three OPC grades are covered by one standard, IS 269:2015." },
            { k: "trap", t: "A higher grade of cement does not simply mean better concrete. 53-grade releases more heat and can crack thick sections, and its early strength tempts under-curing. Match the cement to the job — the grade is a property to choose, not a score to maximise." },
          ],
        },
        {
          n: "2.2",
          title: "The tests that matter for concrete",
          hi: "ज़रूरी परीक्षण",
          blocks: [
            { k: "p", t: "The Building Materials handbook lists the full cement test set; here we single out the ones that change what happens in your concrete." },
            { k: "list", items: [
              "<strong>Fineness</strong> — finer cement hydrates faster: more early strength, but also more heat and more shrinkage. It is a lever, not simply 'more is better'.",
              "<strong>Setting time</strong> — initial set (≥ 30 min) is your working window; miss it and disturbing the concrete breaks the bonds forming inside.",
              "<strong>Soundness</strong> — guards against late expansion from free lime or magnesia, which would crack hardened concrete from within.",
              "<strong>Compressive strength</strong> — the real grade check, at 3, 7 and 28 days. 7-day strength is a useful early predictor of the 28-day result.",
            ] },
            { k: "cmp", t: "IS 269:2015 — key requirements for OPC", cols: ["OPC 33", "OPC 43", "OPC 53"], rows: [
              ["Fineness, min (m²/kg)", "225", "225", "225"],
              ["Initial / final setting (min)", "≥ 30 / ≤ 600", "≥ 30 / ≤ 600", "≥ 30 / ≤ 600"],
              ["Soundness — Le Chatelier / autoclave", "≤ 10 mm / ≤ 0.8%", "≤ 10 mm / ≤ 0.8%", "≤ 10 mm / ≤ 0.8%"],
              ["Strength at 3 days, min (N/mm²)", "16", "23", "27"],
              ["Strength at 7 days, min", "22", "33", "37"],
              ["Strength at 28 days, min / max", "33 / 48", "43 / 58", "53 / —"],
            ]},
            { k: "note", t: "Values as reproduced in <a href=\"https://starcement.co.in/pdf/Pamphlet%20on%20Requirements%20of%20Ordinary%20Portland%20Cement%20as%20per%20IS%20269-2015.pdf\" target=\"_blank\" rel=\"noopener\">a manufacturer's pamphlet reproducing IS 269:2015</a>; the same standard also covers the special grades 43-S and 53-S (fineness ≥ 370 m²/kg, initial set ≥ 60 min, Le Chatelier ≤ 5 mm) and limits MgO (6%), SO₃ (3.5%), loss on ignition (5%), insoluble residue (5%) and chloride (0.1%). The <em>maximum</em> 28-day strength on 33 and 43 grade is easy to miss: a ‘43’ cement testing at 60 N/mm² does not comply." },
            { k: "eg", title: "Example 2.1 — Does this cement comply?",
              given: "Test certificate for a cement sold as OPC 43: fineness 310 m²/kg; initial set 25 min, final 240 min; Le Chatelier expansion 4 mm; mortar cube strength 3 days 25, 7 days 36, 28 days 52 N/mm².",
              steps: [
                { t: "Fineness", w: "310 ≥ 225  ✓" },
                { t: "Setting", w: "initial 25 < 30 min  ✗ — fails\nfinal 240 ≤ 600  ✓" },
                { t: "Soundness", w: "4 ≤ 10 mm  ✓" },
                { t: "Strength", w: "3 d 25 ≥ 23 ✓;  7 d 36 ≥ 33 ✓;  28 d 52 within 43–58 ✓" },
              ],
              ans: "Rejected on initial setting time. Everything else passes — but a 25-minute working window is the one property a site cannot compensate for, which is why the limit exists." },
            { k: "note", t: "The 7-day / 28-day habit is worth carrying to site. Concrete gains most of its strength in the first weeks and is customarily judged at 28 days. A 7-day cube gives an early warning — if it is well below the expected fraction of the grade, something in the mix or curing is already wrong, and you have three more weeks to find out why." },
          ],
        },
        {
          n: "2.3",
          title: "Storage — the quiet way cement is lost",
          hi: "भंडारण",
          blocks: [
            { k: "p", t: "Cement's enemy is moisture, and it does not need liquid water — humidity alone will do it. Cement that has picked up moisture partly hydrates in the bag ('air-set'), forms lumps, and loses strength before it is ever mixed. On a monsoon site this is a real and common loss." },
            { k: "list", items: [
              "Store bags off the floor on a raised platform and clear of walls, so damp cannot wick in.",
              "Stack no more than 10 bags high, on a platform at least 150 mm above the ground; keep a stack no wider than about 3 m (four bag lengths), and above 8 bags lay the bags alternately lengthwise and crosswise (<a href=\"https://www.jkcement.com/blog/construction-planning/how-to-store-cement-on-site/\" target=\"_blank\" rel=\"noopener\">JK Cement</a>). Keep the stack covered.",
              "Use oldest stock first — cement deteriorates with storage time even when kept dry.",
              "Reject any bag with hard lumps that will not crush to powder between the fingers: it has already set in part.",
            ] },
            { k: "real", t: "A site that stacks cement on a bare floor against an outer wall through a wet season can lose a noticeable fraction of its strength before a single cube is cast — and then blames the mix. <strong>Storage is not housekeeping; it is strength you either keep or throw away.</strong>" },
          ],
        },
      ],
    },

  ],
});
