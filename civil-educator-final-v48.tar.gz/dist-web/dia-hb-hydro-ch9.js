/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for the Hydrology handbook, Chapter 9
   (Floods, Flood Frequency Analysis & Flood Routing).
   ------------------------------------------------------------
   Same conventions as the other handbooks' diagram files: strokes
   are currentColor so both themes work, meaning-carrying strokes
   use .hi (marker) or .ac (accent), and every figure gets its own
   marker id prefix so two figures on one page never collide.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function h9mk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 9.5  FLOOD ROUTING: ATTENUATION & LAG */
  "hb-hydro-routing": {
    label: "Inflow vs outflow hydrograph through a reservoir/channel reach — attenuation and lag",
    svg: `<svg viewBox="0 0 680 340" role="img" aria-label="Discharge versus time graph showing two overlapping hydrographs. The inflow hydrograph rises early to a tall, sharp peak labelled Ip. The outflow hydrograph, shown as a flatter, lower curve, peaks later at a lower value labelled Qp. The gap between the peak heights is bracketed on the left and labelled attenuation. The gap between the two peak times is bracketed below the time axis and labelled lag. The region between the two curves is shaded and labelled storage, the volume temporarily held in the reservoir or channel reach.">
      ${h9mk("rt")}

      <!-- axes -->
      <line class="s" x1="70" y1="285" x2="70" y2="34" marker-end="url(#rt-a)"/>
      <line class="s" x1="70" y1="285" x2="648" y2="285" marker-end="url(#rt-a)"/>
      <text class="em" x="52" y="40" text-anchor="middle">Q</text>
      <text class="em" x="650" y="304" text-anchor="middle">t</text>
      <text class="lb" x="58" y="298" text-anchor="middle">0</text>

      <!-- shaded storage region between the two curves -->
      <path class="softa" d="M90,266 C150,150 210,90 250,90 C290,90 350,140 420,200 C480,235 540,250 600,255
                              L600,240 C540,220 480,190 420,165 C380,150 340,150 300,165 C240,190 160,230 90,266 Z"/>
      <text class="lb" x="235" y="195" text-anchor="middle">storage</text>
      <text class="lb" x="235" y="211" text-anchor="middle">= ∫(I − Q) dt</text>

      <!-- inflow curve -->
      <path class="ac" fill="none" stroke-width="2.4" d="M90,266 C150,150 210,90 250,90 C290,90 350,140 420,200 C480,235 540,250 600,255"/>
      <!-- outflow curve -->
      <path class="hi" fill="none" stroke-width="2.4" d="M90,266 C160,230 240,190 300,165 C340,150 380,150 420,165 C480,190 540,220 600,240"/>

      <!-- peak markers -->
      <circle class="acf" cx="250" cy="90" r="4.5"/>
      <circle class="hif" cx="360" cy="150" r="4.5"/>
      <text class="em" x="250" y="76" text-anchor="middle">Ip</text>
      <text class="em" x="360" y="138" text-anchor="middle">Qp</text>

      <!-- curve labels -->
      <text class="lb ac" x="585" y="236" text-anchor="end">Inflow</text>
      <text class="lb hi" x="585" y="266" text-anchor="end">Outflow</text>

      <!-- dashed verticals from each peak down to the time axis -->
      <line class="thin dash" x1="250" y1="90" x2="250" y2="285"/>
      <line class="thin dash" x1="360" y1="150" x2="360" y2="285"/>

      <!-- lag bracket below the time axis -->
      <line class="thin" x1="250" y1="306" x2="360" y2="306" marker-start="url(#rt-m)" marker-end="url(#rt-m)"/>
      <text class="em" x="305" y="324" text-anchor="middle">lag</text>

      <!-- dashed horizontals from each peak back to the Q axis -->
      <line class="thin dash" x1="70" y1="90" x2="250" y2="90"/>
      <line class="thin dash" x1="70" y1="150" x2="360" y2="150"/>

      <!-- attenuation bracket at the left margin -->
      <line class="thin" x1="38" y1="90" x2="38" y2="150" marker-start="url(#rt-m)" marker-end="url(#rt-m)"/>
      <text class="em" x="16" y="120" text-anchor="middle" transform="rotate(-90 16 120)">attenuation</text>
    </svg>`,
    caption: "Flood routing in one picture: the outflow wave is always <strong>shorter (attenuation = Ip − Qp)</strong> and <strong>later (lag)</strong> than the inflow wave that caused it — the shaded region is exactly the volume of water held in storage while the wave passes through the reservoir or channel reach, released back out on the recession limb.",
  },

});
