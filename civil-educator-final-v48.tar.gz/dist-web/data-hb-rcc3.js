/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   Chapter 5 — Shear and Bond
   Chapter 6 — Torsion

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "rcc"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 5 */
    {
      id: "rcc-5",
      n: 5,
      title: "Shear and Bond",
      hi: "अपरूपण और बॉन्ड",
      blurb: "Why beams crack diagonally, how stirrups stop them, and why a correctly sized bar is still useless if it has nowhere to grip.",
      mins: 48,
      sections: [

        {
          n: "5.1",
          title: "Shear is really diagonal tension",
          hi: "अपरूपण असल में तिरछा तनाव है",
          blocks: [
            { k: "p", t: "Chapter 3 designed a beam at mid-span, where the moment is large and the shear is small. Near the supports the situation reverses, and a beam that is perfectly adequate in flexure can fail there — suddenly, and along a crack that leans rather than stands upright." },
            { k: "p", t: "The reason is that shear stress never acts alone. Take a small element in the web of a beam: it carries a bending stress along the axis and a shear stress across it. Combine them and the principal tensile stress is inclined — close to 45° where the bending stress is small, flattening as the bending stress grows. Concrete is weak in tension whatever the direction, so it cracks perpendicular to that principal tension, which is why the crack leans." },
            { k: "dia", id: "hb-rcc-diagtension", cap: "Shear and bending combine into an inclined principal tension; the crack opens at right angles to it." },
            { k: "note", t: "This is why the subject is sometimes called <em>diagonal tension</em> rather than shear, and why shear reinforcement is arranged to cross the lean of the crack. A bar lying along the crack does nothing." },
            { k: "trap", t: "The shear failure of a beam is brittle. There is no equivalent of the under-reinforced warning from Chapter 3 — a diagonal crack can open and the beam can drop in one movement. That is why the code's approach to shear is more conservative than its approach to flexure, and why shear must never be the weaker of the two in a design." },
          ],
        },

        {
          n: "5.2",
          title: "Nominal shear stress",
          hi: "नाम-मात्र अपरूपण प्रतिबल",
          blocks: [
            { k: "p", t: "The real distribution of shear stress through a cracked reinforced section is complicated and nobody designs with it. IS 456 Cl. 40.1 replaces it with a single average figure, defined so that the design rules can be written around it:" },
            { k: "eq", expr: "τv = Vu / (b d)", where: [
              ["τv", "nominal shear stress, N/mm²"],
              ["Vu", "factored shear force at the section, N"],
              ["b", "breadth of the member — the width of the web for a flanged beam, mm"],
              ["d", "effective depth, mm"],
            ]},
            { k: "p", t: "It is called <em>nominal</em> because it is not the stress anywhere in particular — it is a yardstick. Everything the code then says about shear strength is expressed in the same units, so the comparison is consistent even though neither quantity is a real stress at a real point." },
            { k: "trap", t: "For a T-beam, b in this expression is <strong>bw</strong>, the width of the web — not the effective flange width bf that Chapter 4 used for flexure. The flange helps in compression; it does almost nothing about the shear in the web. Using bf here would divide the shear stress by something like seven and hide a real problem." },
            { k: "note", t: "Where the depth of a beam varies along its length (a haunched or tapered beam), Cl. 40.1.1 modifies Vu to account for the vertical component of the inclined compression force. The effect is favourable where the depth increases in the direction of increasing moment, and unfavourable where it decreases." },
          ],
        },

        {
          n: "5.3",
          title: "What the concrete carries on its own",
          hi: "कंक्रीट अकेले कितना उठाती है",
          blocks: [
            { k: "p", t: "A beam with no stirrups at all is not without shear strength. Even after a diagonal crack has formed, three mechanisms carry shear across it: the uncracked concrete in the compression zone above the crack, aggregate interlock along the rough faces of the crack itself, and dowel action of the tension bars crossing it. IS 456 lumps all three into one figure, τc, given by Table 19." },
            { k: "p", t: "The surprising part is what τc depends on. It rises with the grade of concrete, which is expected — but it also rises with the <strong>percentage of tension steel</strong>, which at first looks like a mistake, because tension steel is at the bottom of the beam and the shear is carried across a diagonal crack." },
            { k: "h", t: "Why pt appears in a shear table" },
            { k: "list", items: [
              "More tension steel means the steel stress at a given moment is lower, so it stretches less, so the flexural cracks are <strong>narrower</strong>. Narrow cracks mean the two rough faces are still in contact and aggregate interlock survives.",
              "More tension steel means more bar area available for dowel action across the crack.",
              "More tension steel pushes the neutral axis <strong>down</strong>, not up — so the uncracked compression zone above the crack is deeper, and it is that concrete which carries shear directly.",
            ]},
            { k: "p", t: "The expression IS 456 gives alongside Table 19 makes the dependence explicit, and it is worth using rather than interpolating in the table by eye:" },
            { k: "eq", expr: "τc = 0.85 √(0.8 fck) (√(1 + 5β) − 1) / (6β),   where β = 0.8 fck / (6.89 pt) ≥ 1.0", where: [
              ["pt", "100 As / (b d) — the percentage of tension steel that continues at least a distance d past the section being checked"],
            ]},
            { k: "trap", t: "Only the steel that is <strong>fully anchored past the section</strong> counts towards pt. Bars that have been curtailed just before the section, or that stop at the support without a proper anchorage, do not contribute to aggregate interlock or dowel action and must not be counted. This is the commonest way a shear check is quietly overstated near supports — exactly where the shear is largest." },
            { k: "note", t: "Cl. 40.2.2 allows τc to be increased for members carrying axial compression, by a factor δ = 1 + 3Pu/(Ag fck), not more than 1.5. Compression closes the cracks and improves interlock. It matters for columns and for beams in braced frames with appreciable axial load." },
          ],
        },

        {
          n: "5.4",
          title: "The three cases",
          hi: "तीन स्थितियाँ",
          blocks: [
            { k: "p", t: "Every shear check ends in one of exactly three outcomes, and knowing which one you are in tells you what to do next." },
            { k: "steps", items: [
              "<strong>τv ≤ τc</strong> — the concrete alone is enough. Provide <em>minimum</em> shear reinforcement (Cl. 26.5.1.6) and move on. Minimum stirrups are never omitted from a beam.",
              "<strong>τc &lt; τv ≤ τc,max</strong> — design stirrups for the balance, Vus = Vu − τc b d (Cl. 40.4). This is the normal case.",
              "<strong>τv &gt; τc,max</strong> — the section itself has failed, and no quantity of stirrups is permitted to rescue it (Cl. 40.2.3). Increase b or d, or raise the grade of concrete.",
            ]},
            { k: "tbl", id: "tb-taucmax" },
            { k: "p", t: "The third case needs explaining, because it is the one students find arbitrary. Why should there be a ceiling at all, when more stirrups are always available?" },
            { k: "dia", id: "hb-rcc-truss", cap: "The cracked beam as a truss: concrete struts in compression, stirrups as tension ties." },
            { k: "p", t: "Because once the beam has cracked diagonally, it works as a truss. The concrete between the cracks forms inclined <em>struts</em> in compression, and the stirrups are the vertical <em>ties</em>. Stirrups are the only members you design — but the struts have to carry the same force, and they are plain concrete. τc,max is the point at which the strut, not the tie, reaches its capacity. Adding stirrup steel does nothing about a concrete strut that is already crushing, which is exactly why the code forbids it." },
          ],
        },

        {
          n: "5.5",
          title: "Designing the stirrups",
          hi: "स्टिरप डिज़ाइन",
          blocks: [
            { k: "p", t: "In the second case the concrete carries τc b d and the stirrups take the rest. IS 456 Cl. 40.4 gives the capacity of vertical stirrups from the same truss idea: assume the diagonal crack rises at 45°, so it is crossed by every stirrup within a horizontal distance d, which is d/sv stirrups, each carrying 0.87 fy Asv." },
            { k: "eq", expr: "Vus = 0.87 fy Asv d / sv", where: [
              ["Vus", "shear to be carried by the stirrups = Vu − τc b d, N"],
              ["Asv", "total cross-sectional area of all the legs of one stirrup, mm²"],
              ["sv", "spacing of the stirrups along the length of the member, mm"],
            ]},
            { k: "eq", expr: "sv = 0.87 fy Asv d / Vus", where: [] },
            { k: "dia", id: "hb-rcc-stirrups", cap: "Asv counts every leg that crosses the crack — two for an ordinary stirrup, four for a wide beam." },
            { k: "trap", t: "Asv is the area of <strong>all the legs</strong> of one stirrup, not the area of one bar. A 2-legged 8 mm stirrup has Asv = 2 × 50.27 = 100.5 mm². Getting this wrong by a factor of two is the single most common error in shear design, and half the time it errs on the unsafe side." },
            { k: "h", t: "Bent-up bars" },
            { k: "p", t: "Cl. 40.4 also permits bars bent up from the tension face, where they are no longer needed for moment, to be counted as shear reinforcement — a single bar or group at an angle α contributes 0.87 fy Asv sin α. Cl. 40.4 caps the contribution of bent-up bars at half the total Vus: they are an addition to stirrups, never a replacement for them, because a bent-up bar crosses only the one crack it happens to meet." },
          ],
        },

        {
          n: "5.6",
          title: "Minimum stirrups and maximum spacing",
          hi: "न्यूनतम स्टिरप और अधिकतम दूरी",
          blocks: [
            { k: "p", t: "Two rules apply to every beam, whether or not the shear calculation asked for anything. Both are about what happens between the calculation points." },
            { k: "eq", expr: "Asv / (b sv)  ≥  0.4 / (0.87 fy)        (Cl. 26.5.1.6)", where: [] },
            { k: "p", t: "This minimum exists because shear failure is brittle and the calculation is a lower bound, not a certainty. A beam with τv just under τc has no reserve at all if the load turns out slightly larger or τc slightly smaller than the table says. Minimum stirrups also hold the longitudinal bars in position during casting, confine the compression zone, and control cracking from shrinkage and temperature. Rearranged, the rule gives a maximum spacing directly:" },
            { k: "eq", expr: "sv  ≤  0.87 fy Asv / (0.4 b)", where: [] },
            { k: "p", t: "Cl. 26.5.1.5 adds an absolute cap, so that no diagonal crack can form between two stirrups without being crossed:" },
            { k: "list", items: [
              "Vertical stirrups: sv ≤ 0.75 d, and never more than 300 mm.",
              "Inclined stirrups at 45°: sv ≤ d, and never more than 300 mm.",
            ]},
            { k: "note", t: "The governing spacing is the <strong>smallest</strong> of the three — the design value from Cl. 40.4, the minimum-steel value from Cl. 26.5.1.6, and the absolute cap from Cl. 26.5.1.5. In practice, near mid-span the minimum usually governs and near the supports the design value does, which is why stirrups are closely spaced at the ends of a beam and widely spaced in the middle." },
          ],
        },

        {
          n: "5.7",
          title: "Shear design worked through",
          hi: "अपरूपण डिज़ाइन — हल सहित",
          blocks: [
            { k: "eg",
              title: "Example 5.1 — Stirrups for a beam",
              given: "b = 300 mm, d = 450 mm, M25 concrete, Fe 415 steel. Factored shear at the critical section Vu = 200 kN. Tension steel continuing past the section: 4 bars of 20 mm.",
              steps: [
                { t: "Nominal shear stress (Cl. 40.1)", w: "τv = Vu/(b d) = 200,000/(300 × 450) = 1.481 N/mm²" },
                { t: "Is the section large enough? (Cl. 40.2.3, Table 20)", w: "τc,max for M25 = 3.1 N/mm²\n1.481  <  3.1  ✓ the section is acceptable" },
                { t: "Percentage of tension steel", w: "Ast = 4 × 314.16 = 1256.6 mm²\npt = 100 × 1256.6/(300 × 450) = 0.931%" },
                { t: "Design shear strength of concrete (Cl. 40.2, Table 19 expression)", w: "β = 0.8 × 25/(6.89 × 0.931) = 20/6.413 = 3.118\nτc = 0.85 √20 × (√(1 + 5×3.118) − 1)/(6 × 3.118)\n   = 3.801 × (√16.59 − 1)/18.71\n   = 3.801 × 3.073/18.71 = 0.624 N/mm²" },
                { t: "Which case?", w: "τc = 0.624  <  τv = 1.481  <  τc,max = 3.1\n→ design stirrups for the balance (Cl. 40.4)" },
                { t: "Shear to be carried by stirrups", w: "Vus = Vu − τc b d = 200,000 − 0.624 × 300 × 450\n    = 200,000 − 84,293 = 115,707 N" },
                { t: "Spacing of 2-legged 8 mm stirrups", w: "Asv = 2 × 50.27 = 100.5 mm²\nsv = 0.87 × 415 × 100.5 × 450 / 115,707\n   = 36,286 × 450/115,707 = 141.1 mm" },
                { t: "Check the spacing limits", w: "Minimum steel (Cl. 26.5.1.6): sv ≤ 0.87 × 415 × 100.5/(0.4 × 300) = 302.5 mm\nAbsolute cap (Cl. 26.5.1.5): 0.75 d = 337.5 mm, but not more than 300 mm\nGoverning: 141.1 mm from the design — the smallest of the three." },
              ],
              ans: "Provide 2-legged 8 mm stirrups at 140 mm centres in this region. (10 mm 2-legged would give 220 mm centres — fewer stirrups to fix, more steel by weight; either is acceptable.)",
            },
            { k: "note", t: "Shear varies along the beam, so this calculation is repeated at intervals and the result is a <em>spacing schedule</em> — say 8 mm at 140 for the first 1.5 m from each support, then 8 mm at 250 through the middle. A single spacing for the whole span is wasteful at mid-span and, if taken from the mid-span value, dangerous at the ends." },
            { k: "p", t: "Cl. 40.5 allows the shear strength of sections very close to a support to be enhanced, because the load there is transferred directly into the support by arch action rather than through the web. The usual practical consequence is that the critical section for shear is taken at a distance d from the face of the support rather than at the face itself (Cl. 22.6.2: allowed when the support reaction introduces compression into the end region of the beam; otherwise — e.g. a secondary beam framing into the side of a main beam — the face of the support is the critical section; per the <a href=\"https://gcekbpatna.ac.in/assets/documents/lecturenotes/e-_Notes_Deign_for_Shear-converted.pdf\" target=\"_blank\" rel=\"noopener\">GCE notes on shear design</a>)." },
          ],
        },

        {
          n: "5.8",
          title: "Bond: where development length comes from",
          hi: "बॉन्ड: डेवलपमेंट लेंग्थ कहाँ से",
          blocks: [
            { k: "p", t: "Every calculation so far has assumed that a bar can develop 0.87 fy wherever it is needed. That assumption has to be earned. Force gets into a bar only through its surface — through adhesion, friction and, for deformed bars, the mechanical bearing of the ribs against the concrete. Collectively this is <em>bond</em>, and it is what stops a bar from pulling out of the concrete like a nail from wood." },
            { k: "dia", id: "hb-rcc-bond", cap: "The force balance that defines Ld: the pull in the bar equals the bond force around its surface." },
            { k: "p", t: "The derivation is one line. The pull the bar must carry is its area times its design stress. The bond force available is the surface area of the embedded length times the design bond stress. Set them equal:" },
            { k: "eq", expr: "(π/4) φ² × 0.87 fy  =  π φ Ld × τbd", where: [] },
            { k: "eq", expr: "Ld = φ × 0.87 fy / (4 τbd)        (Cl. 26.2.1)", where: [
              ["φ", "nominal diameter of the bar, mm"],
              ["τbd", "design bond stress, N/mm² (Cl. 26.2.1.1)"],
            ]},
            { k: "tbl", id: "tb-taubd" },
            { k: "p", t: "Cl. 26.2.1.1 gives τbd for plain bars in tension and then makes two adjustments. Deformed bars get a <strong>60% increase</strong>, because the ribs bear mechanically on the concrete instead of relying on adhesion. Bars in <strong>compression</strong> get a further 25% increase, because the end of the bar bears directly on the concrete and, unlike a tension bar, compression does not open transverse cracks that would otherwise break the bond." },
            { k: "tbl", id: "tb-ld" },
            { k: "p", t: "For Fe 415 deformed bars this works out at about 47φ in M20 and 40φ in M25 — which is where the site rule of thumb \"50 times the diameter\" comes from. The rule of thumb is safe for M20 and wasteful for M30, and it is wrong for Fe 500, which needs about 48φ in M25." },
            { k: "trap", t: "Ld is proportional to <strong>fy</strong> and inversely proportional to <strong>fck</strong>. Substituting Fe 500 for Fe 415 to save steel increases every development length by about 20%, and in a congested junction that can be the change that makes the detail impossible to build. Check the lengths before switching grades, not after." },
          ],
        },

        {
          n: "5.9",
          title: "Anchorage, hooks and bends",
          hi: "एंकरेज, हुक और बेंड",
          blocks: [
            { k: "p", t: "Straight embedment is not always available — at an end support there may be only 300 mm of beam left. Cl. 26.2.2 permits the remaining length to be provided as a bend or a hook, and assigns each an <em>anchorage value</em> in terms of equivalent straight length." },
            { k: "list", items: [
              "A standard <strong>bend</strong> is credited with 4φ for every 45° of bend, subject to a maximum of 16φ for the bend as a whole.",
              "A standard <strong>U-hook</strong> is credited with 16φ.",
              "The anchorage value counts towards Ld — so a bar needing 40φ with a U-hook still needs 24φ of straight length before the hook.",
            ]},
            { k: "note", t: "Cl. 26.2.2.1 requires that the bend itself be able to be made without damaging the bar or splitting the concrete inside the bend, which is why minimum bend radii exist and why a bar must never be bent tighter than the schedule says on site. The bearing stress inside a bend can be very high, and the concrete there is often unconfined." },
            { k: "p", t: "In compression members the picture is different again: Cl. 26.2.2.2 does not allow hooks to be credited for bars in compression, because a hook on a compression bar tends to straighten under load rather than grip." },
            { k: "note", t: "Stated precisely (v34): a hook or bend on a compression bar earns <b>no anchorage value</b> (no 16φ, no 4φ per 45°); only the <b>projected straight length</b> of the bar counts towards its compression development length (<a href=\"https://engineeringhulk.com/civil/rcc-design/bond-anchorage-development-length/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — bond, anchorage &amp; development length</a>, which also lists deformed-bar τbd = 1.92, 2.24, 2.40, 2.72, 3.04 N/mm² for M20–M40 — i.e. 1.6 × the plain-bar values used in the table above)." },
          ],
        },

        {
          n: "5.10",
          title: "The check at a simple support",
          hi: "सरल सपोर्ट पर जाँच",
          blocks: [
            { k: "p", t: "There is one place where bond is a design calculation rather than a detailing rule: the end of a simply supported beam. The moment there is zero, so intuitively the bars need no stress — but the shear is at its largest, and a diagonal crack near the support shifts tension into the bottom bars at a section where they have almost no embedded length behind them. Cl. 26.2.3.3 states the requirement:" },
            { k: "eq", expr: "Ld  ≤  1.3 M1 / V  +  L0", where: [
              ["M1", "moment of resistance of the bars that actually continue into the support, N·mm"],
              ["V", "factored shear force at the support, N"],
              ["L0", "sum of the anchorage beyond the centre of the support and the equivalent anchorage of any hook or bend"],
            ]},
            { k: "p", t: "The factor 1.3 applies only where the ends of the bars are confined by a compressive reaction — that is, at a simple support sitting on something. At a point of contraflexure there is no such confinement and the factor is 1.0, with L0 limited to the greater of d or 12φ." },
            { k: "eg",
              title: "Example 5.2 — Bond check at an end support",
              given: "b = 250 mm, d = 400 mm, M25 concrete, Fe 415 steel. Three 16 mm bars continue into the support. Factored shear at the support V = 150 kN. Take L0 = 0 to be conservative.",
              steps: [
                { t: "Area of the bars continuing", w: "Ast = 3 × 201.06 = 603.2 mm²" },
                { t: "Neutral axis for those bars alone", w: "xu = 0.87 × 415 × 603.2/(0.36 × 25 × 250)\n   = 217,782/2250 = 96.8 mm" },
                { t: "Moment of resistance of the continuing bars", w: "z = 400 − 0.42 × 96.8 = 400 − 40.7 = 359.3 mm\nM1 = 217,782 × 359.3 = 78.25 × 10⁶ N·mm" },
                { t: "Available length by Cl. 26.2.3.3", w: "1.3 M1/V + L0 = 1.3 × 78.25 × 10⁶/150,000 + 0\n               = 678.2 mm" },
                { t: "Required development length", w: "Ld = 40.3 φ = 40.3 × 16 = 645 mm   (Fe 415 deformed, M25)" },
                { t: "Compare", w: "645 mm  ≤  678 mm  ✓ satisfied, even with no anchorage credited beyond the support centre." },
              ],
              ans: "The check is satisfied. Had it failed, the remedies in order of preference are: use more, smaller bars (Ld falls with φ while M1 stays put), provide a standard hook to add 16φ to L0, or raise the grade of concrete.",
            },
            { k: "trap", t: "M1 is the moment of resistance of <strong>only the bars that continue into the support</strong>, not of all the bars at mid-span. If three of five bars are curtailed before the support, M1 is computed from the two that remain — and the check gets much harder, which is the point of it." },
          ],
        },

        {
          n: "5.11",
          title: "Curtailment and laps",
          hi: "कर्टेलमेंट और लैप",
          blocks: [
            { k: "p", t: "The moment in a beam falls away from mid-span, so the steel needed falls with it. Stopping bars where they are no longer needed saves steel; stopping them badly causes failures." },
            { k: "dia", id: "hb-rcc-curtail", cap: "The provided moment of resistance is a staircase, and it must stay above the moment curve everywhere." },
            { k: "p", t: "Cl. 26.2.3.1 sets the basic rule: a bar must extend beyond the point at which it is theoretically no longer required by a distance equal to <strong>d or 12φ, whichever is greater</strong>. The reason is the same shift of tension caused by diagonal cracking that made §5.10 necessary — the theoretical cut-off point is not where the bar actually stops being needed." },
            { k: "p", t: "Cl. 26.2.3.2 goes further and discourages terminating bars in a tension zone at all, unless one of its conditions is met — the shear at the cut-off being within two-thirds of the permitted value, or extra stirrups being provided over the length beyond the cut-off. A curtailment point is a stress concentration and a crack starter, and putting one in a region that is already in tension is asking for it." },
            { k: "h", t: "Laps" },
            { k: "p", t: "Bars come in stock lengths, so joints are unavoidable. Cl. 26.2.5.1 covers lap splices: the lap length for bars in tension is the greater of Ld and 30φ; for bars in compression it is the greater of the compression Ld and 24φ. Laps should be staggered, kept away from sections of maximum stress, and for bars larger than 36 mm, Cl. 26.2.5.1 requires welding or mechanical couplers rather than lapping." },
            { k: "note", t: "A lap works by transferring force from one bar to the other <em>through the concrete between them</em>. That is why a lap in a heavily congested zone is weaker than the calculation suggests. It is also why earthquake-resistant detailing puts column laps in the <strong>middle half</strong> of the storey height, where frame moments are smallest, rather than at the ends next to the beams where they peak (see Chapter 12.3). <b>Correction (v35):</b> an earlier version had this reversed." },
          ],
        },

        {
          n: "5.12",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "τv = Vu/(b d), with b = bw for a flanged beam.",
              "Compare with τc (Table 19, depends on fck and pt) and with τc,max (Table 20). Three cases: minimum stirrups, designed stirrups, or a bigger section.",
              "τc,max is a limit on the concrete strut, which is why stirrups cannot rescue a section beyond it.",
              "Vus = 0.87 fy Asv d/sv. Asv counts every leg.",
              "Spacing is the smallest of the design value, the minimum-steel value and the absolute cap.",
              "Ld = 0.87 fy φ/(4 τbd) — about 47φ for Fe 415 in M20, 40φ in M25.",
              "At a simple support, check Ld ≤ 1.3 M1/V + L0, with M1 from the continuing bars only.",
              "Curtail a bar d or 12φ past the point where the moment no longer needs it.",
            ]},
            { k: "p", t: "Chapter 6 takes the same beam and adds a twist to it — literally — and finds that the code handles torsion not with a new theory but by converting the twist into an equivalent shear and an equivalent moment, and then reusing everything in this chapter and Chapter 3." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "rcc-6",
      n: 6,
      title: "Torsion",
      hi: "ऐंठन (टॉर्शन)",
      blurb: "Which twists you must design for and which you may detail away, and how IS 456 turns a torque into an equivalent shear and an equivalent moment.",
      mins: 36,
      sections: [

        {
          n: "6.1",
          title: "Two kinds of twist",
          hi: "दो तरह की ऐंठन",
          blocks: [
            { k: "p", t: "Before any calculation, torsion has to be classified, because the answer for one kind is a full design and the answer for the other is a detail. IS 456 Cl. 41.1 draws the line, and it is drawn on a question of statics: <em>if the member stopped resisting the twist, would the structure still stand?</em>" },
            { k: "dia", id: "hb-rcc-torsion", cap: "Equilibrium torsion has nowhere else to go. Compatibility torsion disappears once the member cracks and softens." },
            { k: "def", term: "Equilibrium torsion", t: "The twist is required for equilibrium — no other load path exists. The edge beam supporting a cantilever slab or a cantilevered canopy is the standard case: the slab's fixing moment can only be resisted by the beam twisting. The torque is known from statics alone and the member must be designed for all of it." },
            { k: "def", term: "Compatibility torsion", t: "The twist arises only because the member is attached to something that rotates — an interior beam twisted by the slab framing into it. The torque depends on the relative stiffnesses, and as soon as the beam cracks in torsion its torsional stiffness collapses, the rotation is accommodated elsewhere, and most of the torque simply goes away. Cl. 41.1 permits it to be neglected provided the member is detailed for torsion." },
            { k: "trap", t: "\"Neglect\" in Cl. 41.1 means neglect in the <em>calculation</em>, not in the drawing. A member with compatibility torsion still needs closed stirrups and corner bars — the torque disappears only because the member is allowed to crack, and it has to be detailed so that the cracking is controlled rather than destructive." },
          ],
        },

        {
          n: "6.2",
          title: "How a beam resists a twist",
          hi: "बीम ऐंठन कैसे झेलती है",
          blocks: [
            { k: "p", t: "A torque applied to a rectangular member produces shear stresses that circulate around the section — up one face, across the top, down the other, back along the bottom. The principal tension they produce therefore also circulates, and the resulting crack does something no flexural or shear crack does: it <strong>spirals</strong> around the member, appearing on all four faces at successive levels." },
            { k: "dia", id: "hb-rcc-torsionreinf", cap: "The torsion crack runs round all four faces, so the reinforcement has to close on itself." },
            { k: "p", t: "That geometry dictates the reinforcement completely. A shear stirrup can be open at the top and still do its job, because shear tension acts on one face. Torsion puts tension on every face, so:" },
            { k: "list", items: [
              "Stirrups must be <strong>closed loops</strong> with properly anchored ends — an open stirrup simply unwinds.",
              "There must be a <strong>longitudinal bar in every corner</strong>, for the stirrup to bear against. Without it the corner of the loop straightens and the concrete spalls off.",
              "Longitudinal steel is needed on all faces, top as well as bottom, because the spiral crack puts the longitudinal direction into tension everywhere, not only at the soffit.",
            ]},
            { k: "p", t: "After cracking, the member behaves as a hollow <em>space truss</em>: the concrete between the spiral cracks forms inclined struts running round the perimeter, the closed stirrups are the transverse ties, and the longitudinal bars are the chords. The core of the section contributes almost nothing — which is why a solid beam and a hollow one of the same outside dimensions have nearly the same torsional strength once cracked." },
          ],
        },

        {
          n: "6.3",
          title: "Equivalent shear",
          hi: "समतुल्य अपरूपण",
          blocks: [
            { k: "p", t: "IS 456 does not give torsion a theory of its own. It converts the torque into quantities that the existing shear and flexure rules can handle. The first conversion, Cl. 41.3.1, adds the torque to the shear:" },
            { k: "eq", expr: "Ve = Vu + 1.6 Tu / b", where: [
              ["Ve", "equivalent shear, N"],
              ["Tu", "factored torsional moment, N·mm"],
              ["b", "breadth of the member, mm"],
            ]},
            { k: "p", t: "Both effects produce shear stress in the web, so adding them is physically reasonable; the coefficient 1.6 is calibrated so that the resulting τve, compared against the ordinary τc and τc,max, gives sensible answers. The equivalent shear stress then follows the definition of §5.2 exactly:" },
            { k: "eq", expr: "τve = Ve / (b d)", where: [] },
            { k: "p", t: "Cl. 41.3.1 requires τve ≤ τc,max, and the consequence of exceeding it is the same as in Chapter 5 — the section is inadequate and no reinforcement is permitted to make up the shortfall. If τve ≤ τc, Cl. 41.3.2 requires only minimum shear reinforcement, and that too must be in the form of closed stirrups." },
            { k: "trap", t: "The 1.6 Tu/b term is usually <strong>larger than Vu itself</strong>. With Tu in kNm and b in metres, a 40 kNm torque on a 300 mm wide beam contributes 213 kN — more than twice a typical 80 kN shear. Torsion is not a small correction to a shear design; it dominates it." },
          ],
        },

        {
          n: "6.4",
          title: "Equivalent moment",
          hi: "समतुल्य बंकन आघूर्ण",
          blocks: [
            { k: "p", t: "The second conversion, Cl. 41.4.2, turns the torque into an additional bending moment so that the longitudinal steel can be designed by the rules of Chapter 3:" },
            { k: "eq", expr: "Mt = Tu (1 + D/b) / 1.7        Me1 = Mu + Mt", where: [
              ["Mt", "equivalent bending moment due to torsion, N·mm"],
              ["D", "overall depth of the member, mm"],
              ["Me1", "the moment for which the longitudinal steel is designed"],
            ]},
            { k: "p", t: "The ratio D/b appears because a deep narrow section is far worse in torsion than a square one of the same area — the spiral crack has a long path down the two deep faces and only a short one across the narrow faces. The design then proceeds exactly as in Chapter 3, with Me1 in place of Mu." },
            { k: "h", t: "When the twist beats the bending" },
            { k: "p", t: "Cl. 41.4.2.1 covers the case where Mt exceeds Mu. Torsion reverses sign as easily as it acts, so a large torque puts the <em>top</em> of the beam into longitudinal tension as readily as the bottom. In that case a second moment is computed and steel is provided on the flexural compression face for it:" },
            { k: "eq", expr: "Me2 = Mt − Mu        (provide steel on the flexural compression face for Me2)", where: [] },
            { k: "note", t: "This is why a beam designed for significant torsion often carries nearly as much steel at the top as at the bottom, even at mid-span where an ordinary beam would have only nominal top bars." },
          ],
        },

        {
          n: "6.5",
          title: "Transverse reinforcement for torsion",
          hi: "टॉर्शन के लिए स्टिरप",
          blocks: [
            { k: "p", t: "The stirrups cannot be converted away, because the twist and the shear stress them differently around the loop. Cl. 41.4.3 gives the required area directly, as the sum of a torsion term and a shear term:" },
            { k: "eq", expr: "Asv = Tu sv / (b1 d1 × 0.87 fy)  +  Vu sv / (2.5 d1 × 0.87 fy)", where: [
              ["b1", "centre-to-centre distance between the corner bars in the direction of the width, mm"],
              ["d1", "centre-to-centre distance between the corner bars in the direction of the depth, mm"],
              ["sv", "spacing of the closed stirrups, mm"],
            ]},
            { k: "p", t: "Cl. 41.4.3 then adds a floor: the total transverse reinforcement must not be less than" },
            { k: "eq", expr: "Asv  ≥  (τve − τc) b sv / (0.87 fy)", where: [] },
            { k: "p", t: "so the answer is the larger of the two. The first expression usually governs when the torque is large, the second when the shear is." },
            { k: "h", t: "Spacing" },
            { k: "p", t: "Cl. 26.5.1.7 caps the spacing of torsion stirrups at the least of <strong>x1</strong>, <strong>(x1 + y1)/4</strong> and <strong>300 mm</strong>, where x1 and y1 are the short and long dimensions of the stirrup. The middle term is the binding one for most beams, and it is considerably tighter than the 0.75 d of ordinary shear — because the spiral crack has to be crossed all the way round, not just once." },
          ],
        },

        {
          n: "6.6",
          title: "Torsion worked through",
          hi: "टॉर्शन — हल सहित",
          blocks: [
            { k: "eg",
              title: "Example 6.1 — Beam with torsion, shear and bending",
              given: "b = 300 mm, D = 500 mm, d = 450 mm, M25 concrete, Fe 415 steel. Factored actions: Mu = 100 kNm, Vu = 80 kN, Tu = 40 kNm (equilibrium torsion). Clear cover 30 mm, 10 mm stirrups.",
              steps: [
                { t: "Equivalent shear (Cl. 41.3.1)", w: "Ve = Vu + 1.6 Tu/b = 80 + 1.6 × 40/0.30\n   = 80 + 213.33 = 293.33 kN\nNote the torque contributes nearly three times the shear itself." },
                { t: "Equivalent shear stress, and the section check", w: "τve = 293,330/(300 × 450) = 2.173 N/mm²\nτc,max for M25 = 3.1 N/mm²   →  2.173 < 3.1  ✓ section is adequate" },
                { t: "Equivalent moment (Cl. 41.4.2)", w: "Mt = Tu(1 + D/b)/1.7 = 40 × (1 + 500/300)/1.7\n   = 40 × 2.667/1.7 = 62.75 kNm\nMe1 = Mu + Mt = 100 + 62.75 = 162.75 kNm\nMt = 62.75 < Mu = 100, so no steel is needed on the compression face (Cl. 41.4.2.1)." },
                { t: "Longitudinal steel for Me1 (Chapter 3 method)", w: "Mu,lim = 0.138 × 25 × 300 × 450² = 209.6 kNm  >  162.75  ✓ singly reinforced\n19.978 Ast² − 162,472 Ast + 162.75 × 10⁶ = 0\nAst = [162,472 − 115,724]/39.956 = 1170.0 mm²\nProvide 4 bars of 20 mm = 1256.6 mm²  ✓" },
                { t: "Corner-bar spacings b1, d1 (centre to centre of the corner bars, assuming 20 mm corner bars)", w: "b1 = 300 − 2×30 − 2×10 − 20 = 200 mm\nd1 = 500 − 2×30 − 2×10 − 20 = 400 mm\nStirrup centreline dimensions for the spacing cap: x1 = 300 − 60 − 10 = 230 mm, y1 = 500 − 60 − 10 = 430 mm" },
                { t: "Transverse steel by the torsion expression (Cl. 41.4.3)", w: "Asv/sv = Tu/(b1 d1 × 0.87fy) + Vu/(2.5 d1 × 0.87fy)\n       = 40×10⁶/(200 × 400 × 361.05)  +  80,000/(2.5 × 400 × 361.05)\n       = 40×10⁶/28,884,000  +  80,000/361,050\n       = 1.3848 + 0.2216 = 1.6064 mm²/mm" },
                { t: "Check against the minimum (Cl. 41.4.3)", w: "pt = 100 × 1170/(300 × 450) = 0.867%\nβ = 20/(6.89 × 0.867) = 3.349\nτc = 3.801 × (√(1 + 16.75) − 1)/(6 × 3.349) = 0.608 N/mm²\nAsv/sv ≥ (2.173 − 0.608) × 300/361.05 = 1.3005 mm²/mm\n1.6064 > 1.3005 — the torsion expression governs." },
                { t: "Spacing of 2-legged 10 mm closed stirrups", w: "Asv = 2 × 78.54 = 157.1 mm²\nsv = 157.1/1.6064 = 97.8 mm\nMaximum (Cl. 26.5.1.7): least of x1 = 230, (230 + 430)/4 = 165, and 300 → 165 mm\n97.8 < 165  ✓" },
              ],
              ans: "Ast = 4 bars of 20 mm at the bottom; 2-legged 10 mm CLOSED stirrups at 95 mm centres, with a longitudinal bar in each of the four corners.",
            },
            { k: "trap", t: "Compare the answer with the same beam without torsion: the shear alone would have needed 8 mm stirrups at around 300 mm, and the moment alone about 700 mm² of steel. A 40 kNm torque nearly doubled the longitudinal steel and cut the stirrup spacing by more than half. If a beam's torsion is being ignored on the grounds that it is small, check the number first." },
            { k: "note", t: "<b>Correction (v34):</b> the earlier version of this example took b1 = 232 mm and d1 = 432 mm — an arithmetic slip (300 − 60 − 10 is 230) and, more importantly, not the quantity the clause defines. b1 and d1 are the centre-to-centre distances between the <b>corner bars</b>, so the stirrup and half of each corner bar must also be deducted: 200 × 400 mm here. Using the larger values understated the torsion steel by about 18% and gave 115 mm spacing instead of 95 mm — an unsafe error. x1 and y1 for the spacing cap are the stirrup's own dimensions, a different pair. The corrected deduction (b − 2 × cover − 2 × stirrup − corner bar) is exactly how <a href=\"https://www.madeeasy.in/uploads/examsolution/125ufrep_ce-test-12.pdf\" target=\"_blank\" rel=\"noopener\">MADE EASY's worked torsion solution</a> computes b1 and d1." },
          ],
        },

        {
          n: "6.7",
          title: "Detailing, and what to carry forward",
          hi: "डिटेलिंग और आगे के लिए",
          blocks: [
            { k: "p", t: "Cl. 26.5.1.7 governs the arrangement, and torsion detailing has requirements that ordinary beam detailing does not:" },
            { k: "list", items: [
              "Stirrups must be <strong>closed</strong>, with the ends anchored by hooks bent into the core of the section — not merely lapped in the cover, where the concrete will spall.",
              "At least one longitudinal bar in <strong>every corner</strong> of every stirrup.",
              "Where a cross-sectional dimension exceeds 450 mm, additional longitudinal bars are needed on the side faces, distributed round the perimeter — spacing and area as required by Cl. 26.5.1.3.",
              "Spacing of the stirrups: the least of x1, (x1 + y1)/4 and 300 mm.",
            ]},
            { k: "list", items: [
              "Classify first: equilibrium torsion is designed for, compatibility torsion is detailed for (Cl. 41.1).",
              "Ve = Vu + 1.6 Tu/b, and τve = Ve/(b d) must not exceed τc,max.",
              "Mt = Tu(1 + D/b)/1.7; design the longitudinal steel for Me1 = Mu + Mt, and if Mt > Mu also for Me2 = Mt − Mu on the compression face.",
              "Transverse steel from Cl. 41.4.3, taking the larger of the torsion expression and the (τve − τc) minimum.",
              "Closed stirrups, corner bars, and spacing capped by (x1 + y1)/4.",
            ]},
            { k: "p", t: "Chapters 3 to 6 have designed a beam completely for strength. Chapter 7 changes the member — from a beam spanning in one direction to a slab, which may span in one direction or two, and where the design is governed less by strength than by deflection and by how the load finds its way to the supports." },
          ],
        },
      ],
    }

  );
})();
