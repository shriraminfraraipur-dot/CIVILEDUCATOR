/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 8
   Hydrographs & Unit Hydrograph Theory
   Source: S2 p.64-95, S3 p.34-46
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-8",
    n: 8,
    title: "Hydrographs & Unit Hydrograph Theory",
    hi: "हाइड्रोग्राफ एवं यूनिट हाइड्रोग्राफ सिद्धांत",
    blurb: "Hydrograph ke saare parts, base-flow separation, DRH se Runoff depth nikalna, Sherman ki Unit Hydrograph theory, superposition aur S-curve se duration badalna, complex-storm se UH ulta nikalna, Snyder ka Synthetic UH, aur IUH — sab worked numericals ke saath, step by step.",
    mins: 55,
    sections: [

      /* ================================================== 8.1 */
      {
        n: "8.1",
        title: "Hydrograph, Runoff components and the Flood Hydrograph",
        hi: "हाइड्रोग्राफ, रनऑफ के घटक और फ्लड हाइड्रोग्राफ",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.64–65, S3 p.34, 36" },
          { k: "def", term: "Hydrograph", t: "A graphical representation between stream discharge (Q, on the y-axis) and time (on the x-axis). Also called a <b>flood hydrograph</b> or <b>storm hydrograph</b>. (S2 p.64; S3 p.34)" },
          { k: "p", t: "Runoff reaching the catchment outlet travels by several paths: <b>surface runoff</b> (flows over the ground surface), <b>sub-surface runoff</b>, split into <b>prompt interflow / seepage flow</b> (shallow, joins the stream fairly quickly) and <b>delayed flow / base flow</b> (travels through the deep groundwater table and joins the stream only after a long time). (S2 p.64)" },
          { k: "def", term: "Direct Runoff (DR)", t: "Surface runoff plus prompt interflow — both reach the main stream within a few hours of the start of the storm. Since prompt interflow is very small compared to surface runoff, <b>Direct Runoff ≈ Surface Runoff</b> in practice. The discharge/hydrograph corresponding to the direct-runoff depth/volume is the <b>Direct Runoff Hydrograph (DRH)</b>. (S2 p.64)" },
          { k: "eq", expr: "Direct Runoff = Surface Runoff + Prompt Interflow", where: [] },
          { k: "def", term: "Base Flow (BF)", t: "That infiltrated water which joins the main stream only after a long period of time, through the groundwater table. It is generally assumed uniform, but in practice it can be variable, or even negative or zero. (S2 p.65; S3 p.36)" },
          { k: "def", term: "Total Runoff / Flood Discharge", t: "Direct Runoff + Base Flow. The hydrograph corresponding to this total discharge/volume is the <b>Flood Hydrograph</b> (S3's table also calls the plain Q-vs-t plot simply \"Hydrograph\", DRH = the plot without base flow, having more than 1 cm depth of DRO). (S2 p.65; S3 p.34)" },
          { k: "eq", expr: "Total Runoff = Direct Runoff + Base Flow  ⇒  Flood Hydrograph = DRH + BF  ⇒  DRH = Flood Hydrograph − BF", where: [] },
          { k: "def", term: "DRO (as per S3)", t: "Direct Runoff includes: (1) Surface Runoff (SRO), (2) precipitation falling directly on the channel surface, (3) interflow. Also stated as DR = SRO + Effluent-river contribution + Precipitation-on-channel. (S3 p.35–36)" },
          { k: "note", t: "India's <b>water year</b>: the hydrological year is taken to begin when rainfall starts exceeding evapotranspiration — by convention, <b>1st June to 31st May</b>. (S3 p.36)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yaad rakhna sabse simple tarika: Total/Flood hydrograph woh poora curve hai jo gauge par actually record hota hai. Usme se baseflow ka flat/slow-varying hissa hata do, bacha hua <b>DRH</b> hai — aur DRH hi woh cheez hai jiski shape, area aur depth se Unit Hydrograph banta hai. Prompt interflow ko ignore karna isliye valid hai kyunki woh surface runoff ke mukable bahut chhota hota hai." },
          { k: "real", t: "Base flow ko 'uniform' maan lena ek simplification hai jo mostly chalti hai, par lambi duration ke complex storms mein ya jab groundwater table khud storm se recharge ho raha ho, baseflow curve mein slight rise/fall practically dekha jaata hai — isliye separation method (8.2) chunna zaroori hai. (S2 p.65)" },
        ],
      },

      /* ================================================== 8.2 */
      {
        n: "8.2",
        title: "Elements of the flood hydrograph — rising limb, crest, recession, and the time terms",
        hi: "फ्लड हाइड्रोग्राफ के भाग — राइज़िंग लिम्ब, क्रेस्ट, रिसेशन और समय-पद",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.66–69, S3 p.37" },
          { k: "dia", id: "hb-hydro-anatomy", cap: "The five landmark points A–E of a flood hydrograph, the three segments between them, and the three time terms measured along the base." },
          { k: "list", items: [
            "<b>Segment AB — Rising limb</b> (also <b>Concentration curve</b>, S3): the initial part of the hydrograph. It is <b>concave</b> because of the heavy initial losses (interception, infiltration, depression storage, evaporation etc.) that must first be satisfied; it rises gradually. Its shape depends on the <b>slope of the catchment</b>, and generally on catchment/basin/drainage characteristics, rainfall characteristics, and climate. Point <b>B is the point of inflection</b> — curvature changes sign here. (S2 p.66; S3 p.37)",
            "<b>Segment BCD — Crest / Storage segment</b>: the most important segment because it carries the <b>peak discharge</b> — corresponding to the combined contribution of <b>all tributaries</b> of the river reaching the outlet together. Point C, the crest, represents the <b>maximum storage of water</b> the river is carrying. (S2 p.66; S3 p.37)",
            "<b>Segment DE — Falling limb</b> (also <b>Recession curve</b>): starts at point of inflection D (on the crest segment, S3) or marks the end of the crest, and is concave because it represents the catchment emptying/depleting its stored water. Its shape depends on the <b>storage characteristics</b> of the catchment — a wide, flat-topped hydrograph for large storage; a narrow, sharply-peaked one for less storage. (S2 p.66; S3 p.37)",
          ] },
          { k: "eq", expr: "t_PK = time of occurrence of the peak  ;  t_s = time of recession (peak to end)  ;  t_B = t_PK + t_s = Base period (total duration of the hydrograph)", where: [] },
          { k: "note", t: "For a <b>small catchment</b>, points B, C, D crowd close together near the peak — the crest segment is very short. (S2 p.67)" },
          { k: "h", t: "Lag time and time of concentration — S2 p.67–69" },
          { k: "def", term: "Lag time (t_L)", t: "Time lapsed between the peak of the (effective) rainfall and the peak of the hydrograph. Equivalently, the time interval between the <b>centre of mass of the rainfall</b> and the peak of the hydrograph — and when rainfall intensity is uniform, these two definitions coincide. (S2 p.67–68)" },
          { k: "eq", expr: "t_L = t_PK − D/2", where: [["D", "duration of the effective rainfall (ER)"]] },
          { k: "def", term: "Time of concentration (t_c)", t: "Two equivalent definitions: (1) the time taken for a drop of water from the <b>most remote part</b> of the catchment to reach the outlet; (2) from the hydrograph viewpoint, for an <b>isolated (uniform) storm</b>, it is the time from the <b>end of rainfall</b> to the <b>point of inflection on the falling limb</b>. For a small catchment, t_c ≈ t_L of the hydrograph (only a mathematical coincidence, no physical significance). t_c is one of the most important parameters in bridge design over a river, to safeguard against scouring or other hydrological failure. (S2 p.68–69)" },
          { k: "eq", expr: "t_c = 0.01947·K^0.77  ;  K = √(L³/ΔH)  ;  ΔH = S₁ − S₂", where: [
            ["L", "length along the main stream, km"],
            ["ΔH", "difference of elevation between inlet (S₁) and outlet (S₂)"],
          ] },
          { k: "eg", title: "Time of concentration from the hydrograph (S2 p.69)", given: "Duration of rainfall = 3 hr. Time to the hydrograph peak = 7 hr. Time to the point of inflection on the falling limb = 8.5 hr. Find t_c.", steps: [
            { t: "t_c is end-of-rainfall to point of inflection on the falling limb", w: "t_c = 8.5 − 3" },
          ], ans: "t_c = 5.5 hr" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "A-B-C-D-E yaad karne ka order: <b>rise → crest → fall</b>, aur dono inflection points (B aur D) curvature ke sign-change points hain — rising limb concave-se-convex badalti hai B par, falling limb convex-se-concave badalti hai D par. t_PK, t_s aur t_B teeno sirf time-axis ke segments hain: peak tak, peak se khatam tak, aur dono jod kar poora base. Lag time ek alag concept hai — woh <b>rainfall ke peak/centroid se hydrograph ke peak tak</b> ka fasla hai, hydrograph ke apne segments se nahi." },
          { k: "trap", t: "t_c ki do definitions hain aur dono exam mein alag-alag diya jaata hai — pehli wali (most remote point to outlet) travel-time wali hai, doosri wali (end of rainfall to inflection on falling limb) hydrograph-reading wali hai. Chhote catchment ke liye dono approximately t_L ke barabar hote hain, par yeh sirf numerical coincidence hai, physically ek jaisa concept nahi. (S2 p.69)" },
          { k: "h", t: "Factors shaping the hydrograph — S3 p.37–38" },
          { k: "list", items: [
            "<b>Fan-shaped (semicircular) catchment</b> → large peak, narrow hydrograph (small t_B) — tributaries are of nearly the same size/travel time, so flow arrives together. (S3 p.38; also S2 p.93)",
            "<b>Elongated (leaf / fern-leaf) catchment</b> → low peak, broad hydrograph (large t_B) — tributaries differ in size and travel time, so flow is spread out.",
            "<b>Steep catchment</b> → sharp rise, high peak, narrow hydrograph (lower t_B).",
            "<b>Urbanised catchment</b> → larger peak, narrower hydrograph (impervious surfaces cut infiltration losses and speed up drainage).",
          ] },
        ],
      },

      /* ================================================== 8.3 */
      {
        n: "8.3",
        title: "Base-flow separation, deriving the DRH, and finding Runoff depth",
        hi: "बेस-फ्लो पृथक्करण, DRH निकालना, और रनऑफ गहराई",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.69–71, S3 p.38–39, 42–44" },
          { k: "p", t: "S3's five-step procedure to analyse a flood hydrograph: (1) plot discharge (y) vs time (x); (2) <b>separate the base flow</b> to get the DRH; (3) find the <b>area of the DRH</b> using a suitable rule (Simpson's rule, Trapezoidal rule, or treating it as a triangle); (4) that area equals the <b>volume of DRO</b>; (5) divide by catchment area to get the <b>depth of DRO, R</b>. (S3 p.38)" },
          { k: "note", t: "The notes name common base-flow separation ideas rather than list all of them individually: in practice the base flow is read off either as a <b>straight horizontal line</b> at the pre-storm discharge (straight-line method), by extending the pre-storm recession and a post-storm recession and joining under the peak (fixed-base / N-day type construction), or simply as the smooth, slowly-varying trend under the flood peak — any of these gives the baseflow ordinate B to subtract at each time step. Whatever method is used, the result is the same ordinate-by-ordinate subtraction shown below. (S2 p.69–70)" },
          { k: "eq", expr: "Ordinates of DRH:  O_i = Q_i − B,  for i = 1 … n   ⟹   O₁ = Q₁ − B = 0 (always)  ,  O_n = Q_n − B = 0 (always)", where: [["Q_i", "ordinate of the flood hydrograph at time i"], ["B", "base-flow ordinate"]] },
          { k: "eq", expr: "Area of DRH = Σ O_i·t = Total direct-runoff volume  ⟹  Runoff depth  R = Area of DRH / Catchment area = Ah/Ac", where: [] },
          { k: "p", t: "Since the centre of gravity of the DRH curve is not readily available, the area is found by the <b>approximate method of strips</b>: (S2 p.70)" },
          { k: "eq", expr: "Ah = Area of DRH = 3600 Σ O_i·t   (m³)   [t in hours]   ⟹   R = 0.36 Σ O_i·t / A   (cm)", where: [
            ["O_i", "ordinate, m³/s"], ["t", "time interval, hr"], ["A", "catchment area, km²"],
          ] },
          { k: "note", t: "If the rainfall-excess (runoff) depth works out to exactly 1 cm, that particular DRH is, by definition, a <b>1-cm Unit Hydrograph</b> for that duration of storm. (S2 p.70)" },
          { k: "eg", title: "Direct runoff depth from a flood hydrograph (S2 p.71)", given: "A 2-hr storm occurs over a catchment of area 300 km². The flood-hydrograph ordinates (Q_t, m³/s) at 6-hr intervals are: t=0→10, 6→20, 12→40, 18→30, 24→10. Base flow B = 10 m³/s. Find the direct-runoff depth.", steps: [
            { t: "Subtract baseflow to get DRH ordinates O_i = Q_i − B", w: "t=0→0, 6→10, 12→30, 18→20, 24→0" },
            { t: "Apply R = 0.36ΣO_i·t/A with t = 6 hr, A = 300 km²", w: "R = (6 × 3600 × ΣO_i × 100)/(300 × 10⁶)   [ΣO_i = 0+10+30+20+0 = 60]" },
            { t: "Simplify", w: "R = 432/10³" },
          ], ans: "R = 0.432 cm" },
          { k: "h", t: "Worked examples — using the triangular approximation of the DRH (S3 p.39, 42–44)" },
          { k: "eq", expr: "Triangular DRH approximation:  R = (½·t_base·Q_peak) / Catchment area", where: [] },
          { k: "eg", title: "Peak ordinate of a triangular 1-hr UH from R (S3 p.42)", given: "Catchment area = 50 km². φ-index = 0.5 cm/hr. Base flow = 10 cumec. The 1-hr UH is triangular with time base 15 hr. Find the peak ordinate of the unit hydrograph.", steps: [
            { t: "For a 1-hr UH, R = 1 cm by definition; use the triangular-DRH formula", w: "R = ½·t_base·Q_peak / A" },
            { t: "Substitute R = 1/100 m, t_base = 15 hr = 15×3600 s, A = 50×10⁶ m²", w: "1/100 = ½ × (15×3600) × Q_peak / (50×10⁶)" },
          ], ans: "Q_peak(UH) = 18.52 cumec (the notes print 18.51, a truncation of 1×10⁶/54000 = 18.518)" },
          { k: "eg", title: "Peak flood ordinate for an actual storm (S3 p.43)", given: "Continuing the above: find the peak ordinate of the hydrograph due to a 1-hour storm with 5.5 cm of rainfall, φ-index = 0.5 cm/hr, base flow = 10 cumec.", steps: [
            { t: "Find rainfall excess from φ-index: φ = (P−R)/t", w: "0.5 = (5.5 − R)/1   ⟹   R = 5 cm" },
            { t: "Scale the UH peak by R in cm (UH ordinates are per 1 cm of rainfall excess) and add base flow", w: "Q_peak = (Q_peak)_UH × R + BF = 18.52 × 5 + 10 = 92.59 + 10\n(the notes multiply by 5×10⁻² instead of 5 and print 10.92)" },
          ], ans: "Q_peak = 102.6 cumec (the notes print 10.92 cumec)" },
          { k: "note", t: "<b>Correction (v45):</b> A unit hydrograph's ordinates are discharges per <b>1 cm</b> of rainfall excess, so the UH peak is multiplied by R expressed in cm (R = 5), not in metres. Correct peak = 18.52 × 5 + 10 = <b>102.6 cumec</b>. The notes used R = 5×10⁻² and printed 10.92 cumec, which would put the flood peak barely above the 10-cumec base flow despite 5 cm of runoff — physically impossible. (S3 p.43)" },
          { k: "eg", title: "Catchment area from 6-hr UH ordinates by the trapezoidal rule (S3 p.43–44)", given: "The ordinates of a 6-hr unit hydrograph at 1-hr intervals are 0, 3, 8, 6, 3, 2, 0 (cumec), for t = 0 to 6 hr. Find the catchment area.", steps: [
            { t: "Area of the UH by the trapezoidal rule, summing ½·1hr·(sum of adjacent ordinates) over each 1-hr strip", w: "Area = ½(1×3600)(0+3) + ½(1×3600)(3+8) + ½(1×3600)(8+6) + ½(1×3600)(6+3) + ½(1×3600)(3+2) + ½(1×3600)(2+0)" },
            { t: "First pass (as worked in the source, then corrected)", w: "A ≈ 1800[3 + 11 + 14 + 9 + 5 + 2] → first attempt ≈ 7.9 km² (superseded below)" },
            { t: "Equivalent compact form actually used: 3600[3/2 + 1 + 5.5 + 7 + 4.5 + 2.5]", w: "Since R = 1 cm (UH) = 1/100 m, A = (3600×[...])/(1/100)" },
          ], ans: "A = 7.92 km²" },
          { k: "eg", title: "Catchment area from a triangular 6-hr UH (S3 p.44–45)", given: "A rainfall of 16 cm occurs over a catchment during 12 hours, uniform intensity. The 6-hr unit hydrograph rises linearly from 0 to 30 cumec in 6 hours and falls linearly from 30 to 0 cumec in the next 12 hours. φ-index = 0.5 cm/hr, base flow = 5 cumec. Find the area of the catchment.", steps: [
            { t: "For the UH itself, R = 1 cm; use the triangular-DRH formula with t_base = 6+12 = 18 hr", w: "R = Area of DRH / A = (½ × t_base × Q_peak) / A" },
            { t: "Substitute R = 1×10⁻² m, Q_peak = 30 m³/s, t_base = 18 hr = 18×3600 s", w: "1×10⁻² = ½ × 30 × (18×3600) / A" },
          ], ans: "A = 97.2 km²" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Base-flow separation ka exact method (straight-line / fixed-base / N-day) exam mein diya hi jaata hai, par calculation hamesha same hai: har time-step par flood-hydrograph ordinate se baseflow ordinate minus karo, jo bache woh DRH hai. Pehla aur aakhri ordinate hamesha zero hona chahiye — yeh ek achha self-check hai. Uske baad area-under-curve (strips/trapezoidal/triangle) se Runoff depth R milta hai — aur agar R exactly 1cm aaye to woh DRH khud hi Unit Hydrograph ban jaata hai." },
          { k: "trap", t: "Formula R = (½·t_base·Q_peak)/A sirf tab use karo jab DRH ko <b>triangular</b> maana ja raha ho (jaisa S3 ke examples mein hai) — agar actual ordinates table mein diye hain (jaisa S2 ke example mein), to strips/trapezoidal method (R = 0.36ΣO_i·t/A) use karo, triangle formula nahi." },
        ],
      },

      /* ================================================== 8.4 */
      {
        n: "8.4",
        title: "Unit Hydrograph — definition and L.K. Sherman's basic assumptions",
        hi: "यूनिट हाइड्रोग्राफ — परिभाषा और शर्मन की मूल अवधारणाएँ",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.71–73, S3 p.39–41" },
          { k: "def", term: "Unit Hydrograph (UH)", t: "The Direct Runoff Hydrograph (DRH) resulting from <b>one unit depth (1 cm)</b> of rainfall excess, occurring uniformly over the catchment, at a uniform rate, over a storm of a specified duration D hours — called the <b>D-hour Unit Hydrograph</b> (e.g. a \"3-hr unit hydrograph\"). Developed by <b>L.K. Sherman</b>. It always starts from the origin and terminates on the time axis. For varying rainfall intensity, the unit hydrograph (for a single duration) is not defined/valid. (S2 p.71–72; S3 p.34, 39)" },
          { k: "list", items: [
            "<b>Flood HG → (− Base flow) → DRH → (÷ rainfall excess, cm) → Unit Hydrograph</b> (S2 p.71)",
            "<b>Unit HG → (× rainfall excess, cm) → DRH → (+ Base flow) → Flood Hydrograph</b> (S2 p.71)",
          ] },
          { k: "h", t: "The basic assumptions of Unit Hydrograph theory" },
          { k: "list", items: [
            "<b>① Linear response (principle of superposition):</b> if rainfall excess x₁(t) produces output y₁(t), and x₂(t) produces y₂(t), then the combined input x₁(t)+x₂(t) produces the combined output y₁(t)+y₂(t). Equivalently: to get n cm of rainfall excess using the same catchment's D-hr UH, simply add n units of the UH, each lagged by D hr relative to the previous one — the result is the DRH of an (n·D)-hr storm whose rainfall excess is n cm. (S2 p.72; S3 p.39)",
            "<b>② Time invariance:</b> the UH (or DRH) for a given rainfall-excess duration is always the same for a given catchment, regardless of <b>when</b> the storm occurs — e.g. a storm from 10am–1pm on one date gives the same UH shape as an equal-duration storm from 12pm–3pm on another date; day-time or night-time makes no difference. (S2 p.73; S3 p.39, 52)",
            "<b>③ Uniform rainfall intensity</b> over the entire duration of the storm. (S2 p.73)",
            "<b>④ Uniform spatial distribution</b> of rainfall over the entire catchment, for the entire storm period. (S2 p.73)",
          ] },
          { k: "note", t: "S3 groups these into \"two basic assumptions\" — <b>time invariance</b> and <b>linear response</b> — naming ③ and ④ (uniform intensity/distribution) as conditions under which the theory is applied, while S2 lists all four as co-equal assumptions. Both are kept here; the substance is identical. (S2 p.72–73; S3 p.39–40)" },
          { k: "note", t: "Unit hydrograph theory is valid for catchments of area roughly <b>2 km² to 5000 km²</b> — small/medium catchments. (S2 p.73; S3 p.39)" },
          { k: "h", t: "How duration D affects the UH's peak and base period" },
          { k: "list", items: [
            "If storm duration is 6 hr, giving DRO = 1 cm, this is the <b>6-hr unit hydrograph</b>, with (say) time base 60 hr. For the same catchment, a 12-hr storm with DRO = 1 cm gives the <b>12-hr UH</b> with time base 12 hr(longer) — but its <b>peak decreases</b>. If duration decreases, the peak <b>increases</b>. (S3 p.40)",
            "Time base of the UH depends only on rainfall <b>duration</b>; it is independent of the depth of DRO. Peak of the DRH, however, <b>does</b> depend on the depth of DRO: Ordinate of DRH = Ordinate of UH × R. (S3 p.40)",
            "If the base period of the 2-hr UHG is given, increasing duration (and hence base period) <b>decreases the peak discharge</b> — two curves with the same total rainfall excess (1 cm) but different base periods must enclose the same area, so the wider one is flatter. (S2 p.73)",
          ] },
          { k: "eq", expr: "Ordinate of DRH = Ordinate of UH × R  (i.e. DRO = UHO × R)", where: [] },
          { k: "def", term: "Drainage density correlation (as a shape factor, S3 p.41)", t: "Drainage density DD = (length of drainage)/(catchment area). Higher DD → quicker disposal of runoff → hydrograph has a larger peak and narrower shape. Lower DD → lower peak, broader shape." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Linear response ka matlab hai ki UH ek 'building block' hai — jaise bhi rainfall excess ho, uska DRH UH ko scale (×R) aur shift/add karke bana sakte ho, bina dobara se analysis kiye. Time invariance ka matlab ye NAHI hai ki hydrograph ka shape kabhi nahi badalta — matlab hai ki <b>same duration ki storm ke liye</b> catchment ka response fixed hai, chahe woh January mein ho ya June mein, din mein ho ya raat mein. Duration badal jaaye (2hr se 6hr) to UH khud bhi badal jaata hai — yehi 8.5/8.6 mein seekhte hain." },
          { k: "trap", t: "'Ordinate of DRH = Ordinate of UH × R' sirf <b>same duration</b> ke UH aur DRH ke beech lagu hota hai — agar storm duration UH ki duration se match nahi karta (jaise 2hr UH hai par storm 6hr ka hai), to seedha multiply nahi kar sakte; pehle superposition (8.5) ya S-curve (8.6) se sahi-duration UH nikaalo, phir R se scale karo." },
        ],
      },

      /* ================================================== 8.5 */
      {
        n: "8.5",
        title: "Changing the UH's duration — Case 1: method of superposition (T = n·D)",
        hi: "UH की अवधि बदलना — केस 1: सुपरपोज़िशन विधि (T = n·D)",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.74–76" },
          { k: "note", t: "<b>Case 1 — if T = n·D</b>, where n is an integer (1, 2, 3 …), use the <b>method of superposition</b>: add n units of the given D-hr UH, each lagged by D-hr relative to the previous one. (S2 p.74)" },
          { k: "eg", title: "2-hr UH → 6-hr UH by superposition (S2 p.74)", given: "A 2-hr unit hydrograph has ordinates (m³/s) at 2-hr intervals: 0, 6, 14, 25, 40, 30, 15, 0 (t = 0 to 14 hr). Derive the 6-hr UH for the same catchment.", steps: [
            { t: "T = 6, D = 2 ⟹ n = 3 (integer) — superpose 3 copies of the 2-hr UH, lagged 0, 2, 4 hr", w: "Lag-by-2hr column = ordinate column shifted down by one row; lag-by-4hr column = shifted by two rows" },
            { t: "Sum the three columns row-wise at each time → this is the 6-hr DRH, with rainfall excess = 3 cm (3 units of 1 cm each)", w: "t=0→0, 2→6, 4→20, 6→45, 8→79, 10→95, 12→85, 14→45, 16→15, 18→0" },
            { t: "Divide every ordinate by 3 cm to get the 6-hr UH ordinates", w: "6-hr UH = (6-hr DRH)/3cm → t=4→6.67, t=6→15, t=8→26.33, t=10→31.67, t=12→28.33, t=14→15, t=16→5" },
          ], ans: "6-hr UH ordinates as above (rest = 0, 2, 20/3 … tabulated); peak ≈ 31.67 m³/s at t=10hr" },
          { k: "eg", title: "3-hr UH → 6-hr UH by superposition, then to the actual flood hydrograph (S2 p.75)", given: "Ordinates of a 3-hr UHG (m³/s) at 3-hr intervals: 0, 6, 12, 24, 18, 6, 0 (t=0 to 18 hr). Constant base flow BF = 10 m³/s. Rainfall-excess depth of the actual storm = 5 cm. Derive the 6-hr UH, and the 6-hr flood hydrograph.", steps: [
            { t: "Lag the 3-hr UH ordinate column by 3 hr and add (n=2, T=6=2×3)", w: "6-hr DRH of R=2cm: t=0→0, 3→6, 6→18, 9→36, 12→42, 15→24, 18→6, 21→0" },
            { t: "Divide by 2 cm to get the 6-hr UH", w: "6-hr UH: t=0→0, 3→3, 6→9, 9→18, 12→21, 15→12, 18→3, 21→0" },
            { t: "Scale the 6-hr UH by the actual rainfall excess (5 cm) to get the 6-hr DRH for this storm", w: "6-hr DRH (R=5cm) = 6-hr UH × 5: t=0→0, 3→15, 6→45, 9→90, 12→105, 15→60, 18→15, 21→0" },
            { t: "Add the constant base flow (10 m³/s) to get the flood hydrograph", w: "Flood HG = DRH + 10: t=0→10, 3→25, 6→55, 9→100, 12→115, 15→70, 18→25, 21→10" },
          ], ans: "Peak of 6-hr flood hydrograph = 115 m³/s at t = 12 hr" },
          { k: "eg", title: "4-hr triangular UH → peak flood discharge for an actual storm (S2 p.76)", given: "A catchment's 4-hr UH is triangular, time base t_B = 80 hr. Catchment area = 720 km². Base flow = 30 m³/s. φ-index = 0.1 cm/hr. A storm of total depth 4 cm occurs uniformly over 4 hr over the entire catchment. Find (a) the peak of the 4-hr UH, (b) the peak flood discharge due to the storm.", steps: [
            { t: "(a) For the UH itself, rainfall excess = 1 cm = Ah/Ac, triangular area formula", w: "½·Q_p·(80×3600) = 720×10⁶ × 0.01" },
            { t: "Solve for Q_p", w: "Q_p = 50 m³/s  (per cm)" },
            { t: "(b) Rainfall excess of the actual storm: total rainfall − φ-index losses", w: "Rainfall excess = 4 − 0.1×4 = 3.6 cm" },
            { t: "Peak ordinate of DRH = peak of UH × rainfall excess, then add base flow", w: "Peak DRH = 50 × 3.6 = 180 m³/s;  Peak flood = 180 + 30" },
          ], ans: "(a) Q_p(UH) = 50 m³/s;  (b) Peak flood discharge = 210 m³/s" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Superposition tabhi seedha chalta hai jab naya duration purane duration ka exact integer multiple ho (T = n×D). Procedure hamesha same hai: ordinate column ko D-hr ki lag se n baar copy-shift karo, row-wise add karo (yeh naya T-hr DRH hai jiska rainfall excess n cm hai), aur phir n se divide karke T-hr UH nikaal lo. Agar T, D ka integer multiple nahi hai (jaise 2hr se 8hr jahan n=4 hota hai — wait yeh integer hi hai; real non-integer case jaise 2hr se 3hr, n=1.5), tab Case 2 (S-curve, 8.6) use karna padta hai." },
          { k: "trap", t: "Superposition se mila hua composite curve <b>DRH hai, UH nahi</b> — usko UH banane ke liye total rainfall excess (jo ki n × 1cm hota hai) se divide karna mat bhoolo. Yeh step galti se skip karna sabse common mistake hai." },
        ],
      },

      /* ================================================== 8.6 */
      {
        n: "8.6",
        title: "Changing the UH's duration — Case 2: the S-curve (S-hydrograph) method",
        hi: "UH की अवधि बदलना — केस 2: एस-कर्व (S-हाइड्रोग्राफ) विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.74, 76–82, S3 p.34–35" },
          { k: "note", t: "<b>Case 2 — if T ≠ n·D</b> (n not an integer), the superposition method does not directly apply; use the <b>S-curve technique</b> instead. (S2 p.74, 82)" },
          { k: "def", term: "S-curve (Summation Hydrograph)", t: "The hydrograph produced by a continuous effective rainfall at a constant rate, continuing for an <b>infinite duration</b>. It is obtained by adding an infinite series of D-hr unit hydrographs, each lagged by D hr relative to the previous one. After enough terms, the discharge Qs becomes <b>constant</b> — the <b>equilibrium discharge</b>. S3 calls this the Summation Hydrograph / S-Hydrograph: \"it consists of the cumulative discharge of the unit hydrograph\" and \"has an equilibrium discharge which is constant after a certain interval\". (S2 p.76–77; S3 p.34–35)" },
          { k: "eq", expr: "Rate of runoff of the S-curve:  R₀ = 1/D (cm/hr)   ⟹   Equilibrium discharge  Qs = A·R₀ = A/D   ⟹   (standard units)  Qs = 2.778·A/D   [A in km², D in hr, Qs in m³/s]", where: [] },
          { k: "note", t: "If the effective-rainfall intensity used to build the S-curve is, say, 2 cm/hr, the S-curve has effectively been built from a 0.5-hr unit hydrograph (since R₀=1/D ⟹ D=0.5 hr when R₀=2). (S2 p.78)" },
          { k: "h", t: "Two methods to derive the S-curve" },
          { k: "list", items: [
            "<b>Method 1:</b> add an infinite series of UH ordinates, each lagged by D-hr — after enough terms the sum becomes constant (= Qs). (S2 p.78)",
            "<b>Method 2</b> (the practical, tabular method — ESE/GATE conventional): fill the <b>S-curve ordinate</b> and the <b>offset S-curve ordinate</b> (i.e. the S-curve itself lagged by D-hr) simultaneously — each new S-curve ordinate = (UH ordinate at that time) + (offset S-curve ordinate, i.e. previous row's S-curve value, carried forward). (S2 p.78)",
          ] },
          { k: "eg", title: "S-curve from a 2-hr UH, method 1 (S2 p.77)", given: "2-hr UH ordinates (m³/s) at 2-hr intervals: 0, 6, 10, 8, 0, 0, 0 … (t=0 to 16 hr). Build the S-curve.", steps: [
            { t: "Lag the ordinate series by 2, 4, 6, 8 hr and sum all shifted copies at each time step", w: "t=0→0, 2→6, 4→16, 6→24, 8→24, 10→24 …" },
          ], ans: "S-curve becomes constant at Qs = 24 m³/s from t=6hr onward" },
          { k: "eg", title: "S-curve from a 2-hr UH, method 2 — tabular offset method (S2 p.78)", given: "2-hr UH ordinates (m³/s): 0, 4, 9, 18, 40, 30, 20, 0 at t=0,2,4,…,14 hr. Build the S-curve ordinates using the offset-S-curve method.", steps: [
            { t: "S-curve ordinate at each step = UH ordinate + offset S-curve (= previous S-curve value, carried forward by 2 hr)", w: "t=0→0, 2→4+0=4, 4→9+4=13, 6→18+13=31, 8→40+31=71, 10→30+71=101, 12→20+101=121, 14→0+121=121" },
          ], ans: "Qs = 121 m³/s (constant from t=12hr)" },
          { k: "eg", title: "S-curve from a 4-hr UH at 2-hr intervals — two offset passes (S2 p.78–79)", given: "4-hr UH ordinates (m³/s) at 2-hr intervals: 0, 4, 10, 20, 30, 50, 80, 60, 30, 20, 10, 0. Derive the S-curve.", steps: [
            { t: "D = 4 hr and the ordinates are at 2-hr intervals, so successive UHs must be lagged by D = 4 hr, i.e. 2 rows: S(t) = U(t) + S(t − 4 hr)", w: "t=0→0, 2→4, 4→10, 6→20+4=24, 8→30+10=40, 10→50+24=74, 12→80+40=120, 14→60+74=134, 16→30+120=150, 18→20+134=154, 20→10+150=160, 22→0+154=154, 24→160, 26→154 …" },
            { t: "The S-curve swings between 154 and 160 because the alternate-ordinate sums of the given UH differ (0+10+30+80+30+10 = 160; 4+20+50+60+20+0 = 154). The equilibrium discharge is their mean", w: "Qs = ΣU·Δt/D = 314 × 2/4 = 157 m³/s" },
            { t: "What the notes' first pass did — it lagged by only 2 hr (1 row), which is the wrong lag for a 4-hr UH", w: "t=0→0, 2→4, 4→14, 6→34, 8→64, 10→114, 12→194, 14→254, 16→284, 18→304, 20→314, 22→314\n314 = 2 × 157: 4-hr UHs added every 2 hr represent rain at 0.5 cm/hr instead of 1/D = 0.25 cm/hr" },
          ], ans: "Qs ≈ 157 m³/s (S-curve oscillates 154 ↔ 160; the notes print \"154 to 160\" and a first-pass value of 314)" },
          { k: "note", t: "<b>Correction (v45):</b> For a D-hr UH the S-curve is built by lagging successive UHs by <b>D</b> hr — here 4 hr = 2 rows of 2-hr data. The notes' first pass used a 1-row (2-hr) lag and reached 314 m³/s, exactly twice the true equilibrium discharge. The notes' second (4-hr-lag) pass is the correct one: 0, 4, 10, 24, 40, 74, 120, 134, 150, 154, 160, 154, 160, 154 … (its last legible value, 164, should read 154). The 154/160 swing comes from the given UH ordinates themselves, so Qs ≈ ΣU·Δt/D = 314 × 2/4 = <b>157 m³/s</b>. (S2 p.78–79)" },
          { k: "note", t: "<b>Check:</b> for this last example, the source's own two passes of the computation (offset by 2-hr vs. the cross-check continuation) land on slightly different equilibrium values — the student's working explicitly notes \"Qs = 154 to 160 m³/s\", i.e. a small discrepancy between the two passes rather than one clean number. Several individual cell values in the second (red-ink) pass were themselves illegible in the original and are shown here as best-legible readings, not confirmed values. (S2 p.79)" },
          { k: "h", t: "Using the S-curve to get a T-hr UH from a given D-hr UH" },
          { k: "steps", items: [
            "Using the ordinates of the given D-hr UH, build the S-curve (S-curve ordinate and offset S-curve — i.e. S-curve lagged by D-hr — can be filled simultaneously, as above).",
            "Now lag the S-curve by T-hr (the duration of the desired UH) to get a second, offset curve.",
            "Find ΔY = (S-curve ordinate) − (S-curve lagged by T-hr ordinate), at each time.",
            "ΔY represents the ordinates of the T-hr DRH for a rainfall excess of (1/D)×T cm. Scale to get the T-hr UH (which must correspond to exactly 1 cm):  T-hr UH ordinate = ΔY · D/T.",
          ] },
          { k: "eq", expr: "ΔY = S-curve ordinate − S-curve (lag by T-hr) ordinate   ⟹   T-hr UH ordinate = ΔY · D/T", where: [] },
          { k: "eg", title: "2-hr UH → 3-hr UH via the S-curve (S2 p.81)", given: "2-hr UHG ordinates (m³/s) at 1-hr intervals: 0, 8, 20, 43, 80, 110, 130, 150, 180, 170, 140, 100, 70, 40, 20, 0 (t=0 to 15 hr). Derive the 3-hr UH.", steps: [
            { t: "Build the S-curve (B) by adding the 2-hr-offset S-curve (A, i.e. previous S-curve value shifted by 2hr) to each UH ordinate", w: "e.g. t=4: B = 80 + 20(A) = 100;  t=8: B = 180 + 230(A) = 410, etc. — full running table t=0→0, 1→8, 2→20, 3→51, 4→100, 5→161, 6→230, 7→311, 8→410, 9→481, 10→550, 11→581, 12→620, 13→621, 14→640, 15→621" },
            { t: "Lag the S-curve by T=3hr to get column C (C at time t = B at time t−3)", w: "t=3→0, 4→8, 5→20, 6→51, 7→100, 8→161, 9→230, 10→311, 11→410, 12→481, 13→550, 14→581, 15→620" },
            { t: "ΔY = B − C at each time", w: "t=0→0, 1→8, 2→20, 3→51, 4→92, 5→141, 6→179, 7→211, 8→249, 9→251, 10→239, 11→171, 12→139, 13→71, 14→59, 15→1" },
            { t: "Scale: 3-hr UH ordinate = ΔY × D/T = ΔY × 2/3", w: "t=0→0, 1→5.33, 2→13.33, 3→34, 4→61.33, 5→94, 6→119.33, 7→140.67, 8→166, 9→167.33, 10→159.33, 11→114, 12→92.67, 13→47.33, 14→39.33, 15→0.67" },
          ], ans: "3-hr UH as tabulated; peak ≈ 167.33 m³/s at t=9hr" },
          { k: "note", t: "<b>Check:</b> the source's own working explicitly flags an anomaly at t=16hr in this same derivation — a continuation row gives ΔY = −19 (S-curve lagged-by-3hr value exceeding the plain S-curve value), which the student circles and annotates \"abrupt value — No, rise after fall\". This is carried forward here as the source left it: the tail end of this particular table does not close out cleanly, and no value is invented to force it to. (S2 p.81)" },
          { k: "eg", title: "Quick S-curve problem — max ordinate of 3-hr UH (S2 p.82)", given: "2-hr UH ordinates and the resulting ΔY table give a maximum ΔY of 9 at one row (circled \"⑨max\" in the source). Find the corresponding 3-hr UH peak.", steps: [
            { t: "Scale by D/T = 2/3", w: "9 × 2/3" },
          ], ans: "3-hr UH peak = 6 m³/s" },
          { k: "eg", title: "Flood peak from a 3-hr storm (S2 p.82)", given: "A storm of 6.6 cm occurs over a catchment in 3 hr; φ-index = 2 mm/hr; peak of the 3-hr UH = 6 m³/s (from the previous example); base flow = 5 m³/s (assumed — see note).", steps: [
            { t: "Rainfall excess", w: "Runoff = 6.6 − 0.2×3 = 6 cm" },
            { t: "Peak of 3-hr flood hydrograph = peak UH × R + BF", w: "6 × 6 + 5 = 41" },
          ], ans: "Peak of 3-hr flood hydrograph = 41 m³/s" },
          { k: "note", t: "<b>Correction (v45):</b> The notes state the data as \"peak of the 3-hr UH = 5 m³/s\" (and title the problem \"catchment area and flood peak\"), but the working uses 6 × 6 + 5 — i.e. a UH peak of <b>6 m³/s</b> (the result of the previous example, 9 × 2/3) and a base flow of <b>5 m³/s</b>. The given has been aligned with the working: UH peak = 6 m³/s, base flow = 5 m³/s taken as assumed. If 5 m³/s were really the UH peak, the flood peak would be 5 × 6 + BF. No catchment-area computation appears in the source working, so none is shown. (S2 p.82)" },
          { k: "eg", title: "Interpolating a mismatched time step, then finding the flood hydrograph peak (S2 p.82)", given: "2-hr UH ordinates at 2-hr intervals: 0, 6, 10, 8, 0. It is required to find the 3-hr UH and the flood peak for a 3-hr storm of 2.3 cm total rainfall, φ = 0.1 cm/hr, BF = 10 m³/s (the notes word the storm as \"a 4-hr rainfall of 2.3 cm/hr intensity\", but the working, R = 2.3 − 0.1×3, treats it as 2.3 cm in 3 hr — the only reading consistent with using a 3-hr UH) — but the time grid needed is 1-hr, so the 2-hr-spaced ordinates must first be interpolated to 1-hr spacing.", steps: [
            { t: "Interpolate the 2-hr-UH ordinates onto a 1-hr grid, e.g. at t=3hr between the t=2 (value 6) and t=4 (value 10) ordinates", w: "θ₃ = 6 + [(10−6)/(4−2)]×(3−2) = 8;  similarly θ₅ = 10 + [(8−10)/(6−4)]×(5−4) = 9" },
            { t: "Build the S-curve on the 1-hr grid (lag D = 2 hr = 2 rows), lag it by T = 3 hr, take ΔY, then scale by D/T = 2/3", w: "1-hr UH: t=0→0, 1→3, 2→6, 3→8, 4→10, 5→9, 6→8, 7→4, 8→0\nS-curve: 0, 3, 6, 11, 16, 20, 24, 24, 24 …\nΔY = S(t) − S(t−3): 0, 3, 6, 11, 13, 14, 13, 8, 4, 0\nmax ΔY = 14 (t = 5 hr)  ⟹  3-hr UH peak = 14 × 2/3 = 9.33 m³/s (the notes take ΔY = 13 and print 8.66)" },
            { t: "Find rainfall excess: Runoff = 2.3 − 0.1×3 = 2 cm (as stated in the source)", w: "flood HG peak = (3-hr UH peak) × R + BF = 9.33 × 2 + 10 = 28.67" },
          ], ans: "Peak flood hydrograph ordinate = 28.67 m³/s (the notes print 27.22 m³/s)" },
          { k: "note", t: "<b>Correction (v45):</b> On the interpolated 1-hr grid the S-curve is 0, 3, 6, 11, 16, 20, 24 (equilibrium 24 m³/s), and ΔY = S(t) − S(t−3) = 0, 3, 6, 11, 13, 14, 13, 8, 4, 0. The maximum is <b>14</b> at t = 5 hr, not 13, so the 3-hr UH peak is 14 × 2/3 = <b>9.33 m³/s</b> and the flood peak is 9.33 × 2 + 10 = <b>28.67 m³/s</b>. The notes used ΔY = 13 (8.66) and printed 27.22 m³/s — even their own 8.66 × 2 + 10 equals 27.32. The storm description in the given has also been aligned with the working's R = 2.3 − 0.1×3 = 2 cm. (S2 p.82)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "S-curve ko ek 'infinite rain' trick samjho: agar rain hamesha chalta rahe (same D-hr UH ko baar-baar D-hr lag se jodte raho), to ek point baad discharge <b>constant</b> ho jaata hai (Qs = A/D). Yeh constant S-curve tumhe kisi bhi naye duration T ka UH nikaalne deta hai, chahe T, D ka integer multiple ho ya na ho — bas S-curve ko T-hr se lag karo, subtract karo (ΔY), aur D/T se scale karo. Superposition (8.5) is S-curve method ka special/simple case hai jab T=nD." },
          { k: "trap", t: "S-curve method mein hamesha scaling factor <b>D/T</b> hai (reciprocal of T/D), Case-1 superposition mein scaling factor <b>1/n</b> hai — dono ek jaisi cheez (UH ko unit-depth par normalize karna) kar rahe hain, par formula ka structure alag dikhta hai, isse confuse mat hona." },
        ],
      },

      /* ================================================== 8.7 */
      {
        n: "8.7",
        title: "Complex / composite storm hydrograph — deriving UH via successive addition and subtraction",
        hi: "कॉम्प्लेक्स/कंपोज़िट स्टॉर्म हाइड्रोग्राफ — क्रमिक जोड़/घटाव विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.83–86" },
          { k: "def", term: "Complex (composite) hydrograph", t: "If a storm lasts, say, 6 hours but its rainfall intensity is <b>not uniform</b> throughout — e.g. rainfall excess R₁ cm in the first 2 hr, R₂ cm in the next 2 hr, R₃ cm in the last 2 hr — the resulting hydrograph is a <b>6-hr complex DRH</b>, whose total rainfall excess is (R₁+R₂+R₃) cm. Intensity is non-uniform over the full 6 hr, but it is uniform within each 2-hr sub-interval, so a 2-hr unit hydrograph can still be obtained/used. (S2 p.83)" },
          { k: "note", t: "<b>Ordinate of the 6-hr Unit Hydrograph ≠ (Ordinate of the 6-hr complex DRH) / (total rainfall excess)</b> — unlike a simple uniform storm, a complex storm's DRH cannot be converted to a UH by one straight division, because each sub-interval contributed a different depth. (S2 p.83)" },
          { k: "h", t: "Case 1 — given the UH, find the complex DRH" },
          { k: "p", t: "Given the ordinates of the 2-hr unit hydrograph, and the rainfall excess R₁, R₂, R₃ cm in each successive 2-hr sub-interval, add (R₁·U + R₂·U + R₃·U), each lagged by 2 hr relative to the previous, to get the 6-hr complex DRH. Add base flow to get the 6-hr flood hydrograph. (S2 p.84)" },
          { k: "eg", title: "Complex storm — 2-hr UH given, find the flood hydrograph (S2 p.84)", given: "Average storm rainfall over three successive 2-hr intervals: 3, 5, 2 cm. φ-index = 0.2 cm/hr. 2-hr UH ordinates (m³/s) at 2-hr intervals: 0, 10, 40, 70, 50, 20, 10, 6, 0. Base flow = 7 m³/s. Find the resulting flood hydrograph.", steps: [
            { t: "Rainfall excess in each 2-hr interval (subtract φ-index losses)", w: "R₁ = 3 − 0.2×2 = 2.6 cm;  R₂ = 5 − 0.2×2 = 4.6 cm;  R₃ = 2 − 0.2×2 = 1.6 cm" },
            { t: "Scale the UH by each R and lag by 0, 2, 4 hr respectively, then sum row-wise to get the 6-hr complex DRH", w: "e.g. t=4: R₁U=104, R₂U(lag2)=46, R₃U(lag4)=0 → DRH=150;  t=6: 182+184+16=382;  t=8: 130+322+64=516 (peak)" },
            { t: "Add base flow (7 m³/s) at every ordinate", w: "Flood HG: t=0→7, 2→33, 4→157, 6→389, 8→523, 10→401, 12→205, 14→100.6, 16→50.6, 18→16.6, 20→7" },
          ], ans: "Peak flood ordinate = 523 m³/s at t = 8 hr" },
          { k: "h", t: "Case 2 — given the complex DRH, find the UH (successive subtraction)" },
          { k: "p", t: "Here the ordinates of the 6-hr complex DRH are given, along with the rainfall excess in each sub-interval (R₁, R₂, R₃ …), and the <b>unknown</b> is the UH itself. Let the unknown UH ordinates be U₁, U₂, U₃ … Uₙ. Writing the superposition equations (R₁·U lagged 0, R₂·U lagged D, … summing to the known complex-DRH ordinate at each time) gives one new equation per time step, which is solved <b>successively</b>, one unknown at a time, starting from the first ordinate. (S2 p.85)" },
          { k: "eg", title: "Deriving the 3-hr UH from a complex DRH by successive subtraction (S2 p.85)", given: "The 6-hr DRH ordinates resulting from two successive 3-hr rainfall excess values of 2 cm and 4 cm are: t=0→0, 3→120, 6→480, 9→660, 12→460, 15→260, 18→160, 21→100, 24→50, 27→20, 30→0. Derive the 3-hr unit hydrograph.", steps: [
            { t: "Set up the superposition equations: 2U_n + 4U_(n−1) = (DRH ordinate at that row), solving successively for U₁, U₂, U₃ …", w: "2U₁ = 0 ⟹ U₁ = 0" },
            { t: "2U₂ + 4U₁ = 120 ⟹ 2U₂ = 120 ⟹", w: "U₂ = 60" },
            { t: "2U₃ + 4U₂ = 480 ⟹ 2U₃ = 480 − 240 = 240 ⟹", w: "U₃ = 120" },
            { t: "2U₄ + 4U₃ = 660 ⟹ 2U₄ = 660 − 480 = 180 ⟹", w: "U₄ = 90" },
            { t: "2U₅ + 4U₄ = 460 ⟹ 2U₅ = 460 − 360 = 100 ⟹", w: "U₅ = 50" },
            { t: "Continue the same pattern for U₆ … U₁₀", w: "2U₆+4U₅=260⟹U₆=30;  2U₇+4U₆=160⟹U₇=20;  2U₈+4U₇=100⟹U₈=10;  2U₉+4U₈=50⟹U₉=5;  2U₁₀+4U₉=20⟹U₁₀=0" },
          ], ans: "3-hr UH ordinates: U₁…U₁₀ = 0, 60, 120, 90, 50, 30, 20, 10, 5, 0 (at t = 0, 3, 6 … 27 hr)" },
          { k: "eg", title: "Complex storm with a flagged rainfall-excess value (S2 p.86)", given: "A 3-hr storm has rainfall intensity 2.5 cm/hr in the 1st hour, 0 cm/hr in the 2nd hour, 3.5 cm/hr in the 3rd hour; φ-index = 0.5 cm/hr; BF = 10 m³/s. 1-hr UH ordinates given, with the complex-DRH table built the same way as above. Find the maximum ordinate of the 3-hr flood hydrograph.", steps: [
            { t: "Rainfall excess in each hour", w: "R₁ = (2.5−0.5)×1 = 2cm;  R₂ = 0;  R₃ = (3.5−0.5)×1, written in the source as \"30cm\"" },
            { t: "Build R₁U + R₂U + R₃U (lagged by 1hr each) — the running table peaks at 42 for the complex DRH", w: "max complex-DRH ordinate = 42 m³/s" },
            { t: "Add base flow; the source's first attempt was overwritten/corrected in blue ink", w: "42 + 10" },
          ], ans: "Maximum ordinate of 3-hr flood hydrograph = 52 m³/s" },
          { k: "note", t: "<b>Check:</b> the source itself flags this R₃ value — the table header for this column reads \"R₃U = 3U\" (implying R₃ = 3 cm) and a working row shows R₃U = 30 (consistent with R₃ = 3 cm if U at that row = 10), yet the rainfall-excess line explicitly writes <b>R₃ = \"30cm\"</b>, marked [sic] in the transcript as apparently inconsistent with its own column header. Both figures are kept here exactly as the source gives them — R₃ is almost certainly meant to read 3 cm, but the original notebook literally shows \"30cm\" at that line, so no value has been silently corrected. Similarly, the maximum ordinate was first mis-added and then corrected to 52 by the student in blue ink — both the original scratch value and the corrected 52 are part of the same working. (S2 p.86)" },
          { k: "eg", title: "Deriving the 2-hr UH's peak from a 4-hr composite DRH (S2 p.86)", given: "A storm of 4 hr occurs with R₁ = 2 cm in the first 2 hr and R₂ = 4 cm in the next 2 hr (R₂ is not stated in the notes but is what the working uses). 4-hr DRH ordinates at 2-hr intervals (t=0,2,4,6,8): 0, 4, 10, 6, 0. Find the maximum ordinate of the 2-hr UH.", steps: [
            { t: "Set up 2U_n + 4U_(n−1) = DRH ordinate, solve successively", w: "2U₁=0⟹U₁=0;  2U₂+4U₁=4⟹U₂=2;  2U₃+4U₂=10⟹U₃=1;  2U₄+4U₃=6⟹U₄=1;  2U₅+4U₄=0⟹U₅=−2, a physically impossible negative ordinate, set to 0 (flagged \"abrupt value here\" in the source)" },
          ], ans: "Maximum ordinate of the 2-hr UH = 2 m³/s" },
          { k: "note", t: "<b>Correction (v45):</b> The equations 2U_n + 4U_(n−1) imply R₂ = 4 cm in the second 2-hr block, which the notes do not state — it has been added to the given. Solving honestly, 2U₅ + 4×1 = 0 gives U₅ = −2 (the notes write U₅ = 0 directly); the negative value shows the DRH data are slightly inconsistent (ΣDRH = 20 needs ΣU = 20/6 ≈ 3.33, but the derived ordinates sum to 4). The peak, U₂ = 2 m³/s, is unaffected. (S2 p.86)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Complex-storm problems do hi direction mein chal sakte hain: (1) UH pata hai, rainfall excess pata hai → DRH nikaalo (seedha superposition, jaisa 8.5 mein), ya (2) DRH pata hai, rainfall excess pata hai → UH ultā nikaalo (successive subtraction). Dusra wala zyada tricky hai kyunki har naya equation sirf <b>ek</b> naya unknown introduce karta hai (U_n), baki saare (U_1...U_n-1) pehle se maalum hote hain pichle steps se — isi tarah equations ek-ek karke solve hote hain, simultaneous solve karne ki zaroorat nahi padti jab tak R's integer multiples mein diye hain aur sequence clean ho." },
          { k: "trap", t: "Successive-subtraction wale case mein agar koi beech ka U negative ya 'abrupt' (unexpected rise after a fall) nikal aaye, to woh physically galat hai (UH kabhi negative ya multiple local maxima jaisa random nahi hota) — iska matlab hai ya to diye gaye DRH values mein rounding error hai, ya calculation mein galti hui. Jaisa S2 ke apne worked examples mein bhi flag hua hai (p.81, p.86), aise values ko seedha accept na karo, balki 0 ya nearest-consistent value maan kar aage badho jab tak original source khud yahi karta dikh raha ho." },
        ],
      },

      /* ================================================== 8.8 */
      {
        n: "8.8",
        title: "Snyder's Synthetic Unit Hydrograph",
        hi: "स्नाइडर की सिंथेटिक यूनिट हाइड्रोग्राफ",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.87–89, S3 p.35" },
          { k: "def", term: "Synthetic Unit Hydrograph (Snyder's method)", t: "An empirical method giving the relationship between discharge and time for a catchment for which <b>detailed rainfall-gauging data is not available</b>. Developed by Snyder, based on a set of empirical relations with <b>regional validity</b>, for finding the discharge and base period of the UH from catchment geometry alone. Based on studies of catchments in the highland area of the USA. (S2 p.87–88; S3 p.35)" },
          { k: "list", items: [
            "<b>Step ① — Basin lag (t_p):</b>  t_p = C_t·(L·L_ca)^0.3,  where L = distance from the most remote point of the basin to the outlet along the main stream (km), L_ca = distance from the centroid (C.G.) of the basin to the outlet (km), C_t = regional constant.",
            "<b>Step ② — Standard duration of rainfall:</b>  t_R = t_p / 5.5 (hours).",
            "<b>Step ③ — If a non-standard duration t_R′ is actually given,</b> the basin lag must be revised:  t_p′ = (21/22)·t_p + t_R′/4.",
            "<b>Step ④ — Peak discharge:</b>  Q_p′ = 2.78·C_p·A / t_p′,  with A in km², t_p′ in hr, Q_p′ in m³/s, C_p = regional constant.",
            "<b>Step ⑤ — Width of the hydrograph</b> at 50% and 75% of peak discharge, to help sketch the curve:  W₅₀ = 5.87/(q_V)^1.08 hr, where q_V = Q_p′/A (m³/s/km²); and  W₇₅ = W₅₀ / 1.75 hr.",
            "<b>Step ⑥ — Base period (for a small catchment):</b>  t_B′ = 72 + 3·t_p′  hours.",
          ] },
          { k: "eq", expr: "t_p = Ct(L·Lca)^0.3  ;  tR = tp/5.5  ;  tp' = (21/22)tp + tR/4  ;  Qp' = 2.78·Cp·A/tp'  ;  W50 = 5.87/(qV)^1.08  ;  W75 = W50/1.75  ;  tB' = 72+3tp'", where: [
            ["Ct, Cp", "regional constants (catchment-specific calibration)"],
            ["qV", "Qp'/A, m³/s per km²"],
          ] },
          { k: "eg", title: "Snyder's method — full worked example (IAS-2006) (S2 p.87–89)", given: "Catchment area A = 2100 km². Length of main stream from gauging station to the most remote point, L = 80 km. Distance from the basin outlet to the point on the stream nearest the centroid of the basin, L_ca = 50 km. C_t = 1.85, C_p = 0.45. Non-standard rainfall duration t_R = 3 hr (given). Calculate the width of the 3-hr unit hydrograph at 50% and 75% of peak discharge.", steps: [
            { t: "Step ① — basin lag", w: "t_p = C_t(L·L_ca)^0.3 = 1.85×(80×50)^0.3" },
            { t: "⟹", w: "t_p = 22.27 hr" },
            { t: "Step ② — standard duration", w: "t_R(standard) = t_p/5.5 = 22.27/5.5 = 4.05 hr" },
            { t: "Since given t_R = 3 hr ≠ 4.05 hr, it is non-standard, so revise the basin lag (Step ③)", w: "t_p′ = (21/22)×t_p + t_R/4 = (21/22)×22.27 + 3/4" },
            { t: "⟹", w: "t_p′ = 22.00 hr" },
            { t: "Step ④ — peak discharge", w: "Q_p′ = 2.78·C_p·A/t_p′ = (2.78×0.45×2100)/22.00" },
            { t: "⟹", w: "Q_p′ = 119.41 m³/s" },
            { t: "Unit peak flow per unit area", w: "q_V = Q_p′/A = 119.41/2100 = 0.0568 m³/s/km²" },
            { t: "Step ⑤ — width at 50% peak", w: "W₅₀ = 5.87/(q_V)^1.08 = 5.87/(0.0568)^1.08 ≈ 129.99" },
            { t: "Width at 75% peak", w: "W₇₅ = W₅₀/1.75 = 130/1.75" },
            { t: "Step ⑥ — base period, for completeness", w: "t_B = 72 + 3t_p′ = 72 + 3×22" },
          ], ans: "t_p′ = 22.00 hr, Q_p′ = 119.41 m³/s, W₅₀ ≈ 130 hr, W₇₅ ≈ 74.29 hr, t_B = 138 hr" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Snyder's method ka poora flow yaad rakhne ke liye ek seedhi chain socho: <b>geometry (L, Lca) → tp → tR(standard) → compare karo given duration se → agar match nahi karta to tp revise karo (tp') → Qp' (peak) → W50, W75 (shape) → tB (base)</b>. Har constant (Ct, Cp) catchment-specific hoti hai aur sirf question mein diya jaata hai, calculate nahi karni padti. Yeh poora method tab use hota hai jab detailed rainfall/runoff records available nahi hain — sirf catchment ki shape/geometry se UH 'synthesize' kar rahe ho." },
          { k: "trap", t: "Step③ ka revision (t_p → t_p′) sirf tab zaroori hai jab diya gaya rainfall duration standard duration (t_p/5.5) se <b>alag</b> ho. Agar given duration already standard duration ke barabar nikal aaye, to t_p′ = t_p hi rahega, revision ki zaroorat nahi — par exam mein hamesha check karo, assume mat karo." },
        ],
      },

      /* ================================================== 8.9 */
      {
        n: "8.9",
        title: "Instantaneous Unit Hydrograph (IUH)",
        hi: "तात्क्षणिक यूनिट हाइड्रोग्राफ (IUH)",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.89–91" },
          { k: "def", term: "Instantaneous Unit Hydrograph (IUH)", t: "The limiting case of a unit hydrograph as its duration D → 0, denoted U(t) or U(0,t). It is a conceptual UH, resulting from 1 cm of rainfall excess falling instantaneously (over zero time) on the catchment, having a single peak discharge and a finite base width. As D decreases, the UH's peak increases (Qp = A·R₀ = A·(1/D), so Qp → ∞ as D → 0 only in the limiting mathematical sense — Qp↑ as D↓). (S2 p.89)" },
          { k: "h", t: "Derivation of the IUH from the S-curve" },
          { k: "p", t: "Take two S-curves built from a D-hr UH, one of them shifted by a very small time increment dt. Their difference (S₁ − S₂ = ΔS, i.e. ΔY) is the DRH of a 'dt-hr' storm whose rainfall excess is (1/D)×dt cm — exactly the S-curve method of §8.6, with the lag T shrunk to the infinitesimal dt. Scaling this ΔS by D/dt (as in the standard S-curve formula) and taking the limit dt → 0 gives the ordinate of the IUH. (S2 p.90)" },
          { k: "eq", expr: "U(t) = lim[dt→0] (S1−S2)·D/dt = lim[dt→0] ΔS·D/dt = (dS/dt)·D = (dS/dt)·(1/R₀)", where: [
            ["dS/dt", "slope of the S-curve at time t"],
            ["R₀", "the S-curve's rainfall-excess rate, R₀ = 1/D"],
          ] },
          { k: "note", t: "<b>Special case:</b> if D = 1 hr (i.e. the IUH is derived from a 1-hr unit hydrograph), then R₀ = 1/D = 1 cm/hr, and the formula simplifies: <b>ordinate of the IUH at any time t = dS/dt = slope of the S-curve</b>. This simplification holds <b>only</b> when the S-curve has been built from a 1-hr unit hydrograph — for any other base duration D, the full U(t) = (dS/dt)·D relation must be used. (S2 p.90–91)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "IUH ko '0-hour UH' samajh lo — ek theoretical UH jiska duration zero hai. Isko directly measure nahi kar sakte (zero-duration storm real mein possible nahi), par S-curve ke slope (dS/dt) se mathematically nikaal sakte ho. Jaise-jaise D chhota hota jaata hai, UH ka peak zyada sharp aur tall hota jaata hai (Qp = A/D, D↓ se Qp↑) — IUH us trend ki limiting/sabse extreme shape hai." },
          { k: "trap", t: "'Ordinate of IUH = slope of S-curve' wala shortcut <b>sirf 1-hr UH</b> se bani S-curve ke liye sahi hai. Agar S-curve kisi doosre D (jaise 2hr ya 3hr UH) se banaya gaya hai, to slope ko D se multiply karna hi padega (U(t) = (dS/dt)×D) — seedha slope le lena galat answer dega." },
        ],
      },

      /* ================================================== 8.10 */
      {
        n: "8.10",
        title: "Factors affecting the shape of the runoff hydrograph",
        hi: "रनऑफ हाइड्रोग्राफ के आकार को प्रभावित करने वाले कारक",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.92–95" },
          { k: "list", items: [
            "<b>(1) Characteristics of rainfall</b> — intensity, direction of storm movement, wind characteristics, etc.",
            "<b>(2a) Area of catchment</b> — hydrograph peak increases with catchment area. In a <b>small</b> catchment, the overland-flow phase dominates over the channel-flow phase; in a <b>large</b> catchment, the channel-flow phase dominates over the overland-flow phase.",
            "<b>(2b) Shape of catchment</b> — governs the time taken for a drop of water from the most remote part of the catchment to reach the outlet, and hence the hydrograph's peak and symmetry: a <b>fan-shaped (semicircular)</b> basin gives a symmetric hydrograph with t_pk = t_s = t_B/2; an elongated/leaf-shaped basin with tributaries concentrated <b>near the outlet</b> gives an <b>early, unsymmetric peak</b> (t_pk < t_B/2); one with tributaries concentrated <b>away from the outlet</b> gives a <b>delayed peak</b> (t_pk > t_B/2).",
          ] },
          { k: "def", term: "Isochrones", t: "Lines joining points in a catchment map that have an equal time of travel of surface runoff to the outlet — all tributaries crossed by one isochrone take the same time to reach the main channel. (S2 p.93)" },
          { k: "list", items: [
            "<b>Fan-shaped catchment</b> → greater runoff/peak, because tributaries are of nearly the same size and have nearly the same (smaller) time of travel.",
            "<b>Fern-leaf catchment</b> → smaller runoff/peak, because tributaries are of different sizes and have different (and larger) times of travel. Stream orders (1, 2, 3, 4 …) describe this branching.",
          ] },
          { k: "h", t: "(2b, continued) Quantifying catchment shape — Form factor and Compactness coefficient" },
          { k: "def", term: "Form Factor (F.F.)", t: "F.F. = (average width of catchment, B) / (axial length of basin, L). Since A = B·L, B = A/L, so F.F. = A/L². A <b>higher</b> F.F. (larger area for the same length) means channel flow is more predominant, with less waterlogging. (S2 p.93–94)" },
          { k: "eq", expr: "F.F. = B/L = A/L²", where: [] },
          { k: "def", term: "Compactness Coefficient (C.C.)", t: "C.C. = (perimeter of the basin, P) / (circumference of a circle of the same area as the basin). If r = √(A/π), then C.C. = P/(2πr) = P/(2√(πA)). A <b>higher</b> C.C. (small catchment, more irregular/elongated shape relative to a circle) means the overland-flow phase is more predominant, with more waterlogging. (S2 p.94)" },
          { k: "eq", expr: "r = √(A/π)  ;  C.C. = P/(2πr) = P/(2√(πA))", where: [] },
          { k: "cmp", t: "Practical significance of the two shape factors (S2 p.94)", cols: ["Effect"], rows: [
            ["Form factor (F.F. = A/L²)", "Area ↑ relative to length → channel flow predominant, less waterlogging"],
            ["Compactness coefficient (C.C.)", "Area ↓ (more irregular shape) → overland-flow phase predominant, more waterlogging"],
          ] },
          { k: "h", t: "(3), (4), (5) Drainage density, stream density, urbanisation" },
          { k: "def", term: "Drainage Density (DD)", t: "DD = (total channel length, L) / (total drainage area, A). As channel length L increases, DD increases. For a <b>fixed</b> catchment area, higher DD means more channel-space to discharge water quickly — a <b>higher, narrower</b> hydrograph peak; lower DD gives a <b>lower, broader</b> peak. (S2 p.94)" },
          { k: "eq", expr: "DD = L/A", where: [] },
          { k: "def", term: "Stream Density (SD)", t: "SD = (number of streams of all orders) / (catchment area, A). Higher SD → higher, narrower hydrograph peak; lower SD → lower, broader peak (same logic as drainage density, but counting streams rather than their total length). (S2 p.95)" },
          { k: "eq", expr: "SD = (No. of streams of all orders) / A", where: [] },
          { k: "def", term: "Urbanisation", t: "Broadly, clearing/channelising the river basin for easier drainage of water. Its effect on the hydrograph is a <b>peakier, earlier</b> curve after urbanisation (impervious surfaces and efficient drains cut infiltration losses and travel time), compared to a flatter, later curve before urbanisation. (S2 p.95)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh poora section ek hi logic baar-baar repeat karta hai: jo bhi factor <b>runoff ko jaldi aur concentrated</b> tareeke se outlet tak pahunchata hai (chhota catchment, fan-shape, high drainage/stream density, urbanisation), woh hydrograph ko <b>tall aur narrow</b> banata hai. Jo factor runoff ko <b>spread out/slow</b> karta hai (bada catchment, elongated/fern-leaf shape, low density), woh hydrograph ko <b>flat aur broad</b> banata hai. Form factor aur compactness coefficient sirf is 'shape' intuition ko numbers mein convert karne ke tareeke hain." },
          { k: "real", t: "Bridge aur urban-drainage design mein isochrones aur drainage density practically bahut use hoti hain — isochrone map se pata chalta hai catchment ka kaunsa hissa 'jaldi' contribute karega (fast response zone), aur drainage density ka trend (jaise ek hi shehar ka 1990 vs 2020 ka DD) directly dikhata hai ki urbanisation ne hydrograph peak ko kitna sharp kar diya hai, jo flood-risk assessment ke liye zaroori hai. (S2 p.94–95)" },
        ],
      },

      /* ================================================== 8.11 */
      {
        n: "8.11",
        title: "Quick revision — Hydrographs & Unit Hydrograph Theory",
        hi: "त्वरित पुनरावृत्ति — हाइड्रोग्राफ एवं यूनिट हाइड्रोग्राफ सिद्धांत",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Hydrograph = Q vs t. DR = SRO + prompt interflow ≈ SRO. Flood HG = DRH + BF (S2 p.64–65; S3 p.34).",
            "Hydrograph parts: Rising limb (A–B, concave, concentration curve), Crest segment (B–C–D, peak at C), Falling/Recession limb (D–E, concave). B, D are points of inflection (S2 p.66; S3 p.37).",
            "t_PK, t_s, t_B; Lag time t_L = t_PK − D/2; Time of concentration t_c (two definitions) and Kirpich formula t_c = 0.01947K^0.77 (S2 p.67–69).",
            "Base-flow separation → DRH ordinates O_i=Q_i−B (O₁=Oₙ=0) → Area of DRH → R = Area/Catchment area = 0.36ΣO_i·t/A, or triangular R = ½t_base·Q_peak/A (S2 p.69–71; S3 p.38–39, 42–45).",
            "Unit Hydrograph (Sherman): DRH of 1cm rainfall excess, uniform intensity, duration D. Basic assumptions: Linear response/superposition, Time invariance, uniform intensity, uniform spatial distribution. Valid for 2–5000 km² (S2 p.71–73; S3 p.39–41).",
            "T=n·D → method of superposition (add n lagged copies, ÷n). T≠n·D → S-curve method: build S-curve (Qs=2.778A/D), lag by T, ΔY=S−S(lag T), T-hr UH=ΔY·D/T (S2 p.74–82).",
            "Complex storm: Case1 UH→complex DRH (direct superposition with different R's); Case2 complex DRH→UH (successive subtraction, one new unknown per step) (S2 p.83–86).",
            "Snyder's Synthetic UH: tp=Ct(L·Lca)^0.3 → tR=tp/5.5 → (if non-standard) tp'=(21/22)tp+tR/4 → Qp'=2.78CpA/tp' → W50=5.87/(qV)^1.08, W75=W50/1.75 → tB'=72+3tp' (S2 p.87–89).",
            "IUH: limiting UH as D→0; U(t)=(dS/dt)·D; if D=1hr, U(t)=dS/dt=slope of S-curve (S2 p.89–91).",
            "Factors affecting hydrograph shape: rainfall characteristics; catchment area & shape (fan vs fern-leaf, isochrones); Form factor FF=A/L²; Compactness coefficient CC=P/(2√(πA)); Drainage density DD=L/A; Stream density SD=N/A; urbanisation (S2 p.92–95; S3 p.37–38).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Flood Hydrograph − Base Flow = DRH; DRH ÷ Rainfall-excess depth (cm) = Unit Hydrograph — and the reverse chain (× R, + BF) rebuilds the flood hydrograph (S2 p.71).",
            "Ordinate of DRH = Ordinate of UH × R — but only when DRH and UH share the <b>same</b> duration; otherwise first fix the duration via superposition or S-curve (S3 p.40).",
            "Longer storm/UH duration D → larger base period t_B but smaller peak Q_p, for the same 1 cm rainfall excess (areas under all unit-depth UHs of a catchment must differ in height to keep the same enclosed volume) (S2 p.73).",
            "S-curve's equilibrium discharge Qs = 2.778A/D is the backbone of the T≠nD duration-change method; T-hr UH ordinate = ΔY·D/T where ΔY = S-curve − S-curve lagged by T-hr (S2 p.76–81).",
            "A tall-narrow hydrograph and a flat-broad hydrograph both point to the same set of causes: small/fan-shaped/steep/urbanised/high-density catchments give the first; large/elongated/low-density catchments give the second (S2 p.92–95; S3 p.38).",
          ] },
        ],
      },

    ],
  });
})();
