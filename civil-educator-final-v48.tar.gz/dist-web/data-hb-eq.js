/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: EARTHQUAKE ENGINEERING
   ------------------------------------------------------------
   The eleventh handbook. It follows the design flow of IS 1893
   (the loads) and IS 13920 (the ductile detailing), from where
   the force comes from to how a frame is detailed to survive it.

   One idea runs through it: we do not design a building to be
   undamaged in the great earthquake — we design it not to
   collapse. Everything follows from that honest bargain: accept
   damage, steer it to safe places, and keep everyone alive.

   Values and formulae follow IS 1893:2016 and IS 13920:2016,
   named at the point of use. Confirm against the current code
   before using a value on real work. AI must never fabricate a
   clause number, and none here are invented.

   Chapters 1–2 here; later chapters follow in data-hb-eq2.js on.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "eq",
  subject: "earthquake",
  name: "Earthquake Engineering",
  hi: "भूकंप अभियांत्रिकी",
  icon: "〰",
  blurb: "Force kahan se aati hai, base shear kaise nikalte hain, aur frame ko na girne layak kaise detail karte hain — IS 1893 aur IS 13920 ka poora flow.",
  note: "The design flow follows IS 1893:2016 and IS 13920:2016, named where they apply. Values are quoted for learning; confirm against the current code before using one on real work.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "eq-1",
      n: 1,
      title: "Where the Force Comes From, and the Honest Bargain",
      hi: "बल कहाँ से आता है",
      blurb: "Why an earthquake loads a building through inertia, why heavier is worse, and the design philosophy that accepts damage to prevent collapse.",
      mins: 24,
      sections: [
        {
          n: "1.1",
          title: "It shakes the ground, not the building",
          hi: "यह ज़मीन हिलाता है",
          blocks: [
            { k: "p", t: "An earthquake does not push against a building the way wind does. It jerks the ground sideways, and the building's mass — through inertia — tries to stay where it was. The columns are dragged along with the ground while the floors lag behind, so the building is bent. The force is not applied from outside; it is generated inside, by the building's own reluctance to move." },
            { k: "dia", id: "hb-eq-inertia", cap: "How ground motion becomes an inertia force in the building." },
            { k: "p", t: "Because the force is mass times acceleration, a startling rule follows: a heavier building attracts a larger earthquake force. This is the opposite of every other structural load, where more mass just means more to carry. In a quake, mass is the enemy — which is why seismic design prizes lightness, and why a heavy water tank on the roof is so dangerous." },
            { k: "trap", t: "Do not picture the earthquake as a horizontal wind that a stronger, heavier building resists better. The heavier building is loaded harder, not protected. Adding mass to 'brace' against a quake makes things worse. The instinct that works for gravity and wind fails completely for earthquakes — the force follows the mass." },
            { k: "eg", title: "Example 1.1 — Mass is the enemy",
              given: "The building of Example 3.1 has a seismic weight of 10,000 kN and a design base shear of 571 kN. The owner adds heavy marble flooring and a rooftop water tank, raising W by 15%.",
              steps: [
                { t: "Base shear is proportional to W", w: "Vb = Ah W, and Ah does not change (the period changes only slightly)\nnew Vb ≈ 571 × 1.15 = 657 kN" },
                { t: "Where the extra mass sits", w: "mass at the roof is the worst place: the distribution Qi ∝ Wi hi² (Example 3.2) gives roof mass the largest share of the force" },
              ],
              ans: "About 15% more earthquake force — some 86 kN — with no change in the structure that must resist it. Additions of mass after design are a seismic change, not a finishing decision." },
          ],
        },
        {
          n: "1.2",
          title: "The honest bargain — no collapse, not no damage",
          hi: "ईमानदार सौदा",
          blocks: [
            { k: "p", t: "You could design a building to ride out the greatest possible earthquake completely undamaged — and it would cost many times what the building is worth, because that quake might come once in a thousand years or never. So the code strikes an honest bargain instead: a graded target matched to how often each size of quake occurs." },
            { k: "dia", id: "hb-eq-philosophy", cap: "The three levels of earthquake and what the building must do in each." },
            { k: "list", items: [
              "<strong>Minor, frequent quakes</strong> — the building stays elastic, with no damage at all.",
              "<strong>Moderate quakes</strong> — some cracking is accepted, but the damage is repairable and no one is endangered.",
              "<strong>The rare, severe quake</strong> — the building may be badly damaged, even beyond repair, but it must NOT collapse — everyone must be able to get out.",
            ] },
            { k: "note", t: "This is the single most important idea in the subject, and it reframes everything that follows. When a later chapter accepts that beams will crack and hinge, or that the structure will yield, it is not a flaw in the design — it is the design working as intended. The goal is life safety. A building that sways, cracks and stands has succeeded; only collapse is failure." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "eq-2",
      n: 2,
      title: "Seismic Zones and the Design Spectrum",
      hi: "भूकंप ज़ोन और डिज़ाइन स्पेक्ट्रम",
      blurb: "How the map of India's hazard becomes a zone factor, and how the ground's shaking at a building's own rhythm is captured by the design spectrum.",
      mins: 28,
      sections: [
        {
          n: "2.1",
          title: "Zones — the hazard on a map",
          hi: "ज़ोन",
          blocks: [
            { k: "p", t: "India is divided into seismic zones — II, III, IV and V — by how severe the earthquake hazard is, based on past earthquakes and geology. Zone V (the Himalaya, the north-east, Kutch) is the most severe; Zone II the least. Each zone carries a zone factor Z that scales the design force." },
            { k: "def", term: "Zone factor (Z)", t: "A number from the seismic zone map (IS 1893) representing the severity of the expected ground motion in that region. It is larger in high-hazard zones and directly scales the design force — so the same building is designed for a bigger force in Kutch than in the Deccan." },
            { k: "real", t: "The zone is set by where the building is, not by choice, and it can dominate the design. An identical apartment block is designed for a far larger earthquake force in Guwahati (Zone V) than in Nagpur (Zone II) — the structure, the column sizes, the detailing all step up. <strong>Location is the first and biggest seismic decision, and it is already made for you by the map.</strong>" },
            { k: "cmp", t: "Zone factors, IS 1893 (Part 1):2016", cols: ["Z"], rows: [
              ["Zone II", "0.10"], ["Zone III", "0.16"], ["Zone IV", "0.24"], ["Zone V", "0.36"],
            ]},
          ],
        },
        {
          n: "2.2",
          title: "The design spectrum — shaking at your rhythm",
          hi: "डिज़ाइन स्पेक्ट्रम",
          blocks: [
            { k: "p", t: "How hard a building is shaken depends not just on the quake but on the building's own natural rhythm — its fundamental period — and on the soil beneath it. The design spectrum captures this: it gives the acceleration a building feels as a function of its period, for each soil type." },
            { k: "def", term: "Natural period (T)", t: "The time a building takes to sway back and forth once, on its own. Tall, flexible buildings have long periods; short, stiff ones have short periods. For an RC frame the code estimates it from the height: T = 0.075 h^0.75 for a bare RC moment frame (0.085 h^0.75 for steel), and T = 0.09 h/√d for buildings with masonry infill, where d is the base dimension in the direction considered." },
            { k: "def", term: "Spectral acceleration (Sa/g)", t: "The acceleration the building feels, read off the design spectrum at its period T for the site's soil type. Softer soils amplify the shaking and shift the peak, so the spectrum has a different curve for hard, medium and soft soil. This is the last factor needed for the design force." },
            { k: "trap", t: "Resonance is the danger the spectrum warns of. If a building's natural period matches the period at which the ground (especially soft soil) shakes hardest, the two reinforce each other and the building is shaken far more violently — the same reason a swing pushed at its own rhythm goes higher. Soft soil sites and mid-rise buildings are a notorious pairing for exactly this, and the spectrum's soil curves exist to capture it." },
            { k: "cmp", t: "Design spectrum for the equivalent static method (5% damping)", cols: ["Plateau Sa/g = 2.5", "Then Sa/g ="], rows: [
              ["Type I — rock / hard soil", "0.10 ≤ T ≤ 0.40 s", "1.00/T up to 4 s"],
              ["Type II — medium / stiff soil", "0.10 ≤ T ≤ 0.55 s", "1.36/T up to 4 s"],
              ["Type III — soft soil", "0.10 ≤ T ≤ 0.67 s", "1.67/T up to 4 s"],
            ]},
            { k: "note", t: "Zone factors, plateau limits and period formulas as listed by the <a href=\"https://infralens.in/knowledge/is-1893-earthquake-design-india-2016-step-by-step\" target=\"_blank\" rel=\"noopener\">InfraLens step-by-step summary</a> and <a href=\"https://help.autodesk.com/cloudhelp/2027/ENU/RSAPRO-UsersGuide/files/GUID-1DFE3234-1AF0-4A7D-8744-C91C323C827E.htm\" target=\"_blank\" rel=\"noopener\">Autodesk Robot's IS 1893:2016 documentation</a>. A built-in check: each descending branch meets the plateau where it should — 2.5 × 0.40 = 1.00, 2.5 × 0.55 ≈ 1.36, 2.5 × 0.67 ≈ 1.67. Below T = 0.1 s the spectrum rises from 1.0 to 2.5." },
            { k: "eg", title: "Example 2.1 — Same building, three soils",
              given: "Find Sa/g for periods of 0.3 s, 0.5 s and 1.0 s on each soil type.",
              steps: [
                { t: "T = 0.3 s", w: "on the plateau for all three soils → 2.5, 2.5, 2.5" },
                { t: "T = 0.5 s", w: "rock: 1.00/0.5 = 2.00;  medium: 2.5;  soft: 2.5" },
                { t: "T = 1.0 s", w: "rock: 1.00;  medium: 1.36;  soft: 1.67" },
              ],
              ans: "A flexible 1-second building on soft soil is designed for 67% more force than the same building on rock — the spectrum's way of encoding soft-soil amplification." },
          ],
        },
      ],
    },

  ],
});
