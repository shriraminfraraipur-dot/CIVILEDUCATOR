/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   Chapter 3 — Chain and Tape Surveying
   Chapter 4 — Compass Surveying
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "sv-3",
      n: 3,
      title: "Chain and Tape Surveying",
      hi: "चेन और टेप सर्वेक्षण",
      blurb: "Measuring distance and nothing else — and the five corrections that turn a tape reading into a length you can plot.",
      mins: 50,
      sections: [

        {
          n: "3.1",
          title: "The instruments",
          hi: "उपकरण",
          blocks: [
            { k: "p", t: "Chain surveying measures <strong>distances only</strong>. No angles are observed at all, which is why the framework has to be made of triangles — a triangle is the one figure whose shape is settled by its side lengths alone." },
            { k: "list", items: [
              "<strong>Metric chain</strong> (IS 1492) — 5, 10, 20 or 30 m; every link is 0.2 m, so a 20 m chain has 100 links and a 30 m chain has <strong>150</strong>. Tallies mark every metre on 5 and 10 m chains and every 5 m on 20 and 30 m chains so a length can be read quickly. Robust, easy to repair in the field, and not very accurate.",
              "<strong>Steel tape</strong> — 20 m, 30 m or 50 m. Far more accurate than a chain and far more easily damaged. This is what precise work uses.",
              "<strong>Invar tape</strong> — a nickel-steel alloy (about 36% nickel) with a very small coefficient of expansion — <a href=\"https://www.rcet.org.in/uploads/academics/regulation2024/rohini_35139680849.pdf\" target=\"_blank\" rel=\"noopener\">RCET surveying notes</a> quote 0.122 × 10⁻⁶ /°C, roughly a hundredth of steel's. Used for base lines and precise work, expensive and soft.",
              "<strong>Synthetic (linen or glass-fibre) tape</strong> — for offsets and rough work only. It stretches, and it must never be used for a line that matters.",
              "<strong>Arrows, ranging rods, pegs, plumb bobs, cross-staff or optical square</strong> — for marking, for lining in, and for setting out the right angles that offsets need.",
            ]},
            { k: "note", t: "Older chains are still met in records and in examinations. Gunter's chain is 66 ft of 100 links — chosen because 10 square chains make exactly an acre, which is a wonderfully practical piece of eighteenth-century design. The engineer's chain is 100 ft of 100 links, and the Indian <strong>revenue chain</strong> 33 ft of 16 links, used for land records. All are obsolete for new work, but a boundary plan from 1950 will be in one of them." },
            { k: "note", t: "Sources for the chain data: <a href=\"https://www.rcet.org.in/uploads/academics/regulation2024/rohini_35139680849.pdf\" target=\"_blank\" rel=\"noopener\">RCET surveying notes</a> (20 m = 100 links, 30 m = 150 links) and <a href=\"https://mappingaround.in/chain-and-tape-survey/\" target=\"_blank\" rel=\"noopener\">MappingAround</a> (lengths, tally spacing, revenue/Gunter's/engineer's chains). <b>Correction (v35):</b> an earlier version said both metric chains have 100 links; only the 20 m chain does." },
          ],
        },

        {
          n: "3.2",
          title: "The framework",
          hi: "ढाँचा",
          blocks: [
            { k: "dia", id: "hb-sv-chain", cap: "Triangles, a base line, a check line, and offsets to the detail." },
            { k: "list", items: [
              "<strong>Base line</strong> — the longest line of the survey, run through the middle of the area if possible, measured with more care than anything else. Everything is built off it.",
              "<strong>Main survey lines</strong> — forming the triangles. Well-conditioned, meaning no angle smaller than about 30° or larger than about 120°, because a sliver triangle locates its apex very poorly.",
              "<strong>Check line</strong> — a line whose length can be both measured and computed. If the two agree, the triangle is right. If they do not, something is wrong and you know it before you leave the field.",
              "<strong>Tie line</strong> — joining known points on two survey lines, to pick up detail and provide a further check.",
              "<strong>Offsets</strong> — short measurements at right angles from a survey line to the detail. Perpendicular offsets are preferred; oblique offsets need two measurements and are used where a perpendicular cannot be set out.",
            ]},
            { k: "p", t: "Why does a poorly conditioned triangle matter? Because the apex is located by the intersection of two arcs, and when those arcs meet at a shallow angle a small error in either radius shifts the intersection a long way along the other. At 30° the geometry is acceptable; at 10° it is worthless. This is the same argument that returns in Chapter 12 for triangulation, and in Chapter 12 again for satellite geometry." },
            { k: "trap", t: "Offsets must be <strong>short</strong>. An offset of 15 m set out by eye can be several degrees off perpendicular, and the resulting position error is far larger than anything in the chaining. The remedy is more survey lines closer to the detail, not longer offsets — and beyond about 15 m, use an optical square rather than judgement." },
          ],
        },

        {
          n: "3.3",
          title: "Ranging, and getting round obstacles",
          hi: "रेंजिंग और बाधाएँ",
          blocks: [
            { k: "p", t: "A line longer than one tape length has to be <em>ranged</em> — intermediate points established truly on the line, so that successive tape lengths are collinear. Direct ranging works when the ends are intervisible; where a hill intervenes, <strong>reciprocal ranging</strong> is used, with two surveyors each directing the other alternately until both are on line. It converges surprisingly quickly." },
            { k: "h", t: "Obstacles" },
            { k: "p", t: "Every chain survey meets something in the way, and the problems divide into two kinds that need quite different treatment:" },
            { k: "list", items: [
              "<strong>Chaining obstructed, vision clear</strong> — a pond, a standing crop. The line can be seen across but not measured across. Solved by geometry: set out a perpendicular or a similar-triangle construction to compute the missing length.",
              "<strong>Vision obstructed, chaining clear</strong> — a hill. Solved by reciprocal ranging.",
              "<strong>Both obstructed</strong> — a building. Solved by offsetting the line round the obstacle: run a parallel line at a known perpendicular offset, past the obstruction, and return.",
            ]},
            { k: "note", t: "A river is the classic case of the first kind, and the classic solution is a 3-4-5 or similar-triangle construction on the bank, which turns an unmeasurable distance into two measurable ones plus a calculation. It is worth doing once with a tape on a football field — the method is much more obvious in your hands than on paper." },
            { k: "eg",
              title: "Example 3.1 — Width of a river by similar triangles",
              given: "Chain line AB crosses a river; A is on the far bank and cannot be reached. At B, on the near bank, a perpendicular BC = 40.0 m is set out. At C a perpendicular to CA is set out, meeting the chain line (on the near side of B) at D. BD is measured as 12.5 m.",
              steps: [
                { t: "Why it works", w: "triangle ACD is right-angled at C, and CB is perpendicular to its hypotenuse AD\nso triangles ABC and CBD are similar:  AB/BC = BC/BD,  i.e.  BC² = AB × BD" },
                { t: "Unknown length", w: "AB = BC²/BD = 40.0²/12.5 = 1600/12.5 = 128.0 m" },
                { t: "Sensitivity", w: "an error of 0.1 m in BD changes AB by 128 × 0.1/12.5 = 1.0 m\n— make BD as long as the ground allows" },
              ],
              ans: "The river crossing AB = 128.0 m. The construction turns one unmeasurable length into two measurable ones; its weakness is that a short BD magnifies every error in it.",
            },
          ],
        },

        {
          n: "3.4",
          title: "The five corrections",
          hi: "पाँच संशोधन",
          blocks: [
            { k: "p", t: "A tape reading is not a length. Between the number in the field book and the distance you can plot are five systematic errors — Chapter 2's second kind — each of which can be computed and removed." },
            { k: "dia", id: "hb-sv-tapecorr", cap: "Five corrections, and the sign of each. Two of them can only ever be negative." },
            { k: "eq", expr: "① standardisation:   Ca = L (c / l)", where: [
              ["L", "measured length"],
              ["l", "nominal tape length"],
              ["c", "the amount the tape is too long (+) or too short (−)"],
            ]},
            { k: "eq", expr: "② slope:   Cs = − [L − √(L² − h²)]  ≈  − (h²/2L + h⁴/8L³)  ≈  − h²/2L;   or  − L(1 − cos θ)", where: [
              ["h", "difference in level between the ends of the measured length L"],
              ["θ", "slope angle, if that is what was measured"],
            ]},
            { k: "eq", expr: "③ temperature:   Ct = α (Tm − T₀) L", where: [
              ["α", "coefficient of thermal expansion — about 11.2 × 10⁻⁶ /°C for steel (sources quote 9.9–12 × 10⁻⁶; use the tape maker's figure); about 0.12 × 10⁻⁶ for invar"],
              ["Tm", "mean field temperature; T₀ the standardisation temperature"],
            ]},
            { k: "eq", expr: "④ pull:   Cp = (P − P₀) L / (A E)", where: [
              ["P", "pull applied; P₀ the standardisation pull, N"],
              ["A", "cross-sectional area of the tape, mm²"],
              ["E", "Young's modulus, about 2.1 × 10⁵ N/mm² for steel"],
            ]},
            { k: "eq", expr: "⑤ sag:   Csag = − W² l / (24 P²)   per span", where: [
              ["W", "total weight of one suspended span, N"],
              ["l", "length of that span"],
            ]},
            { k: "p", t: "There is a sixth for precise work — reduction to mean sea level, <strong>Cmsl = − L h / R</strong> — which matters because a length measured at altitude subtends a smaller angle at the earth's centre than the same length at sea level, and national coordinates are defined at the datum." },
            { k: "trap", t: "The signs of ② and ⑤ are fixed. Slope and sag both mean <em>the tape travelled further than the distance you want</em>, so both are always subtractive. The other three depend on conditions. The question that settles any of them: <strong>did the tape read too many tape-lengths, or too few?</strong> If a tape is too long it reads too few, so the correction is positive." },
          ],
        },

        {
          n: "3.5",
          title: "All five, worked",
          hi: "पाँचों का उदाहरण",
          blocks: [
            { k: "eg",
              title: "Example 3.2 — Correcting a measured base line",
              given: "A line measured as 1500.000 m with a 30 m steel tape. The tape was standardised at 20 °C under 100 N pull and found to be 30.005 m long. In the field the mean temperature was 35 °C and the pull 150 N. Tape cross-section 3 mm², E = 2.1 × 10⁵ N/mm², α = 11.2 × 10⁻⁶ /°C. The tape was supported at its ends only, in 30 m spans, and weighs 0.9 kg per span. Mean altitude 800 m; R = 6370 km.",
              steps: [
                { t: "① Standardisation", w: "the tape is 0.005 m too LONG, so the line is really longer than measured\nCa = L(c/l) = 1500 × (0.005/30) = +0.250 m" },
                { t: "② Slope", w: "the line was measured horizontally, so no slope correction applies here\nCs = 0" },
                { t: "③ Temperature", w: "35 °C is warmer than standard, so the tape expanded and read short\nCt = α(Tm − T₀)L = 11.2×10⁻⁶ × (35 − 20) × 1500 = +0.252 m" },
                { t: "④ Pull", w: "150 N is more than standard, so the tape stretched and read short\nCp = (P − P₀)L/(AE) = (150 − 100) × 1500/(3 × 2.1×10⁵)\n   = 75,000/630,000 = +0.119 m" },
                { t: "⑤ Sag — per span first", w: "W = 0.9 × 9.81 = 8.829 N per 30 m span\nCsag = −W² l/(24 P²) = −(8.829² × 30)/(24 × 150²)\n     = −2338.6/540,000 = −0.004331 m per span\nnumber of spans = 1500/30 = 50\ntotal = 50 × (−0.004331) = −0.217 m" },
                { t: "⑥ Reduction to mean sea level", w: "Cmsl = −L h/R = −1500 × 800/6,370,000 = −0.188 m" },
                { t: "Sum", w: "+0.250 + 0.252 + 0.119 − 0.217 − 0.188 = +0.216 m" },
                { t: "Corrected length", w: "1500.000 + 0.216 = 1500.216 m" },
              ],
              ans: "1500.216 m. Note the sizes: the three positive corrections total +0.621 m and the two negative ones −0.405 m, so they very nearly cancel — and a surveyor who applied none of them would still be within 0.22 m, or 1 in 6900.",
            },
            { k: "trap", t: "That near-cancellation is a trap, not a comfort. It happened because this particular tape was long, the day was hot and the pull heavy; on a cold morning with a short tape and a light pull, all five corrections push the same way and the total is about five times as large. <strong>Compute them, do not assume they will cancel.</strong>" },
            { k: "eg",
              title: "Example 3.3 — How good is the h²/2L approximation?",
              given: "A 30 m tape length is laid on ground falling 3.0 m along it; separately, a 30 m length is laid on a uniform 10° slope.",
              steps: [
                { t: "Exact, from the level difference", w: "Cs = 30 − √(30² − 3²) = 30 − 29.8496 = 0.15038 m" },
                { t: "Approximations", w: "h²/2L = 9/60 = 0.15000 m      (error 0.4 mm)\nh²/2L + h⁴/8L³ = 0.15000 + 0.000375 = 0.150375 m  (error < 0.01 mm)" },
                { t: "From the angle", w: "Cs = 30(1 − cos 10°) = 30 × 0.015192 = 0.456 m per tape length" },
                { t: "Hypotenusal allowance for chaining on slope", w: "add 100(sec θ − 1) links per chain = 100 × 0.01543 = 1.54 links per 100 links at 10°" },
              ],
              ans: "At 1 in 10 the one-term formula is good to 0.4 mm per 30 m; a 10° slope costs 0.456 m per tape length — far too much to ignore.",
            },
            { k: "note", t: "The sag correction repays a second look, because it is the one that can be eliminated rather than computed. Support the tape along its whole length and it vanishes. Alternatively, apply the <em>normal tension</em> — the pull at which the stretch exactly compensates the sag — which is how base lines were measured before EDM existed." },
            { k: "eq", expr: "(Pn − P₀) l / (A E) = W² l / (24 Pn²)   ⇒   Pn = 0.204 W √(AE) / √(Pn − P₀)", where: [
              ["Pn", "normal tension, N — appears on both sides, so solve by trial"],
              ["0.204", "1/√24"],
            ]},
            { k: "eg",
              title: "Example 3.4 — Normal tension for the tape of Example 3.2",
              given: "W = 8.829 N per 30 m span, A = 3 mm², E = 2.1 × 10⁵ N/mm², standard pull P₀ = 100 N.",
              steps: [
                { t: "Rearrange as a cubic", w: "Pn² (Pn − 100) = W² A E/24 = 8.829² × 630,000/24 = 2.046 × 10⁶" },
                { t: "Trial", w: "Pn = 170 N:  170² × 70 = 2.023 × 10⁶  (slightly low)\nPn = 171 N:  171² × 71 = 2.076 × 10⁶  (slightly high)\n→ Pn ≈ 170.4 N" },
                { t: "Check", w: "stretch = (170.4 − 100) × 30/630,000 = 3.35 mm\nsag    = 8.829² × 30/(24 × 170.4²) = 3.35 mm  ✓" },
              ],
              ans: "Pull the tape at about 170 N and the sag and pull corrections cancel — 3.35 mm each per span. Simple iteration Pn ← 0.204W√(AE)/√(Pn − P₀) diverges for this tape; bracket the root as above instead.",
            },
            { k: "note", t: "Formulae cross-checked against <a href=\"https://www.brainkart.com/article/Surveying-Corrections-for-Baseline_4620/\" target=\"_blank\" rel=\"noopener\">BrainKart</a> and <a href=\"https://en.wikipedia.org/wiki/Tape_correction_(surveying)\" target=\"_blank\" rel=\"noopener\">Wikipedia</a>. One of those pages prints the normal-tension constant as 0.0204 — a typographical error; 1/√24 = 0.204, as the derivation above shows." },
          ],
        },

        {
          n: "3.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Chain surveying measures distances only, so the framework must be triangles.",
              "Well-conditioned means no angle below about 30° or above 120°.",
              "The check line is what makes the survey defensible.",
              "Offsets short and perpendicular; more survey lines beats longer offsets.",
              "Five corrections: standardisation, slope, temperature, pull, sag — plus MSL for precise work.",
              "Slope and sag are always negative. The rest follow from too many or too few tape-lengths.",
              "Sag can be designed out, by supporting the tape or by using normal tension Pn = 0.204W√(AE)/√(Pn − P₀).",
              "Metric chain links are 0.2 m: 100 links in a 20 m chain, 150 in a 30 m chain.",
            ]},
            { k: "p", t: "A framework of distances alone is rigid but awkward — it needs open ground and a lot of chaining. Chapter 4 adds the other half of a position: direction." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "sv-4",
      n: 4,
      title: "Compass Surveying",
      hi: "कम्पास सर्वेक्षण",
      blurb: "Direction from the earth's magnetic field — and the two things that make that field lie to you.",
      mins: 42,
      sections: [

        {
          n: "4.1",
          title: "Meridians and bearings",
          hi: "याम्योत्तर और दिशाकोण",
          blocks: [
            { k: "p", t: "A direction has to be measured <em>from</em> something, and that reference line is called a meridian. Three are in use and they are not the same." },
            { k: "list", items: [
              "<strong>True meridian</strong> — the line through the point and the geographic poles. Fixed, and the reference for anything permanent.",
              "<strong>Magnetic meridian</strong> — the direction a freely suspended magnetic needle takes. What a compass actually gives you, and it moves.",
              "<strong>Arbitrary meridian</strong> — any convenient direction assumed as a reference, used for small isolated surveys where absolute orientation does not matter.",
            ]},
            { k: "def", term: "Bearing", t: "The horizontal angle a line makes with the meridian." },
            { k: "dia", id: "hb-sv-bearings", cap: "The same direction, two conventions — whole circle and quadrantal." },
            { k: "list", items: [
              "<strong>Whole circle bearing (WCB)</strong> — measured clockwise from north, 0° to 360°. What a <em>prismatic</em> compass reads.",
              "<strong>Reduced or quadrantal bearing (QB)</strong> — measured from north or south, east or west, never exceeding 90°: N 40° E, S 43° E. What a <em>surveyor's</em> compass reads.",
            ]},
            { k: "p", t: "Converting between them is a matter of noticing which quadrant you are in, and it is far safer to sketch it than to memorise four rules. In the second quadrant (SE) the QB is 180° − WCB; in the third (SW) it is WCB − 180°; in the fourth (NW) it is 360° − WCB; in the first they are equal." },
            { k: "eg",
              title: "Example 4.1 — Converting bearings, and the back bearing",
              given: "(a) WCB of AB = 157°30′.  (b) WCB of PQ = 248°15′.  (c) QB of XY = N 32°45′ W.",
              steps: [
                { t: "(a) 157°30′ lies between 90° and 180° — SE quadrant", w: "QB = S (180° − 157°30′) E = S 22°30′ E\nback bearing = 157°30′ + 180° = 337°30′ = N 22°30′ W" },
                { t: "(b) 248°15′ lies between 180° and 270° — SW quadrant", w: "QB = S (248°15′ − 180°) W = S 68°15′ W\nback bearing = 248°15′ − 180° = 68°15′ = N 68°15′ E" },
                { t: "(c) NW quadrant", w: "WCB = 360° − 32°45′ = 327°15′\nback bearing = 147°15′ = S 32°45′ E" },
              ],
              ans: "S 22°30′ E (BB N 22°30′ W); S 68°15′ W (BB N 68°15′ E); 327°15′ (BB S 32°45′ E). In quadrantal form the back bearing has the same angle with both letters swapped.",
            },
            { k: "def", term: "Fore and back bearing", t: "The bearing of AB observed at A is the fore bearing; the bearing of the same line observed at B is the back bearing. They should differ by exactly 180°. When they do not, something is wrong — and §4.4 is about what." },
          ],
        },

        {
          n: "4.2",
          title: "The two compasses",
          hi: "दो प्रकार के कम्पास",
          blocks: [
            { k: "cmp", t: "Both point north; almost everything else about them differs.",
              cols: ["Prismatic compass", "Surveyor's compass"],
              rows: [
                ["Reads", "Whole circle bearing, 0°–360°", "Quadrantal bearing, 0°–90° in four quadrants"],
                ["Graduated ring", "Attached to the <strong>needle</strong>, so it stays still while the box turns", "Attached to the <strong>box</strong>, so it turns with the sight line"],
                ["Figures", "Written inverted, and read through a prism", "Written upright, read directly"],
                ["E and W on the dial", "In their true positions", "<strong>Interchanged</strong>, so that the quadrant reads correctly"],
                ["Reading taken", "At the far end, through the prism, while sighting", "At the near end, after sighting, looking down"],
                ["Tripod", "Not essential — can be hand-held", "Always on a tripod"],
                ["Least count", "Typically 30′", "Typically 15′"],
                ["Zero of the graduation", "At the <strong>south</strong> end of the ring, because the reading is taken through the prism on the opposite side", "At N and S, 0°–90° each way"],
                ["Sighting", "Sight and read simultaneously", "Sight first, then read"],
              ] },
            { k: "trap", t: "The interchanged E and W on a surveyor's compass looks like a mistake and is not. Because the ring turns <em>with</em> the box, swinging the sight line eastward brings the west graduation towards the index — so the letters are swapped to make the reading come out right. Anyone who \"corrects\" it has broken the instrument." },
            { k: "note", t: "Least count and graduation details of the prismatic compass (30′, zero at the south end, figures inverted to read correctly through the prism) are as given in <a href=\"https://gyansanchay.csjmu.ac.in/wp-content/uploads/2022/09/100012609.pdf\" target=\"_blank\" rel=\"noopener\">CSJMU prismatic-compass notes</a>; 15′ for the surveyor's compass is the usual textbook figure." },
          ],
        },

        {
          n: "4.3",
          title: "Declination",
          hi: "दिक्पात",
          blocks: [
            { k: "def", term: "Magnetic declination", t: "The horizontal angle between the true meridian and the magnetic meridian at a place. East (positive) if magnetic north lies east of true north, west (negative) if it lies west." },
            { k: "eq", expr: "true bearing  =  magnetic bearing  +  declination (E positive, W negative)", where: [] },
            { k: "p", t: "Declination is not a constant. It varies from place to place, and at any one place it varies with time in several distinct ways:" },
            { k: "list", items: [
              "<strong>Secular</strong> — a slow, pendulum-like swing over a long cycle — quoted as roughly 250 years in many surveying texts and about 300 years in others (e.g. <a href=\"https://www.rammohancollege.ac.in/images/Study%20Materials/GEO-A-CC-1-02-TH%20-%20Bearing%20Magnetic%20and%20True%20Whole-Circle%20and%20Reduced.pdf\" target=\"_blank\" rel=\"noopener\">Rammohan College study material</a>); it is not strictly periodic. By far the largest. This is why a bearing from an old plan cannot be used directly today without knowing the date.",
              "<strong>Annual</strong> — a small yearly swing, of the order of one minute of arc.",
              "<strong>Diurnal</strong> — a daily swing of roughly 4–10 minutes depending on the locality (<a href=\"https://www.rammohancollege.ac.in/images/Study%20Materials/GEO-A-CC-1-02-TH%20-%20Bearing%20Magnetic%20and%20True%20Whole-Circle%20and%20Reduced.pdf\" target=\"_blank\" rel=\"noopener\">Rammohan College study material</a>), larger in summer; the needle is quiet at night.",
              "<strong>Irregular</strong> — magnetic storms, sudden and unpredictable, occasionally a degree or more. Compass work should simply stop.",
            ]},
            { k: "eg",
              title: "Example 4.2 — Using an old plan",
              given: "A plan prepared when the declination was 1°10′ W shows the magnetic bearing of a boundary as 48°24′. The declination today is 0°20′ E. What is the true bearing, and what will a compass read along the boundary today?",
              steps: [
                { t: "True bearing (W negative)", w: "true = magnetic + declination = 48°24′ − 1°10′ = 47°14′" },
                { t: "Today's magnetic bearing (E positive)", w: "magnetic = true − declination = 47°14′ − 0°20′ = 46°54′" },
              ],
              ans: "True bearing 47°14′ — it never changes. A compass set to the old 48°24′ today would run the boundary 1°30′ off — about 2.6 m in every 100 m.",
            },
            { k: "def", term: "Isogonic and agonic lines", t: "An isogonic line joins places of equal declination; the agonic line is the isogonic of zero declination, where magnetic and true north coincide." },
            { k: "note", t: "There is also <strong>dip</strong> — the needle's tendency to tilt out of horizontal, because the earth's field is not horizontal except near the magnetic equator. Compass needles are counterweighted on one side to balance it, which is why a needle from one hemisphere does not work properly in the other." },
          ],
        },

        {
          n: "4.4",
          title: "Local attraction",
          hi: "स्थानीय आकर्षण",
          blocks: [
            { k: "p", t: "A compass responds to whatever magnetic field is present, and near iron that is not only the earth's. Rails, pipes, electric lines, reinforcement, a steel tape lying on the ground, even the surveyor's own belt buckle — all of them deflect the needle." },
            { k: "dia", id: "hb-sv-localattr", cap: "Fore and back bearings differing by exactly 180° prove both ends are clean." },
            { k: "p", t: "The key insight, and the one that makes every problem of this type solvable: <strong>local attraction is a property of the station, not of the line</strong>. Every bearing observed <em>at</em> an affected station is wrong by the same amount and in the same direction." },
            { k: "steps", items: [
              "For each line, compute FB − BB. Where it is exactly 180°, both ends of that line are free of attraction.",
              "Start from that clean line. Its bearings are correct as observed.",
              "Move to the next line. The bearing observed at the clean station is correct; compare it with the bearing observed at the other end to find that station's error.",
              "Apply that station's error to every bearing observed at it — with the sign reversed — and continue round the traverse.",
              "The correction must close back on the first clean station. If it does not, there is a mistake as well as attraction.",
            ]},
            { k: "eg",
              title: "Example 4.3 — A traverse with local attraction",
              given: "Observed bearings of a closed traverse ABCD, run clockwise:\nAB — FB 45°30′, BB 225°30′\nBC — FB 124°45′, BB 306°00′\nCD — FB 211°30′, BB 29°45′\nDA — FB 300°00′, BB 120°30′",
              steps: [
                { t: "FB − BB for every line", w: "AB: 225°30′ − 45°30′ = 180°00′  ✓\nBC: 306°00′ − 124°45′ = 181°15′\nCD: 211°30′ − 29°45′  = 181°45′\nDA: 300°00′ − 120°30′ = 179°30′\n→ only AB is clean, so A and B are free of local attraction" },
                { t: "Line BC — B is clean", w: "FB at B = 124°45′ is correct, so the BB should be 304°45′\nobserved at C = 306°00′  →  error at C = +1°15′, correction −1°15′" },
                { t: "Line CD — correct the bearing observed at C", w: "FB at C = 211°30′ − 1°15′ = 210°15′, so the BB should be 30°15′\nobserved at D = 29°45′  →  error at D = −0°30′, correction +0°30′" },
                { t: "Line DA — correct the bearing observed at D", w: "FB at D = 300°00′ + 0°30′ = 300°30′, so the BB at A should be 120°30′\nobserved at A = 120°30′ — and A was found clean in step 1  ✓ the corrections close" },
                { t: "Independent check — included angles", w: "angle at a station = BB of the line arriving − FB of the line leaving\nA = 120°30′ − 45°30′ = 75°00′      B = 225°30′ − 124°45′ = 100°45′\nC = 304°45′ − 210°15′ = 94°30′      D = 30°15′ − 300°30′ + 360° = 89°45′\nsum = 360°00′ = (2n − 4) × 90° for n = 4  ✓" },
              ],
              ans: "Errors: A 0, B 0, C +1°15′, D −0°30′. Corrected bearings — AB 45°30′/225°30′, BC 124°45′/304°45′, CD 210°15′/30°15′, DA 300°30′/120°30′.",
            },
            { k: "note", t: "Notice that the included angle at C from the <em>observed</em> bearings, 306°00′ − 211°30′ = 94°30′, is already correct. Both bearings at a station carry the same error, so it cancels in their difference — local attraction never affects included angles. That gives a second method: compute the angles from the raw bearings, then rebuild every bearing from the clean line AB." },
            { k: "note", t: "<b>Correction (v35):</b> the earlier version of this example used bearings (45°30′, 96°45′, 30°00′, 320°30′) that all lie within a 140° fan — no four lines in those directions can close into a polygon, and its ‘included angles’ summed to 720°. The arithmetic of the correction was right but the data were impossible; the example has been rebuilt on a traverse that closes, with an angle-sum check added." },
            { k: "trap", t: "Do not \"average\" the fore and back bearings of an affected line. It looks reasonable and it is wrong: the error belongs entirely to one station, so averaging spreads a real error over a clean observation and corrupts both. <strong>Find the clean line first, always.</strong>" },
            { k: "real", t: "The most common source on a modern site is the one nobody thinks of: reinforcement. Taking a compass bearing while standing on a slab with 12 mm bars at 150 mm centres a few hundred millimetres below your feet will produce a beautifully repeatable, completely wrong bearing. This, rather than any accuracy argument, is why compass traversing has largely disappeared from construction work." },
          ],
        },

        {
          n: "4.5",
          title: "What a compass traverse is good for",
          hi: "कम्पास ट्रैवर्स कहाँ उपयोगी",
          blocks: [
            { k: "p", t: "A compass traverse measures the bearing of each line and its length, and computes positions from those. Accuracy is modest — 1 in 300 to 1 in 600 is typical — because a needle can be read to perhaps 15 minutes at best, and a 15-minute error over a 200 m line is nearly a metre." },
            { k: "list", items: [
              "<strong>Good for</strong> — reconnaissance, preliminary surveys, forest and revenue work, filling in detail inside a better framework, and anywhere speed matters more than precision.",
              "<strong>Not good for</strong> — anything near iron, any setting out, any work where the plan will be used to build from.",
              "<strong>The advantage that survives</strong> — each line's direction is measured <em>independently</em> from the magnetic meridian, so an angular error at one station does not propagate to the rest of the traverse. In a theodolite traverse, by contrast, angles are measured from the previous line and errors do accumulate.",
            ]},
            { k: "note", t: "That last point is a genuine and underrated strength. A compass traverse is angularly self-correcting in a way a theodolite traverse is not — which is exactly why a long compass traverse does not get steadily worse, it just stays mediocre. Chapter 8 shows the other side of that bargain." },
          ],
        },

        {
          n: "4.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Three meridians: true, magnetic, arbitrary. A compass gives you the magnetic one.",
              "WCB 0°–360° from north; QB from N or S towards E or W, never past 90°.",
              "True bearing = magnetic bearing + declination, east positive.",
              "FB and BB should differ by exactly 180°.",
              "Local attraction belongs to the STATION. Find a clean line, then work outwards — included angles are unaffected and give an independent check.",
              "Never average the bearings of an affected line.",
              "Compass accuracy is 1 in 300 to 1 in 600 — reconnaissance, not construction.",
            ]},
            { k: "p", t: "Chapter 5 takes both of the last two chapters into the field at once, on an instrument that plots the survey as it is measured — and therefore never needs the numbers written down at all." },
          ],
        },
      ],
    }

  );
})();
