/* ============================================================
   TUNNEL ENGINEERING · COMPLETE NOTES — Chapters 3–4
   Excavation in Hard Rock · Excavation in Soft Ground
   Sources: A (43 pp, dense) · B (18 pp, sparser, complementary)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "tunnel");
  if (!hb) { console.error("[tunnel2] handbook tunnel not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "tunnel-3",
      n: 3,
      title: "Excavation in Hard Rock",
      hi: "कठोर चट्टान में उत्खनन",
      blurb: "Rock drills and modes of excavation, explosives and blasting mechanics, cuts and shafts, faces of attack and pilot tunnels, the drift / heading-and-benching / full-face methods with the cantilever car-dump arrangement, and mucking, scaling and hauling with muck-car track layouts.",
      mins: 24,
      sections: [
        {
          n: "3.1",
          title: "Rock drills and modes of excavation",
          hi: "चट्टान ड्रिल और उत्खनन की विधियाँ",
          blocks: [
            { k: "h", t: "📘 Notes — A p.9–11, B p.13–14" },
            { k: "p", t: "Excavation of a hard-rock tunnel needs <b>drilling, cleaning, charging and blasting</b> of the rock (A p.9). One rock drill is required for roughly every <b>4–5 m²</b> of face area, and the diameter of the bore hole at its deepest point should be about <b>6 mm more</b> than the diameter of the cartridge used (A p.9)." },
            { k: "note", t: "A p.10's manuscript reads the drill name as <i>'Doipters'</i> — an unclear handwriting reading, flagged [?] in the transcript. B p.13 independently and clearly names the same drill as the <b>drifter</b> (able to drill horizontal, down and up holes), which resolves the ambiguity." },
            { k: "cmp", t: "Types of rock drill and their capacities (A p.10)", cols: ["Description"], rows: [
              ["a) Percussion drills", "Break rock by impact of blows — (i) wagon drills (ii) churn drills (iii) jack hammer drills"],
              ["b) Abrasion drills", "Create an abrasion/rubbing effect — (i) shot drills: dia. up to 750 mm, length up to 200 m (ii) diamond drills: dia. 300 mm, length 300 m"],
              ["c) Fusion piercing", "Rock is flaked off by heating (O₂ + flux-bearing fuel such as kerosene at the pipe end) and immediately watered"],
              ["d) Special drills", "(i) implosion drills — sealed vacuum capsules (ii) explosion drills — capsule with an explosive charge"],
            ] },
            { k: "list", items: [
              "Sequence of drills by increasing hole size: <b>wagon drill &lt; churn drill &lt; diamond drill &lt; shot drill</b> (A p.10).",
              "B p.13–14 names the drifter and the jack hammer as the two main drill types used in rock, operated on compressed air of <b>0.4–0.6 N/mm²</b>; being heavy, they are supported on a column called a <b>Jumbo</b>. Drill bits are of two kinds: <b>forged bits</b> and <b>detachable bits</b> (B p.14).",
            ] },
            { k: "h", t: "Mode of excavation (A p.10–11)" },
            { k: "list", items: [
              "<b>Percussion mode</b> — for blocky, weathered rock and boulders; done by hydraulic and pneumatic hammers.",
              "<b>Ripping mode</b> — for weathered and jointed rock.",
              "<b>Drag / pitch / point attack</b> — excavation by drag bits: a flat, conically shaped, self-sharpening conical pick.",
              "<b>Rolling / cutter mode</b> — rotating tungsten carbide bits and picks, or disc cutters, used for the <b>full-face attack method</b> of tunnelling.",
            ] },
            { k: "h", t: "Important limits during excavation" },
            { k: "list", items: [
              "Oxygen must not be less than <b>19.5%</b>; CO₂ not more than <b>0.5%</b>; H₂S not more than <b>0.001%</b> (A p.11).",
              "B p.6 gives the same three limits and adds a fourth: <b>CO not more than 0.01%</b>.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Drilling equipment is chosen by what the rock is doing, not just how hard it is — a percussion hammer breaks blocky, already-loosened rock by impact, a ripper works on jointed rock that can be peeled apart, and only a genuinely competent, stable rock face is attacked by rolling disc cutters, which is exactly the equipment a TBM uses for full-face excavation. So 'mode of excavation' here and 'method of tunnelling' (full face, drift, etc. in section 3.4) are two sides of the same decision." },
            { k: "trap", t: "Don't confuse the <b>drill</b> (drifter, jack hammer — the machine) with the <b>drill bit</b> (forged or detachable — the cutting tip) or with the <b>mode of excavation</b> (percussion, ripping, drag, rolling — how the rock face is attacked). Exam questions mix these three lists deliberately." },
          ],
        },
        {
          n: "3.2",
          title: "Blasting — explosives, depth of hole and free-face yield",
          hi: "ब्लास्टिंग — विस्फोटक और मुक्त फलक उपज",
          blocks: [
            { k: "h", t: "📘 Notes — A p.11–12, B p.12–13" },
            { k: "cmp", t: "Types of explosive used in blasting (A p.11, B p.12–13)", cols: ["Note"], rows: [
              ["1) Straight dynamites", "Not suitable for rock tunnelling — poor fume characteristics"],
              ["2) Ammonia dynamites", "Two types: (a) High velocity–high density (HVHD) — the better of the two (b) Low velocity–low density (LVLD) — cannot be used in water"],
              ["3) Ammonia gelatine", "Can be fired/used in the presence of water"],
              ["4) Semi-gelatine", "Better than ammonia gelatine in water"],
              ["5) Blasting agents", "Ammonium nitrate (NH₄NO₃, 94.5%) + fuel oil (5.5%) or other carbonaceous matter; low cost and safe, but highly sensitive to water (A p.11)"],
              ["6) Slurries / water gels", "Recently developed; high % NH₄NO₃ in aqueous solution; resistant to water"],
            ] },
            { k: "p", t: "A good blast with a good yield is obtained when the <b>cut hole is inclined at 45° to the face</b> (A p.11, B p.13)." },
            { k: "list", items: [
              "The quantity of rock released by a blast depends on: 1) nature of rock 2) depth of hole 3) power of the explosive 4) inclination of holes 5) number of holes fired 6) number of free faces for the holes 7) stages of firing the holes 8) pattern of the drilled holes (A p.12).",
            ] },
            { k: "eq", expr: "Depth of hole (B p.13):  d₀ = (4/3) · ∛(W/C)", where: [
              ["W", "weight of explosive charge"],
              ["C", "a coefficient depending on the rock and the quality of the explosive"],
            ] },
            { k: "eq", expr: "Rock released by a blast, relative to a single free face of volume V:  two equidistant free faces → 2.25V  ;  three free faces at a corner → 3.5V", where: [
              ["Single free face", "yield = V, the baseline (A p.12, B p.13)"],
              ["Two free faces", "yield rises to 2.25× (A p.12 states the multiplier; B p.13's figure confirms 2.25V)"],
              ["Three free faces, at a corner", "yield rises to 3.5× (B p.13's figure only — not given in A)"],
            ] },
            { k: "h", t: "Cuts used in blasting" },
            { k: "note", t: "Source difference — the two transcripts name different cut classifications. A p.12–13 (under 'Shafts') lists: <b>a) Central wedge cut</b> — square/rectangular section, most commonly used <b>b) Pyramid/wedge cut</b> — circular section <b>c) Alternate wedge cut</b> — for very large shafts, or stepping. B p.13 instead gives: <b>Pyramidal cut</b> — for the outer periphery, where rim holes are drilled, and <b>Centre cut ('V'-type cut pattern)</b> — for the central cut. Both are quoted as written; the two schemes are not reconciled in the source notes." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The whole idea of a 'cut' is to create the <b>first free face</b> — once one section of rock has been blasted out, every following hole has somewhere to throw rock into, which is why the free-face figures above jump from V to 2.25V to 3.5V as more faces open up. A poorly placed cut wastes explosive on rock that has nowhere to go." },
            { k: "trap", t: "In the depth-of-hole formula d₀ = (4/3)∛(W/C), <b>C is not a constant</b> — it changes with both the rock type and the explosive used, so the same charge weight W gives a different depth for a different rock/explosive combination." },
          ],
        },
        {
          n: "3.3",
          title: "Shafts, portals and faces of attack",
          hi: "शाफ्ट, पोर्टल और आक्रमण के फलक",
          blocks: [
            { k: "h", t: "📘 Notes — A p.12–17" },
            { k: "def", term: "Shaft", t: "A vertical tunnel, well or passage reaching from the ground surface down to the tunnel invert, sunk at suitable points once the tunnel line is set out on the surface. Shafts give additional access, help in removal of muck, and provide natural ventilation in long tunnels (A p.12–13)." },
            { k: "list", items: [
              "Size of a shaft depends on: 1) quantity of muck to be handled 2) size of the muck car 3) nature of the tunnelling equipment used 4) number of labourers 5) space required for pipes and wires 6) nature of the hoisting system 7) eventual use of the shaft (A p.13).",
            ] },
            { k: "cmp", t: "Types of shaft (A p.13–14)", cols: ["Note"], rows: [
              ["By location — over centre-line", "Majority of shafts are of this type; advantage of hoisting materials out of the tunnel easily"],
              ["By location — side shaft", "Shifted to one side of the centre-line; needs a transverse gallery/pilot tunnel to connect to the main tunnel; turning machinery at the gallery's sharp curve is its greatest drawback"],
              ["By duration — temporary", "Refilled once its purpose (information/muck removal/material supply) is served; usually located in a valley"],
              ["By duration — permanent", "Left open even after construction; helps provide ventilation"],
              ["By alignment — vertical", "Easy and cheap to construct"],
              ["By alignment — inclined", "For small depths; gradient 45° or less, so muck can be removed by gravity"],
            ] },
            { k: "p", t: "A protective wall <b>900 mm high</b> is usually built around the edge of a shaft opening, to keep surface water from flowing down the shaft (A p.14)." },
            { k: "def", term: "Portal", t: "The actual doorway or main entrance of a tunnel — the intersection point between the underground opening and the ground surface. It should be made massive and attractive in appearance, so that it gives a layman confidence to enter the tunnel; for a railway tunnel, revolving fans are installed at the portal to drive in fresh air before a train enters (A p.14–15)." },
            { k: "list", items: [
              "<b>Twin tunnels</b> — for double-line railway tunnels, two smaller separate tunnels are sometimes more advantageous than one large one. They need not have the same dimensions, are excavated far enough apart not to disturb each other, increase transportation capacity, keep one line usable if the other is blocked, and improve drainage, ventilation and safety by giving separate entry/exit for the two traffic streams (A p.15).",
            ] },
            { k: "h", t: "Faces of attack for tunnelling in rock (A p.16–17)" },
            { k: "eq", expr: "Faces of attack by the shaft system:  F = 2n + 2", where: [
              ["n", "number of shafts sunk along the tunnel line"],
              ["F", "total faces of attack available, including the two portals"],
            ] },
            { k: "list", items: [
              "<b>System of pilot tunnels</b> — used where a lateral/horizontal approach to the tunnel line is closer and shorter than a deep shaft. A small pilot tunnel is driven first, close to the proposed main tunnel, and short connecting tunnels are driven from it to reach the main tunnel and create operational faces (A p.16–17).",
              "Advantages of a pilot tunnel: a) stores tools and materials during construction b) avoids dislocation of strata at the sides of the main tunnel c) after construction, the cross-headings serve as passages for repair and maintenance workers (A p.17).",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Shafts, portals and pilot tunnels are all answers to the same question: <b>how do we get more crews working on the tunnel at once?</b> A tunnel driven only from its two portals has just 2 faces of attack; every shaft sunk along the line effectively adds another two faces, which is exactly what F = 2n + 2 counts." },
            { k: "trap", t: "Don't drop the '+2' in F = 2n + 2 — those are the two portal faces that exist even with zero shafts (n = 0)." },
          ],
        },
        {
          n: "3.4",
          title: "Excavation methods — Drift, Heading & Benching, Full Face, Cantilever Car Dump",
          hi: "उत्खनन विधियाँ — ड्रिफ्ट, हेडिंग-बेंचिंग, पूर्ण फलक",
          blocks: [
            { k: "h", t: "📘 Notes — A p.16–20, B p.11–12" },
            { k: "h", t: "Sequence of operations for tunnelling in hard rock (A p.16, B p.11)" },
            { k: "steps", items: [
              "Construction of shafts.",
              "Transferring the centre-line to the inside of the tunnel.",
              "Deciding the excavation method (and marking the tunnel profile).",
              "Setting up and drilling holes for blasting.",
              "Filling the holes with explosive.",
              "Carrying out the blasting operation.",
              "Providing ventilation and removing dust after blasting.",
              "Mucking (carting the muck to a suitable place outside the tunnel).",
              "Pumping out and removing ground water, if any.",
              "Providing support inside the tunnel.",
              "Lining of the tunnel.",
              "Opening the tunnel for use.",
            ] },
            { k: "def", term: "Drift method", t: "Consists of driving a small-sized heading, centrally at the top or bottom of the face, for the full length of the tunnel, which is later enlarged by widening and benching — hence also called the multiple drift method. Suitable for large tunnels in difficult or competent (hard) rock. The popular 'top drift' sequence is: (i) boring and blasting the top-centre drift end to end (ii) widening and enlarging the drift (iii) benching in stages (A p.17–18, B p.11)." },
            { k: "list", items: [
              "Advantages: 1) the small preliminary full-length drift is driven accurately, economising construction 2) elaborate supporting platforms are not needed for drilling 3) mucking continues undisturbed during heading work 4) provides good ventilation for workers (A p.18).",
              "Disadvantages: 1) enlargement cannot start until the central drift is complete for the full length 2) mucking tracks must be shifted frequently, bench to bench 3) extremely costly (A p.18).",
            ] },
            { k: "def", term: "Heading and Benching method", t: "The top portion is drilled in advance of the bottom portion. In hard, self-supporting rock the top heading advances one round ahead of the bottom, so heading and benching follow each other; in badly broken rock the heading needs support and the bench provides a working platform, so heading may be excavated and supported for the full length (or part length) before benching starts. Heading is always ahead of benching by a convenient length, formed by excavating the full width above the springing line; in one blast, one heading and one benching round are fired with only a few seconds' time lag (A p.18–19). B p.12 gives the advancement sequence as <b>H₁ : B₁ : H₂ : B₂</b> — alternating heading and bench rounds on each half of the face." },
            { k: "list", items: [
              "Generally suitable for <b>soft-rock tunnelling of medium/average size</b> (A p.19). Advantageous because drilling and mucking can proceed simultaneously, and less explosive is needed than for the full-face method — but removal of muck from the heading is comparatively difficult (A p.19, B p.12).",
            ] },
            { k: "def", term: "Full-face method", t: "The whole section/full face is attacked at a time, the first operation being excavation along the perimeter. Conveniently adopted for tunnels of <b>small cross-section area</b> through stable, self-supporting rock, and is continuous. Well suited when <b>diameter &lt; 6 m and face area &lt; 19 m²</b> — beyond this, construction becomes difficult and costly. Present-day <b>shield and Tunnel Boring Machine (TBM)</b> techniques are popular and well suited for full-face excavation in different ground conditions and shapes/sizes (A p.19, B p.12)." },
            { k: "list", items: [
              "Advantages of the full-face method: 1) simplicity — minimum equipment required 2) minimises the overall ground disturbance and settlement 3) easy and speedy completion 4) the mucking track is laid once for the whole operation (A p.19–20).",
            ] },
            { k: "def", term: "Cantilever car dump method", t: "An improved arrangement for throwing muck from the bench down to the tunnel floor. Two plate girders (A gives the length with an unclear reading, flagged [?] as about 2.9 m; B p.12 clearly states about <b>3 m</b>), spaced 1.8 m centre-to-centre, carry a belt conveyor fitted with jacks. The girder ends project beyond the face of the bench and are supported by struts from the top of the tunnel at the front (A p.20, B p.12)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The three rock methods form a size/stability ladder. <b>Full face</b> needs the rock to stand up on its own across the whole opening — fine for a small diameter. As the opening gets bigger or the rock gets less reliable, you switch to <b>heading and benching</b>, splitting the face into a top half that can be supported and a bottom half excavated afterward under its protection. For the largest or least competent sections, the <b>drift method</b> drives a small pilot opening for the full length first, so the true geology of the whole tunnel is known before the expensive full-size excavation begins." },
            { k: "trap", t: "Full face needs dia &lt; 6 m <b>and</b> face area &lt; 19 m² — both conditions together, not either. Watch the strict '&lt;' for boundary-value questions." },
          ],
        },
        {
          n: "3.5",
          title: "Mucking, scaling and hauling — muck cars and track layouts",
          hi: "मकिंग, स्केलिंग और हॉलिंग",
          blocks: [
            { k: "h", t: "📘 Notes — A p.20–21, B p.16–17" },
            { k: "def", term: "Mucking", t: "Removal of the blasted debris or spoil from inside the tunnel to outside the tunnel entrance (A p.20, B p.16). Mucking and hauling together take <b>½ to ⅓ of the total time</b> of tunnel construction (A p.20). Originally done by manual labour, modern tunnelling uses machines such as the <b>Conway loader</b> and <b>Elmco</b>, fitted with a leading bucket, to speed the work and save labour (A p.20)." },
            { k: "def", term: "Scaling", t: "The process of removing loose rock protrusions from the tunnel roof and sides by hammering, done immediately in the wake of blasting (A p.21)." },
            { k: "h", t: "Hauling (A p.21, B p.16–17)" },
            { k: "list", items: [
              "Haulage is an important item in tunnelling and must be well organised to avoid delaying other operations; at present it is done by electrically driven cars running over tracks.",
              "Types of muck car: i) side-dump car ii) balle-ship iii) muck box or U-bottom car (A p.21). B p.17 additionally mentions <b>nipper cars</b> — vehicles that carry drills to and from sharpening.",
            ] },
            { k: "cmp", t: "Layouts for muck car tracks (A p.21, B p.17)", cols: ["Note"], rows: [
              ["Grass hopper method", "For a narrow tunnel — empty cars run overhead, loaded cars run underneath, on a long gantry with hinged ramps at either end"],
              ["Passing track", "For a wider tunnel — two tracks laid side by side"],
              ["Cherry picker", "Uses only one track — cheaper; needs at least 4 m headroom over the normal track (B p.17)"],
              ["California crossing / Dixon conveyor", "Used for mucking in steep-grade tunnels through a wooden bulkhead with two openings; an oval loop with empty cars moving one way and full cars the other (A p.21, B p.17)"],
            ] },
            { k: "note", t: "The notes flag the <b>NATM (New Austrian Tunnelling Method)</b> only as a cross-reference at this point — A p.20 marks it '[MES 2017] 5) NATM method: see PG-40' and B p.17 lists it only as a heading, 'Special method of tunnelling in Rock — New Austrian Tunnelling Method (NATM)', with no further detail on these pages. Its full description lies outside the page range covered by this chapter." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Track layout is chosen purely by tunnel width and budget: a <b>single track (cherry picker)</b> is cheapest but slowest since loaded and empty cars share the same line; a <b>passing track</b> doubles the tracks to let cars pass; the <b>grass hopper</b> solves the same problem in a narrow bore by stacking empty cars overhead instead of sideways." },
            { k: "trap", t: "Don't mix up mucking (removing blasted debris) with scaling (knocking down loose rock left on the roof/sides) — scaling is a safety step done <b>before</b> mucking properly begins, not a synonym for it." },
          ],
        },
        {
          n: "3.6",
          title: "Quick revision — excavation in hard rock",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Four types of rock drill (percussion, abrasion, fusion piercing, special) and the four modes of excavation (percussion, ripping, drag, rolling/cutter).",
              "Six types of blasting explosive, and what governs the quantity of rock released by a blast.",
              "Depth-of-hole formula d₀ = (4/3)∛(W/C), and the free-face yield multipliers 2.25V / 3.5V.",
              "Shaft types by location, duration and alignment; F = 2n+2 faces of attack; the pilot-tunnel system.",
              "Drift, Heading & Benching, and Full-face methods — when each is used and their size limits (dia &lt; 6 m, area &lt; 19 m² for full face).",
              "Mucking vs scaling vs hauling, and the four muck-car track layouts.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "F = 2n + 2 always includes the two portal faces.",
              "Full-face method: diameter &lt; 6 m AND face area &lt; 19 m² — both conditions together.",
              "Cut hole inclined at 45° to the face gives the best blast yield.",
              "Two equidistant free faces → 2.25× yield; three faces at a corner → 3.5× yield.",
              "Drift method = most accurate but most costly; full-face = simplest but needs stable, self-supporting rock.",
              "NATM is only referenced here (A p.20, B p.17) — its detail is outside this page range.",
            ] },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "tunnel-4",
      n: 4,
      title: "Excavation in Soft Ground",
      hi: "मुलायम भूमि में उत्खनन",
      blurb: "Soil classification for tunnelling and the choice of method, forepoling / compressed-air / needle-beam methods, the six named timbering methods (Army-Case, American, English, Belgian, German, Austrian), liner plates, shield tunnelling — dimensions, parts and shove types — and tunnel lining materials with the T = 82D thickness formula.",
      mins: 25,
      sections: [
        {
          n: "4.1",
          title: "Soil classification for tunnelling, and choice of method",
          hi: "उत्खनन हेतु मिट्टी वर्गीकरण",
          blocks: [
            { k: "h", t: "📘 Notes — A p.22–23, B p.6–7" },
            { k: "cmp", t: "Classification of soft ground for tunnelling (A p.22, B p.6)", cols: ["Support needed", "Example"], rows: [
              ["1) Running ground", "Needs instant support all round", "Water-bearing sands and similar cohesionless soils"],
              ["2) Soft ground", "Needs instant support for the roof", "Soft clay"],
              ["3) Firm ground", "Roof stands for a few minutes; sides stand much longer", "Firm clay and dry earth"],
              ["4) Self-supporting ground", "Stands unsupported for a short length before needing support", "Sandstones, cemented stones, etc."],
            ] },
            { k: "note", t: "<b>Check:</b> A p.22 gives the self-supporting length as '1200 mm to 1500 mm (4 ft to 16 ft)' — but 1500 mm is about 5 ft, not 16 ft. B p.6 independently gives the same quantity as <b>1.2 m to 5 m</b> (≈ 4 ft to 16 ft), which matches the foot figures. The 'mm' value in A (1500 mm) looks like a transcription slip; the intended figure was most likely close to B's 5 m." },
            { k: "list", items: [
              "Characteristics of an ideal soil for tunnelling: 1) remains unaffected when exposed to air 2) composed of homogeneous material 3) has no water-bearing strata 4) capable of being easily excavated (A p.22).",
            ] },
            { k: "h", t: "General character of tunnelling in soft ground, and choice of method" },
            { k: "list", items: [
              "B p.7: explosives are not required; progress is slow compared with hard rock; excavation is by hand tools (shovel, axe, etc.) with no need for heavy, costly equipment; and <b>timbering</b> is required to support the excavation, which increases obstruction and slows the work.",
              "Factors affecting the choice of tunnelling method in soft ground: 1) equipment available 2) method/sequence of excavation — the timber-support method decides the size and sequence of progress 3) size of tunnel 4) type of ground (A p.23).",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The four soil classes (running → soft → firm → self-supporting) are really a single scale of <b>how long the ground stands unsupported</b>, from zero time (running ground) up to a metre or two of unsupported length (self-supporting ground). Every method in the rest of this chapter is essentially a different way of getting timber or steel support in place before that time runs out." },
            { k: "trap", t: "Do not confuse 'running ground' with 'soft ground' — running ground (water-bearing sand) needs support <i>all round</i> instantly, while soft ground (soft clay) needs instant support only for the <i>roof</i>. That distinction decides which method is chosen." },
          ],
        },
        {
          n: "4.2",
          title: "Forepoling, compressed air and needle beam methods",
          hi: "फोरपोलिंग, कम्प्रेस्ड एयर और नीडल बीम विधि",
          blocks: [
            { k: "h", t: "📘 Notes — A p.23–24, B p.7" },
            { k: "def", term: "Forepoling method", t: "Probably the only method usable for <b>running ground</b> and similar cohesionless soils — an old method, replaced by the compressed-air method wherever possible. The process is slow and needs skilled labour. Used advantageously for small-dimension tunnels such as sewers and gas pipes at ordinary depth; forepoles or spikes, a horse head, etc. are used for supporting (A p.23, B p.7)." },
            { k: "def", term: "Compressed air method", t: "Most suitable for clays; the work is done under air pressure. i) working-zone pressure ≤ 1.25 kg/cm²: working hours = 8 hrs, breathing interval = 4 hrs. ii) pressure &gt; 1 kg/cm²: working = 4 hrs, breathing interval = 2 hrs (A p.23)." },
            { k: "note", t: "<b>Check:</b> the two pressure conditions above overlap — the first is stated for p ≤ 1.25 kg/cm² and the second for p &gt; 1 kg/cm², so a pressure between 1 and 1.25 kg/cm² satisfies both as written. The second condition was most likely meant to read '&gt; 1.25 kg/cm²'." },
            { k: "eq", expr: "Volume of free air supplied in the compressed-air method:  6 m³/min per m² of face area  (A p.24, MES 2015)" },
            { k: "def", term: "Needle beam method", t: "Suitable for firm ground and brick lining. Advance is <b>3 m to 4 m per day</b>; the needle beam itself is usually <b>5 m to 6 m</b> long (A p.24, B p.7 — both figures agree)." },
            { k: "steps", items: [
              "A 'monkey drift', 600 mm long, is driven beyond the day's working face.",
              "The roof of the drift is supported by lagging carried on wooden segments, in turn supported by two trench jacks in front and two at the rear.",
              "Once the drift is complete, the needle beam is slowly skidded forward into the monkey drift.",
              "The front end of the beam rests on a plank; the rear end is supported on a stout post resting on the tunnel-floor lining.",
              "A trench jack is placed on the beam's centre-line to support the segment, transferring the roof load onto the needle beam.",
              "The other trench jacks are removed and the drift is widened sideways and re-supported as before.",
              "As the crown and side segments reach invert level, they complete a ring; adjacent segments are connected with timber wedges to get arch action.",
              "All jacks are released as the earth load transfers to the arch segments, the needle beam is pushed further forward, and the whole procedure repeats — a large number of jacks are needed (A p.24).",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The needle beam is a <b>temporary bridge that carries the roof load while a new ring of permanent segments is built</b> — the trench jacks hand the load to the beam, the beam hands it to the completed ring behind, and only then can the jacks in front be freed to advance. It is a slow, jack-by-jack relay, which is why only 3–4 m of progress is made in a day." },
            { k: "trap", t: "The needle beam's <b>length</b> (5–6 m) and its <b>daily advance</b> (3–4 m) are two different numbers describing two different things — don't swap them in an answer." },
          ],
        },
        {
          n: "4.3",
          title: "Named timbering methods",
          hi: "नामित टिम्बरिंग विधियाँ",
          blocks: [
            { k: "h", t: "📘 Notes — A p.24–27, B p.7–8" },
            { k: "def", term: "Army method (Case method)", t: "Devised by the US Army for constructing small tunnels at fairly shallow depth; mainly used for laying underground sewers. Simple and economical — only a few planks and jacks are required, and it can be done with unskilled labour. Sequence: i) the top breast board is removed and the ground excavated 200–300 mm ahead, then the breast board is reset and braced back ii) the next cap board is set and held by a crutch/trench jack iii) the braced boards are removed one at a time and reset in a line below the top breast board, after excavating behind each, forming a new advanced face iv) the sill boards are advanced after checking the grade level v) the side posts are fixed between the sill board and the top cap. Its drawback: limited to short tunnels of small cross-section (A p.24–25, B p.7)." },
            { k: "def", term: "American method", t: "Suitable for large-sized highway or railway tunnels; involves simple operations and does not need heavy timber — but is unsuitable for tunnels with a flat bottom (A p.25, B p.7)." },
            { k: "def", term: "English method", t: "Uses a lot of timber, with frequent shifting of heavy timber logs back and forth — its greatest disadvantage. Masons and excavators must work alternately, so the process takes more time than other methods; if the soil is unstable, excavating the full section increases the danger of caving. Advantage: simple hauling can be adopted, and the lining is built in one piece from foundation to crown, giving strong, homogeneous construction (A p.26, B p.8)." },
            { k: "def", term: "Belgian method", t: "Advantages: i) uses lighter timber sections ii) work can start from different points simultaneously iii) the roof arch (exposed to the greatest pressure) is completed first, then the side walls and invert iv) cost is reduced as muck cars can be taken up to the farthest end in the centre trench. Disadvantage: settlement and cracks can appear in the arch masonry due to underpinning of the built arch, particularly if avoidable subsidence occurs — this is reduced by using R.C.C. arches (A p.26, B p.8)." },
            { k: "def", term: "German method", t: "Three drifts are used to support the roof and sides — one at the crown and two at the bottom along the walls (A p.27, B p.8)." },
            { k: "def", term: "Austrian method", t: "A centre cut is taken for the full height of the tunnel and then widened to the full face, to permit short sections of masonry to be completed. Adopted for long tunnels at great depths (A p.27, B p.8)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "These named methods are really variations on one idea — <b>excavate a small section, support it with timber immediately, then repeat</b> — and they differ mainly in how much timber they use and in what order the arch, walls and invert are built. Belgian builds the roof arch first because it carries the greatest pressure; German splits the work into three parallel drifts; Austrian takes a full-height centre cut for very deep, long tunnels where a wide open face would be unsafe." },
            { k: "trap", t: "The <b>Army/Case method</b> and the <b>Belgian method</b> are both economical and simple, but for different ground: Army/Case is for shallow, small sewers; Belgian is for 'all classes of moderately firm or hard soils' (B p.8) and larger sections." },
          ],
        },
        {
          n: "4.4",
          title: "Liner plates method",
          hi: "लाइनर प्लेट विधि",
          blocks: [
            { k: "h", t: "📘 Notes — A p.27, B p.8, p.14" },
            { k: "def", term: "Liner plates method", t: "Suitable when the strata is <b>sub-aqueous</b>. Standard-sized pressed steel plates, plain or corrugated, support the soil, and work proceeds in short lengths corresponding to the plate lengths. A p.27 gives liner plates as generally <b>400 mm × 900 mm with a 50 mm flange on all four sides</b>; B p.8 gives common sizes as <b>400 × 900 × 50 mm and 400 × 950 × 50 mm</b>. The method is easy to execute and economical, since fewer joints are needed (B p.8)." },
            { k: "note", t: "Source difference — the diameter above which the liner plates need stiffening ribs: A p.27 states stiffening becomes necessary when the <b>tunnel diameter ≥ 8 m</b>; B p.8 gives a much smaller threshold, <b>diameter &gt; 3 m</b>. Both are quoted as written; state which source you are following." },
            { k: "eq", expr: "Depth of the stiffening beam:  25 mm to 40 mm per metre of tunnel diameter  (B p.8)" },
            { k: "list", items: [
              "<b>Support mechanism for excavated soil</b> (B p.14) — the excavated soil mass must be supported: <b>temporary support</b> is used when the time needed to erect permanent supports is more than the failure time of the soil (also called the <i>bridge-action period</i>). <b>Permanent support</b> components: 1) <b>rock bolts</b> — pretensioned bolts 2) <b>bearing plates</b> — Type I (act like a temporary support) and Type II (grouted with cement, so they last longer).",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Liner plates and the timber methods of 4.3 solve the same problem with different materials — steel plates instead of wood — which is why liner plates are preferred in sub-aqueous ground where timber would rot or where speed matters more than cost. The temporary-vs-permanent support idea (B p.14) applies across all these methods: a temporary support only has to survive the 'bridge-action period' until the permanent lining takes over." },
            { k: "trap", t: "Don't take '25–40 mm per m of diameter' as the tunnel lining thickness — it is the depth of the <b>stiffening beam</b> for a liner plate, a different quantity from the lining-thickness formula T = 82D in section 4.6." },
          ],
        },
        {
          n: "4.5",
          title: "Shield tunnelling — dimensions, parts and shove types",
          hi: "शील्ड टनलिंग",
          blocks: [
            { k: "h", t: "📘 Notes — A p.28–31, B p.9–10" },
            { k: "def", term: "Shield", t: "A metal cylinder of hard steel plates, bent to the required curvature and thickness, riveted together (A's description gives 2–3 plates with countersunk-headed rivets). It acts as a bridge with a roof for workers, allowing them to work on the lining on one side and the face of attack on the other (A p.28, B p.9)." },
            { k: "list", items: [
              "<b>Length</b> of the shield is a compromise between the storage required inside it and the problem of governing/changing the direction of motion (A p.28).",
              "<b>Shape</b> — a circular section offers least resistance to motion (more perimeter per unit c/s area), gives the same working-space-per-unit-perimeter as a square section (D/4), is the only shape that permits rotation about its own axis, and resists surrounding soil pressure best since it has no weak corners and produces a natural arch action (A p.28).",
            ] },
            { k: "cmp", t: "Parts of the shield (A p.29, B p.9)", cols: ["Function"], rows: [
              ["1) Cutting edge (leading edge)", "Cuts the soil at the front as the shield is driven forward; a detachable 'hood' may be fitted over the top half so workers in loose soils can work under protection"],
              ["2) Central part (trunk portion)", "Gives the shield its strength; houses the shield-moving propelling jacks, plus extra jacks to prevent nosing up/down or to the sides (B p.9)"],
              ["3) Tail (rear portion)", "Stores segments of primary lining, loose stairs, pea shooter, generator set, welding set, circle boards, compressor units, cement gun; provides space for the erector arm/boom, assembly of lining rings, and the overlap with the newly built lining ring"],
            ] },
            { k: "list", items: [
              "Overlap between the shield tail and the newly set primary-lining ring: <b>maximum = 1½ × ring length</b>, <b>minimum = ½ × ring length</b> — the minimum exists right after a shove of the shield (A p.29, B p.9).",
              "Common equipment used with a shield: 1) supporting equipment — stretchers support breast boards, breast boards support the soil 2) <b>gravel tank</b>, with a pea shooter on wheels on loose planks, located 2–5 m from the rear of the shield 3) <b>chute</b> — a channel-shaped sloping platform discharging spoil onto the trailing dam, located near the trunk 4) <b>trailing dam</b> — an inclined platform (roughly a right-angled triangular dam section) just at the shield's rear end, transferring material from the chute to wagons/dumpers (A p.30–31, B p.10).",
            ] },
            { k: "h", t: "Shove types and the general sequence of shield tunnelling" },
            { k: "cmp", t: "Types of shove (A p.29–30)", cols: ["Meaning"], rows: [
              ["Open shove", "All doors at the front of the shield are kept open"],
              ["Partially blind shove", "Only a percentage of the openings at the front are kept open"],
              ["Blind shove", "The shield is driven in quicksand with its eyes/ports fully closed"],
            ] },
            { k: "note", t: "Source difference in the operating sequence. A p.30 gives 5 steps: 1) excavation 2) support for the face 3) assembly of primary lining 4) shove of shield 5) muck removal. B p.10 also gives 5 stages, but in a different order and with a distinct final stage: ① excavation ② mucking and hauling ③ advancement/shoving ④ erection of tunnel lining ⑤ grouting, caulking and drainage. Both are quoted as written." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "A shield does two jobs at once, front and back: at the cutting edge it holds the ground open long enough to excavate, and at the tail it lets a permanent ring of lining be built inside its protection before the ground can close in. That is why the tail <b>overlap</b> with the last-built ring is so tightly bounded (½ to 1½ ring lengths) — too little overlap and the ground is briefly unsupported; too much and the shield cannot advance." },
            { k: "trap", t: "The shield method does <b>not require timbering</b> (A p.31) — a common one-mark question, along with the liner-plate and compressed-air methods (section 4.4, 4.2)." },
          ],
        },
        {
          n: "4.6",
          title: "Tunnel lining — materials and the T = 82D formula",
          hi: "टनल लाइनिंग — सामग्री और T = 82D सूत्र",
          blocks: [
            { k: "h", t: "📘 Notes — A p.31–33" },
            { k: "def", term: "Tunnel lining", t: "The finishing treatment given to the tunnel cross-section. a) <b>Temporary lining</b> — provided to support the roof and walls during construction. b) <b>Permanent lining</b> — provided in soft ground, which is always liable to disintegrate (A p.31)." },
            { k: "eq", expr: "Thickness of lining (empirical):  T = 82 D", where: [
              ["T", "thickness of lining, in mm"],
              ["D", "diameter of the tunnel, in metres"],
              ["Minimum", "T is never taken less than 230 mm, irrespective of the lining material (A p.31, MES 2015)"],
            ] },
            { k: "eq", expr: "Thumb rule:  25 mm of lining thickness for every 300 mm of bore diameter  (A p.31)" },
            { k: "eq", expr: "Alternate (imperial) form, as given in the [Shrinivasan] book [reference reading uncertain, flagged [?] in the source]:  T = D, with T in inches and D in feet (A p.31)" },
            { k: "note", t: "<b>Check (v45): the three lining rules are one rule.</b> 25 mm per 300 mm of diameter = 83.3 mm per metre; 1 inch per foot = 25.4 mm ÷ 0.3048 m = 83.3 mm per metre; and the notes' T = 82D rounds the same ratio. So a 6 m bore gets about 82 × 6 ≈ 490–500 mm by any of the three forms, and the 230 mm minimum governs only below D ≈ 2.8 m (230/82). These are rule-of-thumb starting values for a trial section, not a design: the final lining thickness comes from a structural check of the lining against ground and water loads (General Engineering Knowledge)." },
            { k: "cmp", t: "Materials used for tunnel lining (A p.32–33)", cols: ["Notes"], rows: [
              ["1) Masonry (brick / stone)", "Brick masonry was the standard lining material but is now mostly out of use, except for sewers; its great disadvantage is the difficulty of back-packing the space between the tunnel roof and the arch extrados. Stone masonry has the same disadvantage but is still used for the side walls."],
              ["2) Cement concrete", "The standard material for both rock and soft-soil lining; gives proper packing, a smooth, waterproof, high-pressure-resistant finish with reinforcement, and needs minimum maintenance. In rock, concrete lining is provided concurrently with the driving operation."],
              ["3) Timber", "Used as both temporary and permanent support; easily and rapidly constructed, cheap, and gives a groaning sound as a warning before collapse — but it decays, is a fire hazard, and is unsuitable where water percolates."],
              ["4) Cast iron", "Suitable for shield-driven tunnels, particularly in sub-aqueous regions. Advantages: i) withstands jacking thrusts ii) can be made waterproof at the joints iii) accurately machined for a structural, tight fit iv) attains full strength immediately."],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "T = 82D is a quick empirical check, not a structural design formula — it gives a starting thickness in millimetres once you know the tunnel diameter in metres, and that thickness is never allowed to drop below 230 mm even for a very small bore. The material table moves in roughly the historical order lining materials were adopted: masonry → concrete → timber (as a cheap temporary measure) → cast iron for the toughest, wettest, shield-driven case." },
            { k: "trap", t: "Keep the two lining formulas' <b>units</b> straight: T = 82D uses T in mm and D in metres; the alternate rule T = D uses T in inches and D in feet. Mixing the unit systems gives a wildly wrong thickness." },
          ],
        },
        {
          n: "4.7",
          title: "Quick revision — excavation in soft ground",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Four soil classes for tunnelling (running, soft, firm, self-supporting) and what support each needs.",
              "Forepoling (running ground), compressed-air (clays, with the pressure/hours table), and needle-beam (firm ground, brick lining) methods.",
              "The six named timbering methods — Army/Case, American, English, Belgian, German, Austrian — and one distinguishing fact for each.",
              "Liner plates (sub-aqueous strata) and the stiffening-diameter threshold — note the A/B source conflict (8 m vs 3 m).",
              "Shield parts (cutting edge, trunk, tail), overlap limits (½–1½ ring length), and the three shove types.",
              "T = 82D (min. 230 mm) and the four tunnel-lining materials with their advantages and disadvantages.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "Liner plate, compressed-air and shield methods do not require timbering.",
              "Needle beam: 3–4 m/day advance, beam length 5–6 m — different numbers, don't swap them.",
              "Compressed air: ≤1.25 kg/cm² → 8 hr work/4 hr rest; the higher-pressure condition's exact cutoff is flagged as inconsistent in the source.",
              "Shield overlap with the lining ring: max 1½ ring length, min ½ ring length (right after a shove).",
              "T = 82D uses mm and metres; T = D (Shrinivasan) uses inches and feet — never mix the two.",
              "Stiffening of liner plates: A says diameter ≥ 8 m, B says diameter &gt; 3 m — quote whichever source the question follows.",
            ] },
          ],
        },
      ],
    },

  );
})();
