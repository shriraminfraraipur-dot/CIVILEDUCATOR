/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: GEOTECHNICAL handbook, Chapters 1–4
   Soil as a material · Index properties · Permeability · Seepage
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.2 THREE PHASE */
  "hb-ge-phase": {
    label: "The three-phase diagram, and everything that comes out of it",
    svg: `<svg viewBox="0 0 706 320" role="img" aria-label="A real soil sample of mixed grains, water and air redrawn as an idealised block separated into three layers of air, water and solids, with volumes marked on the left and weights on the right, from which void ratio, porosity, water content and degree of saturation are all defined.">
      ${hbmk("ph")}
      <text class="em" x="350" y="24" text-anchor="middle">SOIL IS NOT A MATERIAL — IT IS THREE MATERIALS IN A BOX</text>

      <text class="lb" x="112" y="60" text-anchor="middle">REAL SAMPLE</text>
      <rect class="conc" x="46" y="74" width="132" height="176"/>
      ${[[70,100],[104,94],[140,108],[62,134],[96,132],[134,140],[160,124],[74,168],[112,166],[148,172],[64,202],[104,204],[144,206],[86,232],[128,230]]
        .map(([x, y], i) => `<ellipse class="steel" cx="${x}" cy="${y}" rx="${9 + (i % 3) * 3}" ry="${7 + (i % 2) * 3}" transform="rotate(${i * 37} ${x} ${y})"/>`).join("")}
      <text class="lb" x="112" y="272" text-anchor="middle">grains, water between</text>
      <text class="lb" x="112" y="292" text-anchor="middle">them, air in the rest</text>

      <line class="ac" x1="196" y1="162" x2="238" y2="162" marker-end="url(#ph-c)"/>
      <text class="lb" x="217" y="150" text-anchor="middle">idealise</text>

      <text class="lb" x="330" y="60" text-anchor="middle">PHASE DIAGRAM</text>
      <rect class="soft" x="268" y="74" width="124" height="40"/>
      <rect class="softa" x="268" y="114" width="124" height="52"/>
      <rect class="conc" x="268" y="166" width="124" height="84"/>
      <text class="lb" x="330" y="99" text-anchor="middle">AIR</text>
      <text class="ea" x="330" y="145" text-anchor="middle">WATER</text>
      <text class="em" x="330" y="212" text-anchor="middle">SOLIDS</text>

      <line class="ac" x1="256" y1="74" x2="256" y2="166" marker-end="url(#ph-c)" marker-start="url(#ph-c)"/>
      <text class="ea" x="248" y="122" text-anchor="end">Vv</text>
      <line class="ac" x1="256" y1="166" x2="256" y2="250" marker-end="url(#ph-c)" marker-start="url(#ph-c)"/>
      <text class="ea" x="248" y="210" text-anchor="end">Vs</text>
      <line class="hi" x1="404" y1="114" x2="404" y2="166" marker-end="url(#ph-m)" marker-start="url(#ph-m)"/>
      <text class="em" x="412" y="144">Ww</text>
      <line class="hi" x1="404" y1="166" x2="404" y2="250" marker-end="url(#ph-m)" marker-start="url(#ph-m)"/>
      <text class="em" x="412" y="212">Ws</text>
      <text class="lb" x="330" y="272" text-anchor="middle">VOLUMES on the left</text>
      <text class="lb" x="330" y="292" text-anchor="middle">WEIGHTS on the right</text>

      <line class="gl" x1="460" y1="50" x2="460" y2="300"/>
      <text class="em" x="484" y="80">e = Vv / Vs        void ratio</text>
      <text class="em" x="484" y="106">n = Vv / V         porosity</text>
      <text class="em" x="484" y="132">w = Ww / Ws        water content</text>
      <text class="em" x="484" y="158">S = Vw / Vv        saturation</text>
      <line class="thin dash" x1="484" y1="176" x2="672" y2="176"/>
      <text class="ea" x="484" y="202">and the one identity that ties</text>
      <text class="ea" x="484" y="222">all four together:</text>
      <text class="em" x="484" y="252">S e  =  w G</text>
      <text class="lb" x="484" y="280">— know that, and you can get from</text>
      <text class="lb" x="484" y="298">any two of them to the other two</text>
    </svg>`,
    caption: "Air has volume but no weight; water has both; solids have both. That single asymmetry is why volumes go on one side of the diagram and weights on the other, and why every soil relationship falls out of drawing this box. <strong>Se = wG is the hinge</strong> — it is the only equation in Chapter 1 worth memorising, because the rest can be derived from the picture.",
  },

  /* ------------------------------------------- 2.2 ATTERBERG */
  "hb-ge-atterberg": {
    label: "The four states of a fine-grained soil",
    svg: `<svg viewBox="-16 0 732 280" role="img" aria-label="A horizontal water content axis along which a clay passes from a dry brittle solid through semi solid and plastic states to a liquid, with the shrinkage limit, plastic limit and liquid limit marking the three boundaries and the plasticity index being the width of the plastic range.">
      ${hbmk("at")}
      <text class="em" x="350" y="24" text-anchor="middle">ADD WATER TO A CLAY AND IT BECOMES A DIFFERENT MATERIAL</text>
      <line class="s" x1="60" y1="150" x2="640" y2="150" marker-end="url(#at-a)"/>
      <text class="lb" x="640" y="176" text-anchor="end">water content w →</text>

      ${[["SOLID", 108, "brittle · cracks", "volume stops changing"],
         ["SEMI-SOLID", 252, "crumbles when rolled", ""],
         ["PLASTIC", 412, "can be moulded", "and holds its shape"],
         ["LIQUID", 572, "flows under", "its own weight"]]
        .map(([t, x, a, b2]) => `
        <text class="em" x="${x}" y="110" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="196" text-anchor="middle">${a}</text>
        ${b2 ? `<text class="lb" x="${x}" y="214" text-anchor="middle">${b2}</text>` : ""}`).join("")}

      ${[["SL", 180, "shrinkage limit"], ["PL", 328, "plastic limit"], ["LL", 496, "liquid limit"]]
        .map(([t, x, n]) => `
        <line class="hi" x1="${x}" y1="128" x2="${x}" y2="172"/>
        <circle class="hif" cx="${x}" cy="150" r="5"/>
        <text class="em" x="${x}" y="122" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="240" text-anchor="middle">${n}</text>`).join("")}

      <line class="ac" x1="328" y1="66" x2="496" y2="66" marker-end="url(#at-c)" marker-start="url(#at-c)"/>
      <text class="ea" x="412" y="58" text-anchor="middle">PLASTICITY INDEX  PI = LL − PL</text>
      <text class="lb" x="350" y="268" text-anchor="middle">the limits are not properties of the water — they are properties of the CLAY, and that is why they classify it</text>
    </svg>`,
    caption: "Nothing about the mineral changes across this axis; only the water content does. A soil that stays mouldable over a wide band of water content has a large PI and a lot of clay in it — so <strong>the width of the plastic range is a measurement of the clay itself</strong>, obtained without ever looking at a grain.",
  },

  /* ------------------------------------------- 2.4 PLASTICITY CHART */
  "hb-ge-plasticity": {
    label: "The plasticity chart",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A plasticity chart with liquid limit on the horizontal axis and plasticity index on the vertical, divided by the A line into clays above and silts below, and by vertical lines at liquid limits of thirty five and fifty into low, intermediate and high compressibility.">
      ${hbmk("pl2")}
      <text class="em" x="350" y="24" text-anchor="middle">TWO NUMBERS IN, ONE SYMBOL OUT</text>
      <line class="s" x1="90" y1="256" x2="640" y2="256"/>
      <line class="s" x1="90" y1="60" x2="90" y2="256"/>
      <text class="lb" x="90" y="52" text-anchor="middle">PI</text>
      <text class="lb" x="638" y="304" text-anchor="end">liquid limit →</text>
      ${[0, 20, 35, 50, 70, 90].map(v => `<text class="lb" x="${90 + v * 6}" y="274" text-anchor="middle">${v}</text>
        <line class="thin" x1="${90 + v * 6}" y1="256" x2="${90 + v * 6}" y2="261"/>`).join("")}
      ${[10, 30, 50].map(v => `<text class="lb" x="82" y="${260 - v * 3.6}" text-anchor="end">${v}</text>`).join("")}

      <line class="acf" x1="300" y1="60" x2="300" y2="256" stroke="currentColor" stroke-width="1" stroke-dasharray="4 4"/>
      <line class="acf" x1="390" y1="60" x2="390" y2="256" stroke="currentColor" stroke-width="1" stroke-dasharray="4 4"/>
      <text class="lb" x="195" y="80" text-anchor="middle">LOW  (L)</text>
      <text class="lb" x="345" y="80" text-anchor="middle">INTERMEDIATE (I)</text>
      <text class="lb" x="510" y="80" text-anchor="middle">HIGH  (H)</text>

      <line class="hi" x1="210" y1="256" x2="640" y2="98"/>
      <text class="em" x="460" y="158" transform="rotate(-20 460 158)">A-line:  PI = 0.73 (LL − 20)</text>
      <text class="em" x="300" y="150">CLAYS — above the line</text>
      <text class="lb" x="300" y="170">CL  ·  CI  ·  CH</text>
      <text class="em" x="330" y="228">SILTS — below</text>
      <text class="lb" x="330" y="246">ML · MI · MH  (and organic OL, OI, OH)</text>
      <text class="lb" x="90" y="290">IS 1498 uses THREE compressibility bands at LL = 35 and 50 —</text>
      <text class="lb" x="90" y="308">the international USCS chart uses only one, at 50</text>
    </svg>`,
    caption: "The A-line is empirical, not theoretical: it is where a very large number of tested soils happened to separate. Above it a soil behaves as a clay, below it as a silt — and the practical difference is enormous, because a silt of the same plasticity index drains, dilates and loses strength quite differently from a clay.",
  },

  /* ------------------------------------------- 2.3 GRADING */
  "hb-ge-grading": {
    label: "Reading a grading curve",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Particle size distribution curves on a logarithmic size axis: a well graded soil with a smooth curve spanning a wide range of sizes, a poorly graded uniform soil with a steep curve over a narrow range, and a gap graded soil with a flat step where a range of sizes is missing.">
      ${hbmk("gr2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE SHAPE OF THE CURVE IS THE ENGINEERING BEHAVIOUR</text>
      ${[["WELL graded", 160, "em", "hi", "M96 184 C130 172 160 130 190 104 C208 88 218 80 226 76", "smooth over a wide range", "small grains fill gaps"],
         ["POORLY graded", 350, "ea", "ac", "M320 186 C336 180 344 140 350 110 C356 88 364 80 376 76", "steep \u2014 nearly one size", "nothing fills the voids"],
         ["GAP graded", 540, "lb", "thin", "M476 184 C494 176 506 166 518 160 L566 158 C580 140 594 100 606 76", "a flat step: a range of", "sizes is missing"]]
        .map(([t, cx, tc, cc, d, n1, n2]) => `
        <text class="${tc}" x="${cx}" y="58" text-anchor="middle">${t}</text>
        <line class="s" x1="${cx - 70}" y1="70" x2="${cx - 70}" y2="190"/>
        <line class="s" x1="${cx - 70}" y1="190" x2="${cx + 70}" y2="190"/>
        <path class="${cc}" d="${d}" fill="none"/>
        <text class="lb" x="${cx}" y="212" text-anchor="middle">${n1}</text>
        <text class="lb" x="${cx}" y="230" text-anchor="middle">${n2}</text>`).join("")}
      <text class="lb" x="350" y="254" text-anchor="middle">each panel: % finer up the side, particle size along the bottom (log scale)</text>
      <text class="em" x="90" y="280">Cu = D60 / D10</text>
      <text class="em" x="250" y="280">Cc = D30\u00b2 / (D10 \u00d7 D60)</text>
      <text class="lb" x="90" y="298">well graded sand: Cu &gt; 6 AND Cc = 1 to 3 \u2014 both must pass</text>
    </svg>`,
    caption: "A well graded soil compacts to a higher density and a higher strength than a uniform one of the same mineral, because the small particles pack into the spaces between the large ones. <strong>Both criteria must be satisfied</strong> — Cu alone is not enough, and a soil can pass on Cu and fail on Cc, which is exactly what a gap-graded soil does.",
  },

  /* ------------------------------------------- 3.3 PERMEABILITY TESTS */
  "hb-ge-perm": {
    label: "Constant head and falling head",
    svg: `<svg viewBox="0 0 700 310" role="img" aria-label="A constant head permeameter with an overflow keeping the head steady while the discharge is collected and timed, beside a falling head permeameter with a thin standpipe whose water level drops from one mark to another while being timed.">
      ${hbmk("pm")}
      <text class="em" x="168" y="26" text-anchor="middle">CONSTANT HEAD</text>
      <rect class="conc" x="96" y="120" width="112" height="106"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<ellipse class="steel" cx="${110+ (i%4)*28}" cy="${140+Math.floor(i/4)*44}" rx="10" ry="8"/>`).join("")}
      <rect class="softa" x="96" y="66" width="112" height="54"/>
      <line class="s" x1="96" y1="66" x2="208" y2="66"/>
      <path class="ac" d="M208 74 L232 74 L232 96"/>
      <text class="lb" x="242" y="86">overflow keeps</text>
      <text class="lb" x="242" y="104">the head constant</text>
      <line class="hi" x1="76" y1="66" x2="76" y2="226" marker-end="url(#pm-m)" marker-start="url(#pm-m)"/>
      <text class="em" x="68" y="150" text-anchor="end">h</text>
      <path class="ac" d="M152 226 L152 258"/>
      <path class="softa" d="M126 258 L178 258 L178 290 L126 290 Z"/>
      <text class="lb" x="188" y="278">collect Q in time t</text>
      <text class="em" x="60" y="306">k = Q L / (A h t)</text>

      <line class="gl" x1="330" y1="46" x2="330" y2="300"/>

      <text class="em" x="516" y="26" text-anchor="middle">FALLING HEAD</text>
      <rect class="conc" x="452" y="150" width="112" height="86"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<ellipse class="steel" cx="${466+ (i%4)*28}" cy="${168+Math.floor(i/4)*36}" rx="10" ry="8"/>`).join("")}
      <rect class="softa" x="500" y="60" width="16" height="90"/>
      <line class="s" x1="500" y1="56" x2="500" y2="150"/>
      <line class="s" x1="516" y1="56" x2="516" y2="150"/>
      <line class="hi" x1="484" y1="72" x2="532" y2="72"/>
      <line class="hi" x1="484" y1="124" x2="532" y2="124"/>
      <text class="em" x="540" y="76">h₁</text>
      <text class="em" x="540" y="128">h₂</text>
      <line class="ac" x1="470" y1="72" x2="470" y2="124" marker-end="url(#pm-c)"/>
      <text class="lb" x="576" y="100">thin standpipe,</text>
      <text class="lb" x="576" y="118">area a</text>
      <text class="em" x="420" y="262">k = 2.303 (a L)/(A t) × log₁₀(h₁/h₂)</text>
      <text class="lb" x="420" y="286">the head falls while the test runs, so</text>
      <text class="lb" x="420" y="304">it is timed between two marks</text>
    </svg>`,
    caption: "Which test depends entirely on how permeable the soil is. A sand passes enough water to measure comfortably at constant head; a clay would take days to yield a measurable volume, so the falling-head apparatus watches a thin standpipe instead — <strong>the small area a is what makes a tiny flow visible as a large drop in level</strong>.",
  },

  /* ------------------------------------------- 4.3 FLOW NET */
  "hb-ge-flownet": {
    label: "A flow net under a sheet pile",
    svg: `<svg viewBox="0 0 700 316" role="img" aria-label="Water seeping under a sheet pile wall from the high water side to the low water side, drawn as a net of curved flow lines running under the pile tip and equipotential lines fanning from the pile down to the impervious stratum, crossing at right angles to form approximate squares, with the number of flow channels and equipotential drops counted.">
      ${hbmk("fn")}
      <text class="em" x="350" y="24" text-anchor="middle">FLOW LINES AND EQUIPOTENTIALS CROSS AT RIGHT ANGLES \u2014 ALWAYS</text>
      <text class="em" x="350" y="48" text-anchor="middle">q = k H (Nf / Nd)   per unit length of wall</text>

      <rect class="conc" x="80" y="110" width="540" height="148" opacity="0.25"/>
      <rect class="softa" x="80" y="66" width="266" height="44"/>
      <rect class="softa" x="356" y="96" width="264" height="14"/>
      <line class="s" x1="80" y1="110" x2="620" y2="110"/>
      <line class="s" x1="80" y1="258" x2="620" y2="258"/>
      ${[0,1,2,3,4,5,6,7,8,9,10,11].map(i => `<line class="thin" x1="${88 + i * 46}" y1="258" x2="${78 + i * 46}" y2="268"/>`).join("")}
      <text class="lb" x="620" y="282" text-anchor="end">impervious stratum</text>
      <rect class="steel" x="346" y="56" width="10" height="124"/>
      <text class="lb" x="340" y="60" text-anchor="end">sheet pile \u2193</text>
      <line class="thin dash" x1="356" y1="96" x2="240" y2="96"/>
      <line class="hi" x1="250" y1="66" x2="250" y2="96"/>
      <line class="hi" x1="242" y1="66" x2="258" y2="66"/>
      <line class="hi" x1="242" y1="96" x2="258" y2="96"/>
      <text class="em" x="260" y="86">H</text>

      ${[[55, 214], [100, 233], [150, 257], [205, 286]].map(([a, cy]) =>
        `<path class="hi" d="M${351 - a} 110 C${351 - a} ${cy} ${351 + a} ${cy} ${351 + a} 110" fill="none"/>`).join("")}

      ${[[116, 130], [130, 185], [144, 235], [158, 282], [172, 320]].map(([y, x]) => {
        const c1 = Math.round(346 - (346 - x) * 0.45), c2 = Math.round(y + (258 - y) * 0.35);
        const xr = 702 - x, c1r = Math.round(356 + (xr - 356) * 0.45);
        return `<path class="ac" d="M346 ${y} C${c1} ${y} ${x} ${c2} ${x} 258" fill="none"/>
                <path class="ac" d="M356 ${y} C${c1r} ${y} ${xr} ${c2} ${xr} 258" fill="none"/>`;
      }).join("")}
      <line class="ac" x1="351" y1="180" x2="351" y2="258"/>

      <line class="hi" x1="80" y1="288" x2="110" y2="288"/>
      <text class="lb" x="118" y="292">flow lines \u2014 5 channels between them (Nf = 5)</text>
      <line class="ac" x1="80" y1="306" x2="110" y2="306"/>
      <text class="lb" x="118" y="310">equipotentials \u2014 12 drops between them (Nd = 12)</text>
    </svg>`,
    caption: "A flow net is a graphical solution of Laplace's equation, drawn by hand until the figures are approximately square. Its value is that <em>three</em> answers come out of one sketch: the quantity of seepage, the pore pressure anywhere in the field, and — most importantly — the <strong>exit gradient at the downstream toe</strong>, which is what decides whether the soil there will boil.",
  },

});
