/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: Structural Analysis handbook, Ch. 10–12
   Matrix methods · Plastic analysis · Dynamics
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 10.3 STIFFNESS COLUMN */
  "hb-sa-stiff-col": {
    label: "What one column of a stiffness matrix means",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A member with its far end held and its near end rotated by one radian, showing the four forces needed to hold it in that shape — these four values are one column of the member stiffness matrix">
      ${hbmk("sc2")}
      <text class="lb" x="350" y="26" text-anchor="middle">hold EVERY degree of freedom at zero except one — move that one by 1 — and ask what forces are needed</text>
      <line class="thin dash" x1="140" y1="150" x2="440" y2="150"/>
      <path class="s" d="M140 150 Q290 108 440 150"/>
      <line class="s" x1="440" y1="126" x2="440" y2="174"/>
      ${grd(440, 174, 24)}
      <circle class="acf" cx="140" cy="150" r="6"/>
      <path class="ac" d="M140 150 L228 128"/>
      <path class="thin" d="M196 150 A56 56 0 0 0 190 134"/>
      <text class="ea" x="206" y="168">θ = 1</text>

      <path class="hi" d="M118 128 A26 26 0 0 1 142 120" marker-start="url(#sc2-m)"/>
      <text class="em" x="112" y="114" text-anchor="end">4EI/L</text>
      <path class="hi" d="M458 128 A26 26 0 0 1 482 120" marker-start="url(#sc2-m)"/>
      <text class="em" x="488" y="118">2EI/L</text>
      <line class="hi" x1="140" y1="206" x2="140" y2="170" marker-end="url(#sc2-m)"/>
      <text class="em" x="140" y="226" text-anchor="middle">6EI/L²</text>
      <line class="hi" x1="440" y1="206" x2="440" y2="182" marker-end="url(#sc2-m)"/>
      <text class="em" x="440" y="226" text-anchor="middle">6EI/L²</text>

      <line class="gl" x1="40" y1="246" x2="660" y2="246"/>
      <text class="em" x="350" y="272" text-anchor="middle">Those four numbers ARE one column of the member stiffness matrix.</text>
      <text class="lb" x="350" y="294" text-anchor="middle">Repeat for each degree of freedom in turn and the whole matrix is built — nothing mysterious about it.</text>
    </svg>`,
    caption: "A stiffness coefficient k(i,j) is simply <strong>the force needed at i when displacement j is set to one and every other displacement is held at zero.</strong> The 4EI/L and 2EI/L of slope-deflection are two entries of exactly this matrix — the same physics, written as a table.",
  },

  /* ---------------------------------------- 10.4 ASSEMBLY */
  "hb-sa-matrix-dof": {
    label: "Assembling member matrices into the global matrix",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Two beam members sharing a joint, and the corresponding member stiffness matrices overlapping at the shared degree of freedom in the global matrix, where their contributions add">
      ${hbmk("as")}
      <line class="s" x1="60" y1="70" x2="330" y2="70"/>
      <line class="s" x1="330" y1="70" x2="600" y2="70"/>
      <path class="s" d="M60 70 L48 90 L72 90 Z"/>
      <path class="s" d="M330 70 L318 90 L342 90 Z"/>
      <path class="s" d="M600 70 L588 90 L612 90 Z"/>
      <circle class="acf" cx="60" cy="70" r="6"/><circle class="acf" cx="330" cy="70" r="6"/><circle class="acf" cx="600" cy="70" r="6"/>
      <text class="ea" x="60" y="56" text-anchor="middle">1</text>
      <text class="ea" x="330" y="56" text-anchor="middle">2</text>
      <text class="ea" x="600" y="56" text-anchor="middle">3</text>
      <text class="lb" x="195" y="110" text-anchor="middle">member A</text>
      <text class="lb" x="465" y="110" text-anchor="middle">member B</text>

      <line class="gl" x1="40" y1="134" x2="660" y2="134"/>

      <text class="lb" x="350" y="160" text-anchor="middle">GLOBAL STIFFNESS MATRIX — rows and columns are degrees of freedom</text>
      <rect class="conc" x="248" y="180" width="200" height="110"/>
      <line class="thin" x1="248" y1="216" x2="448" y2="216"/>
      <line class="thin" x1="248" y1="254" x2="448" y2="254"/>
      <line class="thin" x1="314" y1="180" x2="314" y2="290"/>
      <line class="thin" x1="382" y1="180" x2="382" y2="290"/>
      <rect class="softa" x="248" y="180" width="134" height="74"/>
      <rect class="soft" x="314" y="216" width="134" height="74"/>
      <text class="ea" x="281" y="204" text-anchor="middle">A</text>
      <text class="ea" x="348" y="204" text-anchor="middle">A</text>
      <text class="ea" x="281" y="242" text-anchor="middle">A</text>
      <text class="em" x="348" y="242" text-anchor="middle">A+B</text>
      <text class="em" x="415" y="242" text-anchor="middle">B</text>
      <text class="em" x="348" y="280" text-anchor="middle">B</text>
      <text class="em" x="415" y="280" text-anchor="middle">B</text>
      <text class="lb" x="238" y="204" text-anchor="end">1</text>
      <text class="lb" x="238" y="242" text-anchor="end">2</text>
      <text class="lb" x="238" y="280" text-anchor="end">3</text>
      <text class="lb" x="281" y="174" text-anchor="middle">1</text>
      <text class="lb" x="348" y="174" text-anchor="middle">2</text>
      <text class="lb" x="415" y="174" text-anchor="middle">3</text>
      <text class="em" x="500" y="244">the shared DOF —</text>
      <text class="em" x="500" y="264">both members</text>
      <text class="em" x="500" y="284">contribute, so they ADD</text>
      <text class="lb" x="120" y="244" text-anchor="middle">everything else</text>
      <text class="lb" x="120" y="264" text-anchor="middle">is zero — the two</text>
      <text class="lb" x="120" y="284" text-anchor="middle">ends never meet</text>
    </svg>`,
    caption: "Assembly is bookkeeping, not mathematics. Each member's matrix is dropped into the rows and columns of the degrees of freedom it connects, and <strong>where two members share a joint their coefficients add.</strong> The far-apart entries stay zero, which is why global stiffness matrices are sparse.",
  },

  /* ---------------------------------------- 11.2 PLASTIC SECTION */
  "hb-sa-plastic-stress": {
    label: "Stress distribution from first yield to full plasticity",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three stress blocks across a rectangular section: linear elastic, partly yielded, and fully plastic with two rectangular blocks, with the corresponding moments labelled">
      ${hbmk("ps")}
      <text class="em" x="116" y="28" text-anchor="middle">ELASTIC</text>
      <rect class="conc" x="66" y="60" width="44" height="140"/>
      <line class="thin dash" x1="60" y1="130" x2="200" y2="130"/>
      <path class="softa" d="M110 60 L170 60 L110 130 Z"/>
      <path class="softa" d="M110 130 L110 200 L170 200 Z" transform="translate(-60,0)"/>
      <path class="ac" d="M110 60 L170 60 L110 130 L50 200 L110 200 Z" fill="none"/>
      <text class="lb" x="176" y="66">σ &lt; fy</text>
      <text class="em" x="116" y="230" text-anchor="middle">M = fy × Ze</text>
      <text class="lb" x="116" y="252" text-anchor="middle">first yield at the</text>
      <text class="lb" x="116" y="270" text-anchor="middle">extreme fibre only</text>

      <line class="gl" x1="236" y1="16" x2="236" y2="286"/>

      <text class="em" x="350" y="28" text-anchor="middle">PARTLY PLASTIC</text>
      <rect class="conc" x="300" y="60" width="44" height="140"/>
      <line class="thin dash" x1="294" y1="130" x2="434" y2="130"/>
      <path class="soft" d="M344 60 L404 60 L404 96 L344 110 Z"/>
      <path class="soft" d="M344 200 L284 200 L284 164 L344 150 Z"/>
      <path class="hi" d="M344 60 L404 60 L404 96 L344 110" fill="none"/>
      <text class="lb" x="410" y="66">fy</text>
      <text class="em" x="350" y="230" text-anchor="middle">Ze &lt; Z &lt; Zp</text>
      <text class="lb" x="350" y="252" text-anchor="middle">yield spreading inward,</text>
      <text class="lb" x="350" y="270" text-anchor="middle">elastic core shrinking</text>

      <line class="gl" x1="470" y1="16" x2="470" y2="286"/>

      <text class="em" x="584" y="28" text-anchor="middle">FULLY PLASTIC</text>
      <rect class="conc" x="534" y="60" width="44" height="140"/>
      <line class="hi" x1="528" y1="130" x2="668" y2="130"/>
      <path class="soft-b" d="M578 60 L638 60 L638 130 L578 130 Z"/>
      <path class="soft-b" d="M578 130 L518 130 L518 200 L578 200 Z"/>
      <text class="lb" x="644" y="66">fy</text>
      <text class="em" x="584" y="230" text-anchor="middle">Mp = fy × Zp</text>
      <text class="lb" x="584" y="252" text-anchor="middle">whole section at yield —</text>
      <text class="lb" x="584" y="270" text-anchor="middle">a plastic hinge has formed</text>
    </svg>`,
    caption: "Elastic design stops at the first picture — one fibre reaching yield. <strong>The section keeps taking more moment long after that</strong>, until the stress block is fully rectangular. The ratio of the two moments is the shape factor, and it is reserve strength that elastic design simply throws away.",
  },

  /* ---------------------------------------- 11.5 MECHANISM */
  "hb-sa-mechanism": {
    label: "Collapse mechanism of a fixed beam",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A fixed ended beam under uniform load, with plastic hinges forming at both supports and at mid-span, and the resulting collapse mechanism with rotation theta at the ends and two theta at the centre">
      ${hbmk("me")}
      <line class="s" x1="120" y1="70" x2="560" y2="70"/>
      <line class="s" x1="120" y1="48" x2="120" y2="92"/>
      <line class="s" x1="560" y1="48" x2="560" y2="92"/>
      ${grd(98, 92, 24)} ${grd(560, 92, 24)}
      ${[0,1,2,3,4,5,6,7,8,9].map(i=>`<line class="ac" x1="${128+i*45}" y1="36" x2="${128+i*45}" y2="62" marker-end="url(#me-c)"/>`).join("")}
      <text class="ea" x="340" y="28" text-anchor="middle">w</text>

      <line class="gl" x1="60" y1="118" x2="660" y2="118"/>

      <text class="lb" x="350" y="144" text-anchor="middle">COLLAPSE MECHANISM — three hinges, one degree of freedom</text>
      <line class="thin dash" x1="120" y1="186" x2="560" y2="186"/>
      <path class="s" d="M120 186 L340 236 L560 186"/>
      <line class="s" x1="120" y1="164" x2="120" y2="208"/>
      <line class="s" x1="560" y1="164" x2="560" y2="208"/>
      ${grd(98, 208, 24)} ${grd(560, 208, 24)}
      <circle class="hif" cx="120" cy="186" r="7"/>
      <circle class="hif" cx="340" cy="236" r="7"/>
      <circle class="hif" cx="560" cy="186" r="7"/>
      <text class="em" x="120" y="168" text-anchor="middle">Mp</text>
      <text class="em" x="340" y="262" text-anchor="middle">Mp</text>
      <text class="em" x="560" y="168" text-anchor="middle">Mp</text>
      <path class="thin" d="M158 186 A38 38 0 0 1 154 196"/>
      <text class="lb" x="176" y="200">θ</text>
      <path class="thin" d="M300 226 A44 44 0 0 0 380 226"/>
      <text class="lb" x="340" y="216" text-anchor="middle">2θ</text>
      <path class="thin" d="M522 186 A38 38 0 0 0 526 196"/>
      <text class="lb" x="508" y="200" text-anchor="end">θ</text>

      <line class="gl" x1="60" y1="272" x2="660" y2="272"/>
      <text class="em" x="350" y="294" text-anchor="middle">Internal work = Mp(θ + 2θ + θ) = 4Mpθ        External work = w × ½L × (L/2)θ = wL²θ/4</text>
    </svg>`,
    caption: "Collapse needs <strong>enough hinges to turn the structure into a mechanism</strong> — here three, because the fixed beam is indeterminate to the second degree and one more hinge makes it move. Equating internal and external work through the same virtual rotation gives the collapse load directly.",
  },

  /* ---------------------------------------- 12.2 SDOF */
  "hb-sa-sdof": {
    label: "The single degree of freedom model and free vibration",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Left, a water tank on a staging idealised as a mass on a spring with a dashpot. Right, the decaying free vibration trace with the period marked and successive peaks used for the logarithmic decrement.">
      ${hbmk("sf")}
      <text class="lb" x="140" y="26" text-anchor="middle">THE MODEL</text>
      <rect class="conc" x="82" y="52" width="116" height="52" rx="4"/>
      <text class="lb" x="140" y="84" text-anchor="middle">mass m</text>
      <path class="s" d="M118 104 L118 128 L104 136 L132 148 L104 160 L132 172 L118 180 L118 200"/>
      <path class="s" d="M168 104 L168 130 M154 130 L182 130 L182 168 L154 168 Z M168 168 L168 200"/>
      <text class="lb" x="96" y="150" text-anchor="end">k</text>
      <text class="lb" x="192" y="152">c</text>
      ${grd(90, 200, 100)}
      <line class="ac" x1="198" y1="78" x2="250" y2="78" marker-end="url(#sf-c)"/>
      <text class="ea" x="256" y="82">u(t)</text>
      <text class="lb" x="140" y="240" text-anchor="middle">m ü + c u̇ + k u = 0</text>
      <text class="em" x="140" y="272" text-anchor="middle">ω = √(k/m)</text>
      <text class="em" x="140" y="296" text-anchor="middle">T = 2π√(m/k)</text>

      <line class="gl" x1="300" y1="16" x2="300" y2="310"/>

      <text class="lb" x="500" y="26" text-anchor="middle">FREE VIBRATION WITH DAMPING</text>
      <line class="s" x1="330" y1="150" x2="670" y2="150" marker-end="url(#sf-a)"/>
      <line class="s" x1="336" y1="70" x2="336" y2="230"/>
      <path class="hi" d="M336 90 Q368 90 384 150 Q400 210 416 150 Q430 104 448 150 Q462 190 478 150 Q492 116 508 150 Q520 178 536 150 Q548 126 564 150 Q576 168 592 150 Q604 136 620 150"/>
      <path class="thin dash" d="M336 90 Q470 120 620 145"/>
      <path class="thin dash" d="M336 210 Q470 180 620 155"/>
      <text class="lb" x="330" y="86" text-anchor="end">u₀</text>
      <line class="thin" x1="416" y1="240" x2="478" y2="240" marker-start="url(#sf-a)" marker-end="url(#sf-a)"/>
      <text class="em" x="447" y="258" text-anchor="middle">T</text>
      <circle class="acf" cx="430" cy="107" r="4"/>
      <circle class="acf" cx="492" cy="119" r="4"/>
      <text class="ea" x="430" y="98" text-anchor="middle">u₁</text>
      <text class="ea" x="492" y="110" text-anchor="middle">u₂</text>
      <text class="lb" x="500" y="286" text-anchor="middle">logarithmic decrement  δ = ln(u₁/u₂) ≈ 2πζ</text>
      <text class="lb" x="500" y="306" text-anchor="middle">— which is how damping is measured on a real structure</text>
    </svg>`,
    caption: "One mass, one spring, one dashpot. Crude, and enough for a very large part of earthquake design — <strong>a water tank on a staging, or a single-storey building, really does behave like this.</strong> The period T is the property that matters most, because the design codes read their spectra against it.",
  },

  /* ---------------------------------------- 12.5 RESONANCE */
  "hb-sa-dmf": {
    label: "Dynamic magnification against frequency ratio, for several damping values",
    svg: `<svg viewBox="0 0 700 330" role="img" aria-label="Curves of dynamic magnification factor against the ratio of forcing frequency to natural frequency, showing a sharp peak at a ratio of one which becomes lower and broader as damping increases">
      ${hbmk("dm")}
      <line class="s" x1="90" y1="262" x2="640" y2="262" marker-end="url(#dm-a)"/>
      <line class="s" x1="90" y1="262" x2="90" y2="50" marker-end="url(#dm-a)"/>
      <text class="lb" x="640" y="290" text-anchor="end">β = ω(force) / ω(natural)</text>
      <text class="lb" x="84" y="46" text-anchor="end">DMF</text>
      <line class="thin dash" x1="255" y1="50" x2="255" y2="262"/>
      <text class="em" x="255" y="282" text-anchor="middle">1.0</text>
      <text class="lb" x="420" y="282" text-anchor="middle">2.0</text>
      <text class="lb" x="90" y="282" text-anchor="middle">0</text>
      <line class="thin" x1="84" y1="230" x2="96" y2="230"/>
      <text class="lb" x="78" y="234" text-anchor="end">1</text>

      <path class="hi" d="M90 230 Q180 214 230 130 Q250 62 262 66 Q280 76 300 150 Q340 214 420 240 Q520 252 620 256"/>
      <text class="em" x="276" y="58">ζ = 0.02</text>
      <path class="ac" d="M90 230 Q182 218 232 168 Q252 128 264 132 Q284 140 306 180 Q346 224 424 244 Q522 254 620 258"/>
      <text class="ea" x="330" y="140">ζ = 0.05</text>
      <path class="s" d="M90 230 Q184 222 236 200 Q254 188 268 190 Q290 196 314 210 Q352 232 428 248 Q524 256 620 258"/>
      <text class="lb" x="390" y="196">ζ = 0.20</text>

      <line class="gl" x1="60" y1="298" x2="660" y2="298"/>
      <text class="em" x="350" y="320" text-anchor="middle">At resonance (β = 1):  DMF = 1 / (2ζ).   At ζ = 5%, that is 10 — the force is magnified ten times.</text>
    </svg>`,
    caption: "Damping barely matters away from resonance and decides everything at it. <strong>IS 1893 assumes 5% damping for reinforced concrete</strong>, and the design spectrum it gives is essentially this curve, smoothed and dressed for a whole population of possible ground motions.",
  },

});
