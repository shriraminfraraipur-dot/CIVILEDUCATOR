/* ============================================================
   HYDROLOGY · COMPLETE NOTES — Chapter 11: Formula Sheet
   Defensive-guard pattern: safe to load in any order.
   ============================================================ */
window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-11", n: 11,
    title: "Formula Sheet — Hydrology",
    hi: "सूत्र पत्रक — जल विज्ञान",
    blurb: "A single compact revision chapter pulling together this handbook's most-used equations, organised by topic and cited back to the chapter each one was derived in: water-budget/continuity, rainfall statistics (Cv, optimum gauge count), missing-rainfall and areal-averaging methods (normal-ratio, Thiessen, isohyetal, DAD), evaporation/evapotranspiration (Dalton, Meyer, Penman), Horton's infiltration equation and W-/φ-index, runoff (Q=CiA, form factor, Dicken's/Ryve's/Inglis's), streamflow measurement (area-velocity, dilution, slope-area, % error relations), hydrograph/Unit Hydrograph theory (t_c, DRH, S-curve, Snyder's), flood frequency (Gumbel's) and flood routing (Muskingum) — plus a consolidated list of every genuine cross-source numeric/definitional conflict found while building this handbook's 10 content chapters, none silently resolved.",
    mins: 22,
    sections: [
      {
        n: "11.1", title: "Hydrologic cycle & water budget (Ch.1)", hi: "जल चक्र और जल बजट",
        blocks: [
          { k: "eq", expr: "Catchment water budget:  P − R − G − E − T = ΔS   [G, E, T together = \"Losses\"]        (hydro-1, S1 p.2)", where: [
            ["P", "total precipitation"], ["R", "total runoff"], ["ΔS", "change in storage"],
          ] },
          { k: "eq", expr: "Equivalent decomposition:  ΔS = ΔS_t + ΔS_sm + ΔS_g  ;  Runoff = Rainfall − Losses        (hydro-1, V p.3)" },
          { k: "eq", expr: "Reservoir water-budget form:  (I1+I2)/2·Δt + P̄·A_res = (Q1+Q2)/2·Δt + E·A_res + G1·A_res + ΔS        (hydro-1, S1 p.3)" },
        ],
      },
      {
        n: "11.2", title: "Rainfall statistics — mean, variability, optimum gauge network (Ch.2)", hi: "वर्षा सांख्यिकी",
        blocks: [
          { k: "eq", expr: "Mean rainfall:  P̄ = (P1+P2+…+Pn)/n        (hydro-2, S2 p.12)" },
          { k: "eq", expr: "Standard deviation — form 1:  σ = √[Σ(P−P̄)²/(n−1)]   ;   form 2 (algebraically identical):  σ = √[n/(n−1)·(mean(P²) − P̄²)]        (hydro-2, S1 p.14; S2 p.12)" },
          { k: "eq", expr: "Coefficient of variation:  Cv = (σ/P̄) × 100  (%)   — India: 15–70%, average ≈30%        (hydro-2, S2 p.7)" },
          { k: "eq", expr: "Optimum number of rain-gauge stations:  N = (Cv/ε)²        (hydro-2, S2 p.12)", where: [["ε", "allowable % error in the estimate of mean rainfall"]] },
          { k: "eq", expr: "Radar: average echo power P_H = C·Z/r²  ,  Z = 200·I^1.6        (hydro-2, S2 p.9)" },
        ],
      },
      {
        n: "11.3", title: "Missing data & areal averaging — normal-ratio, Thiessen, isohyetal, DAD (Ch.3)", hi: "अनुपलब्ध डेटा और क्षेत्रीय औसत",
        blocks: [
          { k: "eq", expr: "Arithmetic-mean method (missing station):  Px = (P1+P2+…+Pm)/m        (hydro-3, S2 p.15)" },
          { k: "eq", expr: "Normal-ratio method:  Px = (Nx/m)·[P1/N1 + P2/N2 + … + Pm/Nm]        (hydro-3, S2 p.15–16)" },
          { k: "eq", expr: "Station-shift correction:  Pcx = (mc/ma) × Px        (hydro-3, S2 p.17)" },
          { k: "eq", expr: "Arithmetic-mean areal rainfall:  P̄ = (P1+…+Pn)/n        (hydro-3, S2 p.18)" },
          { k: "eq", expr: "Thiessen-polygon method:  P̄ = Σ Pi·(Ai/A)        (hydro-3, S2 p.19)" },
          { k: "eq", expr: "Isohyetal method (interior strips):  P̄ = Σ[(Pi+Pi+1)/2 · Ai] / ΣAi   ; including the two outermost strips: P̄ = [P1·A0 + Σ(Pi+Pi+1)/2·Ai + Pn·An] / (A0+ΣAi+An)        (hydro-3, S3 p.20–21)" },
          { k: "eq", expr: "DAD (depth-area) relation:  P̄ = P0 · e^(−K·A^n)        (hydro-3, S3 p.23)", where: [["P0", "max. depth at storm centre"], ["A", "area, km²"]] },
          { k: "eq", expr: "Frequency-depth-duration (intensity) relation:  i_max = K·Tˣ / (t_H + B)ⁿ        (hydro-3, S3 p.25)" },
          { k: "eq", expr: "Probable Maximum Precipitation — statistical:  PMP = P̄ + K·σ   ;   meteorological (WMO):  PMP = 42.16·D^0.475  [D in hr, PMP in cm]        (hydro-3, S3 p.26)" },
        ],
      },
      {
        n: "11.4", title: "Evaporation & evapotranspiration — Dalton, Meyer, Penman, water/energy budget (Ch.4)", hi: "वाष्पीकरण और वाष्पोत्सर्जन",
        blocks: [
          { k: "eq", expr: "Dalton's law:  E = K(es − ea)  [mm/day]        (hydro-4, S2 p.31)" },
          { k: "eq", expr: "Meyer's formula:  E = K(es − ea)[1 + Vg/16]  [mm/day]   (K=0.36 large/deep water body, K=0.5 small/shallow)        (hydro-4, S2 p.36)" },
          { k: "eq", expr: "Reservoir evaporation = Cp × Pan evaporation   (Cp ≈ 0.70 Class-A/USA pan, ≈0.80 I.S. pan)        (hydro-4, S2 p.33; S3 p.13)" },
          { k: "eq", expr: "Water-budget method:  P + Vis + Vig = E + Vos + Vog + TL + ΔS        (hydro-4, S2 p.37–38)" },
          { k: "eq", expr: "Energy-budget method:  E = (Hn − Hg − Hs − Hi) / [ρL(β+1)]        (hydro-4, S2 p.40–41)" },
          { k: "eq", expr: "Penman's combined equation (PET):  PET = (A·Hn + Ea·γ)/(A+γ)  [mm/day]   with  Ea = 0.35(es−ea)[1 + U2/160]        (hydro-4, S2 p.49)" },
        ],
      },
      {
        n: "11.5", title: "Infiltration — Horton's equation, W-index, φ-index (Ch.5)", hi: "रिसाव",
        blocks: [
          { k: "eq", expr: "Horton's equation:  fp = fc + (fo−fc)·e^(−Kh·t)   [0 ≤ t ≤ tc]        (hydro-5, S2 p.38)" },
          { k: "eq", expr: "Cumulative infiltration (Case 1, t ≤ tc):  F̄p ≈ fc·t + (fo−fc)/Kh   [large Kh·t approximation]        (hydro-5, S2 p.40)" },
          { k: "eq", expr: "Cumulative infiltration (Case 2, t > tc):  Fp = fc·tc + (fo−fc)/Kh + fc·(t−tc)        (hydro-5, S2 p.40)" },
          { k: "eq", expr: "W-index = Total infiltration / Total storm duration        (hydro-5, S2 p.42) — ⚠ see 11.11, S3 gives a different form" },
          { k: "eq", expr: "φ-index = (Infiltration during rainfall-excess periods) / (duration of those excess periods)   ⇒  Runoff Q = (rainfall during excess period) − φ·(duration of excess period)        (hydro-5, S2 p.42, 44)" },
        ],
      },
      {
        n: "11.6", title: "Runoff & catchment characteristics — Q=CiA, shape factors, empirical peak-flow formulas (Ch.6)", hi: "अपवाह और जलक्षेत्र विशेषताएँ",
        blocks: [
          { k: "eq", expr: "Rational formula:  Q = C·i·A        (hydro-6, S1 p.4–9)" },
          { k: "eq", expr: "Form factor:  FF = B/L = A/L²   ;   Compactness coefficient:  CC = P/(2π·r) = P/(2√(πA)), r=√(A/π)        (hydro-6, S2 p.93–94)" },
          { k: "eq", expr: "Drainage density:  DD = L/A   ;   Stream density:  SD = N/A        (hydro-6, S2 p.95)" },
          { k: "eq", expr: "Dicken's formula:  Qp = CD·A^(3/4)   [CD ≈ 6–30, by region]        (hydro-6, S2 p.96)" },
          { k: "eq", expr: "Ryve's formula:  Qp = CR·A^(2/3)   [CR ≈ 6.8–10.2 (S2) or 6–8 (S3) — ⚠ see 11.11]        (hydro-6, S2 p.96; S3 p.32)" },
          { k: "eq", expr: "Inglis's formula (Western Ghats region):  Qp = 124·A/(√A+10.4) [S2]  or  124·A/√(A+10.4) [S3]  ;  simplified: Qp = 123√A [S2] or 124√A [S3] — ⚠ see 11.11", where: [["Qp", "m³/s"], ["A", "km²"]] },
        ],
      },
      {
        n: "11.7", title: "Streamflow measurement — area-velocity, dilution, slope-area, % error relations (Ch.7)", hi: "प्रवाह मापन",
        blocks: [
          { k: "eq", expr: "Current-meter calibration:  V = a·N + b        (hydro-7, S2 p.53; S3 p.21)" },
          { k: "eq", expr: "One-point method (shallow):  V̄ = V at 0.6y from top   ;   Two-point method (deep):  V̄ = (V0.2y + V0.8y)/2        (hydro-7, S2 p.54; S3 p.21–22)" },
          { k: "eq", expr: "Mid-section method:  ai = W̄i·yi·vi   ;   Q = Σ ai        (hydro-7, S2 p.55–56)" },
          { k: "eq", expr: "Moving-boat method:  ai = [(yi−1+yi)/2]·VR²·sinθ·cosθ·t   ;   Q = Σ ai        (hydro-7, S2 p.57)" },
          { k: "eq", expr: "Dilution (mass-balance) method:  Q0 = Qs(Cmix−Cs)/(C0−Cmix)        (hydro-7, S2 p.58)" },
          { k: "eq", expr: "Slope-area method:  Q = K√(HF/L)   ,   K = (A/n)R^(2/3) (Manning)        (hydro-7, S2 p.60–61)" },
          { k: "eq", expr: "% error in Q vs % error in head H:  rectangular weir Q∝H^(3/2) ⇒ %errQ = 1.5·%errH   ;   V-notch Q∝H^(5/2) ⇒ %errQ = 2.5·%errH        (hydro-7, S2 p.62)" },
        ],
      },
      {
        n: "11.8", title: "Hydrographs & Unit Hydrograph theory — t_c, DRH, S-curve, Snyder's (Ch.8)", hi: "जलांकलेख और एकक जलांकलेख",
        blocks: [
          { k: "eq", expr: "Time of concentration:  t_c = 0.01947·K^0.77   ,   K = √(L³/ΔH)        (hydro-8, S2 p.68–69)" },
          { k: "eq", expr: "Lag time:  t_L = t_PK − D/2        (hydro-8, S2 p.67)" },
          { k: "eq", expr: "DRH ordinates & runoff depth:  O_i = Q_i − B   ;   Ah = 3600·Σ(O_i·t) [m³]   ⇒   R = 0.36·Σ(O_i·t)/A  [cm]        (hydro-8, S2 p.70)" },
          { k: "eq", expr: "UH scaling:  Ordinate of DRH = Ordinate of UH × R        (hydro-8, S2 p.72)" },
          { k: "eq", expr: "S-curve equilibrium discharge:  Qs = A·R0 = A/D = 2.778·A/D  [A km², D hr, Qs m³/s]        (hydro-8, S2 p.78)" },
          { k: "eq", expr: "S-curve → T-hr UH:  ΔY = S-curve ordinate − (S-curve lagged by T) ordinate   ⇒  T-hr UH ordinate = ΔY·D/T        (hydro-8, S2 p.81)" },
          { k: "eq", expr: "Snyder's Synthetic UH:  tp = Ct(L·Lca)^0.3  ;  tR = tp/5.5  ;  tp′ = (21/22)tp + tR/4  ;  Qp′ = 2.78·Cp·A/tp′  ;  W50 = 5.87/(qV)^1.08  ;  W75 = W50/1.75  ;  tB′ = 72+3tp′        (hydro-8, S2 p.85–86)" },
          { k: "eq", expr: "IUH:  U(t) = (dS/dt)·(1/R0)        (hydro-8, S2 p.89)" },
        ],
      },
      {
        n: "11.9", title: "Floods, flood frequency & flood routing — Gumbel's method, Muskingum (Ch.9)", hi: "बाढ़, बाढ़ आवृत्ति और बाढ़ मार्गन",
        blocks: [
          { k: "eq", expr: "Return period / probability:  P = 1/T   ;   Risk = 1 − (1−P)ⁿ        (hydro-9, S2 p.98)" },
          { k: "eq", expr: "Binomial probability of r occurrences in n years:  P(r,n) = ⁿCᵣ·Pʳ·qⁿ⁻ʳ        (hydro-9, S2 p.99)" },
          { k: "eq", expr: "Gumbel's method:  XT = X̄ + KT·σ   ,   KT = (YT−Ȳn)/Sn   ,   YT = −ln·ln(T/(T−1))        (hydro-9, S2 p.101–103)" },
          { k: "eq", expr: "Confidence limits:  X1,2 = XT ± f(c)·Se   ,   Se = (b·σ)/√N   ,   b = √(1+1.3K+1.1K²)        (hydro-9, S2 p.104)" },
          { k: "eq", expr: "Muskingum storage:  S = K[x·Iᵘ + (1−x)·Qᵘ]   (routing form, u=1):  S2−S1 = K[x(I2−I1)+(1−x)(Q2−Q1)]        (hydro-9, S2 p.106)" },
          { k: "eq", expr: "Muskingum routing equation:  Qn = C0·In + C1·In−1 + C2·Qn−1   (C0+C1+C2=1)\nC0 = (−Kx+0.5Δt)/(K(1−x)+0.5Δt) ;  C1 = (Kx+0.5Δt)/(K(1−x)+0.5Δt) ;  C2 = (K(1−x)−0.5Δt)/(K(1−x)+0.5Δt)        (hydro-9, S2 p.107–108)" },
        ],
      },
      {
        n: "11.10", title: "Droughts — Index of Wetness, Aridity Index (Ch.10)", hi: "सूखा",
        blocks: [
          { k: "eq", expr: "Index of Wetness:  I.O.W = (year's rainfall / ≥30-yr average annual rainfall) × 100        (hydro-10, S2 p.4)" },
          { k: "eq", expr: "Aridity Index:  A.I = [1 − AET/PET] × 100 = [(PET−AET)/PET] × 100        (hydro-10, S2 p.6)" },
        ],
      },
      {
        n: "11.11", title: "⚠️ Where this handbook's sources disagree — consolidated", hi: "⚠️ जहाँ स्रोत असहमत हैं — समेकित सूची",
        blocks: [
          { k: "h", t: "Every genuine cross-source numeric/definitional conflict found while building Chapters 1–10, collected here in one place (none silently resolved — see each chapter for the full discussion)" },
          { k: "list", items: [
            "<b>India's average annual rainfall:</b> S1/V give ≈119–120 cm/yr; S2/V elsewhere give ≈119.4–120 cm/yr against a world average of ≈100 cm/yr — figures are close but not identical across the sources (Ch.1 §1.4, Ch.2 §2.3).",
            "<b>Tipping-bucket gauge's country of origin:</b> S1 attributes Tipping-bucket to the U.K. and Weighing-bucket to the U.S.A.; S2 and V both attribute Tipping-bucket to the U.S. Weather Bureau — two sources against one (Ch.2 §2.4).",
            "<b>Coefficient of variation formula:</b> V's transcript states Cv = 1000σ/P̄ (likely an OCR slip of 100→1000); S1/S2 both use the conventional Cv = (σ/P̄)×100% — kept exactly as each source states it (Ch.2 §2.6).",
            "<b>W-index definition:</b> S2 defines it as Total infiltration/Total duration (no initial-loss term); S3 instead gives W-index = (P−R−Initial loss)/t. Every worked example in the chapter that computes W uses S2's plain form (Ch.5 §5.6).",
            "<b>Ryve's constant CR:</b> S2 gives 6.8–10.2; S3 gives 6–8 for the same formula (Ch.6 §6.7).",
            "<b>Inglis's formula:</b> S2's denominator is (√A+10.4), S3's is √(A+10.4) — mathematically different; the simplified-form constant also differs, 123√A (S2) vs 124√A (S3, specifically for Maharashtra) (Ch.6 §6.7).",
            "<b>\"US method\" naming:</b> S3 labels two different flood-frequency formulas \"US method\" (p.48) and \"US crop method\" (p.49) in close succession — read in context as likely California's method and the U.S. Corps of Engineers' method respectively, but the source's own labelling is ambiguous and reproduced as given (Ch.9 §9.3).",
            "Two source-internal arithmetic slips (not cross-source conflicts, but genuine errors found while cross-checking) are flagged with <b>Check:</b> notes rather than silently fixed, in Ch.1 §1.3 (a lake water-budget example with three transcription slips) and Ch.3 §3.5 (an isohyetal-method example giving 33.33 cm where the source's own areas work out to 13.33 cm).",
          ] },
        ],
      },
      {
        n: "11.12", title: "Quick revision — formula-sheet checklist", hi: "त्वरित पुनरावृत्ति — सूत्र-पत्रक जाँच सूची",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Water budget P−R−G−E−T=ΔS; Cv=(σ/P̄)×100; optimum gauges N=(Cv/ε)² (11.1–11.2).",
            "Normal-ratio Px=(Nx/m)Σ(Pi/Ni); Thiessen P̄=ΣPi(Ai/A); isohyetal strip-weighted average; DAD P̄=P0·e^(−K·Aⁿ) (11.3).",
            "Dalton E=K(es−ea); Meyer E=K(es−ea)[1+Vg/16]; Penman PET=(A·Hn+Ea·γ)/(A+γ) (11.4).",
            "Horton fp=fc+(fo−fc)e^(−Kh·t); W-index=ΣF/Σt; φ-index over the excess period only (11.5).",
            "Q=CiA; Form Factor=A/L²; Dicken's Qp=CD·A^(3/4); Ryve's Qp=CR·A^(2/3); Inglis's Qp≈123–124√A — ⚠ constants vary by source (11.6).",
            "Current-meter V=aN+b; two-point V̄=(V0.2y+V0.8y)/2; mid-section Q=Σ(W̄i·yi·vi); dilution Q0=Qs(Cmix−Cs)/(C0−Cmix); %errQ = (exponent)×%errH for weirs (11.7).",
            "t_c=0.01947K^0.77; DRH ordinate=Q−B, R=0.36Σ(O·t)/A; S-curve Qs=2.778A/D; Snyder's tp=Ct(L·Lca)^0.3 chain (11.8).",
            "Gumbel's XT=X̄+KT·σ with KT from the reduced variate; Muskingum Qn=C0·In+C1·In−1+C2·Qn−1 (11.9).",
            "Index of Wetness and Aridity Index for drought classification (11.10).",
            "Seven genuine cross-source conflicts found across this handbook, all kept side-by-side rather than silently resolved — see 11.11 for the full list.",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Every empirical peak-flow/runoff formula (Dicken's, Ryve's, Inglis's) is region-calibrated — the constant is the whole point, memorise which region each belongs to, not just the exponent on A.",
            "Unit Hydrograph theory rests on linearity + time-invariance + superposition; the S-curve is simply the tool that lets you change the UH's duration without re-deriving it from a fresh storm.",
            "A return period T is NOT the same as 'this will happen once every T years guaranteed' — it is a probability statement (P=1/T per year), which is why the binomial/risk formulas matter for design life.",
            "Where two class-note sources genuinely disagree on a constant or a formula, this handbook keeps both and says so — never guesses which one an exam wants.",
          ] },
        ],
      },
    ],
  });
})();
