/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: GEOTECHNICAL handbook, Chapters 5–8
   Effective stress · Stress distribution · Compaction · Consolidation
   Includes two animated figures — contract as in dia-anim1.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 5.1 EFFECTIVE STRESS */
  "hb-ge-effstress": {
    label: "Why only part of the stress does anything",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Soil grains in contact with water filling the voids between them, showing that the total stress is carried partly by contact forces between the grains and partly by pressure in the pore water, and that only the grain to grain part controls strength and compression.">
      ${hbmk("es")}
      <text class="em" x="350" y="24" text-anchor="middle">WATER CANNOT PUSH GRAINS TOGETHER — IT CAN ONLY HOLD THEM APART</text>
      ${[0,1,2,3,4,5].map(i=>`<line class="ac" x1="${100+i*36}" y1="52" x2="${100+i*36}" y2="78" marker-end="url(#es-c)"/>`).join("")}
      <text class="ea" x="196" y="46" text-anchor="middle">total stress σ</text>
      <rect class="softa" x="76" y="82" width="240" height="150"/>
      ${[[110,112],[160,106],[212,118],[266,110],[96,156],[146,152],[196,158],[250,150],[296,160],[120,200],[172,196],[224,204],[276,200]]
        .map(([x, y], i) => `<ellipse class="steel" cx="${x}" cy="${y}" rx="${16 + (i % 3) * 3}" ry="${13 + (i % 2) * 3}" transform="rotate(${i * 31} ${x} ${y})"/>`).join("")}
      ${[[135,109],[186,112],[239,114],[121,178],[159,174],[210,180],[263,175]]
        .map(([x, y]) => `<circle class="hif" cx="${x}" cy="${y}" r="4"/>`).join("")}
      <text class="em" x="196" y="256" text-anchor="middle">the dots are GRAIN CONTACTS</text>
      <text class="lb" x="210" y="278" text-anchor="middle">the pale fill between them is pore water, at pressure u</text>

      <line class="gl" x1="352" y1="44" x2="352" y2="290"/>
      <text class="em" x="380" y="78">σ  =  σ′  +  u</text>
      <text class="lb" x="380" y="106">total = effective + pore pressure</text>
      <line class="thin dash" x1="380" y1="124" x2="668" y2="124"/>
      <text class="ea" x="380" y="152">σ′ acts at the grain contacts.</text>
      <text class="lb" x="380" y="174">It is the ONLY part that controls</text>
      <text class="lb" x="380" y="196">strength, compression and settlement.</text>
      <text class="ea" x="380" y="228">u acts equally in all directions.</text>
      <text class="lb" x="380" y="250">It pushes grains APART, so raising it</text>
      <text class="lb" x="380" y="272">weakens the soil without adding any load.</text>
    </svg>`,
    caption: "Terzaghi's principle, and the single most important sentence in soil mechanics. Every failure mechanism in this handbook — a slope sliding after rain, a dam boiling at its toe, a foundation settling for years after it was built — is <strong>σ′ changing while σ stays exactly the same</strong>.",
  },

  /* ------------------------------------------- 6.3 PRESSURE BULB */
  "hb-ge-bulb": {
    label: "How a footing's load spreads with depth",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A footing on soil with contours of equal vertical stress beneath it forming a bulb shape, the stress being intense immediately under the footing and dropping to a tenth of the applied pressure at a depth of about one and a half times the footing width.">
      ${hbmk("bu")}
      <text class="em" x="350" y="24" text-anchor="middle">THE LOAD SPREADS — AND THE DEPTH THAT MATTERS SCALES WITH B</text>
      <rect class="conc" x="150" y="64" width="120" height="20"/>
      <text class="lb" x="210" y="56" text-anchor="middle">footing, width B</text>
      <line class="s" x1="50" y1="84" x2="380" y2="84"/>
      ${[["0.5q", 34, 108], ["0.2q", 62, 156], ["0.1q", 88, 212], ["0.05q", 112, 260]].map(([t, rx, yb]) =>
        `<path class="hi" d="M${210 - rx} 84 C${210 - rx} ${Math.round(84 + (yb - 84) / 0.75)} ${210 + rx} ${Math.round(84 + (yb - 84) / 0.75)} ${210 + rx} 84" fill="none"/>
         <text class="ea" x="210" y="${yb + 16}" text-anchor="middle">${t}</text>`).join("")}
      <line class="ac" x1="70" y1="84" x2="70" y2="212" marker-end="url(#bu-c)" marker-start="url(#bu-c)"/>
      <text class="ea" x="62" y="152" text-anchor="end">≈1.5B</text>
      <text class="lb" x="210" y="288" text-anchor="middle">the 0.1q contour is the usual practical limit of interest</text>

      <line class="gl" x1="410" y1="44" x2="410" y2="290"/>
      <text class="em" x="436" y="76">σz = KB Q / z²</text>
      <text class="lb" x="436" y="100">Boussinesq: a point load on an elastic,</text>
      <text class="lb" x="436" y="120">homogeneous, isotropic half-space</text>
      <text class="ea" x="436" y="154">KB depends only on r/z:</text>
      <text class="lb" x="436" y="178">r/z = 0.0  →  0.478</text>
      <text class="lb" x="436" y="198">r/z = 0.5  →  0.273</text>
      <text class="lb" x="436" y="218">r/z = 1.0  →  0.084</text>
      <text class="lb" x="436" y="238">r/z = 2.0  →  0.009</text>
      <text class="em" x="436" y="272">note what that means: a WIDE footing</text>
      <text class="em" x="436" y="292">reaches far deeper than a narrow one</text>
    </svg>`,
    caption: "The last line is the practical consequence and it catches people out. Two footings at the same bearing pressure, one 1 m wide and one 4 m wide, stress the ground to about 1.5 m and 6 m respectively. <strong>The wide one may settle far more</strong>, because it reaches a compressible layer the narrow one never touches — which is why a borehole has to go deep enough for the biggest footing, not the average one.",
  },

  /* ------------------------------------------- 7.2 COMPACTION CURVE */
  "hb-ge-compact": {
    label: "The compaction curve, and why it has a peak",
    svg: `<svg viewBox="0 0 760 318" role="img" aria-label="A compaction curve of dry density against water content rising to a maximum at the optimum moisture content and falling beyond it, with the zero air voids line above and to the right of it, and curves for heavier compactive effort lying higher and to the left.">
      ${hbmk("cp2")}
      <text class="em" x="380" y="24" text-anchor="middle">THERE IS A BEST WATER CONTENT — AND MORE IS WORSE</text>
      <line class="s" x1="100" y1="250" x2="540" y2="250"/>
      <line class="s" x1="100" y1="56" x2="100" y2="250"/>
      <text class="lb" x="92" y="62" text-anchor="end">dry density γd</text>
      <text class="lb" x="538" y="276" text-anchor="end">water content w →</text>

      <line class="thin dash" x1="160" y1="62" x2="520" y2="230"/>
      <text class="lb" x="250" y="96" transform="rotate(25 250 96)">zero air voids line (S = 100%)</text>

      <path class="hi" d="M150 244 C205 216 258 180 300 172 C348 182 420 214 486 244"/>
      <circle class="hif" cx="300" cy="172" r="6"/>
      <line class="thin dash" x1="100" y1="172" x2="300" y2="172"/>
      <line class="thin dash" x1="300" y1="172" x2="300" y2="250"/>
      <text class="em" x="96" y="168" text-anchor="end">MDD</text>
      <text class="em" x="300" y="270" text-anchor="middle">OMC</text>

      <path class="ac" d="M140 240 C190 194 226 156 262 150 C306 156 372 186 420 214"/>
      <text class="ea" x="122" y="124">heavier effort:</text>
      <text class="lb" x="122" y="142">higher peak,</text>
      <text class="lb" x="122" y="160">drier optimum</text>

      <text class="lb" x="130" y="292">DRY side: water lubricates</text>
      <text class="lb" x="130" y="310">grains into a tighter packing</text>
      <text class="em" x="420" y="292">WET side: water fills the voids</text>
      <text class="em" x="420" y="310">and the roller cannot squeeze it out</text>
      <line class="gl" x1="588" y1="60" x2="588" y2="286"/>
      <text class="lb" x="606" y="110">the curve can NEVER</text>
      <text class="lb" x="606" y="130">cross the ZAV line —</text>
      <text class="lb" x="606" y="150">that would mean</text>
      <text class="lb" x="606" y="170">negative air</text>
      <text class="em" x="606" y="204">so the gap between</text>
      <text class="em" x="606" y="224">them IS the air voids</text>
      <text class="em" x="606" y="244">left in the fill</text>
    </svg>`,
    caption: "The peak exists because water does two opposite things. Up to the optimum it lubricates the grains so they slide into a denser packing; beyond it, the voids are nearly full and water — being incompressible and slow to drain — takes up space the roller cannot expel. <strong>The zero air voids line is a hard ceiling</strong>, never a target: reaching it would mean a perfectly saturated fill with no air at all.",
  },

  /* ------------------------------------------- 8.5 e–log p */
  "hb-ge-elogp": {
    label: "The e–log p curve, and what a soil remembers",
    svg: `<svg viewBox="0 0 745 300" role="img" aria-label="A void ratio against logarithm of effective stress plot showing a flat recompression line up to the preconsolidation pressure, then a steeper straight virgin compression line beyond it, with an unload reload loop of much smaller slope.">
      ${hbmk("el")}
      <text class="em" x="372" y="24" text-anchor="middle">SOIL REMEMBERS THE HEAVIEST LOAD IT HAS EVER CARRIED</text>
      <line class="s" x1="100" y1="250" x2="600" y2="250"/>
      <line class="s" x1="100" y1="56" x2="100" y2="250"/>
      <text class="lb" x="92" y="62" text-anchor="end">void ratio e</text>
      <text class="lb" x="598" y="276" text-anchor="end">log σ′ →</text>

      <path class="hi" d="M130 88 C200 94 250 100 300 110"/>
      <path class="hi" d="M300 110 L560 232"/>
      <circle class="hif" cx="300" cy="110" r="6"/>
      <line class="thin dash" x1="300" y1="110" x2="300" y2="250"/>
      <text class="em" x="300" y="270" text-anchor="middle">σ′c — preconsolidation pressure</text>
      <text class="ea" x="150" y="80">RECOMPRESSION — flat</text>
      <text class="lb" x="150" y="130">it has been here before,</text>
      <text class="lb" x="150" y="148">so it barely compresses</text>
      <text class="em" x="400" y="86">VIRGIN COMPRESSION</text>
      <text class="lb" x="400" y="106">a straight line on log axes —</text>
      <text class="lb" x="400" y="124">and its slope is Cc</text>
      <path class="ac" d="M470 190 C440 185 412 179 386 174"/>
      <path class="ac" d="M386 178 C414 185 442 190 470 194"/>
      <text class="ea" x="316" y="215">unload–reload loop:</text>
      <text class="lb" x="316" y="233">slope Cr, far smaller than Cc</text>

      <line class="gl" x1="626" y1="56" x2="626" y2="286"/>
      <text class="em" x="638" y="110">σ′₀ = σ′c</text>
      <text class="lb" x="638" y="130">normally</text>
      <text class="lb" x="638" y="148">consolidated</text>
      <text class="em" x="638" y="186">σ′₀ &lt; σ′c</text>
      <text class="lb" x="638" y="206">OVER-</text>
      <text class="lb" x="638" y="224">consolidated</text>
      <text class="lb" x="638" y="246">— and it will</text>
      <text class="lb" x="638" y="264">settle far less</text>
    </svg>`,
    caption: "Everything about settlement depends on which side of σ′c the new stress lands. A normally consolidated clay loaded further moves down the steep virgin line and settles a great deal; an overconsolidated one — a clay that once had glaciers or eroded ground on top of it — moves along the flat recompression line and hardly settles at all. <strong>Finding σ′c is therefore the whole point of a consolidation test.</strong>",
  },

  /* ============================================== ANIMATED ============== */

  /* ------------------------------------------- 8.2 SPRING ANALOGY */
  "an-ge-consol": {
    label: "The spring analogy: load transferring from water to soil",
    anim: true,
    svg: `<svg viewBox="-16 0 732 320" role="img" aria-label="Three cylinders fitted with a piston, a spring and water with a valve. At the instant of loading the water carries all of it and the spring is uncompressed. As water escapes through the valve the spring shortens and takes more of the load. Finally the water pressure has returned to zero and the spring carries everything.">
      ${hbmk("cn2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE SPRING IS THE SOIL SKELETON · THE WATER IS THE PORE WATER</text>
      ${[["t = 0", 120, 0, 0, ["ALL the load is", "in the WATER"], "u = Δσ   ·   σ′ = 0"],
         ["t = some time", 350, 1.3, 1, ["water escaping —", "the spring takes over"], "u falling   ·   σ′ rising"],
         ["t = ∞", 580, 2.6, 2, ["ALL of it is", "in the SPRING"], "u = 0   ·   σ′ = Δσ"]]
        .map(([t, x, del, k, note, eq]) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <rect class="conc" x="${x - 52}" y="${86 + k * 20}" width="104" height="14"/>
        <line class="ac" x1="${x}" y1="60" x2="${x}" y2="82" marker-end="url(#cn2-c)"/>
        <rect class="softa" x="${x - 50}" y="${100 + k * 20}" width="100" height="${112 - k * 20}"/>
        <path class="s" d="M${x - 52} 100 L${x - 52} 214 L${x + 52} 214 L${x + 52} 100"/>
        <path class="hi" d="${[0, 1, 2, 3, 4].map(i =>
          `M${x - 34} ${112 + k * 20 + i * (94 - k * 20) / 5} L${x + 34} ${112 + k * 20 + (i + 0.5) * (94 - k * 20) / 5}`).join(" ")}"/>
        <path class="s" d="M${x + 52} 150 L${x + 74} 150"/>
        ${k === 2 ? `<line class="s" x1="${x + 68}" y1="142" x2="${x + 80}" y2="158"/>` : ""}
        ${k < 2 ? [0, 1, 2].map(i => `<circle class="acf an-pulse" style="--dur:3s;--del:${del + i * 0.25}s" cx="${x + 82 + i * 12}" cy="150" r="3"/>`).join("") : ""}
        <text class="lb" x="${x}" y="240" text-anchor="middle">${note[0]}</text>
        <text class="lb" x="${x}" y="258" text-anchor="middle">${note[1]}</text>
        <text class="em" x="${x}" y="286" text-anchor="middle">${eq}</text>`).join("")}
      <line class="gl" x1="235" y1="46" x2="235" y2="298"/>
      <line class="gl" x1="465" y1="46" x2="465" y2="298"/>
      <text class="lb" x="350" y="312" text-anchor="middle">the TOTAL stress never changes — only how it is shared, and that sharing takes time because the valve is small</text>
    </svg>`,
    caption: "Watch the water escaping and the spring shortening. Nothing is added to the cylinder after the first instant — <strong>the total load is constant throughout</strong>, and all that happens is a slow handover from the water to the skeleton. That handover is consolidation, the valve is the soil's permeability, and the time it takes is why a building on clay goes on settling for years.",
  },

  /* ------------------------------------------- 5.4 WATER TABLE RISING */
  "an-ge-wt": {
    label: "What a rising water table does to effective stress",
    anim: true,
    svg: `<svg viewBox="0 0 720 316" role="img" aria-label="A soil profile with a water table that rises, showing the total stress diagram barely changing while the pore pressure diagram grows and the effective stress diagram shrinks, so the soil loses strength although nothing was excavated or loaded.">
      ${hbmk("wt2")}
      <text class="em" x="350" y="24" text-anchor="middle">NOTHING IS ADDED · NOTHING IS REMOVED · THE SOIL GETS WEAKER</text>
      <line class="s" x1="60" y1="70" x2="200" y2="70"/>
      <rect class="conc" x="60" y="70" width="140" height="180" opacity="0.3"/>
      <line class="ac an-sag" style="--amp:-52;--dur:5s" x1="60" y1="184" x2="200" y2="184"/>
      <path class="acf an-sag" style="--amp:-52;--dur:5s" d="M196 178 L206 184 L196 190 Z"/>
      <text class="ea" x="214" y="188">water table</text>
      <text class="lb" x="130" y="272" text-anchor="middle">the soil itself is untouched</text>

      <text class="lb" x="330" y="62" text-anchor="middle">σ  total</text>
      <line class="s" x1="286" y1="70" x2="286" y2="250"/>
      <path class="soft" d="M286 70 L286 250 L344 250 Z"/>
      <text class="lb" x="330" y="272" text-anchor="middle">barely changes</text>

      <text class="lb" x="460" y="62" text-anchor="middle">u  pore pressure</text>
      <line class="s" x1="416" y1="70" x2="416" y2="250"/>
      <path class="softa an-grow" style="--dur:5s" d="M416 132 L416 250 L472 250 Z"/>
      <text class="em" x="460" y="272" text-anchor="middle">GROWS</text>

      <text class="lb" x="596" y="62" text-anchor="middle">σ′ = σ − u</text>
      <line class="s" x1="548" y1="70" x2="548" y2="250"/>
      <path class="soft-b" d="M548 70 L548 250 L588 250 L568 132 Z"/>
      <text class="em" x="596" y="272" text-anchor="middle">SHRINKS</text>
      <text class="lb" x="350" y="290" text-anchor="middle">this is why slopes fail after rain, why excavations flood and heave,</text>
      <text class="lb" x="350" y="308" text-anchor="middle">and why the water table is the first thing a report states</text>
    </svg>`,
    caption: "The total stress diagram hardly moves — the soil above is the same soil, only a little heavier once saturated. But the pore pressure grows from nothing, and <strong>every kilopascal it gains is a kilopascal σ′ loses</strong>. A slope that stood for twenty years can fail in one monsoon without a single grain being added to it.",
  },

});
