/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING MATERIALS · Chapters 3–5
   Bricks & blocks · Cement · Lime, pozzolana & gypsum
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bm");
  if (!hb) { console.error("[bm2] handbook bm not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "bm-3",
      n: 3,
      title: "Bricks and Blocks",
      hi: "ईंट और ब्लॉक",
      blurb: "The parts of a brick and why the frog faces up, the sizes that actually get delivered, the three tests that grade a brick, and where blocks beat bricks.",
      mins: 24,
      sections: [
        {
          n: "3.1",
          title: "Anatomy, sizes and the frog",
          hi: "बनावट, नाप और फ्रॉग",
          blocks: [
            { k: "p", t: "A brick is the unit the whole trade is built around, so its geometry has names worth knowing — you cannot describe a bond, or spot a badly laid wall, without them." },
            { k: "dia", id: "hb-bm-brick", cap: "The three faces of a brick, the two standard sizes, and the frog." },
            { k: "def", term: "Modular brick (IS 1077)", t: "190 × 90 × 90 mm. With a 10 mm mortar joint it works to a clean 200 × 100 × 100 module, so 500 bricks make one cubic metre of brickwork — which is why estimating in modular bricks is so tidy." },
            { k: "def", term: "Frog", t: "The recess pressed into the top bed of a machine-made brick. It keys the mortar to the brick and carries the maker's mark. It is laid upwards, always: frog-down leaves a mortar void that weakens the joint and holds water." },
            { k: "trap", t: "The conventional Indian brick is still about 230 × 110 × 70 mm, not the modular 190 × 90 × 90. Estimate with the wrong size and your brick count and mortar quantity are both off from the start. Always confirm the size actually being delivered." },
          ],
        },
        {
          n: "3.2",
          title: "How a brick is made — and why burning is everything",
          hi: "ईंट कैसे बनती है",
          blocks: [
            { k: "p", t: "A clay brick passes through four stages: preparing the clay, moulding, drying, and burning. The first three shape it; the fourth is what turns dried mud into a durable ceramic. Under-burn it and it stays soft and soluble; over-burn it and it warps and vitrifies into a brittle, mis-shapen lump." },
            { k: "steps", items: [
              "<strong>Clay preparation</strong> — weathering, tempering and pugging to a uniform, plastic mass free of stones and roots.",
              "<strong>Moulding</strong> — ground-moulded by hand, or machine-moulded (stiff-mud extrusion or pressed) for sharp, uniform bricks.",
              "<strong>Drying</strong> — slow air-drying to remove most of the water before burning, or the brick cracks in the kiln.",
              "<strong>Burning</strong> — heating to ~900–1100 °C. This is the stage that makes the brick: the clay minerals fuse and it gains strength, hardness and water resistance.",
            ] },
            { k: "cmp", t: "Under-burnt, well-burnt, over-burnt",
              cols: ["Well-burnt (first class)", "Poorly burnt"],
              rows: [
                ["Colour", "uniform deep red", "pale (under) / dark warped (over)"],
                ["Sound when struck", "clear metallic ring", "dull thud"],
                ["Strength", "meets its class", "low (under) / brittle (over)"],
                ["Shape & edges", "sharp, true, uniform", "irregular, cracked"],
                ["Use", "exposed & load-bearing work", "filling, non-structural only"],
              ] },
            { k: "real", t: "The old field test survives because it works: a first-class brick struck against another gives a clear ring and does not break when dropped from about a metre; a poorly burnt one gives a dull thud and chips or breaks. <strong>You are hearing whether the clay actually fused.</strong>" },
          ],
        },
        {
          n: "3.3",
          title: "The three tests that grade a brick",
          hi: "ईंट को परखने के तीन टेस्ट",
          blocks: [
            { k: "p", t: "Three laboratory tests turn the field impressions into numbers, and a brick can pass one while failing another — so they answer three separate questions." },
            { k: "dia", id: "hb-bm-bricktests", cap: "Compressive strength, water absorption and efflorescence — three questions." },
            { k: "eg", title: "Example 3.1 — Water absorption of a brick",
              given: "A brick weighs 3000 g oven-dry. After 24 hours immersed in water it weighs 3510 g. Is it a first-class brick on absorption?",
              steps: [
                { t: "Water taken up", w: "W₂ − W₁ = 3510 − 3000 = 510 g" },
                { t: "As a fraction of dry weight", w: "absorption = (W₂ − W₁) / W₁ × 100\n        = 510 / 3000 × 100\n        = 17.0 %" },
                { t: "Compare with the limit", w: "first class ≤ 20 %  ·  17.0 % < 20 %  → passes" },
              ],
              ans: "17.0% absorption — within the 20% ceiling, so it qualifies as first class on this test. A brick that drinks more than about a fifth of its own weight is heading for frost and staining trouble." },
            { k: "def", term: "Efflorescence", t: "A white bloom of soluble salts left on the surface as absorbed water evaporates. Tested by standing the brick in water and letting it dry: the salts rise, the water leaves, and the salt stays. 'Nil' to 'slight' is acceptable; heavier deposits will later push through plaster and paint." },
            { k: "note", t: "Compressive strength gives the brick its class number (3.5, 7.5, 10 N/mm² and up) — the minimum strength of the class, tested on the brick immersed and with its frog filled with mortar. The class you specify is set by how high and how loaded the wall is." },
          ],
        },
        {
          n: "3.4",
          title: "When a block beats a brick",
          hi: "ब्लॉक कब बेहतर है",
          blocks: [
            { k: "p", t: "Blocks — concrete, hollow concrete, fly-ash, AAC (autoclaved aerated concrete) — are larger units that win on speed and, for some, on weight and insulation. They are not simply bigger bricks; each trades something." },
            { k: "cmp", t: "Brick vs the common blocks",
              cols: ["Burnt-clay brick", "AAC / hollow block"],
              rows: [
                ["Speed of laying", "slow — small units", "fast — one block = several bricks"],
                ["Self-weight", "heavy", "light (AAC floats in water)"],
                ["Insulation", "moderate", "good (air voids)"],
                ["Load capacity", "high", "lower — check for load-bearing use"],
                ["Where it wins", "load-bearing, exposed", "infill in framed buildings, partitions"],
              ] },
            { k: "real", t: "In a modern RCC-framed apartment block the walls carry no building load — the frame does — so the wall only has to stand up, keep weather out and insulate. That is exactly where AAC wins: lighter walls mean smaller beams and columns, and the frame gets cheaper because the infill got lighter." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "bm-4",
      n: 4,
      title: "Cement",
      hi: "सीमेंट",
      blurb: "What cement is made of, why setting is a chemical reaction and not drying, what the four compounds each do, the field and lab tests, and the main types and when to use them.",
      mins: 28,
      sections: [
        {
          n: "4.1",
          title: "From two rocks to a powder that becomes rock again",
          hi: "सीमेंट कैसे बनता है",
          blocks: [
            { k: "p", t: "Portland cement is made by burning limestone and clay together at around 1450 °C until they fuse into hard nodules called clinker, then grinding the clinker with a little gypsum. The name comes from its resemblance, when set, to Portland stone." },
            { k: "dia", id: "hb-bm-cement", cap: "Manufacture, the four compounds, and what setting really is." },
            { k: "def", term: "Setting (hydration)", t: "Cement does not dry — it reacts. Added water chemically combines with the compounds to grow interlocking crystals, giving off heat. This is why concrete sets under water, why it warms while curing, and why you keep it damp rather than let it dry out." },
            { k: "trap", t: "'Let the concrete dry' is exactly wrong. Drying stops hydration and leaves the concrete weak. Curing — keeping it wet for days — is what lets the reaction run to strength. The two ideas are opposites, and confusing them is the most expensive beginner's mistake on a slab." },
          ],
        },
        {
          n: "4.2",
          title: "The four compounds, and what each one does",
          hi: "चार यौगिक",
          blocks: [
            { k: "p", t: "Cement behaviour is decided by the proportions of four compounds (the Bogue compounds). You do not need the chemistry, but you do need what each one contributes, because every special cement is just a re-balancing of these four." },
            { k: "cmp", t: "The four compounds",
              cols: ["Gives early / much", "Gives late / little"],
              rows: [
                ["C₃S (alite)", "most early strength, much heat", "—"],
                ["C₂S (belite)", "—", "slow, long-term strength, low heat"],
                ["C₃A (aluminate)", "flash set + most heat", "little strength; gypsum tames it"],
                ["C₄AF (ferrite)", "—", "colour, very little strength"],
              ] },
            { k: "list", items: [
              "<strong>Rapid-hardening cement</strong> is just OPC with more C₃S (and ground finer) — earlier strength, more heat.",
              "<strong>Low-heat cement</strong> lowers C₃A and C₃S so it releases heat slowly — for mass concrete like dams, where heat cracks the pour.",
              "<strong>Sulphate-resisting cement</strong> limits C₃A, because it is C₃A that sulphates attack.",
            ] },
            { k: "note", t: "This is the single most useful idea in the chapter: the special cements are not exotic — each is ordinary Portland cement with the compound balance shifted to buy one property (speed, low heat, sulphate resistance) at the cost of another." },
          ],
        },
        {
          n: "4.3",
          title: "Testing cement — field and laboratory",
          hi: "सीमेंट के टेस्ट",
          blocks: [
            { k: "p", t: "On site you check cement by hand before you trust it; in the lab a set of standard tests grade it against IS 4031." },
            { k: "cmp", t: "Quick field checks (before you open the bag to a mix)",
              cols: ["Good cement", "Reject it"],
              rows: [
                ["Feel", "cool, smooth, no lumps", "warm, gritty, hard lumps"],
                ["Colour", "uniform greenish-grey", "patchy"],
                ["Float test", "particles sink slowly", "floats (air-set, spoilt)"],
                ["Date", "within a few months of packing", "old, stored damp"],
              ] },
            { k: "dia", id: "hb-bm-vicat", cap: "Initial and final setting time, measured by needle penetration." },
            { k: "list", items: [
              "<strong>Fineness</strong> — finer cement hydrates faster and gains early strength; tested by sieving or air-permeability.",
              "<strong>Setting time</strong> — initial (≥ 30 min for OPC) gives working time; final (≤ 600 min) marks when it has stiffened. Vicat apparatus.",
              "<strong>Soundness</strong> — checks it will not expand after setting (free lime/magnesia cause late expansion); Le-Chatelier test.",
              "<strong>Compressive strength</strong> — the real grade, tested on cement-sand cubes at 3, 7 and 28 days.",
            ] },
            { k: "trap", t: "The grade number of cement — 33, 43, 53 — is its 28-day compressive strength in N/mm², not a mix proportion and not a quality score. A 53-grade cement is stronger early but generates more heat and is not automatically 'better'; for ordinary masonry a 43-grade is often the right choice." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "bm-5",
      n: 5,
      title: "Lime, Pozzolana and Gypsum",
      hi: "चूना, पोज़ोलाना और जिप्सम",
      blurb: "The binders that came before cement and still work alongside it — how lime sets, why a pozzolana needs lime to do anything, and what fly ash brings to modern concrete.",
      mins: 20,
      sections: [
        {
          n: "5.1",
          title: "Lime — the binder that breathes",
          hi: "चूना",
          blocks: [
            { k: "p", t: "Before cement, lime was the binder, and it is still used in plasters and traditional work because it is workable, forgiving and lets a wall breathe. Its story is a cycle: limestone is burnt to quicklime, slaked with water to a paste, and slowly hardens back toward limestone as it takes carbon dioxide from the air." },
            { k: "def", term: "Fat lime (non-hydraulic)", t: "Nearly pure calcium lime. It sets only by carbonation — reacting slowly with CO₂ from the air — so it hardens from the surface inward and will not set under water. Excellent for plaster and whitewash." },
            { k: "def", term: "Hydraulic lime", t: "Lime with clay impurities that give it some cement-like compounds, so it sets partly by hydration — like cement — and can harden in damp conditions or under water. The more clay, the more hydraulic and the stronger, but the less workable." },
            { k: "trap", t: "Fat lime will never set in a damp, airless place — a thick wall core, or underwater — because the CO₂ it needs cannot reach it. If the job is damp, you need a hydraulic lime or cement, not fat lime, however good the fat lime is for plaster." },
          ],
        },
        {
          n: "5.2",
          title: "Pozzolana — powder that is useless alone",
          hi: "पोज़ोलाना",
          blocks: [
            { k: "p", t: "A pozzolana is a material — volcanic ash, fly ash, silica fume, rice-husk ash — that has no binding power by itself, but reacts with lime in the presence of water to form cement-like compounds. That last clause is the whole idea: a pozzolana is a partner, not a binder." },
            { k: "def", term: "The pozzolanic reaction", t: "Pozzolana + lime + water → the same calcium-silicate compounds that give cement its strength. In concrete, the 'lime' is the free lime that cement itself releases as it hydrates — so a pozzolana quietly mops up that spare lime and turns it into more strength." },
            { k: "real", t: "This is why fly ash is added to so much modern concrete. Cement hydration leaves free lime that does nothing useful and is vulnerable to attack; fly ash consumes it, giving a denser, more durable, less permeable concrete — and it replaces some cement, cutting both cost and the heat of a large pour. <strong>PPC (Portland Pozzolana Cement) is OPC with fly ash already blended in.</strong>" },
            { k: "cmp", t: "Fly ash in concrete — the trade",
              cols: ["What you gain", "What you give up"],
              rows: [
                ["Durability", "denser, less permeable, resists attack", "—"],
                ["Heat", "lower heat in large pours", "—"],
                ["Early strength", "—", "slower early gain — needs patience"],
                ["Cost & carbon", "less cement used", "—"],
              ] },
          ],
        },
        {
          n: "5.3",
          title: "Gypsum — the set-controller and the board",
          hi: "जिप्सम",
          blocks: [
            { k: "p", t: "Gypsum appears twice in this subject and it is worth separating the two roles. In cement it is the small addition (a few per cent) that stops C₃A flash-setting, buying working time. On its own, calcined to plaster of Paris, it is a fast-setting binder for casts, mouldings and plasterboard." },
            { k: "def", term: "Plaster of Paris", t: "Gypsum heated to drive off most of its water. Add water back and it re-sets in minutes into a smooth, hard mass, expanding very slightly — which is why it takes the fine detail of a mould so faithfully. Not for damp or exposed use: it is soluble and softens in water." },
            { k: "note", t: "The two gypsum facts examiners like to pair: in cement it retards (slows the set); as plaster of Paris it accelerates (sets fast). Same mineral, opposite roles — the difference is whether it has been calcined and how much is present." },
          ],
        },
      ],
    },

  );
})();
