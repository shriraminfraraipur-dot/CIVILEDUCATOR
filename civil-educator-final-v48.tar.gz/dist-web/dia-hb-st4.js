/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 7–8
   Beams laterally supported · Lateral-torsional buckling
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 7.2 WHY AN I-SECTION */
  "hb-st-isection": {
    label: "Why the material is put where it is",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three sections of equal area compared for bending: a square, a rectangle on edge, and an I section, with the bending stress diagram beside each showing that material near the neutral axis carries almost nothing while material at the extreme fibres carries everything">
      ${hbmk("is")}
      <text class="em" x="350" y="26" text-anchor="middle">SAME AREA — VERY DIFFERENT IN BENDING</text>
      ${[["SQUARE", 110], ["RECTANGLE", 320], ["I-SECTION", 540]].map(([t, x]) =>
        `<text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>`).join("")}

      <rect class="conc" x="76" y="110" width="68" height="68"/>
      <rect class="conc" x="300" y="76" width="40" height="136"/>
      <rect class="conc" x="486" y="76" width="108" height="18"/>
      <rect class="conc" x="528" y="94" width="24" height="100"/>
      <rect class="conc" x="486" y="194" width="108" height="18"/>

      <line class="thin dash" x1="60" y1="144" x2="640" y2="144"/>
      <text class="lb" x="52" y="148" text-anchor="end">N.A.</text>

      <path class="softa" d="M164 144 L164 110 L192 110 Z"/>
      <path class="soft-b" d="M164 144 L164 178 L136 178 Z"/>
      <path class="softa" d="M356 144 L356 76 L412 76 Z"/>
      <path class="soft-b" d="M356 144 L356 212 L300 212 Z"/>
      <path class="softa" d="M610 144 L610 76 L666 76 Z"/>
      <path class="soft-b" d="M610 144 L610 212 L554 212 Z"/>

      <text class="lb" x="110" y="244" text-anchor="middle">most of the area is</text>
      <text class="lb" x="110" y="262" text-anchor="middle">near the N.A., doing nothing</text>
      <text class="lb" x="320" y="244" text-anchor="middle">better — deeper,</text>
      <text class="lb" x="320" y="262" text-anchor="middle">more of it far out</text>
      <text class="em" x="540" y="244" text-anchor="middle">the flanges carry the moment;</text>
      <text class="em" x="540" y="262" text-anchor="middle">the web just holds them apart</text>
      <text class="lb" x="350" y="290" text-anchor="middle">— and carries the shear</text>
    </svg>`,
    caption: "Bending stress varies linearly from the neutral axis, so a fibre at the centre carries almost nothing however much of it there is. An I-section is the answer to that observation: flanges out where the stress is, web only as thick as the shear requires.",
  },

  /* ---------------------------------------- 7.4 SHEAR IN THE WEB */
  "hb-st-webshear": {
    label: "Shear is carried by the web, bending by the flanges",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="An I section with the true parabolic shear stress distribution concentrated in the web, beside the idealised uniform distribution over the web area used in design, and the two combined checks of low shear and high shear">
      ${hbmk("ws")}
      <text class="em" x="168" y="26" text-anchor="middle">SHEAR STRESS — TRUE AND ASSUMED</text>
      <rect class="conc" x="76" y="60" width="112" height="16"/>
      <rect class="conc" x="118" y="76" width="28" height="112"/>
      <rect class="conc" x="76" y="188" width="112" height="16"/>
      <path class="softa" d="M210 60 L218 60 L218 76 L246 76 C258 112 258 152 246 188 L218 188 L218 204 L210 204 Z"/>
      <text class="lb" x="264" y="128">true: nearly all</text>
      <text class="lb" x="264" y="146">of it in the web</text>
      <text class="em" x="168" y="236" text-anchor="middle">design assumes it uniform</text>
      <text class="em" x="168" y="258" text-anchor="middle">over Av = D tw (rolled section)</text>
      <text class="lb" x="168" y="280" text-anchor="middle">Vd = Av fyw /(√3 γm0)</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="278"/>

      <text class="em" x="524" y="26" text-anchor="middle">TWO REGIMES</text>
      <line class="s" x1="410" y1="60" x2="410" y2="190"/>
      <line class="s" x1="410" y1="190" x2="650" y2="190"/>
      <text class="lb" x="402" y="66" text-anchor="end">Md</text>
      <text class="lb" x="648" y="212" text-anchor="end">V →</text>
      <path class="hi" d="M410 80 L554 80 C590 92 618 130 640 184"/>
      <line class="thin dash" x1="554" y1="80" x2="554" y2="190"/>
      <text class="lb" x="554" y="208" text-anchor="middle">0.6 Vd</text>
      <text class="ea" x="420" y="72">full Md available</text>
      <text class="lb" x="470" y="110" text-anchor="middle">LOW SHEAR</text>
      <text class="lb" x="600" y="122" text-anchor="middle">HIGH SHEAR —</text>
      <text class="lb" x="600" y="140" text-anchor="middle">Md is reduced</text>
      <text class="lb" x="600" y="158" text-anchor="middle">to Mdv</text>
      <text class="lb" x="524" y="240" text-anchor="middle">below 0.6 Vd the two do not interact at all;</text>
      <text class="lb" x="524" y="260" text-anchor="middle">above it, the web is busy with shear and</text>
      <text class="lb" x="524" y="280" text-anchor="middle">has less left for bending</text>
    </svg>`,
    caption: "The web carries the shear and the flanges carry the moment, so up to 0.6 Vd they do not compete. Past that the web is working hard enough in shear that its contribution to the moment has to be discounted — which is what Cl. 9.2.2's Mdv does.",
  },

  /* ---------------------------------------- 7.6 WEB BUCKLING/CRIPPLING */
  "hb-st-webcrush": {
    label: "Web buckling and web crippling under a concentrated load",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A beam web under a concentrated load shown failing two ways: buckling, where the whole web bows sideways like a short column between the flanges, and crippling, where the web crushes locally just under the root of the flange">
      ${hbmk("wc")}
      <text class="em" x="168" y="26" text-anchor="middle">WEB BUCKLING</text>
      <rect class="conc" x="70" y="62" width="200" height="16"/>
      <rect class="conc" x="70" y="196" width="200" height="16"/>
      <path class="hi" d="M170 78 C142 112 198 162 170 196"/>
      <line class="ac" x1="170" y1="36" x2="170" y2="58" marker-end="url(#wc-c)"/>
      <path class="thin dash" d="M140 62 L170 129 L200 62"/>
      <path class="thin dash" d="M140 212 L170 129 L200 212"/>
      <text class="lb" x="168" y="240" text-anchor="middle">the web acts as a short COLUMN</text>
      <text class="lb" x="168" y="260" text-anchor="middle">between the flanges; the load</text>
      <text class="lb" x="168" y="280" text-anchor="middle">disperses at 45° to mid-depth</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="278"/>

      <text class="em" x="524" y="26" text-anchor="middle">WEB CRIPPLING</text>
      <rect class="conc" x="426" y="62" width="200" height="16"/>
      <rect class="conc" x="426" y="196" width="200" height="16"/>
      <rect class="conc" x="518" y="78" width="16" height="118"/>
      <path class="soft-b" d="M500 78 L552 78 L546 104 L506 104 Z"/>
      <line class="ac" x1="526" y1="36" x2="526" y2="58" marker-end="url(#wc-c)"/>
      <path class="thin dash" d="M486 62 L526 96"/>
      <path class="thin dash" d="M566 62 L526 96"/>
      <text class="ea" x="590" y="86">1 : 2.5</text>
      <text class="lb" x="524" y="240" text-anchor="middle">the web CRUSHES locally just</text>
      <text class="lb" x="524" y="260" text-anchor="middle">under the root; the load spreads</text>
      <text class="lb" x="524" y="280" text-anchor="middle">at 1 in 2.5 through the flange</text>
    </svg>`,
    caption: "Two different failures at the same place, with two different dispersion assumptions — 45° to mid-depth for buckling, 1 : 2.5 through the flange for crippling. Both are checked at every support and under every concentrated load, and both are cured the same way: a stiffener.",
  },

  /* ---------------------------------------- 8.1 LTB */
  "hb-st-ltb": {
    label: "Lateral-torsional buckling of an unrestrained beam",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A beam loaded in its plane whose compression flange deflects sideways while the tension flange stays put, so that the cross section rotates: a combined lateral deflection and twist that occurs long before the section reaches its plastic moment">
      ${hbmk("lt")}
      <text class="em" x="350" y="26" text-anchor="middle">THE COMPRESSION FLANGE IS A COLUMN — AND IT BUCKLES SIDEWAYS</text>
      <path class="s" d="M80 92 L560 92"/>
      <path class="hi" d="M80 92 C200 50 440 50 560 92"/>
      <text class="ea" x="320" y="46" text-anchor="middle">compression flange kicks OUT of plane</text>
      <path class="s" d="M80 152 L560 152"/>
      <path class="thin" d="M80 152 L560 152"/>
      <text class="lb" x="320" y="176" text-anchor="middle">tension flange stays where it is — it is being pulled straight</text>
      <line class="ac" x1="320" y1="200" x2="320" y2="224" marker-end="url(#lt-c)"/>
      <text class="ea" x="332" y="218">load, in the plane of the web</text>

      <text class="em" x="120" y="264" text-anchor="middle">SECTION AT MID-SPAN</text>
      <g transform="translate(0,0)">
        <rect class="conc" x="76" y="276" width="90" height="10"/>
        <rect class="conc" x="116" y="286" width="10" height="4"/>
      </g>
      <g transform="rotate(-16 460 280)">
        <rect class="soft" x="400" y="256" width="90" height="10"/>
        <rect class="soft" x="440" y="266" width="10" height="34"/>
        <rect class="soft" x="400" y="294" width="90" height="10"/>
      </g>
      <text class="em" x="660" y="268" text-anchor="end">it deflects sideways</text>
      <text class="em" x="660" y="288" text-anchor="end">AND twists — both at once</text>
    </svg>`,
    caption: "The compression flange wants to buckle sideways like a column, but the tension flange holds it back, so the section has no choice but to rotate as well. That coupling is why the mode is called lateral-<em>torsional</em>, and why it depends on the section's torsional stiffness as well as its minor-axis bending stiffness.",
  },

  /* ---------------------------------------- 8.3 RESTRAINT */
  "hb-st-restraint": {
    label: "What counts as lateral restraint",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three beams: one with a concrete slab cast on the compression flange giving continuous restraint, one with secondary beams framing in at intervals giving discrete restraint, and one completely free with no restraint along its length">
      ${hbmk("re")}
      <text class="em" x="350" y="24" text-anchor="middle">LLT IS THE DISTANCE BETWEEN RESTRAINTS — NOT THE SPAN</text>

      <text class="em" x="110" y="66" text-anchor="middle">CONTINUOUS</text>
      <rect class="conc" x="46" y="94" width="180" height="16"/>
      <rect class="soft" x="46" y="78" width="180" height="16"/>
      <rect class="conc" x="126" y="110" width="12" height="46"/>
      <rect class="conc" x="46" y="156" width="180" height="16"/>
      <text class="lb" x="136" y="200" text-anchor="middle">slab cast on the flange</text>
      <text class="em" x="136" y="226" text-anchor="middle">LLT → 0</text>
      <text class="lb" x="136" y="250" text-anchor="middle">full Md available —</text>
      <text class="lb" x="136" y="270" text-anchor="middle">this is the Chapter 7 case</text>

      <line class="gl" x1="256" y1="50" x2="256" y2="288"/>

      <text class="em" x="360" y="66" text-anchor="middle">DISCRETE</text>
      <rect class="conc" x="280" y="94" width="180" height="16"/>
      ${[0,1,2].map(i=>`<rect class="soft" x="${310+i*56}" y="74" width="16" height="20"/>`).join("")}
      <rect class="conc" x="364" y="110" width="12" height="46"/>
      <rect class="conc" x="280" y="156" width="180" height="16"/>
      <line class="ac" x1="326" y1="200" x2="366" y2="200" marker-end="url(#re-c)" marker-start="url(#re-c)"/>
      <text class="ea" x="346" y="220" text-anchor="middle">LLT</text>
      <text class="lb" x="370" y="250" text-anchor="middle">secondary beams at intervals —</text>
      <text class="lb" x="370" y="270" text-anchor="middle">LLT is the spacing between them</text>

      <line class="gl" x1="490" y1="50" x2="490" y2="288"/>

      <text class="em" x="592" y="66" text-anchor="middle">NONE</text>
      <rect class="conc" x="510" y="94" width="170" height="16"/>
      <rect class="conc" x="589" y="110" width="12" height="46"/>
      <rect class="conc" x="510" y="156" width="170" height="16"/>
      <path class="hi" d="M510 102 C560 86 630 86 680 102"/>
      <text class="lb" x="595" y="200" text-anchor="middle">nothing holds the flange</text>
      <text class="em" x="595" y="226" text-anchor="middle">LLT = full span</text>
      <text class="lb" x="595" y="250" text-anchor="middle">and the capacity can fall</text>
      <text class="lb" x="595" y="270" text-anchor="middle">to less than half</text>
    </svg>`,
    caption: "Only restraint to the <em>compression</em> flange counts, and it must actually stop lateral movement — a beam merely sitting on a member below it is not restrained. Halving LLT is the cheapest thing a designer can do to a laterally unsupported beam, and §8.5 shows how much it is worth.",
  },

  /* ---------------------------------------- 8.4 THE LTB CURVE */
  "hb-st-ltbcurve": {
    label: "The bending strength curve",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A graph of design bending stress against the unrestrained length showing the full plastic moment available for short lengths, a steep fall through the intermediate range, and a long shallow tail for very long unrestrained lengths, with a rolled section curve above a welded section curve">
      ${hbmk("lv")}
      <text class="em" x="350" y="24" text-anchor="middle">HOW FAST CAPACITY IS LOST WITH UNRESTRAINED LENGTH</text>
      <line class="s" x1="96" y1="52" x2="96" y2="232"/>
      <line class="s" x1="96" y1="232" x2="620" y2="232"/>
      <text class="lb" x="86" y="58" text-anchor="end">fbd</text>
      <text class="lb" x="618" y="254" text-anchor="end">LLT →</text>
      <line class="thin dash" x1="96" y1="76" x2="620" y2="76"/>
      <text class="ea" x="626" y="80">fy/γm0</text>

      <path class="hi" d="M96 76 L176 76 C250 92 320 152 400 186 C470 210 540 220 620 226"/>
      <path class="ac" d="M96 76 L146 76 C220 100 300 162 386 194 C460 216 540 224 620 228"/>
      <text class="ea" x="210" y="112">rolled, αLT = 0.21</text>
      <text class="ea" x="196" y="182">welded, αLT = 0.49</text>

      <line class="acf" x1="176" y1="76" x2="176" y2="232" stroke-dasharray="3 3"/>
      <text class="lb" x="136" y="252" text-anchor="middle">λLT ≤ 0.4:</text>
      <text class="lb" x="136" y="270" text-anchor="middle">no reduction</text>
      <text class="lb" x="300" y="266" text-anchor="middle">the steep part —</text>
      <text class="lb" x="300" y="284" text-anchor="middle">where most real beams sit</text>
      <text class="lb" x="530" y="266" text-anchor="middle">very long: elastic LTB,</text>
      <text class="lb" x="530" y="284" text-anchor="middle">and fy stops mattering</text>
    </svg>`,
    caption: "The machinery is identical to the column curve of Chapter 6 — λLT, φLT, χLT — with αLT of 0.21 for rolled sections and 0.49 for welded ones. The steep middle section is the practical range, which is why a single lateral restraint at mid-span so often changes a design.",
  },

});
