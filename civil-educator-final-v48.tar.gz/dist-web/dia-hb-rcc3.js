/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 5–6
   Shear and bond · Torsion
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 5.1 DIAGONAL TENSION */
  "hb-rcc-diagtension": {
    label: "Why a beam cracks diagonally near its supports",
    svg: `<svg viewBox="0 0 700 330" role="img" aria-label="A beam element near a support carrying shear and bending, the resulting principal tension acting at forty five degrees, and the diagonal crack that forms at right angles to it running from the support region up towards mid span">
      ${hbmk("dt")}
      <text class="em" x="350" y="24" text-anchor="middle">SHEAR IS NEVER ALONE — IT ARRIVES AS DIAGONAL TENSION</text>

      <rect class="conc" x="60" y="60" width="580" height="90"/>
      ${grd(40, 162, 46)}
      ${grd(614, 162, 46)}
      <line class="s" x1="60" y1="150" x2="86" y2="162"/>
      <line class="s" x1="640" y1="150" x2="614" y2="162"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<line class="ac" x1="${96+i*68}" y1="40" x2="${96+i*68}" y2="58" marker-end="url(#dt-c)"/>`).join("")}
      <text class="ea" x="350" y="36" text-anchor="middle">w</text>

      <rect class="thin dash" x="140" y="70" width="60" height="70" fill="none"/>
      <text class="lb" x="170" y="64" text-anchor="middle">element</text>

      <line class="s" x1="240" y1="106" x2="300" y2="106"/>
      <rect class="soft" x="300" y="76" width="60" height="60"/>
      <line class="hi" x1="300" y1="76" x2="300" y2="136" marker-end="url(#dt-m)"/>
      <line class="hi" x1="360" y1="136" x2="360" y2="76" marker-end="url(#dt-m)"/>
      <line class="hi" x1="300" y1="76" x2="360" y2="76" marker-end="url(#dt-m)"/>
      <line class="hi" x1="360" y1="136" x2="300" y2="136" marker-end="url(#dt-m)"/>
      <text class="lb" x="330" y="70" text-anchor="middle">τ</text>
      <line class="ac" x1="386" y1="142" x2="446" y2="82" marker-end="url(#dt-c)"/>
      <line class="ac" x1="446" y1="82" x2="386" y2="142"/>
      <rect class="thin dash" x="392" y="78" width="58" height="58" fill="none" transform="rotate(45 421 107)"/>
      <text class="ea" x="470" y="80">principal TENSION</text>
      <text class="lb" x="470" y="98">at 45° to the axis</text>
      <text class="lb" x="470" y="116">— and concrete is weak</text>
      <text class="lb" x="470" y="134">in tension</text>

      <text class="em" x="350" y="204" text-anchor="middle">so the crack opens at right angles to that tension</text>
      <rect class="conc" x="60" y="220" width="580" height="80"/>
      ${grd(40, 312, 46)}
      ${grd(614, 312, 46)}
      <path class="hi" d="M150 300 L212 222"/>
      <path class="hi" d="M196 300 L258 222"/>
      <path class="hi" d="M504 300 L442 222"/>
      <path class="hi" d="M550 300 L488 222"/>
      <path class="hi" d="M326 300 L326 250"/><path class="hi" d="M356 300 L356 244"/><path class="hi" d="M386 300 L386 252"/>
      <text class="lb" x="186" y="322" text-anchor="middle">diagonal (shear) cracks near supports</text>
      <text class="lb" x="516" y="322" text-anchor="middle">diagonal (shear) cracks near supports</text>
      <text class="lb" x="352" y="322" text-anchor="middle">vertical (flexural) cracks at mid-span</text>
    </svg>`,
    caption: "Shear on its own is not what breaks a beam. Shear combined with bending produces a principal tensile stress inclined to the axis, and the crack forms perpendicular to it. That is why shear cracks lean and flexural cracks stand upright, and why shear reinforcement is placed to cross the lean.",
  },

  /* ---------------------------------------- 5.4 STIRRUP TRUSS */
  "hb-rcc-truss": {
    label: "The truss analogy for shear reinforcement",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A cracked beam idealised as a truss: the concrete above the crack acts as the compression chord, the tension steel as the bottom chord, the concrete between cracks as inclined compression struts and the stirrups as vertical tension ties">
      ${hbmk("tr")}
      <text class="em" x="350" y="24" text-anchor="middle">A CRACKED BEAM IS A TRUSS</text>

      <line class="s" x1="70" y1="70" x2="630" y2="70"/>
      <line class="s" x1="70" y1="190" x2="630" y2="190"/>
      <text class="ea" x="350" y="58" text-anchor="middle">concrete in compression — top chord</text>
      <text class="ea" x="350" y="216" text-anchor="middle">tension steel — bottom chord</text>
      <line class="steel" x1="70" y1="190" x2="630" y2="190"/>

      ${[0,1,2,3,4].map(i=>`<line class="soft-b" x1="${110+i*120}" y1="190" x2="${170+i*120}" y2="70"/>`).join("")}
      ${[0,1,2,3,4,5].map(i=>`<line class="hi" x1="${110+i*104}" y1="70" x2="${110+i*104}" y2="190" marker-end="url(#tr-m)" marker-start="url(#tr-m)"/>`).join("")}

      <text class="lb" x="146" y="252" text-anchor="middle">concrete STRUTS</text>
      <text class="lb" x="146" y="270" text-anchor="middle">between the cracks —</text>
      <text class="lb" x="146" y="288" text-anchor="middle">compression, at about 45°</text>
      <text class="lb" x="470" y="252" text-anchor="middle">STIRRUPS are the vertical ties —</text>
      <text class="lb" x="470" y="270" text-anchor="middle">tension, and the only members</text>
      <text class="lb" x="470" y="288" text-anchor="middle">you actually have to design</text>
      ${grd(50, 196, 40)}
      ${grd(610, 196, 40)}
    </svg>`,
    caption: "Once diagonal cracks have formed, the beam carries shear the way a truss does. The stirrups are the vertical ties — this is why τc,max exists as a separate limit: it is the strut, not the tie, reaching its capacity, and no amount of extra stirrup steel will help.",
  },

  /* ---------------------------------------- 5.5 STIRRUP TYPES */
  "hb-rcc-stirrups": {
    label: "Stirrup arrangements and the legs that count",
    svg: `<svg viewBox="0 0 700 260" role="img" aria-label="Three stirrup arrangements in section: a two legged vertical stirrup, a four legged stirrup for a wide beam, and inclined bent up bars, with the number of legs crossing a diagonal crack noted for each">
      ${hbmk("st")}
      <text class="em" x="116" y="26" text-anchor="middle">2-LEGGED VERTICAL</text>
      <rect class="conc" x="56" y="46" width="120" height="150"/>
      <rect class="steel" x="72" y="62" width="88" height="118" fill="none"/>
      <circle class="steel" cx="82" cy="170" r="7"/><circle class="steel" cx="116" cy="170" r="7"/><circle class="steel" cx="150" cy="170" r="7"/>
      <circle class="steel" cx="82" cy="72" r="6"/><circle class="steel" cx="150" cy="72" r="6"/>
      <line class="ac" x1="72" y1="120" x2="40" y2="120" marker-end="url(#st-c)"/>
      <line class="ac" x1="160" y1="120" x2="192" y2="120" marker-end="url(#st-c)"/>
      <text class="lb" x="116" y="218" text-anchor="middle">Asv = 2 × area of one bar</text>
      <text class="lb" x="116" y="240" text-anchor="middle">the normal beam stirrup</text>

      <line class="gl" x1="232" y1="16" x2="232" y2="252"/>

      <text class="em" x="350" y="26" text-anchor="middle">4-LEGGED</text>
      <rect class="conc" x="264" y="46" width="172" height="150"/>
      <rect class="steel" x="278" y="62" width="144" height="118" fill="none"/>
      <rect class="steel" x="318" y="62" width="64" height="118" fill="none"/>
      <circle class="steel" cx="288" cy="170" r="7"/><circle class="steel" cx="326" cy="170" r="7"/>
      <circle class="steel" cx="374" cy="170" r="7"/><circle class="steel" cx="412" cy="170" r="7"/>
      <text class="lb" x="350" y="218" text-anchor="middle">Asv = 4 × area of one bar</text>
      <text class="lb" x="350" y="240" text-anchor="middle">for wide beams — Cl. 26.5.1.5 caps</text>

      <line class="gl" x1="468" y1="16" x2="468" y2="252"/>

      <text class="em" x="584" y="26" text-anchor="middle">BENT-UP BARS</text>
      <line class="s" x1="500" y1="180" x2="668" y2="180"/>
      <line class="s" x1="500" y1="60" x2="668" y2="60"/>
      <path class="steel" d="M500 170 L548 170 L608 80 L668 80"/>
      <path class="hi dash" d="M520 180 L590 70"/>
      <text class="lb" x="584" y="218" text-anchor="middle">bars lifted where they are</text>
      <text class="lb" x="584" y="240" text-anchor="middle">no longer needed for moment</text>
    </svg>`,
    caption: "Asv is the total area of all the legs that cross one diagonal crack, not the area of one bar. Counting two legs when four are provided halves the calculated capacity; counting four when two are provided doubles it, which is the dangerous direction.",
  },

  /* ---------------------------------------- 5.7 BOND AND Ld */
  "hb-rcc-bond": {
    label: "Bond stress and development length",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A bar embedded in concrete with bond stress acting over its surface, the force balance between the pull in the bar and the bond resistance around it, and the resulting expression for development length">
      ${hbmk("bd")}
      <text class="em" x="350" y="26" text-anchor="middle">A BAR IS ONLY AS STRONG AS ITS GRIP</text>

      <rect class="conc" x="60" y="60" width="330" height="110"/>
      <rect class="steel" x="40" y="105" width="368" height="18" rx="4"/>
      <line class="hi" x1="470" y1="114" x2="408" y2="114" marker-start="url(#bd-m)"/>
      <text class="em" x="478" y="110">pull</text>
      <text class="lb" x="478" y="128">= (π/4)φ² × 0.87fy</text>
      ${[0,1,2,3,4,5,6,7,8,9].map(i=>`<line class="ac" x1="${82+i*34}" y1="96" x2="${100+i*34}" y2="96" marker-end="url(#bd-c)"/>`).join("")}
      ${[0,1,2,3,4,5,6,7,8,9].map(i=>`<line class="ac" x1="${82+i*34}" y1="134" x2="${100+i*34}" y2="134" marker-end="url(#bd-c)"/>`).join("")}
      <text class="ea" x="225" y="86" text-anchor="middle">bond stress τbd all round the surface</text>
      <line class="thin" x1="60" y1="190" x2="408" y2="190"/>
      <line class="thin" x1="60" y1="182" x2="60" y2="198"/><line class="thin" x1="408" y1="182" x2="408" y2="198"/>
      <text class="em" x="234" y="212" text-anchor="middle">Ld — the length needed to build up that pull</text>

      <line class="gl" x1="60" y1="234" x2="640" y2="234"/>
      <text class="lb" x="60" y="260">Force in the bar  =  bond force around it</text>
      <text class="em" x="60" y="284">(π/4) φ² × 0.87fy  =  π φ Ld × τbd      →      Ld = 0.87 fy φ / (4 τbd)</text>
    </svg>`,
    caption: "Development length is not a detailing convention. It is the length over which the surface of the bar can collect, through bond, the force the bar is being asked to carry — and it drops straight out of one force balance.",
  },

  /* ---------------------------------------- 5.9 CURTAILMENT */
  "hb-rcc-curtail": {
    label: "Curtailment and the bending moment envelope",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A bending moment diagram for a simply supported beam with a stepped moment of resistance diagram above it showing bars curtailed in stages, each curtailed bar extended beyond its theoretical cut off point">
      ${hbmk("cu")}
      <text class="em" x="350" y="24" text-anchor="middle">CURTAILMENT — STOP BARS WHERE THEY ARE NO LONGER NEEDED</text>
      <line class="s" x1="70" y1="180" x2="630" y2="180"/>
      <path class="soft" d="M70 180 Q350 20 630 180 Z"/>
      <text class="lb" x="350" y="164" text-anchor="middle">bending moment diagram</text>

      <path class="hi" d="M70 180 L70 140 L182 140 L182 104 L266 104 L266 62 L434 62 L434 104 L518 104 L518 140 L630 140 L630 180"/>
      <text class="ea" x="350" y="52" text-anchor="middle">moment of resistance provided — a staircase, not a curve</text>

      <line class="steel" x1="96" y1="212" x2="604" y2="212"/>
      <line class="steel" x1="182" y1="228" x2="518" y2="228"/>
      <line class="steel" x1="266" y1="244" x2="434" y2="244"/>
      <text class="lb" x="350" y="266" text-anchor="middle">every bar runs past the point where the curve crosses its step</text>
      <line class="ac" x1="266" y1="244" x2="230" y2="244" marker-end="url(#cu-c)"/>
      <line class="ac" x1="434" y1="244" x2="470" y2="244" marker-end="url(#cu-c)"/>
      <text class="ea" x="350" y="290" text-anchor="middle">extend by d or 12φ, whichever is greater — Cl. 26.2.3.1</text>
      ${grd(50, 186, 40)}
      ${grd(610, 186, 40)}
    </svg>`,
    caption: "The provided capacity is a staircase because bars stop in whole numbers. Every step must stay above the moment curve everywhere, and each bar then runs on past its theoretical cut-off — because a bar stopped exactly where it is no longer needed for moment has no length left in which to develop its stress.",
  },

  /* ---------------------------------------- 6.1 TORSION */
  "hb-rcc-torsion": {
    label: "Equilibrium torsion against compatibility torsion",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="On the left a cantilever slab framing into an edge beam, where the twist is required for equilibrium and must be designed for. On the right an interior beam twisted by the rotation of the slab it supports, where cracking relieves the twist and only detailing is needed">
      ${hbmk("to")}
      <text class="em" x="172" y="26" text-anchor="middle">EQUILIBRIUM TORSION</text>
      <rect class="conc" x="72" y="62" width="44" height="150"/>
      <rect class="soft" x="116" y="72" width="180" height="20"/>
      ${[0,1,2,3,4].map(i=>`<line class="ac" x1="${146+i*36}" y1="46" x2="${146+i*36}" y2="66" marker-end="url(#to-c)"/>`).join("")}
      <text class="ea" x="222" y="40" text-anchor="middle">load on the cantilever</text>
      <path class="hi" d="M62 140 A28 28 0 1 1 126 140" fill="none" marker-end="url(#to-m)"/>
      <text class="em" x="94" y="240" text-anchor="middle">the beam MUST twist</text>
      <text class="lb" x="172" y="264" text-anchor="middle">nothing else can carry the slab moment —</text>
      <text class="lb" x="172" y="286" text-anchor="middle">design the beam for the full torque</text>
      ${grd(60, 212, 68)}

      <line class="gl" x1="348" y1="16" x2="348" y2="296"/>

      <text class="em" x="524" y="26" text-anchor="middle">COMPATIBILITY TORSION</text>
      <rect class="conc" x="470" y="62" width="44" height="150"/>
      <rect class="soft" x="514" y="72" width="150" height="20"/>
      <rect class="soft" x="376" y="72" width="94" height="20"/>
      <path class="hi dash" d="M460 140 A28 28 0 1 1 524 140" fill="none" marker-end="url(#to-m)"/>
      <text class="em" x="492" y="240" text-anchor="middle">the beam is twisted BY the slab</text>
      <text class="lb" x="524" y="264" text-anchor="middle">once it cracks it softens, the slab redistributes,</text>
      <text class="lb" x="524" y="286" text-anchor="middle">and the torque largely disappears — detail only</text>
      ${grd(458, 212, 68)}
    </svg>`,
    caption: "IS 456 Cl. 41.1 draws exactly this line. Equilibrium torsion has nowhere else to go and must be designed for. Compatibility torsion is relieved by the cracking itself, and Cl. 41.1 permits it to be neglected provided the member is detailed for torsion.",
  },

  /* ---------------------------------------- 6.3 SPACE TRUSS */
  "hb-rcc-torsionreinf": {
    label: "Why torsion needs closed stirrups and corner bars",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A beam in torsion cracking in a spiral around all four faces, and the reinforcement that resists it: closed stirrups forming a continuous loop and longitudinal bars at every corner">
      ${hbmk("tf")}
      <text class="em" x="176" y="26" text-anchor="middle">TORSION CRACKS SPIRAL</text>
      <path class="conc" d="M60 90 L300 90 L300 190 L60 190 Z"/>
      <path class="thin" d="M60 90 L92 62 L332 62 L300 90"/>
      <path class="thin" d="M332 62 L332 162 L300 190"/>
      ${[0,1,2,3,4,5].map(i=>`<path class="hi" d="M${76+i*40} 190 L${116+i*40} 90"/>`).join("")}
      <text class="lb" x="196" y="222" text-anchor="middle">the crack runs round all four faces</text>
      <text class="lb" x="196" y="244" text-anchor="middle">in a continuous spiral —</text>
      <text class="lb" x="196" y="266" text-anchor="middle">every face is in tension somewhere</text>

      <line class="gl" x1="384" y1="16" x2="384" y2="272"/>

      <text class="em" x="540" y="26" text-anchor="middle">SO THE STEEL MUST CLOSE</text>
      <rect class="conc" x="470" y="56" width="140" height="150"/>
      <rect class="steel" x="486" y="72" width="108" height="118" fill="none" rx="6"/>
      <circle class="steel" cx="496" cy="82" r="7"/><circle class="steel" cx="584" cy="82" r="7"/>
      <circle class="steel" cx="496" cy="180" r="7"/><circle class="steel" cx="584" cy="180" r="7"/>
      <circle class="steel" cx="540" cy="131" r="6"/>
      <text class="lb" x="646" y="80">closed</text><text class="lb" x="646" y="98">stirrup</text>
      <text class="lb" x="540" y="232" text-anchor="middle">a bar at EVERY corner (Cl. 26.5.1.7),</text>
      <text class="lb" x="540" y="254" text-anchor="middle">extra side-face bars if a dimension &gt; 450 mm,</text>
      <text class="lb" x="540" y="276" text-anchor="middle">and stirrups closed with proper hooks</text>
    </svg>`,
    caption: "A shear stirrup can be open at the top and still work, because shear tension is on one face. Torsion puts tension on all four faces at once, so the stirrup has to be a closed loop with anchored ends, and there has to be a longitudinal bar in every corner for the loop to bear against.",
  },

});
