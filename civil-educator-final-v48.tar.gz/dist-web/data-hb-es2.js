/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: ESTIMATION & COSTING · Ch 4–6
   Earthwork · Concrete & reinforcement · Bar bending schedule
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "es");
  if (!hb) { console.error("[es2] handbook es not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 4 */
    {
      id: "es-4",
      n: 4,
      title: "Earthwork Measurement",
      hi: "मिट्टी कार्य का मापन",
      blurb: "How the volume of soil cut and filled along a road is measured, the trapezoidal and prismoidal rules, and why cut and fill are balanced separately.",
      mins: 20,
      sections: [
        {
          n: "4.1",
          title: "Volume from cross-sections",
          hi: "क्रॉस-सेक्शन से आयतन",
          blocks: [
            { k: "p", t: "Earthwork — excavation and embankment — is measured by volume, but the ground is an irregular shape, so you cannot just multiply length by breadth by depth. Instead the road is cut into cross-sections at regular intervals (chainages), each section's area is found, and the volume between two sections is their areas averaged and multiplied by the spacing." },
            { k: "dia", id: "hb-es-earthwork", cap: "Cross-sections, cut and fill, and the two volume rules." },
            { k: "cmp", t: "The two rules for volume between sections",
              cols: ["Trapezoidal rule", "Prismoidal rule"],
              rows: [
                ["Uses", "the two end areas", "end areas + the middle"],
                ["Assumes", "linear change between sections", "parabolic (more realistic)"],
                ["Accuracy", "slight over-estimate", "more accurate"],
                ["Used for", "quick estimates", "payment quantities"],
              ] },
            { k: "trap", t: "The two rules give noticeably different totals over a long road, and using the wrong one has a cost. The trapezoidal rule over-measures, which flatters an early estimate but over-pays a contractor if used for payment. The prismoidal rule (or the prismoidal correction applied to the trapezoidal result) is the one for money quantities — it is more accurate, and it is usually specified for exactly that reason." },
          ],
        },
        {
          n: "4.2",
          title: "Balancing cut and fill",
          hi: "कटाई और भराई का संतुलन",
          blocks: [
            { k: "p", t: "Cut (soil excavated) and fill (soil placed as embankment) are measured separately, because they are separate costs — and because the cheapest earthwork is the one that reuses its own soil. Ideally the soil taken from a cutting is carried straight to a nearby fill, so you neither import fill nor dump surplus cut." },
            { k: "def", term: "Lead and lift", t: "Lead is the horizontal distance the excavated soil is carried; lift is the vertical height it is raised. Both add to the rate — soil carried far or lifted high costs more to move — so earthwork rates are quoted for a base lead and lift, with extra for anything beyond." },
            { k: "real", t: "On a hill road the engineer tries to set the road level so that the volume of cut roughly equals the volume of fill over each stretch — a 'balanced' earthwork — because then the spoil from the cuttings exactly fills the embankments, with nothing bought in and nothing carted away. <strong>A well-set road profile is largely an earthwork-balancing exercise</strong>, and it saves more money than almost any other single decision." },
            { k: "eg", title: "Example 4.1 — Foundation trench for the building of Example 3.2",
              given: "Trench 0.90 m wide and 1.00 m deep under all walls of the two-room building in Example 3.2 (centre-line of the outer walls 21.8 m; cross wall 3.3 m centre to centre).",
              steps: [
                { t: "Trench centre-line length", w: "outer 21.8 m + cross wall 3.3 − 2 × (0.90/2) = 2.4 m  →  24.2 m" },
                { t: "Volume", w: "24.2 × 0.90 × 1.00 = 21.78 m³" },
              ],
              ans: "21.78 m³ of excavation. Note the junction correction now uses the trench width (0.45 m per T-junction), not the wall thickness — each layer is corrected at its own breadth." },
            { k: "note", t: "For road earthwork between cross-sections, the end-area and prismoidal rules and the prismoidal correction for level sections, Cp = d s (h₁ − h₂)²/6, are worked in <a href=\"#/read/sv/10\">Surveying, Chapter 10</a> (Examples 10.3–10.4) — including a case where alternate-section prismoidal working is worse than end-area." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "es-5",
      n: 5,
      title: "Concrete and Reinforcement Measurement",
      hi: "कंक्रीट और सरिया का मापन",
      blurb: "Measuring concrete by net volume, why the reinforcement and formwork are separate items, and how the quantities feed the material estimate.",
      mins: 20,
      sections: [
        {
          n: "5.1",
          title: "Concrete — net volume, three items in one",
          hi: "कंक्रीट — शुद्ध आयतन",
          blocks: [
            { k: "p", t: "A reinforced concrete member is not one item in an estimate but three, measured separately because they are three different trades and costs: the concrete (by volume), the reinforcement (by weight), and the formwork (by the contact area of the mould)." },
            { k: "cmp", t: "One beam, three measured items",
              cols: ["Measured as", "Note"],
              rows: [
                ["Concrete", "net volume (m³)", "gross size, less any large voids"],
                ["Reinforcement", "weight (kg)", "cutting length × d²/162"],
                ["Formwork (shuttering)", "contact area (m²)", "the mould surface touching concrete"],
              ] },
            { k: "def", term: "Net volume", t: "Concrete is measured to its net finished dimensions. Where members meet — a beam framing into a column, a slab over a beam — the shared concrete is counted once, not twice. The rule is that concrete is never double-measured at junctions, which is the commonest over-measurement error in an RCC takeoff." },
            { k: "note", t: "The concrete quantity connects straight to the Concrete Technology handbook: each cubic metre of a nominal mix has a known material content (for 1:1.5:3 M20, about 8 bags of cement, 0.42 m³ sand and 0.84 m³ coarse aggregate). So the moment you have the net concrete volume, the cement, sand and aggregate quantities follow directly — measurement and material estimate are one continuous chain." },
            { k: "eg", title: "Example 5.2 — Concrete and formwork for a beam below a slab",
              given: "A beam 230 mm wide, 450 mm deep overall, cast with a 150 mm slab; clear span between column faces 5.0 m.",
              steps: [
                { t: "Concrete measured in the beam", w: "only the part below the slab — the slab item already includes the 150 mm:\n0.23 × (0.45 − 0.15) × 5.0 = 0.345 m³" },
                { t: "Formwork (contact area)", w: "soffit 0.23 × 5.0 + two sides 2 × 0.30 × 5.0 = 1.15 + 3.00 = 4.15 m²" },
              ],
              ans: "0.345 m³ of concrete and 4.15 m² of shuttering. Measuring the beam to its full 450 mm would count the slab concrete twice; measuring the sides to 450 mm would double-count slab formwork." },
          ],
        },
        {
          n: "5.2",
          title: "Reinforcement — length drawn, weight paid",
          hi: "सरिया — लंबाई नापो, वज़न में दाम",
          blocks: [
            { k: "p", t: "Reinforcement is the item measured one way and paid another: you measure each bar's length from the drawing, but steel is bought and billed by weight, so every length is converted to mass. The bridge between them is one small, much-used formula." },
            { k: "eq", expr: "weight per metre = d² / 162   (kg/m, d in mm)", where: [
              ["d", "bar diameter in millimetres"],
              ["162", "comes from the density of steel — 7850 kg/m³ — reduced to this handy constant"],
            ] },
            { k: "eg", title: "Example 5.1 — Weight of a length of bar",
              given: "Find the weight of a 16 mm diameter bar, 12 m long.",
              steps: [
                { t: "Weight per metre", w: "d²/162 = 16²/162 = 256/162 = 1.58 kg/m" },
                { t: "For 12 m", w: "1.58 × 12 = 18.96 kg" },
              ],
              ans: "About 18.96 kg. The d²/162 rule is used on every bar in the schedule — it is the single most-used formula in a reinforcement takeoff, so it is worth committing to memory. (The 162 comes straight from steel's density; nothing is invented.)" },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "es-6",
      n: 6,
      title: "The Bar Bending Schedule",
      hi: "बार बेंडिंग शेड्यूल",
      blurb: "Why a bent bar's cutting length is not its straight span, how hooks and bends change it, and a worked stirrup from length to weight.",
      mins: 22,
      sections: [
        {
          n: "6.1",
          title: "Cutting length — hooks add, bends save",
          hi: "कटाई लंबाई",
          blocks: [
            { k: "p", t: "A bar bending schedule (BBS) lists every bar in the structure — its shape, size, cutting length, number and weight — so the steel can be cut and bent before it reaches the site. The one idea that makes it work is the cutting length: a bent bar is not as long as its straight span suggests." },
            { k: "dia", id: "hb-es-bbs", cap: "Why a bent bar's cutting length differs from its span." },
            { k: "list", items: [
              "<strong>Hooks add steel</strong> — a hook at each end (to anchor the bar) adds about 9 diameters of length per hook.",
              "<strong>Bends save steel</strong> — a bar bends round a corner on a curve, not a sharp point, so it uses slightly less than the sum of its straight sides. A 90° bend saves about 2 diameters.",
              "<strong>Cutting length</strong> = straight lengths + hooks − bend allowances.",
            ] },
            { k: "note", t: "The hook and bend allowances (hook ≈ 9d, 90° bend deducts 2d, per IS 2502) are established conventions, not invented figures — they come from the geometry of bending a bar of finite diameter around a mandrel. Different codes and practices vary the exact numbers slightly, so a real BBS states which convention it uses; the method is what matters." },
            { k: "note", t: "<b>Two conventions in this app — on purpose.</b> Example 6.1 below uses 180°-type hooks of 9d with only the three 90° corner bends deducted (1396 mm). The RCC handbook's <a href=\"#/read/rcc/12\">Example 12.1</a> uses 135° hooks of 10d — the seismic stirrup detail — and also deducts 3d for each hook bend (1365 mm). Both are internally consistent; the difference of about 2% is exactly why a schedule must state its convention. For anything in a seismic zone the 135° hook is required (IS 13920)." },
          ],
        },
        {
          n: "6.2",
          title: "A worked stirrup",
          hi: "एक हल किया गया स्टिरप",
          blocks: [
            { k: "p", t: "The stirrup — the rectangular loop that holds a beam's main bars and resists shear — is the classic BBS calculation, because it has both hooks and bends." },
            { k: "eg", title: "Example 6.1 — Cutting length and weight of a stirrup",
              given: "A rectangular stirrup for a 300 × 450 mm beam, with 25 mm clear cover, is made of 8 mm bar. Using hook = 9d and a 90° bend deduction of 2d, find its cutting length and weight. Take three 90° bends and two hooks.",
              steps: [
                { t: "Stirrup side dimensions (inside cover)", w: "a = 300 − 2×25 = 250 mm\nb = 450 − 2×25 = 400 mm" },
                { t: "Straight perimeter", w: "2 × (a + b) = 2 × (250 + 400) = 1300 mm" },
                { t: "Add two hooks (9d each)", w: "2 × 9 × 8 = 144 mm" },
                { t: "Deduct three 90° bends (2d each)", w: "3 × 2 × 8 = 48 mm" },
                { t: "Cutting length", w: "1300 + 144 − 48 = 1396 mm = 1.396 m" },
                { t: "Weight (d²/162)", w: "(8²/162) × 1.396 = 0.395 × 1.396 = 0.552 kg" },
              ],
              ans: "Cutting length 1.396 m, weight about 0.552 kg per stirrup. Multiply by the number of stirrups in the beam for the total. Every figure here is traceable — the side dimensions from the cover, the hook and bend allowances from IS 2502, the weight from the density constant — so the schedule can be checked line by line." },
          ],
        },
      ],
    },

  );
})();
