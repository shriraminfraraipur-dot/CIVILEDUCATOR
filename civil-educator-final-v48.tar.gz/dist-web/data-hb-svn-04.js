/* Surveying class notes — Tape corrections, field work, offsets, obstacles and cross-staff survey, notes p.133–143 — inserted into sv chapter 3 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 3; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- pull */
    { n: "", title: "Notes — Correction for pull", hi: "खिंचाव (पुल) संशोधन", blocks: [
      { k: "h", t: "📘 Notes — p.133" },
      { k: "def", term: "Correction for pull (Cp)", t: "If the pull (tension) applied at the ends of the tape during measurement in the field is different from the standard pull at which the tape was standardised or calibrated, a correction for pull is applied. If the pull applied is <b>greater</b> than the standard pull the correction is <b>+ve</b>, otherwise <b>−ve</b>. (p.133)" },
      { k: "eq", expr: "Correction for pull  Cp = (P − Ps) L / (A E)", where: [
        ["P", "pull applied in the field"],
        ["Ps", "standard pull"],
        ["L", "length"],
        ["A", "cross-sectional area"],
        ["E", "modulus of elasticity"],
      ] },
      { k: "eg",
        title: "Notes example — Pull correction for a 30 m steel tape",
        given: "A steel tape 30 m long was standardised at a pull of 65 N. If the pull at the time of measurement was 80 N, find the correct length of tape. Weight of tape is 10 N, E = 2 × 10⁵ MPa and unit weight of steel is 77.1 kN/m³.",
        steps: [
          { t: "Area of tape from its weight", w: "W = m·g\nW = γ A L\n10 N = (77 × 10³)/((10³)³) × A × 30 × 10³  ⇒  A = 4.32 mm²" },
          { t: "Pull correction", w: "Cp = ((80 − 65) × 30000)/(4.32 × 2 × 10⁵) = 0.520 mm = 0.00052 m" },
          { t: "Correct length", w: "C.L = 30 + 0.00052 = 30.00052 m" },
        ],
        ans: "Correct length of tape = 30.00052 m (p.133)",
      },
      { k: "note", t: "<b>Check:</b> the working writes γ as 77 × 10³ N/m³ although the question gives 77.1 kN/m³. With 77: A = 10/(7.7×10⁻⁵ × 30000) = 4.33 mm²; with 77.1: A = 4.32 mm² (the value the notes use). Either way Cp = 15 × 30000/(4.32 × 2×10⁵) = 0.52 mm, so the answer 30.00052 m stands." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Tape ko jitna zor se kheencho, utna wo stretch hota hai. Stretched tape par 30 m ka mark asal mein 30 m se thoda aage pahunch jaata hai — matlab tape <b>kam reading</b> deta hai. Isliye extra pull (P &gt; Ps) par correction <b>positive</b> hai. Formula simple Hooke's law hai: extension = (extra force) × L / (AE)." },
      { k: "p", t: "Notice the trick in the example: area A is not given directly. It comes from the tape's weight, W = γ A L. Keep units consistent — the notes work in N and mm, so γ = 77 × 10³ N/m³ becomes 77 × 10³/10⁹ N/mm³ and L = 30 × 10³ mm." },
      { k: "trap", t: "Do not mix metres and millimetres inside (P − Ps)L/(AE). If A is in mm² and E in N/mm² (MPa), L must be in mm and the answer comes out in mm — 0.520 mm here, not 0.520 m." },
    ] },

    /* ---------------------------------------------------------- temperature */
    { n: "", title: "Notes — Correction for temperature", hi: "तापमान संशोधन", blocks: [
      { k: "h", t: "📘 Notes — p.134" },
      { k: "def", term: "Correction for temperature (CT)", t: "It is denoted by C<sub>T</sub>. It is required if the tape temperature is different from the temperature at which the tape was standardised. (p.134)" },
      { k: "eq", expr: "CT = L α ΔT  =  L α (Tm − To)", where: [
        ["α", "coefficient of linear expansion"],
        ["Tm", "mean temperature of tape"],
        ["To", "standard temperature"],
      ] },
      { k: "eg",
        title: "Notes example — Temperature correction for a measured line",
        given: "Measured length of a line was 850.420 m with a 30 m tape which was exactly 30 m at 27°C. Find the correct length, where α = 1.16 × 10⁻⁵ /°C and field temperature was 32°C.",
        steps: [
          { t: "Temperature correction", w: "CT = L α ΔT\nCT = 850.420 × 1.16 × 10⁻⁵ × (32 − 27)\nCT = 0.049" },
          { t: "True value", w: "T.V = M.V + CT\n= 850.420 + 0.049  ⇒  850.469 m" },
        ],
        ans: "Correct length = 850.469 m (p.134)",
      },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Garmi mein steel tape lamba ho jaata hai. 32°C par tape 27°C wale 30 m se lamba hai, to har tape-length mein zameen ki asli doori zyada cover hoti hai par reading 30 hi likhi jaati hai — line asal mein badi hai. Isliye Tm &gt; To par CT <b>+ve</b>. Thande din mein ulta: CT −ve." },
      { k: "trap", t: "Use the <b>whole measured length</b> (850.420 m) in CT = LαΔT, not the tape length (30 m). The correction per tape length × number of tape lengths gives the same thing, but plugging 30 m alone gives a correction 28 times too small." },
    ] },

    /* ---------------------------------------------------------- sag + normal tension */
    { n: "", title: "Notes — Correction for sag and normal tension", hi: "झोल संशोधन और सामान्य तनाव", blocks: [
      { k: "h", t: "📘 Notes — p.134–135" },
      { k: "def", term: "Correction for sag (Cg)", t: "When the tape is supported between two ends it takes the shape of a <b>catenary</b>. If the tape is standardised on flat ground and used in catenary, the correction will be <b>negative</b>. (p.134)" },
      { k: "list", items: [
        "Figure (p.134, left): a tape supported at its two ends (upward arrows at each support) sags between them in a curve labelled <b>catenary</b>; the straight line joining the supports is labelled <b>Horizontal</b>; pull arrows act outward at both ends, the right one labelled <b>P</b>.",
        "Figure (p.134, right): a tape supported at three points (upward arrows) sags in two spans labelled <b>Bay 1</b> and <b>Bay 2</b>.",
      ] },
      { k: "eq", expr: "Cg = − l w² / (24 n² P²)", where: [
        ["l", "length of tape"],
        ["n", "number of bays"],
        ["w", "total weight (of the tape)"],
        ["P", "pull applied"],
      ] },
      { k: "eg",
        title: "Notes example — Sag correction, 30 m tape in 3 bays",
        given: "Determine the sag correction for a 30 m steel tape under a pull of 80 N, in 3 bays of 10 m each. Area of cross-section of tape is 8 mm² and unit weight of steel = 77 kN/m³.",
        steps: [
          { t: "Total weight of tape", w: "w = γ · A · L\nw = (77 × 10³)/(10⁹) × 8 × 30 × 10³ = 18.48 N" },
          { t: "Sag correction", w: "Cg = −l w²/(24 n² P²) = −30 × (18.48)²/(24 × 3² × 80²)\nCg = −7.41 × 10⁻³ m" },
          { t: "Correct length", w: "correct length = 30 − 7.41 × 10⁻³ = 29.9925 m" },
        ],
        ans: "Cg = −7.41 × 10⁻³ m; correct length = 29.9925 m (p.135)",
      },
      { k: "note", t: "<b>Check:</b> 30 − 0.00741 = 29.99259 m, which rounds to <b>29.9926 m</b>; the notes' 29.9925 m is the truncated figure. Cg = −7.41 × 10⁻³ m is correct." },
      { k: "def", term: "Normal tension", t: "The pull at which the correction for pull equals the correction for sag, so the two cancel: <b>Correction for pull = Correction for sag</b>. (p.135)" },
      { k: "eq", expr: "(P − Ps) L / (A E) = l w² / (24 n² P²)", where: [
        ["P", "normal tension (unknown) — appears on both sides, so a cubic in P results"],
        ["Ps", "standard tension"],
      ] },
      { k: "eg",
        title: "Notes example — Normal tension for a tape on supports 10 m apart",
        given: "Determine normal tension for a steel tape supported between two supports 10 m apart, if standard tension is 65 N and weight of tape per metre is 0.62 m [read: 0.62 N/m]. E = 2 × 10⁵ MPa and c/s area = 8 mm².",
        steps: [
          { t: "Condition", w: "Correction for pull = Correction for sag\n(P − Ps)L/(AE) = l w²/(24 n² P²)" },
          { t: "Substitute (n = 1 bay, w = 0.62 × 10 N)", w: "(P − 65)(10 × 10³)/(8 × 2 × 10⁵) = 10 × 10³ × (0.62 × 10)²/(24 × 1² × P²)" },
          { t: "Cubic", w: "P³ − 65P² = 2562666.66" },
        ],
        ans: "P = 162.29 N (p.135)",
      },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Sag mein tape seedha nahi rehta, jhool jaata hai — to tape par padhi 30 m ki doori, do supports ke beech ki horizontal doori se zyada hoti hai. Isliye sag correction <b>hamesha negative</b>. Formula mein P² neeche hai: pull badhao to sag tezi se kam hota hai. w total weight hai aur n bays — har bay ka sag alag-alag jod do to l w²/(24 n² P²) hi aata hai, isliye zyada supports = bahut kam sag." },
      { k: "p", t: "Normal tension ek smart jugaad hai: extra pull se tape stretch hota hai (+ correction) aur sag se tape chhota padhta hai (− correction). Aisa pull chuno ki dono barabar ho jaayen — phir koi correction lagana hi nahi padega. Chapter 3.5 mein yahi cubic trial se solve kiya gaya hai." },
      { k: "trap", t: "In Cg = −l w²/(24 n² P²), <b>w is the total weight</b> of the tape (18.48 N for the whole 30 m), not the weight per metre and not the weight per bay. In the normal-tension example the weight per metre (0.62) must first be multiplied by the span (10 m) to get w = 6.2 N." },
      { k: "real", t: "Base-line taping with the tape hung between tripods or pegs is exactly the catenary case; pulling at normal tension with a spring balance lets the crew skip the sag correction for each bay." },
    ] },

    /* ---------------------------------------------------------- MSL + misalignment */
    { n: "", title: "Notes — Correction for MSL and for misalignment", hi: "माध्य समुद्र तल और गलत संरेखण संशोधन", blocks: [
      { k: "h", t: "📘 Notes — p.136" },
      { k: "h", t: "Correction for MSL" },
      { k: "eq", expr: "Ch = − L h / R", where: [
        ["L", "length"],
        ["h", "height above MSL"],
        ["R", "radius of earth, R = 6370 km"],
      ] },
      { k: "eg",
        title: "Notes example — Reducing a base line to MSL",
        given: "Length of base line measured 300 m above MSL is 420.015 m. Determine the equivalent length reduced to MSL.",
        steps: [
          { t: "MSL correction", w: "Ch = −L h/R = (−420.015 × 300)/(6370 × 10³) = −0.019 m" },
          { t: "True value", w: "True value = Measured value + correction\nT.V = 420.015 − 0.019  ⇒  419.9952 m" },
        ],
        ans: "Equivalent length at MSL = 419.9952 m (p.136)",
      },
      { k: "note", t: "<b>Check:</b> the unrounded correction is −0.01978 m, and 420.015 − 0.01978 = 419.9952 m, so the notes' final answer is right; the intermediate line 420.015 − 0.019 would give 419.996 m." },
      { k: "h", t: "Correction for misalignment" },
      { k: "p", t: "Figure (p.136): straight line <b>AB</b> on top (A left, B right). The tape was actually laid from A down to a point off the line (length <b>l₁</b>) and from that point up to B (length <b>l₂</b>); <b>h</b> is the perpendicular from that point to AB (the misalignment). (p.136)" },
      { k: "eq", expr: "Cm = − [ h²/(2l₁²) + h²/(2l₂²) ]   (as written in the box)", where: [
        ["h", "misalignment (perpendicular distance off the line)"],
        ["l₁, l₂", "the two measured parts of the line"],
      ] },
      { k: "note", t: "<b>Check:</b> the boxed formula on p.136 has l₁² and l₂² in the denominators, but the solution below it (and the geometry: l − √(l² − h²) ≈ h²/2l) uses <b>Cm = −[h²/(2l₁) + h²/(2l₂)]</b>. Use the un-squared form." },
      { k: "eg",
        title: "Notes example — Line measured with 1 m misalignment at centre",
        given: "A survey line was measured to be 60 m with a 30 m tape. It was found that there was a misalignment of 1 m at the centre. Determine the correct length.",
        steps: [
          { t: "Misalignment correction", w: "Cm = −[h²/(2l₁) + h²/(2l₂)]  ⇒  −[1²/(2 × 30) + 1²/(2 × 30)]\nCm = −0.033" },
          { t: "True value", w: "T.V = 60 − 0.033" },
        ],
        ans: "T.V = 59.966 m (p.136)",
      },
      { k: "note", t: "<b>Check:</b> Cm = −(1/60 + 1/60) = −0.03333 m, so T.V = 60 − 0.03333 = <b>59.9667 m</b> (59.967 m to the mm); the notes' 59.966 m is truncated. The exact geometry, 2 × (30 − √(30² − 1²)) = 0.03334 m, agrees." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "<b>MSL:</b> survey maps sea-level par banaye jaate hain. Upar (h height par) naapi line, earth ke centre se dekhein to, sea-level par chhoti ho jaati hai — ratio R/(R + h). Isliye MSL correction hamesha <b>−ve</b> (jab line MSL se upar ho)." },
      { k: "p", t: "<b>Misalignment:</b> agar tape seedhi line se hat gaya to aapne terhi path naapi — jo seedhi AB se hamesha lambi hoti hai. Isliye correction <b>hamesha −ve</b>, bilkul slope correction jaisa (h²/2l) — wahan h vertical hai, yahan horizontal." },
      { k: "trap", t: "In the misalignment formula, l₁ and l₂ are the lengths of the two bent parts (30 m each here), not the full 60 m. Using 60 m in each term halves the correction." },
    ] },

    /* ---------------------------------------------------------- combined */
    { n: "", title: "Notes — Combined corrections (pull, temperature, MSL, sag, slope)", hi: "संयुक्त संशोधन — संख्यात्मक", blocks: [
      { k: "h", t: "📘 Notes — p.137–139" },
      { k: "eg",
        title: "Notes example — Horizontal distance between two pegs reduced to MSL",
        given: "A nominal distance of 30 m was set out with a steel tape from a mark on the top of a peg to a mark on the top of another. The tape was in catenary under a pull of 150 N and at a temperature of 25°C. The top of one peg was 0.442 m above the top of the other. Determine the horizontal distance between the marks on the two pegs reduced to MSL, if the top of the higher peg is 195.57 m above MSL. The tape was standardised in catenary at a pull of 120 N and at a temperature of 20°C, and has mass 0.026 kg/m and c/s area 3.25 mm². The coefficient of linear expansion is 0.000011 /°C and E = 2.07 × 10⁵ MPa. The radius of earth may be taken as 6367 km.",
        steps: [
          { t: "Length of tape on flat ground", w: "Normal length of chain = 30 m (flat ground)\nIt is standardised in catenary @ 120 N pull.\nStandard length = L + sag correction @ 120 N pull\nl′ = L + l w²/(24 P²)\nl′ = 30 + (30 × (0.026 × 30 × 9.81)²)/(24 × 120²)\nl′ = 30.0052 m" },
          { t: "(i) Pull correction", w: "Cp = (P − Ps)L/(AE) = ((150 − 120) × 30.0052 × 10³)/(3.25 × 2.07 × 10⁵)\nCp = +1.3380 mm\nCp = +0.0013 m" },
          { t: "(ii) Temperature correction", w: "CT = L α ΔT\nCT = 30.0052 × 0.000011 × (25 − 20)\nCT = +0.00165 m" },
          { t: "(iii) MSL correction", w: "Upper peg RL = 195.57; lower peg RL = 195.57 − 0.442 = 195.128\nh_avg = (195.57 + 195.128)/2 = 195.34\nCh = −L h/R = (−30.0052 × 195.34)/(6367 × 10³) = −0.0000920" },
          { t: "(iv) Sag correction", w: "Cg = −l w²/(24 P²) = (−30.005 × (0.026 × 9.81 × 30)²)/(24 × 150²)\n= −0.00325 m" },
          { t: "(v) Slope correction", w: "Cs = −h²/(2L) = −0.442²/(2 × 30.005)\nCs = −0.00325 m" },
          { t: "Combined correction", w: "Combined correction = −0.000920 + 0.0013 + (−0.00325) + 0.00165 − 0.000325\nC = −0.00447" },
          { t: "Corrected length", w: "C.L = M.L + correction\n= 30.005 − 0.0044" },
        ],
        ans: "C = −0.00447 m; C.L = 30.001 m (p.137–139)",
      },
      { k: "list", items: [
        "Figure (p.138): two levels — upper marked <b>RL = 195.57</b>, lower marked <b>RL = 195.57 − 0.442</b>, with <b>h</b> marked between them (used to get the average height for the MSL correction). (p.138)",
        "Figure (p.139): right-angled triangle — vertical side <b>0.442</b> (with up/down arrows), sloping side <b>30.005</b> (the tape). (p.139)",
      ] },
      { k: "note", t: "<b>Check:</b> (1) l′: w = 0.026 × 30 × 9.81 = 7.652 N, so l w²/(24P²) = 30 × 58.55/345600 = 0.00508 m and l′ = <b>30.0051 m</b> (notes 30.0052 m — no effect on the answer). (2) MSL: h_avg = 195.349 m, and 30.0052 × 195.35/6367000 = <b>−0.000920 m</b>; the notes' line “−0.0000920” has one zero too many, but the combined line correctly uses −0.000920. (3) Slope: 0.442²/(2 × 30.005) = −0.00326 m (notes −0.00325). (4) In the combined line the last term is written −0.000325, but the boxed sum −0.00447 is only obtained with the slope term −0.00325: −0.000920 + 0.0013 − 0.00325 + 0.00165 − 0.00325 = −0.00447 m (with −0.000325 the sum would be −0.001545). (5) C.L = 30.0052 − 0.00447 = 30.0007 m ≈ <b>30.001 m</b>, as the notes give." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Is question ka pehla step sabse important hai. Tape <b>catenary mein</b> 120 N par standardise hua tha — matlab jhoolte hue uski reading 30 m sahi thi. To flat zameen par uski asli lambai thodi zyada hai: l′ = 30 + (120 N wala sag) = 30.0052 m. Ab is l′ se shuru karke field ki har condition ka correction lagao: extra pull (+), zyada temperature (+), height (MSL, −), 150 N par sag (−), aur pegs ke level difference ka slope (−)." },
      { k: "p", t: "Har correction ka sign physically socho: jo cheez tape ko lamba karti hai (pull, garmi) wo +; jo naapi doori ko asli horizontal sea-level doori se lamba dikhati hai (sag, slope, height) wo −." },
      { k: "trap", t: "Do not apply the field sag correction to a tape that was standardised in catenary as if it were standardised on the flat — that double-counts. Either convert to the flat-ground length first (as the notes do with l′) and then apply the full sag at 150 N, or apply only the difference of the two sag corrections. Mixing the two methods is the usual error." },
      { k: "real", t: "Precise taping between pegs — base lines, setting out long bridge spans — needs all five corrections together; individually each is only millimetres, but on a long line they add up to centimetres." },
    ] },

    /* ---------------------------------------------------------- field work */
    { n: "", title: "Notes — Field work in chain surveying, offsets and obstacles", hi: "चेन सर्वेक्षण में क्षेत्र कार्य, ऑफ़सेट और बाधाएँ", blocks: [
      { k: "h", t: "📘 Notes — p.139–141" },
      { k: "h", t: "Field work in chain surveying — steps" },
      { k: "steps", items: [
        "Reconnaissance",
        "Marking of stations",
        "Running survey lines",
        "Taking offsets (p.139)",
      ] },
      { k: "def", term: "1) Reconnaissance", t: "This is the preliminary inspection of the area to be surveyed, to get some idea of the terrain and identify the principal features of the ground. (p.140)" },
      { k: "def", term: "2) Marking of stations", t: "After completion of reconnaissance the main stations are marked on the ground such that the stations can be easily located afterwards. (p.140)" },
      { k: "def", term: "3) Running survey lines", t: "Survey lines are run to measure the distance between main stations. (p.140)" },
      { k: "def", term: "4) Taking offsets", t: "Offsets are lateral distances measured from the survey line. These may be <b>perpendicular</b> or <b>oblique</b> offsets. (p.140)" },
      { k: "list", items: [
        "Figure (p.140, left) — <b>⊥ offset</b>: survey line A—B (horizontal, arrow towards B); a diamond-shaped object with corners R (top), Q (right), P (bottom), S (left); a single perpendicular line drawn from P down to line AB.",
        "Figure (p.140, right) — <b>oblique offset</b>: the same diamond R, Q, P, S above a line with points A and B; two inclined lines run from P down to A and to B, crossing below P (P is fixed by two measured distances from A and B).",
      ] },
      { k: "h", t: "Obstacles in chaining" },
      { k: "p", t: "When chaining a survey line, various obstacles are sometimes encountered in the field. Some obstacles are such that chaining <b>round</b> the obstacle is possible, such as a small pond or a small bend of a river, while in other cases chaining round the obstacle is <b>not possible</b>, e.g. a long river across the survey line. Depending upon the obstacle, a suitable method of chaining should be adopted. (p.141)" },
      { k: "p", t: "<b>(i) When chaining round the obstacle is possible</b> — Figure (p.141): a pond (circle) lies between A (left) and B (right) on the survey line. From A a line l₁ is set out upward (perpendicular), a line l₂ runs across the top parallel to AB, and a line l₃ comes down to B, forming a rectangle round the pond. Then <b>AB = l₂</b>. (p.141)" },
      { k: "p", t: "<b>(ii) When chaining round the obstacle is not possible</b> — Figure (p.141): a river between two banks; A on the near (left) side, B on the far (right) side, line AB across the river. From A a line is set out perpendicular to AB, through C to D. From D a short line DE is set out (perpendicular, away from the river side). A straight line from E passes through C to B. (p.141)" },
      { k: "eq", expr: "From similar triangles CDE and ABC:   DE/DC = AB/AC   ⇒   AB = DE × AC / DC", where: [
        ["AC, CD, DE", "measured on the near bank"],
        ["AB", "the unmeasurable distance across the river"],
      ] },
      { k: "p", t: "AB can be found out. (p.141)" },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Field work ka order logical hai: pehle area ghoom ke dekho (reconnaissance), phir stations gaado jo baad mein mil sakein, phir stations ke beech chain chalao, aur aakhir mein chain line se detail tak offsets lo. Perpendicular offset ek hi naap se point fix karta hai; oblique offset mein do naap (A se aur B se) lagte hain — jahan right angle set karna mushkil ho." },
      { k: "p", t: "River wala trick: C par dono taraf vertically-opposite angles barabar hain aur A tatha D par right angles hain, isliye ΔABC aur ΔDEC similar hain. Nadi ke paar ki doori AB ko apne kinare ki teen naapon (AC, CD, DE) mein badal diya. Chapter 3.3 mein isi idea ka ek doosra construction (BC² = AB × BD) bhi diya hai." },
      { k: "trap", t: "In DE/DC = AB/AC, match the sides correctly: DE corresponds to AB (both opposite the angle at C, perpendicular to the line through A, C, D), and DC corresponds to AC. Swapping them gives AB = DC × AC/DE, which is wrong." },
      { k: "real", t: "A pond or a small loop of a stream is passed by the rectangle method; a wide river, a canal or a railway cutting that cannot be walked round is crossed by the similar-triangle method from one bank." },
    ] },

    /* ---------------------------------------------------------- cross-staff survey */
    { n: "", title: "Notes — Cross-staff survey and area of a field", hi: "क्रॉस-स्टाफ सर्वेक्षण और क्षेत्रफल", blocks: [
      { k: "h", t: "📘 Notes — p.142–143" },
      { k: "p", t: "<b>Q.</b> Plot the cross-staff survey of a field ACDBFE from the field book and determine the area of the field. All values in metres. Calculate area in hectares. (p.142)" },
      { k: "cmp", t: "Field book (p.142) — chain line A (0) to B (1000 m), read from the bottom up", cols: ["Chainage on chain line (m)", "Offset right (m)"], rows: [
        ["—", "at B: 1000", "—"],
        ["F 160 (left)", "K: 750", "—"],
        ["—", "J: 600", "D 140"],
        ["F 150 (left)", "H: 300", "—"],
        ["—", "G: 200", "C 120"],
        ["—", "at A: 0", "—"],
      ] },
      { k: "note", t: "The field book writes the letter F against both left offsets. Since the field is named ACDBFE (going A → C → D → B → F → E), the 160 m offset at 750 is F and the 150 m offset at 300 is E. (p.142)" },
      { k: "list", items: [
        "Figure (p.142) — plot of the field: vertical chain line from A (bottom) to B (top).",
        "Right side: offset 120 at chainage 200 (point C) and offset 140 at chainage 600 (point D); boundary A → C → D → B.",
        "Left side: offset 150 at chainage 300 and offset 160 at chainage 750; boundary A → (150 offset) → (160 offset) → B.",
        "Chain-line segment labels on the sketch: 200 (A to the 120 offset), 100 (120 offset to 150 offset), 300 (beside region 3), 150 (on the left, region 4), 250 (160 offset to B). The sketch is not to scale.",
        "Regions: (1) triangle below the 120 offset, right; (2) triangle below the 150 offset, left; (3) trapezium between the 120 and 140 offsets, right; (4) trapezium between the 150 and 160 offsets, left; (5) triangle above the 140 offset, right; (6) triangle above the 160 offset, left.",
      ] },
      { k: "eg",
        title: "Notes example — Area of field ACDBFE from cross-staff field book",
        given: "Cross-staff field book: chain line A (0) to B (1000 m). Right offsets: C 120 at 200, D 140 at 600. Left offsets: 150 at 300, 160 at 750. All values in metres. Find the area in hectares.",
        steps: [
          { t: "Area (1) — triangle", w: "A₁ = 1/2 × 200 × 120\n= 12000 mm²" },
          { t: "Area (2) — triangle", w: "A₂ = 1/2 × 300 × 150\n= 22500 mm²" },
          { t: "Area (3) — trapezium", w: "A₃ = 1/2 × (140 + 120) × 400\nA₃ = 52000 m²" },
          { t: "Area (4) — trapezium", w: "A₄ = 1/2 × 450 × (150 + 160)\nA₄ = 69750 m²" },
          { t: "Area (5) — triangle", w: "A₅ = 1/2 × 140 × 400\nA₅ = 25000 m²  [digit unclear in the scan; see Check]" },
          { t: "Area (6) — triangle", w: "A₆ = 1/2 × 160 × 250\nA₆ = 20000 m²" },
          { t: "Total", w: "Total area = 204250 m²" },
        ],
        ans: "Total area = 204250 m²; in hectare = 20.42 hect. (p.142–143)",
      },
      { k: "note", t: "<b>Check:</b> (1) A₁ and A₂ are written “mm²”; with all values in metres they are <b>m²</b> (12000 m² and 22500 m²). (2) A₅ = ½ × 140 × 400 = <b>28000 m²</b>; the digit in the notes reads like 25000, but the total 204250 m² uses 28000: 12000 + 22500 + 52000 + 69750 + 28000 + 20000 = 204250 m². (3) 204250 m² ÷ 10000 = <b>20.425 ha</b> (notes 20.42 ha)." },
      { k: "h", t: "💡 Samjho" },
      { k: "p", t: "Cross-staff survey mein ek lambi chain line field ke beech se jaati hai aur har corner tak right-angle offset liya jaata hai (cross-staff se 90° set karke). Isse poora field triangles aur trapeziums mein bant jaata hai: chain line ke shuru aur end par triangle (½ × base × offset), aur do offsets ke beech trapezium (½ × (offset₁ + offset₂) × chainage ka antar)." },
      { k: "p", t: "Field book padhne ka tareeka: beech ka column chainage hai (neeche A se upar B tak), aur dono taraf likhe number offsets hain. Har piece ka base = do consecutive chainages ka antar — jaise right side par 600 − 200 = 400, left side par 750 − 300 = 450, 1000 − 750 = 250." },
      { k: "trap", t: "The base of each piece is the <b>difference</b> of chainages, not the chainage itself — and left and right sides are worked separately with their own chainages. Also keep units: metres × metres = m², and 1 hectare = 10000 m²." },
      { k: "real", t: "Cross-staff surveys are used for small fields and plots where one long chain line can run through the middle and every boundary corner can be reached with a short right-angle offset." },
    ] },

    /* ---------------------------------------------------------- revision */
    { n: "", title: "Notes revision — Tape corrections, field work and cross-staff survey (p.133–143)", hi: "पुनरावृत्ति — टेप संशोधन, क्षेत्र कार्य, क्रॉस-स्टाफ सर्वेक्षण", blocks: [
      { k: "h", t: "✅ Key formulae, values and definitions" },
      { k: "list", items: [
        "✅ Pull: Cp = (P − Ps)L/(AE); + if P &gt; Ps, − otherwise. (p.133)",
        "✅ Tape area from weight: W = γ A L. (p.133)",
        "✅ 30 m tape, 65 → 80 N, W = 10 N: A = 4.32 mm², Cp = 0.520 mm, C.L = 30.00052 m. (p.133)",
        "✅ Temperature: CT = Lα(Tm − To); 850.420 m at 32°C (std 27°C, α = 1.16×10⁻⁵): CT = 0.049, T.V = 850.469 m. (p.134)",
        "✅ Sag: tape between two supports takes a catenary; standardised on flat, used in catenary → correction negative. (p.134)",
        "✅ Sag: Cg = −l w²/(24 n² P²), w = total weight, n = number of bays. 30 m, 80 N, 3 bays, 8 mm²: w = 18.48 N, Cg = −7.41×10⁻³ m. (p.135)",
        "✅ Normal tension: correction for pull = correction for sag; 10 m span, Ps = 65 N, 0.62 N/m, 8 mm²: P³ − 65P² = 2562666.66, P = 162.29 N. (p.135)",
        "✅ MSL: Ch = −Lh/R, R = 6370 km; 420.015 m at 300 m: Ch = −0.019 m, T.V = 419.9952 m. (p.136)",
        "✅ Misalignment: Cm = −[h²/(2l₁) + h²/(2l₂)] (box shows l², solution uses l); 60 m, 1 m off at centre: T.V = 59.966 m (≈ 59.967). (p.136)",
        "✅ Combined example: l′ = 30.0052 m (standardised in catenary at 120 N); Cp = +0.0013, CT = +0.00165, Ch = −0.000920 (h_avg = 195.34), Cg = −0.00325, Cs = −0.00325; C = −0.00447; C.L = 30.001 m. (p.137–139)",
        "✅ Slope: Cs = −h²/(2L). (p.139)",
        "✅ Field work steps: reconnaissance → marking of stations → running survey lines → taking offsets. (p.139–140)",
        "✅ Reconnaissance = preliminary inspection of the area to get an idea of terrain and principal features. (p.140)",
        "✅ Offsets = lateral distances from the survey line; perpendicular or oblique. (p.140)",
        "✅ Obstacle, chaining round possible (pond): rectangle, AB = l₂. (p.141)",
        "✅ Obstacle, chaining round not possible (river): similar Δs CDE and ABC, DE/DC = AB/AC. (p.141)",
        "✅ Cross-staff survey ACDBFE: triangles ½ × base × offset, trapeziums ½ × (sum of offsets) × base; total 204250 m² = 20.42 ha. (p.142–143)",
      ] },
    ] },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
