/* ============================================================
   HYDROLOGY · COMPLETE NOTES — handbook shell
   Chapters are appended by data-hb-hydro-ch*.js files (each guards
   on this handbook already existing, so load order doesn't matter).
   Sources, cited inline on every block:
     S1 = Hydrology Part 1 by Sanjeev (handwritten, 15 pp)
     S2 = Hydrology Part 2 by Sanjeev (handwritten, 109 pp)
     S3 = Hydrology Part 3 (complete) by Sanjeev (handwritten, 55 pp)
     V  = Hydrology, Vision Engineering Academy (scanned printed booklet, 15 pp)
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];
DB.handbooks.push({
  id: "hydro", subject: "hydrology",
  name: "Hydrology — Complete Notes",
  hi: "जल विज्ञान — सम्पूर्ण नोट्स",
  icon: "🌧️",
  blurb: "Hydrologic cycle se lekar precipitation, abstractions (evaporation/infiltration), runoff, streamflow measurement, hydrographs aur flood frequency tak — 4 class-note sources (194 pages) se consolidate kiya gaya, har fact ke saath source aur page number.",
  note: "Sources: Hydrology Part 1 by Sanjeev (S1, 15pp), Hydrology Part 2 by Sanjeev (S2, 109pp), Hydrology Part 3 complete by Sanjeev (S3, 55pp), and Hydrology by Vision Engineering Academy (V, 15pp, printed booklet). Every block cites which source and page it is drawn from. Where the two Sanjeev-series notebooks and the Vision Academy booklet cover the same topic, the content is merged into one section rather than repeated — see each chapter's own source note for exactly which pages feed it.",
  chapters: []
});
