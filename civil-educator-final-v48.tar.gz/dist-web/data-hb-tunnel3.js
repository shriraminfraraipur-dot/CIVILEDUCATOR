/* ============================================================
   TUNNEL ENGINEERING · COMPLETE NOTES — Chapters 5–6
   Lining, ventilation, drainage, health & safety · Railway
   tunnels, NATM, important points and the handbook formula sheet
   Sources: A = tun43-transcript (43 pp, richer) · B = tun18-transcript
   (18 pp, sparser, complementary) — cited as A p.N / B p.N
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "tunnel");
  if (!hb) { console.error("[tunnel3] handbook tunnel not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 5 */
    {
      id: "tunnel-5",
      n: 5,
      title: "Lining, Ventilation, Drainage and Health & Safety",
      hi: "लाइनिंग, वेंटिलेशन, ड्रेनेज और स्वास्थ्य सुरक्षा",
      blurb: "Tunnel lining materials and the T = 82D thickness formula, lighting requirements, the objectives and volume-of-air formula for ventilation, natural vs mechanical (blow-in/blow-out) ventilation, noise and dust control including silicosis, the three-way classification of drainage, and health protection including caisson disease.",
      mins: 24,
      sections: [
        {
          n: "5.1",
          title: "Tunnel lining — purpose, thickness formula and materials",
          hi: "टनल लाइनिंग — उद्देश्य, मोटाई सूत्र और सामग्री",
          blocks: [
            { k: "h", t: "📘 Notes — A p.31–33, B p.18" },
            { k: "def", term: "Tunnel lining", t: "The finishing touch given to the cross-section of a tunnel (A p.31). <b>Temporary lining</b> supports the roof and walls during construction; <b>permanent lining</b> is provided in soft ground, which is always liable to disintegrate (A p.31)." },
            { k: "eq", expr: "Thickness of lining (empirical):  T = 82 D", where: [
              ["T", "thickness of lining, in mm"],
              ["D", "diameter of the tunnel, in metres"],
            ] },
            { k: "list", items: [
              "This thickness is restricted to a <b>minimum of 230 mm</b>, irrespective of the material used for lining. (A p.31, B p.18 — both give the same T = 82D formula with D in m and T in mm)",
              "Thumb rule: <b>25 mm</b> of thickness for every <b>300 mm</b> of bore diameter. (A p.31)",
              "An alternate imperial form is also noted: T = D when T is taken in inches and D in feet, attributed to a reference book whose name is unclear in the source transcript. (A p.31)",
            ] },
            { k: "note", t: "<b>Check (v45): the three lining rules are one rule.</b> 25 mm per 300 mm of diameter = 83.3 mm per metre; 1 inch per foot = 25.4 mm ÷ 0.3048 m = 83.3 mm per metre; and the notes' T = 82D rounds the same ratio. So a 6 m bore gets about 82 × 6 ≈ 490–500 mm by any of the three forms, and the 230 mm minimum governs only below D ≈ 2.8 m (230/82). These are rule-of-thumb starting values for a trial section, not a design: the final lining thickness comes from a structural check of the lining against ground and water loads (General Engineering Knowledge)." },
            { k: "cmp", t: "Materials for tunnel lining (A p.32–33, B p.18)", cols: ["Notes"], rows: [
              ["1) Masonry", "Brick masonry was the standard material but is now largely out of use, except for sewers — the great disadvantage is the difficulty of back-packing the space between the tunnel roof and the arch extrados. Stone masonry has the same disadvantage but is still used for lining sides. (A p.32)"],
              ["2) Cement concrete", "The standard material for both rock and soft-soil lining today — gives proper packing, a smooth waterproof finish, high pressure resistance (with reinforcement) and minimum maintenance cost. In rock terrain it is placed concurrently with the driving operation. B p.18 adds it gives a first-class watertight lining and is used for permanent lining."],
              ["3) Timber", "Easily and rapidly constructed, cheap, and gives a groaning sound as warning before collapse — but it decays, is a fire hazard, and is unsuitable where water percolates. B p.18: the oldest lining material, now replaced by concrete."],
              ["4) Cast iron", "Suitable for shield-driven tunnels, particularly in sub-aqueous regions — withstands jacking thrusts, is made waterproof at joints, is accurately machined for a structural, tight fit, and attains full strength immediately. (A p.33, B p.18)"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "T = 82D is purely empirical — it is not derived from a stress calculation, it is a rule of thumb from practice. That is exactly why the code overrides it with an absolute floor of 230 mm: for a small-diameter tunnel the formula alone would give an impractically thin lining that cannot actually be built or handle handling loads." },
            { k: "trap", t: "Do not confuse 'permanent lining' with 'strong lining'. The notes specifically say permanent lining is used in soft ground <b>because</b> it is liable to disintegrate — permanence here means the lining stays, not that the ground is stable." },
          ],
        },
        {
          n: "5.2",
          title: "Lighting in tunnels",
          hi: "टनल में प्रकाश व्यवस्था",
          blocks: [
            { k: "h", t: "📘 Notes — A p.33, B p.16" },
            { k: "p", t: "For every activity and operation to proceed effectively and satisfactorily, lighting is necessary. A light intensity of <b>260 lumens/m²</b> in the working area is considered satisfactory. (A p.33)" },
            { k: "list", items: [
              "Spacing of lights depends on tunnel dimension, size of the light source, nature of the rock surface, etc.",
              "It is desirable to have <b>more lights of small wattage</b> rather than few lights of larger wattage — this avoids dark spots if one light fails. (A p.33, B p.16)",
              "Overall provision should give uniform illumination without dazzling.",
              "An independent electric circuit with its own isolators and fuse box should be provided, so that only the affected portion needs to be switched off for maintenance/repair. (A p.33)",
            ] },
            { k: "cmp", t: "Types of tunnel lights (A p.33–34, B p.16)", cols: ["Note"], rows: [
              ["1) Lantern and lamp burning oil", "Carried by hand; used during survey work; burning gasoline (B p.16)"],
              ["2) Coal gas lighting", "—"],
              ["3) Acetylene gas lighting", "—"],
              ["4) Electric lighting", "Most popular of the four (B p.16)"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The 'many small lights' rule is a redundancy principle, not just an illumination one — a tunnel is a confined, single-exit space, so a single large light failing must never plunge a long stretch into darkness." },
          ],
        },
        {
          n: "5.3",
          title: "Ventilation — objectives, air-volume formula and methods",
          hi: "वेंटिलेशन — उद्देश्य, वायु-आयतन सूत्र और विधियाँ",
          blocks: [
            { k: "h", t: "📘 Notes — A p.34–36, B p.14–16" },
            { k: "def", term: "Ventilation", t: "The technique of providing fresh air inside the tunnel during and after construction (A p.34). B p.14 frames it slightly more broadly: supply of air and light, and keeping the noise level bearable for humans, during and after construction." },
            { k: "list", items: [
              "<b>Temporary ventilation</b> — provided at the time of construction. <b>Permanent ventilation</b> — provided after the construction work. (A p.34, B p.14)",
            ] },
            { k: "h", t: "① Objects of tunnel ventilation (A p.34)" },
            { k: "list", items: [
              "1) To supply fresh air to the working crew.",
              "2) To remove injurious and obnoxious fumes and gases of explosion.",
              "3) To safely remove dust caused by drilling, blasting and mucking.",
              "4) To reduce temperature in a tunnel situated at great depth.",
            ] },
            { k: "eq", expr: "Volume of air required per worker: 6 to 14 m³/min of fresh air, supplied constantly in the working area", where: [
              ["source", "A p.34 (MES 2017), B p.15"],
            ] },
            { k: "list", items: [
              "The time lapse between exploding the charge and commencing mucking is about <b>30 min</b>, within which the ventilation system should clear the tunnel and supply fresh air. (A p.34)",
              "Capacity of the ventilation system depends on: 1) length and size of tunnel 2) amount of explosive and frequency of blasting 3) temperature and humidity inside the tunnel 4) gases encountered during operation 5) CO₂ released by men, material and explosive 6) heat produced by men, animals, light and certain types of rock. (A p.34–35)",
              "In compressed-air tunnelling the volume of free air to be provided is <b>6 m³/min per m² of face area</b> (A p.23–24, MES 2015) — distinct from the 6–14 m³/min per-worker figure above.",
            ] },
            { k: "h", t: "② Methods of ventilation (A p.35–36, B p.14–16)" },
            { k: "cmp", t: "Natural vs mechanical ventilation", cols: ["Note"], rows: [
              ["Natural ventilation", "Achieved by the temperature difference between inside and outside the tunnel; provided by shafts at suitable intervals along the alignment during construction. Effective for: a) enlarging operation of a drift b) short tunnels of large diameter c) orientation along the wind direction. Inadequate for long tunnels, so mechanical ventilation is then required. (A p.35). B p.14 adds a concrete limit: effective for straight reaches of uniform grade, in tunnels up to <b>100 m</b> in length — a detail not given in A."],
              ["Mechanical ventilation", "Three systems: a) Blowing/plenum process — supplies fresh air right near the working face, but smoke and dust move out slowly, fogging the atmosphere and reducing visibility; not suitable for long tunnels. b) Exhausting/vacuum process — creates a vacuum so natural air is drawn in; shares the advantages/disadvantages of the plenum process. c) Combination of blowing and exhausting — the most efficient system (also called the 'Blow in / Blow out' method, MES 2018, ESE 2007)."],
            ] },
            { k: "list", items: [
              "In the combination system: immediately after blasting the exhausting system runs for <b>15–20 min</b> to remove objectionable gases and dust, after which the blowing system runs for the rest of the working period to supply fresh air. (A p.36)",
              "Fans and pipes are used for tunnel ventilation; pipe size varies from <b>100 mm to 750 mm</b>. (A p.36)",
              "Permanent ventilation is required when the tunnel is left open for traffic, and is generally provided when tunnel length <b>&gt; 750 m</b>. (A p.36)",
              "Vehicles release CO (carbon monoxide): CO % &lt; 0.02% — human beings not affected. CO % = 0.04% — uneasiness, and if inhaled &gt; 1.5 hr → headache; if &gt; 2 hr → unconsciousness. CO % ≥ 0.06% for 2–3 hours proves fatal. (A p.36) — B p.6 separately notes, for excavation air quality generally, CO ≯ 0.01%; the two figures are for different situations (permanent traffic ventilation vs excavation atmosphere) and are both quoted as written.",
              "When tunnels are long, fans are provided at each end plus a central shaft to its left and right. (A p.36)",
              "<b>Primary ventilation</b> is for passengers; <b>secondary ventilation</b> is for plant. (A p.36, B p.16)",
            ] },
            { k: "list", items: [
              "Systems of permanent ventilation (B p.16, not detailed in A's assigned pages): (i) Longitudinal system — fresh air supplied along the length of the tunnel. (ii) Transverse ventilation system — fresh air supplied through shafts. (iii) Combination of longitudinal and transverse / semi-lateral system — the most effective, used for long tunnels.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Keep the two 'volume of air' numbers straight: 6–14 m³/min is <b>per worker</b>, for temporary ventilation during ordinary working; 6 m³/min per m² of face area is a different figure, specific to the <b>compressed-air</b> method's free-air supply. Examiners routinely swap these two to test whether you read the units." },
            { k: "trap", t: "Natural ventilation is not simply 'unreliable' — the notes tie it to specific geometric conditions (short + large-diameter, or good wind orientation). Beyond those, and beyond B's 100 m length figure, mechanical ventilation becomes necessary." },
          ],
        },
        {
          n: "5.4",
          title: "Noise pollution and dust control",
          hi: "ध्वनि प्रदूषण और धूल नियंत्रण",
          blocks: [
            { k: "h", t: "📘 Notes — A p.37, B p.15–16" },
            { k: "h", t: "Noise pollution (A p.37, B p.16)" },
            { k: "list", items: [
              "Continuous noise above <b>100 to 150 dB</b> produces discomfort to passengers.",
              "To reduce the noise level, <b>resonators</b> are installed. A resonator consists of a 20 × 80 cm plastic box, 10 cm high, with a 2 cm diameter spout at the bottom, mounted on an aluminium crib at the crown portion. (A p.37)",
            ] },
            { k: "h", t: "Dust control (A p.37, B p.15)" },
            { k: "p", t: "The various operations of tunnel excavation — drilling, blasting and handling muck — cause dust to accumulate in the tunnel atmosphere. This dust causes serious health risks. In rock tunnels this hazard is very serious, as extended breathing of the silica dust causes a dangerous lung disease known as <b>silicosis</b>, which often proves fatal. (A p.37, MES-2017)" },
            { k: "eq", expr: "Permissible dust concentration: particles of size 0.5 to 5 µ, adjacent to the working area, ≯ 450 particles/cm³", where: [["source", "A p.37, MES-2015"]] },
            { k: "cmp", t: "Methods of dust control", cols: ["Note"], rows: [
              ["1) Wet drilling", "Water used while drilling; does not lead to a completely dust-proof condition but is a fairly good, widely used method. (A p.37, B p.15)"],
              ["2) Use of vacuum hood", "A hood is fitted around the drill, through which drilled dust is sucked and removed safely; vacuum hood combined with wet drilling works satisfactorily. (A p.37, MES-2017; B p.15)"],
              ["3) Use of respirators", "The best and most up-to-date protection. (A p.37, B p.15)"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice the escalation in the three dust-control methods: wet drilling suppresses dust at the source but only partially; the vacuum hood physically captures it; respirators protect the worker directly when the first two are not enough. In practice they are used together, which is exactly why B p.15 calls the hood-plus-wet-drilling combination 'satisfactory' rather than either alone." },
          ],
        },
        {
          n: "5.5",
          title: "Drainage of tunnels",
          hi: "टनल का जल निकासी",
          blocks: [
            { k: "h", t: "📘 Notes — A p.38–39, B p.18" },
            { k: "p", t: "Drainage is provided for: (i) <b>wash water</b>, used for washing drill holes and the cuttings inside the tunnel during construction, and (ii) <b>ground water or sub-soil water</b>. (A p.38) B p.18 frames the same two sources by how they behave: wash water is easy to estimate and handle, while ground/sub-soil water is complex to estimate and difficult to handle." },
            { k: "cmp", t: "Classification of drainage arrangements (A p.38–39, B p.18)", cols: ["Purpose / detail"], rows: [
              ["1) Pre-drainage", "Prevents entry of excess water into the tunnel <b>before</b> construction starts — keeping off surface water and sub-soil water adjoining the tunnel from interfering with the work. Where seepage is small and comes down from the roof, it is made to flow over a temporary pitched roof of corrugated sheet. (A p.38) B p.18 additionally mentions laying steel sheets as suited to single-lane roads and railways, though this reading is marked uncertain in that source."],
              ["2) Dewatering (temporary)", "Removal of water by open drains or ditches on both sides of the tunnel invert. Useful in hard-rock-based and water-resistant soils. (A p.38)"],
              ["3) Pumping (temporary)", "Water that accumulates is collected in sump wells and pumped out. For a long tunnel, water may be pumped from the face into sumps of increasing capacity by a system of gathering pumps, and ultimately pumped out of a sump well near the portal — the sump wells also help settle solid material. Sump wells are located at regular intervals of about <b>800 m to 500 m</b>, or at wet spots (A p.38–39, MES-2018). Any type of centrifugal pump can be used with stand-by units; steel pipes of <b>80 mm to 150 mm</b> diameter are generally used without sacrificing floor working space (A p.39; B p.18 gives the same 80–150 mm pipe range, pumped into a sump)."],
              ["4) Permanent drainage", "A completed tunnel needs a permanent drainage arrangement, typically longitudinal drainage ditches towards the portal or shafts, pumped out from there as required. The drain must have enough capacity to carry the expected water quantity without submerging the tunnel floor, at self-cleansing velocity. The central drain can be covered, with facility for inspection and cleaning. <b>Manholes</b> for inspection should be provided at a distance of <b>30 m to 50 m</b> (A p.39; B p.18 gives the same 30–50 m spacing). If water trickles continuously from the roof, a false roof of corrugated G.I. sheets is provided to divert it to the side drains. The type of permanent drainage adopted depends on soil type, quantity of water, nature of tunnel and type of lining; longitudinal drains, open drains and concrete lining are generally adopted. (A p.39)"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The four categories are really a timeline: pre-drainage acts <b>before</b> excavation reaches the water, dewatering and pumping act <b>during</b> construction while water keeps entering, and permanent drainage is what is left running for the <b>life</b> of the tunnel. A given tunnel typically needs all four in sequence, not just one." },
          ],
        },
        {
          n: "5.6",
          title: "Health protection — silicosis and caisson disease",
          hi: "स्वास्थ्य सुरक्षा — सिलिकोसिस और कैसन रोग",
          blocks: [
            { k: "h", t: "📘 Notes — A p.40" },
            { k: "p", t: "Proper clothing and proper facilities — warm showers, clean and comfortable dressing rooms, lavatories, etc. — are to be provided, along with precautions against the diseases below. (A p.40)" },
            { k: "def", term: "1) Silicosis", t: "Prolonged inhaling of minute silica particles causes fibrosis of lung tissue, which is <b>not curable</b> and progresses even after the victim has left the job or is no longer exposed to silica dust. Dust particles &lt; 10 µ react chemically with pulmonary lymph; after roughly 3 years of contact with silica the worker's blood passage narrows, which can result in a heart attack. The cause of the disease can neither be eliminated nor cured. Silicosis is less dangerous in moist air. A vacuum hood or respirators must be used on drills — wet drilling alone is not fully satisfactory. (A p.40)" },
            { k: "def", term: "2) Caisson disease", t: "Caused when workers are exposed to high pressure for long periods. The joints, fibrous tissue and fats of the body have a poorer blood supply than other body parts, so they de-saturate more slowly during decompression, resulting in localised pain in the body. (A p.40)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Both diseases share the same root cause — the hazardous environment of the working face (dust in one case, pressure in the other) — and both share the same lesson: prevention is the only real cure. Neither the code nor the notes offer a treatment for either; the entire section is about avoiding exposure in the first place, through dust control and controlled decompression schedules." },
            { k: "trap", t: "Do not describe silicosis as reversible if the worker leaves the job — the notes are explicit that it progresses <b>even though</b> the exposure has stopped." },
          ],
        },
        {
          n: "5.7",
          title: "Quick revision — lining, ventilation, drainage, health & safety",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "T = 82D, minimum 230 mm; thumb rule 25 mm per 300 mm bore dia; the four lining materials and their pros/cons.",
              "Lighting: 260 lumens/m²; more small-wattage lights over fewer large ones; independent circuits.",
              "Ventilation objectives; 6–14 m³/min per worker vs 6 m³/min/m² face area (compressed air); natural vs the three mechanical systems; blow-in/blow-out sequence (15–20 min exhaust, then blow); permanent ventilation &gt; 750 m; primary vs secondary ventilation.",
              "Noise &gt; 100–150 dB; resonator construction; dust limit 450 particles/cm³ (0.5–5µ); wet drilling / vacuum hood / respirators.",
              "Four-way drainage classification: pre-drainage, dewatering, pumping (sump wells 500–800 m, pipes 80–150 mm), permanent (manholes 30–50 m).",
              "Silicosis (incurable, progressive) vs caisson disease (decompression, localised pain) and their precautions.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "T = 82D (mm, D in m), floor 230 mm — the single most quoted formula in tunnel lining questions.",
              "6–14 m³/min per worker is the temporary-ventilation number; 6 m³/min per m² face area is the compressed-air-method number — don't swap them.",
              "Combination (blow-in/blow-out) ventilation is the most efficient system; exhaust first (15–20 min), then blow.",
              "Dust limit: 450 particles/cm³ for 0.5–5µ particles — this is what causes silicosis if exceeded over time.",
              "Sump wells every 500–800 m; manholes every 30–50 m; drainage pipes 80–150 mm — three different spacing numbers, easy to mix up.",
            ] },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "tunnel-6",
      n: 6,
      title: "Special Topics — Railway Tunnels, NATM and Revision",
      hi: "विशेष विषय — रेलवे टनल, NATM और पुनरावृत्ति",
      blurb: "BG single-track railway tunnel dimensions, the initial survey sequence for tunnel alignment, the New Austrian Tunnelling Method (NATM), the notes' own 'important points' summary — and finally a complete, deduplicated formula sheet and previous-year-question quick reference pulled from across all six chapters of both sources.",
      mins: 18,
      sections: [
        {
          n: "6.1",
          title: "Railway tunnels and the initial survey sequence",
          hi: "रेलवे टनल और प्रारंभिक सर्वेक्षण क्रम",
          blocks: [
            { k: "h", t: "📘 Notes — A p.41, B p.2" },
            { k: "p", t: "Tunnelling is preferred for railways. Railway tunnels are generally <b>poly-centric</b>. (A p.41)" },
            { k: "eq", expr: "For a B.G. (broad gauge) single-track tunnel:  width = 4.9 to 5.5 m ;  height above top of rail = 6.7 to 7.3 m", where: [["source", "A p.41, B p.2 — both sources agree on these figures"]] },
            { k: "h", t: "Initial survey work for setting the tunnel alignment (A p.41, MES-2015) — sequence" },
            { k: "steps", items: [
              "1) Preliminary setting of the tunnel on the topographical survey of Indian maps.",
              "2) Marking tunnel obligatory points on the topographical maps.",
              "3) Solving lines between the fixed obligatory points.",
              "4) Marking portal points with concrete pillars on the ground.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "This sequence moves from paper to ground: it starts on a map (topographical survey), narrows to fixed control points (obligatory points), does the geometry on paper (solving lines), and only in the last step actually drives a physical marker (concrete pillar) into the earth. Getting the order right — map before pillar — is the point of the question." },
          ],
        },
        {
          n: "6.2",
          title: "NATM and the notes' 'important points' summary",
          hi: "NATM और नोट्स के 'महत्वपूर्ण बिंदु'",
          blocks: [
            { k: "h", t: "📘 Notes — A p.41–43, B p.17" },
            { k: "def", term: "NATM (New Austrian Tunnelling Method)", t: "A newly developed, economical tunnelling method used in rock. Used for large sections in very difficult grounds and below built-up areas; also used for subway construction and in abnormal geological conditions. NATM is also called the <b>Observational Method</b> or the <b>shortcrete method</b>. (A p.41) B p.17 gives only the name, listing it as the special method of tunnelling in rock, without further detail." },
            { k: "h", t: "Important topics and points (A p.42–43)" },
            { k: "list", items: [
              "<b>1) For tunnelling operation:</b> Topographical maps are useful in mountainous regions. The height of a point on the ridge is fixed with the help of reciprocal ranging. For planimetric control, an accuracy of <b>1 in 1000</b> is required.",
              "<b>2) For setting an inclined tunnel:</b> Reference points are constructed at every <b>300 m</b>. The alignment is fixed from the upper/lower apex point. The invert level at the heading is marked by a tap.",
              "<b>3) Cut-and-cover method</b> of construction, in the construction of metro railways, is suitable when the soil is soft and the water table is high.",
              "<b>4) High-pressure grouting</b> is generally resorted to for concreting the lining when the rock strata is poor, highly fissured and likely to see seepage of water.",
              "<b>5)</b> The difference in height of tunnels above rail top between B.G. and M.G. track is kept at <b>0.60 m</b>.",
              "<b>6)</b> The following methods of tunnelling do not require the use of timbering: liner plate method, shield method, compressed air method.",
            ] },
            { k: "h", t: "Lining terms and their function (A p.42–43)" },
            { k: "cmp", t: "By location", cols: ["Function"], rows: [
              ["(a) Ground mould", "Invert lining"],
              ["(b) Leading frame", "Side-wall lining"],
              ["(c) Trusses", "Roof arch lining"],
            ] },
            { k: "cmp", t: "Components", cols: ["Function"], rows: [
              ["(a) Loggings", "To retain the fill"],
              ["(b) Collar braces", "To prevent segments from twisting out of line"],
              ["(c) Wall plates", "To support the arch rib at springing level"],
              ["(d) Segments", "To carry roof load under arch action"],
            ] },
            { k: "p", t: "The advantage of the <b>heading and benching method</b> is that tunnelling is continuous and the work can be expedited. (A p.43, IES-1997)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "NATM's two alternate names tell you what it actually is: 'Observational Method' because support is adjusted based on continuous monitoring of ground behaviour rather than a fixed pre-design, and 'shortcrete method' because sprayed concrete (shotcrete) is the primary means of quickly stabilising the excavated face — the name change simply reflects which feature the speaker is emphasising." },
            { k: "trap", t: "The 0.60 m BG/MG height difference (point 5) and the BG tunnel dimensions in section 6.1 are two separate numbers from two separate notes on the same page — don't merge them into one figure." },
          ],
        },
        {
          n: "6.3",
          title: "Previous-Year Questions and Formula Sheet — full handbook (Ch. 1–6)",
          hi: "पिछले वर्षों के प्रश्न और सूत्र-पत्रक",
          blocks: [
            { k: "h", t: "📐 Formula sheet" },
            { k: "p", t: "Every distinct formula/empirical relation found across the full 43-page (A) and 18-page (B) transcripts is collected below, cited to its actual page, with no duplicates. Purely descriptive limits (percentages, spacings, durations) that are not expressed as a symbolic relation are grouped afterwards as design-data numbers." },
            { k: "eq", expr: "1) Lining thickness:  T = 82 D  (T in mm, D in m) ; T_min = 230 mm", where: [["source", "A p.31, B p.18"]] },
            { k: "eq", expr: "2) Faces of attack from vertical shafts:  Faces = 2n + 2", where: [
              ["n", "number of shafts (formula includes the two portals)"],
              ["source", "A p.16, B p.4"],
            ] },
            { k: "eq", expr: "3) Depth of blast hole:  d₀ = (4/3) · ∛(W/C)", where: [
              ["W", "weight of charge"],
              ["C", "a coefficient depending on the rock and the quality of explosive"],
              ["source", "B p.13"],
            ] },
            { k: "eq", expr: "4) Rock yield vs number of free faces (for an equidistant charge, distance d):  1 face → V ;  2 faces → 2.25 V ;  3 faces → 3.5 V", where: [["source", "single free face and 2.25× figure: A p.12; full 1/2.25/3.5 V set: B p.13"]] },
            { k: "eq", expr: "5) Blast-hole diameter:  d(hole) = d(cartridge) + 6 mm", where: [["source", "A p.9"]] },
            { k: "eq", expr: "6) Grade of a long tunnel:  grade provided < 0.75 × ruling gradient", where: [["source", "A p.9 ties this to tunnels of length > 3 km; B p.5 ties the same 0.75× rule to tunnels of length > 300 m — a direct conflict between the two sources on the length threshold; both figures are quoted as written."]] },
            { k: "eq", expr: "7) Lining-ring overlap (shield tunnelling):  max. overlap = 1½ × ring length ;  min. overlap = ½ × ring length", where: [["source", "A p.29, B p.9"]] },
            { k: "eq", expr: "8) Liner-plate stiffening (soft-ground/sub-aqueous tunnelling):  required when tunnel diameter ≥ 8 m (A p.27)  or  > 3 m (B p.8) ; where required, depth of stiffening beam = 25 to 40 mm per metre of tunnel diameter (B p.8)", where: [["source", "Source conflict on the diameter threshold — A gives ≥ 8 m, B gives > 3 m; both are quoted as written. The beam-depth relation appears only in B."]] },
            { k: "eq", expr: "9) Ventilation air volume, per worker:  6 to 14 m³/min", where: [["source", "A p.34, B p.15"]] },
            { k: "eq", expr: "10) Free-air volume, compressed-air method:  6 m³/min per m² of face area", where: [["source", "A p.23–24"]] },
            { k: "eq", expr: "11) Drilling rate:  1 drill required per 4 to 5 m² of face area", where: [["source", "A p.9"]] },
            { k: "eq", expr: "12) BG single-track railway tunnel:  width = 4.9–5.5 m ; height above rail top = 6.7–7.3 m ; (BG height − MG height) above rail top = 0.60 m", where: [["source", "A p.41–42, B p.2"]] },
            { k: "eq", expr: "13) Dust concentration limit:  particles of 0.5–5 µ ≯ 450 particles/cm³", where: [["source", "A p.37"]] },
            { k: "h", t: "Other design-data numbers used across the notes (not symbolic formulas, but frequently asked)" },
            { k: "cmp", t: "Design data by topic", cols: ["Value", "Source"], rows: [
              ["Planimetric control accuracy", "1 in 1000", "A p.42"],
              ["Reference points for inclined tunnel setting", "every 300 m", "A p.42"],
              ["Manhole spacing, permanent drainage", "30 to 50 m", "A p.39, B p.18"],
              ["Sump-well spacing", "500 to 800 m, or at wet spots", "A p.39"],
              ["Drainage / pumping pipe diameter", "80 to 150 mm", "A p.39, B p.18"],
              ["Full-face method applicability", "diameter < 6 m and face area < 19 m²", "A p.19, B p.12"],
              ["Shaft protective wall height", "900 mm", "A p.14"],
              ["Compressed-air working hours", "pressure ≤ 1.25 kg/cm² → 8 hr work / 4 hr breathing interval ; pressure > 1 kg/cm² → 4 hr work / 2 hr breathing interval (crossover between 1 and 1.25 kg/cm² as written in source)", "A p.23"],
              ["Self-supporting ground, stand-up length", "1200–1500 mm (also written '4 ft to 16 ft' in the same line — internally inconsistent as written) per A ; 1.2 m to 5 m per B — a source conflict", "A p.22, B p.6"],
              ["Needle-beam method", "beam length 5–6 m ; advance rate 3–4 m/day", "A p.24, B p.7"],
              ["Drainage gradient", "nearly level, or 0.2% for drainage", "A p.9, B p.4"],
            ] },
            { k: "note", t: "<b>Check:</b> the self-supporting-ground stand-up length is internally inconsistent within A itself (1200–1500 mm is not the same range as 4–16 ft), and B's figure (1.2–5 m) does not match either — all three numbers are reproduced exactly as the transcripts give them rather than silently picking one." },
            { k: "h", t: "📝 Previous-year-question tags found in the notes (exam-marked points, for quick revision)" },
            { k: "list", items: [
              "[MES 2015] Lining thickness formula, T = 82D — A p.31.",
              "[MES 2017] Ventilation air volume, 6–14 m³/min per worker — A p.34.",
              "[MES 2015] Free-air volume in compressed-air method, 6 m³/min per m² face area — A p.23–24.",
              "[MES 2018 / ESE 2007] Combination (blow-in/blow-out) ventilation as the most efficient system — A p.36.",
              "[MES 2017] Silicosis as the lung disease from prolonged silica-dust exposure — A p.37.",
              "[MES 2015] Dust concentration limit, 450 particles/cm³ — A p.37.",
              "[MES 2018] Sump wells at 800–500 m intervals — A p.39.",
              "[MES 2015] Initial survey sequence for setting tunnel alignment — A p.41.",
              "[MES 2018] NATM as the 'Observational Method' / shortcrete method — A p.41.",
              "[IES 1997] Advantage of the heading-and-benching method — continuous tunnelling, work expedited — A p.43.",
              "[IES 2001] Tunnel alignment carried out by triangulation — A p.8.",
              "[IES 1995 / ESE 2008] Weisbach triangle method to connect the two ends of an underground tunnel — A p.8.",
              "[ESE 2008] Shafts also help in additional access, muck removal and natural ventilation in long tunnels — A p.13.",
              "[MES 2011] Central wedge cut as the most commonly used shaft cut, for square/rectangular sections — A p.12.",
              "[MES 2015] Trimmers used to attain the required shape of a tunnel — A p.6.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "When A and B disagree on a threshold (the 3 km vs 300 m grade rule, the 8 m vs 3 m liner-plate rule, the self-supporting-ground length), the safest exam answer is to name the rule itself confidently — the 0.75 × ruling-gradient relation, the need for stiffening on a large-diameter tunnel — and mention that the exact threshold varies by source rather than committing to a single number you cannot verify." },
          ],
        },
      ],
    },

  );
})();
