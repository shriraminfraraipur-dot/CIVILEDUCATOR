/* ============================================================
   CIVIL EDUCATOR — material categories
   ------------------------------------------------------------
   The 22 material guides were a single flat list, which is fine
   at 5 and unusable at 22. These are the groups a student
   already thinks in — the same shape the codes use.

   Kept in its own file so the grouping can change without
   touching the guides themselves.
   ============================================================ */

window.DB = window.DB || {};

DB.matCategories = [
  {
    id: "binders", icon: "🥣", name: "Binders & cementitious", hi: "बंधक सामग्री",
    blurb: "The things that set and hold everything else together",
  },
  {
    id: "concrete", icon: "🧊", name: "Concrete & aggregate", hi: "कंक्रीट एवं aggregate",
    blurb: "What concrete is made of, and concrete itself",
  },
  {
    id: "metal", icon: "⛓", name: "Steel & metals", hi: "स्टील एवं धातुएँ",
    blurb: "Reinforcement, sections and metalwork",
  },
  {
    id: "masonry", icon: "🧱", name: "Masonry & natural materials", hi: "चिनाई एवं प्राकृतिक सामग्री",
    blurb: "What walls, footings and the ground are made of",
  },
  {
    id: "finishes", icon: "🎨", name: "Finishes & services", hi: "फ़िनिश एवं सेवाएँ",
    blurb: "Everything applied or fitted after the structure stands",
  },
];

/* Bitumen sits with the binders on purpose: in a flexible pavement that is
   exactly what it is, and a student looking for "the binder" should find it
   next to cement and lime rather than in a road-only corner. */
DB.matCatOf = {
  "mat-cement": "binders",
  "mat-lime": "binders",
  "mat-flyash": "binders",
  "mat-admixture": "binders",
  "mat-gypsum": "binders",
  "mat-mortar": "binders",
  "mat-bitumen": "binders",

  "mat-aggregate": "concrete",
  "mat-concrete": "concrete",
  "mat-water": "concrete",

  "mat-steel": "metal",
  "mat-structsteel": "metal",
  "mat-aluminium": "metal",

  "mat-brick": "masonry",
  "mat-stone": "masonry",
  "mat-timber": "masonry",
  "mat-soil": "masonry",

  "mat-paint": "finishes",
  "mat-tiles": "finishes",
  "mat-glass": "finishes",
  "mat-waterproofing": "finishes",
  "mat-pipes": "finishes",
};
