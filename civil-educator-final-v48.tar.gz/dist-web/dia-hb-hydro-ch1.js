/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for the Hydrology handbook, Chapter 1.
   ------------------------------------------------------------
   Same conventions as the other handbooks' diagram files: strokes
   are currentColor so both themes work, meaning-carrying strokes
   use .hi (marker) or .ac (accent), and every figure gets its own
   marker id prefix so two figures on one page never collide.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hyMk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}
/* diagonal hatch fill for a rock/rect band */
function hyHatch(x, y, w, h) {
  let s = `<rect class="s" x="${x}" y="${y}" width="${w}" height="${h}" fill="none"/>`;
  for (let i = -h; i < w; i += 10) {
    let x1 = x + i, x2 = x + i + h;
    s += `<line class="thin" x1="${Math.max(x, x1)}" y1="${x1 < x ? y + (x - x1) : y}" x2="${Math.min(x + w, x2)}" y2="${x2 > x + w ? y + h - (x2 - (x + w)) : y + h}"/>`;
  }
  return s;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 1.2  HYDROLOGIC CYCLE */
  "hb-hydro-cycle": {
    label: "The hydrologic cycle — all components in one figure",
    svg: `<svg viewBox="0 0 680 420" role="img" aria-label="The hydrologic cycle. Rain falls from a cloud; some is intercepted by a tree and evaporates back, the rest reaches the ground. On the ground, some water runs off the surface as surface runoff into a river, pausing in depression storage pockets on the way; the rest infiltrates vertically down to the water table. Below the water table it percolates further down to an impervious rock layer, and groundwater also feeds the river sideways as baseflow or interflow. Water returns to the atmosphere by evaporation from the land and the river surface and by transpiration from the tree, closing the cycle back to the cloud.">
      ${hyMk("hy")}

      <!-- cloud + precipitation -->
      <g>
        <circle class="soft" cx="400" cy="46" r="22"/>
        <circle class="soft" cx="424" cy="40" r="26"/>
        <circle class="soft" cx="452" cy="48" r="20"/>
        <rect class="soft" x="384" y="50" width="86" height="16" rx="8"/>
        <text class="em" x="427" y="24" text-anchor="middle">Precipitation</text>
      </g>
      <line class="hi" x1="368" y1="70" x2="368" y2="96" marker-end="url(#hy-m)"/>
      <line class="hi" x1="400" y1="70" x2="400" y2="100" marker-end="url(#hy-m)"/>
      <line class="hi" x1="432" y1="70" x2="432" y2="100" marker-end="url(#hy-m)"/>
      <line class="hi" x1="460" y1="70" x2="460" y2="100" marker-end="url(#hy-m)"/>

      <!-- ground surface: hill on the left sloping into the river valley on the right -->
      <path class="s" d="M30 150 L200 168 Q300 180 360 212 Q460 236 610 236"/>
      <text class="lb" x="54" y="140">G.L.</text>

      <!-- tree: interception + transpiration + evaporation from soil -->
      <line class="s" x1="170" y1="162" x2="170" y2="118"/>
      <circle class="conc" cx="170" cy="100" r="24"/>
      <line class="hi" x1="368" y1="70" x2="170" y2="96" marker-end="url(#hy-m)" opacity="0"/>
      <line class="hi" x1="160" y1="78" x2="150" y2="56" marker-end="url(#hy-m)"/>
      <line class="hi" x1="178" y1="76" x2="186" y2="52" marker-end="url(#hy-m)"/>
      <text class="ea" x="150" y="44" text-anchor="middle">Transpiration</text>
      <text class="ea" x="170" y="130" text-anchor="middle">Interception</text>
      <line class="hi" x1="206" y1="150" x2="222" y2="118" marker-end="url(#hy-m)"/>
      <text class="lb" x="236" y="112">Evaporation</text>
      <text class="lb" x="236" y="128">(land / soil)</text>

      <!-- surface runoff + depression storage -->
      <path class="ac" d="M220 174 Q300 192 360 214 Q460 234 580 236" marker-end="url(#hy-c)"/>
      <text class="em" x="330" y="200" text-anchor="middle">Surface Runoff</text>
      <ellipse class="soft" cx="300" cy="182" rx="18" ry="6"/>
      <line class="thin dash" x1="300" y1="176" x2="300" y2="150"/>
      <text class="lb" x="300" y="166" text-anchor="middle">Depression</text>
      <text class="lb" x="300" y="200" text-anchor="middle" opacity="0">.</text>
      <text class="lb" x="256" y="195" text-anchor="middle">storage</text>

      <!-- infiltration (vertical) -->
      <line class="hi" x1="110" y1="160" x2="110" y2="262" marker-end="url(#hy-m)"/>
      <line class="hi" x1="150" y1="166" x2="150" y2="268" marker-end="url(#hy-m)"/>
      <text class="ea" x="90" y="226" text-anchor="end">Infiltration</text>
      <text class="lb" x="90" y="240" text-anchor="end">(vertical only)</text>

      <!-- water table -->
      <line class="thin dash" x1="30" y1="282" x2="610" y2="282"/>
      <text class="lb" x="40" y="276">G.W.T. (water table)</text>

      <!-- percolation (vertical, below GWT) -->
      <line class="hi" x1="110" y1="290" x2="110" y2="356" marker-end="url(#hy-m)"/>
      <line class="hi" x1="150" y1="290" x2="150" y2="356" marker-end="url(#hy-m)"/>
      <text class="ea" x="90" y="326" text-anchor="end">Percolation</text>

      <!-- baseflow / interflow toward the river (lateral) -->
      <path class="hi" d="M200 300 Q380 300 470 290" marker-end="url(#hy-m)"/>
      <text class="em" x="330" y="316" text-anchor="middle">Baseflow / Interflow (lateral, to river)</text>

      <!-- rock layer -->
      ${hyHatch(30, 364, 580, 30)}
      <text class="lb" x="40" y="358">ROCK (impervious boundary)</text>

      <!-- river / ocean basin -->
      <path class="softa" d="M470 236 Q520 216 580 236 Q610 248 610 280 L470 280 Q450 258 470 236 Z"/>
      <path class="s" d="M470 236 Q520 216 580 236 Q610 248 610 280"/>
      <text class="em" x="540" y="260" text-anchor="middle">River / Ocean</text>

      <!-- evaporation from water, closing the loop back to the cloud -->
      <line class="hi" x1="500" y1="226" x2="490" y2="196" marker-end="url(#hy-m)"/>
      <line class="hi" x1="540" y1="222" x2="534" y2="192" marker-end="url(#hy-m)"/>
      <text class="lb" x="560" y="200">Evaporation</text>
      <text class="lb" x="560" y="214">(river / ocean)</text>
      <path class="thin dash" d="M520 190 Q520 120 470 72" marker-end="url(#hy-a)"/>
    </svg>`,
    caption: "Precipitation falls from the cloud; part of it never reaches the ground at all — it is held back as interception (on the tree) or as depression storage (in ground hollows) and evaporates straight back. What does reach the ground either runs off the surface into the river, or infiltrates vertically down to the water table, below which it percolates further down to the impervious rock. Groundwater also moves sideways as baseflow/interflow to feed the river. Evaporation from land and water, plus transpiration from vegetation, send water back to the atmosphere, closing the cycle (S2 p.1–2; V p.2–3).",
  },

});
