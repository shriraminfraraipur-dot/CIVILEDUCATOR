/* MACE Academy SOM notes — Elastic constants, Poisson's ratio, generalised Hooke's law, FOS and related numericals, M p.83–103 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------------- E and G */
    {
      n: "",
      title: "MACE notes — Elastic constants: Young's modulus E and shear modulus G",
      hi: "प्रत्यास्थ स्थिरांक — यंग मापांक E और अपरूपण मापांक G",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.83–85" },
        { k: "p", t: "<b>Differential form of strains (continued from M p.82).</b> A point A is at (u, v). The point B, originally a height dy above A, moves after deformation to the position <b>[u + (∂u/∂y)·dy , v + dy]</b>. From the small triangle A–B–B′: ∂u / x = ∂y / dy ⇒ <b>x = (∂u/∂y)·dy</b>, i.e. the horizontal shift of B is (∂u/∂y)·dy and the angle at A is ∂u/∂y. (M p.83)" },
        { k: "list", items: [
          "Figure (M p.83, middle): triangle with A at the bottom, B directly above A at height dy, B′ displaced horizontally from B by x; line AB′ inclined; angle at A marked ∂u/∂y.",
          "Figure (M p.83, right): x–y axes; element ABCD with A (u, v) and D (u + dx, v) on the bottom edge (AD = dx), B and C on the top; A at distance u from the y-axis. Deformed shape AB′C′D — the top edge shifted right (B → B′, C → C′) by x.",
        ] },
        { k: "def", term: "Elastic constant", t: "The parameters that show the stress–strain relationship are known as <b>elastic constants</b>. For various types of stress condition, various elastic constants are defined. (M p.83)" },
        { k: "list", items: [
          "For the normal stress system → <b>Young's modulus</b> is defined",
          "For the shear stress–strain relationship → <b>shear modulus</b> is defined",
          "For hydrostatic loading conditions → <b>bulk modulus</b> is defined",
          "For the linear and lateral strain relationship → <b>Poisson's ratio</b> is defined (M p.83)",
        ] },
        { k: "h", t: "1) Young's modulus (modulus of elasticity, MOE)" },
        { k: "p", t: "Figure (M p.83): a bar of length L fixed at a wall on the left, pulled by P at the right end; the elongation ΔL is shown dashed beyond the end." },
        { k: "eq", expr: "Original length = L ; final length = L + ΔL = L + (ΔL/L)·L  ⇒  final length = L(1 + ε) ,  ε = ΔL/L", where: [["σ", "stress induced"], ["ε", "strain = ΔL/L"]] },
        { k: "eq", expr: "Hooke's law: σ ∝ ε (within proportionality limit) ⇒ σ/ε = constant ⇒ σ/ε = E", where: [["E", "modulus of elasticity"], ["σ", "stress"], ["ε", "strain"]] },
        { k: "p", t: "If ε = 1 then <b>E = σ</b>, i.e. MOE is the stress required to produce unit strain, i.e. <b>MOE is a stiffness property</b>. Figure (M p.84): two bars of the same length L, each pulled by P — steel shows a small extension, rubber a larger one ⇒ <b>(MOE)steel &gt; (MOE)rubber</b>. (M p.84)" },
        { k: "p", t: "ε = 1 means ΔL/L = 1, i.e. <b>ΔL = L</b>. We can conclude that E = σ = P/A when ΔL = L, i.e. the final length becomes 2L₀ (L₀ = original length). But generally <b>ε ≈ 1/1000 only</b>. (M p.84)" },
        { k: "list", items: [
          "<b>Unit:</b> N/m² or N/mm², i.e. kPa, GPa, MPa (same as stress). (M p.84)",
          "<b>Dimension:</b> [M¹ L⁻¹ T⁻²]  [1 N = kg·m/s²]. (M p.84)",
          "<b>NOTE:</b> Young's modulus is the load required per unit area so as to elongate the body by its original length, i.e. to double the dimension of the body. (M p.84)",
          "<b>NOTE:</b> Young's modulus is found by simply taking the slope of the stress–strain curve at the origin. (M p.84)",
          "<b>NOTE:</b> As per IS 456-2000, the modulus of elasticity of steel shall be taken as <b>200 kN/mm²</b>. (M p.84)",
        ] },
        { k: "h", t: "2) Shear modulus (modulus of rigidity)" },
        { k: "p", t: "φ = shear strain = 2 × linear strain; τ = (shear force)/(c/s area) = shear stress. Figure (M p.84): a block fixed at its base (hatched) with the shear stress τ acting along the top face; in the deformed (sheared) shape the left side is inclined at angle φ." },
        { k: "eq", expr: "τ ∝ φ ⇒ τ/φ = constant ⇒ τ/φ = G", where: [["G", "shear modulus or modulus of rigidity"], ["τ", "shear stress"], ["φ", "shear strain"]] },
        { k: "list", items: [
          "G = ∞ for an <b>ideal rigid</b> body. (M p.84)",
          "In the case of a <b>fluid at rest</b>, τ = 0 ⇒ <b>G_fluid = 0</b>. (M p.84)",
          "Figure (M p.84): τ–φ graph — a vertical line along the τ axis labelled 'Ideal rigid, G = ∞'; a horizontal line along the φ axis labelled 'Ideal fluid, G = 0'.",
        ] },
        { k: "cmp", t: "Modulus of rigidity (G) of materials (M p.85)", cols: ["G (shear modulus)"], rows: [
          ["1) Diamond", "478 GPa"],
          ["2) Steel", "79.3 GPa"],
          ["3) Copper", "44.7 GPa"],
          ["4) Aluminium", "25.5 GPa"],
          ["5) Iron", "52.5 GPa"],
          ["6) Rubber", "0.0006 GPa"],
          ["7) Glass", "26.2 GPa"],
          ["8) Fluid", "0"],
        ] },
        { k: "list", items: [
          "G_steel &gt; G_copper &gt; G_aluminium &gt; G_rubber — decreasing order. (M p.85)",
          "<b>NOTE:</b> Shear modulus of metals decreases with increase in temperature [G ∝ 1/T]. (M p.85)",
          "<b>NOTE:</b> At high pressure, shear modulus ∝ applied pressure. (M p.85)",
          "<b>Unit and dimension of G:</b> same as MOE, G = N/m² = (kg·m/s²)·(1/m²) ⇒ G = M¹ L⁻¹ T⁻². (M p.85)",
          "Shear modulus denotes resistance to shear loading, i.e. shear modulus is useful in assessing stiffness against shear. (M p.85)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "E ko 'kitna zor lagega ek unit strain ke liye' samjho — isliye E stiffness hai. ε = 1 (bar ki length double) sirf definition samjhane ka tareeka hai; real metal to ε ≈ 1/1000 par hi yield ke paas pahunch jaata hai. G wahi kaam shear ke liye karta hai: rigid body kabhi shear nahi hoti (G = ∞), aur fluid at rest koi shear resist nahi karta (G = 0). Relations aur steel ka worked example §2.1 mein hai." },
        { k: "trap", t: "E aur G ki unit stress wali hi hai (N/mm², GPa) kyunki strain dimensionless hai. GPa ko MPa mein badalte waqt 10³ ka factor bhoolna common galti hai: 79.3 GPa = 79 300 N/mm², 200 kN/mm² = 200 000 N/mm²." },
        { k: "real", t: "Steel ka bada G (≈ 79 GPa) aur rubber ka bahut chhota G — isi wajah se elastomeric bridge bearings rubber ke bante hain: woh deck ko thermal movement ke liye shear mein aasani se khisakne dete hain." },
      ],
    },

    /* ---------------------------------------------------------------- K and volumetric strain */
    {
      n: "",
      title: "MACE notes — Bulk modulus and volumetric strain",
      hi: "आयतन मापांक और आयतनिक विकृति",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.85–88" },
        { k: "p", t: "<b>3) Bulk modulus.</b> In the hydrostatic loading condition: σx = σy = σz = σ₀ ⇐ direct stress (all around). Figure (M p.85): a cube with σy pressing down on the top face, σx pressing into the right face and σz pressing into the front face — hydrostatic all-round compression." },
        { k: "list", items: [
          "For the given loading the body will either (i) <b>support</b> compression due to σ₀ ⇒ due to the property called <b>compressibility (β)</b>, or (ii) <b>resist</b> compression due to σ₀ ⇒ due to the property called <b>bulk modulus (K)</b>. (M p.85)",
        ] },
        { k: "def", term: "Bulk modulus (K)", t: "★ Bulk modulus is the ratio of direct stress to the volumetric strain (dilation / dilatation). (M p.86)" },
        { k: "eq", expr: "K = σ_direct / ε_vol  ;  ε_vol = ΔV/V  (ΔV = increase in volume — called dilation)", where: [] },
        { k: "list", items: [
          "Bulk modulus is more significant in the case of the compressibility effect under hydrostatic loading. (M p.86)",
          "Bulk modulus shows resistance to compression. (M p.86)",
          "Compressibility is the reciprocal of bulk modulus: <b>β ∝ 1/K</b>. (M p.86)",
        ] },
        { k: "cmp", t: "Bulk modulus of materials (M p.86)", cols: ["K"], rows: [
          ["1) Glass", "35 − 55 GPa"],
          ["2) Steel", "160 GPa"],
          ["3) Diamond", "443 GPa"],
          ["4) Water", "2.2 GPa"],
        ] },
        { k: "h", t: "Volumetric strain — from final dimensions (M p.86–87)" },
        { k: "steps", items: [
          "Initial dimension = L; change = ΔL; strain ε = ΔL/L ⇒ <b>ΔL = L·ε</b>; final dimension = L + L·ε = <b>L(1 + ε)</b>. (M p.86)",
          "Figure (M p.86): a cuboid with edges x, y, z; σy → εy acting on the top face, σx → εx on the right face, σz → εz on the front face. Original dimensions x, y, z; final dimensions x(1 + εx), y(1 + εy), z(1 + εz).",
          "ε_vol = ΔV/V = (V_f − V₀)/V₀; V_f &gt; V₀ → tensile load. (M p.86)",
          "Final volume = xyz(1 + εx)(1 + εy)(1 + εz) = xyz[1 + εz + εy + εyεz + εx + εxεz + εxεy + εxεyεz]. (M p.87)",
          "But εx is very small and εx·εy is much smaller, so εyεz ≈ 0, εxεz ≈ 0, εxεy ≈ 0, εxεyεz = 0 ⇒ <b>final volume = xyz(1 + εx + εy + εz)</b>. (M p.87)",
          "ε_vol = [xyz(1 + εx + εy + εz) − xyz]/xyz ⇒ <b>ε_vol = εx + εy + εz</b>. (M p.87)",
        ] },
        { k: "h", t: "★ Alternate method — by differentiation (M p.87)" },
        { k: "steps", items: [
          "Original volume V = x·y·z. Differentiate: dV = xy(dz) + xz(dy) + yz(dx).",
          "Divide by V: dV/V = xy·dz/xyz + xz·dy/xyz + yz·dx/xyz = dz/z + dy/y + dx/x.",
          "<b>ε_vol = εx + εy + εz</b>. (M p.87)",
          "The three terms are the three possible cases: ① x, y constant and z changes; ② x, z constant and y changes; ③ y, z constant and x changes. (M p.87)",
        ] },
        { k: "eq", expr: "ε_vol = ΔV/V = εx + εy + εz", where: [["εx, εy, εz", "linear strains along the three edges (small-strain result: products of strains neglected)"]] },
        { k: "eg", title: "MACE notes example — fractional decrease in radius of a sphere under uniform pressure", given: "Bulk modulus for a spherical object is K. If it is subjected to uniform pressure P, the fractional decrease in radius is: (a) P/(3K) (b) 3P/K (c) P/K (d) PK/3 (e) 3K/P", steps: [
          { t: "Fractional change in radius", w: "= dr/r ; K = P/ε_vol ... (1)" },
          { t: "Volume of sphere", w: "V = (4/3)πr³\ndV = (4/3)π(3r²)·dr" },
          { t: "Divide by V", w: "ε_vol = dV/V = (4/3)π(3r²)dr / [(4/3)πr³]\nε_vol = 3(dr/r)" },
          { t: "Put in (1)", w: "K = P / [3(dr/r)]\ndr/r = P/(3K)" },
        ], ans: "dr/r = P/(3K) — option (a). (M p.88)" },
        { k: "p", t: "Figure (M p.88): a sphere of radius r with arrows pointing radially inward all round it (uniform pressure P), labelled K and P." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Volume ka strain teeno directions ke linear strains ka jod hai — kyunki strain itne chhote hote hain ki unke products (εx·εy) zero maan sakte hain. Sphere mein har direction mein radius ka same strain hai, isliye ε_vol = 3 × (dr/r). K bahut bada ho (steel 160 GPa) to volume mushkil se badalta hai; paani ka K sirf 2.2 GPa hai, phir bhi practical mein usse 'incompressible' maana jaata hai kyunki pressures chhote hote hain." },
        { k: "trap", t: "Sphere question mein P/K volumetric strain hai, radius ka fractional change nahi. Radius (ya diameter) ka strain uska <b>ek-tihaai</b> hai: dr/r = P/(3K). Option (c) P/K isi galti ke liye rakha jaata hai." },
        { k: "real", t: "Water K ≈ 2.2 GPa (M p.86) — hydraulic jacks aur pipelines ki water-hammer calculations mein yahi compressibility (β = 1/K) use hoti hai." },
      ],
    },

    /* ---------------------------------------------------------------- Poisson's ratio */
    {
      n: "",
      title: "MACE notes — Poisson's ratio: definition, range, auxetic materials and values",
      hi: "पॉइसन अनुपात — परिभाषा, सीमा और मान",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.88–90" },
        { k: "p", t: "<b>4) Poisson's ratio.</b> If the body elongates in the x-direction due to load in the x-direction ⇒ it is called <b>linear strain</b> (ε_linear). If the body elongates in the x-direction then it gets contracted in the y-direction ⇒ the strain in the y-direction due to load in the x-direction is called <b>lateral strain</b> (ε_lateral). (M p.88)" },
        { k: "p", t: "Figure (M p.88) 'Poisson's effect': vertical axis 'direction ⊥ to load (lateral)', horizontal axis 'direction of load (axial)'. A bar of length L and depth d ('before strain', black outline) is overlaid by a longer, thinner bar ('after strain', blue); axial pull σx at both ends; the elongation labelled 'ε_linear or ε_axial'." },
        { k: "eq", expr: "ε_lin = ΔL/L₀ (↑)  ;  ε_lat = Δd/d₀ (↓)", where: [["L₀, d₀", "original length and depth (diameter)"]] },
        { k: "p", t: "If ε_linear is +ve then ε_lateral is −ve. Thus, as per Poisson, ε_lateral ∝ −ε_linear ⇒ −ε_lateral/ε_linear = constant. (M p.89)" },
        { k: "eq", expr: "μ = − ε_lateral / ε_linear", where: [["μ", "Poisson's ratio"]] },
        { k: "list", items: [
          "★ Engineering range of μ ⇒ <b>0 to 0.5</b> (M p.89)",
          "★ Universal range of μ ⇒ <b>−1 to 0.5</b> (M p.89)",
          "★ Maximum value of μ ⇒ <b>0.5</b> (M p.89)",
        ] },
        { k: "def", term: "Auxetic material", t: "When Poisson's ratio (μ) is <b>−ve</b>, such a material is called an <b>auxetic material</b>. (M p.89)" },
        { k: "cmp", t: "Sign of μ (M p.89)", cols: ["Normal material", "Auxetic material"], rows: [
          ["ε_lin", "+ve (or −ve)", "+ve (or −ve)"],
          ["ε_lat", "−ve (or +ve)", "+ve (or −ve)"],
          ["μ", "+ve (+ve)", "−ve (−ve) — 'auxetic material'"],
        ] },
        { k: "note", t: "In this sign table the notes write μ = −ε_lin/ε_lat (M p.89); the definition two lines above is μ = −ε_lat/ε_lin. The sign conclusion is the same either way (opposite signs → μ +ve; same signs → μ −ve), but use −ε_lat/ε_lin for values." },
        { k: "cmp", t: "Values of μ for different materials (M p.89)", cols: ["μ"], rows: [
          ["1) Cork", "0"],
          ["2) Concrete", "0.15"],
          ["3) Rubber", "0.4999 ≈ 0.5"],
          ["4) Ideal plastic", "0.5"],
          ["5) Perfectly rigid", "0"],
          ["6) Non-dilatant", "0.5"],
          ["7) Copper", "0.33"],
          ["8) Cast iron", "0.23"],
          ["9) Elastic / metal material", "0.25 − 0.42"],
        ] },
        { k: "h", t: "★ Significance of Poisson's ratio (M p.90)" },
        { k: "p", t: "Figure (M p.90): a rectangular bar of length x pulled by σx at both ends (σx ⇒ εx = dx/x); arrows at top (downward) and bottom (upward) show the lateral contraction ε_lat = εy." },
        { k: "eq", expr: "μ = −ε_lat/εx ⇒ ε_lat = −μ·εx ⇒ εy = −μ·εx ... (1)  ;  ε_vol = εx + εy = εx − μ·εx ⇒ ε_vol = εx(1 − μ)", where: [] },
        { k: "note", t: "<b>Check:</b> εx(1 − μ) counts only the x and y directions (a 2-D, in-plane 'area' strain). For a 3-D bar under σx alone, the z-direction also contracts, εz = −μ·εx, so ε_vol = εx + εy + εz = <b>εx(1 − 2μ)</b> — exactly what the notes themselves get on M p.94 (ε_vol,x = (σx/E)(1 − 2μ))." },
        { k: "note", t: "<b>Source difference:</b> the existing §2.1 (p.5) gives μ between 0 and 0.5; the MACE notes give 0 to 0.5 as the <i>engineering</i> range and −1 to 0.5 as the <i>universal</i> range (M p.89). Both are right — re-derived: E = 2G(1 + μ) with E &gt; 0 and G &gt; 0 needs 1 + μ &gt; 0 ⇒ μ &gt; −1; E = 3K(1 − 2μ) with K &gt; 0 needs μ &lt; 0.5. So −1 &lt; μ &lt; 0.5 is the theoretical limit; ordinary engineering materials (and the GATE/ESE answer) lie in 0–0.5; negative values belong to auxetic materials." },
        { k: "note", t: "<b>Source difference:</b> concrete μ = <b>0.15</b> in the MACE table (M p.89) vs <b>≈ 0.2</b> as the typical design value in the existing §2.1 table. μ for concrete is not a single number — it varies with mix and stress level — so neither is 'wrong'; quote 0.15 if a question follows these notes and state the assumed value in design work." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Rubber band khincho to patla ho jaata hai — yahi Poisson effect hai. Lambai badhi (+ve), motai ghati (−ve), isliye formula mein minus lagta hai taaki μ positive aaye. μ = 0.5 par volume bilkul nahi badalta (rubber, ideal plastic — 'non-dilatant'); μ = 0 par side mein koi badlav nahi (cork — isliye bottle ke dhakkan ke liye perfect: dabane par side mein phoolta nahi)." },
        { k: "trap", t: "Ek-dimensional bar ka volumetric strain εx(1 − 2μ) hai, εx(1 − μ) nahi — (1 − μ) sirf do directions (plate ka area) ke liye hai. Aur μ ka sign: agar answer negative aaye to woh auxetic material hai, ordinary engineering material nahi." },
        { k: "real", t: "Cork ka μ ≈ 0 (M p.89) — bottle mein ghusaate waqt woh side mein nahi phoolta. Rubber ka μ ≈ 0.5 — isliye rubber pad ko dabao to volume constant rakhne ke liye woh sides se bahar nikalta hai; bearings mein steel plates daal kar isi bulge ko roka jaata hai." },
      ],
    },

    /* ---------------------------------------------------------------- relations + Q1-Q5 */
    {
      n: "",
      title: "MACE notes — Relations between E, G, K and μ, memory tricks and numericals",
      hi: "प्रत्यास्थ स्थिरांकों के संबंध और प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.90, 92–94" },
        { k: "eq", expr: "1) E = 2G(1 + μ)   2) E = 3K(1 − 2μ)   3) E = 9KG/(3K + G)   4) μ = (3K − 2G)/(6K + 2G)", where: [] },
        { k: "list", items: [
          "<b>Trick 1 — E = 2G(1 + μ):</b> “2G spectrum में एक से बढकर एक चोर” — एक → (1), बढकर → (+), चोर → (μ) [meow मांजर]. Gloss: 'In the 2G spectrum (scam) each thief is bigger than the next' — 'one' = 1, 'bigger' = plus, 'thief' = μ (the μ is drawn like a cat — 'मांजर' = cat in Marathi). (M p.90)",
          "<b>Trick 2 — E = 3K(1 − 2μ):</b> “3 काकांचे वाजले बारा” — 3 काकांचे → (3K), वाजले → (−), बारा → (1 − 2). Gloss (Marathi): 'three uncles are done for (their twelve o'clock struck)'. (M p.90)",
          "<b>Trick 3 — E = 9KG/(3K + G):</b> “नौ बच्चे KG में पढते थे / जिनमे से '3' की GF थी” — नौ → (9), KG → (KG); 3 → (3), की → (K), GF → (G). Gloss (Hindi): 'nine children studied in KG / of whom 3 had a girlfriend'. (M p.90)",
          "<b>Trick 4 — μ = (3K − 2G)/(6K + 2G):</b> “3000 पगार होता तेव्हा 2 गुलाब जामुन … कमी खायचो / 6000 पगार झाला तेव्हा 2 गुलाब जामुन जास्त खायचो” — 3000 → (3K), 2 गुलाब → (2G), कमी → (−); 6000 → (6K), 2 गुलाब → (2G), जास्त → (+). Gloss (Marathi): 'when my salary was 3000 I ate 2 gulab jamuns less / when it became 6000 I ate 2 gulab jamuns more'. (M p.90)",
        ] },
        { k: "eg", title: "MACE notes example — Poisson's ratio when E = G (Que 1)", given: "Find out the Poisson's ratio for a material whose MOE = MOR (modulus of rigidity), i.e. E = G.", steps: [
          { t: "Use E = 2G(1 + μ)", w: "E = 2E(1 + μ)" },
          { t: "Cancel E", w: "1/2 = 1 + μ\n1/2 − 1 = μ" },
        ], ans: "μ = −0.5 — not an engineering material, i.e. an auxetic material. (M p.92)" },
        { k: "eg", title: "MACE notes example — Poisson's ratio when E = K (Que 2)", given: "Find out the Poisson's ratio for a material whose MOE = bulk modulus, i.e. E = K.", steps: [
          { t: "Use E = 3K(1 − 2μ)", w: "E = 3E(1 − 2μ)" },
          { t: "Cancel E", w: "1/3 = 1 − 2μ\n1/3 − 1 = −2μ\n−2/3 = −2μ\n(−2/3) × (−1/2) = μ\n2/6 = μ = 1/3" },
        ], ans: "μ = 0.33 (1/3). (M p.92)" },
        { k: "eg", title: "MACE notes example — Poisson's ratio and E when K = G (Que 3)", given: "Find out the Poisson's ratio of a material in which bulk modulus = modulus of rigidity, i.e. K = G. Also E = ?", steps: [
          { t: "Use μ = (3K − 2G)/(6K + 2G) with G = K", w: "μ = (3K − 2K)/(6K + 2K) = K(3 − 2)/[K(6 + 2)] = 1/8 = 1/(4 × 2)\nμ = 0.125" },
          { t: "Use E = 9KG/(3K + G) with G = K", w: "E = 9K²/(3K + K) = 9K²/(4K)\nE = 2.25K" },
        ], ans: "μ = 0.125 and E = 2.25K. (M p.93)" },
        { k: "eg", title: "MACE notes example — Poisson's ratio from a tension test (Que 4)", given: "A bar of length 100 cm was subjected to an axial tensile load of 1 kN. The strain or change in length in the direction of load was 0.1 cm. If the corresponding change in the diameter of the bar was 0.01 mm, what will be the Poisson's ratio for the given material, if the original diameter of the bar was 5 cm?", steps: [
          { t: "Convert", w: "d = 5 cm = 50 mm ; L = 100 cm = 1000 mm ; ΔL = 0.1 cm = 1 mm ; δd = 0.01 mm" },
          { t: "μ = −ε_lat/ε_linear (magnitudes)", w: "μ = (δd/d)/(δl/l) = (0.01 mm/50 mm)/(1 mm/1000 mm)\n= (0.01/50) × (1000/1) = 1/5" },
        ], ans: "μ = 0.2. (M p.93)" },
        { k: "p", t: "Figure (M p.93, Que 4): circular cross-section of diameter 5 cm (50 mm); bar fixed at the left end, length 100 cm (1000 mm), pulled at the right end by 1 kN; extension 0.1 cm (1 mm) shown dotted." },
        { k: "eg", title: "MACE notes example — volume change of a metal sphere under fluid pressure (Que 5, ESE)", given: "A metal sphere of volume 7500 mm³ is subjected to all-around fluid pressure of 200 MPa. The bulk modulus of the material is 1 × 10⁵ N/mm². The volumetric change is: (a) zero (b) 10 mm³ (c) 5 mm³ (d) 15 mm³", steps: [
          { t: "K = σ₀/ε_vol", w: "ε_vol = σ₀/K\nΔV/V = σ₀/K" },
          { t: "Substitute", w: "ΔV = (7500 × 200)/(1 × 10⁵) = 150/10" },
        ], ans: "ΔV = 15 mm (as boxed in the notes) — option (d). (M p.93)" },
        { k: "note", t: "<b>Check:</b> 7500 × 200 / 10⁵ = 15 ✔, but the unit is <b>mm³</b> (a volume), not mm as boxed in the notes: ΔV = 15 mm³ (a decrease, since the pressure is compressive) — option (d)." },
        { k: "list", items: [
          "<b>NOTE 1:</b> The ratio of Young's modulus to the bulk modulus for most metals is about more than 1/3rd. (M p.94)",
          "<b>NOTE 2:</b> Poisson's ratio is constant within the elastic zone. For a non-elastic material / zone, Poisson's ratio is called the <b>contraction ratio</b>. (M p.94)",
        ] },
        { k: "note", t: "From E = 3K(1 − 2μ), E/K = 3(1 − 2μ): for the metal range μ = 0.25 − 0.42 (M p.89) this is 1.5 down to 0.48 — above 1/3 in every case, as NOTE 1 says. E/K would equal 1/3 only at μ = 4/9 ≈ 0.44." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Charon relations ek hi baat ke alag roop hain: isotropic material mein sirf do constants independent hain, baaki do inhi se nikal aate hain (derivation §2.1 mein). Exam mein 'E = G' ya 'E = K' jaisi condition aaye to bas wahi relation chuno jismein dono symbols aate hain aur ek ko cancel kar do — ek line ka sawaal hai." },
        { k: "trap", t: "E = G se μ = −0.5 aata hai — galat calculation nahi, balki material hi auxetic hai (engineering range 0–0.5 se bahar). Aur K = G ke case mein μ = 1/8 ko 1/4 likh dena (6 + 2 = 8, na ki 4) common slip hai." },
      ],
    },

    /* ---------------------------------------------------------------- Hooke's law assumptions, material classes */
    {
      n: "",
      title: "MACE notes — Assumptions of Hooke's law and material symmetry classes",
      hi: "हुक के नियम की मान्यताएँ और पदार्थों के प्रकार",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.90–92" },
        { k: "list", items: [
          "<b>Assumptions of Hooke's law:</b> 1) material is linear elastic; 2) material is isotropic; 3) material is homogeneous. (M p.90)",
        ] },
        { k: "p", t: "★ There are various types of material based upon the distribution of the material, or the molecules, or the atoms, i.e. based upon <b>structure</b>. (M p.90)" },
        { k: "def", term: "1) Monoclinic material", t: "Linear elastic solid having <b>one plane</b> of material symmetry. (M p.90)" },
        { k: "def", term: "2) Isotropic material", t: "Material properties are the <b>same in all directions</b> at all points. Isotropy denotes <b>rotational invariance</b>. Figure (M p.90): three mutually perpendicular axes, each labelled E (same E in every direction). (M p.90–91)" },
        { k: "def", term: "3) Homogeneous material", t: "Material properties are the <b>same at all points</b>. Homogeneity means <b>translational invariance</b>. Figure (M p.91): two sets of three mutually perpendicular axes at two points — E_x1, E_y1, E_z1 and E_x2, E_y2, E_z2 — with E_x1 = E_x2, E_y1 = E_y2, E_z1 = E_z2. (M p.91)" },
        { k: "def", term: "4) Hyperelastic material / Green elastic material", t: "Example: <b>rubber</b>. The stress–strain relationship is derived by means of a <b>strain energy density function</b> (in simple words, modulus of resilience). The stress–strain curve for such a material is always <b>non-linear</b>. Such materials are non-linear elastic, isotropic and incompressible. Their stress–strain relationship is independent of strain rate. (M p.91)" },
        { k: "p", t: "Figure (M p.91): stress–strain axes; a straight steep line from the origin labelled 'linear elastic'; a curve rising and flattening labelled 'non-linear or hyperelastic'." },
        { k: "def", term: "5) Orthotropic material", t: "Material properties differ along <b>three mutually perpendicular orthogonal axes</b>. It is a subset (type) of anisotropic material because properties are different in different directions. ★ Such materials have <b>three planes of symmetry</b>. Example: <b>wood</b>. (M p.91)" },
        { k: "note", t: "NOTE (M p.91): It can be proved that if a material has 2 planes of symmetry, then the 3rd one will also be a plane of symmetry." },
        { k: "def", term: "6) Transversely isotropic material", t: "Special case of orthotropic material in which there is only <b>one axis of symmetry</b>. (M p.91)" },
        { k: "def", term: "7) Anisotropic material", t: "Properties are different in different directions. (M p.91)" },
        { k: "cmp", t: "Total number of independent elastic constants (M p.92)", cols: ["Independent elastic constants"], rows: [
          ["1) General isotropic material", "81"],
          ["2) General isotropic material with stress and strain symmetry [homogeneous]", "36"],
          ["★ 3) Hyperelastic material with stress and strain symmetry [anisotropic material, alleotropic]", "21"],
          ["4) Monoclinic material", "13"],
          ["★ 5) Orthotropic", "9"],
          ["★ 6) Transversely isotropic material", "5"],
          ["★ 7) Homogeneous and isotropic material", "2"],
        ] },
        { k: "note", t: "<b>Check (wording of rows 1–2):</b> 81 and 36 belong to the <i>general anisotropic</i> material, not an isotropic one — an isotropic material has only 2. General Engineering Knowledge: the stiffness tensor linking 9 stress components to 9 strain components has 9 × 9 = 81 terms; symmetry of the stress and strain tensors (τxy = τyx etc.) cuts this to 6 × 6 = 36; the existence of a strain-energy function (hyperelastic) makes the 6 × 6 matrix symmetric, leaving 21 — the usual 'anisotropic' count. The numbers in the table are right; read 'isotropic' in rows 1–2 as 'anisotropic'." },
        { k: "note", t: "<b>Source difference:</b> none in the values — the existing §2.1 table (p.5) gives isotropic 2, orthotropic 9, anisotropic 21, which match rows 7, 5 and 3 here. The MACE table adds the 81, 36, 13 (monoclinic) and 5 (transversely isotropic) steps." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Isotropic = 'har <i>direction</i> mein same' (ghumao to farak nahi — rotation); homogeneous = 'har <i>point</i> par same' (khiskao to farak nahi — translation). Jitni zyada symmetry, utne kam independent constants: koi symmetry nahi → 21, teen planes (wood) → 9, ek axis ke chaaron taraf same → 5, poori tarah same → sirf 2 (E aur μ)." },
        { k: "trap", t: "Isotropic aur homogeneous ko ek samajhna galat hai. Ek material homogeneous ho kar bhi anisotropic ho sakta hai (jaise wood ka ek clear piece — har point par same, par grain ke along aur across alag). Aur number '21' anisotropic ka hai, '81' nahi — 81 bina kisi symmetry ke raw count hai." },
        { k: "real", t: "Wood orthotropic hai (M p.91) — isliye timber design mein grain ke parallel aur perpendicular alag permissible stresses diye jaate hain. Steel ko isotropic aur homogeneous maan kar sirf E aur μ se kaam chal jaata hai." },
      ],
    },

    /* ---------------------------------------------------------------- generalised Hooke's law */
    {
      n: "",
      title: "MACE notes — Generalised Hooke's law and volumetric strain of solids",
      hi: "सामान्यीकृत हुक का नियम",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.94–95" },
        { k: "p", t: "Loading conditions may be of the following three types (M p.94):" },
        { k: "list", items: [
          "<b>(i) Uniaxial loading</b> — figure: cube pulled by σx on the left and right faces. εx → linear strain; εy, εz → lateral strain.",
          "<b>(ii) Biaxial loading</b> — figure: cube with σx (left, right) and σy (top, bottom). εx, εy → can be both lateral and linear strain; εz → lateral.",
          "<b>(iii) Triaxial loading</b> — figure: cube with σx, σy and σz. εx, εy, εz → can be both linear and lateral strain. (M p.94)",
        ] },
        { k: "eq", expr: "μ = −ε_lat/ε_lin  ⇒  ε_lat = −μ·ε_lin", where: [] },
        { k: "cmp", t: "Strain in each direction from each stress acting alone — the strains in a row are added (M p.94)", cols: ["Uniaxial-x (σx)", "Uniaxial-y (σy)", "Uniaxial-z (σz)"], rows: [
          ["Strain in x-direction", "εxx = σx/E (linear)", "+ εxy = −μ·σy/E (lateral)", "+ εxz = −μ·σz/E (lateral)"],
          ["Strain in y-direction", "εyx = −μ·σx/E (lateral)", "+ εyy = σy/E (linear)", "+ εyz = −μ·σz/E (lateral)"],
          ["Strain in z-direction", "εzx = −μ·σx/E (lateral)", "+ εzy = −μ·σy/E (lateral)", "+ εzz = σz/E (linear)"],
          ["ε_vol from that stress alone", "(σx/E)(1 − 2μ), when σy and σz = 0", "(σy/E)(1 − 2μ), when σx and σz = 0", "(σz/E)(1 − 2μ), when σx and σy = 0"],
        ] },
        { k: "eq", expr: "① εx = σx/E − μ·σy/E − μ·σz/E   ② εy = σy/E − μ·σx/E − μ·σz/E   ③ εz = σz/E − μ·σx/E − μ·σy/E", where: [] },
        { k: "eq", expr: "④ ε_vol = εx + εy + εz = [(σx + σy + σz)/E]·(1 − 2μ)", where: [] },
        { k: "p", t: "If μ = 0.5 ⇒ <b>ε_vol = 0</b> ··· non-dilatant material. (M p.95)" },
        { k: "steps", items: [
          "In the hydrostatic loading condition the all-round stress is the same: σx = σy = σz = σ_direct. (M p.95)",
          "ε_vol = (3σ_direct/E)(1 − 2μ)",
          "E = 3(σ_direct/ε_vol)(1 − 2μ)",
          "★ <b>E = 3K(1 − 2μ)</b> (M p.95)",
        ] },
        { k: "eg", title: "MACE notes example — volumetric strain of a sphere of diameter D (Que 1, M p.95)", given: "Find out the volumetric strain for a spherical body of diameter D under triaxial loading conditions.", steps: [
          { t: "Original volume", w: "V = (4/3)πr³ = (1/6)πD³" },
          { t: "Differentiate", w: "dV = (1/6)π(3D²)·dD" },
          { t: "Divide by V", w: "dV/V = (1/6)π(3D²)dD / [(1/6)πD³]\nε_vol = 3(dD/D)   (since ε = δl/l)" },
        ], ans: "ε_vol = 3(dD/D) = 3 × ε_diametral. (M p.95)" },
        { k: "eg", title: "MACE notes example — volumetric strain of a cylindrical rod (Que 2, M p.95)", given: "Find the volumetric strain for a cylindrical rod of length L and diameter D.", steps: [
          { t: "Volume", w: "V = (π/4)D²L" },
          { t: "Differentiate", w: "dV = (π/4)D²(dL) + (π/4)L(2D·dD)" },
          { t: "Divide by V", w: "dV/V = (π/4)D²dL / [(π/4)D²L] + (π/4)2DL·dD / [(π/4)D²L]\ndV/V = dL/L + 2(dD/D)" },
        ], ans: "ε_vol = ε_longitudinal + 2ε_diametral. (M p.95)" },
        { k: "p", t: "Figures (M p.95): a sphere with diameter D marked across the top; a horizontal cylindrical rod with diameter D at the left end and length L below." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Generalised Hooke's law sirf superposition hai: har stress apni direction ko σ/E se khinchta hai aur baaki do directions ko μσ/E se sikodta hai. Table ki har row jod do — wahi ①②③ hain. Teeno ko jodo to ④ milta hai, aur hydrostatic case mein wahi E = 3K(1 − 2μ) ban jaata hai. Same result existing §2.1 mein bhi hai." },
        { k: "p", t: "Shape ke hisaab se volumetric strain: cube/sphere — teeno dimensions same strain, isliye 3ε; cylinder — length ek baar, diameter do baar (area mein D² hai), isliye ε_L + 2ε_D." },
        { k: "trap", t: "Cylinder mein ε_vol = ε_L + 2ε_D hai, ε_L + ε_D nahi — diameter area mein squared aata hai. Aur lateral strain ka sign: tension mein εD negative hota hai, to ε_vol = ε_L(1 − 2μ) aata hai; sign bhoolne par volume galat badh jaata hai." },
        { k: "real", t: "Thin-cylinder (boiler, pipe) problems mein volume change isi ε_L + 2ε_D se nikalta hai, jahan ε_L aur ε_D hoop aur longitudinal stresses se generalised Hooke's law se milte hain." },
      ],
    },

    /* ---------------------------------------------------------------- FOS */
    {
      n: "",
      title: "MACE notes — Factor of safety and margin of safety",
      hi: "सुरक्षा गुणांक और सुरक्षा मार्जिन",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.96–97" },
        { k: "def", term: "★ Factor of safety (FOS)", t: "General definition: <b>FOS = (failure stress)/(working stress)</b>. (M p.96)" },
        { k: "list", items: [
          "<b>Failure stress</b> is the stress at which we assume the material has failed or broken, i.e. beyond failure stress the material is useless. (M p.96)",
          "<b>Working stress</b> is the allowable stress in the material. (M p.96)",
          "Example: if a material fails at 200 MPa, then the working stress will be less than 200 MPa. (M p.96)",
          "FOS defines how much lesser the working stress is as compared to the failure stress. (M p.96)",
          "Example: if a column has to carry a 2000 kN load, its cross-section shall be designed such that it is capable of carrying a load more than 2000 kN. (M p.96)",
          "Based upon the type of material, the consideration of failure stress changes: for <b>ductile</b> materials, failure stress = <b>yield stress</b>; for <b>brittle</b> materials, failure stress = <b>ultimate stress</b>. (M p.96)",
        ] },
        { k: "eq", expr: "FOS(ductile) = yield stress / working stress   ;   FOS(brittle) = ultimate stress / working stress", where: [] },
        { k: "list", items: [
          "FOS ∝ 1/economy ∝ safety ∝ costly (M p.96)",
          "σ_design = P/A  ;  A_req = FOS · P/σ (M p.96)",
        ] },
        { k: "def", term: "★ Margin of safety (MOS)", t: "MOS = (failure stress − working stress)/(working stress) = (F.S./W.S.) − 1 ⇒ <b>MOS = FOS − 1</b>, i.e. <b>FOS = MOS + 1</b>. (M p.96)" },
        { k: "p", t: "Figure (M p.96): a vertical stress axis with two horizontal lines — the upper labelled 'failure stress', the lower 'working stress'; the gap between them marked with a double arrow 'margin'." },
        { k: "eg", title: "MACE notes example — size of a square column (Que 1)", given: "A column is to be designed for a load of 1500 kN. If the permissible stress in the material of failure is not to exceed 200 MPa, what will be the cross-sectional dimension of the square column? Assume a safety factor of 2.", steps: [
          { t: "Data", w: "P = 1500 kN = 1500 × 10³ N ; σf = 200 MPa = 200 N/mm² ; FOS = 2" },
          { t: "Working stress", w: "σ = 200/FOS = 100 N/mm²" },
          { t: "σ = P/A", w: "100 = 1 500 000/A\nA² (side²) = 1 500 000/100 = 15 000\nside = √15 000 = √(150 × 100) = 10√150 = 10 × 12.4 = 124 mm ≅ 125 mm\n(side note: 12² = 144, 13² = 169)" },
        ], ans: "Square column of side 124 mm ≅ 125 mm. (M p.97)" },
        { k: "note", t: "<b>Check:</b> √150 = 12.25, not 12.4, so the required side = √15 000 = <b>122.5 mm</b> (required area 15 000 mm²). The notes' 124 mm is a slightly high square root; adopting 125 mm is still safe because it is rounded up (125² = 15 625 mm² &gt; 15 000 mm²). Note also that 'A²' in the notes means side², the area A itself being 15 000 mm²." },
        { k: "p", t: "Figure (M p.97, side sketch): stress axis with a solid line at 200 and a dashed line at 100 labelled '200/FOS = 100'." },
        { k: "cmp", t: "Que 2 — classify the following designs on the basis of (i) economy (ii) safety (M p.97)", cols: ["FOS · P (kN)", "σ permissible (N/mm²)", "A provided"], rows: [
          ["i)", "1.5 · 1000", "200", "2000 mm²"],
          ["ii)", "2 · 2000", "100", "10 000 mm²"],
          ["iii)", "1.5 · 2000", "200", "10 000 mm²"],
        ] },
        { k: "eg", title: "MACE notes example — classifying designs by economy and safety (Que 2)", given: "Classify the following designs on the basis of (i) economy (ii) safety: i) FOS 1.5, P = 1000 kN, σ permissible = 200, A provided = 2000 mm²; ii) FOS 2, P = 2000 kN, σ permissible = 100, A provided = 10000 mm²; iii) FOS 1.5, P = 2000 kN, σ permissible = 200, A provided = 10000 mm².", steps: [
          { t: "i)", w: "A_req = FOS · P/σ = 1.5 × (1000 × 10³)/200 = 1.5 × 5000 = 7500 mm² > A provided (2000 mm²) — unsafe" },
          { t: "ii)", w: "A_req = 2 × (2000 × 10³)/100 = 40 000 mm² > A provided (10 000 mm²) — unsafe" },
          { t: "iii)", w: "A_req = 1.5 × (2000 × 10³)/200 = 15 000 mm² > A provided (10 000 mm²) — unsafe" },
        ], ans: "All three designs (i), (ii), (iii) are unsafe. (M p.97)" },
        { k: "note", t: "<b>Check:</b> all three areas re-work correctly (7500, 40 000, 15 000 mm²). The notes treat the tabulated σ as the <i>failure</i> stress and divide by FOS. If the tabulated value were already the permissible (working) stress, FOS must not be applied again: A_req = P/σ = 5000, 20 000 and 10 000 mm², and design (iii) would then be exactly adequate. Read the question's wording before multiplying by FOS." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "FOS ek 'buffer' hai: failure stress ko FOS se divide karo to working stress milta hai, aur us stress par member design karo. Ductile material yield par hi bekaar ho jaata hai (permanent set), isliye uska failure stress = yield stress; brittle material bina yield kiye toot jaata hai, isliye ultimate stress. MOS sirf 'extra kitna' batata hai — FOS 2 ka matlab MOS 1 (100% extra)." },
        { k: "trap", t: "FOS aur MOS ko mix mat karo: MOS = FOS − 1. Aur 'permissible stress' diya ho to woh already FOS laga hua working stress hai — dobara FOS se divide/multiply karne par area double count ho jaata hai." },
        { k: "real", t: "Code-based design mein FOS ki jagah partial safety factors aate hain (limit state design), par idea wahi hai — member ki capacity load effect se kaafi upar rakhni hai. Bada FOS = mehenga section (FOS ∝ 1/economy)." },
      ],
    },

    /* ---------------------------------------------------------------- indeterminate bars Q3-Q4 */
    {
      n: "",
      title: "MACE notes — Bars fixed at both ends: support reactions (Q3, Q4)",
      hi: "दोनों सिरों पर स्थिर छड़ — प्रतिक्रियाएँ",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.97–99" },
        { k: "p", t: "Figure (M p.97, Q.3): a horizontal bar between two fixed (hatched, 'unyielding') walls A (left) and B (right); a point load P acts to the right at a section a distance a from A and b from B; total length L = constant. Free bodies: the left part (length a) in tension (+), with R_A acting outward at both its ends; the right part (length b) in compression (−), with R_B pushing inward at both its ends." },
        { k: "eg", title: "MACE notes example — reactions of a bar fixed at both ends with an intermediate load (Q.3)", given: "Consider the following bar and find out the reactions developed by the supports. [A = constant and E = constant] (bar fixed at A and B, load P at distance a from A and b from B, L = a + b)", steps: [
          { t: "Deformations", w: "ΔL = PL/AE\nΔL_A = (+R_A·a)/(AE) ; ΔL_B = (−R_B·b)/(AE)" },
          { t: "Equilibrium at supports", w: "R_A + R_B = P ... (1)   (R_A and R_B act to the left, P to the right)" },
          { t: "Compatibility", w: "L = constant ⇒ ΔL = 0, i.e. (ΔL)_A + (ΔL)_B = 0 — compatibility condition\nR_A·a/(AE) − R_B·b/(AE) = 0\nR_A = R_B(b/a) ... (2)" },
          { t: "Put (2) in (1)", w: "R_B(b/a) + R_B = P\nR_B[b/a + 1] = P\nR_B[(b + a)/a] = P\nR_B = P·a/(a + b) = P(a/L)" },
          { t: "Put R_B in (1)", w: "R_A = P − P(a/L) = P[1 − a/L] = P[(L − a)/L]\nR_A = P(b/L)" },
        ], ans: "R_A = P(b/L), R_B = P(a/L). (M p.98)" },
        { k: "list", items: [
          "<b>Conclusion:</b> a &lt; b → R_A &gt; R_B; a &gt; b → R_A &lt; R_B; a = b → R_A = R_B = P/2, if A = constant and E = constant. (M p.98)",
          "If asked for the stress induced at section x–x (in the right portion, near B): Stress = Load/Area = P(a/L)/A = <b>Pa/(A·L)</b>. Put A as per the shape given in the question ⇒ for a circular bar: <b>Stress = 4Pa/(πD²L)</b>. (M p.98)",
          "Figure (M p.98): bar between fixed walls A and B, load P at a section, section x–x (red dotted) in the right portion near B; free body of the part cut at x–x with R_B at the left face and R_B = P(a/L) at the right end.",
        ] },
        { k: "p", t: "Figure (M p.98, Que 4): bar fixed between walls A (left) and B (right); left part A₁, E₁, length L₁; right part A₂, E₂, length L₂; joint C with load P acting towards B. Free bodies: left bar (E₁, L₁, A) in tension with R_A at both ends; right bar (E₂, L₂, A) in compression with R_B at both ends." },
        { k: "eg", title: "MACE notes example — two bars of different E fixed end to end (Que 4)", given: "Two bars of equal cross-sectional area having modulus of elasticity E₁ and E₂ are connected end to end at point C, while the other ends of the bars are fixed between two points A and B. If the lengths of the bars are L₁ and L₂ respectively and a load P acts at the joint towards support B, find the support reactions at A and B.", steps: [
          { t: "Equal areas", w: "A₁ = A₂ = A" },
          { t: "Compatibility", w: "(ΔL)_A = (ΔL)_B ... (1)\nR_A·L₁/(A·E₁) = R_B·L₂/(A·E₂)\nR_A = R_B(L₂/L₁)(E₁/E₂)" },
          { t: "Equilibrium", w: "R_A + R_B = P ... (2)" },
          { t: "Solve", w: "R_B(L₂/L₁)(E₁/E₂) + R_B = P\nR_B[(L₂/L₁)·(E₁/E₂) + 1] = P\nR_B[(L₂E₁ + L₁E₂)/(L₁E₂)] = P\nR_B = P·L₁·E₂/(L₂E₁ + L₁E₁)   (as written)" },
          { t: "If L₁ = L₂", w: "R_B = P·E₂/(E₁ + E₂)" },
        ], ans: "R_B = P·L₁·E₂/(L₂E₁ + L₁E₁) (as written); R_B = P·E₂/(E₁ + E₂) if L₁ = L₂. (M p.99)" },
        { k: "note", t: "<b>Check:</b> the line just above the answer has the correct bracket (L₂E₁ + L₁E₂)/(L₁E₂), so the answer's denominator should read <b>L₂E₁ + L₁E₂</b>, not L₂E₁ + L₁E₁: <b>R_B = P·L₁E₂/(L₂E₁ + L₁E₂)</b> and R_A = P − R_B = <b>P·L₂E₁/(L₂E₁ + L₁E₂)</b>. With L₁ = L₂ this gives R_B = P·E₂/(E₁ + E₂) — the notes' last line, which is correct." },
        { k: "list", items: [
          "<b>Conclusion:</b> if A = constant and L₁ = L₂, i.e. P at mid-point, load sharing will depend upon <b>MOE</b>: E₁ &gt; E₂ ⇒ R_A &gt; R_B; E₁ &lt; E₂ ⇒ R_A &lt; R_B; E₁ = E₂ ⇒ R_A = R_B. (M p.99)",
          "If A = constant and E = constant, then P at mid-point (⇒ R_A = R_B = P/2, as in Q.3). (M p.99)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Dono ends fixed hain, to total length badal hi nahi sakti — jitna ek hissa khinchta hai utna doosra dabta hai (compatibility). Load usi taraf zyada jaata hai jo hissa zyada stiff hai, yaani AE/L bada ho: chhota hissa (Q.3) ya zyada E wala hissa (Q4). Existing §2.3 mein yahi case R_A = Pb/L se worked example 2.6 ke saath hai." },
        { k: "trap", t: "R_A = Pb/L hai, Pa/L nahi — reaction <b>door wale</b> segment ki length se banta hai (A ke paas load ho, yaani a chhota, to R_A bada). Ulta likhna sabse common galti hai." },
        { k: "real", t: "Do concrete abutments ke beech fixed steel strut, ya do floors ke beech fixed column jis par beech mein load aaye — load dono supports mein stiffness ke hisaab se batta hai, simple statics se nahi." },
      ],
    },

    /* ---------------------------------------------------------------- Q5-Q8 */
    {
      n: "",
      title: "MACE notes — Numericals: restrained Poisson's ratio, zero lateral strain, stress–strain curve and self-weight (Q5–Q8)",
      hi: "संख्यात्मक प्रश्न 5–8",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.99–101" },
        { k: "eg", title: "MACE notes example — Poisson's ratio when all lateral strain is prevented (Que 5)", given: "A bar is stretched in such a manner that all lateral strain is prevented. The modified value of Poisson's ratio in terms of the original value of μ is: (i) μ/(1 − μ) (ii) (1 − μ)/[(1 + μ)(1 + 2μ)] (iii) (1 − μ²)/[(1 + μ)(1 + μ²)] (iv) zero", steps: [
          { t: "Lateral strain prevented", w: "ε_lateral = 0\nμ = −ε_lat/ε_lin = 0" },
          { t: "Via generalised Hooke's law (y-direction strain zero)", w: "εy = σy/E − μ·σx/E − μ·σz/E   (σy/E → 0, σz/E → 0)\n0 = −μ·σx/E\nμ = 0" },
        ], ans: "μ = 0 — option (iv). (M p.99)" },
        { k: "note", t: "<b>Check (reasoning):</b> the notes' answer (iv) is the observed ratio −ε_lat/ε_lin, which is zero because ε_lat = 0. The second route, however, puts σy = σz = 0 — but lateral strain can be prevented only by lateral stresses. With εy = εz = 0 the generalised Hooke's law gives σy = σz = <b>μσx/(1 − μ)</b> (option (i) is this stress ratio). The material constant μ does not change; only the apparent ratio of lateral to linear strain becomes zero." },
        { k: "p", t: "Figure (M p.99): rectangular element with axes +y (up) and −y (down); σx acting on the left face and the right face." },
        { k: "eg", title: "MACE notes example — biaxial stresses giving zero strain in z (Que 6)", given: "A cube of side L is subjected to biaxial stresses in the x and y directions respectively. If the strain in the z-direction is zero due to the stresses in the x and y directions, find the relation between the stresses in the x and y directions: (i) σx = σy (ii) σx = −σy (iii) σx/σy = 2 (iv) σx/σy = μ", steps: [
          { t: "Condition", w: "εz = 0" },
          { t: "Generalised Hooke's law", w: "εz = σz/E − μ·σx/E − μ·σy/E   (σz not applied, so zero)\n0 = −(μ/E)(σx − σy)   (as written)" },
        ], ans: "σx = −σy — option (ii). (M p.100)" },
        { k: "note", t: "<b>Check:</b> the bracket should be (σx <b>+</b> σy): 0 = −(μ/E)(σx + σy) ⇒ σx + σy = 0 ⇒ σx = −σy. The notes' final answer (ii) is correct; only the sign inside the bracket in the intermediate line is a slip (with (σx − σy) one would get σx = σy, option (i))." },
        { k: "list", items: [
          "<b>Conclusion:</b> if the stresses in any two mutually perpendicular directions acting on a cube are <b>equal in magnitude but opposite in nature</b>, then the strain in the third mutually perpendicular direction is zero, i.e. σz = 0, σx = −σy ⇒ εz = 0. (M p.100)",
          "Figure (M p.100): square element with σy arrows up and down (top, bottom) and σx arrows left and right.",
        ] },
        { k: "p", t: "Figure (M p.100, Que 7): stress–strain curve, σ vertical and ε horizontal. A straight line from the origin to the point (ε = 0.1, σ = 30 MPa), then a straight line of smaller slope to the point (ε = 0.6, σ = 180 MPa). Dashed horizontal lines at 180 MPa, 50 MPa (red) and 30 MPa; dashed vertical lines at 0.1, ε (red) and 0.6. The height between the 30 and 180 levels is marked '180 − 30'; the horizontal gap between 0.1 and ε is marked '1/15'." },
        { k: "eg", title: "MACE notes example — elongation read from a bilinear stress–strain curve (Que 7)", given: "The stress–strain curve for a material is as given (straight line from origin to ε = 0.1 at 30 MPa, then straight line to ε = 0.6 at 180 MPa). Find the elongation of a bar made from this material if a 5 kN axial load acts over a cross-section of 100 mm² and the length of the bar is 1000 mm.", steps: [
          { t: "Data", w: "P = 5 kN = 5000 N ; A = 100 mm² ; L = 1000 mm ; ΔL = ?" },
          { t: "Why not PL/AE", w: "ΔL = PL/AE — not used because E is not given\nε = ΔL/L ⇒ ΔL = ε·L ; ε = fn(σ)" },
          { t: "Step i — stress induced", w: "σ = P/A = 5000/100 = 50 MPa" },
          { t: "Step ii — mark σ on the diagram, read strain (linear interpolation / similar triangles)", w: "30 MPa → 0.1 ; 50 MPa → ε ; 180 MPa → 0.6\n(50 − 30)/(ε − 0.1) = (180 − 30)/(0.6 − 0.1)\n20/(ε − 0.1) = 150/0.5\nε = 1/15 + 0.1" },
          { t: "Elongation", w: "ΔL = ε·L = (1/15 + 0.1) × 1000 = 1000/15 + 100 = 200/3 + 100 = 66.66 + 100" },
        ], ans: "ΔL = 166.67 mm. (M p.100–101)" },
        { k: "eg", title: "MACE notes example — self-weight elongation vs. external-load elongation (Que 8)", given: "The ratio of the total elongation of a bar of uniform cross-section produced under its own weight to the elongation produced by an external load equal to the weight of the bar is: (a) 2 (b) 1 (c) 1/2 (d) 1/4", steps: [
          { t: "P = W", w: "(ΔL)self wt / (ΔL)ext. load = (WL/2AE)/(PL/AE) = 1/2" },
        ], ans: "1/2 — option (c). (M p.101)" },
        { k: "p", t: "Figure (M p.101): a vertical bar hanging from a fixed support at the top, with a load P = weight of bar (W) at the bottom. The same question may be asked for a cone or a tapered bar — then (ΔL) under the external load changes:" },
        { k: "eg", title: "MACE notes example — elongation of a cone and of a circular tapered bar under axial load P (Que 8, continued)", given: "Same question for a cone (apex D₁ = 0, base D₂, length L) or a circular tapered bar (D₁ to D₂): find ΔL under the external load and the ratio when P = W.", steps: [
          { t: "Cone: diameter at distance x from apex", w: "k = D₂/L ; Dx = (D₂/L)·x" },
          { t: "Integrate", w: "ΔL = ∫ P·dx/(Ax·E) = (P/E) ∫ dx/[(π/4)Dx²]\n= (4P/πE) ∫ dx/[(D₂/L)·x]²\n= (4PL²/πD₂²E) ∫ x⁻² dx   (0 to L)\n= (4PL²/πD₂²E)[x^(−2+1)/(−2+1)]\n= (4PL²/πD₂²E)[L⁻¹/(−1)]" },
          { t: "Result for cone (as boxed)", w: "ΔL = 4PL/(πD²E)" },
          { t: "Circular tapered bar", w: "k = (D₂ − D₁)/L ; Dx = D₁ + kx = D₁ + [(D₂ − D₁)/L]·x\nΔL = 4PL/(πD₁D₂E)" },
          { t: "Ratio with P = W (πD²/4 = A)", w: "(ΔL)self wt/(ΔL)ext. load = (WL/2AE)/(4PL/πD²E) = (WL/2AE)/(PL/AE) = 1/2" },
        ], ans: "Cone: ΔL = 4PL/(πD²E); tapered bar: ΔL = 4PL/(πD₁D₂E); ratio = 1/2. (M p.101)" },
        { k: "note", t: "<b>Check (cone integral):</b> ∫ x⁻² dx from 0 to L = [−1/x] from 0 to L does not converge — the lower limit (the apex, where the area is zero) gives an infinite value. The notes evaluate only the upper limit and also drop the minus sign. Physically, a point load P on a cone's sharp apex gives infinite stress there, so ΔL is not finite; the tapered-bar formula 4PL/(πD₁D₂E) with D₁ → 0 shows the same. The boxed 4PL/(πD²E) is the elongation of a <i>uniform</i> bar of diameter D (D₁ = D₂ = D) — which is why the ratio still comes out 1/2. Under <i>self-weight</i> a cone's elongation is finite: γL²/6E (existing §2.2)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Que 7 ka idea: jab E na diya ho par graph diya ho, to pehle σ = P/A nikaalo, phir graph se uska strain padho. Graph do seedhi lines ka hai, to beech ka point similar triangles se milta hai — 50 MPa doosri line par hai (30 se upar), isliye 0.1 se aage interpolate kiya." },
        { k: "p", t: "Que 8: self-weight ka load bar ki length par 0 se W tak badhta hai, to average load W/2 — isliye elongation aadhi. Existing §2.2 mein ½ aur ⅓ factor ka reason diya hai." },
        { k: "trap", t: "Bilinear curve mein poore range par ek hi slope (180/0.6 ya 30/0.1) mat lagao. Pehle dekho stress kaun si line par padta hai, phir usi line se strain nikaalo. Aur 'lateral strain prevented' ka matlab material ka μ zero ho gaya — aisa nahi; sirf observed ratio zero hai." },
      ],
    },

    /* ---------------------------------------------------------------- Q9-Q12 */
    {
      n: "",
      title: "MACE notes — Numericals: volumetric strain of a cube, strain matrix and lateral strain (Q9–Q12)",
      hi: "संख्यात्मक प्रश्न 9–12",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.102–103" },
        { k: "eg", title: "MACE notes example — volumetric strain as a multiple of linear strain (Que 9)", given: "A solid cube is subjected to equal normal forces on all its faces. The volumetric strain is x times the linear strain in any of the three directions. The value of x will be: (a) one (b) two (c) three (d) four", steps: [
          { t: "Original volume", w: "V = l³" },
          { t: "Differentiate", w: "dV = 3l²·dl" },
          { t: "Divide by V", w: "dV/V = 3l²·dl/V\nε_vol = 3l²·dl/l³\nε_vol = 3ε_linear" },
        ], ans: "ε_vol = 3ε_linear ⇒ x = 3, option (c). (M p.102)" },
        { k: "p", t: "Figure (M p.102): an l × l × l cube with σy up, σx to the right and σz out of the plane. They also ask for the volumetric strain by providing the value of linear strain. (M p.102)" },
        { k: "eg", title: "MACE notes example — volumetric strain of a cube from its linear strain (Que 10)", given: "A cube of sides 0.375 × 0.375 × 0.375 is subjected to stresses on all three faces equally. If the linear strain is of the order of 0.750 × 10⁻³, which of the following is the correct volumetric strain? (a) 0.250 × 10⁻³ (b) 0.150 × 10⁻³ (c) 0.2250 (d) 2250 × 10⁻⁶", steps: [
          { t: "ε_vol = 3 × ε_linear", w: "= 3 × 0.750 × 10⁻³ = 3 × 750 × 10⁻³ × 10⁻³ = 2250 × 10⁻⁶" },
        ], ans: "ε_vol = 2250 × 10⁻⁶ — option (d). (M p.102)" },
        { k: "cmp", t: "Que 11 — strain matrix and its meaning (M p.102)", cols: ["Column 1", "Column 2", "Column 3"], rows: [
          ["Given matrix, row 1", "0.003", "0", "0"],
          ["Given matrix, row 2", "0", "0.005", "0"],
          ["Given matrix, row 3", "0", "0", "0.009"],
          ["General form, row 1", "εxx", "φxy/2", "φxz/2"],
          ["General form, row 2", "φyx/2", "εyy", "φyz/2"],
          ["General form, row 3", "φzx/2", "φzy/2", "εzz"],
        ] },
        { k: "eg", title: "MACE notes example — unit volume change from a strain matrix (Que 11)", given: "A strain matrix for an elastic material is shown (diagonal 0.003, 0.005, 0.009; all off-diagonal terms 0). If Poisson's ratio is 0.25, the magnitude of unit volume change of the material is given by: (a) 0.017 (b) 0.010 (c) 0.020 (d) 0", steps: [
          { t: "ε_vol = εx + εy + εz", w: "= 0.003 + 0.005 + 0.009\n= (3 + 5 + 9) × 10⁻³ = 17 × 10⁻³" },
        ], ans: "ε_vol = 0.017 — option (a). (M p.102)" },
        { k: "note", t: "The diagonal terms are already strains, so μ = 0.25 is not needed (it is a distractor); μ would be needed only if <i>stresses</i> were given. Off-diagonal (shear) terms do not change volume." },
        { k: "eg", title: "MACE notes example — lateral strain of a bar under axial load (Que 12)", given: "A bar is subjected to an axial load of 50 kN. If the cross-sectional area of the bar is 1000 mm² and the length of the bar is 1000 mm, what is the strain in the y-direction, if the modulus of elasticity is 200 GPa and Poisson's ratio is 1/4?", steps: [
          { t: "Data", w: "P = 50 kN = 50 × 10³ N ; A = 1000 mm² ; L = 1000 mm ; E = 200 GPa = 200 × 10³ MPa ; μ = 1/4" },
          { t: "Generalised Hooke's law", w: "εy = σy/E − μ·σx/E − μ·σz/E   (σy = σz = 0)\nεy = −μ·σx/E = −μP/(AE)" },
          { t: "Substitute", w: "= −[(1/4) × (50 × 10³)/(1000 × 200 × 10³)] = (1/16) × 10⁻³" },
        ], ans: "εy = 0.0625 × 10⁻³ (as written). (M p.103)" },
        { k: "note", t: "<b>Check:</b> σx = 50 000/1000 = 50 N/mm²; εy = −(1/4)(50/200 000) = <b>−0.0625 × 10⁻³</b> = −62.5 × 10⁻⁶. The magnitude in the notes is right but the minus sign written in the working is dropped in the answer — the y-strain is a <b>contraction</b> because the bar is in tension." },
        { k: "p", t: "Figure (M p.103): a rectangular bar with 50 kN pulling at the left end and 50 kN (50 × 10³ N) pulling at the right end." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Strain matrix mein diagonal = normal strains, off-diagonal = aadha shear strain (φ/2). Volume sirf diagonal se badalta hai, isliye ε_vol = trace = εx + εy + εz. Cube par barabar stress ho to teeno strains same, isliye ε_vol = 3ε." },
        { k: "trap", t: "Lateral strain ka sign mat chhodo — tension mein εy negative hai. MCQ mein options agar magnitude mein hon to 0.0625 × 10⁻³ choose karo, par working mein minus likhna zaroori hai. Aur strain matrix wale sawaal mein diya hua μ har baar use karna zaroori nahi." },
      ],
    },

    /* ---------------------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Elastic constants, Poisson's ratio, generalised Hooke's law and FOS (M p.83–103)",
      hi: "पुनरावृत्ति — प्रत्यास्थ स्थिरांक",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and definitions" },
        { k: "list", items: [
          "✅ Elastic constants show the stress–strain relationship: E (normal stress), G (shear), K (hydrostatic), μ (linear vs lateral strain). (M p.83)",
          "✅ Final length = L(1 + ε); σ/ε = E (within proportionality limit). (M p.83)",
          "✅ E = stress for unit strain (ΔL = L, length doubles) — a stiffness property; E = slope of σ–ε curve at origin; unit N/mm², dimension [M¹ L⁻¹ T⁻²]. (M p.84)",
          "✅ IS 456-2000: E of steel = 200 kN/mm². (M p.84)",
          "✅ τ/φ = G; G = ∞ ideal rigid; G = 0 fluid at rest; φ = 2 × linear strain. (M p.84)",
          "✅ G: diamond 478, steel 79.3, iron 52.5, copper 44.7, glass 26.2, aluminium 25.5, rubber 0.0006 GPa, fluid 0. G of metals ↓ as T ↑. (M p.85)",
          "✅ K = σ_direct/ε_vol; compressibility β ∝ 1/K. K: glass 35–55, steel 160, diamond 443, water 2.2 GPa. (M p.86)",
          "✅ ε_vol = ΔV/V = εx + εy + εz (products of strains neglected). (M p.87)",
          "✅ Sphere under pressure P: ε_vol = 3(dr/r); dr/r = P/(3K). (M p.88)",
          "✅ μ = −ε_lateral/ε_linear; engineering range 0–0.5, universal range −1 to 0.5, maximum 0.5; μ −ve ⇒ auxetic material. (M p.89)",
          "✅ μ: cork 0, concrete 0.15, rubber 0.4999 ≈ 0.5, ideal plastic 0.5, perfectly rigid 0, non-dilatant 0.5, copper 0.33, cast iron 0.23, metals 0.25–0.42. (M p.89)",
          "✅ εy = −μ·εx; notes' ε_vol = εx(1 − μ) (2-D); for a 3-D bar ε_vol = εx(1 − 2μ). (M p.90, p.94)",
          "✅ E = 2G(1 + μ); E = 3K(1 − 2μ); E = 9KG/(3K + G); μ = (3K − 2G)/(6K + 2G) — with the four Hindi/Marathi memory tricks. (M p.90)",
          "✅ Hooke's law assumes linear elastic, isotropic, homogeneous material. Isotropy = rotational invariance; homogeneity = translational invariance. (M p.90–91)",
          "✅ Hyperelastic (Green elastic, e.g. rubber): non-linear elastic, isotropic, incompressible, via strain-energy density function. Orthotropic (e.g. wood): 3 planes of symmetry. Transversely isotropic: one axis of symmetry. (M p.91)",
          "✅ Independent elastic constants: 81 → 36 → 21 (hyperelastic/anisotropic) → 13 monoclinic → 9 orthotropic → 5 transversely isotropic → 2 homogeneous isotropic. (M p.92)",
          "✅ E = G ⇒ μ = −0.5 (auxetic); E = K ⇒ μ = 1/3; K = G ⇒ μ = 0.125 and E = 2.25K. (M p.92–93)",
          "✅ Tension test: μ = (δd/d)/(δl/l) = 0.2 for the notes' bar; sphere 7500 mm³ at 200 MPa with K = 10⁵ N/mm² ⇒ ΔV = 15 mm³. (M p.93)",
          "✅ E/K &gt; 1/3 for most metals; μ is constant in the elastic zone, called contraction ratio beyond it. (M p.94)",
          "✅ Generalised Hooke's law: εx = σx/E − μσy/E − μσz/E (and cyclic); ε_vol = [(σx + σy + σz)/E](1 − 2μ); μ = 0.5 ⇒ ε_vol = 0 (non-dilatant). (M p.94–95)",
          "✅ Hydrostatic: E = 3K(1 − 2μ). Sphere: ε_vol = 3ε_diametral; cylinder: ε_vol = ε_L + 2ε_D; cube: ε_vol = 3ε_linear. (M p.95, p.102)",
          "✅ FOS = failure stress/working stress; ductile → yield stress, brittle → ultimate stress; FOS ∝ 1/economy ∝ safety; A_req = FOS·P/σ. (M p.96)",
          "✅ MOS = FOS − 1. Column 1500 kN, σf = 200 MPa, FOS 2 ⇒ side ≈ 125 mm (122.5 mm exact). (M p.96–97)",
          "✅ Bar fixed at both ends, load P at a from A, b from B: R_A = Pb/L, R_B = Pa/L; stress in B-part = Pa/(AL), circular 4Pa/(πD²L). (M p.98)",
          "✅ Two bars E₁, E₂, L₁, L₂ fixed end to end, P at joint: R_B = P·L₁E₂/(L₂E₁ + L₁E₂); L₁ = L₂ ⇒ R_B = P·E₂/(E₁ + E₂). (M p.99)",
          "✅ Lateral strain prevented ⇒ observed μ = 0 (option iv). (M p.99)",
          "✅ εz = 0 under biaxial stress ⇒ σx = −σy. (M p.100)",
          "✅ Bilinear σ–ε curve (0.1, 30 MPa), (0.6, 180 MPa): at 50 MPa, ε = 1/15 + 0.1 ⇒ ΔL = 166.67 mm for L = 1000 mm. (M p.100–101)",
          "✅ Self-weight elongation / elongation under external load W = 1/2; tapered bar ΔL = 4PL/(πD₁D₂E). (M p.101)",
          "✅ Strain matrix: diagonal = εxx, εyy, εzz; off-diagonal = φ/2; ε_vol = 0.003 + 0.005 + 0.009 = 0.017. (M p.102)",
          "✅ Bar 50 kN, A = 1000 mm², E = 200 GPa, μ = 1/4: εy = −0.0625 × 10⁻³. (M p.103)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
