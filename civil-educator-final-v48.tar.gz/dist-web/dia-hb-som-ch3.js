/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 3.
   Conventions as in dia-hb-som-ch1.js. The T-section and the
   SFD/BMD are drawn to scale for Worked examples 3.1 and 3.4.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 3.2  T-SECTION */
  "hb-som-tsec": {
    label: "T-section of Worked example 3.1 — centroid and neutral axis (to scale)",
    svg: `<svg viewBox="0 0 640 340" role="img" aria-label="A T-section drawn to scale: a flange 150 millimetres wide and 20 deep on top of a web 20 wide and 180 deep, total depth 200. The centroid G lies on the vertical axis of symmetry, 135.45 millimetres above the bottom of the web and 64.55 below the top of the flange; a dashed horizontal line through G marks the centroidal x-axis, which is the neutral axis in bending. The centroids of the flange, at 190 from the bottom, and of the web, at 90 from the bottom, are marked with small dots.">
      ${somMk("sm6")}
      <rect class="conc" x="215" y="30" width="210" height="28"/>
      <rect class="conc" x="306" y="58" width="28" height="252"/>
      <line class="ac" x1="170" y1="120.4" x2="470" y2="120.4" style="stroke-dasharray:8 5"/>
      <text class="ea" x="476" y="124">x–x (NA)</text>
      <circle class="hif" cx="320" cy="120.4" r="5"/><text class="em" x="296" y="116" text-anchor="end">G</text>
      <circle class="steel" cx="320" cy="44" r="3"/><text class="lb" x="436" y="76">flange: y = 190</text>
      <circle class="steel" cx="320" cy="184" r="3"/><text class="lb" x="342" y="188">web: y = 90</text>
      <line class="dash" x1="320" y1="20" x2="320" y2="322"/>
      <!-- dimensions -->
      <line class="thin" x1="215" y1="20" x2="425" y2="20"/><text class="lb" x="320" y="15" text-anchor="middle">150</text>
      <line class="thin" x1="500" y1="30" x2="500" y2="58"/><text class="lb" x="506" y="48">20</text>
      <line class="thin" x1="306" y1="322" x2="334" y2="322"/><text class="lb" x="320" y="336" text-anchor="middle">20</text>
      <line class="thin" x1="140" y1="30" x2="140" y2="310"/><text class="lb" x="134" y="175" text-anchor="end">200</text>
      <line class="thin" x1="250" y1="120.4" x2="250" y2="310" marker-start="url(#sm6-a)" marker-end="url(#sm6-a)"/>
      <text class="em" x="246" y="220" text-anchor="end">ȳ = 135.45</text>
      <line class="thin" x1="270" y1="30" x2="270" y2="120.4" marker-start="url(#sm6-a)" marker-end="url(#sm6-a)"/>
      <text class="lb" x="266" y="90" text-anchor="end">64.55</text>
      <line class="thin" x1="130" y1="310" x2="306" y2="310"/>
    </svg>`,
    caption: "Worked example 3.1 to scale (mm). The centroid sits well up in the web, closer to the wide flange; the dashed centroidal axis is the neutral axis used in Chapter 4.",
  },

  /* ---------------------------------------- 3.3  PARABOLIC REGIONS */
  "hb-som-parab": {
    label: "Parabolic segment and parabolic spandrel in one b × h rectangle",
    svg: `<svg viewBox="0 0 640 320" role="img" aria-label="A rectangle b wide and h high. A parabola starts at its vertex O at the bottom-left corner, flat there, and curves up to the top-right corner. The region below the curve is the parabolic spandrel, area one third b h, with its centroid 3b over 4 from O, which is b over 4 from the right side, and 3h over 10 above the base. The region above the curve is the parabolic segment, area two thirds b h, with its centroid 3b over 8 from the left side, which is the parabola's axis, and 3h over 5 above the base, which is 2h over 5 below the top.">
      <rect class="thin" x="170" y="60" width="300" height="200"/>
      <path class="softa" d="M170 60 L170 260 L185.0 259.5 L200.0 258.0 L215.0 255.5 L230.0 252.0 L245.0 247.5 L260.0 242.0 L275.0 235.5 L290.0 228.0 L305.0 219.5 L320.0 210.0 L335.0 199.5 L350.0 188.0 L365.0 175.5 L380.0 162.0 L395.0 147.5 L410.0 132.0 L425.0 115.5 L440.0 98.0 L455.0 79.5 L470.0 60.0 Z"/>
      <path class="soft" d="M170 260 L185.0 259.5 L200.0 258.0 L215.0 255.5 L230.0 252.0 L245.0 247.5 L260.0 242.0 L275.0 235.5 L290.0 228.0 L305.0 219.5 L320.0 210.0 L335.0 199.5 L350.0 188.0 L365.0 175.5 L380.0 162.0 L395.0 147.5 L410.0 132.0 L425.0 115.5 L440.0 98.0 L455.0 79.5 L470.0 60.0 L470 260 Z"/>
      <path class="hi" d="M170.0 260.0 L185.0 259.5 L200.0 258.0 L215.0 255.5 L230.0 252.0 L245.0 247.5 L260.0 242.0 L275.0 235.5 L290.0 228.0 L305.0 219.5 L320.0 210.0 L335.0 199.5 L350.0 188.0 L365.0 175.5 L380.0 162.0 L395.0 147.5 L410.0 132.0 L425.0 115.5 L440.0 98.0 L455.0 79.5 L470.0 60.0"/>
      <text x="160" y="276" text-anchor="end">O (vertex)</text>
      <circle class="acf" cx="282.5" cy="140" r="5"/>
      <text class="ea" x="200" y="100">Segment  A = ⅔bh</text>
      <text class="lb" x="200" y="116">(3b/8 from left, 3h/5 above base)</text>
      <circle class="hif" cx="395" cy="200" r="5"/>
      <text class="em" x="420" y="236" text-anchor="middle">Spandrel A = ⅓bh</text>
      <text class="lb" x="500" y="196">(b/4 from right,</text>
      <text class="lb" x="500" y="212">3h/10 above base)</text>
      <line class="thin" x1="170" y1="292" x2="470" y2="292"/><text class="lb" x="320" y="308" text-anchor="middle">b</text>
      <line class="thin" x1="490" y1="60" x2="490" y2="260"/><text class="lb" x="496" y="160">h</text>
      <text class="lb" x="40" y="40">Parabola y = h(x/b)², vertex O at bottom-left</text>
    </svg>`,
    caption: "The two regions fill the rectangle (⅓ + ⅔ = 1). Every centroid distance is quoted from a named edge — mixing up the reference edge is the usual source of 'wrong' answers.",
  },

  /* ---------------------------------------- 3.4  SFD / BMD */
  "hb-som-sfbm": {
    label: "Overhanging beam of Worked example 3.4 — loading, SFD and BMD (to scale)",
    svg: `<svg viewBox="0 0 640 480" role="img" aria-label="Top: a beam on a pin support A and roller B 6 metres apart with a 2 metre overhang BC; 10 kilonewtons per metre acts on AB and a 20 kilonewton point load at the free end C. Reactions are 23.33 up at A and 56.67 up at B. Middle, the shear force diagram: plus 23.33 at A falling linearly to minus 36.67 just left of B, crossing zero 2.33 metres from A; it jumps up by 56.67 to plus 20 at B, stays at 20 along the overhang, and drops to zero at C. Bottom, the bending moment diagram: a parabola from zero at A rising to a sagging maximum of 27.22 kilonewton metres at 2.33 metres, crossing zero at the point of contraflexure 4.67 metres from A, reaching minus 40 hogging at B, then a straight line back to zero at C.">
      ${somMk("sm7")}
      <!-- loading -->
      <line class="s" x1="70" y1="100" x2="550" y2="100" style="stroke-width:4"/>
      ${[0,1,2,3,4,5,6,7,8,9,10,11,12].map(i=>`<line class="hi" x1="${70+i*30}" y1="62" x2="${70+i*30}" y2="96" marker-end="url(#sm7-m)"/>`).join("")}
      <line class="hi" x1="70" y1="62" x2="430" y2="62"/>
      <text class="em" x="250" y="54" text-anchor="middle">10 kN/m</text>
      <line class="ac" x1="550" y1="40" x2="550" y2="96" marker-end="url(#sm7-c)"/>
      <text class="ea" x="558" y="50">20 kN</text>
      <path class="s" d="M70 102 L60 120 L80 120 Z"/><circle class="s" cx="430" cy="110" r="8"/><line class="s" x1="418" y1="120" x2="442" y2="120"/>
      <text x="70" y="136" text-anchor="middle">A</text><text x="430" y="136" text-anchor="middle">B</text><text x="550" y="120" text-anchor="middle">C</text>
      <text class="lb" x="70" y="150" text-anchor="middle">R=23.33</text><text class="lb" x="430" y="150" text-anchor="middle">R=56.67</text>
      <text class="lb" x="250" y="136" text-anchor="middle">6 m</text><text class="lb" x="490" y="136" text-anchor="middle">2 m</text>

      <!-- SFD baseline y=210, 2 px per kN -->
      <text x="16" y="214">SFD</text>
      <line class="thin" x1="70" y1="210" x2="550" y2="210"/>
      <path class="soft-b" d="M70 210 L70 163.3 L210 210 Z"/>
      <path class="soft-b" d="M210 210 L430 283.3 L430 210 Z"/>
      <path class="soft-b" d="M430 210 L430 170 L550 170 L550 210 Z"/>
      <text class="em" x="96" y="182">+23.33</text>
      <text class="em" x="426" y="300" text-anchor="end">−36.67</text>
      <text class="em" x="490" y="164" text-anchor="middle">+20</text>
      <text class="lb" x="216" y="200">x = 2.33 m (V = 0)</text>

      <!-- BMD baseline y=380, 2 px per kNm, sagging plotted above -->
      <text x="16" y="384">BMD</text>
      <line class="thin" x1="70" y1="380" x2="550" y2="380"/>
      <path class="soft-b" d="M70.0 380.0 L88.0 366.9 L106.0 355.6 L124.0 346.1 L142.0 338.4 L160.0 332.5 L178.0 328.4 L196.0 326.1 L214.0 325.6 L232.0 326.9 L250.0 330.0 L268.0 334.9 L286.0 341.6 L304.0 350.1 L322.0 360.4 L340.0 372.5 L358.0 386.4 L376.0 402.1 L394.0 419.6 L412.0 438.9 L430.0 460.0 L550 380 Z"/>
      <text class="em" x="210" y="318" text-anchor="middle">+27.22 (sagging)</text>
      <text class="em" x="436" y="472">−40 (hogging)</text>
      <circle class="acf" cx="350" cy="380" r="4.5"/>
      <text class="ea" x="350" y="368" text-anchor="middle">contraflexure 4.67 m</text>
      <line class="dash" x1="210" y1="210" x2="210" y2="325"/>
    </svg>`,
    caption: "Worked example 3.4 to scale. Read the rules off the picture: UDL → sloping SFD and parabolic BMD; no load → flat SFD and straight BMD; a point load or reaction → a jump in the SFD; maximum sagging moment where the SFD crosses zero.",
  },
});
