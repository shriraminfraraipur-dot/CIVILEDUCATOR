/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: EARTHQUAKE ENGINEERING handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   Design flow follows IS 1893 and IS 13920 — named as IS.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.1 INERTIA FORCE */
  "hb-eq-inertia": {
    label: "Where the earthquake force comes from",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A building on ground that jerks sideways, while the mass of the building tries to stay put through inertia, so the columns are forced to bend and a horizontal inertia force equal to mass times acceleration acts at each floor, largest at the top.">
      ${hbmk("in2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE GROUND MOVES — THE BUILDING'S MASS WANTS TO STAY</text>
      <line class="s" x1="80" y1="240" x2="320" y2="240"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="thin" x1="${100+i*36}" y1="240" x2="${90+i*36}" y2="252"/>`).join("")}
      <g class="an-sway" style="--amp:20;--dur:4s">
        ${[210,168,126,84].map((y,i)=>`<rect class="conc" x="140" y="${y}" width="120" height="12"/>
          <line class="ac" x1="260" y1="${y+6}" x2="${300+i*10}" y2="${y+6}" marker-end="url(#in2-c)"/>
          <text class="ea" x="${306+i*10}" y="${y+10}">F${i+1}</text>`).join("")}
        <line class="s" x1="150" y1="84" x2="150" y2="222"/>
        <line class="s" x1="250" y1="84" x2="250" y2="222"/>
      </g>
      <text class="lb" x="200" y="272" text-anchor="middle">the taller the floor, the larger its sway and its force</text>

      <line class="gl" x1="410" y1="56" x2="410" y2="286"/>
      <text class="em" x="428" y="84">the force is INERTIA, not wind:</text>
      <text class="lb" x="428" y="110">the ground accelerates sideways;</text>
      <text class="lb" x="428" y="128">the building's mass resists moving</text>
      <text class="ea" x="428" y="158">F = mass × acceleration</text>
      <text class="lb" x="428" y="182">so a HEAVIER building attracts MORE</text>
      <text class="lb" x="428" y="200">force — the opposite of every other load</text>
      <text class="em" x="428" y="232">two consequences that shape design:</text>
      <text class="lb" x="428" y="254">1. lighter is safer in a quake</text>
      <text class="lb" x="428" y="272">2. the force grows with height</text>
    </svg>`,
    caption: "An earthquake does not push a building — it shakes the ground out from under it. The building's mass, through inertia, tries to stay where it was, so the columns are dragged sideways and bent. The force is therefore mass times acceleration, which flips the usual intuition on its head: <strong>a heavier building attracts a larger earthquake force</strong>, not a smaller margin. This is why seismic design prizes lightness, and why the force is largest at the top, where the sway is greatest.",
  },

  /* ------------------------------------------- 2.1 PHILOSOPHY */
  "hb-eq-philosophy": {
    label: "The three-level design philosophy",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="The seismic design philosophy shown as three levels of earthquake: a minor frequent quake causing no damage, a moderate quake causing repairable damage, and a major rare quake where the building may be damaged badly but must not collapse so that lives are saved.">
      ${hbmk("ph2")}
      <text class="em" x="350" y="24" text-anchor="middle">WE DO NOT DESIGN FOR NO DAMAGE — WE DESIGN FOR NO COLLAPSE</text>
      ${[["MINOR quake", 130, "frequent", "NO damage", "structure stays elastic", "soft"],
         ["MODERATE quake", 350, "occasional", "REPAIRABLE damage", "some cracking, no danger", "softa"],
         ["MAJOR quake", 570, "rare, severe", "may be badly damaged", "but MUST NOT COLLAPSE", "soft-b"]]
        .map(([t, x, freq, dmg, note, c]) => `
        <rect class="${c}" x="${x - 92}" y="60" width="184" height="30"/>
        <text class="em" x="${x}" y="80" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="112" text-anchor="middle">${freq}</text>
        <text class="ea" x="${x}" y="150" text-anchor="middle">${dmg}</text>
        <text class="lb" x="${x}" y="178" text-anchor="middle">${note}</text>`).join("")}
      <text class="em" x="350" y="222" text-anchor="middle">the goal in the big one is LIFE SAFETY, not an undamaged building</text>
      <text class="lb" x="350" y="250" text-anchor="middle">a building that cracks and sways but lets everyone walk out has SUCCEEDED — only collapse is failure</text>
      <text class="lb" x="350" y="272" text-anchor="middle">surviving the rare great quake undamaged would be absurdly expensive — so we do not try</text>
    </svg>`,
    caption: "Seismic design accepts damage on purpose. To keep a building perfectly undamaged in the rare great earthquake would cost many times what the building is worth, so the code sets a graded target: no damage in the small, frequent quakes; repairable damage in the moderate ones; and in the rare severe quake, the building may be wrecked but <strong>must not collapse</strong>, so that everyone inside gets out alive. Understanding this is the key to the whole subject — the aim is life safety, and a cracked, standing building is a success, not a failure.",
  },

  /* ------------------------------------------- 3.1 BASE SHEAR */
  "hb-eq-baseshear": {
    label: "The design base shear, factor by factor",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="The design base shear formula broken into its factors: the total horizontal force equals the seismic coefficient times the seismic weight, and the coefficient is built from the zone factor, importance factor, response reduction factor and the spectral acceleration read from the building's natural period.">
      ${hbmk("bs3")}
      <text class="em" x="350" y="24" text-anchor="middle">THE DESIGN FORCE, BUILT FROM FIVE HONEST FACTORS</text>
      <rect class="soft-b" x="200" y="52" width="300" height="40"/>
      <text class="em" x="350" y="78" text-anchor="middle">Vb = Ah × W</text>
      <text class="lb" x="350" y="112" text-anchor="middle">total base shear = seismic coefficient Ah × seismic weight W</text>
      <rect class="conc" x="150" y="130" width="400" height="40"/>
      <text class="em" x="350" y="156" text-anchor="middle">Ah = (Z/2) × (I/R) × (Sa/g)</text>
      ${[["Z", "zone factor — how severe the local hazard", 150],
         ["I", "importance — hospitals & schools weigh more", 300],
         ["R", "response reduction — reward for ductility (÷)", 470],
         ["Sa/g", "spectral accn — from the period T & soil", 610]]
        .map(([f, d, x], i) => `
        <text class="ea" x="${x}" y="200" text-anchor="middle">${f}</text>
        <line class="thin" x1="${x}" y1="170" x2="${x}" y2="188"/>`).join("")}
      <text class="lb" x="120" y="224">Z — bigger in high-seismic zones (IV, V)</text>
      <text class="lb" x="120" y="244">I — 1.0 ordinary, 1.5 important (hospital)</text>
      <text class="lb" x="120" y="264">R — HIGHER for ductile frames → smaller force (it divides)</text>
      <text class="lb" x="120" y="284">Sa/g — read off the design spectrum at the building's period T</text>
    </svg>`,
    caption: "The design base shear looks intimidating but every factor is a plain-language question. How severe is the local hazard (Z)? How important is this building (I)? How ductile — how well can it bend without breaking — is the structure (R, which divides, so ductility earns a smaller force)? And how does the ground shake at this building's natural rhythm (Sa/g, read from the period)? <strong>Multiply the answers to get the coefficient, multiply by the weight, and you have the force.</strong> Nothing in it is invented; each factor comes from the code by a stated rule.",
  },

  /* ------------------------------------------- 6.1 STRONG COL WEAK BEAM */
  "hb-eq-scwb": {
    label: "Strong column, weak beam — choosing where it breaks",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two framed buildings under earthquake. In one the columns hinge and the whole storey collapses. In the other the beams hinge first, at their ends, and the building sways but stands, illustrating the capacity design rule that columns must be stronger than the beams framing into them.">
      ${hbmk("sc")}
      <text class="em" x="350" y="24" text-anchor="middle">YOU CHOOSE WHERE THE DAMAGE HAPPENS — CHOOSE THE BEAMS</text>
      <text class="em" x="170" y="56" text-anchor="middle">WEAK COLUMN — collapse</text>
      ${[0,1].map(c=>`<line class="s" x1="${110+c*120}" y1="72" x2="${110+c*120}" y2="220"/>`).join("")}
      ${[90,150].map(y=>`<rect class="conc" x="104" y="${y}" width="132" height="10"/>`).join("")}
      <circle class="acf" cx="110" cy="210" r="7"/><circle class="acf" cx="230" cy="210" r="7"/>
      <path class="hi" d="M110 220 L96 240 M230 220 L244 240"/>
      <text class="lb" x="170" y="264" text-anchor="middle">columns hinge at the base —</text>
      <text class="lb" x="170" y="282" text-anchor="middle">the whole storey folds & drops</text>

      <text class="em" x="520" y="56" text-anchor="middle">STRONG COLUMN — survives</text>
      ${[0,1].map(c=>`<line class="s" x1="${460+c*120}" y1="72" x2="${460+c*120}" y2="220"/>`).join("")}
      ${[90,150].map(y=>`<rect class="conc" x="454" y="${y}" width="132" height="10"/>`).join("")}
      ${[95,155].map(y=>[470,576].map(x=>`<circle class="hif" cx="${x}" cy="${y}" r="6"/>`).join("")).join("")}
      <text class="lb" x="520" y="264" text-anchor="middle">BEAMS hinge at their ends —</text>
      <text class="lb" x="520" y="282" text-anchor="middle">it sways, cracks, but stays up</text>

      <line class="gl" x1="350" y1="66" x2="350" y2="248"/>
      <text class="ea" x="350" y="130" text-anchor="middle">the rule:</text>
      <text class="lb" x="350" y="152" text-anchor="middle">make columns</text>
      <text class="lb" x="350" y="170" text-anchor="middle">STRONGER than</text>
      <text class="lb" x="350" y="188" text-anchor="middle">the beams into them</text>
      <text class="lb" x="350" y="214" text-anchor="middle">(capacity design)</text>
    </svg>`,
    caption: "A framed building will hinge and yield somewhere in a big quake — the engineer's job is to choose where. If a column hinges, the storey above loses its support and the building can pancake; if the beams hinge instead, the frame sags and cracks at the beam ends but keeps standing. So the rule (IS 13920's capacity design) is to deliberately make the columns stronger than the beams framing into them — <strong>strong column, weak beam</strong> — forcing the damage into the beams, where it is survivable and repairable. You cannot stop the yielding; you can only steer it.",
  },

  /* ------------------------------------------- 7.1 DUCTILE DETAILING */
  "hb-eq-ductile": {
    label: "Ductile detailing — closely spaced ties at the ends",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A beam and column showing that near the joints, where hinges form, the stirrups and ties are spaced much more closely than in the middle, confining the concrete so it can deform without bursting, which is what gives the member its ductility.">
      ${hbmk("du")}
      <text class="em" x="350" y="24" text-anchor="middle">CLOSE THE TIES WHERE THE HINGE WILL FORM</text>
      <rect class="conc" x="90" y="110" width="420" height="60"/>
      <text class="lb" x="300" y="100" text-anchor="middle">beam</text>
      ${[0,1,2,3,4,5].map(i=>`<line class="hi" x1="${104+i*8}" y1="112" x2="${104+i*8}" y2="168"/>`).join("")}
      ${[0,1,2,3,4,5].map(i=>`<line class="hi" x1="${408+i*16}" y1="112" x2="${408+i*16}" y2="168"/>`).join("")}
      ${[0,1,2,3].map(i=>`<line class="thin" x1="${190+i*60}" y1="112" x2="${190+i*60}" y2="168"/>`).join("")}
      <line class="ac" x1="104" y1="184" x2="150" y2="184" marker-end="url(#du-c)" marker-start="url(#du-c)"/>
      <text class="ea" x="127" y="200" text-anchor="middle">close ties</text>
      <text class="lb" x="127" y="216" text-anchor="middle">(confining zone)</text>
      <line class="ac" x1="210" y1="184" x2="330" y2="184" marker-end="url(#du-c)" marker-start="url(#du-c)"/>
      <text class="lb" x="270" y="200" text-anchor="middle">wider spacing (low stress mid-span)</text>
      <text class="lb" x="470" y="200" text-anchor="middle">close ties again at the far joint</text>

      <line class="gl" x1="90" y1="234" x2="510" y2="234"/>
      <text class="em" x="300" y="258" text-anchor="middle">the close ties CONFINE the concrete so it can bend without bursting</text>
      <text class="lb" x="300" y="280" text-anchor="middle">confinement turns a brittle member ductile — the R factor is EARNED here, on the drawing</text>
    </svg>`,
    caption: "Ductility is not a property the concrete has — it is a property the detailing gives it. Where a hinge will form (the ends of beams and columns, near the joints), the stirrups and ties are packed much more closely together. These close ties confine the core concrete, holding it together so it can deform and absorb energy instead of crushing and bursting apart. <strong>The response reduction factor R that shrank the design force in the base-shear formula is a promise, and this detailing is where that promise is kept</strong> — a frame designed for a low force but not detailed for ductility is a lie waiting for an earthquake.",
  },

  /* ------------------------------------------- 4.1 SOFT STOREY */
  "hb-eq-softstorey": {
    label: "The soft storey — a killer irregularity",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A building with solid infill walls in the upper storeys but an open ground storey for parking, showing that the open storey is far more flexible so all the earthquake deformation concentrates there and the columns fail, a common cause of collapse.">
      ${hbmk("ss")}
      <text class="em" x="350" y="24" text-anchor="middle">THE OPEN GROUND STOREY — WHY SO MANY BUILDINGS FALL</text>
      <rect class="softa" x="150" y="60" width="200" height="120"/>
      ${[80,110,140].map(y=>`<line class="thin" x1="150" y1="${y}" x2="350" y2="${y}"/>`).join("")}
      <text class="lb" x="250" y="128" text-anchor="middle">stiff — walls fill the frame</text>
      <line class="s" x1="150" y1="180" x2="150" y2="240"/>
      <line class="s" x1="350" y1="180" x2="350" y2="240"/>
      <line class="s" x1="250" y1="180" x2="250" y2="240"/>
      <rect class="conc" x="150" y="180" width="200" height="8"/>
      <text class="lb" x="250" y="216" text-anchor="middle">OPEN — parking, no walls</text>
      <text class="ea" x="250" y="256" text-anchor="middle">all the flex is HERE</text>
      <path class="hi" d="M150 240 Q170 210 150 188 M250 240 Q270 210 250 188 M350 240 Q370 210 350 188"/>

      <line class="gl" x1="410" y1="56" x2="410" y2="280"/>
      <text class="em" x="428" y="84">the trap:</text>
      <text class="lb" x="428" y="110">the walls above stiffen those storeys,</text>
      <text class="lb" x="428" y="128">so they barely deform</text>
      <text class="lb" x="428" y="150">the open storey has only columns —</text>
      <text class="lb" x="428" y="168">far more flexible</text>
      <text class="ea" x="428" y="198">so ALL the sway concentrates in</text>
      <text class="lb" x="428" y="216">the one open storey, and its columns</text>
      <text class="lb" x="428" y="234">take deformation they can't survive</text>
      <text class="lb" x="428" y="264">common with stilt parking —</text>
      <text class="lb" x="428" y="282">the code demands extra strength there</text>
    </svg>`,
    caption: "The open ground storey — stilt parking under an otherwise wall-filled building — is one of the deadliest configurations there is, and it is everywhere. The infill walls above stiffen the upper storeys so they hardly deform; the open storey has only its bare columns, so it is far more flexible, and all of the building's earthquake sway concentrates in that single soft storey. Its columns are asked to absorb the whole movement and they fail. <strong>The building drops straight down onto the parked cars.</strong> The code recognises this and demands the open storey be specially strengthened.",
  },

});
