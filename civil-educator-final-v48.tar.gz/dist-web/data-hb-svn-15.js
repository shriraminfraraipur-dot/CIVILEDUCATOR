/* Surveying class notes — Areas and Volumes, notes p.196–204 — inserted into sv chapter 10 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 10; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- p.196 */
    {
      n: "",
      title: "Notes — area of a tract: mid-ordinate and average-ordinate rules",
      hi: "मध्य-कोटि और औसत-कोटि नियम",
      blocks: [
        { k: "h", t: "📘 Notes — p.196" },
        { k: "h", t: "Area & Volume Measurement" },
        { k: "p", t: "The method selected for computation of area depends upon the <b>shape of the tract</b> &amp; the <b>accuracy desired</b>. (p.196)" },
        { k: "h", t: "Area of tract with approximate methods" },
        { k: "p", t: "Figure (p.196): an irregular strip — straight base line at the bottom, wavy curved boundary at the top — divided by vertical ordinates into <b>n equal strips of width d</b>. The ordinates at the strip boundaries are labelled O₁ (left end), O₂, O₃, O₄, …, Oₙ, Oₙ₊₁ (right end). The mid-ordinate of each strip (measured at the middle of the strip, from base to curve) is labelled h₁, h₂, h₃, …, hₙ. Strip width d is marked under the first strip; total length along the base <b>L = nd</b>. Note beside the figure: <b>(n+1) ordinates</b>. (p.196)" },
        { k: "h", t: "(1) Mid-ordinate rule" },
        { k: "p", t: "Area = average ordinate × length (p.196)" },
        { k: "eq", expr: "A = [ (h₁ + h₂ + h₃ + … + hₙ) / n ] × L", where: [
          ["h₁ … hₙ", "mid-ordinates of the n strips"],
          ["n", "number of strips"],
          ["L", "length of base line = nd"],
        ] },
        { k: "h", t: "(2) Average-ordinate rule" },
        { k: "eq", expr: "A = [ (O₁ + O₂ + O₃ + … + Oₙ₊₁) / (n + 1) ] × L", where: [
          ["O₁ … Oₙ₊₁", "the (n+1) ordinates at the strip boundaries"],
        ] },
        { k: "eq", expr: "A = [ (O₁ + O₂ + O₃ + … + Oₙ₊₁) / (n + 1) ] × nd", where: [
          ["d", "common interval (strip width)"],
          ["nd", "total length L"],
        ] },
        { k: "p", t: "Both boxed formulas are as given in the notes (p.196)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Dono rules ek hi idea par chalte hain — <b>average height × length</b>. Fark sirf yeh hai ki height kahan naapi gayi. Mid-ordinate rule mein har strip ke <b>beech</b> ki height (h) li jaati hai, to n strips ke n values aate hain, divide by n. Average-ordinate rule mein strips ki <b>boundaries</b> par offsets (O) liye jaate hain — n strips ke liye (n+1) boundaries hoti hain, isliye divide by (n+1)." },
        { k: "p", t: "Average-ordinate rule mein end offsets O₁ aur Oₙ₊₁ ko beech wale offsets jitna hi weight milta hai, jabki ve sirf aadhi-aadhi strip ko represent karte hain. Isi wajah se yeh rule rough hai, aur trapezoidal rule (next section) isse better hai." },
        { k: "trap", t: "Average-ordinate mein denominator <b>(n+1)</b> hai — offsets ki ginti — aur length L = nd, jahan n = strips ki ginti. 9 offsets diye hain to n = 8 strips; L = 8d, 9d nahi. Students aksar offsets ki ginti ko hi n maan kar length galat le lete hain." },
      ],
    },

    /* ---------------------------------------------------------- p.197–198 */
    {
      n: "",
      title: "Notes — trapezoidal rule, Simpson's 1/3rd rule, odd and even offsets",
      hi: "समलम्ब नियम, सिम्पसन 1/3 नियम",
      blocks: [
        { k: "h", t: "📘 Notes — p.197–198" },
        { k: "h", t: "(3) Trapezoidal rule" },
        { k: "p", t: "This rule is <b>more accurate</b> than the mid-ordinate &amp; average-ordinate rules. (p.197)" },
        { k: "eq", expr: "A = d [ (O₁ + Oₙ)/2 + O₂ + O₃ + … + Oₙ₋₁ ]", where: [
          ["d", "common interval between offsets"],
          ["O₁, Oₙ", "first and last offsets"],
          ["O₂ … Oₙ₋₁", "intermediate offsets"],
        ] },
        { k: "h", t: "(4) Simpson's 1/3rd rule (★ Imp)" },
        { k: "eq", expr: "A = (d/3) [ (O₁ + Oₙ) + 4(O₂ + O₄ + … + Oₙ₋₁) + 2(O₃ + O₅ + … + Oₙ₋₂) ]", where: [
          ["O₁ + Oₙ", "first + last offsets (weight 1)"],
          ["O₂, O₄, …", "even-numbered offsets (weight 4)"],
          ["O₃, O₅, …", "odd-numbered intermediate offsets (weight 2)"],
        ] },
        { k: "note", t: "<b>Note (★ Imp):</b><br>(i) Simpson's rule is applicable only when there is an <b>odd number of offsets</b> (<b>even number of segments</b>).<br>(ii) If there is an <b>even</b> number of offsets, Simpson's rule is still applicable, but in that case the total area is divided into two parts —<br>&nbsp;&nbsp;a) area up to the second-last segment, i.e. it has an odd number of offsets; this area is calculated by Simpson's rule;<br>&nbsp;&nbsp;b) area of the last segment is determined by the trapezoidal rule.<br>Total area = sum of ① + sum of ②. (p.197)" },
        { k: "p", t: "Figure (p.197): a strip divided into 9 segments by 10 vertical offsets, offsets numbered 1–10 along the bottom. Segments 1–8 are numbered inside; an arrow over segments 1–8 is labelled <b>\"Simpson rule\"</b>. The 9th (last) segment, between offsets 9 and 10, is marked <b>\"Trapezoidal rule\"</b>; a wavy line at offset 9 separates the two parts. (p.197)" },
        { k: "note", t: "<b>Note (2nd):</b> If in the question it is mentioned that the area has to be calculated by <b>Simpson's rule only</b> &amp; the offsets are even in number, then the <b>average of the offsets</b> is taken between any two adjacent offsets (an extra offset is inserted), and hence the number of offsets becomes odd. (p.198)" },
        { k: "p", t: "Figure (p.198): base line with 7 original offsets (labelled 1–7 on top). An extra offset is inserted between two adjacent original offsets, with an arrow: <b>\"avg → Now there are odd offsets &amp; even segments — use Simpson\"</b>. Segments are renumbered 1–6 in red. (p.198)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "<b>Trapezoidal</b> rule boundary ko do offsets ke beech <b>seedhi line</b> maanta hai — har strip ek trapezium. Isliye end offsets ko aadha weight (÷2) milta hai aur beech wale offsets ko poora, kyunki har beech wala offset do trapeziums mein share hota hai." },
        { k: "p", t: "<b>Simpson's</b> rule teen-teen offsets se ek <b>parabola</b> fit karta hai, yaani do strips ek saath. Isliye strips ki ginti even honi chahiye (offsets odd). Weights ka pattern 1, 4, 2, 4, 2, …, 4, 1 hai — parabola ke beech wale point ko 4, aur do parabolas ke jod wale point ko 2 (dono parabolas se 1-1). Curved boundary par yeh trapezoidal se zyada accurate hota hai. Chapter ke §10.2 mein dono rules ki tulna ek example se dikhai gayi hai." },
        { k: "trap", t: "Simpson mein '4' wala group <b>even-numbered</b> offsets (O₂, O₄, …) ka hai aur '2' wala group <b>odd-numbered intermediate</b> offsets (O₃, O₅, …) ka — first aur last offset kisi group mein nahi aate, aur unhe ÷2 bhi nahi karte (yeh trapezoidal ki aadat hai). Dusri galti: even offsets dekh kar ek offset chhod dena — notes ke do sahi tareeke hain: last segment trapezoidal se, ya do adjacent offsets ka average daal kar." },
      ],
    },

    /* ---------------------------------------------------------- p.198 */
    {
      n: "",
      title: "Notes — volume: end-area and prismoidal formulas",
      hi: "आयतन — अन्त्य-क्षेत्र और प्रिज़्मॉइडल सूत्र",
      blocks: [
        { k: "h", t: "📘 Notes — p.198" },
        { k: "h", t: "Volume measurement" },
        { k: "h", t: "(i) End-area formula / Trapezoidal" },
        { k: "eq", expr: "V = [ (A₁ + Aₙ)/2 + A₂ + A₃ + … + Aₙ₋₁ ] × D", where: [
          ["A₁ … Aₙ", "cross-sectional areas"],
          ["D", "interval between cross-sections"],
        ] },
        { k: "h", t: "(ii) Prismoidal formula (also called Simpson's rule of volume)" },
        { k: "eq", expr: "V = (D/3) [ (A₁ + Aₙ) + 4(A₂ + A₄ + … + Aₙ₋₁) + 2(A₃ + A₅ + … + Aₙ₋₂) ]", where: [
          ["D", "interval between cross-sections"],
          ["A₂, A₄, …", "even-numbered sections (weight 4)"],
          ["A₃, A₅, …", "odd-numbered intermediate sections (weight 2)"],
        ] },
        { k: "p", t: "In both formulas the notes mark D as the <b>interval</b>. (p.198)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Volume ke formulas bilkul area wale formulas ki copy hain — sirf <b>offset O ki jagah cross-section ka area A</b> aur <b>d ki jagah D</b>. End-area = trapezoidal rule, prismoidal = Simpson's rule. Isliye Simpson wali condition yahan bhi lagti hai: prismoidal ke liye cross-sections ki ginti <b>odd</b> honi chahiye." },
        { k: "trap", t: "D hamesha do consecutive cross-sections ke beech ki doori hai, poori length nahi. 3 sections ho aur poori length di ho, to D = length ÷ 2 hoga. Question dhyan se padho ki di hui doori interval hai ya total length." },
        { k: "real", t: "Road, railway aur canal ke earthwork quantities isi tarah nikalti hain — har chainage par cross-section ka area, phir end-area ya prismoidal formula. Chapter ke §10.3 mein prismoidal correction bhi explained hai." },
      ],
    },

    /* ---------------------------------------------------------- p.199–201 */
    {
      n: "",
      title: "Notes — worked numericals: areas from offsets",
      hi: "ऑफसेट से क्षेत्रफल — हल किए गए प्रश्न",
      blocks: [
        { k: "h", t: "📘 Notes — p.199–201" },
        { k: "p", t: "Figure (p.199): an irregular boundary above a straight traverse line, with 9 offsets O1–O9 at 5 m spacing (8 strips, each marked 5 m): 2.10, 3.15, 4.50, 3.60, 4.58, 7.85, 6.45, 4.65, 3.14. Highest point at O6 (7.85). Strips numbered 1–8. (p.199)" },
        { k: "eg",
          title: "Notes example — average-ordinate, trapezoidal and Simpson's rules (9 offsets)",
          given: "The following offsets were taken at 5 m interval from a traverse line to an irregular boundary: 2.10, 3.15, 4.50, 3.60, 4.58, 7.85, 6.45, 4.15, 3.14 m. Compute the area by the average-ordinate rule, trapezoidal rule & Simpson's rule.",
          steps: [
            { t: "Length", w: "L = nd = 8 × 5 = 40 m" },
            { t: "(i) Average-ordinate rule", w: "A = [(O₁ + O₂ + O₃ + … + Oₙ₊₁)/(n+1)] × nd\n= [(2.10 + 3.15 + 4.5 + 3.6 + 4.58 + 7.85 + 6.45 + 4.65 + 3.14)/(8+1)] × 40\nA = 177.82 m²" },
            { t: "(ii) Trapezoidal rule", w: "A = d[(O₁ + Oₙ)/2 + O₂ + O₃ + … + Oₙ₋₁]\n= 5 × [(2.10 + 3.14)/2 + 3.15 + 4.50 + 3.60 + 4.58 + 7.85 + 6.45 + 4.65]\nA = 187 m²" },
            { t: "(iii) Simpson's 1/3rd rule", w: "A = (d/3)[O₁ + Oₙ + 4(O₂ + O₄ + … + Oₙ₋₁) + 2(O₃ + O₅ + … + Oₙ₋₂)]\n= (5/3)[2.10 + 3.14 + 4(3.15 + 3.60 + 7.85 + 4.65) + 2(4.5 + 4.58 + 6.45)]\nA = 188.83 m²" },
          ],
          ans: "Average-ordinate 177.82 m²; trapezoidal 187 m²; Simpson's 188.83 m² (p.199–200)",
        },
        { k: "note", t: "<b>Check:</b> (1) The question line lists the 8th offset as <b>4.15</b>, but the figure and all three workings use <b>4.65</b>; the answers above are for 4.65. With 4.15 the results would be 175.64, 184.5 and 185.5 m². (2) Average-ordinate: sum of offsets = 40.02; 40.02/9 × 40 = <b>177.87 m²</b> (notes write 177.82). Trapezoidal 187.00 m² and Simpson's 188.83 m² re-work correctly." },
        { k: "eg",
          title: "Notes example — 10 offsets: Simpson + trapezoidal",
          given: "Offsets (5 m interval): 2.10, 3.15, 4.50, 3.60, 4.58, 7.85, 6.45, 4.65, 3.14, 2.8. Use Simpson + trapezoidal, & only Simpson.",
          steps: [
            { t: "(i) Simpson + trapezoidal — first 8 segments", w: "From above, up to 8 segments (Simpson) = 188.83 m²" },
            { t: "Last segment by trapezoidal", w: "Figure: last segment is a trapezium with sides 3.14 and 2.8, base 5\nA = d[(O₁ + Oₙ)/2 + O₂ + O₃ + … + Oₙ₋₁]\nA = d[(3.14 + 2.8)/2]\nA = 5 × [(3.14 + 2.8)/2]" },
            { t: "Total", w: "Total area = 188.83 + 5 × ((3.14 + 2.8)/2)\n= 203.68 m²" },
          ],
          ans: "Total area (Simpson + trapezoidal) = 203.68 m² (p.200)",
        },
        { k: "p", t: "Figure (p.201) — \"Use Simpson only\": the same strip with offsets O₁–O₁₁: 2.10, 3.15, 4.50, 3.60, 4.58, 7.85, 6.45, 4.65, 3.14, (inserted offset), 2.8. A red offset <b>2.97</b> is inserted between 3.14 and 2.8 (the average of the two adjacent offsets) and labelled O₁₀; the last offset 2.8 becomes O₁₁. Segments are numbered ①–⑩. (p.201)" },
        { k: "eg",
          title: "Notes example — 10 offsets: Simpson's rule only (averaged offset inserted)",
          given: "Same offsets: 2.10, 3.15, 4.50, 3.60, 4.58, 7.85, 6.45, 4.65, 3.14, 2.8 (5 m interval). Use Simpson's rule only.",
          steps: [
            { t: "Insert average offset", w: "Between 3.14 and 2.8 insert (3.14 + 2.8)/2 = 2.97 → now 11 offsets (odd), 10 segments (even)" },
            { t: "Simpson's rule as written in the notes", w: "A = (d/3)[(O₁ + Oₙ) + 4(O₂ + O₄ + … + Oₙ₋₁) + 2(O₃ + O₅ + … + Oₙ₋₂)]\n= (5/3)[(2.10 + 2.8)/2 + 4(3.15 + 3.6 + 7.85 + 4.05 + 2.97) + 2(4.5 + 4.58 + 6.45 + 3.14)]\n= (no final value written)" },
          ],
          ans: "The notes leave this working unfinished — no final value is written (p.201)",
        },
        { k: "note", t: "<b>Check:</b> The notes' line has two slips: the end offsets are written as (2.10 + 2.8)/2 — in Simpson's rule the ends are <i>not</i> halved — and the 8th offset is written 4.05 instead of <b>4.65</b>. Even with those fixed, using d = 5 for all 10 segments gives 218.53 m², which is wrong because the inserted offset splits the last 5 m strip into two strips of <b>2.5 m</b> (the line is still 45 m long, not 50 m). Correct working with the true spacing: 188.83 (first 8 strips, d = 5) + (2.5/3)(3.14 + 4 × 2.97 + 2.8) = 188.83 + 14.85 = <b>203.68 m²</b> — the same as the Simpson + trapezoidal answer, as it must be, since the inserted offset is the straight-line average." },
        { k: "p", t: "Figure (p.201): irregular boundary above a chain line; offsets 14.5, 24.5, 30.8, 27.4, 28.4, 18.4 at chainages 0, 8, 20, 35, 47, 60; intervals marked along the base 8 m, 12 m, 15 m, 12 m, 13 m. (p.201)" },
        { k: "eg",
          title: "Notes example — unequal intervals, trapezoidal rule",
          given: "The following offsets were taken from a chain line to an irregular boundary. Chainage (m): 0, 8, 20, 35, 47, 60. Offset (m): 14.5, 24.5, 30.8, 27.4, 28.4, 18.4.",
          steps: [
            { t: "Intervals", w: "8 m, 12 m, 15 m, 12 m, 13 m (unequal)" },
            { t: "Using trapezoidal rule, strip by strip", w: "A = ((14.5 + 24.5)/2) × 8 + ((24.5 + 30.8)/2) × 12 + ((30.8 + 27.4)/2) × 15\n+ ((27.4 + 28.4)/2) × 12 + ((28.4 + 18.4)/2) × 13\n= 1563.3 m²" },
          ],
          ans: "A = 1563.3 m² (p.201)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Pehle sawal mein teeno rules ka answer badhta jaata hai: 177.82 → 187 → 188.83. Boundary ka bada hissa upar ki taraf convex hai (O6 = 7.85 par peak), isliye seedhi line wala trapezoidal thoda kam deta hai aur parabola wala Simpson zyada sahi. Average-ordinate rule end offsets ko bhi poora weight deta hai, isliye sabse door hai." },
        { k: "p", t: "Jab intervals <b>barabar nahi</b> hain (chainage 0, 8, 20, 35, …), to formula seedha nahi lagta — har strip ka trapezium alag se nikalo, (O₁ + O₂)/2 × apna interval, aur sab jod do. Simpson ke liye barabar interval zaroori hai." },
        { k: "trap", t: "Average offset daal kar Simpson lagate waqt d nahi badalna bhool jaate hain. Jis strip mein naya offset dala, uski width aadhi ho gayi — poori line par ek hi d = 5 m lagana galat hai. Isse bachne ka seedha raasta: Simpson pehle even segments par, aur bacha hua last segment trapezoidal se." },
      ],
    },

    /* ---------------------------------------------------------- p.202–203 */
    {
      n: "",
      title: "Notes — RPSC 2013: offsets at two different intervals",
      hi: "RPSC 2013 — दो अलग अन्तराल",
      blocks: [
        { k: "h", t: "📘 Notes — p.202–203 (RPSC 2013)" },
        { k: "cmp", t: "RPSC 2013 — data (p.202)", cols: ["Chainage (m)", "Offset (m)"], rows: [
          ["1", "0", "2.5"],
          ["2", "5", "3.8"],
          ["3", "10", "8.4"],
          ["4", "15", "7.6"],
          ["5", "20", "10.5"],
          ["6", "25", "9.3"],
          ["7", "35", "5.8"],
          ["8", "45", "7.8"],
          ["9", "55", "6.9"],
          ["10", "65", "8.4"],
        ] },
        { k: "p", t: "Figure (p.202): irregular boundary above a base line with the ten offsets above; peak at chainage 20 (10.5). Along the base the offsets are relabelled in red: O1, O2, O3, O4, O5 at 5 m spacing (chainage 0–20), then O1, O2, O3, O4, O5 at 10 m spacing (chainage 25–65). The base is divided by two × marks into parts <b>①</b> (0–20), <b>②</b> (20–25) and <b>③</b> (25–65). (p.202)" },
        { k: "p", t: "Taking the offsets between the points where the chainage interval is equal to 10 m as a separate part. Part ① — 5 offsets at 5 m (Simpson); part ② — one 5 m strip (trapezoidal); part ③ — 5 offsets at 10 m (Simpson). (p.202)" },
        { k: "eg",
          title: "Notes example — RPSC 2013: area by Simpson + trapezoidal",
          given: "Chainage: 0, 5, 10, 15, 20, 25, 35, 45, 55, 65 m. Offset: 2.5, 3.8, 8.4, 7.6, 10.5, 9.3, 5.8, 7.8, 6.9, 8.4 m. Find the area.",
          steps: [
            { t: "Area of ① (chainage 0–20, d = 5 m) by Simpson's method", w: "A = (d/3)[(O₁ + O₅) + 4(O₂ + O₄) + 2(O₃)]\n= (5/3)[2.5 + 10.5 + 4(3.8 + 7.6) + 2 × 8.4]\nA = 125.66 m²" },
            { t: "Area of ② (chainage 20–25) by trapezoidal", w: "A = 5 × (10.5 + 9.3)/2\nA = 49.5 m²" },
            { t: "Area of ③ (chainage 25–65, d = 10 m) by Simpson", w: "A = (10/3)[9.3 + 8.4 + 4(5.8 + 6.9) + (2 × 7.8)]\nA = 280.33 m²" },
            { t: "Total", w: "Total area = 125.66 + 49.5 + 280.33" },
          ],
          ans: "A = 455.49 m² (p.202–203)",
        },
        { k: "note", t: "<b>Check:</b> Area ① = (5/3) × 75.4 = 125.666… = <b>125.67 m²</b> (notes truncate to 125.66). Exact total = 125.67 + 49.5 + 280.33 = <b>455.50 m²</b> (notes 455.49). The method is correct." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Simpson ke liye <b>ek part ke andar</b> interval barabar hona chahiye aur offsets odd. Yahan chainage 0–25 mein 5 m wale 6 offsets hain (even) — isliye 0–20 ke 5 offsets par Simpson, aur 20–25 ki ek strip trapezoidal. Fir 25–65 mein 10 m wale 5 offsets (odd) — wahan dobara Simpson, d = 10 ke saath. Har part ka apna d hai." },
        { k: "trap", t: "Pure data par ek hi d lagana sabse badi galti hai — 0–25 par d = 5 aur 25–65 par d = 10. Aur chainage 25 wala offset (9.3) dono parts mein aata hai: ② ka last offset bhi hai aur ③ ka first bhi — ise kisi part se hatana nahi hai." },
      ],
    },

    /* ---------------------------------------------------------- p.203–204 */
    {
      n: "",
      title: "Notes — embankment volume between three cross-sections",
      hi: "तटबंध का आयतन — तीन अनुप्रस्थ काट",
      blocks: [
        { k: "h", t: "📘 Notes — p.203–204" },
        { k: "p", t: "<b>Q.</b> Figure shows 3 cross-sections of an embankment of 30 m. Calculate the volume between the end sections by (i) trapezoidal / end-area, (ii) prismoidal formula / Simpson. (p.203)" },
        { k: "list", items: [
          "Figure (p.203) — three trapezoidal embankment cross-sections, each with <b>top width 11 m</b>, side slopes marked by small slope triangles 2 (horizontal) : 1 (vertical).",
          "Section ①: height <b>2 m</b>; bottom: 4 | 11 | 4, total bottom width <b>19 m</b>. Note in the figure: \"4 → slope से निकाले हैं\" (the 4 m is obtained from the slope: 2 × 2).",
          "Section ②: height <b>3.5 m</b>; slope triangle 1 (vertical) : 2 (horizontal); bottom: 7 | 11 | 7, total <b>25 m</b>.",
          "Section ③: height <b>5 m</b>; slope 2 : 1; side projections 10 and 10, total bottom width <b>31 m</b>.",
        ] },
        { k: "cmp", t: "Cross-section areas — by trapezoidal (two side triangles + middle rectangle) (p.203)", cols: ["Working", "Area (m²)"], rows: [
          ["Section ①", "2[½ × 4 × 2] + 11 × 2", "30 = A₁"],
          ["Section ②", "2[½ × 7 × 3.5] + 11 × 3.5", "63 = A₂"],
          ["Section ③", "2[½ × 5 × 10] + 11 × 5", "105 = A₃"],
        ] },
        { k: "eg",
          title: "Notes example — embankment volume by end-area and prismoidal formulas",
          given: "Figure shows 3 c/s of an embankment of 30 m (top width 11 m, side slopes 2:1, heights 2 m, 3.5 m, 5 m). Calculate the volume between end sections by (i) trapezoidal / end-area, (ii) prismoidal formula / Simpson.",
          steps: [
            { t: "Areas", w: "Area of ① = 2[(1/2) × 4 × 2] + 11 × 2 = 30 = A₁\nArea of ② = 2[(1/2) × 7 × 3.5] + 11 × 3.5 = 63 = A₂\nArea of ③ = 2[(1/2) × 5 × 10] + 11 × 5 = 105 = A₃" },
            { t: "(i) End-area formula", w: "V = [(A₁ + Aₙ)/2 + A₂ + A₃ + … + Aₙ₋₁] × D\n= [(30 + 105)/2 + 63] × 30 = 3915 m³" },
            { t: "(ii) Prismoidal formula", w: "V = (D/3)[(A₁ + Aₙ) + 4(A₂ + A₄ + … + Aₙ₋₁) + 2(A₃ + A₅ + … + Aₙ₋₂)]\nV = (30/3)[30 + 105 + 4(63)]\nV = 3870 m³" },
          ],
          ans: "End-area V = 3915 m³; prismoidal V = 3870 m³ (p.203–204)",
        },
        { k: "note", t: "Arithmetic re-worked: areas 30, 63, 105 m² and volumes 3915 m³ and 3870 m³ are correct with D = 30 m. The notes read \"30 m\" as the <b>interval</b> between sections. If a question instead gives 30 m as the <i>total</i> length of the embankment, then D = 15 m and the same working gives 1957.5 m³ and 1935 m³." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Embankment ka cross-section ek trapezium hai: top width b = 11 m, height h, aur slope 2:1 ki wajah se har side ka horizontal phailaav = 2 × h. Isliye area = beech ka rectangle (11 × h) + do side triangles (2 × ½ × 2h × h). Height 2 m → side 4 m, height 3.5 m → side 7 m, height 5 m → side 10 m — figure ke bottom widths 19, 25, 31 m isi se aate hain." },
        { k: "p", t: "Teen sections = odd, isliye prismoidal formula seedha lagta hai — beech wale A₂ ko weight 4. Prismoidal ka answer (3870) end-area (3915) se 45 m³ kam hai; end-area formula embankment ke volume ko thoda zyada batata hai — chapter ke §10.3 mein isi difference ko prismoidal correction kaha gaya hai." },
        { k: "trap", t: "Section ③ ke area mein notes 2[½ × 5 × 10] likhte hain — yahan 5 height aur 10 side projection hai, order badla hai par product wahi. Galti tab hoti hai jab student slope 2:1 ko ulta (1 horizontal : 2 vertical) le leta hai aur side projection h/2 nikaal deta hai — figure dekho: 2 horizontal, 1 vertical." },
        { k: "real", t: "Site par road ya canal bank ka earthwork aise hi nikaala jaata hai — har chainage par level se height, formation width aur side slope se area, phir end-area ya prismoidal formula se volume." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — Areas and Volumes (p.196–204)",
      hi: "पुनरावृत्ति — क्षेत्रफल और आयतन",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "Method for area depends on the shape of the tract &amp; accuracy desired. (p.196)",
          "n strips of width d → (n+1) ordinates; L = nd. (p.196)",
          "Mid-ordinate rule: A = [(h₁ + h₂ + … + hₙ)/n] × L. (p.196)",
          "Average-ordinate rule: A = [(O₁ + O₂ + … + Oₙ₊₁)/(n+1)] × L = […/(n+1)] × nd. (p.196)",
          "Trapezoidal rule: A = d[(O₁ + Oₙ)/2 + O₂ + O₃ + … + Oₙ₋₁] — more accurate than mid- and average-ordinate rules. (p.197)",
          "Simpson's 1/3rd rule: A = (d/3)[(O₁ + Oₙ) + 4(O₂ + O₄ + … + Oₙ₋₁) + 2(O₃ + O₅ + … + Oₙ₋₂)]. (p.197)",
          "Simpson's rule only for an odd number of offsets (even number of segments). (p.197)",
          "Even offsets: Simpson up to the second-last segment + trapezoidal for the last segment; total = ① + ②. (p.197)",
          "Simpson-only with even offsets: insert the average of two adjacent offsets to make the offsets odd. (p.198)",
          "End-area (trapezoidal) volume: V = [(A₁ + Aₙ)/2 + A₂ + … + Aₙ₋₁] × D, D = interval. (p.198)",
          "Prismoidal (Simpson's rule of volume): V = (D/3)[(A₁ + Aₙ) + 4(A₂ + A₄ + …) + 2(A₃ + A₅ + …)]. (p.198)",
          "9 offsets at 5 m: average-ordinate 177.82 m², trapezoidal 187 m², Simpson 188.83 m². (p.199–200)",
          "10 offsets: Simpson (8 segments) 188.83 + trapezoidal last segment → 203.68 m². (p.200)",
          "Unequal intervals (chainage 0–60): trapezoidal strip by strip → 1563.3 m². (p.201)",
          "RPSC 2013: Simpson (0–20, d = 5) 125.66 + trapezoidal (20–25) 49.5 + Simpson (25–65, d = 10) 280.33 = 455.49 m². (p.202–203)",
          "Embankment, top width 11 m, slope 2:1, heights 2, 3.5, 5 m: A = 30, 63, 105 m². (p.203)",
          "Embankment volume, D = 30 m: end-area 3915 m³, prismoidal 3870 m³. (p.203–204)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
