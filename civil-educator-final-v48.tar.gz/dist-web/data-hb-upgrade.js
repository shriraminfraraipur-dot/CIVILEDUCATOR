/* ============================================================
   CIVIL EDUCATOR — HANDBOOK UPGRADE LAYER
   ------------------------------------------------------------
   Three things get added to the finished handbooks here, all of
   them aimed at one target: a student reading alone, on a phone,
   who needs to SEE what a paragraph is describing.

     1. ANIMATED figures, placed in the sections where the idea
        is a movement or a sequence rather than a state.
     2. COMPARISONS, because "how is this different from that"
        is the question students actually ask, and prose answers
        it badly.
     3. "WHERE YOU'LL MEET THIS" — the real building element the
        theory is about, named plainly, so the reader can go and
        look at one.

   It also closes the two gaps a fresh read of the syllabus
   turned up: plastic analysis of steel structures, and a
   head-to-head of working stress against limit state.

   Injection rather than editing: the chapter files stay as
   written, and every insertion is located by chapter number and
   section number, so a miss is loud rather than silent.
   ============================================================ */

(function () {
  var HB = (window.DB && DB.handbooks) || [];

  function sec(hbId, chN, secN) {
    var h = HB.find(function (x) { return x.id === hbId; });
    if (!h) return null;
    var c = h.chapters.find(function (x) { return x.n === chN; });
    if (!c) return null;
    return c.sections.find(function (x) { return x.n === String(secN); }) || null;
  }

  /* Append blocks to the end of a section. A missed target is reported to
     the console, so the regression suite catches it rather than the reader. */
  function add(hbId, chN, secN, blocks) {
    var s = sec(hbId, chN, secN);
    if (!s) { console.error("[upgrade] no section " + hbId + " " + chN + "/" + secN); return; }
    s.blocks = s.blocks.concat(blocks);
  }

  /* ============================================================
     STRUCTURAL ANALYSIS
     ============================================================ */

  add("sa", 1, "1.10", [
    { k: "dia", id: "an-sa-mechanism", cap: "A mechanism moves without any member changing length. No section size fixes that — only geometry does." },
  ]);

  add("sa", 4, "4.1", [
    { k: "dia", id: "an-sa-ild", cap: "The load rolls; the marker slides down the influence line. The line is the marker's track." },
    { k: "real", t: "Stand on a road bridge while a loaded truck crosses it. The bending moment at the point under your feet rises as the truck approaches, peaks somewhere near you, and falls away again — and the curve it traces is the influence line for that point. It is also why a bridge is posted with an axle-load limit rather than a total-weight limit: <strong>where the load sits matters as much as how heavy it is</strong>." },
  ]);

  add("sa", 6, "6.1", [
    { k: "cmp", t: "The two families of method, and how to tell which one a problem wants.",
      cols: ["Force (flexibility) method", "Displacement (stiffness) method"],
      rows: [
        ["Unknowns", "Redundant <strong>forces</strong> — reactions or internal forces you removed", "Joint <strong>displacements</strong> — rotations and translations"],
        ["How many", "Degree of <em>static</em> indeterminacy, Ds", "Degree of <em>kinematic</em> indeterminacy, Dk"],
        ["Equations used", "Compatibility — deflections must match up", "Equilibrium — forces at each joint must balance"],
        ["Best when", "Ds is small — a propped cantilever, a two-span beam", "Dk is small — a rigid frame with few joints"],
        ["Choice involved", "Yes — you pick which redundants to release, and a bad pick makes the arithmetic ugly", "No — the unknowns are fixed by the structure itself"],
        ["Members of the family", "Consistent deformation, three-moment equation, column analogy", "Slope-deflection, moment distribution, Kani, matrix stiffness"],
        ["What software uses", "Rarely", "Always — the stiffness method is what every analysis package runs"],
      ] },
    { k: "note", t: "That last row is worth pausing on. The displacement method won not because it is more elegant but because it <strong>needs no judgement</strong> — the unknowns follow from the structure, so it can be coded. The force method needs a human to choose the redundants, which is exactly what a computer is bad at." },
  ]);

  add("sa", 8, "8.1", [
    { k: "dia", id: "an-sa-momdist", cap: "Lock every joint, release one, carry over half to the far end, and go round again. The error shrinks each cycle." },
    { k: "real", t: "Moment distribution is what a design office ran on for fifty years before software, and it is still the fastest way to get a continuous beam's moments on the back of an envelope — or to sanity-check what a package has just told you. If a computer output for a two-span beam looks wrong, two cycles of moment distribution by hand will tell you whether it is." },
  ]);

  add("sa", 11, "11.3", [
    { k: "dia", id: "an-sa-hinges", cap: "Hinges appear one at a time. The structure only collapses when there are enough of them to make a mechanism." },
  ]);

  /* ============================================================
     DESIGN OF RCC STRUCTURES
     ============================================================ */

  add("rcc", 1, "1.4", [
    { k: "cmp", t: "The three methods, side by side — the comparison every exam asks for and every designer should be able to give from memory.",
      cols: ["Working stress (WSM)", "Limit state (LSM)"],
      rows: [
        ["Basic question", "Is the stress under everyday load low enough?", "Is there an adequate margin against <em>each way it could become unfit</em>?"],
        ["Material behaviour assumed", "Elastic — straight-line stress, throughout", "Real — parabolic-rectangular concrete, yielding steel"],
        ["Where the safety factor sits", "One factor, on the material stress", "Separate partial factors on <em>loads</em> and on <em>materials</em>"],
        ["Different loads treated differently?", "No — dead load and wind get the same treatment", "Yes — γf differs by load and by combination"],
        ["Says anything about collapse?", "No. Two members at the same working stress can have very different reserves", "Yes — that is the primary limit state"],
        ["Says anything about serviceability?", "Only indirectly, by keeping stresses low", "Yes — a separate check at service load"],
        ["Result", "Safe, simple, and wasteful", "Economical, and it takes two calculations instead of one"],
        ["Still used for", "Liquid-retaining structures (IS 3370), where crack width governs. IS 456 keeps it as Annex B", "Everything else"],
      ] },
    { k: "note", t: "The honest summary: working stress is not wrong, it is <em>incomplete</em>. It controls one thing well — stress at working load — and is silent about the margin against collapse, which is the thing a code exists to guarantee. That is why it survives exactly where its one strength is the governing requirement." },
  ]);

  add("rcc", 3, "3.2", [
    { k: "dia", id: "an-rcc-block", cap: "Strain stays a straight line the whole way. It is the stress diagram that changes shape, because concrete stops being elastic long before it crushes." },
  ]);

  add("rcc", 3, "3.5", [
    { k: "dia", id: "an-rcc-fail", cap: "Watch the sag. The under-reinforced beam is still moving long after the over-reinforced one has finished — and that movement is the warning." },
    { k: "cmp", t: "The distinction the whole of IS 456's flexural design is built to enforce.",
      cols: ["Under-reinforced", "Over-reinforced"],
      rows: [
        ["Which material gives first", "<strong>Steel</strong> yields", "<strong>Concrete</strong> crushes"],
        ["Neutral axis", "xu &lt; xu,max — shallow", "xu &gt; xu,max — deep"],
        ["Deflection before failure", "Large and obvious", "Small"],
        ["Cracks", "Wide, and they keep widening", "Hairline, right up to the end"],
        ["Warning", "Plenty — minutes or longer", "None"],
        ["Failure", "Ductile, gradual", "Brittle, sudden"],
        ["Strength", "Often slightly <em>less</em>", "Often slightly more"],
        ["Permitted by IS 456?", "Yes — this is what Cl. 38.1(f) enforces", "No"],
      ] },
    { k: "note", t: "Read the strength row again. The over-reinforced section is frequently the <em>stronger</em> one, and the code forbids it anyway. That tells you what a design code is actually optimising for, and it is not strength — it is the behaviour on the way to failure." },
  ]);

  add("rcc", 5, "5.1", [
    { k: "real", t: "Go and look at any ordinary RCC beam on a site before it is plastered, and count the stirrups. They will be <strong>close together near the columns and widely spaced in the middle</strong> — often 100 or 150 mm centres at the ends and 250 or 300 in the middle third. That spacing pattern is this entire chapter, built: shear is largest at the supports and smallest at mid-span, so that is where the steel goes." },
  ]);

  add("rcc", 7, "7.2", [
    { k: "cmp", t: "Which way does the slab span? Everything else follows from this one decision.",
      cols: ["One-way", "Two-way"],
      rows: [
        ["Test", "ly/lx &gt; 2, or supported on only two opposite sides", "ly/lx ≤ 2, supported on all four sides"],
        ["How load travels", "Almost entirely across the short span", "Shared between both directions"],
        ["Main steel", "Short direction only", "Both directions"],
        ["Other direction gets", "Distribution steel — 0.12% minimum, not designed for moment", "Its own designed main steel"],
        ["Moments from", "wl²/8, or the Cl. 22.5 coefficients", "αx and αy coefficients, Annex D"],
        ["Which span in the formula", "Its own span", "<strong>lx² for both</strong> — the shorter span, in both directions"],
        ["Corner steel", "Not applicable", "Needed at restrained corners (Cl. D-1.8)"],
        ["Typical example", "A verandah slab, a corridor, a cantilever chajja", "A room roughly square in plan"],
      ] },
    { k: "real", t: "Look at the ceiling of any square-ish room and at a long narrow corridor in the same building. The room's slab is spanning both ways and its steel runs in a mesh; the corridor's spans the short way only, and the bars running along the corridor are there to spread load and control shrinkage, not to carry moment. <strong>The 1/L³ stiffness argument of this section is why</strong>." },
  ]);

  add("rcc", 9, "9.1", [
    { k: "real", t: "Next time you pass an excavation, look at the footing before the backfill goes in. It will be far thicker than its bending moment seems to justify — often 600 mm for a load a 200 mm slab could carry in flexure. That thickness is <strong>punching shear</strong>, §9.4, and nothing else. Look also for the starter bars projecting out of the top: those are the dowels of §9.6, carrying the load across the joint the concrete alone cannot." },
  ]);

  /* ============================================================
     DESIGN OF STEEL STRUCTURES
     ============================================================ */

  add("st", 1, "1.4", [
    { k: "dia", id: "an-st-buckle", cap: "Same grade, same area, three lengths. Only the third one moves — and it is the one that fails first." },
    { k: "real", t: "A scaffolding pole is the everyday demonstration. A 1 m offcut is almost impossible to bend by hand; the same pole at 4 m bows noticeably under a fraction of that push. Nothing about the steel changed. <strong>That is the whole of Chapter 6 in one object you can pick up.</strong>" },
  ]);

  add("st", 1, "1.5", [
    { k: "cmp", t: "Working stress against limit state — the same comparison as in the RCC handbook, with IS 800's own numbers on it.",
      cols: ["Working stress (IS 800-1984)", "Limit state (IS 800:2007)"],
      rows: [
        ["Loads used", "Service loads, unfactored", "Factored — 1.5(DL + LL) and the other Table 4 combinations"],
        ["Material treated as", "Elastic throughout", "Elastic or plastic, depending on the section class"],
        ["Section capacity in bending", "Ze × permissible stress — first yield only", "Zp fy/γm0 for a plastic or compact section"],
        ["Safety factor", "One, about 1.67 on fy, applied to stress", "Separate γf on loads and γm on materials, one per failure mode"],
        ["Are all failure modes treated alike?", "Yes — one factor covers everything", "No. γm0 = 1.10 for yielding, γm1 = 1.25 for rupture, 1.50 for a site weld"],
        ["Serviceability", "Assumed satisfied because stresses are low", "Checked separately, at service load"],
        ["Typical outcome", "Heavier sections", "Lighter, for the same real safety"],
        ["Status", "Withdrawn as the primary method; kept in IS 800 Section 11 for special cases", "The method for new design"],
      ] },
    { k: "note", t: "The row that matters most is the fourth from the top. A single global factor has to be large enough for the <em>worst</em> combination of uncertainty, so it is wasteful everywhere else. Splitting it lets the code be strict where it needs to be — a brittle tear at a bolt hole — and relaxed where it can be, which is where the material saving comes from." },
  ]);

  add("st", 2, "2.1", [
    { k: "dia", id: "an-st-local", cap: "Same depth, same steel, nearly the same area. Only the spread of the flange metal differs — and one of them never reaches its tabulated capacity." },
  ]);

  /* ---- gap closed: plastic analysis, as steel design uses it ---- */
  (function () {
    var h = HB.find(function (x) { return x.id === "st"; });
    if (!h) return;
    var c = h.chapters.find(function (x) { return x.n === 2; });
    if (!c) return;
    var last = c.sections.pop();               // "What to carry forward"
    c.sections.push({
      n: "2.6",
      title: "Plastic analysis, and what the class has to do with it",
      hi: "प्लास्टिक विश्लेषण और सेक्शन वर्ग",
      blocks: [
        { k: "p", t: "Section classification is not only a bookkeeping exercise for choosing a section modulus. It decides whether a whole <em>method of analysis</em> is available to you, and that is a much larger consequence." },
        { k: "p", t: "Elastic analysis stops the moment the most-stressed fibre in the most-stressed section reaches fy. But a ductile section does not fail there — it goes on rotating at a constant moment Mp while the rest of the structure picks up the difference, exactly as the Structural Analysis handbook's Chapter 11 describes. The structure only collapses when enough hinges have formed to turn it into a mechanism." },
        { k: "eq", expr: "Mp = Zp fy        shape factor S = Zp / Ze        load factor = collapse load / working load", where: [
          ["Mp", "plastic moment — every fibre yielded, tension below and compression above the equal-area axis"],
        ]},
        { k: "cmp", t: "The same structure, analysed two ways.",
          cols: ["Elastic analysis", "Plastic analysis"],
          rows: [
            ["Failure defined as", "First yield, at one fibre of one section", "Enough plastic hinges to form a mechanism"],
            ["Section capacity", "My = Ze fy", "Mp = Zp fy"],
            ["Uses redistribution?", "No", "Yes — that is the whole point"],
            ["Gain for a rolled I-section", "—", "About 12–15% from the shape factor, plus whatever redistribution gives"],
            ["Which sections may use it", "Any", "<strong>Class 1 (plastic) only</strong> — Cl. 4.5.2"],
            ["Needs the steel to", "Stay elastic", "Rotate a long way at Mp without local buckling"],
            ["Number of hinges to collapse", "—", "Degree of indeterminacy + 1"],
          ] },
        { k: "p", t: "So the chain runs: <strong>ductile steel → a section whose plates stay flat → rotation capacity → redistribution → a higher collapse load</strong>. Break any link and the method is unavailable. A class 2 section reaches Mp but cannot rotate at it, so it may be designed for the full plastic moment and may <em>not</em> be used in a plastic mechanism — which is exactly the difference between class 1 and class 2, and the reason the code bothers to separate them." },
        { k: "trap", t: "A plastic hinge is not a real hinge and it does not carry zero moment. It carries <strong>Mp, constantly</strong>, while rotating. Drawing it as a pin in the collapse mechanism is a sketching convention for the rotation, not a statement that the moment has gone — and the work equation depends entirely on the moment still being there." },
        { k: "real", t: "The clearest place to see this reasoning applied is a portal frame shed. Analysed elastically the knee is the critical section and everything else is under-used; analysed plastically the frame is allowed to form hinges at the knees and in the rafter, and the section can come down a size. That is why plastic design is standard for portal frames and rare for anything that cannot be relied on to be class 1." },
        { k: "note", t: "IS 800 Section 4.5 sets the conditions: class 1 sections throughout, steel with adequate ductility (a stated ratio of fu to fy and a minimum elongation), and restraint against lateral-torsional buckling at and near every hinge — because a hinge that buckles sideways cannot rotate, and a mechanism that cannot rotate never forms." },
      ],
    });
    last.n = "2.7";
    c.sections.push(last);
    /* the summary now has one more thing to summarise */
    var li = last.blocks.find(function (b) { return b.k === "list"; });
    if (li) li.items.push("Class 1 alone may be used in plastic analysis — the class controls the method, not just the section modulus.");
  })();

  add("st", 3, "3.2", [
    { k: "real", t: "Every bolted splice on a transmission tower, every gusset on a truss bridge, every base plate you have walked past — and the reason they all carry so many bolts for the load involved is on this list. The joint has to beat five failure modes at once, and the bolts are usually sized by the smallest of them rather than by the force." },
  ]);

  add("st", 5, "5.4", [
    { k: "real", t: "Look at the bottom chord of a steel roof truss where it meets the gusset plate. The angle is bolted through <strong>one leg only</strong> — the other leg stands clear, connected to nothing. That single detail, which exists because it is easy to fabricate, is what the β factor in this section is correcting for, and it is why a truss tie is never worth its full Ag fy." },
  ]);

  add("st", 6, "6.3", [
    { k: "cmp", t: "Why the same shape gets a different buckling curve depending on how it was made.",
      cols: ["Hot-rolled section", "Welded built-up section"],
      rows: [
        ["Residual stress", "From uneven cooling after rolling — 70 to 100 N/mm²", "From welding as well — higher, and less favourably distributed"],
        ["Typical buckling class", "a or b", "b, c or worse"],
        ["Imperfection factor α", "0.21 or 0.34", "0.49 or 0.76"],
        ["Classification limits (flange)", "9.4ε / 10.5ε / 15.7ε", "8.4ε / 9.4ε / 13.6ε — tighter"],
        ["Consequence", "More of fy is available", "Less of it is, for the same slenderness"],
      ] },
    { k: "note", t: "Both rows of consequence come from the same physical fact: welding pours heat into a restrained plate and locks stress in as it cools. It is worth carrying that single idea rather than two separate tables — <strong>a welded section has been through more, so it is trusted less</strong>." },
  ]);

  add("st", 8, "8.1", [
    { k: "dia", id: "an-st-ltb", cap: "The top flange goes, the bottom flange stays, so the section twists. On the right, one restraint at mid-span and almost all of it disappears." },
    { k: "real", t: "The clearest example is a steel beam during erection, before the deck is fixed. The same beam is fully restrained once the slab has hardened and completely unrestrained the morning it is lifted into place — and it is carrying wet concrete, workers and a pump line in exactly that unrestrained condition. <strong>The governing LTB check for a composite beam is very often the temporary case</strong>, which is §8.5's last note and the reason temporary bracing is a designer's responsibility." },
  ]);

  add("st", 10, "10.3", [
    { k: "dia", id: "an-st-webbuckle", cap: "The stiffeners carry almost no shear themselves. They shorten the panel so the compression diagonal has less length in which to buckle." },
  ]);

})();
