/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 10
   Droughts — definition, Index of Wetness, classification
   (meteorological / hydrological / agricultural), Aridity Index,
   causes, impacts and mitigation measures
   Source: S2 transcript, p.4–6 (single source — no cross-source
   merge needed for this chapter)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-10",
    n: 10,
    title: "Droughts",
    hi: "अनावृष्टि (सूखा)",
    blurb: "Drought ki definition aur ise flood ke doosre extreme ke roop mein samajhna, Index of Wetness, drought-prone/chronically drought-prone zones, National Commission on Agriculture (1976) ki teen types — meteorological, hydrological, agricultural — IMD ka sub-classification, Aridity Index aur arid-zone classification, aur har type ka impact + mitigation measure.",
    mins: 14,
    sections: [
      {
        n: "10.1",
        title: "Drought — definition, Index of Wetness, drought-prone zones",
        hi: "सूखे की परिभाषा, आर्द्रता सूचकांक और सूखा-प्रवण क्षेत्र",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.4–5" },
          { k: "def", term: "Drought", t: "A climatic anomaly characterised by an insufficient supply of moisture over a long period of time. Drought is a hydrological extreme, exactly like flood — both are anomalies (departures from the normal/average water condition), just at opposite ends of the same spectrum. (S2 p.5)" },
          { k: "note", t: "Source sketch: a single horizontal line with <b>'mini Drought'</b> marked (★) at the left end and <b>'maxi flood'</b> marked (★) at the right end, with 'water' labelled in the middle — showing drought and flood as the two extremes of the same water-availability spectrum, both called <b>anomaly</b> (असामान्यता). (S2 p.5)" },
          { k: "def", term: "Index of Wetness (I.O.W)", t: "A measure of how wet or dry a given year is compared to the long-period average. I.O.W = [Rainfall in that year / Average rainfall of the place (minimum 30 years of data)] × 100. (S2 p.4)" },
          { k: "eq", expr: "I.O.W = (Rainfall of a given year / Average annual rainfall, ≥30-yr record) × 100", where: [
            ["I.O.W", "Index of Wetness, in % (S2 p.4)"],
          ] },
          { k: "list", items: [
            "I.O.W = 60% → moisture deficiency = 40% (S2 p.4)",
            "I.O.W = 100% → no deficiency — year's rainfall equals the long-period average (S2 p.4)",
            "I.O.W > 100% → indicates flood conditions (S2 p.4)",
          ] },
          { k: "cmp", t: "Rain-deficiency classification by I.O.W shortfall (S2 p.4)", cols: ["Classification"], rows: [
            ["30% – 45%", "Large"],
            ["45% – 60%", "Severe"],
            ["> 60%", "Disastrous"],
          ] },
          { k: "p", t: "<b>IMD</b> = Indian Meteorological Department. (S2 p.4)" },
          { k: "def", term: "Drought-prone zone", t: "A region where the probability of occurrence of drought lies between 20% and 40% (0.20 ≤ P ≤ 0.40). (S2 p.5)" },
          { k: "def", term: "Chronically drought-prone zone", t: "A region where the probability of occurrence of drought is greater than 40% (P > 0.40). (S2 p.5)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "I.O.W ek simple ratio hai — is saal ki baarish, average (kam se kam 30 saal ki) baarish se kitni kam/zyada hui. 100% se neeche matlab deficiency (sookha ki taraf), 100% se upar matlab flood ki taraf. Drought-prone aur chronically drought-prone zones ka farq sirf probability ka hai — kitni baar woh region drought dekhta hai: 20-40% baar to 'prone', 40% se zyada baar to 'chronically prone' (yaani almost regular feature)." },
          { k: "trap", t: "I.O.W-based rain-deficiency table (Large 30–45%, Severe 45–60%, Disastrous >60%, S2 p.4) ko IMD ke meteorological-drought sub-classification (Drought ≥25%, Moderate 26–50%, Severe >50%, S2 p.5 — §10.2 mein) ke saath mix mat karo. Dono alag % cut-offs hain aur alag purpose ke liye hain — pehla general wetness/deficiency ke liye, doosra specifically meteorological drought ke liye." },
        ],
      },
      {
        n: "10.2",
        title: "Classification of drought (National Commission on Agriculture, 1976) — meteorological and hydrological drought",
        hi: "सूखे का वर्गीकरण — मौसम विज्ञान एवं जल-वैज्ञानिक सूखा",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.5" },
          { k: "p", t: "The National Commission on Agriculture (1976) classified drought into three types, based on what quantity is actually deficient — rainfall itself, stream/groundwater levels, or soil moisture for crops. (S2 p.5)" },
          { k: "list", items: [
            "<b>① Meteorological drought</b> — deficiency in rainfall itself (S2 p.5)",
            "<b>② Hydrological drought</b> — deficiency in stream/lake/groundwater levels (S2 p.5)",
            "<b>③ Agricultural drought</b> — deficiency in soil moisture needed for crop growth, expressed via the Aridity Index — see §10.3 (S2 p.6)",
          ] },
          { k: "note", t: "This source gives only these three types (meteorological, hydrological, agricultural). A fourth type commonly discussed elsewhere — socio-economic drought — is not covered on these pages of S2, so it is not included here." },
          { k: "def", term: "Meteorological drought", t: "The situation where there is more than 25% decrease in rainfall, i.e. the actual rainfall is less than 75% of the normal (long-period average) rainfall. (S2 p.5)" },
          { k: "eg", title: "Classifying a year as drought/deficiency using the meteorological-drought criterion", given: "Normal (long-period average) rainfall of a station (name illegible in the source) is assumed as 100 cm. Year 1's actual rainfall is 70 cm; Year 2's actual rainfall is 80 cm. Classify each year.", steps: [
            { t: "% decrease in Year 1", w: "(100 - 70) / 100 x 100 = 30% decrease in rainfall" },
            { t: "Compare with the 25% criterion", w: "30% > 25% -> satisfies 'more than 25% decrease' -> meteorological drought" },
            { t: "% decrease in Year 2", w: "(100 - 80) / 100 x 100 = 20% decrease in rainfall" },
            { t: "Compare with the 25% criterion", w: "20% < 25% -> does not meet the drought criterion, but is still a rainfall shortfall" },
          ], ans: "Year 1 (70 cm, 30% deficient) = Drought. Year 2 (80 cm, 20% deficient) = Deficiency of moisture (not full drought)." },
          { k: "list", items: [
            "<b>≥ 25% rainfall deficiency</b> → Drought (S2 p.5)",
            "<b>26% – 50% rainfall deficiency</b> → Moderate drought (S2 p.5)",
            "<b>> 50% rainfall deficiency</b> → Severe drought (S2 p.5)",
          ] },
          { k: "note", t: "<b>Drought-prone year</b> (for a country): a year is called a drought-prone year for a country if more than 20% of the country's area is affected by severe drought. (S2 p.5)" },
          { k: "def", term: "Hydrological drought", t: "When the presence/availability of water in streams, lakes and various underground sources falls below average, it is called hydrological drought. It may occur due to low rainfall, poor management of water, or increasing demand for water. (S2 p.5)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Meteorological drought sirf ek cheez dekhta hai — baarish kam hui ya nahi (rainfall ka directly deficiency). Hydrological drought ek step aage hai — stream, lake aur groundwater mein actual <i>available water</i> kam hai ya nahi, aur yeh kam baarish se, ya galat water management se, ya demand badhne se bhi ho sakta hai (matlab baarish normal bhi ho to bhi hydrological drought aa sakta hai agar demand/mismanagement zyada hai)." },
          { k: "real", t: "Hydrological drought ke teen causes yaad rakho — low precipitation, poor water management, increasing water demand. In teeno mein sirf pehla naturally-driven hai; doosre do insaan-driven hain (reservoir operation, groundwater over-extraction, badhti population/irrigation demand) — isliye hydrological drought management dono (supply + demand side) par focus karta hai. (S2 p.5)" },
        ],
      },
      {
        n: "10.3",
        title: "Agricultural drought and the Aridity Index",
        hi: "कृषि सूखा और शुष्कता सूचकांक (Aridity Index)",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.6" },
          { k: "def", term: "Agricultural drought", t: "Characterised by a deficiency of moisture required for the growth of crops (plants). It is expressed by the Aridity Index (A.I). (S2 p.6)" },
          { k: "def", term: "PET — Potential Evapotranspiration", t: "The amount of water consumed by a plant for its optimum growth, under sufficient (perfect) moisture conditions. (S2 p.6)" },
          { k: "def", term: "AET — Actual Evapotranspiration", t: "The amount of water consumed by a plant under the existing (actual) moisture conditions. (S2 p.6)" },
          { k: "note", t: "Always: <b>PET ≥ AET</b>, so <b>0 ≤ AET/PET ≤ 1</b>. AET = 0 for a fully dry soil (plant can draw no water at all). (S2 p.6)" },
          { k: "note", t: "Source sketch: two plants side by side — <b>Plant A</b> with upward arrows labelled PET and a noted moisture content (M.C.) = 5% at its base; <b>Plant B</b> with upward arrows labelled AET and moisture content also noted as 5% — illustrating PET as the water loss under ideal/potential conditions versus AET as what the plant actually manages to lose/use under the real soil-moisture condition. The source also notes a crop needs about 20% soil moisture to grow to its full potential. (S2 p.6)" },
          { k: "eq", expr: "A.I = [1 - AET/PET] x 100 = [(PET - AET)/PET] x 100", where: [
            ["A.I", "Aridity Index, in % (S2 p.6)"],
            ["PET", "Potential Evapotranspiration (S2 p.6)"],
            ["AET", "Actual Evapotranspiration (S2 p.6)"],
          ] },
          { k: "list", items: [
            "A.I = 0 → Non-arid zone (S2 p.6)",
            "0 < A.I ≤ 25% → Mild arid zone (S2 p.6)",
            "25% < A.I ≤ 50% → Moderate arid zone (S2 p.6)",
            "A.I > 50% → Severe arid zone (S2 p.6)",
          ] },
          { k: "p", t: "<b>Arid</b> = deficiency of moisture. (S2 p.6)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "PET ko 'plant ki zaroorat' aur AET ko 'plant ko mila kitna' samjho. Jitna zyada gap PET aur AET ke beech, utna zyada A.I (aridity), yaani soil utni hi zyada moisture-deficient hai crop ke liye. A.I = 0 ka matlab AET = PET — plant ko jo chahiye woh poora mil raha hai (non-arid), aur A.I jitna 100% ke paas jaayega utna hi AET, PET se door (severe arid)." },
          { k: "trap", t: "PET aur AET ko ulta mat karo — PET <b>'maang' (demand/potential)</b> hai, AET <b>'mila' (actual supply)</b> hai. PET hamesha ≥ AET hota hai, kabhi ulta nahi. (S2 p.6)" },
        ],
      },
      {
        n: "10.4",
        title: "Impact and mitigation measures for each drought type",
        hi: "हर प्रकार के सूखे का प्रभाव और उपचारात्मक उपाय",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.6" },
          { k: "p", t: "The source summarises the three types of drought (§10.1–10.3) in a single branching chart — 'Drought' splitting into Meteorological / Hydrological / Agricultural — with each type's impact and remedy. (S2 p.6)" },
          { k: "cmp", t: "Impact and remedy by drought type (S2 p.6)", cols: ["Impact", "Remedy / mitigation"], rows: [
            ["Meteorological", "Water-cycle imbalance", "(i) Control evaporation (ii) Cloud seeding — enhances precipitation"],
            ["Hydrological", "Reduction of water supply", "Water harvesting"],
            ["Agricultural", "Reduction of crop yield", "(i) Water harvesting (ii) Change of land use of crop"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno type ka remedy dekho to ek pattern dikhta hai — <b>water harvesting</b> do jagah (hydrological aur agricultural) repeat hota hai, kyunki dono ka core issue 'available water kam hai' hota hai — harvesting us available water ko badhane ka direct tareeka hai. Meteorological drought ka remedy alag hai (evaporation control, cloud seeding) kyunki uska issue rainfall/water-cycle ka hi imbalance hai, available stored water ka nahi." },
          { k: "real", t: "Cloud seeding (artificial precipitation-enhancement) aur water harvesting dono practically India mein drought-mitigation ke liye use hote hain — cloud seeding meteorological drought (kam baarish) ke time, aur water harvesting hydrological/agricultural drought (kam available water / soil moisture) ke time par zyada relevant hai. (S2 p.6)" },
        ],
      },
      {
        n: "10.5",
        title: "Quick revision — droughts",
        hi: "त्वरित पुनरावृत्ति — सूखा",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Drought = climatic anomaly, insufficient moisture supply over a long period; hydrological extreme like flood, opposite end of the same spectrum (S2 p.5).",
            "I.O.W = (Year's rainfall / ≥30-yr average) × 100; I.O.W=100% no deficiency, >100% flood; deficiency classes Large (30–45%), Severe (45–60%), Disastrous (>60%) (S2 p.4).",
            "Drought-prone zone: 0.20 ≤ P ≤ 0.40; chronically drought-prone: P > 0.40 (S2 p.5).",
            "National Commission on Agriculture (1976): Meteorological, Hydrological, Agricultural drought — three types in this source (S2 p.5–6).",
            "Meteorological drought: >25% rainfall decrease (<75% of normal); IMD sub-classes Drought ≥25%, Moderate 26–50%, Severe >50% (S2 p.5).",
            "Hydrological drought: streams/lakes/groundwater below average — due to low ppt, poor water management, or rising demand (S2 p.5).",
            "Agricultural drought: A.I = [(PET−AET)/PET]×100; zones Non-arid (0), Mild (0–25%), Moderate (25–50%), Severe (>50%) (S2 p.6).",
            "Impact + remedy: Meteorological → water-cycle imbalance → evaporation control/cloud seeding; Hydrological → reduced water supply → water harvesting; Agricultural → reduced crop yield → water harvesting + land-use change (S2 p.6).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Drought and flood are the two extremes of one anomaly spectrum — 'mini drought' to 'maxi flood' (S2 p.5).",
            "PET ≥ AET always; A.I = [1 − AET/PET] × 100 is the agricultural-drought measure (S2 p.6).",
            "Water harvesting is the common remedy to both hydrological and agricultural drought; meteorological drought's remedy targets the rainfall/water-cycle side instead (evaporation control, cloud seeding) (S2 p.6).",
            "This is a single-source (S2 p.4–6) chapter — no cross-source conflicts to reconcile; one source-flagged illegible item (a station name in the worked example) was kept honestly unresolved rather than invented.",
          ] },
        ],
      },
    ],
  });
})();
