/* MACE Academy SOM notes — Shear stresses in beams, M p.138–143 — inserted into som chapter 4 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 4; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------- M p.138 */
    {
      n: "",
      title: "MACE notes — Shear force, shear stress and the shear stress equation",
      hi: "कर्तन बल, कर्तन प्रतिबल और कर्तन प्रतिबल समीकरण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.138" },
        { k: "p", t: "<b>V-1 Ch. ★ Shear stresses in Beams</b> (M p.138)" },
        { k: "def", term: "Shear force", t: "Any force which acts <b>tangentially or parallel</b> to any plane is called shear force. (M p.138)" },
        { k: "def", term: "Shear stress (τ)", t: "Any shear force acting tangentially on a plane gets distributed on the entire plane. Thus the stress induced due to shear force is termed <b>shear stress</b>, which can be calculated by the following formula:<br>τ = (Shear force) / (Area parallel to the force) = N/m² (M p.138)" },
        { k: "eq", expr: "★ τ = S / (b·d)", where: [
          ["S", "shear force"],
          ["b, d", "edges of the plane (area parallel to the force = b × d)"],
        ] },
        { k: "p", t: "Figure (M p.138): a 3-D sketch of a block whose face has edges <b>b</b> and <b>d</b>; the shear force <b>S</b> is drawn as an upward arrow lying in that face (parallel to the plane)." },
        { k: "h", t: "★ Assumptions in the analysis of shear (M p.138)" },
        { k: "list", items: [
          "Material is homogeneous, isotropic and obeys Hooke's law.",
          "Material is elastic and has the same modulus of elasticity in tension and compression.",
          "★ Shear stress is <b>constant along the width</b>, and variation of shear stress is observed <b>along the depth only</b>, i.e. there is only normal bending because only lateral vertical loads are applied on the beam.",
        ] },
        { k: "eg", title: "MACE notes example — assumed variation of shear stress (MCQ)", given: "Q. Variation of shear is assumed ______\na) Along the length only   b) To vary along the depth   c) To vary along the width   d) To vary along both depth & width", steps: [
          { t: "From the assumptions", w: "Shear stress is constant along the width; variation is observed along the depth only." },
        ], ans: "(b) To vary along the depth (ticked in the notes) (M p.138)" },
        { k: "h", t: "★ Shear stress equation (M p.138)" },
        { k: "eq", expr: "★ τ = (S · As · ȳ) / (I · b)        Trick → \"say bI\"", where: [
          ["S", "shear force at the section"],
          ["I", "moment of inertia of the entire section (about the NA)"],
          ["b", "width of the layer at a distance y from NA"],
          ["As", "shaded area (area above the layer considered)"],
          ["ȳ", "centroidal distance of A shaded from NA"],
          ["y", "distance of the fibre above which A shaded is considered"],
        ] },
        { k: "p", t: "Memory trick (M p.138): read the numerator–denominator as <b>\"S A ȳ … say bI\"</b> — the denominator is <b>b·I</b> (width × moment of inertia)." },
        { k: "list", items: [
          "Figure (M p.138), top: a cantilever fixed at the left end (hatched wall), NA as a dashed line along the beam axis; a vertical section line marked ①—① at mid-span; a small distance y marked above the NA.",
          "Figure (M p.138), bottom — \"@ section ①-①\": rectangular cross-section with the NA at mid-depth; a strip at the top is hatched (the shaded area As) with its lower boundary dashed; arrow <b>y</b> from the NA up to the lower boundary of the shaded strip; arrow <b>ȳ</b> from the NA up to the centroid of the shaded strip.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "τ = S/(b·d) sirf <b>average</b> batata hai — poora shear force poore area par barabar baant diya. Asli beam mein shear stress depth ke saath badalta hai, isliye notes ka main formula τ = S·As·ȳ/(I·b) hai. Yeh wahi formula hai jo is chapter ke 'Shear stress distribution in beams' section mein q = F·aȳ/(I·b) likha hai — sirf naam alag hain: S = F, As·ȳ = aȳ, τ = q." },
        { k: "p", t: "As·ȳ ka matlab: jis level par stress chahiye, uske <b>upar</b> (ya neeche) ka area lo, aur us area ka NA ke about first moment nikaalo. Width b usi level ki chaudai hai, poore section ki nahi. Isi liye assumption hai ki stress width ke across constant hai aur sirf depth ke saath badalta hai." },
        { k: "trap", t: "Students ȳ ko 'layer ki NA se doori (y)' le lete hain. Galat — <b>y</b> us layer ki doori hai jiske upar area liya, aur <b>ȳ</b> us shaded area ke <b>centroid</b> ki NA se doori hai. Rectangle mein ȳ = y + ½(d/2 − y), y nahi." },
      ],
    },

    /* ---------------------------------------------------- M p.139 */
    {
      n: "",
      title: "MACE notes — Rectangular section: shear stress distribution and τmax = 1.5 τavg",
      hi: "आयताकार खंड — कर्तन प्रतिबल वितरण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.139" },
        { k: "p", t: "<b>★ Standard shear stress variation diagram — I) Rectangular section</b> (M p.139)" },
        { k: "list", items: [
          "Let S = shear force",
          "As = b · (d/2 − y)",
          "ȳ = ½ (d/2 − y) + y",
          "I = bd³/12",
        ] },
        { k: "p", t: "Figure (M p.139): rectangle of width b and depth d; NA at mid-depth with d/2 above and d/2 below. The top strip is hatched (shaded area) with its centroid shown by a dot. Arrow <b>y</b> from the NA to the bottom of the shaded strip; arrow <b>ȳ</b> from the NA to the centroid of the strip; dimension <b>(d/2 − y)</b> spans the shaded strip. At the NA level: \"y = 0, τ = max\"." },
        { k: "steps", items: [
          "τ = S·As·ȳ / (I·b)",
          "= S · [b(d/2 − y)] · [½(d/2 − y) + y] / ((bd³/12) · b)",
          "= (12·S/bd³) [ ½(d/2 − y)² + y(d/2 − y) ]",
          "= (12·S/bd³) [ ½(d²/4 − dy + y²) + dy/2 − y² ]",
          "= (12·S/bd³) [ d²/8 − dy/2 + y²/2 + dy/2 − y² ]  (the dy/2 terms cancel)",
          "= (12·S/bd³) [ d²/8 − y²/2 ]",
          "<b>τ = (12/8)(S/bd³)[d² − 4y²]</b> ..... τ ∝ y² ... <b>parabolic variation</b>",
        ] },
        { k: "eq", expr: "τ = (12/8) · (S / bd³) · (d² − 4y²)", where: [
          ["y", "distance of the layer from the NA"],
          ["b, d", "width and depth of the rectangle"],
        ] },
        { k: "cmp", t: "Values at the NA and at the extreme layer (M p.139)", cols: ["Working", "Result"], rows: [
          ["@ y = 0 (at NA)", "τmax = (3/2)(S/bd³) × [d² − 0]", "<b>τmax = (3/2)(S/bd)</b>"],
          ["@ y = d/2 (extreme layer)", "τ = (3/2)(S/bd³)[d² − 4(d/2)²]", "<b>τ = 0</b>"],
        ] },
        { k: "p", t: "But S/(bd) = average shear stress, i.e. <b>τavg = S/(b·d)</b> (M p.139)" },
        { k: "eq", expr: "★ τmax = (3/2) τavg = 1.5 τavg   i.e. τmax is 50% more than τavg", where: [] },
        { k: "list", items: [
          "Figure (M p.139) (1): rectangle, width b, d/2 above and d/2 below the NA; top strip shaded with its centroid dot; labelled τavg below.",
          "Figure (M p.139) (2): shear stress distribution — a parabola, τ = 0 at the top, τmax at the NA (y = 0), τ = 0 at the bottom (y = d/2); a vertical dashed line marks the τavg width.",
          "Figure (M p.139) (3): uniform (rectangular) block of constant width τavg from top to bottom, labelled τavg = S/(b·d).",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Parabola kyun? Jaise-jaise layer NA ki taraf aati hai, uske upar ka shaded area As badhta jaata hai, lekin us area ka centroid NA ke paas aata jaata hai. Dono ka product As·ȳ = (b/2)(d²/4 − y²) — y² wala term isko parabola banata hai. Top par shaded area zero hai isliye τ = 0; NA par As·ȳ sabse bada hai isliye τ max." },
        { k: "p", t: "Is chapter ka main section yahi result q = (F/2I)(d²/4 − y²) likhta hai. Dono same hain: (F/2I)(d²/4 − y²) mein I = bd³/12 rakho to (12/8)(F/bd³)(d² − 4y²) hi aata hai." },
        { k: "trap", t: "τavg = S/(bd) ko 'max' samajh kar answer de dena. Rectangle mein peak NA par 1.5 guna hai. Aur ulta galti: 1.5 factor circular section par laga dena — wahan factor 4/3 hai." },
        { k: "real", t: "Timber beams mein horizontal shear (NA ke paas grain ke along split) aksar fail hone ka kaaran hota hai — kyunki max shear wahin NA par hota hai aur timber grain ke along shear mein kamzor hai." },
      ],
    },

    /* ---------------------------------------------------- M p.140–141 */
    {
      n: "",
      title: "MACE notes — Rectangular section numericals",
      hi: "आयताकार खंड — संख्यात्मक प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.140–141" },
        { k: "eg", title: "MACE notes example — cantilever with UDL: τmax at free end, mid span and fixed end", given: "Que 1) A rectangular beam 200 mm wide and 360 mm deep is subjected to uniformly distributed load on its entire span and is fixed at one end while free at the other end. If the length of beam is 2 m and the intensity of load is 1 kN/m, find out the maximum shear stress at i) free end ii) mid span iii) fixed end.", steps: [
          { t: "Data", w: "b = 200 mm, d = 360 mm\nReaction at fixed end = 1 × 2 = 2 kN\nSFD: 2 kN at fixed end → 1 kN at mid span → 0 kN at free end (linear)" },
          { t: "τavg = S/(bd)", w: "@ fixed: 2000/(200 × 360) = 1/36 MPa\n@ middle: 1000/(200 × 360) = 1/72 MPa\n@ free: 0" },
          { t: "τmax = (3/2) τavg", w: "@ fixed: 1/24 MPa = 0.041 MPa\n@ middle: 1/48 MPa = 0.020 MPa\n@ free: 0" },
        ], ans: "τmax = 0 at free end, 0.020 MPa (1/48) at mid span, 0.041 MPa (1/24) at fixed end (M p.140)" },
        { k: "p", t: "Figure (M p.140): cantilever fixed at the left (hatched wall), free at the right, length 2 m, UDL 1 kN/m over the entire span; mid-span marked (1 m + 1 m). Reaction 2 kN upward at the fixed end. SFD below: 2 kN at the fixed end decreasing linearly to 1 kN at mid-span and 0 kN at the free end." },
        { k: "note", t: "<b>Check:</b> 1/24 = 0.0417 MPa and 1/48 = 0.0208 MPa; the notes' 0.041 and 0.020 are these values truncated to three decimals." },
        { k: "eg", title: "MACE notes example — maximum shear stress in a 100 × 250 mm section", given: "Que 2) Shear force at a section was found to be 25 kN. If the cross-section of rectangular beam is 100 mm × 250 mm deep, what will be the maximum shear stress in the section?", steps: [
          { t: "Rectangle", w: "τmax = (3/2) τavg = (3/2) × S/(bd)\n= (3/2) × (25 × 10³)/(100 × 250)" },
        ], ans: "τmax = 1.5 MPa (M p.140)" },
        { k: "eg", title: "MACE notes example — cantilever under axial tension only (MCQ)", given: "Que 3) A cantilever beam of rectangular cross-section 200 × 200 mm is subjected to axial tension at the free end. If the magnitude of axial tension was 10 kN, find out the maximum shear stress at the free end at NA of section. Choose the correct option: a) 10 MPa  b) 0 MPa  c) 1 MPa  d) 1.5 MPa", steps: [
          { t: "Loading", w: "Axial tension 10 kN at the free end; reaction 10 kN (horizontal) at the fixed end; vertical reaction 0.\nSFD: zero line." },
          { t: "Shear stress", w: "No vertical load → no shear force (S = 0)\nτ = S·A·ȳ/(I·b) = 0" },
        ], ans: "τ = 0 → option (b) 0 MPa (ticked in the notes) (M p.140)" },
        { k: "list", items: [
          "If loads are normal to the cross-section and axial, then shear force will be zero. (M p.140)",
        ] },
        { k: "eg", title: "MACE notes example — effect of doubling width and depth on τavg", given: "Que 4) Average shear stress on a section was 4.5 MPa for a shear force of magnitude S. If the depth of the section and the width of the section both were doubled, what will be the shear stress?", steps: [
          { t: "Original", w: "τavg = 4.5 MPa\nτavg = S/(b·d)\nτ1 = S/(b·d)" },
          { t: "Doubled section", w: "τ2 = S/(2b · 2d) = (1/4)(S/bd)\nτ2 = (1/4) × 4.5 = 1.125 MPa" },
          { t: "Notes' remark", w: "means 25 times less than τavg." },
        ], ans: "τ2 = 1.125 MPa (M p.141)" },
        { k: "note", t: "<b>Check:</b> the answer 1.125 MPa is right, but the remark \"25 times less than τavg\" is a slip. 1.125/4.5 = 0.25, so the new stress is <b>4 times less</b> (it is <b>25% of</b> the original τavg, i.e. 75% less)." },
        { k: "h", t: "Conclusion (M p.141)" },
        { k: "list", items: [
          "1) Shear stress distribution is <b>parabolic</b> in nature, varying from <b>zero at the extreme fibre</b> to <b>maximum value at the N.A</b>.",
          "2) If we plot the average shear stress distribution, it is <b>rectangular (uniform)</b>.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Que 1 ka idea: shear stress section par depend karta hai shear force S par, aur S beam ki length ke saath SFD se badalta hai. Cantilever + UDL mein S fixed end par max (wL), free end par zero — isliye τmax bhi fixed end par sabse zyada aur free end par zero. Pehle SFD banao, phir har section par 1.5·S/(bd)." },
        { k: "p", t: "Que 4: area b·d → 2b·2d = 4 guna, to stress ¼. Ratio ka sawaal hai — S aur original b, d ki value ki zaroorat hi nahi." },
        { k: "trap", t: "Axial load wala MCQ (Que 3): 10 kN dekh kar log 10/(200×200) ya 1.5 × uska answer nikaal lete hain. Axial force section ke <b>normal</b> hai, tangential nahi — isse sirf normal (direct) stress aata hai, shear force S = 0, isliye τ = 0." },
      ],
    },

    /* ---------------------------------------------------- M p.141–142 */
    {
      n: "",
      title: "MACE notes — Circular section and circular tube/ring",
      hi: "वृत्ताकार खंड और खोखला वृत्ताकार (रिंग) खंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.141–142" },
        { k: "p", t: "<b>II) Circular section</b> (M p.141)" },
        { k: "steps", items: [
          "τavg = (shear force)/(Area) = S / ((π/4) × D²)",
        ] },
        { k: "eq", expr: "★ τavg = 4S / (πD²)    &    ★ τmax = 16S / (3πD²)", where: [
          ["S", "shear force"],
          ["D", "diameter of the section"],
        ] },
        { k: "eq", expr: "τmax = (4/3) × τavg = 1.33 τavg  (at the NA)", where: [] },
        { k: "p", t: "Figure (M p.141): three sketches with a dashed line through the centre (NA). (1) Circle of diameter D. (2) Uniform rectangular shear-stress block with horizontal arrows, labelled τavg. (3) Curved (half-round looking) distribution: τ = 0 at the top, τ = 0 at the bottom, maximum at the NA labelled \"τmax = (4/3) × τavg\" and \"τmax = 1.33 τavg\"." },
        { k: "eg", title: "MACE notes example — τmax vs τavg in a circular section (MCQ)", given: "Que 1) A circular section of diameter D is subjected to shear force of magnitude S at section x—x. The maximum shear stress is ------ the average shear stress.\na) 33% lesser  b) 75% more  c) 50% more  d) 33% more", steps: [
          { t: "Circle", w: "τmax = (4/3) τavg\n= 1.33 τavg\n= (1 + 0.33) τavg\n= τavg + 0.33 τavg  ∴ τmax is 33% more" },
        ], ans: "(d) 33% more (ticked in the notes) (M p.141)" },
        { k: "eg", title: "MACE notes example — wooden circular section, τmax from τavg", given: "Que 2) A circular section of diameter 0.5 m made up of wood is subjected to average shear stress of 1.10 MPa. What will be the magnitude of maximum shear stress?", steps: [
          { t: "Circle", w: "τavg = 1.1 MPa\nτmax = 1.33 × τavg = 1.33 × 1.1 = 1.33 × [1 + 1/10]\n= 1.33 + 0.133" },
        ], ans: "τmax = 1.463 MPa (M p.142)" },
        { k: "note", t: "<b>Check:</b> the notes round 4/3 to 1.33. With the exact factor, τmax = (4/3) × 1.1 = <b>1.467 MPa</b>; the notes' 1.463 MPa is the rounded-factor value. The diameter 0.5 m is not needed — only the ratio is used." },
        { k: "eg", title: "MACE notes example — shear stress at the NA of a 40 cm diameter section (MCQ)", given: "Que 3) Shear force at a section was found to be 3.14 N. If the diameter of the section is 40 cm, find the shear stress at the neutral axis of the section.\na) 0  b) 1 MPa  c) 0.5 MPa  d) none", steps: [
          { t: "At NA, circle", w: "τmax = (4/3) τavg\n= (4/3) [4·S/(πD²)]    ∵ D = 40 cm = 400 mm\n= (4/3) × (4/3.14) × 3.14/(400)²   (3.14 cancels)\n= (4 × 4)/3 × 1/(4 × 4 × 10⁴)   (4 × 4 cancels)\n= 0.33 × 10⁻⁴ MPa" },
        ], ans: "τmax = 0.000033 MPa (M p.142)" },
        { k: "note", t: "<b>Check:</b> exact value = (4/3) × 4 × 3.14/(3.14 × 400²) = 1/(3 × 10⁴) = <b>3.33 × 10⁻⁵ MPa</b>, which agrees with the notes' 0.33 × 10⁻⁴ MPa. None of options (a)–(c) equals this, so the option is <b>(d) none</b> (the notes do not tick an option). In the scan the diameter unit is overwritten; the working uses D = 40 cm = 400 mm." },
        { k: "h", t: "III) Circular tube / ring (M p.142)" },
        { k: "eq", expr: "A = (π/4)(D² − d²)   ;   ★ τavg = 4·S / (π(D² − d²))   ;   ★ τmax = 8·S / (π(D² − d²))", where: [
          ["D", "external diameter"],
          ["d", "internal diameter"],
          ["S", "shear force"],
        ] },
        { k: "eq", expr: "★ τmax = 2 τavg", where: [] },
        { k: "p", t: "Figure (M p.142): annular (ring) section with outer diameter D and inner diameter d, a dotted line through the centre (NA). Beside it a uniform rectangular shear-stress block with horizontal arrows labelled τavg, and the boxed result τmax = 2 τavg." },
        { k: "eg", title: "MACE notes example — hollow circular section with D = 2d", given: "Que 1) What is the maximum shear stress in case of a hollow circular section if shear force of S N acts on the section while the external diameter is twice the internal diameter?", steps: [
          { t: "Ring", w: "τmax = 2 × τavg\n= 2 × S/((π/4)(D² − d²))\n= (8·S/π) × 1/[(2d)² − d²]\n= 8·S/(π[3d²])" },
        ], ans: "τmax = 8·S/(3πd²) (M p.142)" },
        { k: "note", t: "<b>Check:</b> τmax = 2 τavg is exact only for a <b>thin</b> ring (D ≈ d). Working τ = S·As·ȳ/(I·b) at the NA of a thick tube (As·ȳ = (D³ − d³)/12, b = D − d, I = π(D⁴ − d⁴)/64) gives τmax/τavg = (4/3)(D² + Dd + d²)/(D² + d²). For D = 2d this is (4/3)(7/5) = 28/15 ≈ <b>1.87</b>, so τmax = 112·S/(45πd²) ≈ 2.49·S/(πd²), about 7% below the notes' 8·S/(3πd²) ≈ 2.67·S/(πd²). The ratio tends to 2 as the wall gets thin, and to 4/3 when d → 0 (solid circle)." },
        { k: "note", t: "<b>Source difference:</b> this chapter's main shear section does not give a numerical factor for the hollow circle (it only notes the shape of the distribution). The MACE notes' τmax = 2 τavg is the thin-tube value; the general thick-tube ratio is the one re-derived in the Check above. For exam MCQs that say 'thin ring/tube', use 2." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Circle mein NA par width sabse zyada (b = D) hoti hai, isliye peak rectangle jitna nahi uthta — sirf 4/3 guna. Ring mein NA par width sirf do patli deewaron ki hoti hai (b = D − d), aur shear zyada tar wahi deewarein uthati hain — isliye peak average ka lagbhag 2 guna ho jaata hai." },
        { k: "trap", t: "Ring ke sawaal mein τavg likhte waqt area (π/4)D² le lena — galat. Area hamesha (π/4)(D² − d²). Aur 'D = 2d' wale sawaal mein (2d)² − d² = 3d², 4d² − d² ko bhool kar 4d² mat likho." },
        { k: "real", t: "Steel tubular sections (CHS) in trusses and scaffolding pipes are thin-walled, so the τmax ≈ 2 τavg rule of the notes is a good quick estimate for them." },
      ],
    },

    /* ---------------------------------------------------- M p.143 */
    {
      n: "",
      title: "MACE notes — Triangular, diamond (square with diagonal horizontal) and I-section",
      hi: "त्रिकोणीय, विकर्ण-क्षैतिज वर्ग और I-खंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.143" },
        { k: "p", t: "<b>IV) Triangular section</b> (M p.143)" },
        { k: "list", items: [
          "<b>(★ Imp)</b> ∴ τmax is at <b>h/2</b> distance (i.e. at the middle of the section, not at the N.A).",
          "∴ <b>τmax = 3·S/(b·h)</b>",
          "∴ <b>τN.A = 8·S/(3·b·h)</b>",
          "★ (boxed beside the triangle) τmax = (9/8) τavg",
          "★ <b>τmax &gt; τNA &gt; τavg</b>",
        ] },
        { k: "p", t: "Figure (M p.143): (1) triangle, apex up, height h, base b; the N.A shown as a dotted line through the centroid (marked with a dot). (2) Shear-stress distribution — a curved profile, zero at the apex and at the base, maximum τmax at h/2 from the top (★, arrow h/2), and a smaller τN.A marked at the N.A level below it. (3) Uniform rectangular block of horizontal arrows labelled τavg." },
        { k: "note", t: "<b>Check:</b> for the triangle the boxed \"τmax = 9/8 τavg\" does not follow from the notes' own results. τavg = S/(bh/2) = 2S/(bh), so τmax/τavg = (3S/bh)/(2S/bh) = <b>3/2</b>, and τN.A/τavg = (8S/3bh)/(2S/bh) = <b>4/3</b>. The 9/8 ratio belongs to the diamond (next item). Working from τ = S·As·ȳ/(I·b) with width b·y/h at depth y from the apex, I = bh³/36, NA at 2h/3 from the apex: τ = (12S/bh³)·y(h − y), maximum at y = h/2 giving 3S/(bh), and at y = 2h/3 giving 8S/(3bh) — confirming both boxed formulas." },
        { k: "note", t: "<b>Source difference:</b> this chapter's main shear section gives triangle q_max = (3/2) q_avg (at h/2) and q_NA = (4/3) q_avg — that is correct and matches the MACE notes' own τmax = 3S/(bh) and τN.A = 8S/(3bh). The MACE notes' boxed 9/8 next to the triangle is the slip; use 3/2 for the triangle." },
        { k: "p", t: "<b>V) Square placed with diagonal horizontal</b> (M p.143)" },
        { k: "eq", expr: "★ τmax = (9/8) τavg", where: [] },
        { k: "p", t: "Figure (M p.143): a square placed as a diamond, both diagonals dashed (one horizontal = NA, one vertical). Beside it the shear-stress distribution with two curved lobes: the maxima are at <b>3h/8 from the top</b> and <b>3h/8 from the bottom</b> (h = full vertical diagonal), with a reduced value (a cusp) at the horizontal diagonal (NA)." },
        { k: "eg", title: "MACE notes example — average shear stress from τmax in a square (diamond) section", given: "Que 1) In case of square section, maximum shear stress is 6.0 MPa. Find out average shear stress.", steps: [
          { t: "Square with diagonal horizontal", w: "τavg = ? ;  τmax = (9/8) τavg\n(6 × 8)/9 = τavg" },
        ], ans: "τavg = 5.3 MPa (M p.143)" },
        { k: "note", t: "<b>Check:</b> 48/9 = 5.33 MPa, so 5.3 MPa is correct (rounded). The notes first wrote \"Rect\" and struck it out for \"square\": the 9/8 factor applies to a square with its <b>diagonal horizontal</b>; a square with sides horizontal is just a rectangle (τmax = 1.5 τavg, which would give 4.0 MPa)." },
        { k: "p", t: "<b>VI) I-section</b> (M p.143)" },
        { k: "list", items: [
          "<b>Flange</b> → to resist <b>bending</b>.",
          "<b>Web</b> → to resist <b>shear</b>.",
          "Figure (M p.143): I-section with top and bottom flanges and a web; the N.A (dashed) at mid-depth. Beside it the shear-stress distribution: small values in the flanges (width marked τflange), a <b>sudden jump</b> at the flange–web junction, and a large parabolic bulge in the web with the maximum <b>\"τmax @ web\"</b> at the N.A.",
        ] },
        { k: "p", t: "The formulas for the I-section are in this chapter's 'Shear stress distribution in beams' section: τmax = (S/8I)[(B/t_w)(D² − d²) + d²], with the jump by B/t_w at the junction." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Triangle aur diamond mein max NA par kyun nahi? Formula mein b denominator mein hai. NA ki taraf jaate hue As·ȳ badhta hai, lekin in shapes mein width b bhi tezi se badhti hai. Ek point ke baad width zyada tezi se badhti hai, to τ ghatne lagta hai — isliye peak NA se pehle aa jaata hai: triangle mein h/2 par, diamond mein NA se h/8 upar/neeche (3h/8 top se)." },
        { k: "p", t: "I-section ka rule yaad rakho: <b>flange bending, web shear</b>. Flange chaudi (B) hai to wahan stress chhota, web patla (t_w) hai to wahan stress achanak B/t_w guna uchhal jaata hai." },
        { k: "trap", t: "Triangle ke liye 9/8 likh dena (jaisa notes mein box hai) — galat. Triangle: τmax = 1.5 τavg (h/2 par), τNA = 4/3 τavg. Sirf <b>diamond</b> (square, diagonal horizontal) ka factor 9/8 hai. Order yaad rakho: triangle mein τmax &gt; τNA &gt; τavg." },
        { k: "real", t: "Steel I-beams ka shear design web area (D × t_w) par hota hai, flanges ko shear mein ignore karte hain — notes ka 'web to resist shear' wahi baat hai." },
      ],
    },

    /* ---------------------------------------------------- Revision */
    {
      n: "",
      title: "MACE notes revision — Shear stresses in beams (M p.138–143)",
      hi: "पुनरावृत्ति — शहतीर में कर्तन प्रतिबल",
      blocks: [
        { k: "h", t: "✅ Key points — MACE notes M p.138–143" },
        { k: "list", items: [
          "✅ Shear force: acts tangentially or parallel to a plane; shear stress τ = shear force / area parallel to the force = S/(b·d), unit N/m². (M p.138)",
          "✅ Assumptions: homogeneous, isotropic, obeys Hooke's law; elastic with same E in tension and compression; τ constant along the width, varies along the depth only. (M p.138)",
          "✅ τ = S·As·ȳ/(I·b) — trick \"say bI\"; I of the whole section, b = width at the layer, As = shaded area, ȳ = its centroid from NA. (M p.138)",
          "✅ Rectangle: τ = (12/8)(S/bd³)(d² − 4y²) — parabolic; τ = 0 at y = d/2; τmax = (3/2)S/(bd) = 1.5 τavg at the NA (50% more). (M p.139)",
          "✅ Cantilever 200 × 360 mm, 2 m, 1 kN/m: τmax = 0 (free), 0.020 MPa (mid), 0.041 MPa (fixed). (M p.140)",
          "✅ S = 25 kN on 100 × 250 mm → τmax = 1.5 MPa. (M p.140)",
          "✅ Axial load only → S = 0 → τ = 0. (M p.140)",
          "✅ b and d both doubled → τavg becomes ¼: 4.5 → 1.125 MPa (4 times less; notes wrote '25 times'). (M p.141)",
          "✅ Conclusion: actual distribution parabolic (zero at extreme fibre, max at NA); average distribution rectangular/uniform. (M p.141)",
          "✅ Circle: τavg = 4S/(πD²), τmax = 16S/(3πD²) = (4/3)τavg = 1.33 τavg (33% more). (M p.141)",
          "✅ Wooden circle, τavg = 1.1 MPa → τmax = 1.463 MPa (exact 1.467). (M p.142)",
          "✅ S = 3.14 N, D = 40 cm → τNA = 0.33 × 10⁻⁴ MPa = 0.000033 MPa → option (d) none. (M p.142)",
          "✅ Ring/tube: τavg = 4S/(π(D² − d²)), τmax = 8S/(π(D² − d²)) = 2 τavg (thin ring); D = 2d → τmax = 8S/(3πd²) (thick-tube exact ≈ 1.87 τavg). (M p.142)",
          "✅ Triangle: τmax at h/2 = 3S/(bh) = 1.5 τavg; τNA = 8S/(3bh) = (4/3)τavg; τmax &gt; τNA &gt; τavg (notes' boxed 9/8 for the triangle is a slip). (M p.143)",
          "✅ Square with diagonal horizontal (diamond): τmax = (9/8)τavg, at 3h/8 from top and bottom; τmax = 6 MPa → τavg = 5.3 MPa. (M p.143)",
          "✅ I-section: flange resists bending, web resists shear; small τ in flange, sudden jump at junction, τmax in the web at NA. (M p.143)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
