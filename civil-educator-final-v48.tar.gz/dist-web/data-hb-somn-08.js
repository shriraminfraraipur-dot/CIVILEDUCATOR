/* MACE Academy SOM notes — Principal-stress special cases and MCQs, maximum shear derivation, Mohr's circle (definition, sign convention, construction, pole, 2θ rule, numericals, standard circles), M p.157–167 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- 1 */
    {
      n: "",
      title: "MACE notes — Principal stresses: the five special cases and the four master formulas",
      hi: "मुख्य प्रतिबल — पाँच विशेष स्थितियाँ और चार मुख्य सूत्र",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.157" },
        { k: "p", t: "<b>Normal stress on one plane with shear (σy = 0, σx ≠ 0, τxy ≠ 0) — principal stresses, concluded from M p.156:</b> (M p.157)" },
        { k: "eq", expr: "σ₁ OR σ₂ = σx/2 ± (1/2)√(σx² + 4τxy²)   OR   σ₁ OR σ₂ = (1/2)(σx ± √(σx² + 4τxy²))  (★ boxed)", where: [
          ["σx", "the only normal stress (σy = 0)"],
          ["τxy", "shear stress on the x-face"],
        ] },
        { k: "h", t: "Summary sketch — the general case and the special cases that follow from it (M p.157)" },
        { k: "list", items: [
          "Figure (M p.157), centre — <b>Case ii) (general element)</b>: a square element with tensile σx (horizontal arrows on both sides), tensile σy (vertical arrows up and down) and shear τxy (top edge →, right edge ↑, bottom edge ←, left edge ↓). A small hatched element sits on a dashed red inclined plane drawn through the square, with angle θ marked at the bottom-right corner. Four red arrows lead out to the special cases, each labelled with a boxed condition:",
          "Arrow labelled <b>[σy = 0, τxy = 0]</b> → <b>case i)</b> (upper left): only horizontal tensile σx — <i>uniaxial stress</i>. (M p.157)",
          "Arrow labelled <b>[σy = 0]</b> → <b>case iv)</b> (upper right): tensile σx plus shear τxy on all four edges, no σy — <i>normal stress on one plane with shear</i>. (M p.157)",
          "Arrow labelled <b>[τxy = 0]</b> → <b>case iii)</b> (right): σy = σ₂ (vertical) and σx = σ₁ (horizontal), no shear — <i>biaxial stress, the given planes are principal planes</i>. (M p.157)",
          "Arrow labelled <b>[σx = 0, σy = 0]</b> → <b>case v)</b> (left): only shear τxy (top →, right ↑, bottom ←, left ↓) — <i>pure shear</i>. (M p.157)",
          "Under case ii) an arrow ⇓ points to the four master equations below. (M p.157)",
        ] },
        { k: "note", t: "<b>Label difference inside the notes:</b> on M p.155–156 pure shear is headed \"Case iv)\" and \"normal stress on one plane with shear\" is headed \"Case (v)\"; the p.157 summary sketch swaps these two labels. The physics is the same — read the case by its condition (σy = 0, or σx = σy = 0), not by its roman numeral." },
        { k: "eq", expr: "① σn OR σn′ = (σx + σy)/2 ± ((σx − σy)/2)·cos2θ ± τxy·sin2θ", where: [
          ["σn", "normal stress on the plane at θ (take the + signs)"],
          ["σn′", "normal stress on the plane perpendicular to it (take the − signs)"],
        ] },
        { k: "eq", expr: "② τ′xy = −((σx − σy)/2)·sin2θ + τxy·cos2θ", where: [
          ["τ′xy", "shear stress on the plane inclined at θ"],
        ] },
        { k: "eq", expr: "③ σ₁ OR σ₂ = (σx + σy)/2 ± √[((σx − σy)/2)² + τxy²]", where: [
          ["σ₁, σ₂", "major and minor principal stresses"],
        ] },
        { k: "eq", expr: "④ tan2θp = 2τxy/(σx − σy)", where: [
          ["θp", "inclination of the principal plane"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the older p.6 notes in §2.5 printed the shear formula with both terms positive. MACE formula ② has the minus sign on the first term — this <b>agrees with the corrected formula given in §2.5</b>. Re-derived check: put tan2θp = 2τxy/(σx − σy) into ②; then −((σx − σy)/2)·sin2θp + τxy·cos2θp = cos2θp·[−((σx − σy)/2)·tan2θp + τxy] = cos2θp·[−τxy + τxy] = 0, as it must be on a principal plane. So ② (MACE) is right." },
        { k: "def", term: "Unloaded body (side box)", t: "For an unloaded body: σ₁ = 0, σ₂ = 0, τm = 0, and τ = 0 on any plane. (M p.157)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Yaad rakhne ka tareeka: sirf ek hi general element hai (case ii) — σx, σy, τxy teeno ke saath. Baaki saare cases usi ke formulas mein kuch terms ko zero rakh kar milte hain. σy = 0 rakho to case iv, τxy = 0 rakho to case iii (principal planes already given), σx = σy = 0 rakho to pure shear. Isliye alag-alag formula ratne ki zaroorat nahi — chaar master formulas ①–④ yaad karo, aur condition lagao." },
        { k: "p", t: "Formula ① mein ± ka matlab: + lo to plane θ par σn, − lo to uske perpendicular plane par σn′. Dono ko jodo to σn + σn′ = σx + σy — yeh sum kabhi nahi badalta (invariant), jo §2.5 mein quick check ke roop mein diya hai." },
        { k: "trap", t: "Formula ③ ke andar <b>(σx − σy)/2</b> ka square hai, (σx − σy) ka nahi. σy = 0 wale case mein yahi (σx/2)² = σx²/4 banta hai — isliye p.157 ke upar wale formula mein √(σx² + 4τxy²) ke bahar <b>½</b> aata hai. Students ½ bhool kar principal stress double nikal dete hain." },
      ],
    },

    /* ---------------------------------------------------------- 2 */
    {
      n: "",
      title: "MACE notes — MCQs on principal stresses, principal planes and maximum shear (Q1–Q8)",
      hi: "मुख्य प्रतिबल और अधिकतम अपरूपण पर बहुविकल्पीय प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.157–159" },
        { k: "p", t: "Figure for Q1–Q5 (M p.157): a cube marked \"100×100×100 mm³\" with vertical tensile arrows (up and down) labelled <b>22 mpa ← major</b> and horizontal tensile arrows (left and right) labelled <b>10 mpa</b>, with \"minor ↓\" written above in red. No shear is drawn." },
        { k: "eg", title: "MACE notes example — Q1: major and minor principal stresses (★)", given: "For the given state of stress (cube 100×100×100 mm³: 22 MPa vertical tension, 10 MPa horizontal tension, no shear), find out the major and minor principal stresses. Options: a) 22.5 & 10.9 MPa  b) 22 & 12 MPa  c) 22 & 10 MPa  d) 19 & 14 MPa", steps: [
          { t: "No shear on the faces", w: "τxy = 0, so the given faces are themselves principal planes" },
          { t: "Read off the stresses", w: "major σ₁ = 22 MPa (vertical);  minor σ₂ = 10 MPa (horizontal)" },
        ], ans: "Option (c): 22 MPa and 10 MPa (M p.157)" },
        { k: "eg", title: "MACE notes example — Q2: shear stress on the principal plane", given: "In the above Q1, find out the shear stress on the principal plane. Options: a) 12 MPa  b) 6 MPa  c) 28 MPa  d) 0", steps: [
          { t: "Definition of a principal plane", w: "a principal plane carries only normal stress; shear on it is zero" },
        ], ans: "Option (d): 0 (M p.157)" },
        { k: "eg", title: "MACE notes example — Q3: maximum shear stress for the Q1 figure", given: "In the above Q1, find out the maximum shear stress corresponding to the figure given in Q1. Options: a) 6 MPa  b) 0  c) 12 MPa  d) 22 MPa", steps: [
          { t: "Maximum shear from principal stresses", w: "τm = (σ₁ − σ₂)/2 = (22 − 10)/2 = 12/2 = 6 MPa" },
        ], ans: "Option (a): τm = 6 MPa (M p.157)" },
        { k: "eg", title: "MACE notes example — Q4: normal stress on the plane of maximum shear", given: "Find out the normal stress on the plane of maximum shear for the same given data of Q1.", steps: [
          { t: "Normal-stress formula", w: "σn = (σx + σy)/2 + ((σx − σy)/2)cos2θ + τxy sin2θ,  with τxy = 0" },
          { t: "Plane of maximum shear", w: "θ = 45°\n(σn)45 = (σ₁ + σ₂)/2 + ((σ₁ − σ₂)/2)cos90,  cos90 = 0" },
          { t: "Substitute", w: "σn = (σ₁ + σ₂)/2 = (22 + 10)/2 = 32/2 = 16 MPa" },
        ], ans: "σn = 16 MPa @ 45° (M p.158)" },
        { k: "eg", title: "MACE notes example — Q5: resultant stress on the plane of maximum shear", given: "What is the resultant stress for the given question (Q1) on the plane of maximum shear?", steps: [
          { t: "Resultant of normal and shear stress", w: "σR = √(σn² + τmax²) = √(16² + 6²) = √(256 + 36) = √292" },
        ], ans: "σR = √292 (left unsimplified in the notes) (M p.158)" },
        { k: "note", t: "<b>Check:</b> √292 = 17.09 MPa (16² + 6² = 256 + 36 = 292 ✔). The notes stop at √292; the value is 17.09 MPa." },
        { k: "p", t: "Figure for Q6 (M p.158): a cube with sides 100 mm, 100 mm, 100 mm; a horizontal force of 1 KN on two opposite faces (→ 1 KN and ←) and a vertical force of 0.5 KN (arrows up and down), with the red note \"0.5 KN ← force given\". Answer sketch: the same cube with the horizontal arrow labelled <b>0.1 mpa (major)</b> and the vertical arrow labelled <b>0.05 mpa (minor)</b>." },
        { k: "eg", title: "MACE notes example — Q6: principal stresses in a cube from applied forces", given: "For the following loading condition on a cube (100 mm sides; 1 kN horizontal, 0.5 kN vertical), find out the magnitudes of major and minor principal stresses. Options: a) 0.5 MPa, 1 MPa  b) 1 MPa, 0.5 MPa  c) 1 kN, 0.5 kN  d) 0.1 MPa, 0.05 MPa", steps: [
          { t: "Stress = force / face area", w: "σx = 1000 N / (100 × 100 mm²) = 0.1 MPa\nσy = 500 N / (100 × 100 mm²) = 0.05 MPa" },
          { t: "No shear", w: "so the given planes are principal planes" },
        ], ans: "Option (d): major 0.1 MPa, minor 0.05 MPa (M p.158)" },
        { k: "p", t: "Figure for Q7 (M p.158): a square element with shear only — top edge → labelled 1 KN, right edge ↑, bottom edge ←, left edge ↓. Answer sketch: the same element with the top arrow labelled 0.1 mpa." },
        { k: "eg", title: "MACE notes example — Q7: principal stresses under pure shear force", given: "Find out the magnitude of major and minor principal stresses generated in a cube of dimension 100×100 mm, with the load applied as shown (1 kN shear on each face, pure shear). Options: a) 0.01 MPa, 0.01 MPa  b) +0.01 MPa, +0.05 MPa  c) 0.01 MPa both  d) 0.05 MPa both  e) +0.1 MPa & −0.1 MPa", steps: [
          { t: "Shear stress", w: "τxy = 1000 N / (100 × 100 mm) [as written; the area is 100 × 100 mm²] = 0.1 MPa" },
          { t: "Principal-stress formula", w: "σ₁ & σ₂ = (σx + σy)/2 ± √[((σx − σy)/2)² + τxy²]\n(σx + σy)/2 = 0 and (σx − σy)/2 = 0 (no normal stress)" },
          { t: "Result", w: "σ₁, σ₂ = ± τxy\nσ₁ = + τxy = + 0.1 MPa;  σ₂ = − τxy = − 0.1 MPa" },
        ], ans: "Option (e): +0.1 MPa and −0.1 MPa (M p.158)" },
        { k: "eg", title: "MACE notes example — Q8: normal stress on the plane of maximum shear in pure shear", given: "Find out the normal stress in the previous question (Q7) on the plane of maximum shear.", steps: [
          { t: "Normal stress on the plane of maximum shear", w: "σn = (σ₁ + σ₂)/2 = (+0.1 − 0.1)/2 = 0" },
          { t: "Reason", w: "this is a case of pure shear, so the normal stress on the plane of maximum shear is directly zero" },
        ], ans: "σn = 0 (M p.159)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "In MCQs ka pattern ek hi hai: pehle dekho shear hai ya nahi. Shear nahi hai (Q1, Q6) to faces hi principal planes hain — bada wala major, chhota wala minor, kuch calculate nahi karna. Shear hai aur normal stress nahi (Q7) to pure shear: σ₁ = +τ, σ₂ = −τ. Phir τmax = (σ₁ − σ₂)/2 aur max-shear plane par σn = (σ₁ + σ₂)/2 — yeh dono Mohr's circle ka radius aur centre hain." },
        { k: "p", t: "Q4 ka 16 MPa yaad rakho: maximum-shear plane par normal stress zero nahi hota (jab tak σ₁ + σ₂ = 0 na ho, jaise pure shear Q8). Isliye us plane par resultant stress (Q5) sirf τmax nahi, √(σn² + τmax²) hota hai." },
        { k: "note", t: "<b>General Engineering Knowledge:</b> Q3's 6 MPa is the <i>in-plane</i> maximum shear (in the plane of the 22 and 10 MPa stresses). When both principal stresses have the same sign and the third principal stress is zero, the <i>absolute</i> maximum shear (3-D) is σ₁/2, which is larger. MCQs that say \"absolute maximum shear\" want that value; the notes' Q3 asks for the in-plane value." },
        { k: "trap", t: "Force ko seedha stress mat likho — Q6 ke option (c) \"1 KN, 0.5 KN\" isi galti ke liye rakha gaya hai. Stress = force/area: 1000 N ÷ 10 000 mm² = 0.1 MPa. Aur mm ko mm² likhna mat bhoolo (notes ke Q7 mein bhi \"100×100 mm\" likha hai, area 100 × 100 mm² hai)." },
      ],
    },

    /* ---------------------------------------------------------- 3 */
    {
      n: "",
      title: "MACE notes — Maximum shear stress: derivation (Q9) and its special cases",
      hi: "अधिकतम अपरूपण प्रतिबल — व्युत्पत्ति और विशेष स्थितियाँ",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.159–160" },
        { k: "p", t: "Figure for Q9 (M p.159): a square element with σy (vertical arrows up/down), σx (horizontal arrows both sides) and τxy on all four edges (top →, right ↑, bottom ←, left ↓). τ′xy = shear stress on any plane inclined at angle θ; its maximum is wanted." },
        { k: "eg", title: "MACE notes example — Q9 (★ Imp): maximum shear stress for a general state of stress", given: "Find out the maximum shear stress for the given state of stress (σx, σy, τxy).", steps: [
          { t: "Shear on any plane at θ", w: "τ′xy = −((σx − σy)/2) sin2θ + τxy cos2θ  ——①" },
          { t: "Differentiate w.r.t. θ and equate to zero (to find the plane of maximum shear, θm)", w: "d(τ′xy)/dθ = −((σx − σy)/2) cos2θ × 2 + τxy(−sin2θ) × 2\n= −(σx − σy) cos2θ − 2τxy sin2θ = 0\n(σx − σy) cos2θ = −2τxy sin2θ" },
          { t: "Plane of maximum shear (★ boxed in the notes)", w: "tan2θm = (σx − σy)/(2τxy)   [σx − σy = opposite side; 2τxy = adjacent side]" },
          { t: "Right triangle ABC", w: "base AB = 2τxy, vertical side BC = (σx − σy), hypotenuse AC = √((σx − σy)² + 4τxy²), angle 2θm at A\nsin2θm = (σx − σy)/AC;  cos2θm = 2τxy/AC" },
          { t: "Substitute in ①", w: "τ′xy = τmax = −((σx − σy)/2) sin2θm + τxy cos2θm\n= −((σx − σy)/2)((σx − σy)/AC) + τxy × (2τxy/AC)\n= −(1/AC)[(σx − σy)²/2 + 2τxy²]\n= −(1/√((σx − σy)² + 4τxy²))[(σx − σy)²/2 + 4τxy²]   [as written]\n= −(1/2)(1/√((σx − σy)² + 4τxy²))[(σx − σy)² + 4τxy²]\n= −(1/2)√((σx − σy)² + 4τxy²)" },
          { t: "Result (★★, case ii, boxed)", w: "τmax = ± √[((σx − σy)/2)² + τxy²]" },
          { t: "In absence of shear (τxy² → 0), boxed", w: "τmax = ± (σx − σy)/2" },
        ], ans: "τmax = ± √[((σx − σy)/2)² + τxy²]; with no shear, τmax = ± (σx − σy)/2 (M p.159)" },
        { k: "note", t: "<b>Check:</b> the final boxed result is correct, but three intermediate lines are not. (1) From the notes' own line (σx − σy)cos2θ = −2τxy sin2θ, dividing by cos2θ gives <b>tan2θm = −(σx − σy)/(2τxy)</b>; the minus sign is dropped in the box. (2) With the notes' sin2θm = (σx − σy)/AC and cos2θm = 2τxy/AC, the substitution gives (1/AC)[−(σx − σy)²/2 + 2τxy²], not −(1/AC)[(σx − σy)²/2 + 2τxy²]; e.g. for σx = 80, σy = −40, τxy = 30 this is −40.2, not the maximum. (3) The line with \"+ 4τxy²\" inside the bracket should read \"+ 2τxy²\" (it becomes 4τxy² only after the ½ is taken out, as the next line does). Correct route: with tan2θm = −(σx − σy)/(2τxy), sin2θm = −(σx − σy)/AC and cos2θm = 2τxy/AC, so τmax = (1/AC)[(σx − σy)²/2 + 2τxy²] = (1/2)·AC = √[((σx − σy)/2)² + τxy²] — the same boxed answer (for σx = 80, σy = −40, τxy = 30 it gives 67.08, matching worked example 2.9)." },
        { k: "note", t: "<b>Source difference:</b> the older p.7 notes in §2.6 also write Tan2θs = (σx − σy)/2τxy, and §2.6 already corrects this to tan2θs = −(σx − σy)/(2τxy). The MACE derivation on M p.159, read line by line, confirms the minus sign (see the Check above). Both sources agree on the result that matters: τmax = √[((σx − σy)/2)² + τxy²] and the max-shear planes lie 45° from the principal planes." },
        { k: "p", t: "Figure (M p.159): a small square element with normal stresses only (arrows up, down, left, right) — the \"absence of shear\" case." },
        { k: "h", t: "Principal stresses in terms of τmax (M p.160)" },
        { k: "eq", expr: "σ₁ OR σ₂ = (σx + σy)/2 ± τmax   ⇒   σ₁ OR σ₂ = (σx + σy)/2 ± √[((σx − σy)/2)² + τxy²]  (boxed)", where: [
          ["(σx + σy)/2", "average normal stress = centre of Mohr's circle"],
          ["τmax", "maximum shear stress = radius of Mohr's circle"],
        ] },
        { k: "cmp", t: "Maximum shear stress — special cases (M p.160)", cols: ["Condition", "τm"], rows: [
          ["①", "σx = 0", "± √(σy²/4 + τxy²)"],
          ["②", "σy = 0", "± √(σx²/4 + τxy²)"],
          ["③", "σy = 0, τxy = 0", "± √(σx²/4) = σx/2"],
          ["④", "σx = 0, τxy = 0", "± √(σy²/4) = σy/2"],
          ["⑤", "τxy = 0", "√(((σx − σy)/2)²) = (σx − σy)/2"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Derivation ka idea simple hai: τ′xy θ ka function hai, to uska maximum wahan hoga jahan dτ′/dθ = 0. Us angle ke sin aur cos ek right triangle se nikaal kar formula mein daalo — √ wala term aa jaata hai. Yaad rakhne layak result: τmax = √[(half-difference)² + τ²] — yahi Mohr's circle ka radius hai, aur principal stresses = centre ± radius." },
        { k: "p", t: "Special cases ko alag ratna nahi hai — general formula mein jo zero hai woh hata do. Uniaxial σx mein τmax = σx/2: isi liye ductile steel ka tension specimen 45° par slip lines dikhata hai." },
        { k: "trap", t: "Sign ka dhyan: notes ke box mein tan2θm = (σx − σy)/(2τxy) likha hai, par derivation khud minus deta hai. MCQ mein agar sirf τmax ka magnitude poocha hai to fark nahi padta, lekin agar max-shear plane ka angle aur direction poocha hai to minus sign wala form use karo, warna galat plane par pahunchoge (jahan shear maximum nahi hota)." },
      ],
    },

    /* ---------------------------------------------------------- 4 */
    {
      n: "",
      title: "MACE notes — Mohr's circle: definition, sign convention and plotting steps",
      hi: "मोर का वृत्त — परिभाषा, चिह्न परिपाटी और रचना",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.160–162" },
        { k: "h", t: "2) Graphical method (Mohr's circle method) (M p.160)" },
        { k: "def", term: "Mohr's circle (★)", t: "A plot of normal stress on the x-axis, called the <b>σ-axis</b>, and shear stress on the y-axis, called the <b>τ-axis</b>. In general, Mohr's circle is made up of the locus of the various combinations of normal stress and shear stress corresponding to the various planes in a loaded element. (M p.160)" },
        { k: "list", items: [
          "σn on the x-axis (σ-axis); τ on the y-axis (τ-axis). (M p.160)",
          "Generally σn = fn(σx, σy, τxy, θ) and τ′xy = fn(σx, σy, τm [as written; i.e. τxy], θ). (M p.160)",
          "For any given loading (σx, σy and τ fixed): σn = fn(θ) and τ′xy = fn(θ). (M p.160)",
          "For any given θ (plane), σn and τ are unique. (M p.160)",
        ] },
        { k: "note", t: "<b>NOTE (M p.160):</b> In a loaded body, for any given load system, there exist an infinite number of inclined planes inside the body. Every plane carries a unique combination of σn and τ. Since there are infinite planes in a body, there are infinite possible combinations of normal stress and shear stress. If we plot all these combinations on a graph and join them, they form a circle — this is called Mohr's circle." },
        { k: "h", t: "Plotting of Mohr's circle — given element and sign convention (M p.161)" },
        { k: "p", t: "Figure (M p.161), given element: a square with σy (arrow up on top), σx (arrow → on the right face), and shear: top edge ←, right edge ↓, bottom edge →, left edge ↑. Let σx &gt; σy. A 3-D cube beside it shows τyx on the top face (arrow ←, face marked \"y\") and τxy on the right face (arrow ↓, face marked \"x\"), with the box <b>τyx = τxy</b> (complementary shear)." },
        { k: "cmp", t: "Sign convention box (M p.161)", cols: ["Shear", "Normal"], rows: [
          ["+ve", "↑[+]↓ — the pair of shears turns the element clockwise (↻)", "←[+]→ — arrows outward: Tension (T)"],
          ["−ve", "↓[−]↑ — the pair turns the element anticlockwise (↺)", "→[−]← — arrows inward: Compression (C)"],
        ] },
        { k: "list", items: [
          "① x-face: σx → with τxy ↓ (clockwise, +ve) ⇒ point <b>(σx, τxy)</b>. (M p.161)",
          "② y-face: σy ↑ with τyx ← (anticlockwise, −ve) ⇒ point <b>(σy, −τyx)</b>. (M p.161)",
        ] },
        { k: "steps", items: [
          "<b>Step i)</b> Draw the σ-axis (horizontal) and the τ-axis (vertical). (M p.161)",
          "<b>Step ii)</b> Plot the coordinates (σx, τxy) and (σy, −τyx) and join them with a straight line. Figure: point B (σx, τxy) above the σ-axis on the right, point A (σy, −τyx) below the σ-axis on the left; line AB cuts the σ-axis at C. (M p.161)",
          "<b>Step iii)</b> The straight line cuts the σ-axis at point C. It can easily be proved that C is the centre of Mohr's circle. Hence draw a circle with centre at C and radius AC or BC, i.e. AB is the diameter of the circle. (M p.161)",
          "<b>Step iv)</b> The extreme topmost point M of the circle denotes maximum shear stress. Similarly the extreme bottom-most point N denotes maximum shear stress, but the top and bottom points are opposite in nature even though they are equal in magnitude. (M p.162)",
          "The extreme rightmost point E gives the maximum normal stress, called the <b>major principal stress (σ₁)</b>. (M p.162)",
          "The extreme leftmost point D gives the minimum normal stress, called the <b>minor principal stress (σ₂)</b>. (M p.162)",
          "Mohr's circle cuts the x-axis (σ-axis) at two different locations, D and E; at these points the shear stresses are zero (τ = 0). (M p.162)",
        ] },
        { k: "p", t: "<b>Main figure (M p.161)</b> — \"Read all steps first, then see the diagram\": τ-axis vertical, σ-axis horizontal; centre C on the σ-axis. Points on the circle: <b>M (σn, τmax)</b> topmost, with a dashed line to the τ-axis labelled τmax; <b>N (σn, −τmax)</b> bottom-most (dashed vertical M–C–N); <b>B (σx, τxy)</b> upper right, labelled \"normal stress on x-plane\"; <b>A (σy, τyx)</b> lower left, with AB a diameter through C; <b>D (σ₂, 0)</b> leftmost, labelled \"min normal stress (minor principal stress)\"; <b>E (σ₁, 0)</b> rightmost, labelled \"max normal stress (major principal stress)\"; <b>P</b> on the circle at lower right, labelled \"Pole\", with the vertical line BP labelled \"x-plane\" and the horizontal line AP meeting it at a right angle at P; <b>O</b> a point on the circle just right of M, joined to P, with angle θ at P between PO and PB and angle 2θ at C between CO and CB; the arc between CB and CA at C is marked 180°. Dimensions from the τ-axis: σ₂ to D/A, σ₁ to E." },
        { k: "eq", expr: "τmax = MC = radius of circle = (diameter of circle)/2 = DE/2   ⇒   τmax = (σ₁ − σ₂)/2  (★ boxed)", where: [
          ["DE", "diameter = σ₁ − σ₂"],
        ] },
        { k: "h", t: "Important conclusions — interpretation of planes (M p.162)" },
        { k: "list", items: [
          "Any vertical plane in the element is the <b>x-plane</b>, while any horizontal plane is the <b>y-plane</b>. (M p.162)",
          "The <b>radial lines</b> in a Mohr's circle show planes. Example: BC is the x-plane and σx is the stress on that plane; AC is the y-plane and σy is the stress on that plane. (M p.162)",
          "Similarly CE is the major principal plane, on which σ₁ (major principal stress) acts; CD is the minor principal plane, on which σ₂ (minor principal stress) acts. (M p.162)",
          "Figure (M p.162): the square element with normal and shear stresses; a red vertical line along the right face labelled \"x-plane\", a red horizontal line along the top face labelled \"y-plane\"; a red dashed inclined line through the element at angle θ from the vertical (x-plane); below, a small rotated element on the inclined plane with σn (normal arrow) and τ′xy (shear along the plane), angle θ between the inclined plane and the vertical.",
        ] },
        { k: "note", t: "<b>NOTE (★★★, M p.162):</b> If we mark any angle θ on the loaded element, that θ becomes <b>two times (2θ)</b> on Mohr's circle. Example: in the real (loaded) body the x-axis and y-axis lie at 90° to each other; however, the same axes shown on Mohr's circle lie at 180° (BC and AC show the x-axis and y-axis respectively, and the angle between BC and AC is 180°)." },
        { k: "note", t: "<b>Source difference:</b> §2.6 plots τ <i>positive downward</i> with X = (σx, τxy) and Y = (σy, −τxy), τxy taken positive when it acts upward on the right face (anticlockwise couple). MACE plots τ <i>positive upward</i> but calls a <b>clockwise</b> shear positive. Re-derived: an anticlockwise x-face shear is +τxy in §2.6 and goes below the axis; in MACE it is −ve and also goes below the axis. A clockwise x-face shear goes above the axis in both. So the two rules draw the <b>same circle with the same points</b> — only the word \"positive\" is attached differently. Use one convention throughout a problem." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har plane ek point hai, aur saare points milkar circle banate hain — yahi Mohr's circle hai. Bas do points chahiye: x-face (σx, τxy) aur y-face (σy, −τyx). Yeh dono ek doosre ke opposite (diameter ke dono ends) par hote hain, kyunki element mein x aur y faces 90° par hain aur circle par angle double ho jaata hai — 180°." },
        { k: "p", t: "Circle se seedha padho: right end = σ₁, left end = σ₂, top/bottom = ±τmax, centre = (σ₁ + σ₂)/2. σ-axis par jahan circle katta hai wahan τ = 0 — isliye principal planes par shear zero hota hai, yeh formula ke bina dikh jaata hai." },
        { k: "trap", t: "Y point ko (σy, +τyx) plot karna sabse common galti hai — complementary shear τyx = τxy magnitude mein barabar hai par y-face par uski ghumne ki direction ulti hai (clockwise ki jagah anticlockwise), isliye Y hamesha (σy, −τyx) hai. Agar dono points σ-axis ke ek hi side aa gaye to circle galat hai — AB diameter ko σ-axis cross karna hi chahiye (jab tak τ = 0 na ho)." },
        { k: "real", t: "Site par stress seedha nahi naapte, strain gauges se naapte hain; strains bhi isi tarah ke Mohr's circle par chalte hain (§2.6 ka strain-rosette example). RCC beam ke support ke paas diagonal cracks isi principal tension direction mein bante hain jo circle ke σ₁ point se milti hai." },
      ],
    },

    /* ---------------------------------------------------------- 5 */
    {
      n: "",
      title: "MACE notes — The pole of Mohr's circle and why θ becomes 2θ",
      hi: "मोर वृत्त का ध्रुव (पोल) और 2θ नियम",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.163" },
        { k: "steps", items: [
          "The x-plane of the real body can be plotted directly from point B (as a line parallel to the x-plane, i.e. vertical); it cuts the circle at point <b>P</b>. (M p.163)",
          "Similarly the y-plane can be plotted from A as AP (horizontal), and the angle made by these two planes at P is <b>90°</b>. This point P is called the <b>pole</b>. (M p.163)",
          "Since BP is the x-plane, which we also see in the loaded body, an inclined plane in the loaded body at angle θ to the x-plane can be drawn as a line <b>PO at angle θ from BP</b>. (M p.163)",
          "This gives an arc OB, which subtends angle θ at the circumference point P. From the basics of circle geometry, <b>∠OCB = 2θ</b>. (M p.163)",
        ] },
        { k: "def", term: "Circle-geometry rule", t: "Any arc which subtends an angle θ at any point on the circumference of a circle subtends an angle 2θ at the centre of the circle. (M p.163)" },
        { k: "p", t: "Figure \"Basic of geometry\" (M p.163): a circle with centre C; points O (top), B (right, slightly below the centre) and P (lower left) on the circumference; arc OB labelled \"Arc\"; chords PO and PB with angle θ at P; radii CO and CB with angle 2θ at C." },
        { k: "list", items: [
          "Thus we can easily prove that any angle on the element, if plotted on Mohr's circle, becomes double. (M p.163)",
          "(★) From the Mohr's circle diagram we can find normal stress, shear stress etc. by using the geometry of the circle. (M p.163)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Pole ek shortcut hai: P se jo line kisi bhi plane ke parallel kheencho, woh circle ko jis point par kaategi, woh point usi plane ke (σn, τ) deta hai. Isliye pole se angle θ hi naapte hain (asli angle), jabki centre C se wahi arc 2θ dikhta hai. BP ⊥ AP isliye hai kyunki AB diameter hai — semicircle mein bana angle hamesha 90° (Thales)." },
        { k: "p", t: "Matlab do raaste: centre se naapo to 2θ ghumao, pole se naapo to θ. Dono same point O par pahunchte hain." },
        { k: "trap", t: "Pole aur centre ko mix mat karo: centre C se θ (2θ ki jagah) ghuma diya, ya pole P se 2θ ghuma diya — dono mein galat point milega. Rule: <b>C par 2θ, P par θ</b>." },
      ],
    },

    /* ---------------------------------------------------------- 6 */
    {
      n: "",
      title: "MACE notes — Mohr's circle numericals (Q1–Q6)",
      hi: "मोर वृत्त पर संख्यात्मक प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.163–166" },
        { k: "p", t: "Figure for Q1 (M p.163): a 3-D cube with σyy = 2 mpa (arrow up on the top face, marked y), τyx = 0 on the top face, τxy = 0 on the right face (marked x), σxx = 4 mpa (arrow → on the right face). Circle sketch: τ (vertical) vs σn (horizontal); the circle passes through (2, 0) labelled \"y-plane\" and (4, 0) labelled \"x-plane\", centre C; the top point (σn, τm) labelled \"@ 45°\" with a dashed line to the τ-axis labelled τmax; 2θ marked at C between the x-plane radius and the vertical radius; σ₂ measured from the τ-axis to (2, 0) and σ₁ to (4, 0)." },
        { k: "eg", title: "MACE notes example — Q1: maximum shear from a stress matrix by Mohr's circle", given: "For the given stress matrix, find out the magnitude of maximum shear stress by using Mohr's circle method. Stress = [4 0; 0 2]", steps: [
          { t: "Read the matrix", w: "[4 0; 0 2] = [σxx τxy; τyx σyy]\nshear = 0, so the given stresses are principal stresses on principal planes" },
          { t: "Points", w: "x-plane → (4, 0)   [σ, τ]\ny-plane → (2, 0)" },
          { t: "Maximum shear = radius", w: "τmax = diameter/2 = (σ₁ − σ₂)/2 = (4 − 2)/2\nτm = 1 MPa" },
          { t: "Plane of maximum shear", w: "2θ = 90°  ⇒  θ = 45°  OR  270°/2 = 135°" },
        ], ans: "τm = 1 MPa, on planes at θ = 45° or 135° (M p.163)" },
        { k: "eg", title: "MACE notes example — Q2: coordinates of the centre of the circle", given: "In the previous question, find out the coordinates of the centre of Mohr's circle.", steps: [
          { t: "Centre lies on the σ-axis", w: "C = (σn, τ) = (—, 0)  [at the centre line / x-axis]\nso find σn corresponding to τm" },
          { t: "σn at the centre", w: "σn = σ₂ + radius = σ₂ + τm = σ₂ + (σ₁ − σ₂)/2 = (σ₁ + σ₂)/2\n= (4 + 2)/2 = 3 MPa" },
        ], ans: "Coordinates of the centre = (σn, τ) = (3, 0) (M p.164)" },
        { k: "p", t: "Figure for Q3 (M p.164): a square element with compressive σ₂ (vertical arrows pointing inward, top and bottom) and compressive σ₁ (horizontal arrows pointing inward). Options: <b>a)</b> circle entirely to the right of the τ-axis, centre on the σ-axis; <b>b)</b> circle entirely to the left of the τ-axis, centre on the σ-axis; <b>c)</b> circle centred at the origin; <b>d)</b> circle lying below the σ-axis (touching it from below), to the right of the τ-axis." },
        { k: "eg", title: "MACE notes example — Q3: which Mohr's circle fits a biaxial compression element", given: "For the given loaded element (σ₁ and σ₂ both compressive, no shear), which of the following is the correct Mohr's circle? a) right of τ-axis  b) left of τ-axis  c) centred at origin  d) below the σ-axis", steps: [
          { t: "Sign of normal stress", w: "→← C ⇒ −ve;  ←→ T ⇒ +ve" },
          { t: "Both stresses compressive", w: "σ₁ and σ₂ are both compressive, so we draw on the −ve side\nthe circle lies on the left-hand side of the shear-stress axis\ni.e. the centre of the circle lies on the negative normal-stress axis\nboth major and minor principal stresses are negative, since the loading is compressive" },
          { t: "Why not (d) (★ Imp)", w: "Mohr's circle always has its centre on the x-axis, so it is symmetric about the x-axis (normal-stress axis); hence option (d) is never possible" },
          { t: "Options (a) and (c)", w: "possible in some other case of loading" },
        ], ans: "Option (b): circle entirely on the −σ side (M p.164–165)" },
        { k: "p", t: "Answer sketch (M p.164): axes +τ (up), −τ (down), +σn (right), −σn (left); the circle lies wholly on the −σn side; σ₁ is the distance from the origin to the near (right) end of the circle and σ₂ the distance to the far (left) end." },
        { k: "note", t: "<b>NOTE (M p.165):</b> Mohr's circle is always symmetric about the x-axis, but it may or may not be symmetric about the shear-stress axis." },
        { k: "eg", title: "MACE notes example — Q4: Mohr's circle for uniaxial stress σ = [2 0; 0 0]", given: "Plot Mohr's circle for the given stress element/matrix σ = [2 0; 0 0]. Find out: (1) radius of circle, (2) diameter of circle, (3) τmax, (4) angle of obliquity corresponding to τm, (5) normal stress at 15° with the x-plane, (6) distance of the centre of the circle from the origin.", steps: [
          { t: "Read the matrix", w: "σ = [2 0; 0 0] = [σx τxy; τyx σy], so σ₁ = σx = 2" },
          { t: "(1) Radius", w: "radius = σ₁/2 = 2/2 = 1" },
          { t: "(2) Diameter", w: "diameter = σ₁ = 2" },
          { t: "(3) Maximum shear", w: "τmax = τm = σ₁/2 = 1 MPa" },
          { t: "(4) Angle of obliquity corresponding to τm", w: "tanβ = τm/σn = τm/(σ₁/2) = 2τm/σ₁ = (2 × 1)/2\ntanβ = 1  ⇒  β = 45°" },
          { t: "(5) Normal stress at 15° with the x-plane (2θ = 30° on the circle)", w: "σn = AB + BP = σ₁/2 + τm cos30 = σ₁/2 + (σ₁/2)cos30\nσn = 1 + 1 × √3/2 = 1 + 1 × 1.73/2 = 1 + 1 × 0.865 = 1.865 MPa" },
          { t: "(6) Distance of centre from origin", w: "= radius = D/2 = 1" },
        ], ans: "R = 1, D = 2, τmax = 1 MPa, β = 45°, σn(15°) = 1.865 MPa, centre 1 from origin (M p.165)" },
        { k: "note", t: "<b>Check:</b> √3/2 = 0.866, so σn = 1 + 0.866 = <b>1.866 MPa</b> (the notes' 1.865 comes from rounding √3 to 1.73). Cross-check by formula ① with σx = 2, σy = 0, τxy = 0, θ = 15°: σn = 2cos²15° = 1.866 MPa ✔." },
        { k: "p", t: "Figures for Q4 (M p.165): (i) the circle passes through the origin; left point (σ₂, τ₂) = (0, 0), right point (σ₁, τ₁) = (2, 0), top point (σn, τm) = (σ₁/2, τm) = (1, 1); a red line from the origin to the top point makes angle β with the σ-axis; σn is the horizontal distance from origin to centre, τm the vertical from centre to top, σ₁ the diameter. (ii) The same circle with A at (0, 0), centre B, and a red radius τm from B to the point (σθ, τθ) at 2θ = 30° from the σ-axis; P is the foot of the perpendicular from that point to the σ-axis; σn is measured from the τ-axis to P." },
        { k: "p", t: "Figure for Q5 (M p.166): a square in pure shear (top →, right ↑ labelled \"2 mpa = τxy = τm … in pure shear case\", bottom ←, left ↓). Circle sketch: centred at the origin; points (0, 2) at the top and \"(0, 2)\" at the bottom [as written; the bottom point is (0, −2)], (σ₂, 0) on the left, (σ₁, 0) on the right; a red radius to the point (1.73, 1.0) at angle 2θ from the σn-axis; σn = horizontal distance from the origin to the foot of the perpendicular from (1.73, 1.0); radius dimension 2 mpa. A second element sketch shows a red inclined line through the square with \"15° = θ\" marked from the right vertical face, and a small element on that plane with a normal arrow." },
        { k: "eg", title: "MACE notes example — Q5: draw and interpret Mohr's circle for pure shear", given: "For the given loaded element (pure shear, τxy = 2 MPa), draw and interpret Mohr's circle.", steps: [
          { t: "1) Centre", w: "(0, 0)" },
          { t: "2) Maximum shear", w: "τmax = 2 MPa" },
          { t: "3) and 4) Principal stresses", w: "σ₁ = + τmax = + 2 MPa;  σ₂ = − τmax = − 2 MPa" },
          { t: "5) Radius", w: "radius = τmax = 2 MPa" },
          { t: "6) σn at θ = 15°", w: "σn = τm cos2θ = τxy cos2θ = 2 × cos30 = 2 × √3/2\nσn = 1.73 MPa" },
          { t: "Shear on the same plane", w: "τ′xy = τxy sin2θ = 2 × 1/2\nτ′xy = 1 MPa" },
        ], ans: "Centre (0, 0); τmax = 2 MPa; σ₁ = +2, σ₂ = −2 MPa; R = 2 MPa; σn = 1.73 MPa and τ′xy = 1 MPa at θ = 15° (M p.166)" },
        { k: "note", t: "<b>Check:</b> the notes' 1.73 MPa / 1 MPa are the stresses on a plane <b>15° from the major principal plane</b> (the circle sketch turns 2θ = 30° from the (σ₁, 0) point). If θ = 15° is measured from the <b>x-plane</b>, as the element sketch shows and as the notes define θ on M p.162, formulas ① and ② with σx = σy = 0 give σn = τxy sin2θ = 2 × sin30° = <b>1 MPa</b> and τ′xy = τxy cos2θ = 2 × cos30° = <b>1.73 MPa</b> — the two values swap. On the circle this is a turn of 30° from the x-plane point (0, ±2), not from (σ₁, 0)." },
        { k: "p", t: "Figure for Q6 (M p.166): a tank of water with an element at depth H (H dimensioned from the water surface to the element); the element carries compressive σy (vertical arrows inward) and σx (horizontal arrows inward). Labelled sketch \"Hydrostatic condⁿ\": a horizontal σ-axis with a single point labelled (σ₁, 0) (γw·H, 0). A further sketch: a σ-axis with points (σy, 0) and (σx, 0) and a red point between them." },
        { k: "eg", title: "MACE notes example — Q6: Mohr's circle for a fluid element at rest", given: "Draw Mohr's circle for a fluid element at rest.", steps: [
          { t: "At rest", w: "shear = 0" },
          { t: "Pascal's law", w: "fluid exerts equal pressure in all directions\nσx = σy = σv = (γw·H) kPa,  where H = depth of water above the element" },
          { t: "Result", w: "1) Mohr's circle is a point on the normal-stress axis\n2) Radius = 0\n3) Diameter = 0" },
        ], ans: "Mohr's circle reduces to a point (γw·H, 0) on the σ-axis; radius = diameter = 0 (M p.166)" },
        { k: "note", t: "<b>Check (sign only):</b> the fluid pressure is compressive (the element sketch shows inward arrows), so by the notes' own sign convention (M p.161, compression −ve) the point lies at (−γw·H, 0), on the negative σ side. Its magnitude γw·H and the zero radius are as the notes give." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har numerical ka pehla kadam: centre aur radius nikaalo. Centre = (σx + σy)/2, radius = √[((σx − σy)/2)² + τ²]. Phir: σ₁ = centre + R, σ₂ = centre − R, τmax = R, aur max-shear plane par σn = centre. Q1 se Q5 sab isi recipe se nikal jaate hain." },
        { k: "p", t: "Circle ki position bhi kuch batati hai: poora right side (dono tension), poora left (dono compression, Q3), origin se guzarta (uniaxial, Q4), origin par centred (pure shear, Q5), aur ek point (hydrostatic, Q6 — har plane par same stress, shear kahin nahi). Fluid shear nahi le sakta at rest — isliye uska circle ek point hai." },
        { k: "trap", t: "Angle kahan se naapa hai, yeh pehle tay karo — x-plane se ya principal plane se. Pure shear mein x-plane point (0, ±τ) par hai, (σ₁, 0) par nahi; Q5 mein isi wajah se σn aur τ′ ki values ulat jaati hain (Check note dekho). Uniaxial (Q4) mein x-plane hi principal plane hai, isliye wahan dono tareeke same answer dete hain." },
        { k: "real", t: "Hydrostatic (Q6) wali state soil mechanics mein bhi aati hai: jab sab directions mein stress barabar ho to Mohr's circle ek point ban jaata hai aur shear zero — isliye isotropic compression akela soil ya rock ko shear failure tak nahi le jaata; failure ke liye circle ka radius (deviator stress) badhna zaroori hai." },
      ],
    },

    /* ---------------------------------------------------------- 7 */
    {
      n: "",
      title: "MACE notes — Mohr's circles for six standard stress states",
      hi: "विभिन्न प्रतिबल स्थितियों के लिए मोर वृत्त",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.167" },
        { k: "cmp", t: "(★) Mohr's circle for various cases (M p.167)", cols: ["Element", "Mohr's circle"], rows: [
          ["1) Tensile", "σx and σy both tensile (outward) with shear (top ←, right ↓, bottom →, left ↑)", "Lies entirely on the right (+ve side) of the τ-axis, centre on the σn-axis"],
          ["2) Uniaxial tension", "Only horizontal tensile σx = σ₁", "+ve side, touching the τ-axis at the origin; centre on the σn-axis; diameter = σ₁"],
          ["3) Compressive", "Normal stresses compressive (arrows inward on all four faces) with shear (top ←, right ↓, bottom →, left ↑)", "On the −ve side: entirely to the left of the τ-axis, centre on the σn-axis"],
          ["4) Biaxial tension, no shear", "Tensile normal stresses on all four faces (outward), no shear", "Entirely to the right of the τ-axis; σ₂ = distance from τ-axis to the left end, σ₁ = distance to the right end"],
          ["5) Pure shear", "Shear only (top →, right ↑, bottom ←, left ↓)", "Centred at the origin"],
          ["6) σx with shear, σy = 0", "Tensile σx with shear (top ←, right ↓, bottom →, left ↑), no σy", "Crosses the τ-axis (see description below)"],
        ] },
        { k: "p", t: "Figure, case 6 (M p.167): τ – σn axes; red point (σx, τxy) upper right; red point (σy, τyx) on the τ-axis below the σn-axis (σy = 0); a red diameter joins them; a blue vertical radius from the centre to the top of the circle; (σ₂, 0) is the left intersection with the σn-axis (left of the origin) and (σ₁, 0) the right intersection. Dimensions: σ₂ from (σ₂, 0) to the origin, σ₁ from the origin to (σ₁, 0); two equal red distances \"x\" are marked — between (σ₂, 0) and the origin, and between σx and (σ₁, 0)." },
        { k: "note", t: "In all six sketches the centre sits on the σn-axis, as stated with Q3: the circle is always symmetric about the normal-stress axis, but may or may not be symmetric about the shear-stress axis — it is symmetric about the τ-axis only in pure shear (case 5). (M p.164–165, p.167)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Circle ko τ-axis ke saath dekh kar turant stress-state pehchan lo: τ-axis ko na chhue aur right mein ho → dono principal stresses tension; left mein ho → dono compression; τ-axis ko origin par chhue → ek principal stress zero (uniaxial); τ-axis ko cross kare → ek tension, ek compression (case 5 aur 6). Case 6 mein σx aur shear saath hain, isliye σ₁ σx se bada aur σ₂ negative ho jaata hai — dono ke beech ka extra 'x' barabar hota hai kyunki circle centre ke dono taraf symmetric hai." },
        { k: "trap", t: "Case 6 mein students sochte hain ki σy = 0 hai to σ₂ bhi zero hoga. Nahi — shear ki wajah se circle τ-axis ko cross karta hai, aur σ₂ negative (compressive) aata hai, chahe koi compressive load na lagaya ho." },
        { k: "real", t: "Shaft jispar bending (σx) aur torsion (τ) dono hain, ya beam web jahan bending stress aur shear dono hain — dono case 6 hain. Isliye ek axially tensile-loaded member mein bhi kisi inclined plane par compression ho sakta hai; thin webs mein isi se diagonal buckling ka khatra hota hai." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Principal stresses, maximum shear and Mohr's circle (M p.157–167)",
      hi: "पुनरावृत्ति — मुख्य प्रतिबल, अधिकतम अपरूपण और मोर वृत्त",
      blocks: [
        { k: "h", t: "✅ Key points to revise" },
        { k: "list", items: [
          "✅ σy = 0 with shear: σ₁, σ₂ = ½(σx ± √(σx² + 4τxy²)). (M p.157)",
          "✅ σn or σn′ = (σx + σy)/2 ± ((σx − σy)/2)cos2θ ± τxy sin2θ; σn + σn′ = σx + σy. (M p.157)",
          "✅ τ′xy = −((σx − σy)/2)sin2θ + τxy cos2θ — agrees with the corrected formula of §2.5. (M p.157)",
          "✅ σ₁, σ₂ = (σx + σy)/2 ± √[((σx − σy)/2)² + τxy²] = (σx + σy)/2 ± τmax; tan2θp = 2τxy/(σx − σy). (M p.157, p.160)",
          "✅ Unloaded body: σ₁ = σ₂ = τm = 0 and τ = 0 on any plane. (M p.157)",
          "✅ Special cases: uniaxial [σy = 0, τxy = 0], σx with shear [σy = 0], biaxial principal [τxy = 0], pure shear [σx = σy = 0] — the p.157 sketch swaps the iv/v labels used on p.155–156. (M p.157)",
          "✅ Shear on a principal plane = 0; τm = (σ₁ − σ₂)/2 (22 & 10 MPa → 6 MPa). (M p.157)",
          "✅ Normal stress on the max-shear plane = (σ₁ + σ₂)/2 (16 MPa in Q4; 0 in pure shear Q8). Resultant there = √(σn² + τmax²) = √292 = 17.09 MPa. (M p.158–159)",
          "✅ Stress = force/area: 1 kN on 100 × 100 mm² = 0.1 MPa; 0.5 kN → 0.05 MPa. Pure shear τ: σ₁ = +τ, σ₂ = −τ. (M p.158)",
          "✅ τmax = ±√[((σx − σy)/2)² + τxy²]; with no shear τmax = ±(σx − σy)/2. Plane: the derivation gives tan2θm = −(σx − σy)/(2τxy) (notes' box drops the sign). (M p.159)",
          "✅ τm special cases: σx = 0 → √(σy²/4 + τxy²); σy = 0 → √(σx²/4 + τxy²); uniaxial → σ/2; τxy = 0 → (σx − σy)/2. (M p.160)",
          "✅ Mohr's circle = locus of (σn, τ) for all planes; σ on the x-axis, τ on the y-axis; one unique point per plane. (M p.160)",
          "✅ Sign convention: clockwise shear +ve, anticlockwise −ve; tension +ve, compression −ve. Plot (σx, τxy) and (σy, −τyx); τyx = τxy. (M p.161)",
          "✅ Line joining the two points cuts the σ-axis at the centre C; AB is a diameter. (M p.161)",
          "✅ Top/bottom points = ±τmax (equal, opposite in nature); right end = σ₁, left end = σ₂; τ = 0 where the circle cuts the σ-axis. (M p.162)",
          "✅ τmax = radius = DE/2 = (σ₁ − σ₂)/2; centre = (σ₁ + σ₂)/2. (M p.162, p.164)",
          "✅ Radial lines = planes (CB x-plane, CA y-plane, CE major principal plane, CD minor principal plane). Vertical plane = x-plane, horizontal = y-plane. (M p.162)",
          "✅ θ on the element = 2θ on the circle; x and y axes (90°) appear 180° apart. (M p.162)",
          "✅ Pole P: x-plane from B and y-plane from A meet at P at 90°; a plane at θ from BP drawn from P gives the point O, with ∠OCB = 2θ (arc subtends θ at the circumference, 2θ at the centre). (M p.163)",
          "✅ [4 0; 0 2]: τm = 1 MPa at 45° or 135°; centre (3, 0). (M p.163–164)",
          "✅ Both stresses compressive → circle wholly on the −σ side; the circle is always symmetric about the σ-axis (never wholly below it), not necessarily about the τ-axis. (M p.164–165)",
          "✅ Uniaxial σ = 2: R = 1, D = 2, τmax = 1 MPa, angle of obliquity β = 45° (tanβ = τm/σn), σn at 15° = 1.865 (exactly 1.866) MPa, centre 1 from origin. (M p.165)",
          "✅ Pure shear τ = 2 MPa: centre (0, 0), R = τmax = 2, σ₁ = +2, σ₂ = −2 MPa; notes' σn = 1.73, τ′ = 1 MPa at 15° are for a plane 15° from the principal plane (from the x-plane the values swap). (M p.166)",
          "✅ Fluid at rest: σx = σy = γw·H (compressive), no shear — Mohr's circle is a point, radius = diameter = 0. (M p.166)",
          "✅ Six standard circles: both tensile → right of τ-axis; uniaxial → touches the origin; both compressive → left; biaxial without shear → right, ends at σ₂ and σ₁; pure shear → centred at origin; σx with shear → crosses the τ-axis (σ₂ negative). (M p.167)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
