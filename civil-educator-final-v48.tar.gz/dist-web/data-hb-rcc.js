/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   ------------------------------------------------------------
   The second handbook. Where the Structural Analysis handbook is
   built from mechanics and cites methods, this one is built on
   IS 456:2000 and cites clauses — so every design value here
   carries the clause it comes from.

   The copyright line is the same one the rest of this app keeps:
   clause number and heading are navigation facts; the
   explanations, the worked arithmetic and the traps are written
   for this app. The code's text is never reproduced.

   Chapters are registered here; Chapters 1–2 follow in this file
   and later chapters are pushed by data-hb-rcc2.js onwards.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "rcc",
  subject: "rcc",
  name: "Design of RCC Structures",
  hi: "आर.सी.सी. संरचना डिज़ाइन",
  icon: "🏢",
  blurb: "IS 456:2000 ka poora design course — philosophy se detailing tak, har clause ke saath, har example ka hisaab likha hua.",
  note: "Every design value in this handbook names the IS 456:2000 clause it comes from. The code's own text is never reproduced — confirm any value against the published standard before using it in design.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "rcc-1",
      n: 1,
      title: "Design Philosophy",
      hi: "डिज़ाइन दर्शन",
      blurb: "What a design has to deliver, the three methods that have been used to deliver it, and why limit state needs you to calculate the same member twice.",
      mins: 28,
      sections: [
        {
          n: "1.1",
          title: "What a design has to deliver",
          hi: "डिज़ाइन से क्या चाहिए",
          blocks: [
            { k: "p", t: "Analysis ended with a set of forces (Structural Analysis handbook, §1.1). Design begins by asking what section, what grade of concrete and what area of steel can carry them. But strength is only one of four things a design owes, and the other three are the ones that generate complaints." },
            { k: "list", items: [
              "<strong>Safety</strong> — it must not collapse, with an acceptable margin against everything being worse than assumed at once.",
              "<strong>Serviceability</strong> — it must not deflect visibly, crack widely, or vibrate uncomfortably while in normal use.",
              "<strong>Durability</strong> — it must still be able to do both of those after fifty years in the environment it actually sits in.",
              "<strong>Economy</strong> — it must do all of that without wasting material, because the client is paying and concrete has a carbon cost.",
            ]},
            { k: "p", t: "These pull against each other. More cover improves durability and reduces effective depth, which costs strength. A slimmer beam is cheaper and deflects more. Design is the business of settling those trades deliberately rather than by accident, and a design code is the record of how a profession has agreed to settle them." },
            { k: "note", t: "IS 456:2000 is titled a <em>code of practice</em>, not a textbook, and that matters when you read it. It states what must be satisfied and the values to use. It very rarely explains why — that part is what this handbook is for." },
          ],
        },
        {
          n: "1.2",
          title: "Working stress method",
          hi: "वर्किंग स्ट्रेस विधि",
          blocks: [
            { k: "p", t: "The oldest of the three. Keep the stress under service load below a permissible value, obtained by dividing the material strength by a factor of safety. Both concrete and steel are assumed to behave elastically, so the familiar elastic theory of bending applies and the analysis is straightforward." },
            { k: "eq", expr: "σ(calculated under service load)  ≤  σ(permissible) = strength / factor of safety", where: [] },
            { k: "h", t: "Where it breaks down" },
            { k: "list", items: [
              "Concrete is <strong>not elastic</strong> at anything near its strength. Assuming it is misrepresents the real stress block badly at high load.",
              "It says nothing about the actual margin against collapse. Two members with the same working stress can have very different reserves.",
              "It cannot handle the fact that different loads have different uncertainties — dead load is known far better than wind, yet both get the same treatment.",
            ]},
            { k: "p", t: "It survives in IS 456 as Annex B, and it is still required in some situations — liquid-retaining structures under IS 3370 use it because limiting crack width is the governing concern and the elastic model is a better vehicle for that. Knowing it is not optional." },
            { k: "note", t: "<b>Update (v34) — IS 3370 no longer means 'working stress only'.</b> IS 3370 (Part 2):2009 cl. 4.3 lets the designer follow <b>either</b> limit state design (cl. 4.4, with the calculated surface crack width limited to 0.2 mm, and 0.1 mm for more severe exposure per its Annex B) <b>or</b> working stress design (cl. 4.5, with low permissible steel stresses such as 130 N/mm² for deformed bars when checking resistance to cracking). Source: the standard as published on <a href=\"https://law.resource.org/pub/in/bis/S03/is.3370.2.2009.pdf\" target=\"_blank\" rel=\"noopener\">Public.Resource.Org</a>. Working stress is still widely used for water tanks because it is simple and conservative, but it is a choice, not a requirement." },
            { k: "tbl", id: "tb-wsm" },
          ],
        },
        {
          n: "1.3",
          title: "Ultimate load method",
          hi: "अल्टीमेट लोड विधि",
          blocks: [
            { k: "p", t: "The correction to the obvious flaw: instead of keeping service stress low, multiply the service load by a load factor and check that the section can carry the result at its real ultimate capacity, using the true non-linear stress block." },
            { k: "p", t: "That fixes the collapse question and creates a new one. A member designed only for ultimate load can be perfectly safe and still be unusable — deflecting enough to crack the partitions under it, or cracking widely enough to let chlorides reach the steel. The method has no mechanism for noticing." },
            { k: "trap", t: "This is not a historical curiosity. A student who designs a slender beam purely from Mu = 0.87 fy Ast (d − 0.42 xu) and stops there has just used the ultimate load method, whatever they call it. <strong>The deflection check is not an optional extra step; it is the second half of the method.</strong>" },
          ],
        },
        {
          n: "1.4",
          title: "Limit state method",
          hi: "लिमिट स्टेट विधि",
          blocks: [
            { k: "def", term: "Limit state", t: "A state beyond which the structure no longer satisfies the requirements it was designed for." },
            { k: "p", t: "Limit state design takes the honest position: there are several ways a structure can stop being acceptable, they are not all collapse, and each should be checked against the conditions relevant to it. IS 456 Cl. 35 sets this out and divides them in two." },
            { k: "dia", id: "hb-rcc-methods" },
            { k: "h", t: "Limit states of collapse" },
            { k: "list", items: [
              "Flexure — IS 456 Cl. 38",
              "Compression — Cl. 39",
              "Shear — Cl. 40",
              "Torsion — Cl. 41",
              "Overall stability against overturning and sliding — Cl. 20",
            ]},
            { k: "h", t: "Limit states of serviceability" },
            { k: "list", items: [
              "Deflection — Cl. 23.2, with the span-to-depth route in Cl. 23.2.1 and calculation in Annex C",
              "Cracking — Cl. 35.3.2 and Annex F",
              "Vibration, and any other condition that makes the structure unfit for its use",
            ]},
            { k: "p", t: "The decisive design idea is that these two families are checked with <strong>different loads and different material strengths</strong>. That is not a technicality — it is the reason the method works, and it is the subject of §1.6." },
          ],
        },
        {
          n: "1.5",
          title: "Characteristic strength and characteristic load",
          hi: "अभिलाक्षणिक शक्ति और भार",
          blocks: [
            { k: "def", term: "Characteristic strength (IS 456 Cl. 36.1)", t: "The value of the material strength below which not more than 5% of test results are expected to fall." },
            { k: "p", t: "Neither the average nor the minimum. Concrete strength scatters — nominally identical cubes from the same mix differ — so a single number has to be defined statistically, and the code picks the 5% fractile." },
            { k: "dia", id: "hb-rcc-char" },
            { k: "eq", expr: "fck = fm − 1.65 s        so a mix must target    fm = fck + 1.65 s", where: [
              ["fck", "Characteristic cube strength at 28 days — the grade, so M25 means fck = 25 N/mm²"],
              ["fm", "Mean strength the mix must actually achieve"],
              ["s", "Standard deviation, from IS 456 Table 8 until site data exists"],
            ]},
            { k: "p", t: "Two things follow that matter on site. A mix for M25 is designed for a mean well above 25, so most cubes should read above 25 — a batch averaging exactly 25 is <em>failing</em>, not passing. And one low cube does not condemn the concrete; the acceptance criteria of Cl. 16 are written around groups of results precisely because scatter is expected." },
            { k: "cmp", t: "Assumed standard deviation s until site data exists (IS 456 Table 8 / IS 10262)", cols: ["s (N/mm²)", "Source"], rows: [
              ["M10 – M15", "3.5", "EngineeringHulk (IS 10262 table)"],
              ["M20 – M25", "4.0", "EngineeringHulk; InfraLens (M20)"],
              ["M30 and above", "5.0 per IS 456 Table 8 (InfraLens); EngineeringHulk lists 6.0 for M40–M50", "<b>conflict — check the current IS 10262</b>"],
            ] },
            { k: "note", t: "Sources: <a href=\"https://engineeringhulk.com/civil/construction-materials/concrete-technology/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — concrete technology &amp; IS 10262:2019</a>; <a href=\"https://infralens.in/term/target-mean-strength\" target=\"_blank\" rel=\"noopener\">InfraLens — target mean strength</a>. The note under IS 456 Table 8 adds that these values assume good site control (proper cement storage, weigh batching, controlled water, regular checks); where control is poorer they are increased by 1 N/mm² (read from the published IS 456 on <a href=\"https://law.resource.org/pub/in/bis/S03/is.456.2000.pdf\" target=\"_blank\" rel=\"noopener\">Public.Resource.Org</a>)." },
            { k: "eg", title: "Worked example 1.1 — target mean strength for an M25 mix", given: "M25 concrete. No site data yet, good site control. Then: the same mix on a site without weigh batching. Find: the mean strength the mix must be designed for.", steps: [
              { t: "Good control (s = 4.0 N/mm²)", w: "fm = fck + 1.65 s = 25 + 1.65 × 4.0 = 31.6 N/mm²" },
              { t: "Poorer control (s increased by 1.0 → 5.0)", w: "fm = 25 + 1.65 × 5.0 = 33.25 N/mm²" },
            ], ans: "31.6 N/mm² with good control, 33.3 N/mm² without — poor site control costs about 1.7 N/mm² of extra mean strength, i.e. more cement for the same grade. Interpretation: quality control is not paperwork; it is paid for in cement." },
            { k: "note", t: "<b>Update (v38):</b> IS 10262:2019 also requires the target to be at least fck + X, with X = 5.5 N/mm² for M20–M25 (verified in two sources — see <a href=\"#/read/ct/5\">Concrete Technology, Chapter 5</a>). For M25 that gives 30.5 N/mm², so 1.65 s still governs here." },
            { k: "p", t: "Characteristic load is defined the same way, at the other tail: the value with a 5% chance of being exceeded. In practice the loads in IS 875 and IS 1893 are taken as the characteristic values directly." },
            { k: "tbl", id: "tb-grades" },
          ],
        },
        {
          n: "1.6",
          title: "Partial safety factors",
          hi: "आंशिक सुरक्षा गुणांक",
          blocks: [
            { k: "p", t: "Working stress design used one factor of safety to cover every uncertainty at once. Limit state splits it, because the uncertainties are of different sizes and belong in different places." },
            { k: "eq", expr: "Design strength = characteristic strength / γm        Design load = characteristic load × γf", where: [] },
            { k: "h", t: "Material factors — IS 456 Cl. 36.4.2" },
            { k: "list", items: [
              "<strong>Concrete: γm = 1.5.</strong> Larger, because concrete is made on site, cured by whoever is available, and its strength in a member is not quite its strength in a cube.",
              "<strong>Steel: γm = 1.15.</strong> Smaller, because it is made in a factory to a specification and tested before it arrives.",
            ]},
            { k: "p", t: "Those two numbers produce the two constants that appear in every formula in the rest of this handbook. Concrete: 0.67 fck / 1.5 = 0.446 fck, usually written 0.45 fck. Steel: fy / 1.15 = 0.87 fy. If you remember nothing else from this chapter, remember where 0.87 comes from — it is not a fudge factor." },
            { k: "h", t: "Load factors — IS 456 Cl. 36.4.1 and Table 18" },
            { k: "tbl", id: "tb-loadfactors" },
            { k: "dia", id: "hb-rcc-loadpath" },
            { k: "trap", t: "For serviceability, γf = 1.0 and γm = 1.0 — <strong>service loads and real material strengths.</strong> Checking deflection with factored loads is the single most common error in student limit state design, and it produces a beam that passes a check it never had to meet. Collapse asks what if everything is worse at once; serviceability asks what will actually happen." },
            { k: "note", t: "Precisely: IS 456 Table 18 gives γf = 1.0 for DL + IL in the serviceability limit state, and Cl. 36.4.2.1 gives γm = 1.0 for both materials there; for combinations that include wind or earthquake the table reduces some of the serviceability factors further — read the table for those rows. (Serviceability DL + IL = 1.0 also stated by <a href=\"https://infralens.in/term/load-combination\" target=\"_blank\" rel=\"noopener\">InfraLens — load combinations</a>.)" },
          ],
        },
        {
          n: "1.7",
          title: "Load combinations",
          hi: "भार संयोजन",
          blocks: [
            { k: "p", t: "Loads do not all reach their peak at the same moment, so applying every factored load together would be absurdly conservative. IS 456 Table 18 sets the combinations that must be checked, and the reductions in them are an explicit statement about that." },
            { k: "list", items: [
              "<strong>1.5 (DL + LL)</strong> — the usual governing case for a floor beam.",
              "<strong>1.5 (DL + WL)</strong> or <strong>0.9 DL + 1.5 WL</strong> — the second exists because dead load can <em>help</em>, and a lighter structure is worse for uplift and overturning. Taking DL at 0.9 is the honest treatment of a favourable load.",
              "<strong>1.2 (DL + LL + WL)</strong> — all three together, but each at 1.2 rather than 1.5, because all three peaking simultaneously is far less likely.",
            ]},
            { k: "p", t: "The same reasoning runs through IS 1893 for seismic combinations, and imposed load is reduced there for the same reason — a building is unlikely to be fully occupied at the moment of an earthquake." },
            { k: "eg", title: "Worked example 1.2 — which combination governs?", given: "(a) A floor beam carries DL = 20 kN/m and IL = 12 kN/m. (b) A light sheeted roof has DL = 0.5 kN/m² and wind suction (uplift) WL = 1.2 kN/m². Find the design load in each case.", steps: [
              { t: "(a) Floor beam — gravity case", w: "wu = 1.5 (20 + 12) = 48 kN/m" },
              { t: "(b) Roof — 1.5 (DL + WL), with uplift negative", w: "1.5 (0.5 − 1.2) = −1.05 kN/m² (net uplift)" },
              { t: "(b) Roof — 0.9 DL + 1.5 WL", w: "0.9 × 0.5 − 1.5 × 1.2 = 0.45 − 1.80 = −1.35 kN/m² (net uplift)" },
            ], ans: "(a) 48 kN/m. (b) The 0.9 DL case gives 29% more uplift (1.35 vs 1.05 kN/m²) and governs the holding-down bolts and purlin connections — exactly the case the note below explains." },
            { k: "note", t: "The 0.9 DL case catches people out because it feels wrong to reduce a load. Ask which direction the load helps in: for an overturning check, or uplift on a light roof, dead load is the thing resisting failure, so assuming <em>less</em> of it is what conservative means." },
          ],
        },
        {
          n: "1.8",
          title: "What this handbook does next",
          hi: "इस हैंडबुक में आगे",
          blocks: [
            { k: "p", t: "Chapter 2 fixes the material behaviour every later calculation assumes. Chapters 3 to 6 cover the limit states of collapse one at a time — flexure, shear and bond, torsion. Chapters 7 to 9 apply them to slabs, columns and footings. Chapter 10 returns to serviceability, and Chapters 11 and 12 finish with the remaining elements and with detailing." },
            { k: "note", t: "If you have not read the Structural Analysis handbook, §1.1 and §1.11 of it are assumed here without re-explanation — this handbook starts from the forces, and takes for granted that you know where they came from." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "rcc-2",
      n: 2,
      title: "Materials for Design",
      hi: "डिज़ाइन के लिए सामग्री",
      blurb: "The idealised behaviour every formula in this handbook rests on: the concrete stress block, the steel curve, modulus, creep, and the durability rules that decide cover and grade before strength does.",
      mins: 30,
      sections: [
        {
          n: "2.1",
          title: "Grades of concrete",
          hi: "कंक्रीट की श्रेणियाँ",
          blocks: [
            { k: "p", t: "A grade is stated as M followed by the characteristic cube strength in N/mm² at 28 days — M25 means fck = 25. IS 456 Cl. 6.1 and Table 2 group the grades, and Cl. 6.1.2 sets the lowest grade allowed for reinforced work." },
            { k: "list", items: [
              "<strong>M20</strong> — the minimum for reinforced concrete in mild exposure (Cl. 6.1.2 with Table 5).",
              "<strong>M25 and above</strong> — required as the exposure becomes more severe, before strength has been considered at all.",
              "<strong>M30 and above</strong> — the practical starting point for anything in a coastal or aggressive environment.",
            ]},
            { k: "trap", t: "The grade is frequently fixed by <strong>durability, not by strength</strong>. IS 456 Table 5 sets a minimum grade for each exposure condition, and in mild exposure a beam might be perfectly adequate in M20 while a similar beam near the sea needs M30 for reasons that have nothing to do with the bending moment. Check Table 5 before you start sizing." },
            { k: "tbl", id: "tb-exposure" },
          ],
        },
        {
          n: "2.2",
          title: "The design stress-strain curve for concrete",
          hi: "कंक्रीट का डिज़ाइन स्ट्रेस-स्ट्रेन वक्र",
          blocks: [
            { k: "p", t: "Real concrete has a curved, falling stress-strain relationship that varies with grade, age, rate of loading and a dozen other things. Design needs one agreed idealisation, and IS 456 Fig. 21 gives it: parabolic from zero to a strain of 0.002, then constant to 0.0035, at which point the concrete is taken to crush." },
            { k: "dia", id: "hb-rcc-concrete-curve" },
            { k: "eq", expr: "Peak design stress = 0.67 fck / γm = 0.67 fck / 1.5 = 0.446 fck ≈ 0.45 fck", where: [] },
            { k: "h", t: "The two numbers worth understanding rather than memorising" },
            { k: "list", items: [
              "<strong>0.67</strong> converts cube strength into the strength concrete shows in an actual member. A cube is small, restrained by the testing machine platens, and loaded fast; a beam is none of those. The factor is the profession's agreed allowance for the difference.",
              "<strong>0.0035</strong> is the strain at which concrete in flexure is taken to fail. Every flexure formula in Chapter 3 begins by putting this strain at the extreme compression fibre — it is what fixes the neutral axis depth.",
            ]},
            { k: "note", t: "The area and centroid of that stress block are what produce the familiar 0.36 fck b xu for the compression force and 0.42 xu for its lever arm. Chapter 3 derives both rather than quoting them." },
          ],
        },
        {
          n: "2.3",
          title: "Modulus of elasticity, creep and shrinkage",
          hi: "प्रत्यास्थता गुणांक, क्रीप और संकुचन",
          blocks: [
            { k: "eq", expr: "Ec = 5000 √fck        (IS 456 Cl. 6.2.3.1, N/mm²)", where: [["fck", "Characteristic cube strength, N/mm²"]] },
            { k: "p", t: "This is the short-term static modulus, and the code itself notes that a measured value can differ from it by around ±20%, because the modulus depends heavily on the aggregate. Use it for design; do not treat it as a measured property." },
            { k: "h", t: "Creep — Cl. 6.2.5" },
            { k: "p", t: "Concrete under sustained load keeps deforming for years. The code handles it through a creep coefficient that depends on the age at loading, and the practical device is an <strong>effective modulus</strong>: Ece = Ec / (1 + θ). With θ = 2.2 for concrete loaded at 7 days (1.6 at 28 days — table below), the long-term effective modulus can be well under half the short-term value." },
            { k: "note", t: "<b>Correction (v34):</b> an earlier version of this paragraph gave θ = 1.6 for loading at 7 days. IS 456 Cl. 6.2.5.1 gives <b>2.2 at 7 days, 1.6 at 28 days, 1.1 at 1 year</b> — as the table below always showed (values cross-checked with <a href=\"https://infralens.in/term/creep-coefficient-concrete\" target=\"_blank\" rel=\"noopener\">InfraLens</a> and the published code)." },
            { k: "tbl", id: "tb-creep" },
            { k: "p", t: "That is why the long-term deflection of a beam can be two to three times its short-term deflection, and why IS 456 Cl. 23.2 writes its limit in terms of the <em>final</em> deflection. A beam that passes a short-term check and fails in service has usually had creep ignored." },
            { k: "h", t: "Shrinkage — Cl. 6.2.4" },
            { k: "p", t: "Concrete shrinks as it dries, and the code's design value for total shrinkage strain is 0.0003 for ordinary conditions. Restrain that shrinkage and you get tension — which is the origin of a large share of the cracking blamed on structural loading, and the reason for distribution steel and for the shrinkage reinforcement required in slabs and walls." },
            { k: "h", t: "Tensile (flexural) strength — Cl. 6.2.2" },
            { k: "eq", expr: "fcr = 0.7 √fck   (N/mm²)", where: [["fcr", "flexural strength (modulus of rupture) — the stress at which an uncracked section first cracks in bending; read from the published IS 456 (Cl. 6.2.2)"]] },
            { k: "p", t: "Design ignores this tension for strength (Cl. 38.1), but it decides <b>when</b> a member cracks — the cracking moment M_cr = fcr·I/y_t — and that matters for deflection (Chapter 10, Annex C) and for liquid-retaining structures. Compare it with the beam test in the SOM handbook (<a href=\"#/read/som/3\">SOM Worked example 3.6</a>), which measures exactly this quantity." },
            { k: "eg", title: "Worked example 2.1 — the material constants of M25", given: "M25 concrete. A 230 × 450 mm rectangular beam (uncracked, steel ignored). Find: Ec, fcr, long-term modulus if loaded at 28 days, and the moment at which the beam first cracks.", steps: [
              { t: "Short-term modulus", w: "Ec = 5000 √25 = 25 000 N/mm²" },
              { t: "Flexural strength", w: "fcr = 0.7 √25 = 3.5 N/mm²" },
              { t: "Effective modulus, θ = 1.6", w: "Ece = 25 000/(1 + 1.6) = 9615 N/mm²" },
              { t: "Cracking moment, Z = bD²/6", w: "Z = 230 × 450²/6 = 7.763 × 10⁶ mm³\nMcr = 3.5 × 7.763 × 10⁶ = 27.2 × 10⁶ N·mm = 27.2 kN·m" },
            ], ans: "Ec = 25 000, fcr = 3.5, Ece = 9615 N/mm²; Mcr ≈ 27 kN·m. Interpretation: a typical floor beam of this size sees service moments well above 27 kN·m, so it works cracked — which is why the steel, not the concrete, carries the tension in every later chapter." },
          ],
        },
        {
          n: "2.4",
          title: "Reinforcing steel",
          hi: "सरिया",
          blocks: [
            { k: "p", t: "Steel is manufactured, so it is far more predictable than concrete — hence the smaller γm of 1.15 from §1.6. IS 456 Cl. 5.6 lists the acceptable types, and the grade is stated as Fe followed by the characteristic yield strength." },
            { k: "list", items: [
              "<strong>Fe 250</strong> — mild steel, plain round bars. A sharp yield point and excellent ductility; now uncommon in main reinforcement.",
              "<strong>Fe 415, Fe 500</strong> — high yield strength deformed bars, to IS 1786. These are the working grades.",
              "<strong>Fe 500D and similar</strong> — the D designation indicates higher specified ductility, which is what IS 13920 asks for in earthquake-resisting members.",
            ]},
            { k: "dia", id: "hb-rcc-steel-curve" },
            { k: "eq", expr: "Design yield stress = fy / 1.15 = 0.87 fy        Es = 2 × 10⁵ N/mm² for all grades", where: [] },
            { k: "p", t: "Mild steel has a genuine yield plateau. Cold-worked bars do not — their curve bends over gradually with no defined yield — so the code defines an equivalent yield as the stress at which the strain is 0.87fy/Es plus an inelastic 0.002. That definition has a direct design consequence, and it is the subject of the next paragraph rather than a footnote." },
            { k: "trap", t: "Because Fe 500 needs more strain to reach its design stress than Fe 415 does, the section has to rotate further before the steel yields — so the <strong>limiting neutral axis depth is smaller for Fe 500</strong> (0.46d against 0.48d). Higher grade steel is not simply a stronger substitute; it changes the geometry of the balanced section, as Chapter 3 shows." },
            { k: "note", t: "<b>Precisely where the +0.002 comes from:</b> IS 456 Cl. 38.1 requires the strain in the tension steel at failure to be not less than 0.87fy/Es + 0.002 — for <b>every</b> grade, mild steel included (<a href=\"https://infralens.in/code/IS-456-2000/clause/38-1\" target=\"_blank\" rel=\"noopener\">InfraLens — Cl. 38.1</a>). It is a ductility requirement: the steel must be well past yield when the concrete crushes. That single rule produces all three limiting depths, as the example shows (values also in <a href=\"https://engineeringhulk.com/civil/rcc-design/formulas/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk's IS 456 formula sheet</a>)." },
            { k: "eg", title: "Worked example 2.2 — deriving xu,max/d = 0.53, 0.48 and 0.46", given: "Es = 2 × 10⁵ N/mm², concrete crushing strain 0.0035. Find the limiting neutral-axis depth ratio for Fe 250, Fe 415 and Fe 500.", steps: [
              { t: "Steel strain at failure, εs = 0.87fy/Es + 0.002", w: "Fe 250: 0.00109 + 0.002 = 0.00309\nFe 415: 0.00181 + 0.002 = 0.00381\nFe 500: 0.00218 + 0.002 = 0.00418" },
              { t: "Similar triangles of the linear strain diagram: xu/d = 0.0035/(0.0035 + εs)", w: "Fe 250: 0.0035/0.00659 = 0.531\nFe 415: 0.0035/0.00731 = 0.479\nFe 500: 0.0035/0.00768 = 0.456" },
            ], ans: "0.53, 0.48 and 0.46 — the three numbers of Cl. 38.1, reproduced from one strain rule. Interpretation: the stronger the steel, the more it must stretch to yield, so the compression zone has to be shallower for the steel to yield first." },
          ],
        },
        {
          n: "2.5",
          title: "Durability, exposure and cover",
          hi: "टिकाऊपन, एक्सपोज़र और कवर",
          blocks: [
            { k: "p", t: "IS 456 Cl. 8 treats durability as a design requirement in its own right, not as good practice. The logic is simple: reinforcement in concrete is protected by the alkalinity of the cement paste around it, and durability design is the business of keeping that protection intact for the design life." },
            { k: "steps", items: [
              "Establish the exposure condition — mild, moderate, severe, very severe or extreme (Cl. 8.2.2, Table 3).",
              "Read off the minimum grade, minimum cement content and maximum water-cement ratio for that exposure (Table 5).",
              "Read off the nominal cover for that exposure (Cl. 26.4.2, Table 16).",
              "Check the cover for fire resistance as well (Table 16A) and take the larger.",
              "Only now start the flexural design — because cover has just reduced the effective depth.",
            ]},
            { k: "tbl", id: "tb-cover" },
            { k: "p", t: "Cover is measured to the <strong>outside of the stirrup</strong>, not to the main bar, and the nominal cover must never be less than the diameter of the bar (Cl. 26.4.1). In a footing the minimum is 50 mm, and in a column the cover to longitudinal bars is generally not less than 40 mm." },
            { k: "trap", t: "Every millimetre of cover comes straight out of the effective depth, and capacity depends on d². Increasing cover for durability from 25 mm to 50 mm in a 450 mm deep beam removes about 6% of d and roughly 11% of its moment capacity. <strong>Fix cover before sizing, not after</strong> — otherwise the flexural design has to be redone." },
            { k: "h", t: "The chemical limits" },
            { k: "p", t: "Cl. 8.2.5 caps the chloride and sulphate content of the mix, because both attack from within and no amount of cover will help. This is the reason sea sand and unapproved water are not permitted, and the reason admixtures have to be checked for chloride content rather than assumed innocent." },
            { k: "list", items: [
              "<b>Chloride (Cl. 8.2.5.2, Table 7)</b> — maximum total acid-soluble chloride, kg per m³ of concrete: <b>0.6</b> for reinforced concrete (or plain concrete with embedded metal); <b>0.4</b> for prestressed or steam-cured concrete containing metal.",
              "<b>Sulphate (Cl. 8.2.5.3)</b> — total water-soluble sulphate in the mix, as SO₃, not more than <b>4% by mass of cement</b>.",
            ] },
            { k: "note", t: "Values read from the published IS 456 on <a href=\"https://law.resource.org/pub/in/bis/S03/is.456.2000.pdf\" target=\"_blank\" rel=\"noopener\">Public.Resource.Org</a>. <b>Units conflict between sources:</b> InfraLens quotes chloride limits as percentages <i>by mass of cement</i> (e.g. 0.3% for RCC in mild exposure) — a different basis from the code's kg/m³ of concrete; convert using the actual cement content before comparing, and take the code table as authoritative." },
            { k: "eg", title: "Worked example 2.3 — what cover costs in effective depth", given: "A 300 × 500 mm beam with 8 mm stirrups and 20 mm main bars. Find the effective depth for moderate exposure (30 mm cover) and severe exposure (45 mm), and the effect on flexural capacity.", steps: [
              { t: "d = D − cover − stirrup − bar/2", w: "Moderate: 500 − 30 − 8 − 10 = 452 mm\nSevere: 500 − 45 − 8 − 10 = 437 mm" },
              { t: "Capacity ∝ d² (Chapter 3)", w: "(437/452)² = 0.935" },
            ], ans: "d drops from 452 to 437 mm and moment capacity by about 6.5% — before any load has been considered. Fix exposure and cover first." },
          ],
        },
        {
          n: "2.6",
          title: "What the next chapters assume",
          hi: "अगले अध्याय क्या मानकर चलते हैं",
          blocks: [
            { k: "list", items: [
              "Concrete reaches 0.446 fck at a strain of 0.002 and crushes at 0.0035.",
              "Steel reaches 0.87 fy and is perfectly plastic after that.",
              "Plane sections remain plane — so strain varies linearly through the depth.",
              "Concrete carries no tension once it has cracked.",
              "There is no slip between steel and concrete — perfect bond, which Chapter 5 then has to earn by providing development length.",
            ]},
            { k: "p", t: "Those five are the assumptions listed in IS 456 Cl. 38.1 for flexure, and every formula in Chapter 3 is a consequence of them. None of them is exactly true; all of them are close enough, and knowing which one is doing the work in a given calculation is what lets you judge when it stops being close enough." },
          ],
        },
      ],
    },

  ],
});
