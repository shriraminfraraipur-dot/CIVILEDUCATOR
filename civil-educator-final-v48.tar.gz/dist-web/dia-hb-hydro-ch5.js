/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook,
   Chapter 5 "Infiltration".
   ------------------------------------------------------------
   Same conventions as the other diagrams files: strokes are
   currentColor so both themes work, meaning-carrying strokes use
   .hi (marker) or .ac (accent), and the figure gets its own
   marker-id prefix so it never collides with another figure on
   the same page.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function mk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 5.3  HORTON'S CURVE */
  "hb-hydro-horton": {
    label: "Horton's infiltration-capacity curve — Case 1 and Case 2",
    svg: `<svg viewBox="0 0 680 300" role="img" aria-label="Graph of infiltration capacity f against time t. The curve starts high at fo and decays exponentially to a constant fc, reached at time tc. The area under the curve from 0 to tc is shaded as Case 1, and a rectangular extra area from tc to a later time t at height fc is shaded separately as the Case 2 addition">
      ${mk("hc")}

      <line class="ac" x1="70" y1="230" x2="70" y2="40" marker-end="url(#hc-c)"/>
      <line class="ac" x1="70" y1="230" x2="630" y2="230" marker-end="url(#hc-c)"/>
      <text class="lb" x="70" y="28" text-anchor="middle">f (cm/hr)</text>
      <text class="lb" x="630" y="250" text-anchor="end">t (hr) →</text>

      <path class="softa" d="M70 230 L70 72 C130 95 190 150 230 190 C242 197 250 199 260 200 L260 230 Z"/>
      <rect class="soft" x="260" y="200" width="220" height="30"/>

      <path class="s" d="M70 72 C130 95 190 150 230 190 C242 197 250 199 260 200 L620 200"/>

      <line class="thin dash" x1="260" y1="200" x2="260" y2="240"/>
      <line class="thin dash" x1="480" y1="200" x2="480" y2="240"/>
      <line class="thin dash" x1="40" y1="72" x2="70" y2="72"/>
      <line class="thin dash" x1="40" y1="200" x2="70" y2="200"/>

      <circle class="acf" cx="70" cy="72" r="4"/>
      <circle class="acf" cx="260" cy="200" r="4"/>

      <text class="ea" x="36" y="68" text-anchor="end">fo</text>
      <text class="ea" x="36" y="204" text-anchor="end">fc</text>
      <text class="ea" x="260" y="254" text-anchor="middle">tc</text>
      <text class="ea" x="480" y="254" text-anchor="middle">t</text>

      <text class="em" x="160" y="158" text-anchor="middle">Case 1</text>
      <text class="lb" x="160" y="176" text-anchor="middle">0 ≤ t ≤ tc</text>
      <text class="em" x="370" y="216" text-anchor="middle">Case 2 — extra</text>
      <text class="lb" x="370" y="190" text-anchor="middle">fc·(t − tc)</text>

      <line class="gl" x1="70" y1="40" x2="70" y2="230"/>
      <text class="lb" x="350" y="282" text-anchor="middle">Shaded area up to time t = cumulative infiltration F̄p</text>
    </svg>`,
    caption: "fp decays from fo toward a constant fc, reached at time tc. The <strong>shaded area under the curve is the cumulative infiltration</strong> — Case 1 (0 ≤ t ≤ tc) is the exponential-decay area itself, and Case 2 (t &gt; tc) is that same Case-1 area plus a plain rectangle fc·(t − tc) tacked on, because once fp has flattened to fc it stops changing.",
  },

});
