/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook, Chapter 3
   (Rainfall Data Analysis).
   ------------------------------------------------------------
   Same conventions as the other dia-hb-*.js files: strokes are
   currentColor so both themes work, meaning-carrying strokes use
   .hi (marker) or .ac (accent), and every figure gets its own
   marker-id prefix so two figures on one page never collide.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hymk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 3.4 THIESSEN POLYGON CONSTRUCTION */
  "hb-hydro-thiessen": {
    label: "Thiessen-polygon construction for four rain-gauge stations",
    svg: `<svg viewBox="0 0 680 420" role="img" aria-label="Four rain-gauge stations P1 to P4 arranged in a quadrilateral inside an irregular catchment boundary. Thin solid lines join adjacent stations into triangles. Dashed perpendicular bisectors of those joining lines meet at a central point and close up into one shaded polygon per station, each polygon containing exactly one gauge.">
      ${hymk("th")}

      <!-- catchment boundary -->
      <path class="dash" d="M70 60 Q220 20 420 50 Q620 80 610 220 Q600 350 430 380 Q230 410 110 340 Q30 260 70 60 Z"/>
      <text class="lb" x="340" y="28" text-anchor="middle">CATCHMENT BOUNDARY</text>

      <!-- lines joining adjacent stations (triangulation) -->
      <line class="thin" x1="230" y1="140" x2="440" y2="130"/>
      <line class="thin" x1="440" y1="130" x2="460" y2="300"/>
      <line class="thin" x1="460" y1="300" x2="250" y2="300"/>
      <line class="thin" x1="250" y1="300" x2="230" y2="140"/>
      <line class="thin" x1="230" y1="140" x2="460" y2="300"/>

      <!-- Thiessen regions (perpendicular bisectors closing into polygons) -->
      <path class="softa" d="M70 60 Q220 20 420 50 Q500 65 480 130 L345 215 L230 140 Q150 110 70 60 Z"/>
      <path class="soft" d="M420 50 Q620 80 610 220 Q560 240 480 220 L345 215 L480 130 Z"/>
      <path class="softa" d="M610 220 Q600 350 430 380 Q400 300 410 240 L480 220 L345 215 Z"/>
      <path class="soft" d="M430 380 Q230 410 110 340 Q30 260 70 60 Q150 110 230 140 L345 215 L410 240 Q400 300 430 380 Z"/>

      <!-- perpendicular bisectors, dashed, meeting at the central Thiessen vertex -->
      <line class="dash hi" x1="335" y1="135" x2="355" y2="295"/>
      <line class="dash hi" x1="450" y1="100" x2="300" y2="325"/>
      <line class="dash hi" x1="200" y1="190" x2="500" y2="255"/>
      <circle class="acf" cx="345" cy="215" r="4"/>
      <text class="ea" x="345" y="200" text-anchor="middle">O</text>

      <!-- gauge stations -->
      <circle class="acf" cx="230" cy="140" r="7"/>
      <text class="em" x="230" y="122" text-anchor="middle">P1</text>
      <circle class="acf" cx="440" cy="130" r="7"/>
      <text class="em" x="440" y="112" text-anchor="middle">P2</text>
      <circle class="acf" cx="460" cy="300" r="7"/>
      <text class="em" x="474" y="300" text-anchor="middle">P3</text>
      <circle class="acf" cx="250" cy="300" r="7"/>
      <text class="em" x="236" y="300" text-anchor="middle">P4</text>

      <text class="lb" x="150" y="80" text-anchor="middle">A1</text>
      <text class="lb" x="540" y="110" text-anchor="middle">A2</text>
      <text class="lb" x="520" y="320" text-anchor="middle">A3</text>
      <text class="lb" x="150" y="330" text-anchor="middle">A4</text>

      <text class="lb" x="340" y="405" text-anchor="middle">solid = joins between adjacent gauges · dashed = perpendicular bisectors · each shaded polygon carries exactly one gauge</text>
    </svg>`,
    caption: "Join adjacent gauges, bisect each join at right angles, and the bisectors close up into one polygon per gauge. Each polygon's area Aᵢ becomes that gauge's weight, Aᵢ/A, in P̄ = ΣPᵢ(Aᵢ/A) — the whole method is just finding that one area per gauge.",
  },

});
