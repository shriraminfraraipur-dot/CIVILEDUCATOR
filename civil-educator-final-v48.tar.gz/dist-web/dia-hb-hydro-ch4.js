/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook, Chapter 4
   (Evaporation, Transpiration & Evapotranspiration).
   ------------------------------------------------------------
   Same conventions as dia-hb-sa1.js: strokes are currentColor so
   both themes work, meaning-carrying strokes use .hi (marker) or
   .ac (accent), unique marker-id prefix so figures never collide.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hymk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}
/* hatched ground under a support */
function hygrd(x, y, w) {
  let s = `<line class="s" x1="${x}" y1="${y}" x2="${x + w}" y2="${y}"/>`;
  for (let i = 0; i < w; i += 9) s += `<line class="thin" x1="${x + i}" y1="${y}" x2="${x + i - 7}" y2="${y + 8}"/>`;
  return s;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 4.3 CLASS-A vs I.S. PAN */
  "hb-hydro-pan": {
    label: "Class-A pan (USA) vs I.S. pan — construction and pan coefficient",
    svg: `<svg viewBox="0 0 680 400" role="img" aria-label="Two evaporation pan cross-sections side by side, both 1210 millimetre diameter and 255 millimetre deep, standing on a 150 millimetre wooden platform above ground level, with 180 to 200 millimetre of water inside. The left pan, Class-A (USA), is open-topped unpainted galvanised iron. The right pan, the Indian Standard pan, is made of copper and covered with a hexagonal wire netting lid. Below both, the pan-coefficient relation: reservoir evaporation equals Cp times pan evaporation, with Cp about 0.70 for the Class-A pan and about 0.80 for the I.S. pan.">
      ${hymk("hp")}

      <text class="lb" x="168" y="22" text-anchor="middle">CLASS-A PAN (U.S.A.)</text>
      <line class="s" x1="98" y1="52" x2="98" y2="172"/>
      <line class="s" x1="238" y1="52" x2="238" y2="172"/>
      <line class="s" x1="98" y1="172" x2="238" y2="172"/>
      <line class="thin" x1="106" y1="96" x2="230" y2="96"/>
      <path class="hi" d="M168 96 L160 108 L176 108 Z"/>
      <text class="lb" x="168" y="130" text-anchor="middle">water</text>
      <text class="lb" x="168" y="150" text-anchor="middle">unpainted G.I. sheet</text>

      <line class="thin dash" x1="98" y1="40" x2="238" y2="40"/>
      <line class="thin" x1="98" y1="36" x2="98" y2="44"/><line class="thin" x1="238" y1="36" x2="238" y2="44"/>
      <line class="ac" x1="100" y1="40" x2="236" y2="40" marker-start="url(#hp-c)" marker-end="url(#hp-c)"/>
      <text class="ea" x="168" y="32" text-anchor="middle">1210 mm dia</text>

      <line class="hi" x1="256" y1="52" x2="256" y2="172" marker-start="url(#hp-m)" marker-end="url(#hp-m)"/>
      <text class="em" x="262" y="116">255 mm</text>
      <line class="thin" x1="212" y1="96" x2="256" y2="96"/>
      <text class="lb" x="320" y="88">180–200 mm</text>
      <text class="lb" x="320" y="104">water depth</text>

      ${hygrd(80, 172, 176)}
      <rect class="conc" x="110" y="172" width="18" height="30"/>
      <rect class="conc" x="208" y="172" width="18" height="30"/>
      <line class="hi" x1="90" y1="202" x2="90" y2="172" marker-start="url(#hp-m)" marker-end="url(#hp-m)"/>
      <text class="em" x="68" y="190">150 mm</text>
      ${hygrd(70, 202, 196)}
      <text class="lb" x="168" y="222" text-anchor="middle">wooden platform, G.L.</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="340"/>

      <text class="lb" x="512" y="22" text-anchor="middle">INDIAN STANDARD (I.S.) PAN</text>
      <line class="s" x1="442" y1="52" x2="442" y2="172"/>
      <line class="s" x1="582" y1="52" x2="582" y2="172"/>
      <line class="s" x1="442" y1="172" x2="582" y2="172"/>
      <rect class="soft-b" x="442" y="44" width="140" height="10"/>
      <line class="thin" x1="450" y1="49" x2="458" y2="41"/><line class="thin" x1="466" y1="49" x2="474" y2="41"/>
      <line class="thin" x1="482" y1="49" x2="490" y2="41"/><line class="thin" x1="498" y1="49" x2="506" y2="41"/>
      <line class="thin" x1="514" y1="49" x2="522" y2="41"/><line class="thin" x1="530" y1="49" x2="538" y2="41"/>
      <line class="thin" x1="546" y1="49" x2="554" y2="41"/><line class="thin" x1="562" y1="49" x2="570" y2="41"/>
      <text class="em" x="512" y="34" text-anchor="middle">hexagonal G.I. wire netting</text>
      <line class="thin" x1="450" y1="96" x2="574" y2="96"/>
      <path class="hi" d="M512 96 L504 108 L520 108 Z"/>
      <text class="lb" x="512" y="130" text-anchor="middle">water</text>
      <text class="lb" x="512" y="150" text-anchor="middle">copper sheet</text>

      <line class="hi" x1="600" y1="52" x2="600" y2="172" marker-start="url(#hp-m)" marker-end="url(#hp-m)"/>
      <text class="em" x="606" y="116">255 mm</text>

      ${hygrd(424, 172, 176)}
      <rect class="conc" x="454" y="172" width="18" height="30"/>
      <rect class="conc" x="552" y="172" width="18" height="30"/>
      <line class="hi" x1="434" y1="202" x2="434" y2="172" marker-start="url(#hp-m)" marker-end="url(#hp-m)"/>
      <text class="em" x="412" y="190">150 mm</text>
      ${hygrd(414, 202, 196)}
      <text class="lb" x="512" y="222" text-anchor="middle">wooden platform, G.L.</text>

      <line class="gl" x1="30" y1="252" x2="650" y2="252"/>
      <rect class="soft" x="130" y="268" width="420" height="68" rx="8"/>
      <text class="em" x="340" y="294" text-anchor="middle">Reservoir evaporation = Cp &times; Pan evaporation</text>
      <text class="ea" x="220" y="320" text-anchor="middle">Cp &asymp; 0.70 (Class-A, USA)</text>
      <text class="ea" x="460" y="320" text-anchor="middle">Cp &asymp; 0.80 (I.S. pan)</text>
      <text class="lb" x="340" y="356" text-anchor="middle">Netting on the I.S. pan also cuts its own reading &asymp;14.1% vs an uncovered pan — a separate effect, see note in 4.3</text>
    </svg>`,
    caption: "Both pans are the same 1210 mm &times; 255 mm tin, on the same 150 mm platform — only the material and the wire-netting lid differ. That is enough to change what the pan reads, which is exactly why a pan coefficient Cp is needed before a pan reading can stand in for real reservoir evaporation (S2 p.31&ndash;33; S3 p.13&ndash;14).",
  },

});
