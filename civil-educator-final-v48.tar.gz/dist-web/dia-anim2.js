/* ============================================================
   CIVIL EDUCATOR — ANIMATED DIAGRAMS, SET 2
   Processes rather than states: a load rolling across a span,
   a moment being locked and released, hinges forming one by one.

   These are the topics where a static figure teaches almost
   nothing, because the whole idea IS the sequence.

   Same contract as set 1: authored at rest, readable frozen,
   and the caption carries the lesson in words.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ====================================================== SA: ROLLING LOAD */
  "an-sa-ild": {
    label: "A load rolling across, and the influence line it traces",
    anim: true,
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A unit load rolling from one support to the other across a simply supported beam, with the left hand reaction shown falling from one to zero as it travels, and beneath it the triangular influence line for that reaction traced out as the diagram the ordinate follows.">
      ${hbmk("ani")}
      <text class="em" x="350" y="24" text-anchor="middle">ONE LOAD, MOVING — THIS IS WHAT AN INFLUENCE LINE IS</text>

      <line class="s" x1="100" y1="112" x2="580" y2="112"/>
      ${grd(84, 118, 32)} ${grd(548, 118, 32)}
      <text class="lb" x="100" y="146" text-anchor="middle">A</text>
      <text class="lb" x="580" y="146" text-anchor="middle">B</text>
      <g class="an-roll" style="--amp:480;--dur:6s">
        <line class="ac" x1="100" y1="72" x2="100" y2="104" marker-end="url(#ani-c)"/>
        <text class="ea" x="100" y="64" text-anchor="middle">1</text>
      </g>
      <text class="lb" x="340" y="92" text-anchor="middle">the unit load travels the whole span</text>

      <text class="em" x="100" y="186" text-anchor="end">RA</text>
      <line class="s" x1="100" y1="266" x2="580" y2="266"/>
      <line class="s" x1="100" y1="180" x2="100" y2="266"/>
      <path class="soft" d="M100 180 L580 266 L100 266 Z"/>
      <path class="hi" d="M100 180 L580 266"/>
      <g class="an-roll" style="--amp:480;--dur:6s">
        <line class="acf" x1="100" y1="180" x2="100" y2="266" stroke="currentColor" stroke-width="2"/>
        <circle class="hif" cx="100" cy="180" r="6"/>
      </g>
      <text class="ea" x="112" y="176">RA = 1 when the load is over A …</text>
      <text class="ea" x="574" y="288" text-anchor="end">… and 0 when it has reached B</text>

      <text class="em" x="350" y="310" text-anchor="middle">the DIAGRAM is not a load — it is the value of RA for every position the load could take</text>
    </svg>`,
    caption: "This is the single idea students most often miss. An ordinary bending moment diagram answers <em>what is the moment at each point, for one fixed set of loads</em>. An influence line answers the opposite question — <strong>what happens at ONE point, as the load moves everywhere</strong>. Watch the marker slide down the line as the load rolls: the line is its track.",
  },

  /* ================================================ SA: MOMENT DISTRIBUTION */
  "an-sa-momdist": {
    label: "Moment distribution, one cycle at a time",
    anim: true,
    svg: `<svg viewBox="0 0 712 320" role="img" aria-label="A continuous beam over three supports shown in four stages: all joints locked so that fixed end moments are out of balance, the joint released so the unbalanced moment is distributed to the members in proportion to their stiffness, half of each distributed moment carried over to the far end, and the cycle repeated until the remaining unbalance is negligible.">
      ${hbmk("anm")}
      <text class="em" x="350" y="24" text-anchor="middle">LOCK · RELEASE · CARRY OVER · REPEAT</text>

      <line class="s" x1="80" y1="96" x2="620" y2="96"/>
      ${grd(64, 102, 32)} ${grd(334, 102, 32)} ${grd(604, 102, 32)}
      <text class="lb" x="80" y="128" text-anchor="middle">A</text>
      <text class="em" x="350" y="128" text-anchor="middle">B</text>
      <text class="lb" x="620" y="128" text-anchor="middle">C</text>
      ${[0, 1, 2, 3, 4, 5].map(i => `<line class="ac" x1="${120 + i * 34}" y1="58" x2="${120 + i * 34}" y2="88" marker-end="url(#anm-c)"/>`).join("")}
      <text class="lb" x="500" y="76" text-anchor="middle">span BC unloaded</text>

      <g class="an-step" style="--dur:8s;--del:0s">
        <text class="em" x="60" y="176">① LOCK every joint</text>
        <text class="lb" x="60" y="196">clamp B so it cannot rotate. Each span now behaves as</text>
        <text class="lb" x="60" y="214">fixed-fixed, and you read off its fixed end moments.</text>
        <text class="lb" x="60" y="232">At B they do not balance — that is the whole problem.</text>
      </g>
      <g class="an-step" style="--dur:8s;--del:2s">
        <text class="em" x="60" y="258">② RELEASE B</text>
        <text class="lb" x="60" y="278">the out-of-balance moment is shared between BA and BC</text>
        <text class="lb" x="60" y="296">in proportion to their stiffness — the distribution factors</text>
      </g>
      <g class="an-step" style="--dur:8s;--del:4s">
        <text class="em" x="396" y="176">③ CARRY OVER</text>
        <text class="lb" x="396" y="196">half of what each member received at B</text>
        <text class="lb" x="396" y="214">appears at its FAR end — that is what</text>
        <text class="lb" x="396" y="232">the carry-over factor of ½ means</text>
      </g>
      <g class="an-step" style="--dur:8s;--del:6s">
        <text class="em" x="396" y="258">④ REPEAT</text>
        <text class="lb" x="396" y="278">the carry-over has unbalanced B again, by less.</text>
        <text class="lb" x="396" y="296">Go round again. It converges quickly.</text>
      </g>
      <path class="hi an-step" style="--dur:8s;--del:2s" d="M350 96 A34 34 0 0 1 384 130" fill="none" marker-end="url(#anm-m)"/>
      <path class="hi an-step" style="--dur:8s;--del:4s" d="M300 140 L110 140" marker-end="url(#anm-m)"/>
      <path class="hi an-step" style="--dur:8s;--del:4s" d="M400 140 L590 140" marker-end="url(#anm-m)"/>
    </svg>`,
    caption: "Moment distribution is not a formula, it is a <strong>procedure</strong>, and that is exactly why it is hard to learn from a page. The physical story: clamp every joint so you can compute each span on its own, then let the joints go one at a time and watch the error shrink. <strong>Hardy Cross's insight was that you can stop whenever the remaining unbalance stops mattering</strong>.",
  },

  /* ================================================== SA: PLASTIC COLLAPSE */
  "an-sa-hinges": {
    label: "Plastic hinges forming until the structure becomes a mechanism",
    anim: true,
    svg: `<svg viewBox="0 0 736 300" role="img" aria-label="A propped cantilever under increasing load. First the whole beam is elastic, then a plastic hinge forms at the fixed end, then a second hinge forms under the load, and at that point the beam has become a mechanism and collapses. The load at which that happens is the collapse load.">
      ${hbmk("anh")}
      <text class="em" x="350" y="24" text-anchor="middle">LOAD RISING · HINGES APPEARING · THEN IT IS A MECHANISM</text>

      ${[["① elastic — nothing yielded yet", 0, 72, 0],
         ["② first hinge at the fixed end", 1.6, 148, 1],
         ["③ second hinge under the load — COLLAPSE", 3.2, 224, 2]]
        .map(([lbl, del, y, n]) => `
        <g class="an-step" style="--dur:5.4s;--del:${del}s">
          <rect class="conc" x="76" y="${y - 22}" width="16" height="44"/>
          <line class="s" x1="92" y1="${y}" x2="420" y2="${y}"/>
          ${grd(404, y + 6, 26)}
          <line class="ac" x1="256" y1="${y - 34}" x2="256" y2="${y - 8}" marker-end="url(#anh-c)"/>
          ${n >= 1 ? `<circle class="hif" cx="96" cy="${y}" r="8"/>` : ""}
          ${n >= 2 ? `<circle class="hif" cx="256" cy="${y}" r="8"/>` : ""}
          ${n >= 2 ? `<path class="hi" d="M92 ${y} L256 ${y + 20} L420 ${y}"/>` : ""}
          <text class="${n === 2 ? "em" : "lb"}" x="446" y="${y + 4}">${lbl}</text>
        </g>`).join("")}

      <text class="lb" x="76" y="274">a plastic hinge is not a real hinge — it is a section that has</text>
      <text class="lb" x="76" y="292">gone fully plastic and now rotates at a constant moment Mp</text>
      <text class="em" x="446" y="274">degree of indeterminacy 1</text>
      <text class="em" x="446" y="292">→ it takes 1 + 1 = 2 hinges to collapse</text>
    </svg>`,
    caption: "This is why plastic analysis gives a higher collapse load than elastic analysis gives a first-yield load. After the first hinge forms the beam does not fail — it simply <strong>redistributes</strong>, carrying on until enough hinges exist to turn it into a mechanism. The number needed is the degree of indeterminacy plus one, and Chapter 2's ductility is what makes the redistribution possible.",
  },

  /* ================================================ SA: STABLE vs MECHANISM */
  "an-sa-mechanism": {
    label: "The difference a single diagonal makes",
    anim: true,
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="Two identical pin jointed rectangular frames under a sideways load. The unbraced one racks over into a parallelogram because it is a mechanism. The braced one with a single diagonal does not move, because the diagonal turns the rectangle into two triangles.">
      ${hbmk("anx")}
      <text class="em" x="350" y="24" text-anchor="middle">PIN JOINTS · ONE DIAGONAL · COMPLETELY DIFFERENT STRUCTURE</text>

      <text class="em" x="168" y="58" text-anchor="middle">NO DIAGONAL — A MECHANISM</text>
      <line class="thin dash" x1="76" y1="84" x2="260" y2="84"/>
      <g class="an-sway" style="--amp:34;--dur:3s">
        <line class="s" x1="76" y1="84" x2="260" y2="84"/>
        <circle class="hif" cx="76" cy="84" r="5"/>
        <circle class="hif" cx="260" cy="84" r="5"/>
      </g>
      <line class="s" x1="76" y1="84" x2="76" y2="196"/>
      <line class="s" x1="260" y1="84" x2="260" y2="196"/>
      <g class="an-sway" style="--amp:34;--dur:3s"><line class="hi" x1="76" y1="84" x2="76" y2="84"/></g>
      ${grd(60, 202, 32)} ${grd(244, 202, 32)}
      <line class="ac an-sway" style="--amp:34;--dur:3s" x1="40" y1="84" x2="68" y2="84" marker-end="url(#anx-c)"/>
      <text class="lb" x="168" y="234" text-anchor="middle">the rectangle racks into a parallelogram</text>
      <text class="em" x="168" y="258" text-anchor="middle">it moves without anything breaking</text>
      <text class="lb" x="168" y="280" text-anchor="middle">— zero stiffness, whatever the member sizes</text>

      <line class="gl" x1="348" y1="46" x2="348" y2="284"/>

      <text class="em" x="524" y="58" text-anchor="middle">ONE DIAGONAL — STABLE</text>
      <line class="s" x1="432" y1="84" x2="616" y2="84"/>
      <line class="s" x1="432" y1="84" x2="432" y2="196"/>
      <line class="s" x1="616" y1="84" x2="616" y2="196"/>
      <line class="hi" x1="432" y1="196" x2="616" y2="84"/>
      <circle class="hif" cx="432" cy="84" r="5"/>
      <circle class="hif" cx="616" cy="84" r="5"/>
      ${grd(416, 202, 32)} ${grd(600, 202, 32)}
      <line class="ac" x1="396" y1="84" x2="424" y2="84" marker-end="url(#anx-c)"/>
      <text class="lb" x="524" y="234" text-anchor="middle">now it is two triangles, and a triangle</text>
      <text class="lb" x="524" y="258" text-anchor="middle">cannot change shape without stretching a side</text>
      <text class="em" x="524" y="280" text-anchor="middle">this is what "stable" actually means</text>
    </svg>`,
    caption: "Determinacy formulas count equations and unknowns, and they are worth knowing — but this is what they are counting. <strong>A mechanism moves without any member changing length</strong>, so no amount of steel helps it. The left frame needs geometry, not section. It is the same lesson as the bracing of a steel shed, drawn on one bay.",
  },

});
