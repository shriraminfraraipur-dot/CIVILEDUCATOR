/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook, Chapter 2
   "Precipitation — Forms, Measurement & Rain Gauge Networks".
   ------------------------------------------------------------
   Symon's (non-recording) rain gauge — cross-section.
   Same conventions as diagrams.js / dia-hb-sa1.js: strokes are
   currentColor so both themes work, meaning-carrying strokes use
   .hi (marker) or .ac (accent), and this figure gets its own
   marker-id prefix so it never collides with another figure.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hymk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
  </defs>`;
}
/* hatched ground / concrete fill */
function hygrd(x, y, w) {
  let s = `<line class="s" x1="${x}" y1="${y}" x2="${x + w}" y2="${y}"/>`;
  for (let i = 0; i < w; i += 9) s += `<line class="thin" x1="${x + i}" y1="${y}" x2="${x + i - 7}" y2="${y + 8}"/>`;
  return s;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 2.4 SYMON'S GAUGE */
  "hb-hydro-symons": {
    label: "Symon's non-recording rain gauge — cross-section",
    svg: `<svg viewBox="0 0 640 460" role="img" aria-label="Cross-section of Symon's non-recording rain gauge: a 12.7 centimetre diameter funnel feeds a receiving bottle inside a metal outer casing, the casing standing 30.5 centimetres above ground level on a concrete base; alongside it, the separate graduated jar used to read the collected water as a depth of rainfall">
      ${hymk("sy")}

      <!-- dimension: funnel diameter -->
      <line class="thin" x1="150" y1="40" x2="150" y2="58"/>
      <line class="thin" x1="330" y1="40" x2="330" y2="58"/>
      <line class="ac" x1="150" y1="50" x2="330" y2="50" marker-start="url(#sy-a)" marker-end="url(#sy-a)"/>
      <text class="em" x="240" y="34" text-anchor="middle">12.7 cm (127 mm) dia.</text>

      <!-- funnel -->
      <path class="s" d="M150 58 L330 58 L256 150 L224 150 Z"/>
      <text class="lb" x="240" y="90" text-anchor="middle">funnel</text>

      <!-- neck into outer casing -->
      <rect class="s" x="224" y="150" width="32" height="18"/>

      <!-- outer metal casing -->
      <rect class="conc" x="176" y="168" width="128" height="200"/>
      <text class="lb" x="240" y="188" text-anchor="middle">metallic casing</text>

      <!-- receiving bottle inside casing -->
      <path class="s" d="M208 210 L272 210 L272 330 Q272 344 240 344 Q208 344 208 330 Z"/>
      <text class="lb" x="240" y="232" text-anchor="middle">receiving</text>
      <text class="lb" x="240" y="248" text-anchor="middle">bottle</text>
      <text class="lb" x="240" y="266" text-anchor="middle">(holds up to</text>
      <text class="lb" x="240" y="282" text-anchor="middle">10 cm of rain)</text>

      <!-- ground level -->
      <line class="gl" x1="60" y1="368" x2="420" y2="368"/>
      <text class="ea" x="430" y="372">G.L.</text>

      <!-- dimension: rim to GL, 30.5cm -->
      <line class="thin" x1="520" y1="58" x2="548" y2="58"/>
      <line class="thin" x1="520" y1="368" x2="548" y2="368"/>
      <line class="ac" x1="534" y1="58" x2="534" y2="368" marker-start="url(#sy-a)" marker-end="url(#sy-a)"/>
      <text class="em" x="552" y="206" text-anchor="start">30.5 cm</text>
      <text class="lb" x="552" y="222" text-anchor="start">rim to G.L.</text>

      <!-- concrete base -->
      <rect class="soft-b" x="176" y="368" width="128" height="56"/>
      ${hygrd(60, 368, 116)}
      ${hygrd(304, 368, 116)}
      <text class="lb" x="240" y="400" text-anchor="middle">concrete block</text>
      <text class="lb" x="240" y="416" text-anchor="middle">600×600×600 mm</text>

      <!-- separate graduated measuring jar -->
      <line class="dash" x1="304" y1="300" x2="372" y2="260"/>
      <text class="lb" x="400" y="146" text-anchor="middle">poured out and</text>
      <text class="lb" x="400" y="162" text-anchor="middle">read in a separate</text>
      <text class="lb" x="400" y="178" text-anchor="middle">graduated jar</text>
      <rect class="s" x="380" y="192" width="40" height="110"/>
      <line class="thin" x1="380" y1="212" x2="420" y2="212"/>
      <line class="thin" x1="380" y1="232" x2="420" y2="232"/>
      <line class="thin" x1="380" y1="252" x2="420" y2="252"/>
      <line class="thin" x1="380" y1="272" x2="420" y2="272"/>
      <text class="lb" x="400" y="314" text-anchor="middle">scale</text>
      <text class="lb" x="400" y="330" text-anchor="middle">(depth of rain)</text>
    </svg>`,
    caption: "The instrument does one job: catch rain through a fixed 12.7 cm opening and let you read the depth off a graduated jar. Every number on this drawing — 127 mm, 30.5 cm, the 10 cm bottle limit — is also the reason the gauge needs daily attention in heavy rain and can only ever report a day's <strong>total</strong>, never how that rain was spread through the day (S1 p.12–13; S2 p.7–9; V p.7–8).",
  },

});
