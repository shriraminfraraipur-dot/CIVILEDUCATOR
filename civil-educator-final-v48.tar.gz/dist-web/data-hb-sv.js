/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   ------------------------------------------------------------
   The fourth handbook. Where the other three are built on a
   design code, this one is built on measurement itself — what
   you can know about a piece of ground, how well, and how you
   prove it.

   Two habits run through every chapter, because they are what
   separates a surveyor from someone holding a tape:
     · every measurement carries an error, and you should be
       able to say roughly how big;
     · every set of measurements carries a CHECK, and a survey
       without one is a survey you cannot defend.

   Standards are named where they govern (IS 1492 for chains,
   IS 2932 for levelling staves, IRC codes for road curves).
   Confirm any value against the published standard before
   using it on real work.

   Chapters 1–2 follow here; later chapters are pushed by
   data-hb-sv2.js onwards.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "sv",
  subject: "survey",
  name: "Surveying",
  hi: "सर्वेक्षण",
  icon: "📐",
  blurb: "Chain se GNSS tak — har method ka principle, har correction ka reason, aur har survey ka check. Field ke liye likha gaya, exam ke liye bhi kaafi.",
  note: "Worked values here are computed from first principles and shown in full so you can check them. Where a standard governs — IS 1492, IS 2932, the IRC road codes — it is named; confirm against the published document before using a value on site. Phase 1 audit (v36): every chapter verified against web sources, 40 worked examples recomputed, corrections flagged in-line. v46: the complete 240-page Surveying class notes are added chapter by chapter in 📘 Notes sections, cited as p.N; every numerical was re-worked and slips are shown in Check notes.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "sv-1",
      n: 1,
      title: "What Surveying Is For",
      hi: "सर्वेक्षण किसलिए",
      blurb: "Two principles that decide how every job is organised, and the one question that settles whether the earth's curvature matters to you.",
      mins: 34,
      sections: [

        {
          n: "1.1",
          title: "The job",
          hi: "काम क्या है",
          blocks: [
            { k: "p", t: "Surveying is the business of finding out where things are — and, just as often, of putting things where they are supposed to be. Those are two different jobs and it is worth naming them separately, because the second one is unforgiving in a way the first is not." },
            { k: "def", term: "Surveying", t: "Measuring the relative positions of points on, above or below the earth's surface, and representing them on a plan or in a set of coordinates. The ground exists; you are recording it." },
            { k: "def", term: "Setting out", t: "The reverse operation: taking positions from a drawing and marking them on the ground so that something can be built there. An error in a survey gives a wrong plan. An error in setting out gives a wrong building — and the building is already up before anyone notices." },
            { k: "p", t: "Everything a civil engineer builds begins and ends with this work. The site is surveyed before design, the structure is set out before construction, and the finished work is surveyed again to confirm it went where it was meant to. A handbook on design that never mentions where the levels came from has left out the first and last step." },
            { k: "real", t: "The clearest example of the difference is a road. Surveying it produces a contour plan and a longitudinal section from which the alignment is designed. Setting it out means driving pegs at every 20 or 30 m chainage, each at a calculated position and level, for a machine operator to work to. <strong>Get the survey wrong and the design is based on a fiction; get the setting out wrong and the road is built in the wrong place.</strong>" },
          ],
        },

        {
          n: "1.2",
          title: "Work from the whole to the part",
          hi: "पूर्ण से अंश की ओर",
          blocks: [
            { k: "p", t: "This is the first principle of surveying, and it is a statement about <em>errors</em> rather than about geometry." },
            { k: "dia", id: "hb-sv-whole2part", cap: "A framework first, detail inside it. The alternative lets every error travel to the end of the job." },
            { k: "p", t: "Suppose you survey a 2 km stretch by measuring from each point to the next, all the way along. Every small error is inherited by every point after it, and they accumulate. By the far end you may be metres out, and — worse — you have no way of knowing it." },
            { k: "p", t: "Now do it the other way. Establish a handful of <strong>control points</strong> first, measured with much more care than the rest of the job needs, covering the whole area. Then fill in the detail between them, working from the nearest control point. An error made while picking up a fence line stays with that fence line; it cannot travel, because the next detail starts afresh from control." },
            { k: "list", items: [
              "<strong>Errors are confined</strong> rather than accumulated.",
              "<strong>The work can be split</strong> between several parties without them drifting apart.",
              "<strong>It can be checked</strong> — control points are surveyed redundantly, so a blunder in the framework shows up immediately.",
              "<strong>It can be added to years later</strong>, because the control is still there and still consistent.",
            ]},
            { k: "note", t: "This is why a national survey starts with a few hundred high-precision triangulation stations across the whole country and works down to street level, rather than starting in one town and spreading outwards. It is the same reason a building is set out from a grid rather than from the corner of the last column cast." },
          ],
        },

        {
          n: "1.3",
          title: "Fix a point by two measurements, and check it with a third",
          hi: "दो माप से स्थिति, तीसरे से जाँच",
          blocks: [
            { k: "p", t: "The second principle. A single measurement from a known point does not locate anything: a distance puts the point somewhere on a circle, a direction puts it somewhere on a line. It takes two independent measurements to reduce that to a single position." },
            { k: "dia", id: "hb-sv-fixpoint", cap: "Four patterns — and every method in this handbook is one of them." },
            { k: "list", items: [
              "<strong>Two distances</strong> from two known points — chain surveying, and trilateration.",
              "<strong>A perpendicular offset at a measured chainage</strong> — how detail is picked up along a chain line.",
              "<strong>One distance and one angle</strong> — a polar fix; this is what a total station does.",
              "<strong>Two angles</strong> from two known points — intersection, triangulation, and plane table work.",
            ]},
            { k: "p", t: "The third measurement is where the professionalism lives. Two measurements give an answer whether or not either is correct; three give an answer <em>and</em> tell you whether to believe it. The check line in a chain survey, the closing error of a traverse, the third face of a levelling circuit — all the same idea." },
            { k: "trap", t: "A survey with no redundancy cannot be wrong, in the sense that nothing in it will ever contradict anything else. That is not a strength, it is the absence of a test. <strong>A measurement you cannot check is a measurement you cannot defend</strong>, and the time to find that out is not in court." },
          ],
        },

        {
          n: "1.4",
          title: "Plane or geodetic",
          hi: "समतल या भूगणितीय",
          blocks: [
            { k: "p", t: "Plane surveying treats the earth as flat: level lines are straight, plumb lines are parallel, and plane trigonometry applies. Geodetic surveying allows for curvature and works on the surface of a spheroid. The question is when the first assumption stops being safe." },
            { k: "dia", id: "hb-sv-planegeo", cap: "The arc along the ground against the chord through it — and how much they actually differ." },
            { k: "p", t: "Two numbers settle it, and both are worth being able to produce rather than quote." },
            { k: "eq", expr: "arc − chord  ≈  s³ / (24 R²)", where: [
              ["s", "distance along the earth's surface"],
              ["R", "mean radius of the earth, about 6370 km"],
            ]},
            { k: "p", t: "Put s = 18.2 km and R = 6370 km into that: s³ = 6027 km³, 24R² = 9.74 × 10⁸ km², and the difference is 6.2 × 10⁻⁶ km — about <strong>6 mm over 18 km</strong>. No ordinary tape or EDM measurement is that good, so treating the arc as a straight line costs nothing." },
            { k: "trap", t: "Question banks state this ‘18.2 km’ result inconsistently — 1 cm, 1.5 cm, even 10 cm all appear as the ‘answer’ (see the discussion on <a href=\"https://www.indiabix.com/civil-engineering/surveying/discussion-635-5\" target=\"_blank\" rel=\"noopener\">IndiaBix</a>). Work it out instead: s³/(24R²) with R = 6370 km gives <strong>6.2 mm</strong>, and the difference only reaches 10 mm at about 21 km. ‘About a centimetre’ is the right order of magnitude; 10 cm is simply wrong." },
            { k: "eq", expr: "spherical excess  ε(seconds)  =  A × 206265 / R²", where: [
              ["A", "area of the triangle, in the same units as R²"],
            ]},
            { k: "p", t: "A triangle drawn on a curved surface has angles adding to more than 180°. For the excess to reach even one arc-second the triangle must cover R²/206265 = <strong>about 196 km²</strong> — roughly a 14 km square. An ordinary theodolite cannot reliably detect one second, so again the flat assumption holds." },
            { k: "list", items: [
              "<strong>Plane surveying</strong> — areas up to roughly 250 km² (the commonly quoted upper limit; e.g. <a href=\"https://prepp.in/question/which-one-is-the-upper-limit-of-survey-area-square-697f94647b6c7a95ec70c6fc\" target=\"_blank\" rel=\"noopener\">Prepp</a>). Virtually all engineering, cadastral and construction work.",
              "<strong>Geodetic surveying</strong> — national control networks, long tunnels driven from both ends, large dams, anything where positions must be consistent across hundreds of kilometres.",
            ]},
            { k: "note", t: "Levelling is the exception that catches people out. Curvature and refraction affect a single long sight at the <em>millimetre</em> level over a few hundred metres, not kilometres — so they matter in plane surveying, and Chapter 6 deals with them properly. Plane surveying ignores curvature in <em>plan</em>, not in <em>height</em>." },
          ],
        },

        {
          n: "1.5",
          title: "Classifying the work",
          hi: "सर्वेक्षण के प्रकार",
          blocks: [
            { k: "p", t: "Surveys are named after what they are for, and the name tells you what accuracy and what detail is expected." },
            { k: "list", items: [
              "<strong>Topographic</strong> — the shape of the ground and the natural and built features on it. Produces the contoured plan a design starts from.",
              "<strong>Cadastral</strong> — boundaries and ownership. Legal consequences, so the accuracy is defined by statute rather than by engineering need.",
              "<strong>Engineering</strong> — surveys for a specific work: route surveys for roads, railways and canals, and the setting out that follows.",
              "<strong>Hydrographic</strong> — beds of rivers, lakes, harbours and the sea. Soundings rather than levels, and the datum is tidal.",
              "<strong>Mine</strong> — surface and underground workings, tied together through shafts.",
              "<strong>Astronomical</strong> — determining position and azimuth from observations to the sun or stars. Largely replaced by GNSS, but the idea survives in how azimuths are checked.",
              "<strong>Archaeological, geological, military</strong> — the same instruments, different purposes and tolerances.",
            ]},
            { k: "p", t: "Classification by instrument is the other common list — chain, compass, plane table, theodolite, tacheometric, photogrammetric, GNSS — and that is how the rest of this handbook is organised, because the instrument determines the method, the errors and the checks." },
          ],
        },

        {
          n: "1.6",
          title: "Scales — and what goes wrong with them",
          hi: "पैमाना",
          blocks: [
            { k: "p", t: "Every survey ends up on a plan, and a plan is only as good as the scale it is drawn to and the paper it is drawn on. Two ideas cover almost every scale problem: the representative fraction, and what happens when either the scale or the sheet is not what it claims to be." },
            { k: "def", term: "Representative fraction (RF)", t: "The ratio of a distance on the plan to the same distance on the ground, in the same units: 1 cm = 10 m is RF = 1/1000, written 1 : 1000. A ‘large scale’ has a large RF (1 : 500 — lots of detail, small area); a ‘small scale’ a small one (1 : 50,000)." },
            { k: "p", t: "The smallest distance a draughtsman can plot sets the smallest feature a plan can show. If 0.10 mm is the least that can be drawn, a 1 : 10,000 plan cannot show anything smaller than 0.10 mm × 10,000 = 1.0 m — the example set in <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105107122/modules/module1/htmlpage/25.htm\" target=\"_blank\" rel=\"noopener\">NPTEL Surveying, Module 1</a>. Choose the scale from the smallest feature the user needs, not from the size of the paper." },
            { k: "h", t: "A shrunk plan" },
            { k: "p", t: "Paper shrinks with age and humidity. If a line that was drawn 10 cm long now measures 9.75 cm, every length on the sheet has shrunk by the same factor:" },
            { k: "eq", expr: "SF = shrunk length / original length;   true length = measured length / SF;   true area = measured area / SF²", where: [
              ["SF", "shrinkage factor, less than 1"],
            ]},
            { k: "p", t: "The area correction goes as SF² because area is length × length — the same reason as everything else in this section. The ‘shrunk scale’ of the sheet is simply SF × the original RF." },
            { k: "h", t: "A wrong scale, or a wrong chain" },
            { k: "p", t: "If lengths were measured with a chain or tape that is not its nominal length, every measured length is in error by the ratio of the two: true length = (L′/L) × measured length, where L′ is the actual and L the nominal length. Areas carry the square of the ratio. The same logic applies to a plan drawn to the wrong scale: true length = (RF used / RF intended) × measured length." },
            { k: "eg",
              title: "Example 1.1 — True area from a shrunk plan surveyed with a short chain",
              given: "A plan drawn to 1 cm = 15 m shows a plot of 115.5 cm². A line originally 10 cm long on the plan now measures 9.75 cm. The survey was made with a 30 m chain later found to be 5 cm too short.",
              steps: [
                { t: "Shrinkage factor", w: "SF = 9.75/10 = 0.975" },
                { t: "Area on the unshrunk plan", w: "115.5/0.975² = 115.5/0.950625 = 121.50 cm²" },
                { t: "Area on the ground, as measured with the faulty chain", w: "1 cm = 15 m  →  1 cm² = 225 m²\n121.50 × 225 = 27,337 m²" },
                { t: "Correct for the short chain", w: "actual chain length L′ = 30 − 0.05 = 29.95 m\ntrue area = (L′/L)² × measured area = (29.95/30)² × 27,337\n= 0.99667 × 27,337 = 27,246 m²" },
              ],
              ans: "True area ≈ 27,246 m² (2.72 ha). Shrinkage changed the answer by about 5%; the short chain by about 0.3% — and in the opposite direction, because a short chain over-reads lengths.",
            },
            { k: "note", t: "This combination — a shrunk plan surveyed with a faulty chain — is a standard university examination problem; the data above follow <a href=\"https://abesit.in/wp-content/uploads/2024/07/BCE302-SURVEYING-AND-GEOMATICS.pdf\" target=\"_blank\" rel=\"noopener\">an AKTU BCE302 examination question</a>." },
            { k: "trap", t: "The two corrections go opposite ways and are easy to invert. A <strong>shrunk</strong> plan under-reads, so you divide by SF² (making the area bigger). A <strong>short</strong> chain over-reads — it is laid down more times than it should be — so you multiply by (L′/L)² (making the area smaller). If both corrections pushed the same way, check your working." },
          ],
        },

        {
          n: "1.7",
          title: "What this handbook does next",
          hi: "आगे क्या",
          blocks: [
            { k: "list", items: [
              "<strong>Ch 2</strong> — errors: what kinds there are, which ones averaging fixes, and which ones it hides.",
              "<strong>Ch 3–4</strong> — the two oldest instruments: the chain for distance and the compass for direction.",
              "<strong>Ch 5</strong> — plane tabling, where the plot is made in the field.",
              "<strong>Ch 6–7</strong> — heights: levelling, and the contours that come out of it.",
              "<strong>Ch 8</strong> — the theodolite, and the traverse that is the workhorse of engineering control.",
              "<strong>Ch 9</strong> — tacheometry: distance without a tape.",
              "<strong>Ch 10–11</strong> — what the measurements are turned into: areas, volumes and curves.",
              "<strong>Ch 12</strong> — triangulation, total stations and GNSS.",
            ]},
            { k: "p", t: "Chapter 2 comes before any instrument on purpose. Every chapter after it will state a correction, a check or a permitted closing error, and none of that means very much until you can say what kind of error is being dealt with and why that particular treatment works on it." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "sv-2",
      n: 2,
      title: "Errors, Accuracy and Precision",
      hi: "त्रुटियाँ, यथार्थता और परिशुद्धता",
      blurb: "Three kinds of error, only one of which averaging will help you with — and how to state how good a measurement is.",
      mins: 42,
      sections: [

        {
          n: "2.1",
          title: "No measurement is exact",
          hi: "कोई माप पूर्ण नहीं",
          blocks: [
            { k: "p", t: "A measured length is never the true length. It is an estimate, and the useful question is never \"is it right?\" but <strong>\"how far out might it be, and in which direction?\"</strong> A surveyor who can answer that is doing engineering; one who cannot is guessing carefully." },
            { k: "p", t: "Errors come in three kinds, and they behave so differently that the same remedy helps one and actively conceals another." },
            { k: "def", term: "Mistakes (blunders)", t: "Gross errors from carelessness — a whole tape length miscounted, 6.32 booked as 3.62, the wrong staff read. They are not small and they do not average out. Only a <strong>check</strong> catches them, which is what §1.3's third measurement is for." },
            { k: "def", term: "Systematic (cumulative) errors", t: "Errors that follow a rule and keep the same sign: a tape 5 mm short, an uncorrected temperature, a line of sight that tilts up. They <strong>accumulate in proportion to the number of measurements</strong>, they can in principle be computed and removed, and repetition will never reveal them." },
            { k: "def", term: "Random (accidental, compensating) errors", t: "What is left after mistakes and systematic errors are gone — small variations of either sign from causes too numerous to track. They tend to cancel, they grow with the <strong>square root</strong> of the number of measurements rather than in proportion, and they are what the theory of errors is about." },
            { k: "trap", t: "The systematic error is the dangerous one precisely because the work looks good. Every reading agrees with the last, the field book is neat, and every value is wrong by the same amount in the same direction. <strong>Consistency is not correctness.</strong>" },
          ],
        },

        {
          n: "2.2",
          title: "Accuracy is not precision",
          hi: "यथार्थता ≠ परिशुद्धता",
          blocks: [
            { k: "dia", id: "hb-sv-accprec", cap: "Four targets. The second one is the one to be afraid of." },
            { k: "def", term: "Precision", t: "How closely a set of measurements agree <em>with each other</em>. A property of the instrument and the method." },
            { k: "def", term: "Accuracy", t: "How close they are to the <em>true value</em>. A property of the instrument, the method, <strong>and</strong> whether the systematic errors have been dealt with." },
            { k: "p", t: "A total station reading to a millimetre is precise. If its prism constant is set wrong it is precisely wrong, every time, by the same amount — and no number of repeat observations will tell you. This is why instruments are checked against a known baseline rather than against themselves." },
            { k: "list", items: [
              "More readings → random error falls as 1/√n. <strong>Averaging works.</strong>",
              "More readings → systematic error unchanged. <strong>Averaging does nothing.</strong>",
              "More readings → a mistake may show up as an outlier, if you are looking. <strong>Checking works.</strong>",
            ]},
            { k: "real", t: "You can see this on any construction site where levels have been taken with an instrument that has never been checked. Every level is beautifully consistent with every other, the whole floor is 15 mm out, and it is not discovered until something has to meet something else." },
          ],
        },

        {
          n: "2.3",
          title: "The most probable value",
          hi: "सर्वाधिक संभाव्य मान",
          blocks: [
            { k: "p", t: "Measure the same quantity n times under the same conditions and you get n slightly different answers. The value most likely to be correct — given only those observations — is their arithmetic mean." },
            { k: "eq", expr: "most probable value  =  Σ(observations) / n        residual  v = observation − mean", where: [] },
            { k: "p", t: "That is a result, not a definition: it follows from the <strong>principle of least squares</strong>, which states that the most probable set of values is the one making Σv² a minimum. For repeated measurements of a single quantity, the value that minimises the sum of squared residuals is exactly the mean." },
            { k: "h", t: "How good is it?" },
            { k: "eq", expr: "probable error of a single observation:   Es = ± 0.6745 √( Σv² / (n − 1) )", where: [] },
            { k: "eq", expr: "probable error of the mean:   Em = Es / √n  =  ± 0.6745 √( Σv² / (n(n − 1)) )", where: [] },
            { k: "p", t: "The 0.6745 is the factor that converts a standard deviation into the interval containing the true value with 50% probability — the \"probable error\" convention traditional in surveying. The part that matters is the <strong>√n</strong>: to halve the uncertainty of a mean you need four times as many observations, and to reduce it tenfold, a hundred times as many. That is the law of diminishing returns, written down." },
            { k: "note", t: "Modern practice states quality as a <strong>standard deviation</strong> σ = √(Σv²/(n − 1)) rather than as a probable error. They are the same information on different scales: probable error = 0.6745σ (50% confidence), σ itself covers about 68%, and 1.96σ about 95% — the figure an instrument specification or a GNSS report usually means. Always say which one you are quoting." },
            { k: "eg",
              title: "Example 2.1 — Most probable value of a line",
              given: "A line is measured five times with the same tape under the same conditions: 100.215, 100.222, 100.218, 100.226, 100.219 m.",
              steps: [
                { t: "Most probable value", w: "mean = 501.100/5 = 100.220 m" },
                { t: "Residuals v = observation − mean (mm)", w: "−5, +2, −2, +6, −1     (check: Σv = 0 ✓)\nΣv² = 25 + 4 + 4 + 36 + 1 = 70 mm²" },
                { t: "Standard deviation and probable error of one observation", w: "σ = √(70/4) = 4.18 mm\nEs = 0.6745 × 4.18 = ± 2.8 mm" },
                { t: "Of the mean", w: "σm = 4.18/√5 = 1.87 mm\nEm = 0.6745 × 1.87 = ± 1.3 mm" },
              ],
              ans: "Most probable length 100.220 m, probable error of the mean ± 1.3 mm (standard error ± 1.9 mm). This says nothing about whether the tape itself is right — that is a systematic error, and it is invisible here.",
            },
            { k: "note", t: "It is also the argument for fixing the systematic errors first. Once Em has been driven below the size of an uncorrected systematic error, further observations buy nothing at all — you are refining a number that is biased." },
          ],
        },

        {
          n: "2.4",
          title: "How errors combine",
          hi: "त्रुटियाँ कैसे जुड़ती हैं",
          blocks: [
            { k: "p", t: "A surveyed quantity is usually computed from several measured ones, and their errors have to be carried through. The rule depends on whether the errors are independent." },
            { k: "eq", expr: "sum or difference of independent quantities:   E = √(E₁² + E₂² + … + Eₙ²)", where: [] },
            { k: "p", t: "So a line measured in n equal bays, each with the same random error e, has a total random error of e√n — <em>not</em> ne. That square root is why a long line is not proportionally worse than a short one, and it is the single most useful result in this chapter." },
            { k: "eq", expr: "systematic errors, by contrast:   E = E₁ + E₂ + … + Eₙ", where: [] },
            { k: "p", t: "They add directly, because they all have the same sign. A tape 5 mm short used 50 times gives 250 mm of error, every time, with no cancellation whatever." },
            { k: "eg",
              title: "Example 2.2 — Systematic against random over one kilometre",
              given: "A 1 km line is measured with a 30 m tape. The tape is 3 mm too long (systematic), and each tape length also carries a random error of ± 3 mm.",
              steps: [
                { t: "Number of tape lengths", w: "n = 1000/30 = 33.3" },
                { t: "Systematic part — adds directly", w: "33.3 × 3 = 100 mm, all in one direction" },
                { t: "Random part — adds as √n", w: "3 × √33.3 = ± 17 mm" },
              ],
              ans: "The same 3 mm per tape length produces 100 mm of systematic error but only ± 17 mm of random error. Standardise the tape, and the job improves six-fold; measure the line again with the same tape, and it does not improve at all.",
            },
            { k: "h", t: "Products, and the general rule" },
            { k: "p", t: "For any quantity computed from independent measurements, f = f(x₁, x₂, …), each error contributes in proportion to how sensitive f is to that measurement:" },
            { k: "eq", expr: "E_f = √[ (∂f/∂x₁ · E₁)² + (∂f/∂x₂ · E₂)² + … ]", where: [
              ["∂f/∂x", "the rate at which the result changes with each measured quantity"],
            ]},
            { k: "p", t: "For a sum every partial derivative is 1 and this reduces to √(ΣE²). For an area A = a × b, ∂A/∂a = b and ∂A/∂b = a, so E_A = √((b·E_a)² + (a·E_b)²)." },
            { k: "eg",
              title: "Example 2.3 — Error in a computed area",
              given: "A rectangular plot is measured as 50.00 m ± 0.020 m by 30.00 m ± 0.015 m (independent errors).",
              steps: [
                { t: "Area", w: "A = 50.00 × 30.00 = 1500.0 m²" },
                { t: "Contributions", w: "from the length: b × Ea = 30 × 0.020 = 0.60 m²\nfrom the width:  a × Eb = 50 × 0.015 = 0.75 m²" },
                { t: "Combined", w: "E_A = √(0.60² + 0.75²) = √0.9225 = ± 0.96 m²" },
              ],
              ans: "1500.0 ± 0.96 m² — about 1 in 1560. The smaller error on the short side matters more, because it is multiplied by the long side.",
            },
            { k: "h", t: "Weighted observations" },
            { k: "p", t: "Not every observation deserves equal trust. An angle observed four times is better than one observed once; a line measured with an EDM is better than the same line chained. Weights express that, and the weighted mean is used instead of the plain one." },
            { k: "eq", expr: "weighted mean  =  Σ(w × observation) / Σw        weight  w ∝ 1/E²", where: [] },
            { k: "p", t: "Weight is inversely proportional to the <em>square</em> of the probable error — so an observation twice as good counts four times as much. For a mean of several sets, weight is proportional to the number of observations in the set, which falls straight out of the 1/√n rule." },
            { k: "eg",
              title: "Example 2.4 — Weighted mean of an angle",
              given: "The same angle is measured by three parties: 47°30′20″ (probable error ± 2″), 47°30′26″ (± 3″) and 47°30′22″ (± 4″).",
              steps: [
                { t: "Weights ∝ 1/E²", w: "1/4 : 1/9 : 1/16  =  36 : 16 : 9  (multiplying by 144)" },
                { t: "Weighted mean of the seconds", w: "(36 × 20 + 16 × 26 + 9 × 22)/(36 + 16 + 9)\n= (720 + 416 + 198)/61 = 1334/61 = 21.87″" },
                { t: "Probable error of the weighted mean", w: "Ewm = 1/√(Σ 1/E²) = 1/√(0.25 + 0.111 + 0.0625) = 1/√0.4236 = ± 1.54″" },
              ],
              ans: "47°30′21.9″ ± 1.5″. The plain mean (22.7″) would have given the poorest observation the same say as the best.",
            },
          ],
        },

        {
          n: "2.5",
          title: "Stating how good a survey is",
          hi: "सर्वेक्षण की गुणवत्ता कैसे बताएँ",
          blocks: [
            { k: "p", t: "Surveyors quote accuracy as a ratio — 1 in 1000, 1 in 5000, 1 in 25,000 — meaning the misclosure divided by the total length measured. It is a useful convention because it is dimensionless and scales." },
            { k: "cmp", t: "What ratio to expect from what method. These are working figures, not code values — the point is the order of magnitude and the gap between them.",
              cols: ["Typical accuracy"],
              rows: [
                ["Pacing", "1 in 100 to 1 in 200"],
                ["Ordinary chaining, rough ground", "1 in 500"],
                ["Careful chaining with corrections applied", "1 in 1000 to 1 in 5000"],
                ["Compass traverse", "1 in 300 to 1 in 600"],
                ["Theodolite traverse, engineering work", "1 in 5000 to 1 in 10,000"],
                ["Total station traverse", "1 in 10,000 and better"],
                ["Precise levelling, per km of circuit", "a few mm"],
              ] },
            { k: "p", t: "The practical use of that table is deciding when to stop. If a job needs 1 in 1000, a theodolite traverse already has margin and a total station is being bought for nothing. If it needs 1 in 10,000, no amount of care with a compass will get there and the method itself has to change." },
            { k: "trap", t: "A stated ratio is meaningless without saying what was misclosed. \"1 in 5000\" on a traverse that was never closed is an assertion, not a measurement. <strong>The ratio is only real if there was a check that could have failed.</strong>" },
          ],
        },

        {
          n: "2.6",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Mistakes are caught by checks; systematic errors by computation or technique; random errors by averaging.",
              "Repetition exposes random error and conceals systematic error.",
              "Precision is agreement; accuracy is truth. A systematic error gives you the first without the second.",
              "Most probable value = the mean. Its probable error falls as 1/√n.",
              "Independent random errors combine as √(ΣE²) — in general as √Σ(∂f/∂x · E)²; systematic errors add directly.",
              "Weight ∝ 1/E².",
              "Quote accuracy as a ratio — and only if something was actually closed.",
            ]},
            { k: "p", t: "Chapter 3 applies all of this immediately. Every one of the five tape corrections is a systematic error being computed and removed, and the check line is the redundancy that catches the blunders the corrections cannot." },
          ],
        },
      ],
    },

  ],
});
