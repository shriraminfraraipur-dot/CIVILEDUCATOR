/* Surveying class notes — Levelling (peg setting, old level book, dumpy & tilting levels, two-peg test, curvature & refraction, visible distance, reciprocal levelling), notes p.85–97 — inserted into sv chapter 6 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 6; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- p.84–86 */
    {
      n: "",
      title: "Notes — setting out pegs on a falling gradient (p.84–86)",
      hi: "ढलान पर खूँटियाँ गाड़ना — लेवल बुक",
      blocks: [
        { k: "h", t: "📘 Notes — p.85–86 (question on p.84)" },
        { k: "p", t: "<b>Q.</b> The following observations were made in running fly levels from a BM of RL 60.65. BS: 0.964, 1.632, 1.105, 0.850 · FS: 0.948, 1.153, 1.984. 5 pegs at 20 m interval are to be set on a <b>falling gradient of 1 in 100</b> from the last position of the instrument. The first peg is to be at RL 60. Work out the staff readings required for setting the pegs and prepare the page of the level book. (p.84)" },
        { k: "list", items: [
          "<b>Figure (p.85):</b> longitudinal ground profile — ground curves down from a hump at the left, runs fairly level, then slopes down to the right. A horizontal dashed <b>line of sight</b> runs across the top. On the level part a staff is drawn with the height of instrument <b>61.116</b> marked up to the line of sight; the level (tripod) stands to its right.",
          "Further right, on the down-slope: peg <b>P₁</b> with <b>RL = 60</b> written below it, then pegs <b>P₂, P₃, P₄, P₅</b> successively lower. A vertical staff is drawn at every peg up to the line of sight. At each peg a short horizontal line is drawn at the previous peg's level and the drop to the next peg is labelled <b>0.2</b>. (p.85)",
        ] },
        { k: "cmp", t: "Level book (height of instrument method) — as prepared in the notes (p.85)", cols: ["Readings", "HOI", "RL"], rows: [
          ["A (BM)", "BS 0.964", "61.614", "60.65"],
          ["B", "FS 0.948 · BS 1.632", "62.298", "60.666"],
          ["C", "FS 1.153 · BS 1.105", "62.25", "61.195 (as written in the table)"],
          ["D", "FS 1.984 · BS 0.850", "61.116", "60.266"],
          ["P₁", "IS 1.116", "—", "60"],
          ["P₂", "IS 1.316", "—", "59.8"],
          ["P₃", "IS 1.516", "—", "59.6"],
          ["P₄", "IS 1.716", "—", "59.4"],
          ["P₅", "FS 1.916", "—", "59.2"],
        ] },
        { k: "note", t: "<b>Check:</b> RL of C = 62.298 − 1.153 = <b>61.145</b>. The table on p.85 shows 61.195, but the working on p.86 (written over) gives 61.145 and uses 61.145 for the next step (HOI of C = 61.145 + 1.105 = 62.25). The correct RL of C is 61.145; every later value in the book (62.25, 60.266, 61.116) is consistent with 61.145." },
        { k: "eg",
          title: "Notes example — staff readings for setting pegs on a 1 in 100 falling gradient",
          given: "Fly levels from a BM of RL 60.65: BS 0.964, 1.632, 1.105, 0.850; FS 0.948, 1.153, 1.984. 5 pegs at 20 m interval are to be set on a falling gradient of 1 in 100 from the last position of the instrument. The first peg is to be at RL 60. Work out the staff readings required for setting the pegs and prepare the page of the level book.",
          steps: [
            { t: "HOI of A", w: "HOI = RL + BS\n= 60.65 + 0.964\n= 61.614" },
            { t: "RL of B and HOI at B", w: "RL of B = HOI − FS at B = 61.614 − 0.948 = 60.666\nHOI at B = 60.666 + 1.632 = 62.298" },
            { t: "RL of C and HOI of C", w: "RL of C = HOI − FS = 62.298 − 1.153 = 61.145\nHOI of C = RL + BS at C = 61.145 + 1.105 = 62.25" },
            { t: "RL of D and HOI at D", w: "RL of D = HOI − FS = 62.25 − 1.984 = 60.266\nHOI at D = RL + BS = 60.266 + 0.850 = 61.116" },
            { t: "Fall between pegs", w: "Gradient = 1 in 100 (downward slope); pegs equidistant at 20 m\nFall at each peg station = (1/100) × 20 = 0.2 m" },
            { t: "Peg P₁ — no instrument change", w: "RL of P₁ = HOI − IS\n60 = 61.116 − IS\nIS = 1.116" },
            { t: "Peg P₂ — downward slope", w: "RL of P₂ = 60 − 0.2 = 59.8\nStaff reading at P₂ = 61.116 − 59.8 = 1.316" },
            { t: "Similarly for all", w: "P₃: RL 59.6, reading 1.516\nP₄: RL 59.4, reading 1.716\nP₅: RL 59.2, reading 1.916 (booked as FS — last reading)" },
          ],
          ans: "Staff readings for setting the pegs: P₁ 1.116, P₂ 1.316, P₃ 1.516, P₄ 1.716, P₅ 1.916 (RLs 60, 59.8, 59.6, 59.4, 59.2). (p.85–86)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Yahan levelling ulta chalta hai. Normally staff reading lo aur RL nikalo (RL = HOI − reading). Peg setting me RL pehle se pata hai (design gradient se), to staff reading nikalte hain: <b>required reading = HOI − required RL</b>. Staffman peg ko tab tak thokta hai jab tak staff par yahi reading na aa jaye. Falling gradient me har peg 0.2 m neeche hai, isliye har peg ki reading 0.2 m <b>badhti</b> hai (1.116 → 1.316 → …)." },
        { k: "p", t: "Fly levelling (A → D) sirf height ko BM se peg site tak le kar aane ke liye hai — change points B, C par FS aur BS dono book hote hain. Instrument D par hi rehta hai, isliye sab pegs ek hi HOI (61.116) se set hote hain; P₁–P₄ intermediate sights hain aur P₅ last reading hone se FS. Book ka check: ΣBS − ΣFS = last RL − first RL (section 6.3)." },
        { k: "trap", t: "Falling gradient par students reading ko bhi 0.2 se <b>ghata</b> dete hain. Ulta hai: point jitna neeche, staff utni zyada lambi dikhegi, to reading <b>badhti</b> hai. RL ghatta hai, reading badhti hai." },
        { k: "real", t: "Sewer lines, drains aur road formation par grade pegs bilkul isi tarah lagte hain: ek HOI se har chainage ki 'required staff reading' table bana lo, phir staff par woh reading aane tak peg ko thoko." },
      ],
    },

    /* ---------------------------------------------------------- p.87–89 */
    {
      n: "",
      title: "Notes — reconstructing an old level book, with collimation correction (p.87–89)",
      hi: "पुरानी लेवल बुक का पुनर्निर्माण और कोलिमेशन सुधार",
      blocks: [
        { k: "h", t: "📘 Notes — p.87–89" },
        { k: "p", t: "<b>Q.</b> The following readings have been taken from the page of an old level book. It is required to reconstruct the page, fill up the missing quantities and apply the usual check. Also calculate the corrected level of the [last] Temporary BM (TBM) if the instrument is known to have an <b>elevated collimation error of 30″</b>, and backsight and foresight distances average <b>40 m and 90 m</b> respectively. (p.87)" },
        { k: "cmp", t: "Reconstructed page (rise and fall method) — values underlined in the notes are the filled-in missing quantities (p.87)", cols: ["Readings", "Rise / Fall", "RL"], rows: [
          ["1", "BS 3.125", "—", "<b>124.18</b>"],
          ["2", "<b>FS 1.8</b> · <b>BS 2.265</b>", "Rise 1.325", "125.505"],
          ["3", "IS 2.320", "Fall 0.055", "<b>125.45</b>"],
          ["4", "<b>IS 1.92</b>", "<b>Rise 0.4</b>", "125.850"],
          ["5", "FS 2.655 · <b>BS 1.04</b>", "Fall 0.735", "<b>125.115</b>"],
          ["6", "FS 3.205 · BS 1.620", "Fall 2.165", "<b>122.95</b>"],
          ["7", "IS 3.625", "Fall 2.005", "<b>120.945</b>"],
          ["8", "<b>FS 1.48</b>", "<b>Rise 2.145</b>", "123.090"],
          ["Σ", "ΣBS 8.05 · ΣFS 9.14", "ΣRise 3.87 · ΣFall 4.96", "—"],
        ] },
        { k: "note", t: "Notes' remark under the table: <b>last reading always FS</b>. (p.87)" },
        { k: "eg",
          title: "Notes example — reconstructing the old level book page",
          given: "Readings from the page of an old level book (rise and fall method), with missing quantities to be filled in and the usual check applied: Point 1 BS 3.125; Point 2 Rise 1.325, RL 125.505; Point 3 IS 2.320, Fall 0.055; Point 4 RL 125.850; Point 5 FS 2.655, Fall 0.735; Point 6 BS 1.620, FS 3.205, Fall 2.165; Point 7 IS 3.625, Fall 2.005; Point 8 RL 123.090.",
          steps: [
            { t: "① FS of 2 and RL of 1", w: "BS of 1 − FS of 2 = 1.325\n3.12 − FS of 2 = 1.325\nFS of 2 = 1.8\nRL of 1 = 125.505 − 1.325 = 124.18" },
            { t: "② BS of 2", w: "BS of 2 − IS of 3 = −0.055\nBS of 2 − 2.320 = −0.055\nBS of 2 = 2.265" },
            { t: "③ RL of 3", w: "RL of 3 = 125.505 − 0.055 = 125.45" },
            { t: "④ Rise at 4", w: "Rise at 4 = RL of 4 − RL of 3\n= 125.850 − 125.45\n= 0.4" },
            { t: "⑤ IS of 4", w: "IS of 3 − IS of 4 = +0.4\n2.320 − IS of 4 = +0.4\nIS of 4 = 1.92" },
            { t: "⑥ Fall at 5 and RL at 5", w: "IS of 4 − FS at 5\n1.92 − 2.655 = −0.735 (Fall)\nRL at 5 = 125.115" },
            { t: "BS at 5 and RL at 6", w: "BS at 5 − FS at 6 = −2.165\nBS at 5 − 3.205 = −2.165\nBS at 5 = 1.04\nRL at 6 = 125.115 − 2.165 = 122.95" },
            { t: "RL at 7", w: "BS at 6 − IS of 7\n1.620 − 3.625 = −2.005\nRL at 7 = 122.95 − 2.005 = 120.945" },
            { t: "Rise at 8 and FS of 8", w: "Rise at 8 = 123.090 − 120.9 = 2.145\nIS of 7 − FS of 8 = +2.145\nFS of 8 = 1.48" },
            { t: "Usual (arithmetic) check", w: "ΣBS − ΣFS = ΣRise − ΣFall = last RL − first RL\n8.05 − 9.14 = 3.87 − 4.96 = 123.090 − 124.18\n= −1.09" },
          ],
          ans: "Missing quantities: FS₂ 1.8, BS₂ 2.265, IS₄ 1.92, BS₅ 1.04, FS₈ 1.48, Rise₄ 0.4, Rise₈ 2.145, RL₁ 124.18, RL₃ 125.45, RL₅ 125.115, RL₆ 122.95, RL₇ 120.945. Check: ΣBS − ΣFS = ΣRise − ΣFall = last RL − first RL = −1.09. (p.87–89)",
        },
        { k: "note", t: "<b>Check:</b> in the last step the notes write “123.090 − 120.9”; RL at 7 is <b>120.945</b>, so Rise at 8 = 123.090 − 120.945 = <b>2.145</b> — the notes' answer is right, only the RL was written short. Also in step ① the notes write 3.12 for BS of 1 (3.125): 3.125 − 1.325 = 1.800, so FS of 2 = 1.8 is right." },
        { k: "h", t: "Correction for collimation error (p.89)" },
        { k: "list", items: [
          "<b>Figure (p.89):</b> a horizontal line from the instrument to a vertical staff, and an inclined line above it from the same point making an angle of <b>30″</b> with the horizontal. The vertical intercept on the staff between the two lines is labelled <b>30/206265</b> (per unit distance — the angle in radians).",
        ] },
        { k: "eq", expr: "Error in a reading = (α″ × D) / 206265", where: [
          ["α″", "collimation error in seconds (30″)"],
          ["D", "sight distance (40 m for BS, 90 m for FS)"],
          ["206265", "seconds in one radian"],
        ] },
        { k: "eg",
          title: "Notes example — corrected level of the last TBM (elevated collimation error 30″)",
          given: "Same level book (ΣBS = 8.05, ΣFS = 9.14, first RL = 124.18). The instrument has an elevated collimation error of 30″; backsight and foresight distances average 40 m and 90 m respectively. Calculate the corrected level of the last TBM.",
          steps: [
            { t: "Correction to each BS", w: "−(30 × 40)/206265 = −0.006" },
            { t: "Correction to each FS", w: "−(30 × 90)/206265 = −0.013" },
            { t: "Check with corrected sums", w: "ΣBS (corrected) − ΣFS (corrected) = last RL − first RL" },
            { t: "Apply to 4 BS and 4 FS", w: "(8.05 − 4 × 0.006) − [9.14 − (4 × 0.013)] = last RL (corrected) − first RL\n(4 = No. of BS; 4 = No. of FS)" },
            { t: "First RL stays the same (पहले वाला ही रहेगा)", w: "8.026 − 9.088 = Last RL − (124.18)" },
          ],
          ans: "Last RL corrected = 123.11 (p.89)",
        },
        { k: "note", t: "<b>Check:</b> 8.026 − 9.088 = −1.062, so last RL = 124.18 − 1.062 = <b>123.118 ≈ 123.12</b> (with unrounded corrections, 123.119). The notes' boxed 123.11 is 123.118 cut off at two decimals rather than rounded." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Reconstruction ka ek hi mantra hai: <b>rise/fall = previous reading − current reading</b> (same set-up par). Positive aaye to rise, negative to fall. Change point par previous reading = BS, current = FS; intermediate par IS. Jo bhi ek cheez missing ho, isi equation ko ulta solve karo. RL ke liye: RL = previous RL ± rise/fall." },
        { k: "p", t: "Collimation correction: 'elevated' error ka matlab line of sight upar ki taraf jhuki hai, to har reading <b>zyada</b> padhi gayi — isliye har BS aur FS se ghatao. Error distance ke proportion me hai (D × α/206265). Agar BS aur FS distances barabar hote (40 = 40) to dono correction cancel ho jaate; yahan FS lambe (90 m) hain isliye net asar bacha. First RL ek known value hai, us par koi correction nahi lagta." },
        { k: "trap", t: "Correction <b>har reading</b> par lagta hai, isliye BS ki ginti (4) aur FS ki ginti (4) se multiply karna hai — sirf ek baar 0.006 aur 0.013 ghata dena galat hai. Aur IS par correction ka check par koi asar nahi, kyunki IS ΣBS − ΣFS me aata hi nahi." },
      ],
    },

    /* ---------------------------------------------------------- p.90–92 */
    {
      n: "",
      title: "Notes — dumpy & tilting levels, permanent adjustments and the two-peg test (p.90–92)",
      hi: "डम्पी व टिल्टिंग लेवल, स्थायी समायोजन और टू-पेग टेस्ट",
      blocks: [
        { k: "h", t: "📘 Notes — p.90–92" },
        { k: "def", term: "Dumpy level", t: "The telescope and spindle are cast as <b>one piece</b>. Levelling is done using levelling screws; under proper adjustment the <b>axis of the bubble tube should be perpendicular to the axis of the instrument (vertical axis)</b>. (p.90)" },
        { k: "def", term: "Tilting level", t: "The line of sight <b>need not be perpendicular</b> to the vertical axis. (p.90)" },
        { k: "h", t: "Permanent adjustments (p.90)" },
        { k: "list", items: [
          "(a) Axis of bubble tube should be perpendicular to the vertical axis. Line of sight should be <b>parallel to the axis of the bubble tube</b>.",
          "(b) Horizontal cross hair shall be perpendicular to the vertical axis.",
          "To make the line of sight parallel to the axis of the bubble tube, the <b>2-peg test</b> is performed. (p.90)",
        ] },
        { k: "h", t: "Two-peg test — set-up 1: instrument midway (p.90)" },
        { k: "list", items: [
          "<b>Figure (p.90):</b> staffs at A (left) and B (right) on level ground; the level is set up between them. A horizontal dashed true line of sight goes to both staffs; the erroneous (inclined) line of sight rises to each staff at angle <b>e</b> with the horizontal on both sides. On staff A: reading <b>a₁</b> (ground to inclined line) and error intercept <b>D₁e</b>. On staff B: reading <b>b₁</b> and error intercept <b>D₂e</b>. Distance A–instrument = <b>D₁</b>, instrument–B = <b>D₂</b>.",
        ] },
        { k: "steps", items: [
          "Corrected reading at A = a₁ − D₁e",
          "Corrected reading at B = b₁ − D₂e",
          "Δh<sub>AB</sub> = a₁ − b₁ = a₁ − D₁e − b₁ + D₂e",
          "D₁ = D₂ ⇒ <b>Δh<sub>AB</sub> = a₁ − b₁</b> ——— ① (p.90)",
        ] },
        { k: "h", t: "Two-peg test — set-up 2: instrument outside (p.91)" },
        { k: "list", items: [
          "<b>Figure (p.91):</b> staffs at A and B, level set up to the right beyond B. Horizontal true line of sight to both staffs; inclined line rising from the instrument at angle <b>e</b> toward A. Reading on A = <b>a₂</b>, on B = <b>b₂</b>. Error intercept at A = <b>(D₁ + D₂ + D₃)e</b>; at B = <b>D₃·e</b>. Ground distances: D₁ (A to an intermediate tick), D₂ (tick to B), D₃ (B to instrument).",
        ] },
        { k: "steps", items: [
          "Correct reading at A = a₂ − [D₁ + D₂ + D₃]e",
          "Correct reading at B = b₂ − D₃e",
          "Difference in elevation: Δh<sub>AB</sub> = a₂ − [(D₁ + D₂ + D₃)e − b₂ + D₃·e] ——— ②",
          "From ① and ②: a₁ − b₁ = a₂ − D₁e − D₂e − D₃e − b₂ + D₃e (the D₃e terms cancel)",
          "a₁ − b₁ = (a₂ − b₂) − (D₁ + D₂)e",
          "(D₁ + D₂)e = (a₂ − b₂) − (a₁ − b₁) (p.91)",
        ] },
        { k: "note", t: "<b>Check:</b> equation ② as bracketed in the notes, a₂ − [(D₁+D₂+D₃)e − b₂ + D₃e], would expand to a₂ − (D₁+D₂+D₃)e + b₂ − D₃e. The intended (and correct) form is Δh<sub>AB</sub> = [a₂ − (D₁+D₂+D₃)e] − [b₂ − D₃e] = a₂ − (D₁+D₂+D₃)e − b₂ + D₃e, which is what the notes use in the next line. The final formula for e is correct." },
        { k: "eq", expr: "e = [(a₂ − b₂) − (a₁ − b₁)] / (D₁ + D₂)", where: [
          ["a₁, b₁", "readings on A and B with the instrument midway"],
          ["a₂, b₂", "readings on A and B with the instrument outside (beyond B)"],
          ["D₁ + D₂", "distance between the two pegs"],
          ["e", "collimation error, in radians (error per unit distance)"],
        ] },
        { k: "eg",
          title: "Notes example — collimation error of a tilting level by two-peg test",
          given: "In order to check the adjustment of a tilting level the following procedure was followed. Pegs A, B, C, D were set out on a straight line such that AB = BC = CD = 30 m. The level was set up at B and readings were taken on A and C. The level was then moved to D and readings were taken again on A and C. Level at B: staff on A 1.926, staff on C 1.462. Level at D: staff on A 2.445, staff on C 1.945. Determine the collimation error.",
          steps: [
            { t: "Formula", w: "e = ((a₂ − b₂) − (a₁ − b₁))/(D₁ + D₂)" },
            { t: "Substitute (D₁ = AB = 30, D₂ = BC = 30)", w: "= ((2.445 − 1.945) − (1.926 − 1.462))/(30 + 30)" },
            { t: "Result", w: "= (0.500 − 0.464)/60\n= 0.0006 radian" },
          ],
          ans: "Collimation error e = 0.0006 radian (p.92)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Two-peg test ka idea: jab instrument <b>beech me</b> hota hai to dono staff par error barabar (D₁e = D₂e) hota hai aur difference me cancel ho jaata hai — isliye a₁ − b₁ hi <b>sahi</b> height difference hai. Phir instrument ko bahar rakhte hain jahan dono distances alag hain; ab difference me (D₁ + D₂)e ka error bach jaata hai. Dono differences ka antar ÷ peg distance = e." },
        { k: "p", t: "Dumpy me telescope spindle ke saath fix hai, isliye bubble tube ka axis vertical axis ke perpendicular hona zaroori hai (warna ghumane par bubble bhaagega). Tilting level me telescope thoda tilt hota hai aur har reading se pehle bubble centre karte hain, isliye wahan sabse important condition hai: <b>line of sight ∥ bubble tube axis</b> — aur yahi two-peg test check karta hai. Section 6.4 ka worked example isi test ko dusri layout se karta hai." },
        { k: "trap", t: "Example me pegs A, B, C, D hain, par formula ke 'A aur B' yahan <b>A aur C</b> hain (staff A aur C par hai; B aur D sirf instrument stations). Isliye D₁ + D₂ = AB + BC = 60 m, 90 m nahi — CD (= D₃) formula me cancel ho jaata hai." },
        { k: "real", t: "Site par naye ya giraye hue level ka two-peg test har kaam shuru karne se pehle karna chahiye; error mile to ya to instrument adjust karo, ya har set-up par BS aur FS distances barabar rakho taaki error cancel ho jaye." },
      ],
    },

    /* ---------------------------------------------------------- p.92–94 */
    {
      n: "",
      title: "Notes — curvature, refraction, combined correction and distance visible (p.92–94)",
      hi: "वक्रता, अपवर्तन, संयुक्त सुधार और दृश्य दूरी",
      blocks: [
        { k: "h", t: "📘 Notes — p.92–94" },
        { k: "p", t: "When the lines of sight are long, the effects of <b>curvature and refraction</b> are taken into account. (p.92)" },
        { k: "h", t: "Curvature effect" },
        { k: "p", t: "The effect of curvature occurs because the difference between the <b>level line</b> and the <b>horizontal line</b> increases as the distance between staff station and instrument station increases. The level line is a curved line, but the line of collimation is a horizontal line which is <b>tangential</b> to the level line. (p.92)" },
        { k: "p", t: "Due to curvature the error is <b>positive</b>, so the correction is <b>negative</b>. (p.93)" },
        { k: "eq", expr: "Cc = −0.0785 d²", where: [
          ["Cc", "curvature correction (m)"],
          ["d", "distance between staff station and instrument (km)"],
        ] },
        { k: "h", t: "Refraction effect correction" },
        { k: "p", t: "Error due to refraction is <b>negative</b>, so the correction is <b>positive</b>. (p.93)" },
        { k: "eq", expr: "C_R = |(1/7) Cc| = |(1/7)(−0.0785 d²)|  →  C_R = +0.0112 d²", where: [
          ["C_R", "refraction correction (m)"],
          ["d", "distance (km)"],
        ] },
        { k: "h", t: "Combined correction" },
        { k: "eq", expr: "C = Cc + C_R = −0.0785 d² + 0.0112 d²  →  C = −0.0673 d²", where: [
          ["C", "combined correction for curvature and refraction (m), d in km"],
        ] },
        { k: "note", t: "<b>Check:</b> the notes write the first term as “−0.0785R²”; it should read −0.0785<b>d²</b> (d = distance in km). The result C = −0.0673d² is correct (−0.0785 + 0.0112 = −0.0673)." },
        { k: "h", t: "Distance visible (p.94)" },
        { k: "list", items: [
          "<b>Figure (p.94):</b> a curved level line (earth surface) with a straight tangent line of length <b>d</b> drawn from the tangent point; at the far end the vertical offset <b>h</b> between the tangent line and the curved line is marked with a double arrow.",
          "h = combined correction due to curvature and refraction. (p.94)",
        ] },
        { k: "eq", expr: "h = 0.0673 d²      d = 3.854 √h", where: [
          ["h", "height above the level surface (m)"],
          ["d", "distance visible (km)"],
        ] },
        { k: "list", items: [
          "<b>Figure (p.94, lighthouse):</b> curved sea surface (arc). A horizontal tangent line touches the arc at its top and is divided at the tangent point into <b>d₁</b> (left) and <b>d₂</b> (right). At the left end the observer's height <b>8 m</b> is shown between the tangent line and the arc; at the right end the lighthouse height <b>40 m</b>.",
        ] },
        { k: "eg",
          title: "Notes example — distance between ship and lighthouse",
          given: "An observer standing on the deck of a ship just sees the lighthouse which is 40 m above sea level. If the observer's eye is 8 m above sea level, determine the distance between the observer and the lighthouse.",
          steps: [
            { t: "Distance visible from each height (d = 3.854√h)", w: "d = d₁ + d₂" },
            { t: "Distance between observer and lighthouse", w: "d = 3.854√8 + 3.854√40" },
          ],
          ans: "d = 35.27 km (p.94)",
        },
        { k: "note", t: "<b>Check:</b> 3.854√8 = 10.90 km and 3.854√40 = 24.37 km; total 3.854 × (2.8284 + 6.3246) = <b>35.276 km ≈ 35.28 km</b>. The notes' 35.27 km is the same value cut off at two decimals." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Instrument ki line of sight seedhi (tangent) jaati hai, par zameen/paani ki level line neeche mudti jaati hai. Isliye door ki staff par reading <b>zyada</b> aati hai → curvature error positive, correction negative. Hawa ki layers ray ko thoda neeche (zameen ki taraf) mod deti hain, jo is error ka lagbhag 1/7 wapas kar deta hai → refraction correction positive. Net: 0.0785 − 0.0112 = 0.0673." },
        { k: "p", t: "Distance visible wahi formula ulta hai: agar aankh h metre upar hai to horizon d = 3.854√h km door. Ship aur lighthouse dono ka horizon ek hi tangent point par milta hai, isliye dono distances <b>jodte</b> hain. Section 6.5 me yahi formula 3.855 constant ke saath likha hai — dono √(1/0.0673) ki rounding hain." },
        { k: "trap", t: "Formula me d <b>km</b> me aur correction <b>metre</b> me hai. d = 630 m ko 630 rakh doge to answer hazaaron metre aayega — pehle 0.63 km karo. Aur lighthouse sawaal me √(8 + 40) nahi, √8 + √40 lena hai." },
        { k: "real", t: "Ordinary levelling me sights 100 m ke aas-paas hote hain, wahan combined correction bahut chhota hai; par river crossings, lambi sights aur coast/tower visibility (triangulation stations ki intervisibility) me yeh correction zaroori ho jaata hai." },
      ],
    },

    /* ---------------------------------------------------------- p.95–97 */
    {
      n: "",
      title: "Notes — reciprocal levelling and its worked example (p.95–97)",
      hi: "पारस्परिक (रेसिप्रोकल) लेवलिंग",
      blocks: [
        { k: "h", t: "📘 Notes — p.95–97" },
        { k: "def", term: "Reciprocal levelling", t: "Used to determine the <b>correct difference in elevation</b> between two points which are quite far apart, such that it is <b>not possible to set up the instrument between these two points</b>. Eg — opposite banks of a river or valley. (p.95)" },
        { k: "list", items: [
          "Reciprocal levelling eliminates the need of correction due to — 1) Curvature · 2) Refraction · 3) Collimation. (p.95)",
        ] },
        { k: "h", t: "Case 1 — instrument set up at A (p.95)" },
        { k: "list", items: [
          "<b>Figure (p.95):</b> valley/river profile between A (left bank) and B (right bank). Instrument set up just left of A; staff at A reads <b>a₁</b>; staff at B reads <b>b₁</b>; horizontal line of sight drawn from the instrument across to the staff at B.",
        ] },
        { k: "steps", items: [
          "Staff reading at A = a₁ (correct)",
          "Staff reading at B = b₁ (wrong)",
          "Correct reading at B = (b₁ − e)",
          "Difference of elevation between A and B: Δh<sub>AB</sub> = (b₁ − e) − a₁ ——— ① (p.95)",
        ] },
        { k: "h", t: "Case 2 — instrument set up at B (p.95–96)" },
        { k: "list", items: [
          "<b>Figure (p.95):</b> same valley profile; instrument set up just right of B; staff at A reads <b>a₂</b>; staff at B reads <b>b₂</b>; horizontal line of sight drawn from the instrument across to the staff at A.",
        ] },
        { k: "steps", items: [
          "Staff reading at A = a₂ (wrong)",
          "Staff reading at B = b₂ (correct)",
          "Correct reading at A = (a₂ − e)",
          "Difference of elevation between A and B: Δh<sub>AB</sub> = b₂ − (a₂ − e) ——— ② (p.96)",
        ] },
        { k: "h", t: "True difference in elevation — ① + ② (p.96)" },
        { k: "steps", items: [
          "2Δh<sub>AB</sub> = (b₁ − e) − a₁ + b₂ − a₂ + e",
          "2Δh<sub>AB</sub> = (b₁ + b₂) − (a₁ + a₂)",
        ] },
        { k: "eq", expr: "Δh_AB = [(b₁ − a₁) + (b₂ − a₂)] / 2", where: [
          ["a₁, b₁", "readings on A and B, instrument at A"],
          ["a₂, b₂", "readings on A and B, instrument at B"],
        ] },
        { k: "h", t: "Determination of collimation error — ① = ② (p.96–97)" },
        { k: "steps", items: [
          "(b₁ − e) − a₁ = b₂ − a₂ + e",
          "b₁ − e − a₁ = b₂ − a₂ + e",
          "(b₁ − a₁) − (b₂ − a₂) = 2e",
        ] },
        { k: "eq", expr: "e = [(b₁ − a₁) − (b₂ − a₂)] / 2", where: [
          ["e", "combined error of curvature, refraction and collimation (in the far-staff reading)"],
        ] },
        { k: "list", items: [
          "Correction for curvature and refraction = −0.0673 d²",
          "<b>Collimation error = e − 0.0673 d²</b> (p.97)",
        ] },
        { k: "eg",
          title: "Notes example — reciprocal levelling across a river (630.5 m)",
          given: "Reciprocal levelling between two points A and B 630.5 m apart on opposite sides of a river gave the following results. Instrument at A: staff reading on A 1.360 (a₁), staff on B 1.585 (b₁). Instrument at B: staff reading on B 1.335 (b₂), staff on A 0.890 (a₂). Determine the difference in elevation between A and B and the amount of collimation error.",
          steps: [
            { t: "Difference in elevation", w: "Δh_AB = ((b₁ − a₁) + (b₂ − a₂))/2\n= ((1.585 − 1.360) + (1.335 − 0.890))/2\nΔh_AB = 0.335" },
            { t: "Combined error e", w: "e = ((b₁ − a₁) − (b₂ − a₂))/2\n= ((1.585 − 1.360) − (1.335 − 0.890))/2\ne = −0.11" },
            { t: "Collimation error", w: "Collimation error = e − 0.0673 d²\n= −0.11 − 0.0673 (0.6305)²\n= −0.137" },
            { t: "Collimation error as an angle (sketch: right triangle, long side 630.5, short vertical side 0.137, angle θ at the left vertex)", w: "tan θ = 0.137/630.5 = 44″" },
          ],
          ans: "Δh_AB = 0.335 m; e = −0.11; collimation error = −0.137 m, i.e. θ = 44″ (p.97)",
        },
        { k: "note", t: "<b>Check:</b> 0.0673 × 0.6305² = 0.0268, so collimation error = −0.11 − 0.0268 = −0.1368 ≈ <b>−0.137 m</b> ✓. The angle: 0.137/630.5 = 0.0002173 rad × 206265 = <b>44.8″ ≈ 45″</b> (44.7″ using −0.1368). The notes' 44″ is the value cut off, not rounded." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "River ke beech instrument nahi rakh sakte, to BS–FS barabar nahi ho paate. Trick: ek baar A ke paas se padho (B wali reading me error e), ek baar B ke paas se (A wali reading me wahi error e). Dono baar error 'door wali' staff par hai aur distance same hai, isliye average lene par e cancel ho jaata hai — curvature, refraction aur collimation teeno ek saath. Difference lene par e mil jaata hai; usme se curvature-refraction (0.0673d²) hata do to sirf collimation bachta hai." },
        { k: "p", t: "Sign samjho: notes me Δh<sub>AB</sub> = b − a liya hai, yaani positive answer ka matlab <b>A, B se upar</b> hai (B ki staff reading zyada). Yahan 0.335 m positive → B, A se 0.335 m neeche. e negative aaya, matlab door ki reading kam padhi gayi — line of sight neeche jhuki hai." },
        { k: "trap", t: "a aur b ko instrument ke hisaab se mat lagao, <b>staff point</b> ke hisaab se lagao: a hamesha A par reading, b hamesha B par — chahe instrument kahin bhi ho. Is example me second set-up ki table me pehle B (1.335) aur phir A (0.890) likha hai; b₂ = 1.335, a₂ = 0.890. Ulta lene par Δh aur e dono galat aayenge." },
        { k: "real", t: "Pul (bridge) ya canal crossing par dono kinaaron ke RL isi se jode jaate hain. Dono set-up jaldi-jaldi karo (ya do instruments se ek saath), kyunki refraction din bhar badalta hai aur sirf constant error hi cancel hota hai — section 6.5 me yahi baat example ke saath hai." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — Levelling (p.85–97)",
      hi: "नोट्स पुनरावृत्ति — लेवलिंग",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and definitions" },
        { k: "list", items: [
          "✅ HOI = RL + BS; RL = HOI − (IS or FS). (p.85–86)",
          "✅ Peg setting: fall per peg = (1/gradient) × interval = (1/100) × 20 = 0.2 m; required staff reading = HOI − required RL (P₁ 1.116 … P₅ 1.916 from HOI 61.116). (p.86)",
          "✅ Rise/fall = previous reading − current reading; last reading always FS. (p.87–88)",
          "✅ Check: ΣBS − ΣFS = ΣRise − ΣFall = last RL − first RL (= −1.09 in the old level book). (p.89)",
          "✅ Collimation error in a reading = α″ × D / 206265; elevated error → correction negative to every BS and FS; first RL unchanged; corrected last RL 123.11 (123.118). (p.89)",
          "✅ Dumpy level: telescope and spindle cast as one piece; bubble tube axis ⊥ vertical axis. Tilting level: line of sight need not be ⊥ vertical axis. (p.90)",
          "✅ Permanent adjustments: bubble tube axis ⊥ vertical axis; line of sight ∥ bubble tube axis; horizontal cross hair ⊥ vertical axis. (p.90)",
          "✅ Two-peg test (makes line of sight ∥ bubble tube axis): instrument midway gives true Δh = a₁ − b₁; e = [(a₂ − b₂) − (a₁ − b₁)] / (D₁ + D₂). (p.90–91)",
          "✅ Two-peg example: AB = BC = CD = 30 m → e = (0.500 − 0.464)/60 = 0.0006 rad. (p.92)",
          "✅ Curvature: error positive, correction Cc = −0.0785 d² (m, d in km). (p.92–93)",
          "✅ Refraction: error negative, correction C_R = +(1/7)·0.0785 d² = +0.0112 d². (p.93)",
          "✅ Combined: C = −0.0673 d². (p.93)",
          "✅ Distance visible: h = 0.0673 d², d = 3.854 √h (d km, h m); ship–lighthouse (8 m, 40 m) d = 3.854√8 + 3.854√40 = 35.27 km (35.276). (p.94)",
          "✅ Reciprocal levelling: for points far apart (river, valley); eliminates curvature, refraction and collimation corrections. (p.95)",
          "✅ Δh<sub>AB</sub> = [(b₁ − a₁) + (b₂ − a₂)] / 2; e = [(b₁ − a₁) − (b₂ − a₂)] / 2 = combined error. (p.96)",
          "✅ Collimation error = e − 0.0673 d². (p.97)",
          "✅ Reciprocal example (630.5 m): Δh = 0.335 m, e = −0.11, collimation error = −0.137 m, θ = 44″ (44.8″). (p.97)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
