/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for the Hydrology handbook,
   Chapter 8 (Hydrographs & Unit Hydrograph Theory).
   ------------------------------------------------------------
   Same conventions as the other dia-hb-* files: strokes are
   currentColor so both themes work, meaning-carrying strokes use
   .hi (marker) or .ac (accent), and the figure's marker ids are
   prefixed so they never collide with another figure on the page.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function hyMk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 8.2 ANATOMY OF A HYDROGRAPH */
  "hb-hydro-anatomy": {
    label: "The labelled parts of a flood hydrograph",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="A flood hydrograph: a rainfall hyetograph bar at top, below it the discharge curve rising from point A as a concave rising limb through inflection point B, continuing convex to the peak C, across the flat crest segment to D, falling as a convex then concave recession limb through inflection point D to point E on the baseflow line. Base flow is a dashed horizontal line under the whole curve. Brackets along the time axis mark time to peak, time of recession and the total base period, and the shaded area between the curve and the baseflow line is labelled the direct runoff volume.">
      ${hyMk("hy")}

      <!-- hyetograph (rainfall) -->
      <text class="lb" x="90" y="20">i (cm/hr)</text>
      <rect class="conc" x="78" y="30" width="16" height="26"/>
      <rect class="conc" x="96" y="20" width="16" height="36"/>
      <rect class="conc" x="114" y="34" width="16" height="22"/>
      <line class="thin" x1="60" y1="56" x2="300" y2="56"/>
      <text class="lb" x="200" y="46" text-anchor="middle">effective rainfall (duration D)</text>

      <!-- axes -->
      <line class="s" x1="60" y1="66" x2="60" y2="268"/>
      <text class="lb" x="30" y="70" text-anchor="middle">Q↑</text>
      <line class="s" x1="60" y1="268" x2="650" y2="268"/>
      <line class="ac" x1="630" y1="268" x2="652" y2="268" marker-end="url(#hy-c)"/>
      <text class="lb" x="650" y="286" text-anchor="end">Time (hr) →</text>

      <!-- baseflow -->
      <line class="thin dash" x1="60" y1="238" x2="610" y2="238"/>
      <text class="lb" x="500" y="232">Base flow</text>

      <!-- shaded DRH area -->
      <path class="softa" d="M90 238 C 150 150, 190 90, 270 76 L 340 80 C 400 92, 460 150, 520 238 Z"/>

      <!-- the curve itself, split so colour can mark rising vs falling -->
      <path class="hi" d="M90 238 C 150 150, 190 90, 270 76"/>
      <path class="s" d="M270 76 L 340 80"/>
      <path class="ac" d="M340 80 C 400 92, 460 150, 520 238"/>

      <!-- points -->
      <circle class="acf" cx="90" cy="238" r="4"/>
      <text class="ea" x="90" y="258" text-anchor="middle">A</text>
      <circle class="acf" cx="178" cy="124" r="4"/>
      <text class="ea" x="150" y="118" text-anchor="middle">B</text>
      <circle class="acf" cx="270" cy="76" r="4"/>
      <text class="em" x="270" y="60" text-anchor="middle">C — peak</text>
      <circle class="acf" cx="430" cy="128" r="4"/>
      <text class="ea" x="458" y="122">D</text>
      <circle class="acf" cx="520" cy="238" r="4"/>
      <text class="ea" x="520" y="258" text-anchor="middle">E</text>

      <text class="lb" x="150" y="190" text-anchor="middle">rising limb</text>
      <text class="lb" x="150" y="204" text-anchor="middle">(concentration curve)</text>
      <text class="lb" x="305" y="98" text-anchor="middle">crest segment</text>
      <text class="lb" x="455" y="190" text-anchor="middle">falling limb</text>
      <text class="lb" x="455" y="204" text-anchor="middle">(recession curve)</text>
      <text class="em" x="300" y="170" text-anchor="middle">direct runoff volume</text>
      <text class="lb" x="178" y="104" text-anchor="middle">pt. of inflection</text>
      <text class="lb" x="458" y="108">pt. of inflection</text>

      <!-- time brackets -->
      <line class="thin" x1="90" y1="300" x2="270" y2="300" marker-start="url(#hy-a)" marker-end="url(#hy-a)"/>
      <text class="lb" x="180" y="296" text-anchor="middle">t&#8321;=t&#8343;&#8337;</text>
      <line class="thin" x1="270" y1="300" x2="520" y2="300" marker-start="url(#hy-a)" marker-end="url(#hy-a)"/>
      <text class="lb" x="395" y="296" text-anchor="middle">t&#8322;=t&#8347;</text>
      <line class="thin" x1="90" y1="322" x2="520" y2="322" marker-start="url(#hy-a)" marker-end="url(#hy-a)"/>
      <text class="lb" x="305" y="318" text-anchor="middle">t&#8328;&#8337; — base period</text>
    </svg>`,
    caption: "A, B, C, D, E are the five landmarks every hydrograph question is built on. <strong>A→B→C is the rising limb</strong> (concave then convex, controlled by catchment slope and losses), <strong>C is the peak</strong> (crest segment — the biggest contribution of all tributaries), and <strong>C→D→E is the falling/recession limb</strong> (controlled by the catchment's storage). The shaded area above the dashed base-flow line is the direct-runoff volume used to find Area of DRH and hence R.",
  },

});
