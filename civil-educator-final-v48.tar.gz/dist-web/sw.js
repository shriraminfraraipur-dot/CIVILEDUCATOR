/* Civil Educator — service worker (offline shell cache) */
const CACHE = "ccl-v96";
const ASSETS = ["./", "index.html", "data-codes.js", "data-codes-2.js", "data-topics.js", "data-topics2.js", "data-topics3.js", "data-exam.js", "data-exam2.js", "data-exam3.js", "data-exam4.js", "data-exam5.js", "diagrams.js", "diagrams2.js", "diagrams3.js", "diagrams4.js", "data-extra.js", "data-extra2.js", "data-clauses.js", "data-clauses2.js", "data-guides.js", "data-guides2.js", "data-guides3.js", "data-guides4.js", "data-hindi.js", "data-matcats.js", "data-materials.js", "data-materials2.js", "dia-hb-sa1.js", "dia-hb-sa2.js", "data-hb-sa.js", "dia-hb-sa3.js", "data-hb-sa2.js", "dia-hb-sa4.js", "data-hb-sa3.js", "dia-hb-sa5.js", "data-hb-sa4.js", "dia-hb-sa6.js", "data-hb-sa5.js", "data-hb-sa6.js", "dia-hb-rcc1.js", "data-hb-rcc.js", "dia-hb-rcc2.js", "data-hb-rcc2.js", "dia-hb-rcc3.js", "data-hb-rcc3.js", "dia-hb-rcc4.js", "data-hb-rcc4.js", "dia-hb-rcc5.js", "data-hb-rcc5.js", "dia-hb-rcc6.js", "data-hb-rcc6.js", "dia-hb-st1.js", "data-hb-st.js", "dia-hb-st2.js", "data-hb-st2.js", "dia-hb-st3.js", "data-hb-st3.js", "dia-hb-st4.js", "data-hb-st4.js", "dia-hb-st5.js", "data-hb-st5.js", "dia-hb-st6.js", "data-hb-st6.js", "dia-anim1.js", "dia-anim2.js", "data-hb-upgrade.js", "dia-hb-sv1.js", "dia-hb-sv2.js", "dia-hb-sv3.js", "data-hb-sv.js", "data-hb-sv2.js", "data-hb-sv3.js", "data-hb-sv4.js", "data-hb-sv5.js", "data-hb-sv6.js", "data-hb-svn-01.js", "data-hb-svn-02.js", "data-hb-svn-03.js", "data-hb-svn-04.js", "data-hb-svn-05.js", "data-hb-svn-06.js", "data-hb-svn-07.js", "data-hb-svn-08.js", "data-hb-svn-09.js", "data-hb-svn-10.js", "data-hb-svn-11.js", "data-hb-svn-12.js", "data-hb-svn-13.js", "data-hb-svn-14.js", "data-hb-svn-15.js", "data-hb-svn-16.js", "dia-hb-ge1.js", "dia-hb-ge2.js", "dia-hb-ge3.js", "data-hb-ge.js", "data-hb-ge2.js", "data-hb-ge3.js", "data-hb-ge4.js", "data-hb-ge5.js", "data-hb-ge6.js", "dia-hb-bm1.js", "data-hb-bm.js", "data-hb-bm2.js", "data-hb-bm3.js", "dia-hb-bmn1.js", "data-hb-bmn.js", "data-hb-bmn2.js", "dia-hb-stn1.js", "data-hb-stn.js", "data-hb-stn2.js", "data-hb-stn3.js", "data-hb-stn4.js",
  "dia-hb-som-ch1.js", "dia-hb-som-ch2.js", "dia-hb-som-ch3.js", "dia-hb-som-ch4.js", "dia-hb-som-ch5.js", "dia-hb-som-ch6.js", "dia-hb-som-ch7.js", "dia-hb-som-ch8.js", "data-hb-som.js", "data-hb-som2.js", "data-hb-som3.js", "data-hb-somn-01.js", "data-hb-somn-02.js", "data-hb-somn-03.js", "data-hb-somn-04.js", "data-hb-somn-05.js", "data-hb-somn-06.js", "data-hb-somn-07.js", "data-hb-somn-08.js", "data-hb-somn-09.js", "data-hb-somn-10.js", "data-hb-somn-11.js", "data-hb-somn-12.js", "data-hb-somn-13.js", "data-hb-somn-14.js", "data-hb-somn-15.js", "data-hb-somn-16.js", "data-hb-somn-17.js", "data-hb-somn-18.js", "data-hb-bridge.js", "data-hb-tunnel.js", "data-hb-tunnel2.js", "data-hb-tunnel3.js",
  "data-hb-san.js", "data-hb-san2.js", "data-hb-san3.js", "data-hb-san4.js", "data-hb-san5.js", "data-hb-san6.js", "data-hb-san7.js", "data-hb-san8.js", "data-hb-san9.js",
  "data-hb-fm.js", "data-hb-fm2.js", "data-hb-fm3.js", "data-hb-fm4.js", "data-hb-fm5.js", "data-hb-fm6.js",
  "data-hb-irr.js", "data-hb-irr2.js", "data-hb-irr3.js", "data-hb-irr4.js", "data-hb-irr5.js", "data-hb-irr6.js", "data-hb-irr7.js",
  "data-hb-hydro.js", "dia-hb-hydro-ch1.js", "data-hb-hydro-ch1.js", "dia-hb-hydro-ch2.js", "data-hb-hydro-ch2.js", "dia-hb-hydro-ch3.js", "data-hb-hydro-ch3.js", "dia-hb-hydro-ch4.js", "data-hb-hydro-ch4.js", "dia-hb-hydro-ch5.js", "data-hb-hydro-ch5.js", "dia-hb-hydro-ch6.js", "data-hb-hydro-ch6.js", "dia-hb-hydro-ch7.js", "data-hb-hydro-ch7.js", "dia-hb-hydro-ch8.js", "data-hb-hydro-ch8.js", "dia-hb-hydro-ch9.js", "data-hb-hydro-ch9.js", "data-hb-hydro-ch10.js", "data-hb-hydro-ch11.js",
  "data-courses.js", "data-hb-merge.js", "dia-hb-st1.js", "data-hb-st.js", "data-handbook-sa.js", "data-handbook-sa-hi.js", "data-subjects.js", "calc-meta.js", "calc.js", "auth.js", "app.js", "manifest.webmanifest"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS.map((a) => new Request(a, { cache: "reload" })))).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))));
  self.clients.claim();
});

/* Network first for the app shell so updates arrive; cache fallback keeps it usable offline. */
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET" || new URL(req.url).origin !== location.origin) return;
  e.respondWith(
    fetch(req)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy)).catch(() => {});
        return res;
      })
      .catch(() => caches.match(req).then((m) => m || caches.match("index.html")))
  );
});
