/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING SERVICES & SAFETY · Ch 3–5
   Drainage & sanitation · Water & wastewater treatment · Egress
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bs");
  if (!hb) { console.error("[bs2] handbook bs not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "bs-3",
      n: 3,
      title: "Building Drainage and Sanitation",
      hi: "भवन जल निकासी और स्वच्छता",
      blurb: "The trap and its water seal, why every drain needs a vent, and how the pipes of a building are arranged to carry foul water out without letting foul air in.",
      mins: 22,
      sections: [
        {
          n: "3.1",
          title: "The trap — a cupful of water doing a vital job",
          hi: "ट्रैप — पानी की सील",
          blocks: [
            { k: "p", t: "Drainage is not just about carrying foul water away — it is equally about stopping foul air coming back. The device that does the second job is the trap, and it is on every fixture in the building." },
            { k: "dia", id: "hb-bs-trap", cap: "The trap's water seal and the vent that protects it." },
            { k: "def", term: "Trap", t: "A U-bend below a fixture that holds a small plug of water — the water seal. That plug seals the pipe, so foul and sometimes explosive sewer gas cannot rise back through the drain into the room. A P-trap, S-trap or bottle trap all do the same thing: hold water across the pipe." },
            { k: "def", term: "Water seal", t: "The depth of the water plug held in the trap (typically 50 mm). A deeper seal is harder to break; too shallow and it evaporates or siphons away easily. A trap that has lost its seal — dried out or siphoned — is simply an open pipe to the sewer, with nothing between the room and the drains." },
            { k: "trap", t: "A floor trap in a rarely-used bathroom is the classic failure: the water seal slowly evaporates over weeks of disuse, and one day the room smells of drains for no obvious reason. The cure is simply to run water into it occasionally to refill the seal. It is a reminder that the seal is water, and water leaves — by evaporation or by siphoning — unless the design protects it." },
          ],
        },
        {
          n: "3.2",
          title: "Venting — why the seal needs air",
          hi: "वेंटिंग",
          blocks: [
            { k: "p", t: "A trap's water seal can be broken not only by drying but by the flow of water itself, and this is where venting comes in. When a rush of water falls down a soil stack, it can create suction (or pressure) that pulls the water seal right out of a connected trap — self-siphonage. The vent pipe is the fix." },
            { k: "def", term: "Vent pipe", t: "A pipe open to the atmosphere that lets air into the drainage system behind the flowing water, so that the pressure stays balanced and the water seals are not siphoned out. Every drainage design is a system of soil pipes, waste pipes and vent pipes working together — the vents are as essential as the drains." },
            { k: "cmp", t: "The pipes of a drainage system",
              cols: ["Carries"],
              rows: [
                ["Soil pipe", "discharge from WCs (with solids)"],
                ["Waste pipe", "discharge from basins, sinks, baths"],
                ["Vent pipe", "air only — protects the water seals"],
                ["Anti-siphonage pipe", "air to the traps specifically, against siphonage"],
              ] },
            { k: "real", t: "In a multi-storey building the soil stack runs the full height and is carried up above the roof, open to the sky — that upstand you see poking above a building's roofline is the vent, letting sewer gas escape harmlessly high up and letting air in to protect every trap below. <strong>A drainage system without adequate venting gurgles, smells and loses its seals</strong> — the vents are why a well-designed system does none of those things." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "bs-4",
      n: 4,
      title: "Water and Wastewater Treatment",
      hi: "जल एवं अपशिष्ट उपचार",
      blurb: "The treatment train that makes water safe, in outline — coarse to fine to invisible — and the same logic run to clean wastewater before it is returned.",
      mins: 18,
      sections: [
        {
          n: "4.1",
          title: "Making water safe — a train of steps",
          hi: "जल को सुरक्षित बनाना",
          blocks: [
            { k: "p", t: "Treating raw water for supply is a sequence of steps, each removing what the previous one could not, arranged deliberately from coarse to fine to invisible. You take out the bulk cheaply first so every later, more precise step has less to do." },
            { k: "dia", id: "hb-bs-treatment", cap: "The treatment train, coarse to fine to invisible." },
            { k: "list", items: [
              "<strong>Screening</strong> — bars and screens catch leaves, rags and large debris. Physical and cheap.",
              "<strong>Sedimentation</strong> — the water is slowed so suspended solids settle out under gravity (aided by coagulants that clump fine particles together).",
              "<strong>Filtration</strong> — the water passes through sand beds that trap the fine particles the settling missed.",
              "<strong>Disinfection</strong> — chlorine (or UV, ozone) kills the pathogens too small to filter. The last step, and the one that makes it truly safe to drink.",
            ] },
            { k: "note", t: "The order is the lesson: physical and cheap first (screening, settling), chemical and precise last (disinfection). Settling out the bulk of the solids early makes the filters last longer and the disinfectant work better on clearer water. Doing it out of order — trying to disinfect muddy water — wastes chemicals and fails, because solids shield the pathogens." },
          ],
        },
        {
          n: "4.2",
          title: "Wastewater — the same logic, before release",
          hi: "अपशिष्ट जल",
          blocks: [
            { k: "p", t: "Wastewater (sewage) is treated before it is returned to a river or reused, and it follows a similar coarse-to-fine logic, with a biological step added to consume the dissolved organic matter that physical steps cannot remove." },
            { k: "cmp", t: "The stages of sewage treatment",
              cols: ["Removes"],
              rows: [
                ["Primary (physical)", "settleable & floating solids — screens, grit, settling"],
                ["Secondary (biological)", "dissolved organic matter — microbes consume it"],
                ["Tertiary (polishing)", "nutrients, fine solids, pathogens before release"],
                ["Disinfection", "remaining pathogens, before the water is discharged"],
              ] },
            { k: "real", t: "The biological (secondary) stage is the heart of sewage treatment and has no equivalent in water supply: colonies of microbes are deliberately grown and fed the sewage, and they eat the dissolved organic pollution, turning it into settleable sludge. It is treatment by cultivated life, not by machinery. <strong>The deep theory of these biological processes is environmental engineering's own large subject</strong> — this handbook gives the services-level overview a building engineer needs, not the process design a treatment-plant engineer needs." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "bs-5",
      n: 5,
      title: "Means of Egress",
      hi: "निकास मार्ग",
      blurb: "The first line of fire safety — getting everyone out — through travel distance, two remote exits, and exits sized for the crowd.",
      mins: 20,
      sections: [
        {
          n: "5.1",
          title: "Getting people out comes first",
          hi: "पहले लोगों को निकालना",
          blocks: [
            { k: "p", t: "Fire safety begins not with fighting the fire but with getting people away from it. The 'means of egress' — the continuous, protected path from any point in the building to a safe place outside — is the first and most important line of defence, and the plan is judged by how quickly it can empty the building." },
            { k: "dia", id: "hb-bs-egress", cap: "Travel distance, two exits, and exits sized for the occupant load." },
            { k: "def", term: "Means of egress", t: "The continuous and unobstructed path of travel from any occupied point to the exit discharge (a safe place outside). It has three parts: the exit access (the route to the exit), the exit itself (the protected stair or door), and the exit discharge (from the exit to the street)." },
            { k: "def", term: "Occupant load", t: "The number of people a space is assumed to hold, found by dividing the floor area by an occupant-load factor set by the NBC for each use (denser for assembly halls, sparser for offices). It is the crowd the exits must be sized for — and it is often far more than the number normally present, because the design covers the busy day." },
          ],
        },
        {
          n: "5.2",
          title: "The three rules that size an escape",
          hi: "बचाव के तीन नियम",
          blocks: [
            { k: "p", t: "Three rules, all set by the NBC, turn 'get people out' into dimensions on a drawing." },
            { k: "list", items: [
              "<strong>Travel distance</strong> — no point may be further than a set distance from an exit (shorter for hazardous or sleeping occupancies), so no one is ever far from a way out.",
              "<strong>Two exits, remote from each other</strong> — so that a fire blocking one route still leaves another. A single exit is a death trap the moment it is blocked.",
              "<strong>Exit width for the occupant load</strong> — the exits and stairs must be wide enough for the whole occupant load to pass in time, sized in 'units' of width per so many persons.",
            ] },
            { k: "trap", t: "The commonest and deadliest failure is not a design error but an operational one: exits locked, blocked or obstructed. A perfectly designed second exit chained shut 'for security', a fire stair used for storage, a corridor narrowed by parked equipment — every fire tragedy's inquiry finds these. The design provides the escape; keeping it clear and unlocked is a duty that never ends. <strong>An exit that is locked is not an exit.</strong>" },
            { k: "real", t: "This is why fire doors must open in the direction of escape and with a single push (panic hardware), why exit signs are lit even in a power cut, and why fire stairs are pressurised to keep smoke out. Each detail assumes a panicking crowd in poor visibility and removes one more thing that could go wrong. <strong>The whole of egress design imagines the worst moment and engineers it to still work.</strong>" },
          ],
        },
      ],
    },

  );
})();
