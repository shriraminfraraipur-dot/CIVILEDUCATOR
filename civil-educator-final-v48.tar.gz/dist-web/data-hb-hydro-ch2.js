/* ============================================================
   HYDROLOGY — COMPLETE NOTES · Chapter 2
   Precipitation — Forms, Measurement & Rain Gauge Networks
   Consolidated from three source transcripts (S1, S2, V); every
   fact is page-cited back to its source(s).
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-2",
    n: 2,
    title: "Precipitation — Forms, Measurement & Rain Gauge Networks",
    hi: "वर्षण — प्रकार, मापन एवं वर्षामापी नेटवर्क",
    blurb: "Precipitation ke saare forms (rain, snow, drizzle, glaze, sleet, hail) aur unke causes (convective, orographic, cyclonic), Indian monsoon ke seasons aur rainfall stats, Symon's non-recording gauge se recording gauges (tipping/weighing/syphon/telemetering/radar) tak, aur optimum rain-gauge network density ka N/Cv/standard-error formula — teen transcripts (S1, S2, V) se consolidate kiya gaya, har fact page-cited.",
    mins: 34,
    sections: [

      /* ============================================================ 2.1 */
      {
        n: "2.1",
        title: "Precipitation — definition and forms",
        hi: "वर्षण — परिभाषा और प्रकार",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.11–12; S2 p.3; V p.5–6" },
          { k: "def", term: "Precipitation", t: "All forms of water that reach the earth's surface from the atmosphere. (S2 p.3; V p.5)" },
          { k: "p", t: "Six forms are described across the sources: <b>Rain, Snow, Drizzle, Glaze, Sleet</b> and <b>Hail</b>. (S1 p.11–12; S2 p.3; V p.5–6)" },
          { k: "note", t: "S1's own listing names only five forms (Rain, Snow, Sleet, Glaze, Hail) and does not call out Drizzle separately — S2 and V both treat it as a distinct sixth form (fine droplets below the 'light rain' threshold). All six are kept here. (S1 p.11; S2 p.3; V p.5)" },
          { k: "def", term: "Rain", t: "The predominant form of precipitation in India — in Indian usage 'rainfall' is often used synonymously with precipitation. Water-droplet size ranges 0.5–6 mm. (S1 p.11; S2 p.3; V p.5)" },
          { k: "cmp", t: "Classification of rain by intensity (S1 p.11; S2 p.3; V p.5)", cols: ["Intensity"], rows: [
            ["Light rain", "trace (0) – 2.5 mm/hr"],
            ["Moderate rain", "2.5 – 7.5 mm/hr"],
            ["Heavy rain", "&gt; 7.5 mm/hr"],
          ] },
          { k: "def", term: "Rainy day", t: "A day on which the total rainfall exceeds 2.5 mm, by the standard IMD convention of reading the gauge once every day at 08:30 (8:30 AM). (S1 p.11; S2 p.3)" },
          { k: "def", term: "Snow", t: "Ice crystals, usually combining into flakes, with an average density of about 0.1 g/cc (roughly 1/10th of water's density). In India, snow occurs mainly in the Himalayan region; its accumulation may build up into a glacier. (S1 p.11; S2 p.3; V p.5)" },
          { k: "def", term: "Drizzle", t: "Very fine water droplets, size &lt;0.5 mm, falling at an intensity &lt;1 mm/hr — the drops float/drift in the air like a fine sprinkler rather than falling as distinct drops. (S2 p.3; V p.5)" },
          { k: "def", term: "Glaze", t: "Rain or drizzle that freezes on contact with the ground or any solid body at/near 0°C, forming an ice coating — also called freezing rain. (S1 p.12; S2 p.3; V p.5)" },
          { k: "def", term: "Sleet", t: "A frozen raindrop — rain that turns to ice while still falling, before it reaches the ground; effectively a mixture of rain and snow. (S1 p.11; S2 p.3; V p.5)" },
          { k: "def", term: "Hail", t: "Showery precipitation in the form of irregular ice pellets or lumps larger than 8 mm, produced by a violent thunderstorm with very strong vertical air currents. (S1 p.12; S2 p.4; V p.6)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Saare 'ice wale' forms (sleet, glaze, hail) ek hi baat lagte hain par banne ka tareeka alag hai. <b>Sleet</b> mein raindrop <b>hawa mein girte-girte</b> hi freeze ho jaata hai (ground tak pahunchne se pehle). <b>Glaze</b> mein drop liquid hi rehta hai jab tak woh <b>0°C ki cold ground/surface se touch</b> nahi karta — touch karte hi coating ban jaati hai (isiliye 'freezing rain' bhi kehte hain). <b>Hail</b> alag mechanism hai — thunderstorm ke strong updrafts mein ice crystal baar-baar upar-neeche cycle karke layers jama karta hai jab tak woh bahut bada (&gt;8mm) na ho jaaye aur gir na jaaye." },
          { k: "trap", t: "Snow aur Hail ko size se confuse mat karo — Snow flakes bahut halke (0.1 g/cc density) hote hain, jabki Hail solid ice lumps hote hain (&gt;8mm) jo thunderstorm ki wajah se bante hain, barf ke mausam se nahi. Isi tarah Drizzle ko 'light rain' se mix mat karo — droplet size (&lt;0.5mm vs 0.5–6mm) hi dono ko alag karta hai, sirf intensity nahi." },
        ],
      },

      /* ============================================================ 2.2 */
      {
        n: "2.2",
        title: "Causes of precipitation — convective, orographic and cyclonic",
        hi: "वर्षण के कारण — संवाहक, पर्वतीय एवं चक्रवाती",
        blocks: [
          { k: "h", t: "📘 Notes — V p.6" },
          { k: "def", term: "Front", t: "The interface between two distinct air masses. When a warmer air mass meets a colder one, the warmer mass is lifted over the colder mass, forming the front; the warm air then cools adiabatically, forming clouds and resulting in precipitation. (V p.6)" },
          { k: "list", items: [
            "<b>Convective precipitation</b> — a pocket of air warmer than its surroundings, being less dense, rises up; it undergoes cooling and gives precipitation. (V p.6)",
            "<b>Orographic precipitation</b> — a moist air mass is forced to rise to higher altitude by a mountain barrier, and consequently undergoes cooling, condensation and precipitation. Windward slopes get heavy rainfall; leeward slopes get only light rainfall (the rain-shadow effect). (V p.6)",
            "<b>Cyclone</b> — a large low-pressure region with circular wind motion; it is one of the main mechanisms of cyclonic precipitation. (V p.6)",
            "<b>Anticyclone</b> — a high-pressure region of usually large areal extent, with clockwise wind circulation in the northern hemisphere; precipitation, where it occurs at all, is confined to its edges. (V p.6)",
          ] },
          { k: "def", term: "Tropical cyclone", t: "Areal extent generally 100–200 km diameter; isobars closely spaced; winds anticlockwise in the northern hemisphere. The storm's centre is called the <b>eye</b>, about 10–50 km in diameter; strong winds occur outside the eye, decreasing in speed further out. Pressure at the storm centre is very low, resulting in heavy rainfall over the entire area. Tropical cyclones cause heavy damage to life and property — intense rainfall and large floods are their typical consequence. (V p.6)" },
          { k: "def", term: "Extratropical cyclone", t: "A cyclone formed outside the tropical zone; also has anticlockwise wind circulation in the northern hemisphere, but precipitation intensity and wind velocity are lower than for a tropical cyclone, while the duration and areal extent of the precipitation are longer. Associated with a frontal system. (V p.6)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno mechanism ek hi physics use karte hain — <b>moist air ko force karke upar uthao, woh cool hoga, condense hoga, barsega.</b> Farak sirf 'kaun upar uthata hai' mein hai: Convective mein air <b>khud</b> apni kam density ki wajah se upar jaati hai (local heating se), Orographic mein <b>mountain barrier</b> force karta hai upar jaane ke liye, aur Cyclonic/Frontal mein <b>doosri air mass</b> (cold front) usko upar push karti hai. Isiliye orographic rain hamesha windward side par zyada hoti hai — leeward side tak pahunchte-pahunchte air apna zyada moisture already gira chuki hoti hai." },
          { k: "real", t: "Site application: hill-station projects mein windward slope par drainage design heavier rainfall intensity ke liye karna padta hai jabki leeward side par comparatively kam — yeh seedha orographic effect ka result hai, Western Ghats jaisi jagah par clearly dikhta hai." },
        ],
      },

      /* ============================================================ 2.3 */
      {
        n: "2.3",
        title: "Indian monsoon seasons and rainfall statistics",
        hi: "भारतीय मानसून के मौसम एवं वर्षा के आँकड़े",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.11; S2 p.3; V p.7" },
          { k: "p", t: "Precipitation in India has two major seasons and two transition periods: (1) South-West monsoon / summer monsoon (June–September); (2) Transition-I, post-monsoon (October–November); (3) Winter season (December–February); (4) Transition-II, summer (March–May). (V p.7)" },
          { k: "list", items: [
            "The South-West monsoon is India's principal rainy season — about 75% of the annual rainfall occurs in it, and July is the rainiest month. (V p.7)",
            "The monsoon originates in the Indian Ocean and first appears over Kerala towards the end of May; it then proceeds across the country in two branches — the Arabian Sea branch and the Bay of Bengal branch — which meet over Delhi at roughly the same time. (V p.7)",
            "Average monsoon rainfall is 87.7 cm. (V p.7)",
            "S2 separately marks the monsoon's active window as 15 June to 15 September. (S2 p.3)",
          ] },
          { k: "note", t: "<b>Different figures for the same quantity:</b> S2 gives India's average annual precipitation as about 120 cm/year (against a world average of about 100 cm/year); V instead gives 119.4 cm/year (alongside an average annual runoff of 55 cm). The two values are close enough to plausibly be the same long-period average rounded differently, but since the sources state different numbers, both are kept here rather than silently choosing one. (S2 p.3; V p.7)" },
          { k: "eq", expr: "Coefficient of variation of annual rainfall  Cv = (σ/P̄) × 100  — varies between 15% and 70% across India, with an average value of about 30%", where: [
            ["σ", "standard deviation of the place's annual rainfall record"],
            ["P̄", "mean annual rainfall of the place"],
          ] },
          { k: "p", t: "More than 50% of a year's rainfall occurs within just 15 days, and in less than 100 hours total — Indian rainfall is highly concentrated in time, not spread evenly through the year. (V p.7)" },
          { k: "p", t: "To find the average annual precipitation of a place, a minimum of 30 years of data is required; the average of those 30 years' data is what is called the place's average annual precipitation. The hydrological 'water year' used for this is 1st June to 31st May, not the calendar year — it is aligned to the monsoon cycle. (S2 p.3)" },
          { k: "eq", expr: "Example — average annual ppt of Delhi, 2020:  P̄₂₀₂₀ = (P₁₉₉₁ + P₁₉₉₂ + ⋯ + P₂₀₂₀) / 30", where: [] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Water year 1 June–31 May isliye liya jaata hai kyunki calendar year (1 Jan–31 Dec) monsoon ke beech mein kaat deta — SW monsoon June mein shuru hota hai aur agle saal ke withdrawal tak ek continuous hydrological event hai, usko January se December mein todna statistically awkward hoga. Isi tarah '75% rainfall sirf SW monsoon mein' aur 'Cv = 15–70%' dono batate hain ki India ka rainfall temporally bahut <b>unreliable/concentrated</b> hai — isi wajah se rain-gauge network aur storage planning dono critical ho jaate hain." },
        ],
      },

      /* ============================================================ 2.4 */
      {
        n: "2.4",
        title: "Non-recording rain gauges — Symon's gauge",
        hi: "अ-अभिलेखी वर्षामापी — साइमन गेज",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.12–13; S2 p.7–9; V p.7–8" },
          { k: "def", term: "Non-recording gauge", t: "Gives only the total depth of rainfall collected over the observation period (normally one day) — it records magnitude only, not how that rainfall was distributed over time (its intensity). (S2 p.9)" },
          { k: "def", term: "Symon's gauge", t: "The standard non-recording gauge, extensively/most widely used in India. S1 attributes its development to 'Mr. Syphon' — almost certainly a transcription mix-up with the siphon mechanism used in a different, <i>recording</i> type of gauge (see the trap below) rather than the actual inventor's name. (S1 p.12)" },
          { k: "p", t: "Dimensions are consistent across all three sources: the funnel/collecting-area diameter is <b>12.7 cm (127 mm)</b> — giving a collecting surface area of about 127 cm², matching the 100–200 cm² range S1 gives — with the funnel rim standing <b>30.5 cm</b> above ground level. (S1 p.12–13; S2 p.7–8; V p.7–8)" },
          { k: "list", items: [
            "Rain collected by the funnel is channelled into a <b>receiving bottle</b> inside the metal casing. (S1 p.12–13; V p.8)",
            "Water from the bottle is poured into a separate <b>graduated measuring jar</b> and read off directly, to an accuracy of up to 0.1 mm. (V p.8)",
            "The whole assembly stands on a <b>600 mm × 600 mm × 600 mm concrete block</b>. (S1 p.13)",
          ] },
          { k: "dia", id: "hb-hydro-symons", cap: "Symon's non-recording rain gauge — the funnel, the receiving bottle inside the casing, and the separate graduated jar used to read the collected rain as a depth (S1 p.12–13; S2 p.7–9; V p.7–8)." },
          { k: "h", t: "Siting rules (S2 p.7; V p.7–8)" },
          { k: "list", items: [
            "Ground must be level and open, so the gauge's rim is horizontal. (S2 p.7; V p.7)",
            "The gauge must be surrounded by an open, fenced area of at least <b>5.5 m × 5.5 m</b>. (S2 p.7; V p.7)",
            "No object/obstruction should be nearer to the instrument than <b>30 m</b>, or <b>twice the height of the obstruction</b> — whichever is more. (S2 p.7; V p.7)",
            "The gauge should be set as near the ground as possible (to reduce wind effect), but sufficiently high to avoid being affected by flooding. V's own source sketch marks a specific recommended mounting-height range here, but the figure is illegible in that scan ('35 to 4 feet' — not a usable value); no specific height beyond this trade-off is given. (V p.8)",
          ] },
          { k: "note", t: "Rainfall is read every day at the same standard time, <b>08:30 (8:30 AM)</b>, by IMD convention — that reading is taken as the previous 24 hours' 'day's rainfall'. (S1 p.11; S2 p.9; V p.8)" },
          { k: "note", t: "Installation of non-recording gauges in India is governed by <b>IS 4986-1968</b>. (S2 p.9)" },
          { k: "list", items: [
            "<b>Disadvantage 1:</b> the receiving bottle does not hold more than 10 cm of water, so frequent observation/emptying is needed during heavy rainfall. (S2 p.9)",
            "<b>Disadvantage 2:</b> this gauge gives only the magnitude of rainfall, not its intensity. (S2 p.9)",
          ] },
          { k: "p", t: "IMD has largely moved from the original metal Symon's gauge to an improved fibre-glass-reinforced-polyester version of the same design. (S2 p.9; V p.7)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Siting rules sab ek hi logic follow karte hain — <b>kuch bhi aas-paas hawa ya rain-drop ke path ko disturb nahi karna chahiye.</b> '30m ya 2×H' rule isliye hai kyunki koi obstruction (building/tree) apne aas-paas turbulence banata hai jiska zone roughly uski height ke 2 guna tak phailta hai — usse paas gauge rakhne par catch ghat ya badh sakta hai, galat reading degi. Height ka trade-off bhi socho: zameen ke bahut paas rakhoge to wind-driven undercatch kam hoga par flood mein doob jaayega; bahut upar rakhoge to wind catch ko reduce kar dega (turbulent airflow drops ko gauge se bahar udaa deta hai)." },
          { k: "trap", t: "<b>Symon ≠ Siphon.</b> 'Symon's gauge' is named after its design/maker — the <i>siphon</i> is a completely different mechanism, used in the recording Natural-Syphon type gauge (section 2.5) to auto-empty a float chamber. S1's note that the gauge was 'Developed by Mr. Syphon' is kept here exactly as transcribed, but is most likely this same name confusion. (S1 p.12)" },
          { k: "real", t: "On a real site, this is the checklist to actually walk out and verify before installing a gauge: open, level ground; nothing taller than half the clearance distance within 30 m; a 5.5 m fenced plot; and a stand height that will survive the site's worst recorded flood level." },
        ],
      },

      /* ============================================================ 2.5 */
      {
        n: "2.5",
        title: "Recording rain gauges — tipping-bucket, weighing-bucket, syphon, telemetering and radar",
        hi: "अभिलेखी वर्षामापी — टिपिंग-बकेट, भार-बकेट, साइफन, टेलीमीटरिंग एवं रेडार",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.13; S2 p.8–11; V p.8–9" },
          { k: "def", term: "Recording gauge", t: "Automatically produces a continuous plot of accumulated rainfall against time, instead of just a daily total. This accumulated-rainfall-vs-time plot is called the <b>Mass Curve of Rainfall</b>, and its slope at any point gives the rainfall intensity at that time. (S1 p.13; S2 p.9; V p.9)" },
          { k: "list", items: [
            "<b>Tipping-bucket type:</b> a small pair of balanced buckets sits under the funnel; each bucket tips (bringing the other into position) once it collects a fixed 0.25 mm of rain. Intensity is worked out from the time taken to tip and/or the number of tips in an interval. Compact (about 30.5 cm), and useful for inaccessible, high-rainfall hilly areas. (S1 p.13; S2 p.8; V p.8)",
            "<b>Weighing-bucket type:</b> rainfall from the funnel collects into a bucket resting on a spring-loaded weighing platform; the weight of the bucket and its contents is traced, through the weighing mechanism, onto a chart on a clockwork-driven rotating drum that completes one revolution per day. Gives the mass curve of rainfall directly. (S1 p.13; S2 p.10; V p.8)",
            "<b>Natural-syphon (float) type:</b> rain from the funnel fills a float chamber; a float linked to a pen traces the rise on a chart wrapped on the recording drum. When the chamber fills completely, it self-empties through a syphon and the trace drops back to zero, so the record looks like a saw-tooth — rising slopes (= intensity) separated by vertical drops (the syphon draining). This type is most widely adopted by the IMD / Indian standards, and is described under <b>IS: 5235-1969</b>. (S1 p.13; S2 p.10–11; V p.8)",
            "<b>Telemetering gauge:</b> used in mountainous or otherwise inaccessible regions; carries an electronic unit that transmits its readings remotely, instead of needing a site visit to read the chart. Not covered by S1. (S2 p.8; V p.8)",
            "<b>Radar method:</b> one of the most accurate methods. Radar emits electromagnetic pulses (wavelength 3–10 cm — about 5 cm for light rain, about 10 cm for heavy rain/floods/cyclones) that are scattered by raindrops, and the return echo is measured by receivers. (S1 p.13; S2 p.11)",
          ] },
          { k: "note", t: "<b>Sources disagree on country of use:</b> S1 attributes the Tipping-bucket type to the <b>U.K.</b> and the Weighing-bucket type to the <b>U.S.A.</b>; S2 and V both instead attribute the Tipping-bucket type to the <b>U.S. Weather Bureau</b> — two sources against one on this specific point. Both versions are kept here; see each source's own page for its own attribution. (S1 p.13; S2 p.8; V p.8)" },
          { k: "eq", expr: "Average echo power received by radar:  P_H = C·Z / r²  ,  Z = 200·I^1.6", where: [
            ["C", "a constant"],
            ["Z", "radar echo factor"],
            ["I", "intensity of rainfall (mm/hr)"],
            ["r", "radial distance of the storm from the radar (km)"],
          ] },
          { k: "list", items: [
            "The hydrological range of a radar is about 340 km (an older figure of 200 km is also recorded in the source). (S2 p.11)",
            "At the time this source was compiled, about 40 radars were installed across India — a figure that will have changed since, so treat it as dated rather than current. (S2 p.11)",
            "A rain gauge measures what is called <b>point rainfall</b> or <b>station rainfall</b> — the magnitude of rainfall only at the one point where it is installed. Radar instead gives an <b>instantaneous image of the rainfall pattern</b> over an entire area. (S2 p.11)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Mass curve ka concept simple hai — y-axis par accumulated rainfall (cumulative total, kabhi neeche nahi aata except syphon type ke self-empty drops mein), x-axis par time. Kyunki slope = Δrainfall/Δtime = <b>intensity</b>, isiliye jahan curve steep hai wahan heavy rain tha, jahan flat hai wahan rain ruka tha ya bahut light tha. Weighing-bucket aur natural-syphon dono directly yeh mass curve dete hain; tipping-bucket thoda alag hai — woh continuous curve nahi, discrete steps (0.25mm ka ek-ek tip) deta hai, jisse intensity thoda 'lumpy'/stepped resolution mein milti hai, bilkul continuous nahi." },
          { k: "trap", t: "Radar 'point rainfall' nahi deta — woh ek area ka instantaneous pattern deta hai, jabki har tarah ka rain-gauge (recording ya non-recording) hamesha ek hi point ka reading deta hai. Dono complementary hain, ek doosre ka replacement nahi — isiliye real network mein gauges aur radar dono use hote hain." },
        ],
      },

      /* ============================================================ 2.6 */
      {
        n: "2.6",
        title: "Optimum rain-gauge network density — the N/Cv/standard-error formula",
        hi: "वर्षामापी नेटवर्क का उपयुक्त घनत्व — N/Cv/मानक त्रुटि सूत्र",
        blocks: [
          { k: "h", t: "📘 Notes — S1 p.14–15; S2 p.12–13; V p.9–10" },
          { k: "def", term: "Rain-gauge (network) density", t: "The ratio of total catchment area to the total number of gauges in it — i.e. the average area served by each gauge. Density should be as small an area-per-gauge as practically possible, for accurate hydrological analysis/forecasting; density is correspondingly kept higher (smaller area per gauge) in hilly terrain. (V p.8–9)" },
          { k: "def", term: "Optimum number of rain-gauge stations (N)", t: "The statistically required number of stations, compared against the existing number, to decide whether additional gauges are needed. (S1 p.13)" },
          { k: "eq", expr: "N = (Cv / ε)²", where: [
            ["N", "optimum number of rain-gauge stations"],
            ["Cv", "coefficient of variation (%) of rainfall across the existing stations"],
            ["ε (or E)", "allowable % error in the estimate of the mean rainfall"],
          ] },
          { k: "eq", expr: "Mean rainfall:  P̄ = (P₁ + P₂ + ⋯ + Pₙ) / n       Coefficient of variation:  Cv = (σ / P̄) × 100", where: [
            ["n", "number of existing rain-gauge stations"],
          ] },
          { k: "eq", expr: "Standard deviation — form 1 (used in S1's worked examples):  σ = √[ Σ(P − P̄)² / (n − 1) ]", where: [] },
          { k: "eq", expr: "Standard deviation — form 2 (used in S2's worked examples):  σ = √[ n/(n−1) · ( mean(P²) − P̄² ) ]", where: [
            ["mean(P²)", "mean of the squares of the individual rainfall values, i.e. ΣP²/n"],
            ["P̄²", "square of the mean rainfall, i.e. (ΣP/n)²"],
          ] },
          { k: "note", t: "The two σ forms above are algebraically identical — they are simply two different calculation routes to the same sample standard deviation. S1's worked examples use form 1; S2's use form 2. (S1 p.14; S2 p.12)" },
          { k: "note", t: "<b>Discrepant formula:</b> V's transcript gives the coefficient of variation as <b>Cv = 1000σ/P̄</b> — missing the conventional ×100(%) scaling and instead using a coefficient of 1000. This is almost certainly a transcription/OCR slip (reading '100' as '1000'), since S1 and S2 both define Cv the conventional way, as (σ/P̄)×100%. Kept here exactly as V states it rather than silently corrected. (V p.10; cf. S1 p.14; S2 p.12)" },
          { k: "def", term: "Standard error (E')", t: "The actual error corresponding to the existing set of rain-gauge stations. E' = Cv/√n. (S2 p.12)" },
          { k: "list", items: [
            "Illustrative example — Delhi, 3 existing stations: E' = Cv/√3 ≈ 12% (say). (S2 p.12)",
            "Illustrative example — Delhi, 7 existing stations, allowable error 5%: N = (Cv/5)² ≈ 7 (say). (S2 p.12)",
          ] },
          { k: "note", t: "WMO recommends that at least 10% of the total rain gauges in a network should be of the recording type, with the rest non-recording. (S2 p.12; V p.8)" },
          { k: "eg", title: "Worked example 1 — optimum N for an allowable error of 10%", given: "Six existing rain-gauge stations A–F record annual rainfall of 85, 110, 135, 95, 115 and 140 cm. Find the optimum number of rain-gauge stations for a permissible error of 10%.", steps: [
            { t: "Mean rainfall", w: "P̄ = (85+110+135+95+115+140)/6 = 680/6 = 113.33 cm" },
            { t: "Sum of squared deviations", w: "(85−113.33)² + (110−113.33)² + (135−113.33)² + (95−113.33)² + (115−113.33)² + (140−113.33)² = 802.59 + 11.09 + 469.69 + 335.99 + 2.79 + 711.29 = 2333.43" },
            { t: "Standard deviation", w: "σ = √[2333.43 / (6−1)] = √466.69 = 21.6" },
            { t: "Coefficient of variation", w: "Cv = (σ/P̄) × 100 = (21.6/113.33) × 100 = 19.06%" },
            { t: "Optimum number of stations", w: "N = (Cv/ε)² = (19.06/10)² = 3.63" },
          ], ans: "N ≈ 4 stations (rounded up) (S1 p.14–15)" },
          { k: "note", t: "<b>Check:</b> the source transcript's working for Cv shows the numerator as '21.16' on that line, even though σ was computed as 21.6 just above it. This is almost certainly a transcription slip, not a real arithmetic error — 21.6/113.33×100 = 19.06%, which is exactly the Cv the source's own next line uses to get N ≈ 4, while 21.16/113.33×100 would give 18.67% instead. Use σ = 21.6 (S1 p.14–15)." },
          { k: "eg", title: "Worked example 2 — optimum N for an allowable error of 15% (source incomplete)", given: "Six existing rain-gauge stations A–F record annual rainfall of 75, 85, 65, 110, 120 and 145 cm. Allowable error 15%. Find the optimum number of rain-gauge stations.", steps: [
            { t: "Mean rainfall", w: "P̄ = (75+85+65+110+120+145)/6 = 600/6 = 100 cm" },
            { t: "Sum of squared deviations", w: "(75−100)² + (85−100)² + (65−100)² + (110−100)² + (120−100)² + (145−100)² = 625+225+1225+100+400+2025 = 4600" },
            { t: "Standard deviation", w: "σ = √[4600/(6−1)] = √920 = 30.33" },
            { t: "Coefficient of variation", w: "Cv = (σ/P̄) × 100 = (30.33/100) × 100 = 30.33%" },
          ], ans: "The source page ends right here, before computing N — it stops at Cv = 30.33% ('problem not completed'). Applying the same formula the source uses elsewhere to its own figures: N = (Cv/ε)² = (30.33/15)² ≈ 4.09 → rounded up, 5 stations. (S1 p.15)" },
          { k: "eg", title: "Worked example 3 — standard error and optimum N for 10% error", given: "Six rain-gauge stations A–F record annual rainfall of 82.6, 102.9, 180.3, 110.3, 98.8 and 136.7 cm. Find (i) the standard error in the estimate of mean rainfall, and (ii) the optimum number of stations for a 10% error in that estimate.", steps: [
            { t: "Mean rainfall", w: "P̄ = (82.6+102.9+180.3+110.3+98.8+136.7)/6 = 711.6/6 = 118.6 cm" },
            { t: "Mean of the squares", w: "mean(P²) = (82.6²+102.9²+180.3²+110.3²+98.8²+136.7²)/6 = 15088.9 cm²" },
            { t: "Standard deviation", w: "σ = √[6/5 × (15088.9 − 118.6²)] = √[6/5 × (15088.9 − 14065.96)] = √1227.53 = 35.03" },
            { t: "Coefficient of variation", w: "Cv = (σ/P̄) × 100 = (35.03/118.6) × 100 = 29.54%" },
            { t: "(i) Standard error", w: "E' = Cv/√n = 29.54/√6 = 12.06%" },
            { t: "(ii) Optimum number of stations", w: "N = (Cv/E)² = (29.54/10)² = 8.72" },
          ], ans: "Standard error ≈ 12.06%; optimum N ≈ 9 stations (rounded up from 8.72) (S2 p.13)" },
          { k: "cmp", t: "Zone-wise data for a 1130 km² basin with 8 existing stations (S2 p.13)", cols: ["Area (km²)", "Station(s)", "Annual rainfall (cm)"], rows: [
            ["Zone 1", "85", "A", "120"],
            ["Zone 2", "290", "B, C", "95, 96"],
            ["Zone 3", "395", "D, E, F", "60, 65, 70"],
            ["Zone 4", "230", "G", "45"],
            ["Zone 5", "65", "H", "21"],
            ["Zone 6", "65", "— (none)", "—"],
          ] },
          { k: "eg", title: "Worked example 4 — additional stations needed, and where to put them", given: "For the 1130 km² basin above (table), find how many additional rain-gauge stations are needed if the allowable error in the estimate of mean rainfall is not to exceed 10 cm, and suggest how to distribute them.", steps: [
            { t: "Mean rainfall (n = 8 existing stations)", w: "P̄ = (120+95+96+60+65+70+45+21)/8 = 572/8 = 71.5 cm" },
            { t: "Mean of the squares", w: "mean(P²) = (120²+95²+96²+60²+65²+70²+45²+21²)/8 = 5979 cm²" },
            { t: "Standard deviation", w: "σ = √[8/7 × (5979 − 71.5²)] = √[8/7 × (5979 − 5112.25)] = √990.57 = 31.47" },
            { t: "Coefficient of variation", w: "Cv = (σ/P̄) × 100 = (31.47/71.5) × 100 = 44.02%" },
            { t: "Allowable error as a percentage", w: "%E = (10/71.5) × 100 = 13.98%" },
            { t: "Optimum number of stations", w: "N = (Cv/E)² = (44.02/13.98)² = 9.91" },
            { t: "Additional stations required", w: "N − n = 10 − 8 = 2" },
          ], ans: "2 additional stations are required, sited in Zone-4 and Zone-6 — the zones with the thinnest existing coverage (230 km² served by only one gauge, and 65 km² with none at all). (S2 p.13)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "N = (Cv/ε)² ka sabse important implication yeh hai ki yeh <b>inverse-square</b> relationship hai — agar tumhe apna allowable error <b>aadha</b> karna hai (double precision chahiye), to gauges <b>4 guna</b> badhane padenge, 2 guna nahi. Isi tarah agar rainfall zyada variable hai (high Cv, matlab station-to-station rainfall mein zyada farak), to same precision ke liye zyada gauges chahiye honge — isiliye hilly/high-rainfall areas (jahan rainfall spatially bahut variable hota hai) ko flat plains se zyada dense network chahiye hota hai." },
          { k: "trap", t: "N ko hamesha <b>upar round</b> karo, kabhi neeche nahi — N=3.63 ko 3 round karoge to allowable error actually exceed ho jaayega, criteria satisfy nahi hoga. Isi tarah jab additional stations nikalo (N − n), round-up N hi use karo, decimal N nahi." },
          { k: "real", t: "Worked example 4 jaisa real catchment distribution problem batata hai ki additional gauges hamesha <b>sabse kam-covered zones</b> mein jaate hain — Zone-4 mein already ek gauge tha par 230 km² ke liye kaafi nahi tha, Zone-6 mein ek bhi nahi tha. Yeh general principle hai: existing gap sabse pehle bharo, blindly sab zones mein equally mat baanto." },
        ],
      },

      /* ============================================================ 2.7 */
      {
        n: "2.7",
        title: "WMO, IMD and IS spacing recommendations",
        hi: "WMO, IMD एवं IS द्वारा अनुशंसित दूरी",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.12, 14; V p.8–9" },
          { k: "cmp", t: "Recommended network density by terrain and authority (S2 p.14; V p.8–9)", cols: ["Area served per gauge"], rows: [
            ["WMO — flat region, tropical zone", "600–900 km²"],
            ["WMO — mountainous region, tropical zone", "100–250 km²"],
            ["WMO — polar zone", "1500–10,000 km²"],
            ["IMD / IS code — plain areas", "520 km² (denser where the area lies in the path of low-pressure systems)"],
            ["IMD / IS code — avg. elevation about 1000 m", "260–390 km²"],
            ["IMD / IS code — hilly region, heavy rainfall", "130 km²"],
          ] },
          { k: "note", t: "S2 attributes the second set of figures to the 'IMD recommendation' while V attributes the identical numbers to 'the Indian standard code'. Since the values themselves match exactly, both attributions are kept together as one set of figures rather than treated as a conflict. (S2 p.14; V p.9)" },
          { k: "note", t: "WMO also recommends that at least 10% of a network's total gauges be of the recording type (repeated from section 2.6). (S2 p.12; V p.8)" },
          { k: "p", t: "India is the world's 2nd-largest country whose territory passes through the Tropic of Cancer (across 8 states). Worked examples of the zones above: <b>Bihar and Uttar Pradesh</b> are treated as plain-area density; the <b>Western Ghats of Maharashtra</b> as hilly, high-rainfall density. (S2 p.14)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Pattern dekho — jahan rainfall <b>spatially zyada variable</b> hota hai (hilly/high-rainfall relief rainfall, jahan ek valley aur usse 5km door ridge ka rainfall bahut alag ho sakta hai), wahan area-per-gauge sabse chota hai (130 km²). Jahan terrain flat hai aur rainfall zyada uniform hai (plains, polar zones), wahan area-per-gauge bahut bada ho sakta hai (plains: 520km²; polar: 1500–10,000km²). Yeh seedha section 2.6 ke Cv wale concept se connect hota hai — zyada spatial variability = zyada density chahiye, same jaisa temporal variability (high Cv) zyada stations maangta hai." },
        ],
      },

      /* ============================================================ 2.8 */
      {
        n: "2.8",
        title: "Quick revision — precipitation, forms, gauges and network density",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Six forms of precipitation — rain (with its light/moderate/heavy intensity classes), snow, drizzle, glaze, sleet, hail — definitions, sizes and how each forms (S1 p.11–12; S2 p.3; V p.5–6).",
            "Causes: convective, orographic (windward/leeward contrast) and cyclonic precipitation — fronts, tropical vs. extratropical cyclones, anticyclones (V p.6).",
            "India's 4 rainfall seasons; SW monsoon gives ~75% of annual rainfall via two branches meeting over Delhi; Cv of annual rainfall 15–70% (avg ~30%); water year = 1 June–31 May (S2 p.3; V p.7).",
            "Symon's gauge: 12.7 cm funnel diameter, 30.5 cm rim height, ≤10 cm bottle capacity, siting rules (5.5 m fence, 30 m/2×H clearance, read daily at 8:30 AM) (S1 p.12–13; S2 p.7–9; V p.7–8).",
            "Five recording-gauge types: tipping-bucket (0.25 mm per tip), weighing-bucket, natural-syphon/float (IS 5235-1969), telemetering, radar (P_H = C·Z/r², Z = 200·I^1.6) (S1 p.13; S2 p.8–11; V p.8–9).",
            "Network-density formulas: N = (Cv/ε)², Cv = (σ/P̄)×100, standard error E' = Cv/√n; always round N up (S1 p.14–15; S2 p.12–13; V p.9–10).",
            "WMO and IMD/IS recommended gauge spacing by terrain, from 130 km²/gauge (hilly, heavy rainfall) to 10,000 km²/gauge (polar) (S2 p.14; V p.8–9).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "A rain gauge only ever reports 'how much', never 'how fast' — only a recording gauge's mass curve (slope = intensity) or the radar method gives the time/area pattern (S1 p.13; S2 p.9, 11; V p.9).",
            "N = (Cv/ε)² is an inverse-square relationship: halving the allowable error ε needs 4× as many gauges, not 2× (S1 p.14; S2 p.12).",
            "Two sources disagree on which country uses the tipping-bucket gauge — S1 says U.K. (and Weighing-bucket, U.S.A.); S2 and V both say the Tipping-bucket is the U.S. Weather Bureau's — flagged, not resolved (S1 p.13; S2 p.8; V p.8).",
            "Denser networks always go where rainfall is spatially most variable — hilly, high-rainfall terrain (as little as 130 km²/gauge) vs. flat plains (520 km²/gauge) or polar zones (up to 10,000 km²/gauge) (S2 p.14; V p.8–9).",
          ] },
        ],
      },

    ],
  });
})();
