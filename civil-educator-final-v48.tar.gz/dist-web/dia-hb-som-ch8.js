/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 8.
   Conventions as in dia-hb-som-ch1.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 8.3  UNIT LOAD ON A TRUSS */
  "hb-som-truss": {
    label: "Unit load method on a three-member truss (Worked example 8.3)",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="Left: the real truss — a triangle with bottom chord A B of 6 metres, apex C 4 metres high, pin support at A and roller at B, and a 100 kilonewton load at C. Member forces: A C and B C each 62.5 kilonewtons compression, A B 37.5 tension. Right: the same truss with the real load removed and a unit load of 1 at C in the direction of the deflection wanted; member forces are the real ones divided by 100: 0.625 compression in the rafters and 0.375 tension in the tie. The vertical deflection of C is the sum over members of n N L over A E.">
      ${somMk("sm14")}
      ${[[40,"Real loads: N","P = 100 kN","−62.5","+37.5"],[340,"Unit load: n","1","−0.625","+0.375"]].map(([x0,t,load,rc,tie])=>`
        <line class="hi" x1="${x0}" y1="230" x2="${x0+120}" y2="70"/>
        <line class="hi" x1="${x0+240}" y1="230" x2="${x0+120}" y2="70"/>
        <line class="ac" x1="${x0}" y1="230" x2="${x0+240}" y2="230"/>
        <circle class="s" cx="${x0}" cy="230" r="4"/><circle class="s" cx="${x0+240}" cy="230" r="4"/><circle class="s" cx="${x0+120}" cy="70" r="4"/>
        <path class="s" d="M${x0} 234 L${x0-10} 250 L${x0+10} 250 Z"/>
        <circle class="s" cx="${x0+240}" cy="242" r="7"/>
        <line class="s" x1="${x0+120}" y1="22" x2="${x0+120}" y2="62" marker-end="url(#sm14-a)"/>
        <text x="${x0+128}" y="34">${load}</text>
        <text class="em" x="${x0+44}" y="140" text-anchor="end">${rc}</text>
        <text class="em" x="${x0+196}" y="140">${rc}</text>
        <text class="ea" x="${x0+120}" y="222" text-anchor="middle">${tie}</text>
        <text x="${x0+120}" y="276" text-anchor="middle">${t}</text>
        <text class="lb" x="${x0-8}" y="266">A</text><text class="lb" x="${x0+244}" y="266">B</text><text class="lb" x="${x0+108}" y="62">C</text>`).join("")}
      <text class="lb" x="320" y="296" text-anchor="middle">AB = 6 m, AC = BC = 5 m, height 4 m · compression −, tension +</text>
    </svg>`,
    caption: "Two analyses of the same truss: once with the real loads (N), once with only a unit load placed where and in the direction the deflection is wanted (n). Then δ = Σ nNL/AE — no differentiation needed.",
  },
});
