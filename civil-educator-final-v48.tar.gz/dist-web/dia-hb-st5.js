/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 9–10
   Beam-columns · Plate girders
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 9.2 P-DELTA */
  "hb-st-pdelta": {
    label: "The second-order moment a beam-column makes for itself",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A column carrying axial load and an applied end moment, deflecting sideways so that the axial load acts at an eccentricity equal to that deflection, producing an additional P delta moment which increases the deflection further">
      ${hbmk("pd")}
      <text class="em" x="350" y="24" text-anchor="middle">P × δ — THE MOMENT NOBODY APPLIED</text>
      <line class="thin dash" x1="180" y1="56" x2="180" y2="236"/>
      <path class="hi" d="M180 236 C126 196 126 100 180 56"/>
      ${grd(152, 240, 56)}
      <line class="ac" x1="180" y1="30" x2="180" y2="52" marker-end="url(#pd-c)"/>
      <text class="ea" x="192" y="44">P</text>
      <path class="ac" d="M206 66 A26 26 0 0 1 206 104" fill="none" marker-end="url(#pd-c)"/>
      <text class="ea" x="218" y="90">M applied</text>
      <line class="ac" x1="180" y1="146" x2="138" y2="146" marker-end="url(#pd-c)" marker-start="url(#pd-c)"/>
      <text class="ea" x="130" y="150" text-anchor="end">δ</text>

      <text class="em" x="300" y="150">P now acts δ off the axis,</text>
      <text class="em" x="300" y="172">so it adds a moment P δ …</text>
      <text class="lb" x="300" y="200">… which increases δ …</text>
      <text class="lb" x="300" y="222">… which increases P δ …</text>
      <text class="em" x="300" y="252">the loop either converges</text>
      <text class="em" x="300" y="274">or the member fails</text>

      <line class="gl" x1="520" y1="44" x2="520" y2="286"/>
      <text class="em" x="612" y="80" text-anchor="middle">this is why</text>
      <text class="em" x="612" y="102" text-anchor="middle">P and M cannot</text>
      <text class="em" x="612" y="124" text-anchor="middle">be checked</text>
      <text class="em" x="612" y="146" text-anchor="middle">separately</text>
      <text class="lb" x="612" y="182" text-anchor="middle">a member safe</text>
      <text class="lb" x="612" y="204" text-anchor="middle">under P alone</text>
      <text class="lb" x="612" y="226" text-anchor="middle">and safe under</text>
      <text class="lb" x="612" y="248" text-anchor="middle">M alone can fail</text>
      <text class="lb" x="612" y="270" text-anchor="middle">under both</text>
    </svg>`,
    caption: "Axial load and bending do not simply add. The bending produces a deflection, the axial load then acts at that eccentricity, and the extra moment produces more deflection. The interaction expressions of Cl. 9.3 are how IS 800 keeps that feedback inside a hand calculation.",
  },

  /* ---------------------------------------- 9.3 INTERACTION */
  "hb-st-interaction": {
    label: "The two checks a beam-column has to pass",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two interaction diagrams side by side: a section capacity curve which bulges outwards because a plastic section resists combined actions better than a linear sum suggests, and an overall member buckling curve which is close to a straight line and usually governs">
      ${hbmk("ia")}
      <text class="em" x="176" y="26" text-anchor="middle">① SECTION CAPACITY (local)</text>
      <line class="s" x1="70" y1="56" x2="70" y2="212"/>
      <line class="s" x1="70" y1="212" x2="290" y2="212"/>
      <text class="lb" x="62" y="62" text-anchor="end">P/Nd</text>
      <text class="lb" x="288" y="234" text-anchor="end">M/Md</text>
      <path class="hi" d="M70 62 C170 66 232 124 262 212"/>
      <path class="thin dash" d="M70 62 L262 212"/>
      <text class="lb" x="176" y="112">bulges OUT —</text>
      <text class="lb" x="176" y="132">a plastic section</text>
      <text class="lb" x="176" y="152">does better than</text>
      <text class="lb" x="176" y="172">a linear sum</text>
      <text class="lb" x="176" y="262" text-anchor="middle">is the CROSS-SECTION</text>
      <text class="lb" x="176" y="282" text-anchor="middle">strong enough?</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">② OVERALL BUCKLING (member)</text>
      <line class="s" x1="418" y1="56" x2="418" y2="212"/>
      <line class="s" x1="418" y1="212" x2="638" y2="212"/>
      <text class="lb" x="410" y="62" text-anchor="end">P/Pd</text>
      <text class="lb" x="636" y="234" text-anchor="end">M/Mdz</text>
      <path class="hi" d="M418 62 C470 96 540 150 610 212"/>
      <path class="thin dash" d="M418 62 L610 212"/>
      <text class="lb" x="500" y="120">close to linear,</text>
      <text class="lb" x="500" y="140">sometimes inside it</text>
      <text class="em" x="524" y="262" text-anchor="middle">will the MEMBER buckle?</text>
      <text class="em" x="524" y="282" text-anchor="middle">— usually the governing check</text>
    </svg>`,
    caption: "Cl. 9.3.1 asks whether the cross-section can take the combination, and Cl. 9.3.2 asks whether the member will buckle under it. They are different questions with different answers, and a member can pass the first comfortably while failing the second.",
  },

  /* ---------------------------------------- 10.1 WHY A PLATE GIRDER */
  "hb-st-girder": {
    label: "The anatomy of a plate girder",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A welded plate girder in elevation showing the deep thin web, the two flange plates, intermediate transverse stiffeners along the span and heavier bearing stiffeners over the supports, with a cross section alongside">
      ${hbmk("pg")}
      <text class="em" x="350" y="24" text-anchor="middle">BUILT FROM PLATE — EVERY DIMENSION IS A DECISION</text>
      <rect class="conc" x="70" y="62" width="440" height="18"/>
      <rect class="conc" x="70" y="200" width="440" height="18"/>
      <rect class="soft" x="70" y="80" width="440" height="120"/>
      ${[0,1,2,3].map(i=>`<rect class="steel" x="${152+i*86}" y="80" width="8" height="120"/>`).join("")}
      <rect class="steel" x="76" y="80" width="14" height="120"/>
      <rect class="steel" x="490" y="80" width="14" height="120"/>
      ${grd(60, 224, 44)}
      ${grd(476, 224, 44)}
      <text class="ea" x="290" y="56" text-anchor="middle">flange plate — carries the moment</text>
      <text class="lb" x="290" y="146" text-anchor="middle">web — deep and thin</text>
      <text class="lb" x="196" y="246" text-anchor="middle">intermediate stiffeners</text>
      <text class="lb" x="84" y="266" text-anchor="middle">bearing</text>
      <text class="lb" x="84" y="284" text-anchor="middle">stiffener</text>

      <line class="gl" x1="544" y1="44" x2="544" y2="290"/>
      <rect class="conc" x="574" y="62" width="100" height="16"/>
      <rect class="conc" x="574" y="202" width="100" height="16"/>
      <rect class="soft" x="618" y="78" width="12" height="124"/>
      <line class="ac" x1="574" y1="240" x2="674" y2="240" marker-end="url(#pg-c)" marker-start="url(#pg-c)"/>
      <text class="ea" x="624" y="258" text-anchor="middle">bf</text>
      <line class="ac" x1="694" y1="78" x2="694" y2="202" marker-end="url(#pg-c)" marker-start="url(#pg-c)"/>
      <text class="ea" x="684" y="144" text-anchor="end">d</text>
      <text class="lb" x="624" y="284" text-anchor="middle">d/tw can exceed 200</text>
    </svg>`,
    caption: "A rolled section's proportions were decided by the mill. A plate girder's are decided by the designer — depth, web thickness, flange width, flange thickness and stiffener spacing are five independent choices, which is what makes it efficient and what makes it work.",
  },

  /* ---------------------------------------- 10.3 SHEAR BUCKLING */
  "hb-st-shearbuckle": {
    label: "A thin web buckles in shear before it yields",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A deep thin web panel under shear developing diagonal compression and diagonal tension, buckling into waves along the compression diagonal, and the same panel with closer stiffeners where the shorter panel resists buckling much better">
      ${hbmk("sb")}
      <text class="em" x="176" y="26" text-anchor="middle">WIDE PANEL — IT BUCKLES</text>
      <rect class="soft" x="66" y="56" width="220" height="150"/>
      <rect class="steel" x="66" y="56" width="10" height="150"/>
      <rect class="steel" x="276" y="56" width="10" height="150"/>
      <line class="ac" x1="86" y1="196" x2="266" y2="66" marker-end="url(#sb-c)" marker-start="url(#sb-c)"/>
      <text class="ea" x="250" y="96">tension</text>
      <line class="hi" x1="266" y1="196" x2="86" y2="66" marker-end="url(#sb-m)" marker-start="url(#sb-m)"/>
      <text class="ea" x="100" y="96">compression</text>
      ${[0,1,2].map(i=>`<path class="thin" d="M${100+i*52} 196 C${124+i*52} 156 ${140+i*52} 106 ${164+i*52} 66"/>`).join("")}
      <text class="lb" x="176" y="232" text-anchor="middle">the compression diagonal ripples,</text>
      <text class="lb" x="176" y="252" text-anchor="middle">and the panel gives up long before</text>
      <text class="lb" x="176" y="272" text-anchor="middle">the steel reaches its shear yield</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="290"/>

      <text class="em" x="524" y="26" text-anchor="middle">CLOSE STIFFENERS — IT DOES NOT</text>
      <rect class="soft" x="414" y="56" width="220" height="150"/>
      ${[0,1,2,3,4].map(i=>`<rect class="steel" x="${414+i*52}" y="56" width="10" height="150"/>`).join("")}
      <rect class="steel" x="624" y="56" width="10" height="150"/>
      <text class="lb" x="524" y="232" text-anchor="middle">each panel is now short and stocky —</text>
      <text class="lb" x="524" y="252" text-anchor="middle">kv rises, the critical stress rises with it,</text>
      <text class="em" x="524" y="276" text-anchor="middle">and the web can reach shear yield</text>
    </svg>`,
    caption: "Shear on a panel is diagonal tension one way and diagonal compression the other. A thin panel cannot carry the compression diagonal and buckles into waves. Transverse stiffeners do not carry the shear themselves — they shorten the panel so that the compression diagonal has less length in which to buckle.",
  },

  /* ---------------------------------------- 10.4 TENSION FIELD */
  "hb-st-tensionfield": {
    label: "Tension field action — the web as a truss diagonal",
    svg: `<svg viewBox="0 0 712 290" role="img" aria-label="A buckled web panel after the compression diagonal has gone, carrying further load as a band of diagonal tension anchored by the flanges and the stiffeners, so that the girder behaves as a Pratt truss with the stiffeners acting as vertical posts">
      ${hbmk("tfd")}
      <text class="em" x="350" y="24" text-anchor="middle">AFTER BUCKLING, THE WEB IS STILL USEFUL</text>
      <rect class="conc" x="70" y="56" width="440" height="16"/>
      <rect class="conc" x="70" y="200" width="440" height="16"/>
      ${[0,1,2,3,4].map(i=>`<rect class="steel" x="${74+i*106}" y="72" width="12" height="128"/>`).join("")}
      ${[0,1,2,3].map(i=>[0,1,2,3].map(j=>`<line class="ac" x1="${92+i*106+j*20}" y1="198" x2="${112+i*106+j*20}" y2="74"/>`).join("")).join("")}
      <text class="ea" x="560" y="96">diagonal TENSION band</text>
      <text class="lb" x="560" y="116">— the only thing left</text>
      <text class="lb" x="560" y="136">after the compression</text>
      <text class="lb" x="560" y="156">diagonal has gone</text>
      <text class="em" x="290" y="250" text-anchor="middle">the stiffeners become the vertical POSTS of a truss,</text>
      <text class="em" x="290" y="272" text-anchor="middle">carrying compression — so they must be designed for it</text>
    </svg>`,
    caption: "A buckled panel is not a failed one. The diagonal tension band remains, anchored by the flanges and the stiffeners, and the girder carries further load as a Pratt truss. Cl. 8.4.2.2 permits this explicitly — and it is why an intermediate stiffener in a tension-field design is a compression member with a real calculation behind it.",
  },

  /* ---------------------------------------- 10.6 STIFFENERS */
  "hb-st-stiffeners": {
    label: "The stiffeners, and what each one is for",
    svg: `<svg viewBox="0 0 740 296" role="img" aria-label="A plate girder showing bearing stiffeners at the supports transferring the reaction between the flanges, intermediate transverse stiffeners dividing the web into panels, and a longitudinal stiffener running along the compression zone of a very deep web">
      ${hbmk("sf")}
      <text class="em" x="350" y="24" text-anchor="middle">THREE KINDS, THREE JOBS</text>
      <rect class="conc" x="60" y="54" width="580" height="16"/>
      <rect class="conc" x="60" y="190" width="580" height="16"/>
      <rect class="soft" x="60" y="70" width="580" height="120"/>
      <rect class="steel" x="64" y="70" width="18" height="120"/>
      <rect class="steel" x="618" y="70" width="18" height="120"/>
      ${[0,1,2,3,4].map(i=>`<rect class="steel" x="${160+i*94}" y="70" width="9" height="120"/>`).join("")}
      <line class="hi" x1="322" y1="104" x2="628" y2="104"/>
      ${grd(52, 212, 40)}
      ${grd(608, 212, 40)}
      <line class="ac" x1="73" y1="34" x2="73" y2="50" marker-end="url(#sf-c)"/>

      <text class="em" x="60" y="248">BEARING</text>
      <text class="lb" x="60" y="268">at supports and point loads — takes the</text>
      <text class="em" x="330" y="248">INTERMEDIATE</text>
      <text class="lb" x="330" y="268">divides the web into panels, raising kv</text>
      <text class="em" x="560" y="248">LONGITUDINAL</text>
      <text class="lb" x="560" y="268">for very deep webs, in the</text>
      <text class="lb" x="60" y="286">whole reaction between the flanges</text>
      <text class="lb" x="560" y="286">compression zone only</text>
    </svg>`,
    caption: "A bearing stiffener carries load; an intermediate stiffener changes the geometry of the panel so the web can carry more; a longitudinal stiffener is placed in the compression zone of a very deep web, where bending rather than shear is what buckles it.",
  },

});
