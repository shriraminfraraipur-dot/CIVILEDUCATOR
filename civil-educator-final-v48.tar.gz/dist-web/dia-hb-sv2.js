/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: SURVEYING handbook, Chapters 5–8
   Plane table · Levelling · Contouring · Theodolite and traverse
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 5.3 PLANE TABLE METHODS */
  "hb-sv-planetable": {
    label: "The four plane table methods",
    svg: `<svg viewBox="0 0 736 300" role="img" aria-label="Four plane table methods: radiation with rays drawn from one station to several points whose distances are measured, intersection with rays from two stations meeting at the point, traversing from station to station around a framework, and resection where the table's own position is found from rays to three known points.">
      ${hbmk("pt2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE TABLE IS THE DRAWING BOARD — THE PLOT IS MADE IN THE FIELD</text>
      ${[["RADIATION", 108, 0], ["INTERSECTION", 285, 1], ["TRAVERSING", 462, 2], ["RESECTION", 630, 3]]
        .map(([t, x, k]) => `
        <text class="em" x="${x}" y="60" text-anchor="middle">${t}</text>
        ${k === 0 ? `<circle class="hif" cx="${x}" cy="180" r="6"/>
            ${[[-52, -52], [0, -66], [52, -46], [56, 14], [-50, 18]].map(([dx, dy]) =>
              `<line class="hi" x1="${x}" y1="180" x2="${x + dx}" y2="${180 + dy}"/><circle class="acf" cx="${x + dx}" cy="${180 + dy}" r="4"/>`).join("")}
            <text class="lb" x="${x}" y="228" text-anchor="middle">one station, rays out,</text>
            <text class="lb" x="${x}" y="248" text-anchor="middle">distances measured</text>
            <text class="lb" x="${x}" y="272" text-anchor="middle">small areas only</text>`
          : k === 1 ? `<circle class="hif" cx="${x - 50}" cy="200" r="6"/><circle class="hif" cx="${x + 50}" cy="200" r="6"/>
            <line class="s" x1="${x - 50}" y1="200" x2="${x + 50}" y2="200"/>
            <line class="hi" x1="${x - 50}" y1="200" x2="${x + 6}" y2="118"/>
            <line class="hi" x1="${x + 50}" y1="200" x2="${x + 6}" y2="118"/>
            <circle class="acf" cx="${x + 6}" cy="118" r="5"/>
            <text class="lb" x="${x}" y="228" text-anchor="middle">two stations, no distance</text>
            <text class="lb" x="${x}" y="248" text-anchor="middle">to the point at all</text>
            <text class="lb" x="${x}" y="272" text-anchor="middle">for inaccessible objects</text>`
          : k === 2 ? `${[[-46, 24], [-10, -44], [44, -14], [28, 40]].map(([dx, dy], i, a) => {
              const n = a[(i + 1) % a.length];
              return `<line class="hi" x1="${x + dx}" y1="${170 + dy}" x2="${x + n[0]}" y2="${170 + n[1]}"/><circle class="hif" cx="${x + dx}" cy="${170 + dy}" r="5"/>`;
            }).join("")}
            <text class="lb" x="${x}" y="228" text-anchor="middle">station to station round</text>
            <text class="lb" x="${x}" y="248" text-anchor="middle">a closed framework</text>
            <text class="lb" x="${x}" y="272" text-anchor="middle">like any traverse</text>`
          : `${[[-46, -50], [36, -56], [50, 8]].map(([dx, dy]) =>
              `<circle class="hif" cx="${x + dx}" cy="${180 + dy}" r="5"/><line class="hi" x1="${x + dx}" y1="${180 + dy}" x2="${x}" y2="180"/>`).join("")}
            <circle class="acf" cx="${x}" cy="180" r="6"/>
            <text class="lb" x="${x}" y="228" text-anchor="middle">rays to three KNOWN points</text>
            <text class="lb" x="${x}" y="248" text-anchor="middle">fix where YOU are standing</text>
            <text class="em" x="${x}" y="272" text-anchor="middle">the three-point problem</text>`}`).join("")}
      <line class="gl" x1="196" y1="48" x2="196" y2="284"/>
      <line class="gl" x1="374" y1="48" x2="374" y2="284"/>
      <line class="gl" x1="548" y1="48" x2="548" y2="284"/>
    </svg>`,
    caption: "Resection is the interesting one, because it reverses the usual direction of the work: instead of using your known position to locate new points, you use known points to locate <strong>yourself</strong>. It is the same idea a GNSS receiver uses, six chapters later and with satellites instead of church spires.",
  },

  /* ------------------------------------------- 6.2 LEVELLING TERMS */
  "hb-sv-levelling": {
    label: "One setting of the level, and what every reading is called",
    svg: `<svg viewBox="-8 0 716 300" role="img" aria-label="A levelling instrument set up between a benchmark and a change point, with the backsight taken to the known point, intermediate sights to points along the way, and the foresight taken to the change point, all read on a horizontal line of collimation at a fixed height of instrument.">
      ${hbmk("lv2")}
      <text class="em" x="350" y="24" text-anchor="middle">ONE SET-UP · ONE HEIGHT OF INSTRUMENT · MANY READINGS</text>
      <line class="hi" x1="60" y1="92" x2="640" y2="92"/>
      <text class="ea" x="350" y="82" text-anchor="middle">line of collimation — horizontal, and the same for every reading from here</text>
      <rect class="steel" x="330" y="96" width="34" height="12"/>
      <path class="s" d="M340 108 L330 152 M354 108 L364 152 M347 108 L347 152"/>
      <text class="lb" x="347" y="170" text-anchor="middle">level</text>

      ${[[110, 196, "1.585", "BS", "on the BM — the only reading whose RL you already know"],
         [222, 218, "2.310", "IS", ""],
         [462, 176, "1.020", "IS", ""],
         [596, 236, "2.885", "FS", "on the change point — the last reading from this set-up"]]
        .map(([x, gy, r, k, note]) => `
        <rect class="conc" x="${x - 9}" y="${gy - 108}" width="18" height="108"/>
        <line class="ac" x1="${x}" y1="92" x2="${x}" y2="${gy}" marker-end="url(#lv2-c)" marker-start="url(#lv2-c)"/>
        <text class="ea" x="${x + 13}" y="${(92 + gy) / 2}">${r}</text>
        <text class="em" x="${x}" y="${gy + 20}" text-anchor="middle">${k}</text>`).join("")}
      <path class="thin" d="M60 200 C160 208 230 226 300 224 C400 220 470 182 560 196 C600 202 620 240 640 244"/>
      <text class="lb" x="110" y="272" text-anchor="middle">BM, RL known</text>
      <text class="lb" x="596" y="272" text-anchor="middle">change point</text>
      <text class="lb" x="350" y="292" text-anchor="middle">BS is first from a set-up, FS is last, everything between is an IS — the names are about POSITION, not size</text>
    </svg>`,
    caption: "Students lose marks on this before they touch the arithmetic. A backsight is not \"a sight backwards\" and a foresight is not \"a long one\" — a <strong>BS is simply the first reading after the instrument is set up, and an FS the last one before it moves</strong>. A change point carries both, which is what lets the line of levels walk across the site.",
  },

  /* ------------------------------------------- 6.5 CURVATURE & REFRACTION */
  "hb-sv-curvref": {
    label: "Curvature and refraction, and why one partly cancels the other",
    svg: `<svg viewBox="0 0 712 290" role="img" aria-label="A level line curving with the earth below a truly horizontal line of sight, so a distant staff reads too much by the curvature amount, and the line of sight itself bending downward through the atmosphere by refraction, which returns about one seventh of that error.">
      ${hbmk("cr2")}
      <text class="em" x="350" y="24" text-anchor="middle">TWO ERRORS, OPPOSITE IN SIGN, AND ONE IS SEVEN TIMES THE OTHER</text>
      <path class="s" d="M70 216 A620 620 0 0 1 560 216"/>
      <text class="lb" x="200" y="248">level surface — curves with the earth</text>
      <line class="thin dash" x1="70" y1="216" x2="620" y2="216"/>
      <text class="lb" x="480" y="210">truly horizontal line</text>
      <path class="hi" d="M70 216 C260 222 420 234 600 250"/>
      <text class="ea" x="300" y="236">actual line of sight — bent DOWN by refraction</text>
      <rect class="steel" x="72" y="180" width="8" height="40"/>
      <rect class="conc" x="556" y="150" width="16" height="120"/>
      <line class="ac" x1="590" y1="216" x2="590" y2="248" marker-end="url(#cr2-c)" marker-start="url(#cr2-c)"/>
      <text class="ea" x="600" y="236">net</text>

      <line class="gl" x1="60" y1="262" x2="640" y2="262"/>
      <text class="em" x="60" y="284">curvature  C = 0.0785 d²   ·   refraction  R = 0.0112 d²   ·   combined  0.0673 d²   (d in km, answer in m)</text>
    </svg>`,
    caption: "Curvature makes a distant staff read <em>too much</em>; refraction bends the ray down and gives back about a seventh of it. Both vanish entirely if the backsight and foresight distances are kept equal, which is why <strong>balancing sight lengths is the first rule of good levelling</strong> — it removes collimation error at the same time, for free.",
  },

  /* ------------------------------------------- 7.2 CONTOUR CHARACTERISTICS */
  "hb-sv-contour": {
    label: "Reading ground from contour lines",
    svg: `<svg viewBox="0 0 700 310" role="img" aria-label="Contour patterns for the standard landforms: closed rings with higher values inside for a hill, closed rings with lower values inside for a depression, V shapes pointing uphill for a valley, rounded shapes pointing downhill for a ridge, contours crossing in pairs at an overhanging cliff, and a saddle between two summits.">
      ${hbmk("ct2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE SPACING IS THE SLOPE · THE SHAPE IS THE LANDFORM</text>
      ${[["HILL", 106, 88, 0], ["VALLEY", 282, 88, 1], ["RIDGE", 458, 88, 2],
         ["SADDLE", 106, 214, 3], ["CLIFF", 282, 214, 4], ["DEPRESSION", 458, 214, 5]]
        .map(([t, x, y, k]) => `
        <text class="em" x="${x}" y="${y - 30}" text-anchor="middle">${t}</text>
        ${k === 0 ? [34, 24, 14].map((r, i) => `<ellipse class="${i ? "thin" : "hi"}" cx="${x}" cy="${y + 20}" rx="${r + 12}" ry="${r}" fill="none"/>`).join("")
          + `<text class="lb" x="${x}" y="${y + 24}" text-anchor="middle">120</text>`
          : k === 1 ? [0, 1, 2].map(i => `<path class="${i ? "thin" : "hi"}" d="M${x - 46 - i * 6} ${y - 8 + i * 20} Q${x} ${y + 38 + i * 12} ${x + 46 + i * 6} ${y - 8 + i * 20}" fill="none"/>`).join("")
            + `<line class="ac" x1="${x}" y1="${y + 56}" x2="${x}" y2="${y + 16}" marker-end="url(#ct2-c)"/>`
            + `<text class="lb" x="${x}" y="${y + 74}" text-anchor="middle">V points UPhill</text>`
          : k === 2 ? [0, 1, 2].map(i => `<path class="${i ? "thin" : "hi"}" d="M${x - 46 - i * 6} ${y + 42 - i * 20} Q${x} ${y - 4 - i * 12} ${x + 46 + i * 6} ${y + 42 - i * 20}" fill="none"/>`).join("")
            + `<text class="lb" x="${x}" y="${y + 74}" text-anchor="middle">U points DOWNhill</text>`
          : k === 3 ? `${[[-30, 0], [30, 0]].map(([dx]) => [26, 16].map((r, i) =>
              `<ellipse class="${i ? "thin" : "hi"}" cx="${x + dx}" cy="${y + 18}" rx="${r}" ry="${r - 6}" fill="none"/>`).join("")).join("")}
            <path class="ac dash" d="M${x} ${y - 6} L${x} ${y + 42}"/>
            <text class="lb" x="${x}" y="${y + 66}" text-anchor="middle">a pass between two tops</text>`
          : k === 4 ? `${[0, 1, 2, 3].map(i => `<path class="${i === 1 ? "hi" : "thin"}" d="M${x - 50} ${y + i * 5 + 4} Q${x} ${y + 34} ${x + 50} ${y + i * 5 + 4}" fill="none"/>`).join("")}
            <text class="lb" x="${x}" y="${y + 66}" text-anchor="middle">contours almost touching</text>
            <text class="em" x="${x}" y="${y + 84}" text-anchor="middle">they may CROSS only at an overhang</text>`
          : [34, 24, 14].map((r, i) => `<ellipse class="${i ? "thin" : "hi"}" cx="${x}" cy="${y + 20}" rx="${r + 12}" ry="${r}" fill="none"/>`).join("")
            + `<text class="lb" x="${x}" y="${y + 24}" text-anchor="middle">80</text>`
            + `${[0, 1, 2, 3].map(i => `<line class="thin" x1="${x - 40 + i * 26}" y1="${y - 8}" x2="${x - 40 + i * 26}" y2="${y - 1}"/>`).join("")}`}`).join("")}
      <text class="lb" x="596" y="100">close together</text>
      <text class="em" x="596" y="118">= steep</text>
      <text class="lb" x="596" y="150">far apart</text>
      <text class="em" x="596" y="168">= gentle</text>
      <text class="lb" x="596" y="222">evenly spaced</text>
      <text class="em" x="596" y="240">= uniform slope</text>
      <text class="lb" x="350" y="302" text-anchor="middle">a hill and a depression draw identically — only the figured values, or the hachures, tell them apart</text>
    </svg>`,
    caption: "Every one of these is worth being able to read at a glance, because a contour plan is how a site is handed to you. The pair to be careful with is the last: <strong>a hill and a hollow produce the same rings</strong>, and only the numbers written on them — or the little tick marks pointing downhill — say which you are looking at.",
  },

  /* ------------------------------------------- 8.2 FACE LEFT / FACE RIGHT */
  "hb-sv-faces": {
    label: "Why every angle is measured twice",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A theodolite observing the same target on face left and then transited to face right, with the line of sight error appearing on one side of the true direction on the first face and the same amount on the other side on the second, so that the mean of the two readings is free of the error.">
      ${hbmk("fl2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE MEAN OF TWO FACES KILLS THE INSTRUMENT'S OWN ERRORS</text>

      <text class="em" x="168" y="60" text-anchor="middle">FACE LEFT</text>
      <circle class="hif" cx="168" cy="200" r="7"/>
      <line class="thin dash" x1="168" y1="200" x2="168" y2="86"/>
      <line class="hi" x1="168" y1="200" x2="192" y2="90"/>
      <path class="ac" d="M168 130 A70 70 0 0 1 182 132" fill="none"/>
      <text class="ea" x="196" y="128">+e</text>
      <text class="lb" x="168" y="232" text-anchor="middle">reads a little too far right</text>
      <text class="lb" x="168" y="252" text-anchor="middle">vertical circle on the left</text>

      <line class="gl" x1="348" y1="48" x2="348" y2="272"/>

      <text class="em" x="524" y="60" text-anchor="middle">FACE RIGHT</text>
      <circle class="hif" cx="524" cy="200" r="7"/>
      <line class="thin dash" x1="524" y1="200" x2="524" y2="86"/>
      <line class="hi" x1="524" y1="200" x2="500" y2="90"/>
      <path class="ac" d="M510 132 A70 70 0 0 1 524 130" fill="none"/>
      <text class="ea" x="470" y="128">−e</text>
      <text class="lb" x="524" y="232" text-anchor="middle">the SAME error, now the other way</text>
      <text class="lb" x="524" y="252" text-anchor="middle">telescope transited, circle on the right</text>

      <text class="em" x="350" y="284" text-anchor="middle">mean of the two faces = the true direction — collimation, trunnion and index errors all cancel</text>
    </svg>`,
    caption: "This is the cheapest accuracy in surveying: it costs one extra pointing and removes three separate instrumental errors at once. It works because transiting the telescope <strong>reverses the sign of each error without changing its size</strong> — so the average is what the instrument would have read if it were perfect.",
  },

  /* ------------------------------------------- 8.5 TRAVERSE CLOSING */
  "hb-sv-traverse": {
    label: "Closing error, and what balancing actually does",
    svg: `<svg viewBox="0 0 720 300" role="img" aria-label="A closed traverse plotted from its measured lengths and bearings which fails to return exactly to its starting station, leaving a small closing error, with that error distributed back around the traverse in proportion to the length of each line.">
      ${hbmk("tv2")}
      <text class="em" x="350" y="24" text-anchor="middle">IT SHOULD COME BACK TO A — THE GAP IS YOUR ERROR</text>
      <path class="hi" d="M120 232 L268 84 L400 148 L236 246"/>
      <circle class="hif" cx="120" cy="232" r="7"/>
      <circle class="hif" cx="268" cy="84" r="6"/>
      <circle class="hif" cx="400" cy="148" r="6"/>
      <circle class="hif" cx="236" cy="246" r="6"/>
      <circle class="acf" cx="120" cy="232" r="4"/>
      <text class="em" x="104" y="246">A</text>
      <text class="lb" x="268" y="74" text-anchor="middle">B</text>
      <text class="lb" x="412" y="146">C</text>
      <text class="lb" x="238" y="266" text-anchor="middle">D</text>
      <line class="ac" x1="236" y1="246" x2="120" y2="232" marker-end="url(#tv2-c)"/>
      <path class="thin dash" d="M236 246 L120 232"/>
      <text class="ea" x="176" y="278" text-anchor="middle">closing error e = √(ΣL² + ΣD²)</text>

      <line class="gl" x1="452" y1="44" x2="452" y2="284"/>
      <text class="em" x="480" y="78">ΣLatitudes should be 0</text>
      <text class="em" x="480" y="100">ΣDepartures should be 0</text>
      <text class="lb" x="480" y="130">they are not, so:</text>
      <text class="ea" x="480" y="158">accuracy = perimeter / e</text>
      <text class="lb" x="480" y="178">— quoted as "1 in 2200"</text>
      <text class="em" x="480" y="212">BOWDITCH: share the error out</text>
      <text class="lb" x="480" y="232">in proportion to each line's LENGTH</text>
      <text class="lb" x="480" y="258">(use Transit instead when the angles</text>
      <text class="lb" x="480" y="276">are better than the distances)</text>
    </svg>`,
    caption: "Balancing does not make the survey more accurate — the measurements are what they are. It makes the plot <em>consistent</em>, so the figure closes and coordinates can be computed. The real information is in the ratio: <strong>1 in 2200 tells you how good the work was</strong>, and if that number is poor, no amount of balancing rescues it.",
  },

});
