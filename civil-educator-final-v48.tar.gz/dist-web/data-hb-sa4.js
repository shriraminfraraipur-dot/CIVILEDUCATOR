/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: Structural Analysis, Chapters 6–7
   Force method · Slope-deflection method
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sa"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "sa-6",
      n: 6,
      title: "Force Method — Consistent Deformation",
      hi: "बल विधि — संगत विरूपण",
      blurb: "The first method for indeterminate structures: release the redundants, analyse twice, and restore compatibility. Also where support settlement and temperature finally produce forces.",
      mins: 32,
      sections: [
        {
          n: "6.1", title: "Why a new method is needed", hi: "नई विधि की ज़रूरत क्यों",
          blocks: [
            { k: "p", t: "Everything up to here has been determinate: three equations, three unknowns, done. From §1.11 you already know that most real structures are not. A fixed portal has three redundants, a four-span continuous beam has three, and for all of them equilibrium runs out before the unknowns do." },
            { k: "p", t: "The missing equations have to come from somewhere, and §1.9 said where: compatibility — statements about how the structure is allowed to deform. The force method turns that principle into a procedure, and it needs exactly the deflection tools of Chapter 5 to do it." },
            { k: "note", t: "This is also the reason an indeterminate analysis needs EI and a determinate one does not. Compatibility equations are about displacement, and displacement depends on stiffness. If you ever find yourself solving an indeterminate structure without EI appearing anywhere, something has gone wrong — unless every member has the same EI, in which case it cancels." },
          ],
        },
        {
          n: "6.2", title: "The method, in five steps", hi: "विधि, पाँच चरणों में",
          blocks: [
            { k: "steps", items: [
              "Find Ds (§1.11). That is how many redundants you must choose and how many compatibility equations you will write.",
              "Choose the redundants and remove them. What is left — the <strong>released structure</strong> — must be stable and determinate.",
              "Analyse the released structure under the real loads. Find the displacement at each released point, in the direction of that redundant. Call it δ(load).",
              "Analyse it again under each redundant applied as a unit force, alone. Find the displacement at each released point. Call it δ₁₁, δ₁₂ and so on — the flexibility coefficients.",
              "Write one compatibility equation per redundant and solve. Then superpose to get the real forces.",
            ]},
            { k: "dia", id: "hb-sa-force-method" },
            { k: "eq", expr: "δ(load) + R₁ δ₁₁ + R₂ δ₁₂ + … = Δ(actual)", where: [
              ["δ(load)", "Displacement at the release, on the released structure, under the real loads"],
              ["δᵢⱼ", "Displacement at release i caused by a unit value of redundant j"],
              ["Rᵢ", "The unknown redundant"],
              ["Δ(actual)", "What the real structure allows there — usually zero, but not always"],
            ]},
            { k: "p", t: "The right-hand side deserves attention. It is zero when the real support genuinely prevents movement. It is <em>not</em> zero when the support settles — and that single substitution is how settlement enters the analysis, which is the subject of §6.5." },
          ],
        },
        {
          n: "6.3", title: "Choosing the redundants", hi: "रिडंडेंट चुनना",
          blocks: [
            { k: "p", t: "There is no unique correct choice, and a good choice can halve the work. Two guides." },
            { k: "list", items: [
              "<strong>Pick releases that leave a released structure you can analyse quickly.</strong> On a continuous beam, releasing the interior support moments leaves a row of simply supported spans — every one a standard case. Releasing the vertical reactions instead leaves one long beam, which is also easy. Releasing a mixture usually is not.",
              "<strong>Never release so much that the structure becomes a mechanism.</strong> After every release, check stability by §1.10 — the count is not enough, the arrangement matters.",
            ]},
            { k: "trap", t: "Releasing a support on a frame can leave something that is determinate but <em>unstable</em> — three parallel reactions, say. The arithmetic will not warn you; the flexibility coefficient simply comes out infinite or the equations refuse to solve. Sketch the released structure and check it can still stand." },
          ],
        },
        {
          n: "6.4", title: "Worked example — a two-span continuous beam", hi: "हल किया उदाहरण — दो-स्पैन सतत बीम",
          blocks: [
            { k: "eg", title: "Example 6.1 — two equal spans under uniform load", given: "Continuous beam ABC. Spans AB and BC are each 6 m. All three supports are simple. A uniformly distributed load of 20 kN/m runs over the whole 12 m. EI is constant. Find the support moment at B.", steps: [
              { t: "Degree of static indeterminacy", w: "Reactions: three vertical, plus one horizontal at the hinged end = 4\nDse = r − 3 = 4 − 3 = 1\nNo closed loops → Dsi = 0\n\nDs = 1 — one redundant, one compatibility equation." },
              { t: "Choose the redundant and release", w: "Take the vertical reaction at B as the redundant, R.\nRemoving it leaves a simply supported beam of span 12 m — a standard case.\n\nCompatibility condition: the real support at B does not move, so the net deflection there must be ZERO." },
              { t: "Deflection at B under the real load", w: "Simply supported span L = 12 m, UDL w = 20 kN/m.\nMid-span deflection = 5wL⁴ / 384EI\n\n  = 5 × 20 × 12⁴ / (384 EI)\n  = 5 × 20 × 20736 / (384 EI)\n  = 2 073 600 / (384 EI)\n  = 5400 / EI    ↓ downward" },
              { t: "Deflection at B under a unit upward force there", w: "Central point load on a simply supported span:\nδ₁₁ = P L³ / 48EI  with P = 1\n\n  = 12³ / (48 EI)\n  = 1728 / (48 EI)\n  = 36 / EI    ↑ upward" },
              { t: "Compatibility — net movement at B is zero", w: "5400/EI  −  R × 36/EI  =  0\n\n  R = 5400 / 36\n  R = 150 kN ↑\n\n(EI cancels — as it must, since every member has the same EI.)" },
              { t: "Back to statics", w: "Total load = 20 × 12 = 240 kN\nVA = VC = (240 − 150) / 2 = 45 kN ↑" },
              { t: "Moment at B", w: "Take the left span as a free body, moments about B:\n\n  M(B) = 45 × 6  −  20 × 6 × 3\n       = 270 − 360\n       = − 90 kNm     (hogging)" },
              { t: "Check against the standard result", w: "For two equal spans carrying the same UDL, the support moment is wL²/8:\n  20 × 6² / 8 = 20 × 36 / 8 = 90 kNm ✓" },
            ], ans: "R(B) = 150 kN · VA = VC = 45 kN · M(B) = 90 kNm hogging" },
            { k: "note", t: "Notice how much of the middle support's reaction the continuity has attracted: 150 kN out of 240, against the 120 kN it would take if the two spans were separate simply supported beams. Continuity is not free — it concentrates reaction and moment at the interior support, which is exactly where the top steel has to be." },
          ],
        },
        {
          n: "6.5", title: "Settlement, temperature and lack of fit", hi: "धँसाव, तापमान और लैक ऑफ़ फ़िट",
          blocks: [
            { k: "p", t: "This is the section that explains a large amount of real-world cracking, and the force method makes it easy to see." },
            { k: "dia", id: "hb-sa-settlement" },
            { k: "p", t: "In the compatibility equation of §6.2, replace the zero on the right-hand side with the actual movement. If support B settles by 10 mm, the equation becomes δ(load) − R δ₁₁ = −0.010 m, and R changes. Take away the load entirely and the equation still has a non-zero right-hand side — so the settlement <strong>alone</strong> produces reactions and moments throughout the structure." },
            { k: "list", items: [
              "<strong>Determinate structure</strong> — no redundants, so no compatibility equation, so no forces. It tilts and carries on.",
              "<strong>Indeterminate structure</strong> — every redundant restraint resists the movement, and the resistance is a force.",
            ]},
            { k: "p", t: "Temperature change works the same way. A uniform rise makes the structure want to expand; restrain it and you get axial force. A temperature gradient through the depth makes it want to curve; restrain that and you get moment. Lack of fit — a member fabricated 5 mm too short — is the same equation again with a different number on the right." },
            { k: "trap", t: "The magnitude is often underestimated. Settlement-induced moments in a stiff continuous structure can rival the live load moments, because the moment produced is proportional to EI: <strong>the stiffer you make it, the more it resists the movement and the more it attracts.</strong> That is the opposite of the intuition that stiffer is safer, and it is why differential settlement is treated as a serious limit state rather than a nuisance." },
          ],
        },
        {
          n: "6.6", title: "Flexibility coefficients and Maxwell's reciprocal theorem", hi: "फ्लेक्सिबिलिटी गुणांक और मैक्सवेल प्रमेय",
          blocks: [
            { k: "def", term: "Flexibility coefficient δᵢⱼ", t: "The displacement at point i, in direction i, caused by a unit force applied at point j in direction j." },
            { k: "eq", expr: "Maxwell's reciprocal theorem:   δᵢⱼ = δⱼᵢ", where: [] },
            { k: "p", t: "The deflection at A due to a unit load at B equals the deflection at B due to a unit load at A. It is not obvious and it is exactly true for linear elastic structures, and it halves the work: with three redundants there are nine coefficients but only six distinct ones." },
            { k: "p", t: "It is also a free check. Compute δ₁₂ and δ₂₁ independently and they must agree; if they do not, one of the two analyses is wrong. Betti's theorem is the same idea generalised from unit loads to whole load systems." },
            { k: "note", t: "Arranged as a matrix, the flexibility coefficients form the flexibility matrix, and the compatibility equations become [δ]{R} = {Δ} − {δ(load)}. That matrix statement is Chapter 10 — the force method has been a matrix method all along, just written out longhand." },
          ],
        },
        {
          n: "6.7", title: "Where the force method stops being the right tool", hi: "यह विधि कब सही नहीं रहती",
          blocks: [
            { k: "p", t: "It scales with Ds, and Ds grows fast. A four-span continuous beam has three redundants and a nine-by-nine set of coefficients is already unpleasant by hand; a three-bay three-storey frame has dozens. Two consequences follow." },
            { k: "list", items: [
              "<strong>For beams and frames, the displacement methods win</strong> — Chapters 7 and 8 — because their work scales with Dk instead, and Dk stays small when Ds does not.",
              "<strong>For trusses, the force method stays competitive</strong>, because truss deflections are sums rather than integrals and each coefficient is one tabulated column.",
            ]},
            { k: "p", t: "What the force method never loses is its explanatory value. It is the method that makes clear <em>why</em> an indeterminate structure behaves differently — redundant forces exist to enforce displacement conditions, and anything that changes those conditions changes the forces. Keep that even after you stop using it to calculate." },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "sa-7",
      n: 7,
      title: "Slope-Deflection Method",
      hi: "स्लोप-डिफ्लेक्शन विधि",
      blurb: "The displacement method written out in full: end moments in terms of joint rotations and sway, equations from joint equilibrium, and the extra shear equation that sway frames need.",
      mins: 34,
      sections: [
        {
          n: "7.1", title: "The idea, and the equation", hi: "विचार, और समीकरण",
          blocks: [
            { k: "p", t: "Turn the force method on its head. Instead of asking what forces are redundant, ask what displacements are unknown — the joint rotations and the sway — and write every member end moment in terms of them. The number of unknowns is then the kinematic indeterminacy Dk of §1.12, not Ds." },
            { k: "dia", id: "hb-sa-sd-member" },
            { k: "eq", expr: "MAB = (2EI/L)(2θA + θB − 3Δ/L) + FEM(AB)", where: [
              ["MAB", "Moment at end A of member AB, clockwise positive"],
              ["θA, θB", "Rotations of the joints at A and B, clockwise positive"],
              ["Δ", "Relative transverse displacement of B with respect to A"],
              ["FEM(AB)", "Fixed end moment at A for the load on that span, from the standard table"],
              ["EI, L", "Flexural rigidity and length of the member"],
            ]},
            { k: "p", t: "Read the equation as a superposition and it stops being something to memorise. Lock both ends: the span carries its load and develops its fixed end moments. Now let end A rotate by θA: that alone needs a moment 4EIθA/L at A and carries 2EIθA/L over to B. Let B rotate: same again the other way. Let the ends displace relatively by Δ: that is a chord rotation of Δ/L, which produces −6EIΔ/L² at each end. Add the four contributions and the equation above is what you get." },
            { k: "tbl", id: "tb-sa-fem" },
          ],
        },
        {
          n: "7.2", title: "Where the equations come from", hi: "समीकरण कहाँ से आते हैं",
          blocks: [
            { k: "list", items: [
              "<strong>At every rigid joint</strong> — the member end moments meeting there must sum to zero. One equation per joint that is free to rotate.",
              "<strong>At a simple support or a free end</strong> — the moment there is zero, which eliminates that rotation rather than adding an equation.",
              "<strong>For every independent sway</strong> — one extra equation from horizontal equilibrium of the storey (§7.4).",
            ]},
            { k: "p", t: "Count them before you start: unknowns should equal equations. If they do not, you have either missed a sway equation or forgotten that a simple support gives a condition rather than an unknown." },
            { k: "note", t: "A useful simplification: for a member whose far end is a simple support, you can eliminate that rotation at the outset and use a modified stiffness of 3EI/L instead of 4EI/L. It shortens the algebra and it is the same simplification that reappears in moment distribution in Chapter 8." },
          ],
        },
        {
          n: "7.3", title: "Worked example — continuous beam without sway", hi: "हल किया उदाहरण — बिना स्वे की सतत बीम",
          blocks: [
            { k: "eg", title: "Example 7.1 — the same beam as Example 6.1, by slope-deflection", given: "Continuous beam ABC, spans AB = BC = 6 m, UDL 20 kN/m over both, A and C simply supported, B continuous. EI constant. Find the support moment at B — and check it against the force-method answer.", steps: [
              { t: "Fixed end moments, from the table", w: "For a UDL over a full span, FEM = wL²/12 = 20 × 36 / 12 = 60 kNm.\nWith clockwise positive:\n\n  FEM(AB) = −60      FEM(BA) = +60\n  FEM(BC) = −60      FEM(CB) = +60" },
              { t: "Write the four end moments", w: "Let k = 2EI/L = 2EI/6 = EI/3. No sway, so Δ = 0.\n\n  M(AB) = k(2θA + θB) − 60\n  M(BA) = k(2θB + θA) + 60\n  M(BC) = k(2θB + θC) − 60\n  M(CB) = k(2θC + θB) + 60" },
              { t: "Apply the end conditions", w: "A and C are simple supports, so the moment there is zero:\n\n  M(AB) = 0  →  k(2θA + θB) = 60      … (i)\n  M(CB) = 0  →  k(2θC + θB) = −60     … (ii)" },
              { t: "Joint equilibrium at B", w: "M(BA) + M(BC) = 0\n\n  k(2θB + θA) + 60 + k(2θB + θC) − 60 = 0\n  k(4θB + θA + θC) = 0\n  4θB + θA + θC = 0                    … (iii)" },
              { t: "Solve", w: "From (i):  θA = (60/k − θB) / 2\nFrom (ii): θC = (−60/k − θB) / 2\n\nAdd them:\n  θA + θC = (60/k − θB − 60/k − θB) / 2 = −θB\n\nSubstitute into (iii):\n  4θB − θB = 0\n  θB = 0\n\nThen θA = 30/k  and  θC = −30/k." },
              { t: "Back-substitute for the moment at B", w: "M(BA) = k(2θB + θA) + 60\n      = k(0 + 30/k) + 60\n      = 30 + 60\n      = +90 kNm\n\nM(BC) = k(2θB + θC) − 60\n      = k(−30/k) − 60\n      = −30 − 60\n      = −90 kNm\n\nCheck joint B:  +90 − 90 = 0 ✓" },
              { t: "Compare with Chapter 6", w: "Example 6.1, by the force method, gave a support moment at B of 90 kNm hogging.\nSame beam, different method, same answer. ✓" },
            ], ans: "θB = 0 · M at B = 90 kNm hogging — identical to the force-method result" },
            { k: "note", t: "θB came out exactly zero, and that is not luck. The beam and the loading are symmetric about B, so the joint has no reason to rotate either way. Spotting symmetry before you start can remove an unknown entirely — and finding a symmetric joint rotating is a sign of an error." },
          ],
        },
        {
          n: "7.4", title: "Sway — the extra equation", hi: "स्वे — अतिरिक्त समीकरण",
          blocks: [
            { k: "p", t: "A frame free to translate sideways has one more unknown than joint equilibrium can supply an equation for. The missing equation is horizontal equilibrium of the storey." },
            { k: "dia", id: "hb-sa-sway" },
            { k: "eq", expr: "Σ (column shears) = applied horizontal load        H of a column = (M(top) + M(bottom)) / h", where: [
              ["h", "Height of that column"],
              ["M(top), M(bottom)", "Its end moments, clockwise positive"],
            ]},
            { k: "steps", items: [
              "Decide whether the frame can sway at all. Symmetric frame, symmetric loading, no horizontal load — then Δ = 0 and there is no extra equation.",
              "If it can, take Δ as an extra unknown and include the −3Δ/L term in every member that translates.",
              "Cut a horizontal section through the columns of the storey and write ΣH = 0 in terms of the column end moments.",
              "Solve the joint equations and the shear equation together.",
            ]},
            { k: "trap", t: "Forgetting the sway equation is the most common way this method fails, and it fails silently — you end up with more unknowns than equations and no way forward. Before solving, <strong>count unknowns and count equations</strong>. If unknowns exceed equations by one, you have almost certainly left out a sway." },
          ],
        },
        {
          n: "7.5", title: "Worked example — a sway frame", hi: "हल किया उदाहरण — स्वे फ्रेम",
          blocks: [
            { k: "eg", title: "Example 7.2 — portal frame under horizontal load", given: "Portal ABCD. Columns AB and DC are 4 m high with fixed bases at A and D. Beam BC is 6 m. A horizontal load of 20 kN acts at B. EI constant throughout, and there is no vertical load.", steps: [
              { t: "Unknowns", w: "Bases fixed → θA = θD = 0.\nJoints B and C can rotate → θB, θC.\nThe frame can translate → Δ.\n\nThree unknowns: θB, θC, Δ.\nEquations: joint B, joint C, and the storey shear. Three. ✓" },
              { t: "Use the symmetry of the geometry", w: "Both columns are identical and the frame is geometrically symmetric, while the loading is horizontal. Under sway, both upper joints rotate in the SAME direction:\n\n  θB = θC = θ\n\nThat leaves two unknowns, θ and Δ." },
              { t: "Write the end moments", w: "Columns: 2EI/L = 2EI/4 = EI/2\nBeam:    2EI/L = 2EI/6 = EI/3\nNo load on any member → all FEM = 0.\n\n  M(AB) = (EI/2)(θ − 3Δ/4)\n  M(BA) = (EI/2)(2θ − 3Δ/4)\n  M(BC) = (EI/3)(2θ + θ) = EI θ\n  M(CB) = (EI/3)(2θ + θ) = EI θ\n  M(CD) = (EI/2)(2θ − 3Δ/4)\n  M(DC) = (EI/2)(θ − 3Δ/4)" },
              { t: "Joint equilibrium at B", w: "M(BA) + M(BC) = 0\n\n  (EI/2)(2θ − 3Δ/4) + EIθ = 0\n  EIθ − 3EIΔ/8 + EIθ = 0\n  2EIθ = 3EIΔ/8\n\n  θ = 3Δ / 16                          … (i)" },
              { t: "Storey shear equation", w: "Shear in column AB, taking it to resist the applied load:\n  H = − (M(AB) + M(BA)) / h\n\n  M(AB) + M(BA) = (EI/2)(3θ − 3Δ/2)\n                = (3EI/2)(θ − Δ/2)\n\nSubstitute θ = 3Δ/16:\n  θ − Δ/2 = 3Δ/16 − 8Δ/16 = −5Δ/16\n  M(AB) + M(BA) = (3EI/2)(−5Δ/16) = −15EIΔ/32\n\n  H = (15EIΔ/32) / 4 = 15EIΔ/128  per column\n\nBoth columns: 2 × 15EIΔ/128 = 15EIΔ/64" },
              { t: "Equate to the applied load and solve", w: "  15 EI Δ / 64 = 20\n  EI Δ = 20 × 64 / 15 = 85.33\n\nFrom (i):\n  EI θ = 3 × 85.33 / 16 = 16.0" },
              { t: "Back-substitute for every end moment", w: "M(AB) = (1/2)(16.0 − 3 × 85.33 / 4) = (1/2)(16.0 − 64.0) = −24.0 kNm\nM(BA) = (1/2)(32.0 − 64.0)                              = −16.0 kNm\nM(BC) = 16.0 kNm\nM(CB) = 16.0 kNm\nM(CD) = −16.0 kNm\nM(DC) = −24.0 kNm" },
              { t: "Three checks before accepting it", w: "Joint B:   M(BA) + M(BC) = −16 + 16 = 0 ✓\nJoint C:   M(CB) + M(CD) = +16 − 16 = 0 ✓\nStorey:    H per column = −(−24 − 16)/4 = 10 kN\n           two columns  = 20 kN = the applied load ✓" },
            ], ans: "Δ = 85.33/EI · base moments 24 kNm · top-of-column moments 16 kNm · beam end moments 16 kNm" },
            { k: "note", t: "The base moment came out larger than the top moment — 24 against 16 — which is the usual pattern for a fixed-base portal under lateral load, and it is why the column base and its footing need the heavier detailing. Reading that off the answer is worth as much as the answer." },
          ],
        },
        {
          n: "7.6", title: "Multi-storey frames and the limits of hand work", hi: "बहुमंज़िला फ्रेम और हाथ से हल की सीमा",
          blocks: [
            { k: "p", t: "Each storey that can translate independently adds one sway unknown and one shear equation. Two storeys means two sways; the equations couple, because a column belongs to the storey above and the storey below at once." },
            { k: "p", t: "The algebra grows quickly, and beyond two storeys slope-deflection by hand stops being sensible. That is not a failure of the method — it is the point at which the same equations, arranged as matrices, become Chapter 10, and a computer solves them. Every stiffness-method program in use is doing exactly what §7.1 describes, for every member, simultaneously." },
            { k: "list", items: [
              "<strong>Continuous beams, any number of spans</strong> → fine by hand, and moment distribution (Chapter 8) is usually faster still.",
              "<strong>Single-storey frames, sway or not</strong> → fine by hand.",
              "<strong>Two storeys</strong> → possible, tedious.",
              "<strong>More</strong> → matrix methods.",
            ]},
          ],
        },
      ],
    }

  );
})();
