/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: Structural Analysis handbook, Ch. 6–7
   Force method · Slope-deflection
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 6.2 THE FORCE METHOD */
  "hb-sa-force-method": {
    label: "The force method in three drawings",
    svg: `<svg viewBox="0 0 700 400" role="img" aria-label="Top, a propped cantilever under uniform load. Middle, the released cantilever showing the free end deflection under the load. Bottom, the same cantilever under a unit upward force at the prop, showing the upward deflection. Compatibility sets the sum to zero.">
      ${hbmk("fm")}
      <text class="em" x="60" y="30">1 · THE REAL STRUCTURE</text>
      <line class="s" x1="120" y1="72" x2="500" y2="72"/>
      <line class="s" x1="120" y1="52" x2="120" y2="92"/>
      ${grd(98, 92, 24)}
      ${[0,1,2,3,4,5,6,7,8].map(i=>`<line class="ac" x1="${126+i*44}" y1="42" x2="${126+i*44}" y2="66" marker-end="url(#fm-c)"/>`).join("")}
      <text class="ea" x="310" y="34" text-anchor="middle">w</text>
      <circle class="s" cx="492" cy="84" r="9"/>
      ${grd(478, 96, 30)}
      <text class="lb" x="560" y="76">Ds = 1</text>
      <text class="lb" x="560" y="94">one redundant</text>

      <line class="gl" x1="40" y1="118" x2="660" y2="118"/>

      <text class="em" x="60" y="148">2 · RELEASE IT — remove the prop</text>
      <line class="thin dash" x1="120" y1="188" x2="500" y2="188"/>
      <line class="s" x1="120" y1="168" x2="120" y2="208"/>
      ${grd(98, 208, 24)}
      <path class="hi" d="M120 188 Q310 212 500 252"/>
      ${[0,1,2,3,4,5,6,7,8].map(i=>`<line class="ac" x1="${126+i*44}" y1="158" x2="${126+i*44}" y2="182" marker-end="url(#fm-c)"/>`).join("")}
      <line class="hi" x1="500" y1="192" x2="500" y2="248" marker-start="url(#fm-m)" marker-end="url(#fm-m)"/>
      <text class="em" x="514" y="228">δ(load)</text>
      <text class="lb" x="560" y="252">= wL⁴/8EI ↓</text>

      <line class="gl" x1="40" y1="272" x2="660" y2="272"/>

      <text class="em" x="60" y="300">3 · UNIT REDUNDANT — put R back as 1</text>
      <line class="thin dash" x1="120" y1="342" x2="500" y2="342"/>
      <line class="s" x1="120" y1="322" x2="120" y2="362"/>
      ${grd(98, 362, 24)}
      <path class="ac" d="M120 342 Q310 330 500 306"/>
      <line class="ac" x1="500" y1="376" x2="500" y2="312" marker-end="url(#fm-c)"/>
      <text class="ea" x="512" y="368">1</text>
      <line class="ac" x1="470" y1="342" x2="470" y2="312" marker-start="url(#fm-c)" marker-end="url(#fm-c)"/>
      <text class="ea" x="440" y="326" text-anchor="end">δ₁₁</text>
      <text class="lb" x="560" y="316">= L³/3EI ↑</text>

      <line class="gl" x1="40" y1="382" x2="660" y2="382"/>
      <text class="em" x="350" y="398" text-anchor="middle">Compatibility:  δ(load) − R × δ₁₁ = 0   →   R = δ(load) / δ₁₁ = 3wL/8</text>
    </svg>`,
    caption: "The whole method in one picture. <strong>A redundant is a force whose value is fixed by a displacement condition rather than by equilibrium</strong> — here, the fact that the real prop does not let the end move at all. One redundant, one compatibility equation, every time.",
  },

  /* ---------------------------------------- 6.5 SETTLEMENT */
  "hb-sa-settlement": {
    label: "Why settlement stresses an indeterminate structure and not a determinate one",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Left, two simply supported spans whose middle support settles: they simply tilt and no bending moment is caused. Right, a continuous beam over the same supports: the settlement forces curvature and therefore moment.">
      ${hbmk("st3")}
      <text class="em" x="168" y="28" text-anchor="middle">DETERMINATE — two simple spans</text>
      <line class="thin dash" x1="40" y1="100" x2="300" y2="100"/>
      <path class="s" d="M40 100 L168 124"/>
      <path class="s" d="M168 124 L300 100"/>
      <path class="s" d="M40 100 L30 118 L50 118 Z"/>
      <path class="s" d="M300 100 L290 118 L310 118 Z"/>
      <circle class="s" cx="168" cy="134" r="8"/>
      <line class="hi" x1="168" y1="100" x2="168" y2="124" marker-start="url(#st3-m)" marker-end="url(#st3-m)"/>
      <text class="em" x="182" y="116">δ</text>
      <text class="lb" x="168" y="176" text-anchor="middle">each span just tilts as a rigid line</text>
      <text class="lb" x="168" y="196" text-anchor="middle">no curvature is forced</text>
      <line class="s" x1="40" y1="238" x2="300" y2="238"/>
      <text class="em" x="168" y="262" text-anchor="middle">M = 0 everywhere</text>
      <text class="lb" x="168" y="284" text-anchor="middle">settlement causes NO stress</text>

      <line class="gl" x1="350" y1="16" x2="350" y2="292"/>

      <text class="em" x="528" y="28" text-anchor="middle">INDETERMINATE — one continuous beam</text>
      <line class="thin dash" x1="400" y1="100" x2="660" y2="100"/>
      <path class="s" d="M400 100 Q470 128 528 124 Q590 120 660 100"/>
      <path class="s" d="M400 100 L390 118 L410 118 Z"/>
      <path class="s" d="M660 100 L650 118 L670 118 Z"/>
      <circle class="s" cx="528" cy="134" r="8"/>
      <line class="hi" x1="528" y1="100" x2="528" y2="124" marker-start="url(#st3-m)" marker-end="url(#st3-m)"/>
      <text class="em" x="542" y="116">δ</text>
      <text class="lb" x="528" y="176" text-anchor="middle">the beam must stay continuous,</text>
      <text class="lb" x="528" y="196" text-anchor="middle">so it is forced to curve</text>
      <line class="s" x1="400" y1="238" x2="660" y2="238"/>
      <path class="soft" d="M440 238 Q528 200 616 238 Z"/>
      <path class="hi" d="M440 238 Q528 200 616 238"/>
      <text class="em" x="528" y="262" text-anchor="middle">M ≠ 0</text>
      <text class="lb" x="528" y="284" text-anchor="middle">settlement causes REAL moments</text>
    </svg>`,
    caption: "Curvature is what produces moment, and curvature is what the redundant restraints force. <strong>The same settlement that a determinate structure absorbs without complaint puts real stress into an indeterminate one</strong> — which is why a long continuous deck needs joints and a series of simple spans does not.",
  },

  /* ---------------------------------------- 7.1 THE SD MEMBER */
  "hb-sa-sd-member": {
    label: "A member in the slope-deflection method",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A member AB with its two ends rotating by theta A and theta B and its far end displaced transversely by delta, with the resulting end moments drawn clockwise positive">
      ${hbmk("sd")}
      <text class="lb" x="350" y="26" text-anchor="middle">the three things that can move a member end</text>
      <line class="thin dash" x1="110" y1="140" x2="560" y2="140"/>
      <path class="s" d="M110 140 Q240 100 350 128 Q470 158 560 92"/>
      <circle class="acf" cx="110" cy="140" r="6"/>
      <circle class="acf" cx="560" cy="92" r="6"/>
      <text class="ea" x="96" y="146" text-anchor="end">A</text>
      <text class="ea" x="576" y="98">B</text>

      <path class="ac" d="M110 140 L190 116"/>
      <path class="thin" d="M158 140 A48 48 0 0 0 152 126"/>
      <text class="ea" x="172" y="138">θA</text>
      <path class="ac" d="M480 116 L560 92"/>
      <path class="thin" d="M512 92 A48 48 0 0 0 506 106"/>
      <text class="ea" x="500" y="82">θB</text>

      <line class="hi" x1="560" y1="140" x2="560" y2="98" marker-start="url(#sd-m)" marker-end="url(#sd-m)"/>
      <text class="em" x="576" y="126">Δ</text>
      <line class="thin dash" x1="540" y1="92" x2="600" y2="92"/>

      <path class="hi" d="M92 168 A26 26 0 0 1 116 176" marker-start="url(#sd-m)"/>
      <text class="em" x="84" y="190" text-anchor="end">MAB</text>
      <path class="hi" d="M578 60 A26 26 0 0 1 602 68" marker-start="url(#sd-m)"/>
      <text class="em" x="606" y="54">MBA</text>

      <line class="gl" x1="40" y1="210" x2="660" y2="210"/>
      <text class="em" x="350" y="242" text-anchor="middle">MAB = (2EI/L)(2θA + θB − 3Δ/L) + FEM(AB)</text>
      <text class="em" x="350" y="272" text-anchor="middle">MBA = (2EI/L)(2θB + θA − 3Δ/L) + FEM(BA)</text>
      <text class="lb" x="350" y="302" text-anchor="middle">clockwise positive throughout — moments, rotations and Δ all measured the same way</text>
    </svg>`,
    caption: "Everything in the method is in these two lines. <strong>The unknowns are displacements, not forces</strong> — so the number of them is the kinematic indeterminacy of §1.12, and the equations come from joint equilibrium rather than from compatibility.",
  },

  /* ---------------------------------------- 7.4 SWAY */
  "hb-sa-sway": {
    label: "The sway equation: horizontal equilibrium of a storey",
    svg: `<svg viewBox="0 0 770 340" role="img" aria-label="A portal frame under horizontal load, swaying sideways, with a free body cut through both columns showing the column shears that must together balance the applied horizontal load">
      ${hbmk("sw")}
      <text class="lb" x="170" y="26" text-anchor="middle">THE FRAME SWAYS</text>
      <path class="thin dash" d="M70 80 L70 230 M270 80 L270 230 M70 80 L270 80"/>
      <path class="s" d="M100 74 L300 74"/>
      <path class="s" d="M70 230 Q78 150 100 74"/>
      <path class="s" d="M270 230 Q278 150 300 74"/>
      ${grd(48, 230, 44)} ${grd(248, 230, 44)}
      <line class="ac" x1="52" y1="74" x2="94" y2="74" marker-end="url(#sw-c)"/>
      <text class="ea" x="46" y="78" text-anchor="end">P</text>
      <line class="hi" x1="70" y1="56" x2="100" y2="56" marker-end="url(#sw-m)"/>
      <text class="em" x="118" y="60">Δ</text>
      <text class="lb" x="170" y="262" text-anchor="middle">both joints translate by the same Δ</text>
      <text class="lb" x="170" y="282" text-anchor="middle">because the beam is axially rigid</text>

      <line class="gl" x1="330" y1="16" x2="330" y2="320"/>

      <text class="lb" x="520" y="26" text-anchor="middle">CUT THE COLUMNS AND LOOK AT THE TOP</text>
      <path class="hi dash" d="M380 150 L660 150" style="stroke-dasharray:7 5"/>
      <path class="s" d="M420 74 L620 74"/>
      <path class="s" d="M400 150 Q408 112 420 74"/>
      <path class="s" d="M600 150 Q608 112 620 74"/>
      <line class="ac" x1="372" y1="74" x2="414" y2="74" marker-end="url(#sw-c)"/>
      <text class="ea" x="366" y="78" text-anchor="end">P</text>
      <line class="hi" x1="400" y1="176" x2="400" y2="152" marker-end="url(#sw-m)"/>
      <line class="hi" x1="380" y1="166" x2="414" y2="166" marker-start="url(#sw-m)"/>
      <text class="em" x="400" y="196" text-anchor="middle">H₁</text>
      <line class="hi" x1="580" y1="166" x2="614" y2="166" marker-start="url(#sw-m)"/>
      <text class="em" x="600" y="196" text-anchor="middle">H₂</text>

      <line class="gl" x1="350" y1="222" x2="680" y2="222"/>
      <text class="em" x="516" y="252" text-anchor="middle">ΣH = 0 :   H₁ + H₂ = P</text>
      <text x="516" y="284" text-anchor="middle">H of a column = (M(top) + M(bottom)) / h</text>
      <text class="lb" x="516" y="314" text-anchor="middle">This is the extra equation. Without it the system has one unknown too many.</text>
    </svg>`,
    caption: "A frame free to translate has one more unknown — Δ — than joint equilibrium can supply equations for. <strong>The missing equation is horizontal equilibrium of the storey</strong>, written in terms of the column end moments. Symmetric frame under symmetric load: Δ is zero and this equation disappears.",
  },

});
