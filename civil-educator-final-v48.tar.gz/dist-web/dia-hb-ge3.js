/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: GEOTECHNICAL handbook, Chapters 9–12
   Shear strength · Earth pressure · Bearing capacity · Foundations
   Includes one animated figure — contract as in dia-anim1.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 9.2 MOHR-COULOMB */
  "hb-ge-mohr": {
    label: "Mohr circles and the failure envelope",
    svg: `<svg viewBox="0 0 700 316" role="img" aria-label="Two Mohr circles drawn from triaxial tests at different cell pressures, with a straight line drawn tangent to both, its intercept on the shear stress axis being the cohesion and its slope the angle of internal friction.">
      ${hbmk("mc")}
      <text class="em" x="350" y="24" text-anchor="middle">EACH TEST GIVES A CIRCLE · THE ENVELOPE IS THE SOIL</text>
      <line class="s" x1="80" y1="250" x2="640" y2="250"/>
      <line class="s" x1="80" y1="60" x2="80" y2="250"/>
      <text class="lb" x="72" y="66" text-anchor="end">τ</text>
      <text class="lb" x="638" y="276" text-anchor="end">σ′ →</text>

      <path class="thin" d="M150 250 A72 72 0 0 1 294 250" fill="none"/>
      <path class="thin" d="M257 250 A109 109 0 0 1 475 250" fill="none"/>
      ${[[150, "σ3"], [294, "σ1"], [257, "σ3"], [475, "σ1"]].map(([x, t]) =>
        `<circle class="hif" cx="${x}" cy="250" r="4"/><text class="lb" x="${x}" y="268" text-anchor="middle">${t}</text>`).join("")}
      <path class="hi" d="M80 213 L600 75"/>
      <circle class="hif" cx="80" cy="213" r="5"/>
      <circle class="hif" cx="203" cy="180" r="4"/>
      <circle class="hif" cx="338" cy="145" r="4"/>
      <line class="ac" x1="92" y1="213" x2="92" y2="250" marker-end="url(#mc-c)" marker-start="url(#mc-c)"/>
      <text class="ea" x="102" y="238">c′</text>
      <line class="thin dash" x1="80" y1="213" x2="200" y2="213"/>
      <path class="ac" d="M170 213 A90 90 0 0 0 168 189" fill="none"/>
      <text class="ea" x="178" y="204">φ′</text>
      <text class="em" x="470" y="162">τ = c′ + σ′ tan φ′</text>
      <text class="lb" x="470" y="182">the Mohr–Coulomb envelope</text>

      <text class="lb" x="80" y="292">a circle TOUCHING the line is at failure · a circle below it is safe</text>
      <text class="lb" x="80" y="310">· a circle crossing it is impossible</text>
    </svg>`,
    caption: "A single test gives one circle and one circle has infinitely many tangents, which is why shear strength always needs at least two tests. The envelope is the property of the soil; the circles are just the evidence for it. <strong>The failure plane is at 45° + φ/2 to the major principal plane</strong> — not at 45°, and not where the shear stress is largest.",
  },

  /* ------------------------------------------- 9.3 THE TESTS */
  "hb-ge-sheartests": {
    label: "Four ways of measuring shear strength",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A direct shear box splitting along a forced horizontal plane, a triaxial cell with a cylindrical sample under confining pressure and axial load, an unconfined compression test with no confinement at all, and a vane shear test rotating blades in soft clay in the ground.">
      ${hbmk("sh2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE INSTRUMENT DECIDES WHICH STRENGTH YOU GET</text>
      ${[["DIRECT SHEAR", 106, 0], ["TRIAXIAL", 282, 1], ["UNCONFINED", 452, 2], ["VANE", 616, 3]]
        .map(([t, x, k]) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        ${k === 0 ? `<rect class="conc" x="${x - 46}" y="96" width="92" height="34"/>
            <rect class="conc" x="${x - 38}" y="130" width="92" height="34"/>
            <line class="hi" x1="${x - 46}" y1="130" x2="${x + 54}" y2="130"/>
            <line class="ac" x1="${x - 70}" y1="113" x2="${x - 50}" y2="113" marker-end="url(#sh2-c)"/>
            <line class="ac" x1="${x + 58}" y1="147" x2="${x + 78}" y2="147" marker-end="url(#sh2-c)"/>
            <line class="ac" x1="${x}" y1="70" x2="${x}" y2="92" marker-end="url(#sh2-c)"/>
            <text class="lb" x="${x}" y="196" text-anchor="middle">the plane is FORCED</text>
            <text class="lb" x="${x}" y="214" text-anchor="middle">on the sample</text>
            <text class="lb" x="${x}" y="238" text-anchor="middle">simple; drainage</text>
            <text class="lb" x="${x}" y="256" text-anchor="middle">hard to control</text>`
          : k === 1 ? `<rect class="softa" x="${x - 52}" y="84" width="104" height="96"/>
            <rect class="conc" x="${x - 22}" y="96" width="44" height="72"/>
            ${[0,1,2].map(i=>`<line class="ac" x1="${x - 46}" y1="${112+i*24}" x2="${x - 28}" y2="${112+i*24}" marker-end="url(#sh2-c)"/>
              <line class="ac" x1="${x + 46}" y1="${112+i*24}" x2="${x + 28}" y2="${112+i*24}" marker-end="url(#sh2-c)"/>`).join("")}
            <line class="hi" x1="${x}" y1="64" x2="${x}" y2="92" marker-end="url(#sh2-m)"/>
            <path class="hi" d="M${x - 18} 168 L${x + 20} 100"/>
            <text class="lb" x="${x}" y="196" text-anchor="middle">the sample CHOOSES</text>
            <text class="lb" x="${x}" y="214" text-anchor="middle">its own failure plane</text>
            <text class="em" x="${x}" y="238" text-anchor="middle">drainage fully controlled</text>
            <text class="em" x="${x}" y="256" text-anchor="middle">— UU, CU, CD</text>`
          : k === 2 ? `<rect class="conc" x="${x - 22}" y="96" width="44" height="72"/>
            <line class="hi" x1="${x}" y1="64" x2="${x}" y2="92" marker-end="url(#sh2-m)"/>
            <path class="hi" d="M${x - 18} 164 L${x + 18} 102"/>
            <text class="lb" x="${x}" y="196" text-anchor="middle">σ₃ = 0 — a triaxial</text>
            <text class="lb" x="${x}" y="214" text-anchor="middle">test with no cell</text>
            <text class="em" x="${x}" y="238" text-anchor="middle">cu = qu / 2</text>
            <text class="lb" x="${x}" y="256" text-anchor="middle">saturated clay only</text>`
          : `<line class="s" x1="${x}" y1="66" x2="${x}" y2="130"/>
            <path class="steel" d="M${x - 16} 130 L${x + 16} 130 L${x + 16} 172 L${x - 16} 172 Z"/>
            <line class="s" x1="${x}" y1="126" x2="${x}" y2="176"/>
            <path class="ac" d="M${x - 24} 90 A24 24 0 0 1 ${x + 24} 90" fill="none" marker-end="url(#sh2-c)"/>
            <text class="lb" x="${x}" y="196" text-anchor="middle">IN THE GROUND —</text>
            <text class="lb" x="${x}" y="214" text-anchor="middle">nothing is sampled</text>
            <text class="em" x="${x}" y="238" text-anchor="middle">soft sensitive clay,</text>
            <text class="em" x="${x}" y="256" text-anchor="middle">where sampling ruins it</text>`}`).join("")}
      <line class="gl" x1="194" y1="46" x2="194" y2="270"/>
      <line class="gl" x1="368" y1="46" x2="368" y2="270"/>
      <line class="gl" x1="536" y1="46" x2="536" y2="270"/>
      <text class="lb" x="350" y="292" text-anchor="middle">the vane exists because the act of taking a sample of soft clay destroys the thing you wanted to measure</text>
    </svg>`,
    caption: "The choice is really about <em>drainage</em>, because that is what decides whether you measure total or effective stress parameters. A triaxial test can be run unconsolidated-undrained, consolidated-undrained or consolidated-drained, and the same clay will hand you three different answers — all of them correct, for three different field situations.",
  },

  /* ------------------------------------------- 10.4 RANKINE PRESSURE */
  "hb-ge-rankine": {
    label: "The pressure diagram on a retaining wall",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A retaining wall with a triangular active earth pressure diagram from the backfill, a rectangular addition from a uniform surcharge, and where a water table is present a hydrostatic triangle added on top of a reduced soil pressure computed with submerged unit weight.">
      ${hbmk("rk")}
      <text class="em" x="350" y="24" text-anchor="middle">TRIANGLE FROM THE SOIL · RECTANGLE FROM A SURCHARGE</text>
      <rect class="conc" x="150" y="66" width="30" height="180"/>
      <rect class="conc" x="124" y="246" width="120" height="22"/>
      <path class="soft" d="M180 66 L330 66 L330 246 L180 246 Z" opacity="0.3"/>
      ${[0,1,2,3,4].map(i=>`<line class="ac" x1="${200+i*30}" y1="44" x2="${200+i*30}" y2="62" marker-end="url(#rk-c)"/>`).join("")}
      <text class="ea" x="260" y="38" text-anchor="middle">surcharge q</text>

      <rect class="softa" x="120" y="66" width="30" height="180"/>
      <path class="soft-b" d="M120 66 L120 246 L60 246 Z"/>
      <text class="lb" x="135" y="60" text-anchor="middle">Ka q</text>
      <text class="lb" x="78" y="262">Ka γ H</text>
      <line class="thin dash" x1="52" y1="186" x2="150" y2="186"/>
      <text class="lb" x="48" y="190" text-anchor="end">H/3</text>
      <line class="ac" x1="246" y1="186" x2="190" y2="186" marker-end="url(#rk-c)"/>
      <text class="em" x="254" y="190">Pa</text>

      <line class="gl" x1="368" y1="44" x2="368" y2="288"/>
      <text class="em" x="392" y="76">Ka = (1 − sinφ)/(1 + sinφ) = tan²(45 − φ/2)</text>
      <text class="lb" x="392" y="102">Kp = 1/Ka = tan²(45 + φ/2)</text>
      <line class="thin dash" x1="392" y1="118" x2="672" y2="118"/>
      <text class="ea" x="392" y="146">from the soil:   Pa = ½ Ka γ H²   at H/3</text>
      <text class="ea" x="392" y="172">from a surcharge:  Pq = Ka q H   at H/2</text>
      <text class="em" x="392" y="206">and if there is water:</text>
      <text class="lb" x="392" y="230">use γ′ for the soil below the water table,</text>
      <text class="lb" x="392" y="250">then ADD the full hydrostatic ½ γw h²</text>
      <text class="em" x="392" y="280">— water gets no K: it pushes equally.</text>
    </svg>`,
    caption: "The last line is where most wall calculations go wrong. Soil arches and transmits only a fraction K of its vertical stress sideways; <strong>water does not arch and has no K at all</strong>. Applying Ka to the water pressure under-estimates the thrust by a factor of three for a typical φ, and drainage behind a wall exists precisely so that term never appears.",
  },

  /* ------------------------------------------- 11.2 BEARING FAILURE */
  "hb-ge-bearing": {
    label: "How a footing fails, and the three terms that resist it",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A strip footing pushing a wedge of soil downward which forces two shear zones sideways and lifts passive wedges either side, with the three contributions to bearing capacity identified as cohesion, surcharge from the soil above founding level and the weight of the soil within the failure zone.">
      ${hbmk("bc2")}
      <text class="em" x="350" y="24" text-anchor="middle">THE FOOTING GOES DOWN ONLY IF THE SOIL BESIDE IT COMES UP</text>
      <line class="s" x1="50" y1="94" x2="650" y2="94"/>
      <rect class="conc" x="288" y="94" width="124" height="22"/>
      <line class="ac" x1="350" y1="60" x2="350" y2="88" marker-end="url(#bc2-c)"/>
      <text class="ea" x="350" y="52" text-anchor="middle">qu</text>
      <line class="hi" x1="288" y1="116" x2="350" y2="180"/>
      <line class="hi" x1="412" y1="116" x2="350" y2="180"/>
      <path class="soft-b" d="M288 116 L412 116 L350 180 Z"/>
      <text class="lb" x="350" y="146" text-anchor="middle">wedge I</text>
      <path class="hi" d="M350 180 C300 190 250 170 214 130"/>
      <path class="hi" d="M350 180 C400 190 450 170 486 130"/>
      <path class="hi" d="M214 130 L140 94"/>
      <path class="hi" d="M486 130 L560 94"/>
      <path class="softa" d="M214 130 L140 94 L214 94 Z"/>
      <path class="softa" d="M486 130 L560 94 L486 94 Z"/>
      <text class="lb" x="196" y="140">radial shear zone</text>
      <text class="ea" x="150" y="86" text-anchor="middle">passive</text>
      <text class="ea" x="550" y="86" text-anchor="middle">passive</text>
      <line class="ac" x1="70" y1="94" x2="70" y2="116"/>
      <line class="ac" x1="62" y1="94" x2="78" y2="94"/>
      <line class="ac" x1="62" y1="116" x2="78" y2="116"/>
      <text class="ea" x="84" y="112">Df</text>

      <text class="em" x="60" y="222">qu  =  c Nc   +   γ Df Nq   +   0.5 γ B Nγ</text>
      <text class="lb" x="60" y="250">cohesion of the soil</text>
      <text class="lb" x="278" y="250">the weight of soil ABOVE</text>
      <text class="lb" x="278" y="268">founding level — surcharge</text>
      <text class="lb" x="500" y="250">the weight of soil WITHIN</text>
      <text class="lb" x="500" y="268">the failure zone</text>
      <text class="em" x="60" y="292">all three N factors depend on φ alone</text>
    </svg>`,
    caption: "Reading the three terms physically makes the formula memorable. The second explains why <strong>simply founding deeper increases capacity</strong> — there is more soil to lift. The third contains B, which is why a wider footing has a higher <em>ultimate</em> capacity even though it may settle more. And in a saturated clay under undrained conditions φ = 0, so Nq = 1, Nγ = 0, and the whole thing collapses to about 5.14c + γDf.",
  },

  /* ------------------------------------------- 12.2 PILES */
  "hb-ge-piles": {
    label: "Where a pile's capacity comes from",
    svg: `<svg viewBox="0 0 700 316" role="img" aria-label="An end bearing pile carried through soft soil to rock, a friction pile developing its capacity along the shaft in deep soft soil with no hard stratum, and a pile group whose block failure may govern instead of the sum of the individual piles.">
      ${hbmk("pi")}
      <text class="em" x="350" y="24" text-anchor="middle">SKIN FRICTION ALONG THE SIDE · END BEARING AT THE TOE</text>
      ${[["END BEARING", 118, 0], ["FRICTION", 320, 1], ["GROUP", 546, 2]].map(([t, x, k]) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <line class="s" x1="${x - 78}" y1="76" x2="${x + 78}" y2="76"/>
        ${k === 2
          ? `${[-44, 0, 44].map(dx => `<rect class="steel" x="${x + dx - 8}" y="76" width="16" height="150"/>`).join("")}
             <rect class="conc" x="${x - 62}" y="64" width="124" height="12"/>
             <path class="hi dash" d="M${x - 60} 76 L${x - 60} 240 L${x + 60} 240 L${x + 60} 76"/>
             <text class="lb" x="${x}" y="264" text-anchor="middle">the whole BLOCK may fail</text>
             <text class="lb" x="${x}" y="282" text-anchor="middle">as one — take the smaller of</text>
             <text class="em" x="${x}" y="302" text-anchor="middle">block   vs   Σ individual</text>`
          : `<rect class="steel" x="${x - 9}" y="76" width="18" height="${k ? 168 : 150}"/>
             ${k === 0
               ? `<rect class="conc" x="${x - 70}" y="226" width="140" height="40"/>
                  <text class="lb" x="${x}" y="252" text-anchor="middle">rock / dense stratum</text>
                  <line class="hi" x1="${x}" y1="240" x2="${x}" y2="220" marker-end="url(#pi-m)"/>
                  <text class="em" x="${x + 16}" y="214">Qp</text>
                  <text class="lb" x="${x}" y="286" text-anchor="middle">most of the load goes</text>
                  <text class="lb" x="${x}" y="304" text-anchor="middle">straight to the toe</text>`
               : `${[0,1,2,3,4].map(i=>`<line class="ac" x1="${x - 20}" y1="${118+i*30}" x2="${x - 20}" y2="${98+i*30}" marker-end="url(#pi-c)"/>
                    <line class="ac" x1="${x + 20}" y1="${118+i*30}" x2="${x + 20}" y2="${98+i*30}" marker-end="url(#pi-c)"/>`).join("")}
                  <text class="ea" x="${x + 34}" y="164">Qs</text>
                  <text class="lb" x="${x}" y="272" text-anchor="middle">no hard layer within reach —</text>
                  <text class="lb" x="${x}" y="290" text-anchor="middle">the shaft carries it all</text>
                  <text class="em" x="${x}" y="310" text-anchor="middle">Qs = α cu × perimeter × L</text>`}`}`).join("")}
      <line class="gl" x1="220" y1="46" x2="220" y2="300"/>
      <line class="gl" x1="428" y1="46" x2="428" y2="300"/>
    </svg>`,
    caption: "Real piles are almost always both, and the split is rarely what the name suggests. In the worked example of §12.3 the shaft carries 87% of the load and the toe only 13% — so calling it an \"end bearing\" pile because it happens to reach a firm layer would have sized it on the smaller of the two contributions.",
  },

  /* ============================================== ANIMATED ============== */

  /* ------------------------------------------- 10.2 WALL MOVEMENT */
  "an-ge-earthpressure": {
    label: "Earth pressure depends on which way the wall moves",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three identical walls: one held rigidly at rest carrying the at rest pressure, one allowed to move away from the backfill so the soil mobilises its own shear strength and the pressure falls to the active value, and one pushed into the backfill so the pressure rises to the much larger passive value.">
      ${hbmk("ep2")}
      <text class="em" x="350" y="24" text-anchor="middle">SAME SOIL · SAME WALL · THREE COMPLETELY DIFFERENT PRESSURES</text>
      ${[["AT REST", 118, 0, "K₀ ≈ 1 − sin φ", "≈ 0.50", "no movement at all —", "a basement wall, propped"],
         ["ACTIVE", 350, -10, "Ka = tan²(45 − φ/2)", "= 0.33", "wall moves AWAY —", "the soil helps hold itself up"],
         ["PASSIVE", 582, 14, "Kp = tan²(45 + φ/2)", "= 3.00", "wall pushes IN —", "the soil resists, and hard"]]
        .map(([t, x, amp, k, v, n1, n2], i) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        <rect class="conc an-sway" style="--amp:${amp};--dur:4s" x="${x - 10}" y="78" width="20" height="120"/>
        <path class="soft" d="M${x + 10} 78 L${x + 100} 78 L${x + 100} 198 L${x + 10} 198 Z" opacity="0.3"/>
        <line class="s" x1="${x - 90}" y1="198" x2="${x + 102}" y2="198"/>
        <path class="${i === 2 ? "soft-b" : "softa"} an-sway" style="--amp:${amp};--dur:4s"
              d="M${x - 10} 78 L${x - 10 - (i === 2 ? 72 : i === 1 ? 8 : 12)} 198 L${x - 10} 198 Z"/>
        ${amp ? `<line class="ac an-sway" style="--amp:${amp};--dur:4s" x1="${x - 20}" y1="132" x2="${x - 20 + (amp > 0 ? 18 : -18)}" y2="132" marker-end="url(#ep2-c)"/>` : ""}
        <text class="ea" x="${x}" y="226" text-anchor="middle">${k}</text>
        <text class="em" x="${x}" y="248" text-anchor="middle">${v}</text>
        <text class="lb" x="${x}" y="272" text-anchor="middle">${n1}</text>
        ${i === 2 ? `<text class="ea" x="${x}" y="208" text-anchor="middle">9 × the active triangle</text>` : ""}
        <text class="lb" x="${x}" y="290" text-anchor="middle">${n2}</text>`).join("")}
      <line class="gl" x1="234" y1="46" x2="234" y2="296"/>
      <line class="gl" x1="466" y1="46" x2="466" y2="296"/>
    </svg>`,
    caption: "Watch the width of each pressure triangle as the wall moves. Passive is <strong>nine times</strong> active for φ = 30°, and that ratio is why a sheet pile gets its support from a modest embedded depth. The catch is movement: active needs only a few millimetres to develop, while full passive needs the wall to push in by several per cent of its height — far more than most structures can tolerate, which is why passive resistance is usually taken with a large factor of safety or ignored altogether.",
  },

});
