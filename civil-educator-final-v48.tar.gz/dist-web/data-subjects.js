/* ============================================================
   CIVIL EDUCATOR — subject map
   ------------------------------------------------------------
   The library is organised by IS code. A student's head is
   organised by subject and unit: "Concrete Technology, Unit 3,
   test on Monday". This file is the translation layer between
   the two.

   Nothing here is new technical content. Every entry is an id
   that already exists in data-topics*.js, data-materials*.js,
   data-extra*.js, calc-meta.js or the tables/formulas lists, so
   this file introduces no new claims and no new clause numbers.
   If an id is wrong the app simply skips it — see the validator
   note at the bottom.

   Honesty rule: units are listed as the syllabus actually runs,
   not as our coverage happens to fall. A unit we have nothing
   for still appears, marked as not covered, because a student
   deserves to know what the app does not have before they rely
   on it — and because it tells us what to write next.

   Shape:
     { id, name, hi, icon, sem, also, blurb,
       units: [{ t, hi, topics[], mats[], calcs[], ex[],
                 tables[], formulas[], checks[], cmps[] }] }
   Every array is optional.
   ============================================================ */

window.DB = window.DB || {};

DB.subjects = [
  /* ------------------------------------------------ 1st / 2nd year */
  {
    id: "building-materials",
    name: "Building Materials",
    hi: "भवन निर्माण सामग्री",
    icon: "🧱",
    sem: "1st year · 2nd sem",
    also: "Building Materials & Construction · Engineering Materials",
    blurb: "Har material kya hai, kaise banta hai, kaise test hota hai, site par kaise pehchane — ab poora 8-chapter handbook bhi.",
    hb: "bm",
    units: [
      {
        t: "What makes a material fit to build with", hi: "सामग्री कब निर्माण योग्य होती है", ch: 1,
      },
      {
        t: "Stone", hi: "पत्थर", ch: 2,
        mats: ["mat-stone"],
      },
      {
        t: "Bricks and blocks", hi: "ईंट और ब्लॉक", ch: 3,
        topics: ["t-brick"], mats: ["mat-brick"], tables: ["tb-brick"],
      },
      {
        t: "Cement", hi: "सीमेंट", ch: 4,
        topics: ["t-cementtests"], mats: ["mat-cement"],
      },
      {
        t: "Lime, pozzolana and gypsum", hi: "चूना, पोज़ोलाना और जिप्सम", ch: 5,
        mats: ["mat-lime", "mat-flyash", "mat-gypsum"],
      },
      {
        t: "Aggregate, sand, water and admixtures", hi: "गिट्टी, रेत, पानी और एडमिक्सचर", ch: 6,
        topics: ["t-aggtests"], mats: ["mat-aggregate", "mat-water", "mat-admixture"],
      },
      {
        t: "Timber and metals", hi: "लकड़ी और धातुएँ", ch: 7,
        topics: ["t-800-materials"], mats: ["mat-timber", "mat-steel", "mat-structsteel", "mat-aluminium"],
        tables: ["tb-800-steel", "tb-steelwt"],
      },
      {
        t: "Mortar, plaster and finishes", hi: "मसाला, प्लास्टर और फिनिश", ch: 8,
        topics: ["t-mortar", "t-nominalmix", "t-plaster"],
        mats: ["mat-mortar", "mat-concrete", "mat-soil", "mat-bitumen", "mat-paint", "mat-glass", "mat-tiles", "mat-waterproofing", "mat-pipes"],
        tables: ["tb-nominalmix"],
      },
    ],
  },

  {
    id: "concrete-tech",
    name: "Concrete Technology",
    hi: "कंक्रीट प्रौद्योगिकी",
    icon: "🧊",
    sem: "2nd year · 3rd–4th sem",
    also: "Concrete Technology & Practice",
    blurb: "Cement aur pani se cube test tak — ab poora 8-chapter handbook bhi, har value ka code reference ke saath.",
    hb: "ct",
    units: [
      {
        t: "What concrete is — the water-cement ratio", hi: "कंक्रीट क्या है — जल-सीमेंट अनुपात", ch: 1,
      },
      {
        t: "Cement — types, tests and storage", hi: "सीमेंट — प्रकार, परीक्षण और भंडारण", ch: 2,
        topics: ["t-cementtests"], mats: ["mat-cement", "mat-flyash", "mat-lime"],
      },
      {
        t: "Aggregates, water and admixtures", hi: "गिट्टी, पानी और एडमिक्सचर", ch: 3,
        topics: ["t-aggtests", "t-chloride"], mats: ["mat-aggregate", "mat-water", "mat-admixture"],
      },
      {
        t: "Fresh concrete — workability, placing, compaction", hi: "ताज़ा कंक्रीट — वर्केबिलिटी, प्लेसिंग, संघनन", ch: 4,
        topics: ["t-workability", "t-batching", "t-placing", "t-consjoint", "t-specialconcreting"],
        calcs: ["concrete-qty", "pcc"], checks: ["cl-concrete-receipt"],
      },
      {
        t: "Hardened concrete — strength, Ec, shrinkage and creep", hi: "कठोर कंक्रीट — शक्ति, Ec, संकुचन और क्रीप", ch: 5,
        topics: ["t-grades", "t-ec", "t-shrinkcreep"], tables: ["tb-grades", "tb-creep"],
        formulas: ["f-ec", "f-concrete"], mats: ["mat-concrete"],
      },
      {
        t: "Mix proportioning — nominal and design mix", hi: "मिक्स अनुपात — नॉमिनल और डिज़ाइन मिक्स", ch: 6,
        topics: ["t-nominalmix"], tables: ["tb-nominalmix"],
        calcs: ["concrete-qty", "slab-qty", "beam-qty", "column-qty", "footing-qty"],
      },
      {
        t: "Durability, exposure and cover", hi: "टिकाऊपन, एक्सपोज़र और कवर", ch: 7,
        topics: ["t-exposure", "t-cover", "t-chloride"], tables: ["tb-exposure", "tb-cover"],
      },
      {
        t: "Curing, formwork and quality control", hi: "क्योरिंग, फॉर्मवर्क और गुणवत्ता नियंत्रण", ch: 8,
        topics: ["t-curing", "t-formwork", "t-acceptance", "t-cubetest", "t-ndt", "t-assessment"],
        tables: ["tb-formwork", "tb-sampling"], checks: ["cl-preconcrete"],
      },
    ],
  },

  {
    id: "masonry-construction",
    name: "Building Construction",
    hi: "भवन निर्माण",
    icon: "🏗",
    sem: "2nd year",
    also: "Construction Technology · Masonry Structures",
    blurb: "Chinai, bond, load-bearing wall, plaster aur bhukamp band — ab poora 8-chapter handbook bhi, site par roz kaam aane wali cheezein.",
    hb: "bc",
    units: [
      {
        t: "A building as an assembly of elements", hi: "तत्वों की संरचना के रूप में भवन", ch: 1,
      },
      {
        t: "Masonry units and mortar", hi: "चिनाई इकाइयाँ और मसाला", ch: 2,
        topics: ["t-brick", "t-mortar"], mats: ["mat-brick", "mat-stone", "mat-mortar", "mat-lime"],
        tables: ["tb-brick"], calcs: ["brickwork"],
      },
      {
        t: "Brickwork practice and bonds", hi: "चिनाई की विधि और बॉन्ड", ch: 3,
        topics: ["t-brickwork"], cmps: ["cmp-english-flemish"], checks: ["cl-brickwork"],
      },
      {
        t: "Load bearing masonry design", hi: "लोड बेयरिंग चिनाई डिज़ाइन", ch: 4,
        topics: ["t-masonry"],
      },
      {
        t: "Plastering and finishes", hi: "प्लास्टर और फिनिशिंग", ch: 5,
        topics: ["t-plaster"], calcs: ["plaster"],
        mats: ["mat-paint", "mat-tiles", "mat-gypsum", "mat-waterproofing"],
      },
      {
        t: "Seismic bands in masonry buildings", hi: "चिनाई भवनों में भूकंप बैंड", ch: 6,
        topics: ["t-seismicband"],
      },
      {
        t: "Doors, windows and roofs", hi: "दरवाज़े, खिड़कियाँ और छत", ch: 7,
        mats: ["mat-timber", "mat-glass", "mat-aluminium"],
      },
      {
        t: "Stairs", hi: "सीढ़ियाँ", ch: 8,
        topics: ["t-stairs"],
      },
    ],
  },

  {
    id: "struct-analysis",
    name: "Structural Analysis",
    hi: "संरचनात्मक विश्लेषण",
    icon: "📐",
    sem: "2nd–3rd year · 4th–5th sem",
    also: "Theory of Structures · Structural Analysis I & II",
    blurb: "Poora subject ek handbook ki tarah likha hai — 12 chapters, shuru se aakhir tak, har method derive kiya gaya, har example ka hisaab likha. Har unit apne chapter se juda hai.",
    units: [
      {
        t: "Basic concepts, determinacy and stability", hi: "मूल अवधारणाएँ, निश्चितता और स्थिरता", ch: 1,
        topics: ["t-sa-intro", "t-sa-supports", "t-sa-equilibrium", "t-sa-elastic", "t-sa-static-ind", "t-sa-kinematic-ind"],
        tables: ["tb-sa-ind"], formulas: ["f-sa-ds", "f-sa-dk"],
      },
      { t: "Trusses", hi: "ट्रस", ch: 2, topics: ["t-sa-truss"] },
      { t: "Shear force and bending moment", hi: "अपरूपण बल और बंकन आघूर्ण", ch: 3 },
      { t: "Influence lines and rolling loads", hi: "प्रभाव रेखा और चलायमान भार", ch: 4, topics: ["t-sa-ild"] },
      { t: "Deflections — strain energy and unit load method", hi: "विक्षेपण — विकृति ऊर्जा और यूनिट लोड विधि", ch: 5, topics: ["t-sa-unitload"] },
      { t: "Force method — consistent deformation", hi: "बल विधि — संगत विरूपण", ch: 6, topics: ["t-sa-consistent"] },
      {
        t: "Slope-deflection method", hi: "स्लोप-डिफ्लेक्शन विधि", ch: 7,
        topics: ["t-sa-slopedefl"], tables: ["tb-sa-fem"], formulas: ["f-sa-slopedefl"],
      },
      {
        t: "Moment distribution method", hi: "मोमेंट डिस्ट्रिब्यूशन विधि", ch: 8,
        topics: ["t-sa-momentdist"], tables: ["tb-sa-stiff", "tb-sa-fem"], formulas: ["f-sa-df"],
      },
      { t: "Arches and cables", hi: "मेहराब और केबल", ch: 9, topics: ["t-sa-arch"], formulas: ["f-sa-arch"] },
      { t: "Matrix methods — flexibility and stiffness", hi: "मैट्रिक्स विधियाँ — फ्लेक्सिबिलिटी और स्टिफनेस", ch: 10 },
      { t: "Plastic analysis", hi: "प्लास्टिक विश्लेषण", ch: 11 },
      { t: "Structural dynamics — single degree of freedom", hi: "संरचनात्मक गतिकी — एकल स्वतंत्रता कोटि", ch: 12 },
    ],
  },

  {
    id: "rcc",
    name: "Design of RCC Structures",
    hi: "आर.सी.सी. संरचना डिज़ाइन",
    icon: "🏢",
    sem: "3rd year · 5th sem",
    also: "RCC Design · Design of Concrete Structures · Limit State Design",
    blurb: "IS 456 ka poora design course — har unit me theory, calculator aur solved numerical saath me.",
    units: [
      {
        t: "Design philosophy and loads", hi: "डिज़ाइन दर्शन और भार", ch: 1,
        topics: ["t-designmethod", "t-limitstate", "t-wsm", "t-stability", "t-deadload", "t-liveload", "t-windload", "t-loadcomb"],
        tables: ["tb-loadfactors", "tb-unitweight", "tb-wsm"], formulas: ["f-wind"], cmps: ["cmp-wsm-lsm"],
      },
      {
        t: "Materials for design", hi: "डिज़ाइन की सामग्री", ch: 2,
        topics: ["t-grades", "t-ec", "t-shrinkcreep", "t-exposure", "t-cover"],
        tables: ["tb-grades", "tb-creep", "tb-exposure", "tb-cover"],
      },
      {
        t: "Flexure — singly reinforced sections", hi: "बंकन — सिंगली रीइन्फोर्स्ड", ch: 3,
        topics: ["t-mulim", "t-momentcoeff", "t-redistribution", "t-effspan"],
        tables: ["tb-momentcoeff"], formulas: ["f-mulim"], calcs: ["mu-lim", "ast-singly"],
        ex: ["ex-beam-singly"],
      },
      {
        t: "Doubly reinforced and flanged sections", hi: "डबली रीइन्फोर्स्ड और T-बीम", ch: 4,
        ex: ["ex-beam-doubly", "ex-tbeam"],
      },
      {
        t: "Shear, bond and anchorage", hi: "अपरूपण, बॉन्ड और एंकरेज", ch: 5,
        topics: ["t-shear", "t-minshear", "t-enhancedshear", "t-ld", "t-lap", "t-anchorage"],
        tables: ["tb-taubd", "tb-ld", "tb-taucmax"], formulas: ["f-ld", "f-tauc"],
        calcs: ["tauc-calc", "dev-length", "lap-length"],
        ex: ["ex-shear", "ex-devlength", "ex-lap"],
      },
      {
        t: "Torsion", hi: "ऐंठन (टॉर्शन)", ch: 6,
        topics: ["t-torsion"], formulas: ["f-torsion"], ex: ["ex-torsion"],
      },
      {
        t: "Slabs — one-way, two-way and flat slabs", hi: "स्लैब — वन-वे, टू-वे और फ्लैट स्लैब", ch: 7,
        topics: ["t-slabtypes", "t-flatslab", "t-minmax-slab"],
        calcs: ["bar-spacing", "slab-qty", "bbs-slab"],
        ex: ["ex-slab-oneway", "ex-slab-twoway"], cmps: ["cmp-osy-tsy"],
      },
      {
        t: "Columns — short, slender and biaxial", hi: "कॉलम — छोटे, स्लेंडर और द्वि-अक्षीय", ch: 8,
        topics: ["t-colreinf", "t-efflength", "t-slenderness", "t-mineccentricity", "t-columndesign"],
        tables: ["tb-efflength"], formulas: ["f-emin", "f-axialcol"], calcs: ["column-qty"],
        ex: ["ex-column-axial", "ex-slender-col"],
      },
      {
        t: "Footings and foundations", hi: "फुटिंग और नींव", ch: 9,
        topics: ["t-footing"], calcs: ["footing-qty"],
        ex: ["ex-footing", "ex-combined-footing", "ex-punching"],
      },
      {
        t: "Serviceability — deflection and cracking", hi: "सेवाक्षमता — विक्षेपण और दरार", ch: 10,
        topics: ["t-spandepth", "t-deflection", "t-crackwidth"], calcs: ["span-depth"], ex: ["ex-deflection"],
      },
      {
        t: "Staircases, walls and deep beams", hi: "सीढ़ियाँ, दीवारें और डीप बीम", ch: 11,
        topics: ["t-stairs", "t-walls", "t-deepbeam", "t-expjoint"], ex: ["ex-stair"],
      },
      {
        t: "Detailing and bar bending schedule", hi: "डिटेलिंग और बार बेंडिंग शेड्यूल", ch: 12,
        topics: ["t-minmax-beam", "t-barspacing", "t-curtail", "t-cover"],
        tables: ["tb-reinflimits", "tb-spacing", "tb-cover"],
        calcs: ["bbs-bar", "bbs-stirrup", "bbs-beam", "steel-weight"],
        checks: ["cl-reinforcement"],
      },
    ],
  },

  {
    id: "steel",
    name: "Design of Steel Structures",
    hi: "स्टील संरचना डिज़ाइन",
    icon: "⛓",
    sem: "3rd year · 6th sem",
    also: "Steel Structures · Design of Metal Structures",
    blurb: "IS 800:2007 limit state ke hisab se — tension, compression, beam, connection sab.",
    units: [
      {
        t: "Steel as a material and design basis", hi: "इस्पात और डिज़ाइन आधार", ch: 1,
        topics: ["t-800-materials", "t-800-lsd", "t-800-psf", "t-800-analysis"],
        tables: ["tb-800-steel"],
      },
      {
        t: "Section classification", hi: "सेक्शन वर्गीकरण", ch: 2,
        topics: ["t-800-class"], tables: ["tb-800-class"],
      },
      {
        t: "Bolted connections", hi: "बोल्ट जोड़", ch: 3,
        topics: ["t-800-bolt", "t-800-hsfg"], formulas: ["f-800-hsfg"], ex: ["ex-bolt"],
      },
      {
        t: "Welded connections", hi: "वेल्डेड जोड़", ch: 4,
        topics: ["t-800-weld"], ex: ["ex-weld"],
      },
      {
        t: "Tension members", hi: "तनाव सदस्य", ch: 5,
        topics: ["t-800-tension"], ex: ["ex-steel-tension", "ex-blockshear"],
      },
      {
        t: "Compression members and columns", hi: "संपीडन सदस्य और कॉलम", ch: 6,
        topics: ["t-800-comp", "t-800-slender", "t-800-details"], tables: ["tb-800-slender"],
        ex: ["ex-steel-comp"],
      },
      {
        t: "Beams — bending, shear and deflection", hi: "बीम — बंकन, अपरूपण, विक्षेपण", ch: 7,
        topics: ["t-800-bend", "t-800-shear", "t-800-defl"], formulas: ["f-800-shear"],
        ex: ["ex-steel-beam", "ex-steel-highshear"],
      },
      {
        t: "Lateral-torsional buckling", hi: "पार्श्व-मरोड़ बकलिंग", ch: 8,
      },
      {
        t: "Beam-columns — combined forces", hi: "बीम-कॉलम — संयुक्त बल", ch: 9,
        topics: ["t-800-combined"],
      },
      {
        t: "Plate girders", hi: "प्लेट गर्डर", ch: 10,
      },
      {
        t: "Column bases, trusses and industrial buildings", hi: "बेस, ट्रस और औद्योगिक भवन", ch: 11,
        topics: ["t-800-eq"],
      },
      {
        t: "Gantry girders, fatigue and fabrication", hi: "गैन्ट्री, थकान और निर्माण", ch: 12,
        topics: ["t-800-durability", "t-800-fire", "t-800-fatigue", "t-800-fab", "t-800-wsd"],
        formulas: ["f-800-eps"],
      },
    ],
  },

  {
    id: "geotech",
    name: "Geotechnical Engineering",
    hi: "भू-तकनीकी अभियांत्रिकी",
    icon: "🪨",
    sem: "3rd year · 5th–6th sem",
    also: "Soil Mechanics · Foundation Engineering",
    blurb: "Soil classification se pile capacity tak — ab poora 12-chapter handbook bhi, phase relationships se lekar pile group tak.",
    hb: "ge",
    units: [
      {
        t: "Soil as an engineering material", hi: "\u0907\u0902\u091c\u0940\u0928\u093f\u092f\u0930\u093f\u0902\u0917 \u0938\u093e\u092e\u0917\u094d\u0930\u0940 \u0915\u0947 \u0930\u0942\u092a \u092e\u0947\u0902 \u092e\u093f\u091f\u094d\u091f\u0940", ch: 1,
        mats: ["mat-soil"],
      },
      {
        t: "Index properties and classification", hi: "\u0938\u0942\u091a\u0915\u093e\u0902\u0915 \u0917\u0941\u0923 \u0914\u0930 \u0935\u0930\u094d\u0917\u0940\u0915\u0930\u0923", ch: 2,
        topics: ["t-soilclass", "t-soiltests"], formulas: ["f-aline"], ex: ["ex-soilclass"],
      },
      { t: "Permeability", hi: "\u092a\u093e\u0930\u0917\u092e\u094d\u092f\u0924\u093e", ch: 3 },
      { t: "Seepage and flow nets", hi: "\u0930\u093f\u0938\u093e\u0935 \u0914\u0930 \u092a\u094d\u0930\u0935\u093e\u0939 \u091c\u093e\u0932", ch: 4 },
      { t: "Effective stress", hi: "\u092a\u094d\u0930\u092d\u093e\u0935\u0940 \u092a\u094d\u0930\u0924\u093f\u092c\u0932", ch: 5 },
      { t: "Stress distribution in soil", hi: "\u092e\u093f\u091f\u094d\u091f\u0940 \u092e\u0947\u0902 \u092a\u094d\u0930\u0924\u093f\u092c\u0932 \u0935\u093f\u0924\u0930\u0923", ch: 6 },
      {
        t: "Compaction", hi: "\u0938\u0902\u0918\u0928\u0928", ch: 7,
        ex: ["ex-fielddensity"],
      },
      {
        t: "Consolidation and settlement", hi: "\u0938\u092e\u0947\u0915\u0928 \u0914\u0930 \u092c\u0948\u0920\u093e\u0928", ch: 8,
        topics: ["t-settlement"], ex: ["ex-settlement"],
      },
      { t: "Shear strength", hi: "\u0905\u092a\u0930\u0942\u092a\u0923 \u0938\u093e\u092e\u0930\u094d\u0925\u094d\u092f", ch: 9 },
      { t: "Earth pressure and retaining walls", hi: "\u092e\u0943\u0926\u093e \u0926\u093e\u092c \u0914\u0930 \u0930\u093f\u091f\u0947\u0928\u093f\u0902\u0917 \u0935\u0949\u0932", ch: 10 },
      {
        t: "Bearing capacity and shallow foundation design", hi: "\u0935\u0939\u0928 \u0915\u094d\u0937\u092e\u0924\u093e \u0914\u0930 \u0909\u0925\u0932\u0940 \u0928\u0940\u0902\u0935 \u0921\u093f\u091c\u093c\u093e\u0907\u0928", ch: 11,
        topics: ["t-bearing", "t-footing"], calcs: ["footing-qty", "excavation"],
        ex: ["ex-bearing", "ex-footing", "ex-punching", "ex-combined-footing"],
      },
      {
        t: "Piles, deep foundations and site investigation", hi: "\u092a\u093e\u0907\u0932, \u0917\u0939\u0930\u0940 \u0928\u0940\u0902\u0935 \u0914\u0930 \u0938\u094d\u0925\u0932 \u0905\u0928\u094d\u0935\u0947\u0937\u0923", ch: 12,
        topics: ["t-pile"], ex: ["ex-pile"],
      },
    ],
  },

  {
    id: "survey",
    name: "Surveying",
    hi: "सर्वेक्षण",
    icon: "📐",
    sem: "2nd year · 3rd–4th sem",
    also: "Surveying & Geomatics",
    blurb: "Levelling, area, contour aur traverse — har ek ke saath calculator jo steps dikhata hai.",
    units: [
      { t: "What surveying is for — principles and classification", hi: "सर्वेक्षण के सिद्धांत", ch: 1 },
      { t: "Errors, accuracy and precision", hi: "त्रुटियाँ और यथार्थता", ch: 2 },
      {
        t: "Chain and tape surveying", hi: "चेन और टेप सर्वेक्षण", ch: 3,
        calcs: ["distance-bearing"],
      },
      { t: "Compass surveying and bearings", hi: "कम्पास और दिशाकोण", ch: 4 },
      { t: "Plane table surveying", hi: "प्लेन टेबल सर्वेक्षण", ch: 5 },
      {
        t: "Levelling — HI and rise & fall", hi: "लेवलिंग", ch: 6,
        topics: ["t-levelling"], formulas: ["f-level"], ex: ["ex-levelling"],
        calcs: ["level-hi", "slope"],
      },
      {
        t: "Contouring", hi: "कंटूरिंग", ch: 7,
        topics: ["t-contour"],
      },
      {
        t: "Theodolite and traverse computation", hi: "थियोडोलाइट और ट्रैवर्स", ch: 8,
        topics: ["t-traverse"], formulas: ["f-traverse"], calcs: ["traverse"],
      },
      { t: "Tacheometry", hi: "टैकियोमेट्री", ch: 9 },
      {
        t: "Areas and volumes", hi: "क्षेत्रफल और आयतन", ch: 10,
        topics: ["t-area"], formulas: ["f-simpson"], ex: ["ex-simpson"],
        calcs: ["area-offsets", "area-coords"],
      },
      { t: "Curves — horizontal and vertical", hi: "वक्र", ch: 11 },
      { t: "Triangulation, total station and GNSS", hi: "त्रिभुजन, टोटल स्टेशन और GNSS", ch: 12 },
    ],
  },

  {
    id: "transport",
    name: "Transportation Engineering",
    hi: "परिवहन अभियांत्रिकी",
    icon: "🛣",
    sem: "3rd year · 6th sem",
    also: "Highway Engineering · Pavement Design",
    blurb: "Geometry se pavement tak — ab poora 8-chapter handbook bhi. Yeh IRC dastavez hain, IS code nahi — app me alag dikhaye gaye hain.",
    hb: "tr",
    units: [
      {
        t: "The road as a system — alignment", hi: "एक तंत्र के रूप में सड़क — संरेखण", ch: 1,
      },
      {
        t: "Geometric design — cross-section and sight distance", hi: "ज्यामितीय डिज़ाइन — क्रॉस-सेक्शन और दृष्टि दूरी", ch: 2,
      },
      {
        t: "Horizontal curves and superelevation", hi: "क्षैतिज वक्र और अधिउन्नयन", ch: 3,
        ex: ["ex-superelevation"],
      },
      {
        t: "Traffic, design traffic (msa) and subgrade CBR", hi: "यातायात, डिज़ाइन ट्रैफ़िक (msa) और सबग्रेड CBR", ch: 4,
        topics: ["t-cbr"], formulas: ["f-msa"], ex: ["ex-msa"],
      },
      {
        t: "Highway materials — bitumen and aggregates", hi: "राजमार्ग सामग्री — बिटुमेन और गिट्टी", ch: 5,
        mats: ["mat-bitumen", "mat-aggregate"], topics: ["t-aggtests"],
      },
      {
        t: "Flexible pavement design", hi: "लचीला फुटपाथ डिज़ाइन", ch: 6,
        topics: ["t-pavementlayers"],
      },
      {
        t: "Rigid pavement design", hi: "कठोर फुटपाथ डिज़ाइन", ch: 7,
        topics: ["t-rigidpavement"], cmps: ["cmp-flex-rigid"],
      },
      {
        t: "Railways, airports and docks", hi: "रेलवे, हवाई अड्डे और बंदरगाह", ch: 8,
      },
    ],
  },

  /* ------------------------------------------------ 4th year / applied */
  {
    id: "earthquake",
    name: "Earthquake Engineering",
    hi: "भूकंप अभियांत्रिकी",
    icon: "〰",
    sem: "4th year · elective",
    also: "Seismic Design · Structural Dynamics (design part)",
    blurb: "IS 1893 aur IS 13920 ka poora design flow — ab poora 8-chapter handbook bhi, base shear se ductile detailing tak.",
    hb: "eq",
    units: [
      {
        t: "Where the force comes from — the philosophy", hi: "बल कहाँ से आता है — दर्शन", ch: 1,
        topics: ["t-1893-principles"],
      },
      {
        t: "Seismic zones and the design spectrum", hi: "भूकंप ज़ोन और डिज़ाइन स्पेक्ट्रम", ch: 2,
        topics: ["t-seismiczone"], tables: ["tb-zonefactor"],
      },
      {
        t: "Design base shear and natural period", hi: "डिज़ाइन बेस शियर और प्राकृतिक अवधि", ch: 3,
        topics: ["t-seismic", "t-period"], formulas: ["f-baseshear"], ex: ["ex-seismic"],
      },
      {
        t: "Drift, irregularity and separation", hi: "ड्रिफ्ट, अनियमितता और पृथक्करण", ch: 4,
        topics: ["t-drift", "t-irregular", "t-1893-separation"], ex: ["ex-drift"],
      },
      {
        t: "Load combinations and dynamic analysis", hi: "भार संयोजन और गतिक विश्लेषण", ch: 5,
        topics: ["t-1893-loadcomb", "t-1893-dynamic"],
      },
      {
        t: "Ductility and capacity design", hi: "तन्यता और क्षमता डिज़ाइन", ch: 6,
        topics: ["t-scwb"], cmps: ["cmp-456-13920"],
      },
      {
        t: "Ductile detailing of RC frames", hi: "आर.सी. फ्रेम की डक्टाइल डिटेलिंग", ch: 7,
        topics: ["t-13920-mat", "t-13920-beam", "t-confining", "t-13920-joint", "t-13920-wall"],
        tables: ["tb-13920", "tb-13920-wall"], ex: ["ex-confining"],
      },
      {
        t: "Masonry and steel under earthquake", hi: "भूकंप में चिनाई और स्टील", ch: 8,
        topics: ["t-seismicband", "t-800-eq"],
      },
    ],
  },

  {
    id: "estimation",
    name: "Estimation & Costing",
    hi: "आकलन एवं लागत",
    icon: "📊",
    sem: "4th year · 7th sem",
    also: "Quantity Surveying · Estimating & Costing",
    blurb: "Cost = quantity × rate — ab poora 8-chapter handbook bhi, har unit ke saath calculator jo steps dikhata hai.",
    hb: "es",
    units: [
      {
        t: "What an estimate is — types and the cost equation", hi: "आकलन क्या है — प्रकार और लागत समीकरण", ch: 1,
      },
      {
        t: "Units, conversions and modes of measurement", hi: "इकाई, रूपांतरण और मापन विधि", ch: 2,
        tables: ["tb-conversion"],
        calcs: ["conv-length", "conv-area", "conv-volume", "conv-mass", "conv-force", "conv-stress"],
      },
      {
        t: "Taking out quantities — centre-line and long/short wall", hi: "मात्रा निकालना — सेंटर-लाइन और लंबी-छोटी दीवार", ch: 3,
      },
      {
        t: "Earthwork measurement", hi: "मिट्टी कार्य का मापन", ch: 4,
        topics: ["t-earthwork"], calcs: ["excavation", "backfill", "earthwork"],
      },
      {
        t: "Concrete and reinforcement measurement", hi: "कंक्रीट और सरिया का मापन", ch: 5,
        topics: ["t-quantities"],
        calcs: ["concrete-qty", "pcc", "slab-qty", "beam-qty", "column-qty", "footing-qty"],
        ex: ["ex-slab-qty"],
      },
      {
        t: "Bar bending schedule", hi: "बार बेंडिंग शेड्यूल", ch: 6,
        calcs: ["bbs-bar", "bbs-stirrup", "bbs-beam", "bbs-slab", "steel-weight"],
        tables: ["tb-steelwt"], formulas: ["f-steelwt"],
      },
      {
        t: "Masonry, plaster and finishing quantities", hi: "चिनाई, प्लास्टर और फिनिशिंग की मात्रा", ch: 7,
        topics: ["t-mortar", "t-plaster"], calcs: ["brickwork", "plaster"],
        ex: ["ex-brickwork-qty", "ex-plaster-qty"],
      },
      {
        t: "Rate analysis, tendering and valuation", hi: "दर विश्लेषण, निविदा और मूल्यांकन", ch: 8,
      },
    ],
  },

  {
    id: "building-services",
    name: "Building Services & Safety",
    hi: "भवन सेवाएँ एवं सुरक्षा",
    icon: "🚰",
    sem: "3rd–4th year",
    also: "Water Supply & Sanitary Engineering · NBC · Fire Safety",
    blurb: "Paani, drainage, aag se surakcha aur waterproofing — ab poora 8-chapter handbook bhi, NBC ke hisaab se.",
    hb: "bs",
    units: [
      {
        t: "The invisible half of a building", hi: "भवन का अदृश्य आधा", ch: 1,
      },
      {
        t: "Water demand and storage", hi: "जल माँग और भंडारण", ch: 2,
        topics: ["t-waterdemand"], mats: ["mat-water", "mat-pipes"],
      },
      {
        t: "Building drainage and sanitation", hi: "भवन जल निकासी और स्वच्छता", ch: 3,
        topics: ["t-drainage"], mats: ["mat-pipes"],
      },
      {
        t: "Water and wastewater treatment", hi: "जल एवं अपशिष्ट उपचार", ch: 4,
      },
      {
        t: "Means of egress and travel distance", hi: "निकास मार्ग और यात्रा दूरी", ch: 5,
        topics: ["t-egress"],
      },
      {
        t: "Fire load and fire resistance rating", hi: "अग्नि भार और अग्नि प्रतिरोध रेटिंग", ch: 6,
        topics: ["t-firegrading"],
      },
      {
        t: "Fire detection and suppression", hi: "अग्नि पहचान और शमन", ch: 7,
      },
      {
        t: "Waterproofing and damp proofing", hi: "वाटरप्रूफिंग और डैम्प प्रूफिंग", ch: 8,
        mats: ["mat-waterproofing"],
      },
    ],
  },

  {
    id: "testing-qc",
    name: "Material Testing & QC",
    hi: "सामग्री परीक्षण एवं गुणवत्ता",
    icon: "🔬",
    sem: "Lab · all years",
    also: "Concrete & Highway Materials Lab · Quality Control",
    blurb: "Lab file aur viva ke liye — ab poora 8-chapter handbook bhi. Har test kyun, kya value, kis code se.",
    hb: "qc",
    units: [
      {
        t: "Why we test — sampling and the logic", hi: "परीक्षण क्यों — नमूनाकरण", ch: 1,
      },
      {
        t: "Cement tests", hi: "सीमेंट परीक्षण", ch: 2,
        topics: ["t-cementtests"], mats: ["mat-cement"],
      },
      {
        t: "Aggregate tests", hi: "गिट्टी परीक्षण", ch: 3,
        topics: ["t-aggtests"], mats: ["mat-aggregate"],
      },
      {
        t: "Concrete — cube test and acceptance", hi: "कंक्रीट — क्यूब टेस्ट और स्वीकृति", ch: 4,
        topics: ["t-cubetest", "t-acceptance", "t-workability"], tables: ["tb-sampling", "tb-grades"],
        checks: ["cl-concrete-receipt"],
      },
      {
        t: "Non-destructive testing", hi: "अविनाशी परीक्षण", ch: 5,
        topics: ["t-ndt", "t-assessment"],
      },
      {
        t: "Soil tests", hi: "मिट्टी परीक्षण", ch: 6,
        topics: ["t-soiltests", "t-soilclass"], mats: ["mat-soil"],
      },
      {
        t: "Brick, steel and bitumen tests", hi: "ईंट, स्टील और बिटुमेन परीक्षण", ch: 7,
        topics: ["t-brick"], mats: ["mat-brick", "mat-steel", "mat-bitumen"], tables: ["tb-brick"],
      },
      {
        t: "Quality control and acceptance", hi: "गुणवत्ता नियंत्रण और स्वीकृति", ch: 8,
      },
    ],
  },
];

/* Subjects the app does not cover at all yet. Shown on the Subjects page
   so nobody installs this expecting their whole semester to be here.
   Each of these is theory-and-derivation heavy and sits outside the IS
   code library, which is what this app is built from. */
DB.subjectsMissing = [
  "Engineering Mechanics",
  "Strength of Materials",
  "Fluid Mechanics",
  "Hydrology & Irrigation",
  "Environmental Engineering (treatment)",
  "Construction Management & Project Planning",
];

/* Note for whoever edits this file next:
   run  node _subjects.js  — it checks every id here against the real
   DB arrays and prints anything that does not resolve. Do that before
   shipping; a typo here silently hides content from a whole unit. */
