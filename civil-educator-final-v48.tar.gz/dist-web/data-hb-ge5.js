/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   Chapter 9  — Shear Strength
   Chapter 10 — Earth Pressure and Retaining Walls
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "ge"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 9 */
    {
      id: "ge-9",
      n: 9,
      title: "Shear Strength",
      hi: "अपरूपण सामर्थ्य",
      blurb: "Why the same clay honestly gives three different strengths, and which one your problem needs.",
      mins: 38,
      sections: [

        {
          n: "9.1",
          title: "Soil fails in shear",
          hi: "मिट्टी अपरूपण में फेल होती है",
          blocks: [
            { k: "p", t: "Soil does not fail by crushing. A slope slides, a foundation punches down by pushing soil sideways, a retaining wall is overturned by soil shearing along a plane behind it. In every case the mechanism is <strong>one mass of soil sliding past another</strong>, and the resistance to that is shear strength." },
            { k: "eq", expr: "τf  =  c′  +  σ′ tan φ′        — the Mohr–Coulomb criterion", where: [
              ["τf", "shear stress at failure on the failure plane"],
              ["c′", "effective cohesion — strength that exists at zero normal stress"],
              ["φ′", "effective angle of internal friction"],
            ]},
            { k: "p", t: "The two terms are physically different. <strong>Friction</strong> requires a normal force pressing the grains together, so it scales with σ′ — and it is the only source of strength in a clean sand. <strong>Cohesion</strong> is strength that survives at zero normal stress: electrochemical attraction between clay particles, cementation, and in a partly saturated soil the apparent cohesion from capillary suction." },
            { k: "trap", t: "Note the primes. Because only effective stress presses grains together, the fundamental strength parameters are <strong>c′ and φ′</strong> — expressed in terms of effective stress. Total stress parameters c and φ exist and are used, but they are not properties of the soil: they are properties of the soil <em>plus the drainage conditions of the test</em>, which is the whole of §9.4." },
          ],
        },

        {
          n: "9.2",
          title: "Mohr circles and the envelope",
          hi: "मोर वृत्त और लिफ़ाफ़ा",
          blocks: [
            { k: "dia", id: "hb-ge-mohr", cap: "Each test is a circle; the envelope tangent to them is the soil." },
            { k: "p", t: "A Mohr circle represents the complete state of stress at a point: its diameter runs from σ₃ to σ₁ on the normal stress axis, and every point on it gives the normal and shear stress on some plane through that point." },
            { k: "list", items: [
              "A circle lying <strong>entirely below</strong> the envelope — the soil is safe, no plane is at failure.",
              "A circle <strong>touching</strong> the envelope — failure, on the plane corresponding to the point of tangency.",
              "A circle <strong>crossing</strong> the envelope — impossible. The soil would have failed before reaching that state.",
            ]},
            { k: "eq", expr: "σ₁  =  σ₃ tan²(45 + φ/2)  +  2c tan(45 + φ/2)", where: [] },
            { k: "p", t: "The failure plane is inclined at <strong>45° + φ/2</strong> to the major principal plane — <em>not</em> at 45°, which is where the shear stress is greatest. Failure occurs where the ratio of shear stress to available strength is worst, and since the available strength itself grows with normal stress, the critical plane rotates away from 45° by half the friction angle." },
            { k: "eg",
              title: "Example 9.1 — Two triaxial tests, one envelope",
              given: "Two consolidated-undrained triaxial tests on the same clay.\nTest 1: cell pressure 100 kPa, sample failed at a total axial stress of 280 kPa.\nTest 2: cell pressure 200 kPa, sample failed at 440 kPa.",
              steps: [
                { t: "Set up the two equations", w: "Let N = tan²(45 + φ/2).\n280 = 100 N + 2c √N\n440 = 200 N + 2c √N" },
                { t: "Subtract to eliminate the cohesion term", w: "440 − 280 = (200 − 100) N\n160 = 100 N\nN = 1.600" },
                { t: "Friction angle", w: "tan(45 + φ/2) = √1.600 = 1.2649\n45 + φ/2 = arctan(1.2649) = 51.67°\nφ/2 = 6.67°,  so  φ = 13.3°" },
                { t: "Cohesion", w: "Substitute back into the first equation:\n280 = 100(1.600) + 2c(1.2649)\n280 − 160 = 2.5298 c\nc = 120/2.5298 = 47.4 kPa" },
                { t: "Check against the second test", w: "σ₁ = 200(1.600) + 2(47.4)(1.2649) = 320 + 120 = 440 kPa  ✓" },
                { t: "The failure plane", w: "45 + φ/2 = 51.7° to the horizontal — visible on the failed sample" },
              ],
              ans: "c = 47.4 kPa, φ = 13.3°. The low friction angle with substantial cohesion is characteristic of a consolidated-undrained test on clay — and §9.4 explains why the same clay tested drained would give something closer to c′ ≈ 0 with φ′ ≈ 25°.",
            },
            { k: "note", t: "Two tests are the minimum and three is better, because a single circle has infinitely many tangents. With three, the envelope's straightness can be checked — and a genuinely curved envelope, which overconsolidated clays produce, is telling you something the straight-line fit will hide." },
          ],
        },

        {
          n: "9.3",
          title: "The tests",
          hi: "परीक्षण",
          blocks: [
            { k: "dia", id: "hb-ge-sheartests", cap: "Four instruments, and the drainage control is what separates them." },
            { k: "cmp", t: "Direct shear against triaxial — the two laboratory workhorses.",
              cols: ["Direct shear box", "Triaxial"],
              rows: [
                ["Failure plane", "<strong>Forced</strong> — horizontal, whether the soil likes it or not", "The sample chooses its own weakest plane"],
                ["Drainage control", "Poor — cannot measure or control pore pressure", "<strong>Complete</strong> — drainage valves and pore pressure transducer"],
                ["Stress state", "Not uniform; principal stresses unknown during shear", "Uniform and known throughout"],
                ["Effective stress parameters", "Only for free-draining soils tested slowly", "Yes, directly"],
                ["Cost and speed", "Cheap and quick", "Slower and more expensive"],
                ["Best for", "Sands, and quick comparative work", "Anything that matters, and all clays"],
              ] },
            { k: "list", items: [
              "<strong>Unconfined compression (UCS)</strong> — a triaxial test with σ₃ = 0. Valid only for saturated clay, where it gives cu = qu/2. Fast, and standard for soft clays.",
              "<strong>Vane shear</strong> — a cruciform vane pushed into the ground and rotated, measuring torque. The point is that <em>nothing is sampled</em>: for a soft sensitive clay, the act of taking a sample destroys the very thing you wanted to measure, so the test goes to the soil rather than the other way round. With both ends of the vane shearing, cu = T / [π D² (H/2 + D/6)].",
            ]},
          ],
        },

        {
          n: "9.4",
          title: "Why one clay gives three answers",
          hi: "एक ही मिट्टी, तीन उत्तर",
          blocks: [
            { k: "p", t: "This is the section that makes sense of the whole chapter. A triaxial test can be run three ways, and the same clay honestly gives three different strengths — because they answer three different field questions." },
            { k: "cmp", t: "The three triaxial procedures.",
              cols: ["What it models"],
              rows: [
                ["<strong>UU</strong> — unconsolidated undrained", "Loading so fast that no drainage occurs at all. Gives cu with φu = 0 for a saturated clay. Models end-of-construction on soft clay — the most critical moment for an embankment."],
                ["<strong>CU</strong> — consolidated undrained", "The soil has consolidated under its existing stresses, then is loaded rapidly. With pore pressure measured, it yields c′ and φ′ as well. The usual compromise: effective parameters in a reasonable time."],
                ["<strong>CD</strong> — consolidated drained", "Loaded slowly enough that no excess pore pressure ever builds up. Gives c′ and φ′ directly. Models the long-term condition — and for a clay it can take weeks."],
              ] },
            { k: "p", t: "So the question is never \"what is the shear strength of this clay?\" It is <strong>\"which drainage condition governs my problem?\"</strong> — and the answer differs between the two ends of the same structure's life:" },
            { k: "list", items: [
              "<strong>Embankment on soft clay</strong> — the dangerous moment is the end of construction, before the foundation has consolidated and gained strength. Undrained, so UU.",
              "<strong>Cut slope in stiff clay</strong> — the dangerous moment is <em>years later</em>. Excavation reduces stress, the clay slowly draws water in and swells, σ′ falls and strength falls with it. Drained, so CD. Cuttings have failed decades after they were made.",
              "<strong>Foundation on sand</strong> — always drained, whatever the loading rate, because k is so high that pore pressures never build up.",
            ]},
            { k: "trap", t: "Those first two are worth reading twice, because they point in opposite directions in time. <strong>A fill is most at risk on the day it is finished; a cutting is most at risk long after everyone has gone home.</strong> Using the wrong analysis is not conservative in either case — it is simply the wrong question." },
            { k: "eg",
              title: "Example 9.2 — Field vane in soft clay",
              given: "A vane 75 mm in diameter and 150 mm high is rotated in a soft clay; the peak torque is 45 N·m. After remoulding (rapid rotation) the torque falls to 15 N·m.",
              steps: [
                { t: "Undisturbed strength", w: "cu = T/[π D²(H/2 + D/6)] = 45/[π × 0.075² × (0.075 + 0.0125)]\n   = 45/(0.017671 × 0.0875) = 45/0.0015463 = 29,100 Pa ≈ 29.1 kPa" },
                { t: "Remoulded strength", w: "15/0.0015463 = 9,700 Pa ≈ 9.7 kPa" },
                { t: "Sensitivity", w: "St = 29.1/9.7 = 3.0" },
              ],
              ans: "cu ≈ 29 kPa, sensitivity 3 — a medium-sensitive soft clay. The vane measured it without the sampling disturbance that would have lowered a laboratory value." },
            { k: "note", t: "Sands have a further behaviour worth knowing: a <em>dense</em> sand must ride up over its own grains to shear, so it expands (dilates) and shows a peak strength followed by a drop to a lower <strong>critical state</strong> value. A loose sand contracts and reaches the same critical state without a peak. Designing on the peak strength of a dense sand is designing on something the soil will shed after a little movement." },
          ],
        },

        {
          n: "9.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "τf = c′ + σ′ tan φ′. Friction needs normal stress; cohesion does not.",
              "A Mohr circle touching the envelope is at failure; crossing it is impossible.",
              "Failure plane at 45° + φ/2, not 45°.",
              "Two tests minimum for an envelope; three is better.",
              "Direct shear forces the plane; triaxial lets the soil choose and controls drainage.",
              "Vane shear goes to the soil because sampling soft clay destroys it.",
              "UU for end of construction, CD for the long term, CU as the practical compromise.",
              "A fill is most at risk when finished; a cutting is most at risk years later.",
              "Dense sand peaks then drops to critical state — do not design on the peak.",
            ]},
            { k: "p", t: "Chapter 10 applies this strength to the commonest geotechnical structure of all: a wall with soil behind it." },
          ],
        },
      ],
    },

    /* =========================================================== CH 10 */
    {
      id: "ge-10",
      n: 10,
      title: "Earth Pressure and Retaining Walls",
      hi: "मृदा दाब और रिटेनिंग वॉल",
      blurb: "How hard soil pushes depends on which way the wall moves — and the answers differ by a factor of nine.",
      mins: 34,
      sections: [

        {
          n: "10.1",
          title: "Three pressures, one soil",
          hi: "तीन दाब, एक मिट्टी",
          blocks: [
            { k: "p", t: "The force soil exerts on a wall is not a property of the soil alone. It depends on <strong>how much the wall moves and in which direction</strong>, because movement lets the soil mobilise its own shear strength — either to help hold itself up, or to resist being pushed." },
            { k: "dia", id: "an-ge-earthpressure", cap: "Hold the wall still, let it move away, push it in — three different pressures from one soil." },
            { k: "def", term: "At rest (K₀)", t: "No movement at all. The soil is in the state it has always been in, and no shear strength is mobilised. K₀ ≈ 1 − sin φ′ for a normally consolidated soil. This is the case for a basement wall, propped at both ends and unable to yield." },
            { k: "def", term: "Active (Ka)", t: "The wall moves <em>away</em> from the soil. The soil expands slightly, mobilises its shear strength in its own support, and the pressure on the wall <strong>falls</strong> to a minimum. This is the design case for a free-standing retaining wall." },
            { k: "def", term: "Passive (Kp)", t: "The wall is pushed <em>into</em> the soil. The soil is compressed, resists, and the pressure <strong>rises</strong> to a maximum. This is the resistance in front of a sheet pile's embedded length." },
            { k: "p", t: "For φ = 30° the three coefficients are about 0.50, 0.33 and 3.00 — so <strong>passive pressure is nine times active</strong>. That enormous ratio is why a modest embedded depth can support a sheet pile wall, and it is the single most useful number in this chapter." },
            { k: "trap", t: "The movements needed are wildly different. Active pressure is fully mobilised by a wall rotation of about 0.1% of its height — a few millimetres, which almost any wall provides. <strong>Full passive resistance needs 2 to 5%</strong> — 100 mm or more on a 3 m wall, far beyond what any structure can tolerate. That is why passive resistance is taken with a large factor of safety, or discounted altogether." },
          ],
        },

        {
          n: "10.2",
          title: "Rankine's theory",
          hi: "रैंकिन सिद्धांत",
          blocks: [
            { k: "p", t: "Rankine considered the state of stress in a semi-infinite soil mass at the point of failure. For a smooth vertical wall with a level, cohesionless backfill:" },
            { k: "eq", expr: "Ka = (1 − sin φ)/(1 + sin φ) = tan²(45 − φ/2)        Kp = 1/Ka = tan²(45 + φ/2)", where: [] },
            { k: "dia", id: "hb-ge-rankine", cap: "A triangle from the soil, a rectangle from a surcharge — and water gets neither." },
            { k: "eq", expr: "pa = Ka γ z          Pa = ½ Ka γ H²   acting at H/3 above the base", where: [] },
            { k: "p", t: "The pressure grows linearly with depth because γz does, so the diagram is a triangle and its resultant acts at the third point. A uniform <strong>surcharge</strong> q on the surface adds a constant Ka q at every depth — a rectangle, whose resultant acts at mid-height." },
            { k: "eq", expr: "cohesive soil:   pa = Ka γ z − 2c √Ka", where: [] },
            { k: "p", t: "That second term is negative, so near the surface the computed active pressure is negative — the soil is in tension. Soil cannot sustain tension, so it cracks instead, to a depth <strong>zc = 2c/(γ √Ka)</strong>. The crack fills with water in the first rains, and the water pressure in it is often worse than the earth pressure it replaced. <strong>Tension cracks are usually ignored in the pressure diagram and provided for in the drainage.</strong>" },
            { k: "eg",
              title: "Example 10.1 — Thrust on a wall, with a surcharge",
              given: "A 6.0 m high wall retains a level cohesionless backfill with γ = 18 kN/m³ and φ = 30°. A uniform surcharge of 20 kPa acts on the surface. No water table.",
              steps: [
                { t: "Active earth pressure coefficient", w: "Ka = (1 − sin30°)/(1 + sin30°) = 0.5/1.5 = 0.3333\n(check: tan²(45 − 15) = tan²30° = 0.3333  ✓)" },
                { t: "Thrust from the soil", w: "Pa = ½ Ka γ H² = 0.5 × 0.3333 × 18 × 6.0²\n   = 0.5 × 0.3333 × 18 × 36 = 108.0 kN per metre run\nacting at H/3 = 2.00 m above the base" },
                { t: "Thrust from the surcharge", w: "Pq = Ka q H = 0.3333 × 20 × 6.0 = 40.0 kN per metre\nacting at H/2 = 3.00 m above the base" },
                { t: "Total, and where it acts", w: "Total = 108.0 + 40.0 = 148.0 kN per metre\nȳ = (108.0 × 2.00 + 40.0 × 3.00)/148.0\n  = (216 + 120)/148.0 = 2.270 m above the base" },
                { t: "For comparison, the passive side", w: "Kp = 1/0.3333 = 3.000\nPp for the same 6 m would be ½ × 3.0 × 18 × 36 = 972 kN — nine times Pa" },
              ],
              ans: "148.0 kN/m acting 2.27 m above the base. Note that a 20 kPa surcharge — roughly a metre of stored material, or a parked truck — added 37% to the thrust and raised its point of application by 270 mm, which matters a great deal for overturning.",
            },
            { k: "trap", t: "If there is a water table behind the wall, use <strong>γ′</strong> for the soil below it and then <strong>add the full hydrostatic ½ γw h²</strong> separately. Water has no K — it pushes equally in every direction. Applying Ka to the water underestimates the thrust by a factor of three, and it is why drainage behind a wall is not a detail but a structural requirement." },
          ],
        },

        {
          n: "10.3",
          title: "Coulomb, and designing the wall",
          hi: "कूलम्ब और दीवार का डिज़ाइन",
          blocks: [
            { k: "cmp", t: "The two classical theories.",
              cols: ["Rankine (1857)", "Coulomb (1776)"],
              rows: [
                ["Approach", "Stress state in the soil mass at failure", "Equilibrium of a rigid wedge sliding on a plane"],
                ["Wall friction", "Ignored — wall assumed smooth", "<strong>Included</strong>"],
                ["Wall face", "Vertical", "Any inclination"],
                ["Backfill surface", "Level or uniformly sloping", "Any shape, including irregular"],
                ["Result", "Simple closed form", "More general, and the trial-wedge version handles anything"],
                ["Which is safer", "Conservative for active — ignoring wall friction overstates the thrust", "More realistic, and unsafe for passive if wall friction is overestimated"],
              ] },
            { k: "eg",
              title: "Example 10.2 — Tension crack in a cohesive backfill",
              given: "Backfill with c = 10 kPa, φ = 20°, γ = 18 kN/m³.",
              steps: [
                { t: "Ka", w: "(1 − sin 20°)/(1 + sin 20°) = 0.658/1.342 = 0.490;  √Ka = 0.700" },
                { t: "Depth of tension crack", w: "zc = 2c/(γ√Ka) = 20/(18 × 0.700) = 1.59 m" },
              ],
              ans: "The top 1.6 m of the wall gets no earth pressure in theory — and a crack 1.6 m deep that can fill with water. Design for the water in the crack, or drain it." },
            { k: "eg",
              title: "Example 10.3 — A water table behind the wall",
              given: "The 6.0 m wall of Example 10.1 (φ = 30°, Ka = 1/3), no surcharge, but with a water table 3.0 m below the top. γ = 18 kN/m³ above it, γsat = 20 kN/m³ below; γw = 9.81 kN/m³.",
              steps: [
                { t: "Earth pressure at the water table and at the base", w: "at 3 m: Ka γ z = (1/3)(18)(3) = 18.0 kPa\nat 6 m: 18.0 + (1/3)(20 − 9.81)(3) = 18.0 + 10.19 = 28.19 kPa" },
                { t: "Earth thrust", w: "½ × 18.0 × 3 + 18.0 × 3 + ½ × 10.19 × 3 = 27.0 + 54.0 + 15.3 = 96.3 kN/m" },
                { t: "Water thrust — no Ka", w: "½ γw h² = ½ × 9.81 × 3² = 44.1 kN/m" },
                { t: "Total", w: "96.3 + 44.1 = 140.4 kN/m  (against 108.0 kN/m dry)" },
              ],
              ans: "A water table halfway up adds 30% to the thrust — and the water component alone is nearly half the soil's. This is the number a blocked weep hole adds to a wall designed dry." },
            { k: "p", t: "Rankine is used for ordinary walls because it is simple and errs on the safe side for the active case. Coulomb is used where the geometry is awkward — a battered face, a sloping or stepped backfill, or where wall friction is worth claiming." },
            { k: "h", t: "The checks on a retaining wall" },
            { k: "p", t: "A retaining wall almost always fails as a rigid body long before its concrete is overstressed, which is why the stability checks come before any reinforcement is designed. <a href=\"#/read/rcc/11\">Chapter 11 of the RCC handbook</a> works one through in full (Example 11.2), including the IS 456 Cl. 20 form of the checks; the list is:" },
            { k: "list", items: [
              "<strong>Overturning</strong> about the toe — factor of safety around 2.",
              "<strong>Sliding</strong> along the base — factor of safety around 1.5, and usually the one that fails first.",
              "<strong>Bearing pressure</strong> under the base — maximum within the safe bearing capacity, minimum not negative.",
              "<strong>Overall (slip circle) stability</strong> — the whole wall and a mass of soil rotating together on a deep failure surface. Missed surprisingly often, and it does not care how well the wall itself was designed.",
            ]},
            { k: "real", t: "The weight doing most of the work in a cantilever wall is the <strong>soil sitting on the heel</strong>, not the concrete. That is why such walls have long heels and short toes, and why backfilling is a structural operation rather than a finishing one — the wall is not stable until its heel is loaded." },
            { k: "note", t: "Drainage is the cheapest thing on a retaining wall and the most commonly neglected. Weep holes at 1 to 1.5 m centres, a granular filter behind the wall, and a longitudinal drain at the base remove the hydrostatic term entirely. <strong>A blocked weep hole can double the thrust on a wall that was correctly designed</strong>, and a great many wall failures are drainage failures wearing a structural disguise." },
          ],
        },

        {
          n: "10.4",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "At rest, active, passive — the pressure depends on wall movement, not just on the soil.",
              "Ka = tan²(45 − φ/2), Kp = tan²(45 + φ/2), K₀ ≈ 1 − sin φ.",
              "Passive is about nine times active for φ = 30°.",
              "Active needs millimetres of movement; full passive needs far more than a structure can allow.",
              "Pa = ½ Ka γ H² at H/3; a surcharge adds Ka q H at H/2.",
              "Cohesion gives a tension crack to depth 2c/(γ√Ka).",
              "Water gets no K. Use γ′ and add the full hydrostatic pressure separately.",
              "Rankine ignores wall friction and is conservative for active; Coulomb is more general.",
              "Check overturning, sliding, bearing AND overall slip stability.",
              "Drainage is structural.",
            ]},
            { k: "p", t: "Chapter 11 turns the problem the other way up: instead of soil pushing a structure sideways, a structure pushing down on soil." },
          ],
        },
      ],
    }

  );
})();
