/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: ESTIMATION & COSTING · Ch 7–8
   Masonry, plaster & finishing quantities · Rate analysis,
   specifications, tendering & valuation
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "es");
  if (!hb) { console.error("[es3] handbook es not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 7 */
    {
      id: "es-7",
      n: 7,
      title: "Masonry, Plaster and Finishing Quantities",
      hi: "चिनाई, प्लास्टर और फिनिशिंग की मात्रा",
      blurb: "Measuring brickwork by volume and plaster and paint by area, the deductions that matter, and how each quantity turns into materials.",
      mins: 18,
      sections: [
        {
          n: "7.1",
          title: "Brickwork by volume, plaster by area",
          hi: "चिनाई आयतन में, प्लास्टर क्षेत्रफल में",
          blocks: [
            { k: "p", t: "The finishing trades are measured in the unit that matches how they consume material. Brickwork is a solid, so it goes by volume; plaster, painting and flooring are skins over a surface, so they go by area. The same wall therefore appears twice in an estimate — once as brickwork (m³) and again as plaster (m²) on each face." },
            { k: "cmp", t: "The finishing items",
              cols: ["Unit & deductions", "What it feeds"],
              rows: [
                ["Brickwork", "m³ — deduct openings over the code's threshold", "feeds 500 bricks + mortar per m³"],
                ["Plaster", "m² per face — deduct openings", "one or both faces as specified"],
                ["Painting", "m² — a multiplier for panelled/corrugated work", "measured over the painted area"],
                ["Flooring / skirting", "m² / running m", "area for floor, length for skirting"],
              ] },
            { k: "note", t: "The chain from quantity to material never stops. Brickwork volume gives bricks, cement and sand (Building Construction handbook). Plaster area × thickness gives the plaster mortar, and hence its cement and sand. Paint area ÷ coverage gives litres of paint. Every measured quantity is one multiplication away from a material order — which is the whole practical point of the takeoff." },
            { k: "eg", title: "Example 7.1 — Floor, skirting and paint for one room",
              given: "Room 4.0 × 3.0 m internally, 3.0 m high, one door 1.0 × 2.1 m and one window 1.2 × 1.0 m. Floor tiles, 100 mm skirting, two coats of emulsion on walls (plastered) and ceiling.",
              steps: [
                { t: "Flooring (m²)", w: "4.0 × 3.0 = 12.00 m²" },
                { t: "Skirting (running m)", w: "perimeter 2(4.0 + 3.0) = 14.0 m, less the door width 1.0 m → 13.0 m" },
                { t: "Wall painting (m²) — plaster-style deductions assumed here; painting has its own part of IS 1200, so check it", w: "gross 14.0 × 3.0 = 42.00 m²; door 2.10 and window 1.20 are each 0.5–3 m² → deduct (one face, the room side) 3.30\nnet 38.70 m² (less the skirting band 13.0 × 0.10 = 1.30 if the skirting is not painted → 37.40 m²)" },
                { t: "Ceiling", w: "4.0 × 3.0 = 12.00 m²" },
              ],
              ans: "Floor 12.00 m², skirting 13.0 m, walls about 37.4 m² and ceiling 12.0 m² of painting. Paint litres = area × coats ÷ the manufacturer's coverage per litre — a figure to take from the product data, not from a textbook." },
          ],
        },
        {
          n: "7.2",
          title: "Deductions that matter",
          hi: "ज़रूरी कटौतियाँ",
          blocks: [
            { k: "p", t: "Finishing quantities are where careless deductions quietly inflate an estimate. A wall full of doors and windows has much less brickwork and plaster than its gross area suggests, and the mode of measurement says exactly how to handle each opening." },
            { k: "trap", t: "Two errors recur. First, measuring plaster over openings and forgetting to deduct them — a house with many windows can be over-measured by a tenth or more this way. Second, over-deducting: the code often says small openings below a threshold are not deducted (the extra work of finishing the reveals roughly balances the material saved), so deducting them is both wrong and wasted effort. Know the threshold." },
            { k: "note", t: "The plaster thresholds (≤ 0.5 m² ignore; 0.5–3 m² one face; > 3 m² both faces plus reveals) and the 0.1 m² brickwork threshold are set out, with a worked wall, in <a href=\"#/read/es/2\">Chapter 2</a>." },
            { k: "real", t: "A contractor's bill and an engineer's check-measure most often differ on exactly these finishing deductions — did the window jamb get plastered, is the reveal measured, was the small ventilator deducted. This is why the mode of measurement is agreed before work starts: it settles in advance whose arithmetic is right. <strong>The disputes are never about the wall — they are about the holes in it.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "es-8",
      n: 8,
      title: "Rate Analysis, Tendering and Valuation",
      hi: "दर विश्लेषण, निविदा और मूल्यांकन",
      blurb: "The second half of the cost equation — what a unit rate is really made of — plus how work is put out to tender and how a finished property's value is assessed.",
      mins: 22,
      sections: [
        {
          n: "8.1",
          title: "Rate analysis — building up a unit rate",
          hi: "दर विश्लेषण",
          blocks: [
            { k: "p", t: "Rate analysis is the other half of cost = quantity × rate. Where the earlier chapters measured the quantity, this one works out the rate: what one unit of finished work — a cubic metre of concrete, a square metre of plaster — actually costs to deliver, all in." },
            { k: "dia", id: "hb-es-rate", cap: "What a unit rate is built up from." },
            { k: "list", items: [
              "<strong>Materials</strong> — the cement, sand, aggregate, steel, bricks in one unit of work, each at its market rate (plus a small wastage allowance).",
              "<strong>Labour</strong> — the mason, mazdoor and other trades needed to place them, from standard task-work outputs.",
              "<strong>Tools, plant, water, sundries</strong> — a small percentage on the above.",
              "<strong>Overheads and profit</strong> — the contractor's establishment costs and margin, a further percentage on top.",
            ] },
            { k: "trap", t: "Comparing a contractor's quoted rate only against the shop price of the materials is a classic misjudgement. Most of the rate is the labour to place the material and the overheads to run the job — the raw material can be well under half the finished rate. A rate that merely covers materials is a rate that bankrupts the contractor, and a client who expects it does not understand rate analysis." },
            { k: "eg", title: "Example 8.1 — Rate for one cubic metre of brickwork in 1:6",
              given: "Illustrative prices: bricks ₹9.50 each, cement ₹390 per bag, sand ₹2,200 per m³, mason ₹600 per day, mazdoor ₹450 per day. Quantities per m³ (Example 2.1 of the Building Construction handbook, with wastage): 540 bricks, 1.47 bags, 0.30 m³ sand; labour 0.55 mason-day and 1.20 mazdoor-days. Contractor's profit and overheads 15%.",
              steps: [
                { t: "Materials", w: "bricks 540 × 9.50 = 5,130\ncement 1.47 × 390 = 573\nsand 0.30 × 2,200 = 660\nsubtotal = ₹6,363" },
                { t: "Labour", w: "mason 0.55 × 600 = 330;  mazdoor 1.20 × 450 = 540\nsubtotal = ₹870" },
                { t: "Cost of work", w: "6,363 + 870 = ₹7,233" },
                { t: "Profit and overheads 15%", w: "7,233 × 1.15 = ₹8,318 per m³" },
              ],
              ans: "About ₹8,320 per m³ — bricks alone are 62% of it, which is why brick price and wastage dominate masonry rates. The structure, and the 15% for profit and overheads, follow the CPWD-style analysis worked by InfraLens; the prices are illustrative only." },
            { k: "note", t: "The unit rates used in examples in this app are illustrative assumptions, not published figures — real rates come from the current market and the project's own schedule (often a state PWD or CPWD Schedule of Rates). The method of building the rate up is what transfers; the numbers must always be taken from the live source." },
          ],
        },
        {
          n: "8.2",
          title: "Specifications and tendering",
          hi: "विशिष्टियाँ और निविदा",
          blocks: [
            { k: "p", t: "An estimate says what a job costs; a specification says what the job actually is, and a tender is how it is competitively priced and awarded. The three work together: you cannot rate work you have not specified, and you cannot fairly tender work you have not estimated." },
            { k: "def", term: "Specification", t: "The written description of the quality of work and materials that the drawings cannot show — the grade of concrete, the class of brick, the number of plaster coats, the workmanship standard. The drawing shows the shape; the specification fixes the quality." },
            { k: "def", term: "Tender", t: "An offer by a contractor to do the specified work for a stated price. Work is put out to tender so that competition sets a fair price; the estimate is the owner's private check on whether the tenders received are reasonable." },
            { k: "real", t: "Drawings, specifications and the bill of quantities form a set, and they must agree — a dispute on site is very often a gap between them (the drawing shows a detail the specification never mentioned, or the BOQ measured work the drawing does not contain). <strong>A good tender package leaves no gap between what is drawn, what is specified, and what is measured</strong>, because every gap becomes a claim." },
          ],
        },
        {
          n: "8.3",
          title: "Valuation — what a finished property is worth",
          hi: "मूल्यांकन",
          blocks: [
            { k: "p", t: "Valuation is a different question from estimating: not what it costs to build, but what a finished, ageing property is worth now — for sale, purchase, loan, rent or tax. Cost looks forward to construction; value looks at the property as it stands, worn by its years of use." },
            { k: "def", term: "Depreciation", t: "The loss in value of a building as it ages and wears. The simplest model is straight-line: the building loses an equal amount of value each year over its useful life, from its construction cost down to its scrap (salvage) value at the end." },
            { k: "eg", title: "Example 8.1 — Straight-line depreciation",
              given: "A building cost ₹20,00,000 to construct, has a useful life of 60 years, and a scrap value of 10% of cost. Find its depreciated value after 20 years.",
              steps: [
                { t: "Scrap value", w: "10% × 20,00,000 = 2,00,000" },
                { t: "Annual depreciation (straight-line)", w: "(cost − scrap) / life\n= (20,00,000 − 2,00,000) / 60\n= 18,00,000 / 60 = 30,000 per year" },
                { t: "Depreciation over 20 years", w: "20 × 30,000 = 6,00,000" },
                { t: "Depreciated value", w: "20,00,000 − 6,00,000 = 14,00,000" },
              ],
              ans: "About ₹14,00,000 after 20 years. Straight-line is the simplest method; others (declining-balance, sinking-fund) age the value on different curves. The land, note, does not depreciate — only the building does — so a full valuation adds the current land value back on top." },
            { k: "eq", expr: "sinking fund instalment  I = S i / [(1 + i)ⁿ − 1]        years' purchase  YP = 1/i (perpetual)  or  1/(i + Ic) for n years        capitalised value = net annual income × YP", where: [
              ["S", "sum to be accumulated (often 90% of the building cost, scrap being 10%)"],
              ["i", "rate of interest; Ic = sinking-fund coefficient i′/[(1 + i′)ⁿ − 1] at the rate the fund earns"],
            ]},
            { k: "eg", title: "Example 8.2 — Sinking fund for a building",
              given: "A building costs ₹30,000, has a future life of 20 years and a scrap value of 10%. The fund earns 4%.",
              steps: [
                { t: "Sum to accumulate", w: "S = 0.9 × 30,000 = ₹27,000" },
                { t: "Annual instalment", w: "I = 27,000 × 0.04/[(1.04)²⁰ − 1] = 1,080/(2.1911 − 1) = 1,080/1.1911 = ₹906.7" },
              ],
              ans: "About ₹907 a year (the RCET notes give ₹907.20 using a rounded table coefficient)." },
            { k: "eg", title: "Example 8.3 — Capitalised value from rent",
              given: "A property yields a net annual income of ₹1,20,000 after all outgoings. The investor expects 6%. Compare (a) a freehold income in perpetuity with (b) a building whose life is 40 years, the sinking fund earning 4%.",
              steps: [
                { t: "(a) Perpetual", w: "YP = 1/0.06 = 16.67  →  value = 1,20,000 × 16.67 = ₹20,00,000" },
                { t: "(b) 40-year life", w: "Ic = 0.04/[(1.04)⁴⁰ − 1] = 0.04/3.801 = 0.01052\nYP = 1/(0.06 + 0.01052) = 14.18  →  value = 1,20,000 × 14.18 = ₹17,01,600" },
              ],
              ans: "₹20.0 lakh in perpetuity against ₹17.0 lakh for a 40-year life — the difference is the cost of replacing the capital as the building wears out." },
            { k: "note", t: "Sinking-fund formula and Example 8.2 from the <a href=\"https://www.rcet.org.in/uploads/academics/rohini_91745128968.pdf\" target=\"_blank\" rel=\"noopener\">RCET valuation notes</a>; YP and capitalised value follow from the definition of years' purchase (the capital that yields ₹1 a year). The CPWD-style rate-analysis structure is from <a href=\"https://infralens.in/knowledge/rate-analysis-from-dsr-10-worked-examples\" target=\"_blank\" rel=\"noopener\">InfraLens</a>." },
            { k: "note", t: "This is only an outline of valuation — the field has its own methods (rental, profit, development and cost approaches) and is properly the province of a qualified valuer. The app gives the estimating engineer's working grasp of it, enough to understand a valuation report, not to replace one." },
          ],
        },
      ],
    },

  );
})();
