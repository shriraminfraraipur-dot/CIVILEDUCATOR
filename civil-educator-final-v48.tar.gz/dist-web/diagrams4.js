/* ============================================================
   CIVIL EDUCATOR — inline SVG diagrams, part 4
   Diagrams attached to code guides (keyed "g-*").
   Uses the mk() / dim() helpers declared in diagrams.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------ WIND: FACTOR CHAIN + UPLIFT */
  "g-wind": {
    label: "From basic wind speed to design pressure",
    svg: `<svg viewBox="0 0 500 268" role="img" aria-label="The chain of factors converting the basic wind speed into a design wind pressure, and a sketch showing wind causing suction on a roof rather than downward pressure">
      ${mk("wd")}
      <rect class="conc" x="24" y="30" width="78" height="34" rx="6"/>
      <text class="lb" x="63" y="44" text-anchor="middle">basic speed</text>
      <text class="em" x="63" y="58" text-anchor="middle">Vb</text>
      <line class="ac" x1="106" y1="47" x2="140" y2="47" marker-end="url(#wd-c)"/>

      <rect class="conc" x="144" y="30" width="128" height="34" rx="6"/>
      <text class="em" x="208" y="52" text-anchor="middle">× k1 k2 k3 k4</text>
      <line class="ac" x1="276" y1="47" x2="310" y2="47" marker-end="url(#wd-c)"/>

      <rect class="conc" x="314" y="30" width="70" height="34" rx="6"/>
      <text class="lb" x="349" y="44" text-anchor="middle">design</text>
      <text class="em" x="349" y="58" text-anchor="middle">Vz</text>
      <line class="ac" x1="388" y1="47" x2="412" y2="47" marker-end="url(#wd-c)"/>
      <text class="em" x="418" y="44">pz =</text>
      <text class="em" x="418" y="60">0.6 Vz²</text>
      <text class="lb" x="250" y="88" text-anchor="middle">k1 risk · k2 terrain &amp; height · k3 topography · k4 importance</text>

      <path class="conc" d="M120 190 L230 140 L340 190 Z"/>
      <rect class="conc" x="140" y="190" width="200" height="54"/>
      <line class="hi" x1="150" y1="200" x2="150" y2="164" marker-end="url(#wd-m)"/>
      <line class="hi" x1="200" y1="176" x2="200" y2="140" marker-end="url(#wd-m)"/>
      <line class="hi" x1="262" y1="176" x2="262" y2="140" marker-end="url(#wd-m)"/>
      <line class="hi" x1="312" y1="200" x2="312" y2="164" marker-end="url(#wd-m)"/>
      <line class="ac" x1="40" y1="150" x2="106" y2="150" marker-end="url(#wd-c)"/>
      <line class="ac" x1="40" y1="172" x2="106" y2="172" marker-end="url(#wd-c)"/>
      <text class="ea" x="36" y="140" text-anchor="end">wind</text>
      <text class="em" x="230" y="120" text-anchor="middle">suction — the roof is pulled UP</text>
      <text class="lb" x="230" y="264" text-anchor="middle">critical case is dead load minus wind, not plus</text>
    </svg>`,
    caption: "Wind on a roof is mostly <strong>suction, not downward pressure</strong>. That is why light roofs fail by uplift and why the holding-down detail — not the purlin size — is usually what decides whether the roof stays on.",
  },

  /* ------------------------------------ FLEXIBLE vs RIGID PAVEMENT */
  "g-pavement": {
    label: "How a flexible and a rigid pavement carry the wheel load",
    svg: `<svg viewBox="0 0 500 262" role="img" aria-label="A flexible pavement spreading the wheel load through successive layers in a narrow cone, beside a rigid concrete slab spreading the same load over a wide area by bending">
      ${mk("pv")}
      <text class="lb" x="120" y="22" text-anchor="middle">flexible (IRC:37)</text>
      <rect class="soft-b" x="20" y="44" width="200" height="22"/>
      <rect class="conc" x="20" y="66" width="200" height="26"/>
      <rect class="conc" x="20" y="92" width="200" height="30"/>
      <rect class="soft" x="20" y="122" width="200" height="60"/>
      <rect class="s" x="20" y="122" width="200" height="60"/>
      <line class="hi" x1="120" y1="20" x2="120" y2="42" marker-end="url(#pv-m)"/>
      <path class="ac" d="M110 44 L62 182" stroke-dasharray="5 4"/>
      <path class="ac" d="M130 44 L178 182" stroke-dasharray="5 4"/>
      <text class="lb" x="234" y="60" text-anchor="start">bituminous</text>
      <text class="lb" x="234" y="84" text-anchor="start">base</text>
      <text class="lb" x="234" y="112" text-anchor="start">sub-base</text>
      <text class="lb" x="234" y="158" text-anchor="start">subgrade</text>
      <text class="em" x="120" y="200" text-anchor="middle">load spreads layer</text>
      <text class="em" x="120" y="216" text-anchor="middle">by layer — subgrade</text>
      <text class="em" x="120" y="232" text-anchor="middle">strength governs</text>

      <text class="lb" x="378" y="22" text-anchor="middle">rigid (IRC:58)</text>
      <rect class="conc" x="300" y="44" width="180" height="34"/>
      <rect class="conc" x="300" y="78" width="180" height="20"/>
      <rect class="soft" x="300" y="98" width="180" height="84"/>
      <rect class="s" x="300" y="98" width="180" height="84"/>
      <line class="hi" x1="390" y1="20" x2="390" y2="42" marker-end="url(#pv-m)"/>
      <path class="ac" d="M330 44 L308 182" stroke-dasharray="5 4"/>
      <path class="ac" d="M450 44 L472 182" stroke-dasharray="5 4"/>
      <line class="dash" x1="360" y1="44" x2="360" y2="78"/>
      <line class="dash" x1="420" y1="44" x2="420" y2="78"/>
      <text class="lb" x="390" y="66" text-anchor="middle">concrete slab</text>
      <text class="lb" x="390" y="93" text-anchor="middle">DLC sub-base</text>
      <text class="em" x="390" y="200" text-anchor="middle">the slab bends and</text>
      <text class="em" x="390" y="216" text-anchor="middle">spreads the load wide —</text>
      <text class="em" x="390" y="232" text-anchor="middle">slab stress governs</text>
    </svg>`,
    caption: "A flexible pavement passes the load down through its layers, so the <strong>subgrade CBR drives the whole thickness</strong>. A rigid slab carries it in bending and spreads it very wide, so the design is about stress in the slab and about where the joints go.",
  },

  /* ------------------------------------ WATERPROOFING UPSTAND */
  "g-waterproof": {
    label: "Where a roof waterproofing actually fails",
    svg: `<svg viewBox="0 0 500 244" role="img" aria-label="Section through a roof parapet showing the membrane turned up behind a chased termination, the slope towards the outlet, and the outlet detail">
      ${mk("wp")}
      <rect class="conc" x="60" y="150" width="380" height="40"/>
      <rect class="conc" x="60" y="60" width="34" height="90"/>
      <path class="soft-b" d="M94 138 L440 152 L440 150 L94 136 Z"/>
      <path class="hi" d="M78 74 L78 98 L94 138 L440 152"/>
      <line class="thin" x1="78" y1="74" x2="150" y2="52"/>
      <text class="em" x="156" y="48">membrane turned up and</text>
      <text class="em" x="156" y="64">terminated in a chase</text>

      <path class="soft" d="M94 136 L440 150 L440 106 L94 106 Z"/>
      <line class="thin" x1="120" y1="112" x2="120" y2="134" marker-end="url(#wp-a)"/>
      <text class="lb" x="200" y="100" text-anchor="middle">screed to falls — 1 in 100 minimum</text>

      <rect class="conc" x="404" y="150" width="14" height="60"/>
      <rect class="conc" x="434" y="150" width="6" height="60"/>
      <line class="ac" x1="411" y1="156" x2="411" y2="206" marker-end="url(#wp-c)"/>
      <line class="thin" x1="418" y1="196" x2="470" y2="212"/>
      <text class="ea" x="474" y="216" text-anchor="end">outlet</text>

      <text class="lb" x="76" y="212" text-anchor="middle">parapet</text>
      <text class="lb" x="250" y="176" text-anchor="middle">roof slab</text>
      <text class="lb" x="250" y="232" text-anchor="middle">failures happen at upstands, outlets and penetrations — not in the middle</text>
    </svg>`,
    caption: "Drain the water first, then seal it out. A membrane on a roof with <strong>no fall</strong> or a <strong>flat-stopped upstand</strong> will leak however many layers it has — and almost every leak starts at a junction, not in the field.",
  },

  /* ------------------------------------ TILE GROUPS */
  "g-tilegroup": {
    label: "Ceramic tile groups by water absorption",
    svg: `<svg viewBox="0 0 500 200" role="img" aria-label="A scale of ceramic tile groups arranged by water absorption from fully vitrified at the left to porous wall tiles at the right, with the appropriate use for each">
      ${mk("tg")}
      <rect class="soft-b" x="30" y="52" width="94" height="34"/>
      <rect class="s" x="30" y="52" width="94" height="34"/>
      <text class="em" x="77" y="74" text-anchor="middle">BIa</text>
      <text class="lb" x="77" y="40" text-anchor="middle">≤ 0.5%</text>
      <text class="lb" x="77" y="108" text-anchor="middle">fully vitrified</text>
      <text class="lb" x="77" y="124" text-anchor="middle">floors, external</text>

      <rect class="soft" x="128" y="52" width="94" height="34"/>
      <rect class="s" x="128" y="52" width="94" height="34"/>
      <text class="em" x="175" y="74" text-anchor="middle">BIb</text>
      <text class="lb" x="175" y="40" text-anchor="middle">0.5 – 3%</text>
      <text class="lb" x="175" y="108" text-anchor="middle">vitrified</text>
      <text class="lb" x="175" y="124" text-anchor="middle">floors</text>

      <rect class="conc" x="226" y="52" width="94" height="34"/>
      <text class="em" x="273" y="74" text-anchor="middle">BIIa / BIIb</text>
      <text class="lb" x="273" y="40" text-anchor="middle">3 – 10%</text>
      <text class="lb" x="273" y="108" text-anchor="middle">semi-vitreous</text>
      <text class="lb" x="273" y="124" text-anchor="middle">light traffic</text>

      <rect class="conc" x="324" y="52" width="94" height="34"/>
      <text class="em" x="371" y="74" text-anchor="middle">BIII</text>
      <text class="lb" x="371" y="40" text-anchor="middle">&gt; 10%</text>
      <text class="lb" x="371" y="108" text-anchor="middle">porous</text>
      <text class="lb" x="371" y="124" text-anchor="middle">walls only</text>

      <line class="ac" x1="30" y1="152" x2="418" y2="152" marker-end="url(#tg-c)"/>
      <text class="ea" x="30" y="174">less absorbed — stronger, denser</text>
      <text class="ea" x="418" y="174" text-anchor="end">more porous</text>
    </svg>`,
    caption: "Water absorption is the property that classifies a ceramic tile and decides where it may be used. <strong>A BIII wall tile on a floor wears through its glaze in months</strong> — and a BIa vitrified tile needs adhesive, not cement slurry, because there is nothing for the slurry to grip.",
  },

});
