/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   Chapter 5 — Effective Stress
   Chapter 6 — Stress Distribution in Soil
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "ge"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 5 */
    {
      id: "ge-5",
      n: 5,
      title: "Effective Stress",
      hi: "प्रभावी प्रतिबल",
      blurb: "The one idea the whole subject rests on — and the reason a slope can fail without anything being added to it.",
      mins: 32,
      sections: [

        {
          n: "5.1",
          title: "Terzaghi's principle",
          hi: "टर्ज़ाघी का सिद्धांत",
          blocks: [
            { k: "p", t: "A column of saturated soil carries the weight of everything above it. But the soil is grains and water, and those two carry it in completely different ways — one through contacts, the other through pressure — and only one of them does any structural work." },
            { k: "dia", id: "hb-ge-effstress", cap: "Total stress is shared between grain contacts and pore water. Only the first does anything." },
            { k: "eq", expr: "σ  =  σ′  +  u", where: [
              ["σ", "total stress — the whole weight per unit area"],
              ["σ′", "effective stress — the part carried at the grain contacts"],
              ["u", "pore water pressure"],
            ]},
            { k: "p", t: "Terzaghi's principle states that <strong>all measurable effects of a change of stress — compression, distortion, change of shearing resistance — are due exclusively to changes in effective stress</strong>. Not to total stress, and not to pore pressure. That single sentence, published in 1925, is what turned soil mechanics from a collection of rules into a subject." },
            { k: "p", t: "The physical reason is simple enough to hold in your head. Water has no shear strength and pushes equally in every direction, so it cannot press one grain against another — it can only hold them apart. Friction between grains needs a normal force at the contact, and only σ′ provides one." },
            { k: "trap", t: "A soil at σ′ = 0 has <strong>no shear strength whatever</strong>, however strong its grains. That is not an abstraction: it is quicksand, it is a boiling excavation base, and it is a liquefying sand layer in an earthquake. In every case the grains are unchanged and the total stress is unchanged — only the sharing moved." },
          ],
        },

        {
          n: "5.2",
          title: "Computing a stress profile",
          hi: "प्रतिबल प्रोफ़ाइल",
          blocks: [
            { k: "steps", items: [
              "Work down from the surface. Total stress at any depth = Σ(unit weight × thickness) of every layer above it, using bulk γ above the water table and saturated γsat below it.",
              "Pore pressure at any depth below the water table = γw × the depth of water above that point, for hydrostatic conditions.",
              "Effective stress = the difference.",
              "Check: σ′ computed that way must equal the sum of γ above the water table and γ′ below it, over the same depths.",
            ]},
            { k: "eg",
              title: "Example 5.1 — A stress profile with a water table",
              given: "Ground profile: 0–2 m dry sand, γ = 17.5 kN/m³; water table at 2 m; 2–6 m sand, γsat = 20.2 kN/m³; 6–9 m clay, γsat = 19.0 kN/m³. Take γw = 9.81 kN/m³.",
              steps: [
                { t: "At 2 m — the water table", w: "σ  = 17.5 × 2 = 35.00 kPa\nu  = 0 (at the water table)\nσ′ = 35.00 kPa" },
                { t: "At 6 m — base of the sand", w: "σ  = 35.00 + 20.2 × 4 = 35.00 + 80.80 = 115.80 kPa\nu  = 9.81 × 4 = 39.24 kPa\nσ′ = 115.80 − 39.24 = 76.56 kPa" },
                { t: "At 9 m — base of the clay", w: "σ  = 115.80 + 19.0 × 3 = 115.80 + 57.00 = 172.80 kPa\nu  = 9.81 × 7 = 68.67 kPa\nσ′ = 172.80 − 68.67 = 104.13 kPa" },
                { t: "The check, via submerged unit weights", w: "γ′ for the sand  = 20.2 − 9.81 = 10.39 kN/m³\nγ′ for the clay  = 19.0 − 9.81 =  9.19 kN/m³\nσ′ at 9 m = 17.5(2) + 10.39(4) + 9.19(3)\n         = 35.00 + 41.56 + 27.57 = 104.13 kPa  ✓" },
              ],
              ans: "σ′ = 35.0, 76.6 and 104.1 kPa at 2, 6 and 9 m. Note the gradients: above the water table σ′ climbs at 17.5 kPa/m, below it at only about 10 — submerged soil generates barely half the effective stress of the same soil above water.",
            },
            { k: "note", t: "That final check is worth doing every time, and it is not just arithmetic hygiene. Computing σ′ directly from γ′ is often quicker than computing σ and u separately — but it only works for <em>hydrostatic</em> pore pressure. The moment there is seepage, the two routes diverge and only σ − u is correct." },
          ],
        },

        {
          n: "5.3",
          title: "What changes σ′ without changing σ",
          hi: "σ बदले बिना σ′ कैसे बदले",
          blocks: [
            { k: "dia", id: "an-ge-wt", cap: "The water table rises. Total stress barely moves, pore pressure grows, effective stress shrinks." },
            { k: "list", items: [
              "<strong>A rising water table</strong> — the classic case, and the one in the figure. u grows, σ barely changes, σ′ falls, and the soil loses strength.",
              "<strong>Seepage</strong> — upward flow reduces σ′, downward flow increases it. This is the quick condition of Chapter 4, seen from the other side.",
              "<strong>Rapid drawdown</strong> — a reservoir level falls quickly. The water outside the slope is gone (σ drops) but the water <em>inside</em> it has not had time to drain (u stays high), so σ′ collapses. Upstream dam slopes fail this way.",
              "<strong>Loading a clay</strong> — the load is carried first entirely by the pore water, and only transfers to the skeleton as water drains. That is Chapter 8.",
              "<strong>Pumping from an aquifer</strong> — lowering the water table raises σ′ over a huge area, which consolidates the ground and causes regional subsidence.",
            ]},
            { k: "eg",
              title: "Example 5.2 — What a rising water table does",
              given: "The sand of Example 5.1 (γ = 17.5 kN/m³ above the water table, γsat = 20.2 kN/m³ below) originally had the water table below 6 m. After a wet season it rises to 2 m below ground. Find σ′ at 6 m before and after.",
              steps: [
                { t: "Before — all dry above 6 m", w: "σ′ = 17.5 × 6 = 105.0 kPa (u = 0)" },
                { t: "After — water table at 2 m", w: "σ′ = 17.5 × 2 + (20.2 − 9.81) × 4 = 35.0 + 41.6 = 76.6 kPa" },
                { t: "Change", w: "(105.0 − 76.6)/105.0 = 27% less effective stress" },
              ],
              ans: "The total stress hardly changed, but σ′ — and with it the frictional strength and bearing capacity of the sand — fell by about a quarter. That is why bearing capacity calculations always ask where the highest water table will be, not where it was on the day of the borehole." },
            { k: "real", t: "Regional subsidence from groundwater pumping is effective stress at city scale. Parts of Mexico City have sunk more than ten metres, and Jakarta and Bangkok are sinking now. Nothing was built on the ground to cause it — <strong>σ was constant and σ′ rose because u fell</strong>, and the clay consolidated exactly as Chapter 8 predicts." },
            { k: "def", term: "Capillary rise", t: "Water drawn above the water table by surface tension. In the capillary zone the pore pressure is <em>negative</em>, so σ′ is <strong>greater</strong> than σ. This is why a damp sand can be cut vertically and a dry one cannot — and why that face collapses the moment it dries or is flooded. Apparent cohesion from capillarity is real, useful and completely unreliable." },
          ],
        },

        {
          n: "5.4",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "σ = σ′ + u, and only σ′ controls strength, compression and settlement.",
              "Water cannot press grains together; it can only hold them apart.",
              "σ′ = 0 means no shear strength, whatever the soil.",
              "Build the profile with γ above the water table and γsat below, then subtract u.",
              "Or use γ′ directly below the water table — but only for hydrostatic conditions.",
              "Almost every geotechnical failure is σ′ changing while σ stays put.",
              "Capillarity gives negative pore pressure and apparent cohesion — real, and not to be relied on.",
            ]},
            { k: "p", t: "Chapters 1 to 5 have dealt with the stresses already in the ground. Chapter 6 adds a new one at the surface and asks how far down it is still felt." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "ge-6",
      n: 6,
      title: "Stress Distribution in Soil",
      hi: "मिट्टी में प्रतिबल वितरण",
      blurb: "How a load at the surface spreads with depth, and why a wide footing reaches deeper than a narrow one.",
      mins: 26,
      sections: [

        {
          n: "6.1",
          title: "The problem, and the assumption behind every solution",
          hi: "समस्या और उसकी मान्यता",
          blocks: [
            { k: "p", t: "A footing applies a pressure at the surface. Settlement and bearing capacity both depend on what that pressure becomes at depth — and the soil is not a column of independent slices, so it is not simply the load divided by the area." },
            { k: "p", t: "Every classical solution treats the soil as an <strong>elastic, homogeneous, isotropic half-space</strong>. None of those three is true of any real soil: soil is not elastic, it is layered rather than homogeneous, and it is usually stiffer horizontally than vertically. The solutions are used anyway, for a reason worth understanding." },
            { k: "note", t: "The reason is that the <em>vertical stress</em> from a surface load turns out to be remarkably insensitive to the stiffness assumed. Displacements are very sensitive — so elastic theory gives poor settlements and acceptable stresses. That is why this chapter's output feeds into Chapter 8's settlement calculation as a stress, and the compressibility comes from a laboratory test instead." },
          ],
        },

        {
          n: "6.2",
          title: "Boussinesq",
          hi: "बूसिनेस्क",
          blocks: [
            { k: "p", t: "Boussinesq solved the case of a single vertical point load on the surface of an elastic half-space in 1885. Everything else in this chapter is that solution integrated over an area." },
            { k: "eq", expr: "σz  =  (3Q / 2πz²) × [1 + (r/z)²]^(−5/2)   =   KB Q / z²", where: [
              ["Q", "the point load"],
              ["z", "depth below the surface"],
              ["r", "horizontal distance from the line of action"],
              ["KB", "the Boussinesq influence factor, a function of r/z alone"],
            ]},
            { k: "p", t: "Two features of that expression are worth noticing. First, <strong>σz does not depend on the soil's elastic constants at all</strong> — E and Poisson's ratio cancel out, which is what makes the result so much more robust than it has any right to be. Second, it depends on r and z only through their <em>ratio</em>, so the stress field is self-similar: the pattern at 2 m depth is the pattern at 1 m, stretched." },
            { k: "eg",
              title: "Example 6.1 — Stress under and beside a point load",
              given: "A concentrated load of 1000 kN acts at the ground surface. Find the vertical stress at a depth of 3.0 m, at a horizontal distance of 1.5 m from the load.",
              steps: [
                { t: "The ratio", w: "r/z = 1.5/3.0 = 0.50" },
                { t: "Influence factor", w: "KB = (3/2π) × [1 + 0.5²]^(−5/2)\n   = 0.4775 × (1.25)^(−2.5)\n   = 0.4775 × 0.5724 = 0.2733" },
                { t: "Vertical stress", w: "σz = KB Q/z² = 0.2733 × 1000/3.0²\n   = 273.3/9 = 30.37 kPa" },
                { t: "Compare with directly beneath the load", w: "at r/z = 0:  KB = 0.4775\nσz = 0.4775 × 1000/9 = 53.06 kPa" },
              ],
              ans: "30.4 kPa at 1.5 m to the side, against 53.1 kPa directly beneath — so moving half a depth sideways loses 43% of the stress. The fall-off is steep: at r/z = 1 the factor is 0.084, and at r/z = 2 it is 0.009.",
            },
            { k: "trap", t: "Boussinesq gives infinite stress at the load itself, because a true point load is a mathematical fiction. Close to a real footing the result is meaningless, and the solution is only used at depths greater than about the footing width. For the stress immediately beneath a footing, use the applied bearing pressure — you already know it." },
            { k: "note", t: "<strong>Westergaard's</strong> solution treats the soil as reinforced by thin, rigid horizontal sheets that prevent lateral strain — a better model for a varved or thinly stratified deposit. It gives lower stresses beneath the load and a wider spread, and it is the more realistic of the two for a layered alluvial clay." },
          ],
        },

        {
          n: "6.3",
          title: "Real footings, and the pressure bulb",
          hi: "वास्तविक फुटिंग और दाब बल्ब",
          blocks: [
            { k: "dia", id: "hb-ge-bulb", cap: "Contours of equal vertical stress beneath a footing, and the depth at which they stop mattering." },
            { k: "list", items: [
              "<strong>Uniformly loaded rectangle</strong> — integrate Boussinesq over the area. The standard result gives σz under a <em>corner</em> as a function of m = B/z and n = L/z, and the stress anywhere else is found by dividing the loaded area into rectangles with a common corner at the point of interest.",
              "<strong>Circular area</strong> — a closed-form result exists for the axis.",
              "<strong>Irregular area</strong> — <strong>Newmark's influence chart</strong>: a set of concentric circles and radial lines, each of the resulting figures contributing the same small fraction of the stress. Draw the footing on tracing paper at a scale set by the depth, lay it on the chart, and count the figures it covers.",
            ]},
            { k: "eq", expr: "2 : 1 dispersion (approximate):   Δσz = Q / [(B + z)(L + z)]", where: [
              ["B, L", "width and length of the loaded area; the load is assumed to spread at 2 vertical : 1 horizontal on each side"],
            ]},
            { k: "eg",
              title: "Example 6.2 — Quick estimate against Boussinesq",
              given: "A 2.0 m × 2.0 m footing carries 1000 kN. Estimate the vertical stress increase 3.0 m below its centre.",
              steps: [
                { t: "2 : 1 method (average over the spread area)", w: "Δσ = 1000/[(2 + 3)(2 + 3)] = 1000/25 = 40.0 kPa" },
                { t: "Boussinesq, treating the load as a point (Example 6.1)", w: "σz = 0.4775 × 1000/3.0² = 53.1 kPa — directly beneath" },
              ],
              ans: "40 kPa average against 53 kPa on the centre line. The 2 : 1 figure is an average over a widening area, so it under-states the centre-line stress and over-states it at the edges — fine for a first estimate, not for the critical point." },
            { k: "def", term: "Pressure bulb", t: "A contour of equal vertical stress beneath a footing. Conventionally the significant depth is taken as the 0.1q or 0.2q contour, which for a square footing lies at roughly 1.5 to 2 times the footing width." },
            { k: "trap", t: "That scaling with B is the thing to carry away. Two footings at the same bearing pressure, 1 m and 4 m wide, stress the soil to about 1.5 m and 6 m respectively. <strong>The wide one may settle several times more</strong>, because it reaches a compressible layer the narrow one never touches — and a borehole stopped at 3 m would have found the good ground and missed the problem entirely." },
            { k: "real", t: "This is why a site investigation is specified by the <em>foundation</em>, not by the site. The standard rule is to take boreholes to at least 1.5 times the width of the largest loaded area, or until a stratum of adequate bearing is proved to sufficient depth — whichever is deeper. A raft 20 m across needs information 30 m down." },
          ],
        },

        {
          n: "6.4",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Elastic theory gives acceptable stresses and poor displacements — use it for the first, not the second.",
              "σz = KB Q/z², and KB depends only on r/z.",
              "Vertical stress is independent of E and ν, which is why it survives the bad assumptions.",
              "KB: 0.478 at r/z = 0, 0.273 at 0.5, 0.084 at 1.0, 0.009 at 2.0.",
              "Westergaard suits thinly layered deposits better than Boussinesq.",
              "Newmark's chart handles any shape of loaded area.",
              "Significant depth ≈ 1.5 to 2 × B. A wide footing reaches far deeper than a narrow one.",
            ]},
            { k: "p", t: "Chapter 7 leaves natural ground for a moment and deals with soil that is placed rather than found — where the engineer chooses the density instead of measuring it." },
          ],
        },
      ],
    }

  );
})();
