/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: TRANSPORTATION ENGINEERING · Ch 6–8
   Flexible pavement · Rigid pavement · Railways, airports & docks
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "tr");
  if (!hb) { console.error("[tr3] handbook tr not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "tr-6",
      n: 6,
      title: "Flexible Pavement Design",
      hi: "लचीला फुटपाथ डिज़ाइन",
      blurb: "How a bitumen pavement carries a wheel by spreading it through layers to the soil, what each layer does, and why the design comes down to two numbers.",
      mins: 22,
      sections: [
        {
          n: "6.1",
          title: "How a flexible pavement works",
          hi: "लचीला फुटपाथ कैसे काम करता है",
          blocks: [
            { k: "p", t: "A flexible pavement has almost no bending strength of its own. It carries a wheel load by spreading it — the load enters a small tyre contact area at the top and fans out through successively lower, weaker layers in a widening cone, until at the subgrade it is spread thin enough for the soil to bear. The layers get cheaper and weaker as you go down, because the stress they must carry falls with depth." },
            { k: "dia", id: "hb-tr-flexrigid", cap: "How flexible and rigid pavements carry the same wheel." },
            { k: "list", items: [
              "<strong>Wearing course</strong> — the top bituminous surface: takes the tyre contact, resists abrasion, sheds water. Thin but tough.",
              "<strong>Base course</strong> — the main load-spreading layer, strong crushed stone (often bituminous or granular).",
              "<strong>Sub-base</strong> — cheaper granular material continuing the spread and providing drainage.",
              "<strong>Subgrade</strong> — the compacted natural soil that finally receives the spread-out load. Its CBR sets the design.",
            ] },
            { k: "note", t: "Because each layer only has to spread the load enough for the next one down, you use expensive strong material only where the stress is high (near the top) and cheap material lower down. That layering is the whole economy of a flexible pavement — strength is placed exactly where it is needed and nowhere else." },
            { k: "eg", title: "Example 6.1 — Standard axles and the fourth-power law",
              given: "The standard axle is 80 kN. A day's traffic in one lane includes 200 axles of 120 kN (overloaded trucks) and 2000 axles of 40 kN (light vehicles).",
              steps: [
                { t: "Damage per axle, relative to standard", w: "120 kN: (120/80)⁴ = 1.5⁴ = 5.06\n40 kN:  (40/80)⁴ = 0.5⁴ = 0.0625" },
                { t: "Standard axles per day", w: "200 × 5.06 = 1012\n2000 × 0.0625 = 125" },
              ],
              ans: "The 200 overloaded axles do eight times the damage of ten times as many light ones. This is the arithmetic behind the vehicle damage factor F in the msa formula of Chapter 4." },
          ],
        },
        {
          n: "6.2",
          title: "Two numbers set the thickness",
          hi: "मोटाई दो संख्याओं से तय",
          blocks: [
            { k: "p", t: "For all its layers, a flexible pavement design comes down to two inputs: how much traffic the road will carry over its life, and how strong the soil beneath is. Everything else reads off charts from these two." },
            { k: "cmp", t: "The two design inputs",
              cols: ["Design traffic (msa)", "Subgrade CBR (%)"],
              rows: [
                ["Measures", "total wheel-load damage over life", "strength of the soil below"],
                ["From", "traffic count, growth, life, VDF", "soaked CBR test"],
                ["More of it means", "thicker pavement", "thinner pavement"],
                ["Chapter", "Chapter 4", "Chapter 4"],
              ] },
            { k: "p", t: "With the msa and the CBR, IRC 37 gives the total pavement thickness and the thickness of each layer directly from design charts (or catalogue). The engineer's judgement goes into the inputs — honest traffic growth, the soaked CBR, sensible material choices — and the charts do the rest. Get the inputs wrong and no amount of thickness saves the road." },
            { k: "trap", t: "The two commonest ways a flexible pavement is under-designed are both input errors: optimistic traffic growth (the road carries far more heavy vehicles than assumed, especially with overloading and the fourth-power law), and an over-generous CBR (tested dry, or not soaked). Both make the pavement look adequate on paper and fail early in the ground." },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "tr-7",
      n: 7,
      title: "Rigid Pavement Design",
      hi: "कठोर फुटपाथ डिज़ाइन",
      blurb: "The concrete slab that bridges over the soil, why it needs joints, and how it compares with flexible pavement over a whole life.",
      mins: 20,
      sections: [
        {
          n: "7.1",
          title: "A slab that bridges the soil",
          hi: "मिट्टी पर पुल जैसा स्लैब",
          blocks: [
            { k: "p", t: "A rigid pavement is a concrete slab, and it carries load in the opposite way to a flexible one. Instead of passing the wheel load down to the soil, the slab has real bending strength of its own — it bridges over the subgrade like a beam, carrying the load in flexure and spreading it over a wide area before the ground feels it. The soil barely matters to the slab's strength; the concrete's flexural strength is what governs." },
            { k: "def", term: "Wheel-load stress in a slab", t: "The critical stresses in a rigid pavement are bending (flexural) stresses in the concrete, worst when the wheel is at a corner, an edge, or the interior of the slab. The design ensures the concrete's flexural strength is not exceeded under the repeated load — a fatigue problem, since the slab is bent millions of times." },
            { k: "p", t: "Temperature adds a second load the flexible pavement never feels. Sun warms the top of the slab more than the bottom, so it tries to curl; at night it reverses. This warping fights the slab's own weight and adds bending stress — so a rigid pavement is designed for wheel load and temperature warping together." },
            { k: "eq", expr: "radius of relative stiffness   l = [ E h³ / (12 (1 − μ²) k) ]^¼", where: [
              ["E, μ", "modulus and Poisson's ratio of the concrete"],
              ["h", "slab thickness"],
              ["k", "modulus of subgrade reaction"],
            ]},
            { k: "eg", title: "Example 7.1 — How far does a slab spread a wheel load?",
              given: "Slab 300 mm thick, E = 30,000 N/mm², μ = 0.15, on a subgrade with k = 0.06 N/mm³ (60 MPa/m). (Westergaard's parameter — classical slab-on-grade theory, general engineering knowledge.)",
              steps: [
                { t: "Substitute", w: "E h³ = 30,000 × 300³ = 8.10 × 10¹¹\n12(1 − 0.15²)k = 12 × 0.9775 × 0.06 = 0.7038\nl = (8.10 × 10¹¹/0.7038)^¼ = (1.151 × 10¹²)^¼ = 1036 mm" },
              ],
              ans: "l ≈ 1.04 m: the slab spreads a wheel load over a region several metres across — the reason a thin concrete slab can sit on soil whose CBR would demand a thick flexible pavement. Every Westergaard stress formula is written in terms of l." },
          ],
        },
        {
          n: "7.2",
          title: "Why a concrete road has joints",
          hi: "जोड़ क्यों",
          blocks: [
            { k: "p", t: "A continuous concrete slab would crack itself apart as it expands in heat, contracts in cold, and shrinks as it cures. So the slab is deliberately divided by joints — planned lines of weakness where the movement is allowed to happen, instead of random cracks appearing wherever the concrete decides." },
            { k: "cmp", t: "The joints and what they allow",
              cols: ["Joint", "What it does"],
              rows: [
                ["Contraction joint", "lets the slab shrink & contract — controls cracking", "transverse, at intervals"],
                ["Expansion joint", "gives room to expand in heat", "gap filled with compressible filler"],
                ["Construction joint", "where one day's pour meets the next", "planned, doweled"],
                ["Longitudinal joint", "controls cracking along the road", "between lanes"],
              ] },
            { k: "real", t: "The regular 'thunk-thunk' you hear driving on an old concrete highway is the tyres crossing the transverse joints — the deliberate breaks that let each slab move. Dowel bars across the joints let the load transfer from one slab to the next while still allowing the gap to open and close. <strong>The joints are not damage; they are the design working.</strong>" },
          ],
        },
        {
          n: "7.3",
          title: "Flexible or rigid?",
          hi: "लचीला या कठोर?",
          blocks: [
            { k: "p", t: "The two pavement types are genuine alternatives, and the choice is a whole-life decision, not just a first-cost one." },
            { k: "cmp", t: "The trade-off",
              cols: ["Flexible (bitumen)", "Rigid (concrete)"],
              rows: [
                ["Carries load by", "spreading to the soil", "bridging over it in bending"],
                ["Design governed by", "subgrade CBR + traffic", "concrete flexural strength"],
                ["Initial cost", "lower", "higher"],
                ["Life & maintenance", "shorter life, frequent upkeep", "long life, little upkeep"],
                ["Repair", "easy — patch & overlay", "hard — replace whole slabs"],
                ["Rides best when", "new", "consistent for decades"],
              ] },
            { k: "note", t: "A flexible pavement is cheaper to build and easy to patch but needs constant attention and periodic resurfacing; a rigid pavement costs more upfront but can last decades with little maintenance. On a heavily trafficked corridor where closing lanes for repair is itself hugely costly, the long-lived rigid pavement often wins over its whole life even though it loses on first cost." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "tr-8",
      n: 8,
      title: "Railways, Airports and Docks",
      hi: "रेलवे, हवाई अड्डे और बंदरगाह",
      blurb: "The other transport modes in outline — how a rail track spreads its load, what makes a runway different from a road, and what a harbour must provide.",
      mins: 18,
      sections: [
        {
          n: "8.1",
          title: "The railway track — a load-spreading system",
          hi: "रेलवे ट्रैक",
          blocks: [
            { k: "p", t: "A railway track is, like a pavement, a system for spreading a concentrated load to the ground — but through a different chain. The steel wheel bears on the rail, the rail spans between sleepers, the sleepers spread the load onto the ballast, and the ballast spreads it onto the formation. Each element hands the load to a wider area, exactly as a flexible pavement's layers do." },
            { k: "list", items: [
              "<strong>Rail</strong> — the steel running surface; a beam carrying the wheel load to the sleepers.",
              "<strong>Sleepers</strong> — hold the two rails to gauge and spread the load to the ballast.",
              "<strong>Ballast</strong> — the stone bed: spreads the load, drains water, and holds the track in place.",
              "<strong>Formation</strong> — the prepared earth (subgrade) beneath, the final recipient of the load.",
            ] },
            { k: "def", term: "Gauge", t: "The clear distance between the inner faces of the two rails. India's broad gauge is 1676 mm. Consistent gauge is what lets rolling stock run over the whole network — a change of gauge means a change of train." },
            { k: "eq", expr: "equilibrium cant   C = G V² / (127 R)   (mm)", where: [
              ["G", "centre-to-centre distance of the rail heads, 1750 mm for broad gauge"],
              ["V, R", "speed in km/h and radius in m"],
            ]},
            { k: "eg", title: "Example 8.1 — Cant on a broad-gauge curve",
              given: "BG Group A route, curve radius 875 m, maximum speed 110 km/h.",
              steps: [
                { t: "Equilibrium cant at 110 km/h", w: "C = 1750 × 110²/(127 × 875) = 21,175,000/111,125 = 190.6 mm" },
                { t: "Limit", w: "maximum cant on BG Group A, B, C routes = 165 mm → provide 165 mm" },
                { t: "Cant deficiency", w: "190.6 − 165 = 25.6 mm ≤ 100 mm (permitted above 100 km/h on Group A and B routes) ✓" },
              ],
              ans: "Provide 165 mm cant; the 26 mm deficiency is carried as unbalanced lateral acceleration, well within the limit. Limits from the Indian Railways Permanent Way Manual; cant excess for slow trains must also be checked (≤ 75 mm on BG)." },
            { k: "note", t: "Cant formula and limits (G = 1750 mm; maximum cant 165 mm, 185 mm in special cases on Group A; deficiency 100 mm above 100 km/h on Group A/B, otherwise 75 mm; cant excess 75 mm) from the <a href=\"https://nfr.indianrailways.gov.in/railwayboard/uploads/codesmanual/IRPWM/PermanentWayManualCh4_data.htm\" target=\"_blank\" rel=\"noopener\">Indian Railways Permanent Way Manual, Ch. 4</a>." },
          ],
        },
        {
          n: "8.2",
          title: "Airports — why a runway is not just a wide road",
          hi: "हवाई अड्डे",
          blocks: [
            { k: "p", t: "A runway carries pavement loads, but the demands that shape it are different from a road's. The loads are enormous but concentrated on very few, very heavy wheels; the 'traffic' is a handful of movements, not a continuous stream; and the geometry is set by aircraft performance, not by sight distance." },
            { k: "list", items: [
              "<strong>Runway length</strong> — set by the most demanding aircraft, and corrected for airport elevation, temperature and gradient (thinner, hotter air needs a longer take-off run).",
              "<strong>Orientation</strong> — aligned with the prevailing wind, because aircraft take off and land into the wind; a wind-rose analysis fixes the direction.",
              "<strong>Pavement</strong> — designed for very heavy but very few wheel loads, so fatigue matters less and single-load capacity matters more than on a road.",
            ] },
            { k: "note", t: "The elevation-and-temperature correction to runway length is a real and sometimes dramatic effect: a hot, high-altitude airport has thinner air, so wings and engines are less effective and the same aircraft needs a substantially longer runway than it would at a cool sea-level field. Geometry here follows physics, not traffic." },
            { k: "eg", title: "Example 8.2 — Correcting a basic runway length",
              given: "Basic runway length 2100 m at sea level, standard conditions. Airport elevation 450 m. Hottest month: mean of daily means T₁ = 25 °C, mean of daily maxima T₂ = 40 °C. Effective gradient 0.5%.",
              steps: [
                { t: "Elevation: +7% per 300 m", w: "2100 × (1 + 0.07 × 450/300) = 2100 × 1.105 = 2320.5 m" },
                { t: "Airport reference temperature", w: "ART = T₁ + (T₂ − T₁)/3 = 25 + 5 = 30 °C" },
                { t: "Standard temperature at 450 m", w: "15 − 0.0065 × 450 = 12.1 °C (standard atmosphere lapse rate, general knowledge)" },
                { t: "Temperature: +1% per °C above standard", w: "2320.5 × (1 + 0.179) = 2736 m" },
                { t: "Check combined elevation + temperature", w: "(2736 − 2100)/2100 = 30.3% < 35% ✓ (no special study needed)" },
                { t: "Gradient: +20% per 1% effective gradient", w: "2736 × (1 + 0.20 × 0.5) = 2736 × 1.10 = 3010 m" },
              ],
              ans: "About 3010 m — 43% longer than the sea-level figure, almost all of it from altitude and heat. Correction rules from the MADE EASY notes on ICAO practice." },
            { k: "note", t: "Correction rules (7% per 300 m; 1% per °C of ART above standard; 20% per 1% effective gradient; review if elevation + temperature exceed 35%) and the ART formula from <a href=\"https://www.madeeasy.in/study/ce/railway-engineering/correction-for-elevation-temperaure-gradient\" target=\"_blank\" rel=\"noopener\">MADE EASY study notes (ICAO corrections)</a>." },
          ],
        },
        {
          n: "8.3",
          title: "Harbours and docks — the water's edge",
          hi: "बंदरगाह और गोदी",
          blocks: [
            { k: "p", t: "A harbour is where transport changes from water to land, and civil engineering provides the shelter and the interface. The work divides into protecting a calm area of water and building the structures that let ships berth and cargo cross the edge." },
            { k: "list", items: [
              "<strong>Breakwater</strong> — a barrier that shelters the harbour from waves, creating calm water for ships to lie safely.",
              "<strong>Wharf / quay / jetty</strong> — the structures ships tie up against and cargo is worked over.",
              "<strong>Dock</strong> — an enclosed body of water for berthing; a dry dock can be pumped out to expose a ship's hull for repair.",
              "<strong>Dredging</strong> — deepening the approach and berths so loaded ships have enough water under the keel.",
            ] },
            { k: "real", t: "The tide sets the hardest problem: a ship must have enough water beneath it at all states of the tide, so berths are dredged deep and, where the tidal range is large, wet docks with gates hold the water level constant so ships stay afloat and level while being worked whatever the tide outside. <strong>The whole harbour is arranged around keeping ships safely afloat at a workable level.</strong>" },
          ],
        },
      ],
    },

  );
})();
