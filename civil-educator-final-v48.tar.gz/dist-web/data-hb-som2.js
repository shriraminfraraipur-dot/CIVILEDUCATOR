/* ============================================================
   STRENGTH OF MATERIALS · COMPLETE NOTES — Chapters 5–7
   Deflection of beams & columns · Core of a section, torsion,
   resilience & springs · Thin/thick cylinders and dams
   Source: handwritten class notes (17 pp), cited as p.N; Ch.5–7 deepened
   in v31–v33 via web research (see claude/research-log-som.md)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "som");
  if (!hb) { console.error("[som2] handbook som not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 5
       v31 — rebuilt through the Phase 1 chapter quality gate. Notes
       blocks kept with (p.N); errors corrected openly; new material
       web-researched and linked. Log: claude/research-log-som.md */
    {
      id: "som-5",
      n: 5,
      title: "Deflection of Beams and Columns",
      hi: "बीम और स्तंभों का विक्षेपण",
      blurb: "The elastic-curve equation and boundary conditions, double integration and Macaulay's method, moment-area and conjugate-beam methods, the standard deflection table (with two corrected rows), superposition and propped cantilevers, static indeterminacy, IS 456 deflection limits, and columns — Euler's derivation and its limit, Rankine's formula and constants, theoretical vs code effective lengths and the IS 456 short-column rule — with 6 worked examples.",
      mins: 55,
      sections: [
        /* ---------------------------------------------- 5.1 */
        {
          n: "5.1",
          title: "Elastic curve, slope–deflection relations and important points",
          hi: "एलास्टिक वक्र, ढाल-विक्षेप संबंध और महत्वपूर्ण बिंदु",
          blocks: [
            { k: "h", t: "📘 Notes — p.12" },
            { k: "def", term: "Elastic line (deflection curve)", t: "The shape of the deflected beam is called the <b>elastic line</b> or deflection curve. (p.12)" },
            { k: "eq", expr: "Curvature = 1/R = M/EI = d²y/dx² = dθ/dx", where: [
              ["R", "radius of curvature"], ["M", "bending moment"], ["EI", "flexural rigidity"],
            ] },
            { k: "p", t: "This is the bending equation of <a href=\"#/read/som/4\">Chapter 4</a> (1/R = M/EI) combined with geometry: for small slopes the curvature of the line y(x) is simply d²y/dx². Everything in this chapter is a way of integrating <b>EI·d²y/dx² = M</b> twice and fixing the two constants from the supports." },
            { k: "eq", expr: "Slope θ = dy/dx  ⇒  EI(dy/dx) = ∫M dx   ;   Deflection y  ⇒  EI(y) = ∫∫M dx" },
            { k: "dia", id: "hb-som-elastic" },
            { k: "cmp", t: "Boundary conditions — what each support tells you", cols: ["Deflection y", "Slope θ"], rows: [
              ["Fixed end", "0", "0"],
              ["Pin / roller", "0", "unknown (usually maximum)"],
              ["Free end", "unknown", "unknown — but M = 0 and F = 0 there"],
              ["Axis of symmetry (symmetric beam and load)", "unknown (maximum)", "0"],
            ] },
            { k: "note", t: "<b>Stiffness (k)</b> = Span/Deflection (also written in the notes as L/y, with a crossed-out/illegible word before it — exact original phrasing uncertain); stiffness also depends on EI. (p.12)" },
            { k: "note", t: "As corrected in <a href=\"#/read/som/1\">§1.6</a>: span/deflection (L/y) is a <b>serviceability ratio</b> — the form in which codes set deflection limits (§5.4) — while stiffness proper is load per unit deflection, e.g. 48EI/L³ for a central load on a simply supported beam." },
            { k: "h", t: "Important points" },
            { k: "list", items: [
              "<b>a) Cantilever</b> — y and θ are <b>maximum at the free end</b>, and <b>zero at the fixed end</b>.",
              "<b>Maxwell's law of reciprocal deflections:</b> y_C (deflection at C due to a load at B) = y_B (deflection at B due to the same load at C). (p.12)",
              "<b>b) Simply supported beam</b> — y is maximum where the slope (θ) changes sign; y = 0 at the support reactions. θ is maximum at the support reactions, and θ = 0 at the point of maximum deflection (y_max).",
              "<b>c) Propped cantilever</b> — deflection at the prop = 0, i.e. the deflection due to the prop (y_p = PL³/3EI) equals the deflection due to the load acting on the cantilever alone (y_max).",
            ] },
            { k: "h", t: "Static indeterminacy (p.12)" },
            { k: "eq", expr: "Static indeterminacy = (No. of unknown reactions) − 3   [available equilibrium equations: ΣFx = 0, ΣFy = 0, ΣM = 0]" },
            { k: "list", items: [
              "No. of unknown reactions ≤ 3 → <b>determinate</b> beam (e.g. fixed support + roller support: 3 − 3 = 0).",
              "No. of unknown reactions &gt; 3 → <b>indeterminate</b> beam (e.g. two fixed-type supports: 4 − 3 = 1, one degree indeterminate).",
            ] },
            { k: "note", t: "<b>Correction to the notes — the two examples.</b> Count the reactions each support provides (§3.4: roller 1, hinge 2, fixed 3). <i>Fixed + roller</i> (a propped cantilever) has 3 + 1 = 4 → <b>1 degree</b> indeterminate, not 0. <i>Two fixed ends</i> have 3 + 3 = 6 → <b>3 degrees</b> (2 if axial forces are ignored), not 1. A determinate example is <i>hinge + roller</i> (simply supported): 2 + 1 = 3 → 0. Also, 'fewer than 3 reactions' is not 'determinate' but a <b>mechanism</b> (unstable). (General engineering knowledge; counting from §3.4.)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice the pattern: for a cantilever the fixed end pins both y and θ to zero, so everything is free to grow towards the tip. For a simply supported beam the supports pin only y to zero, so θ is largest exactly there and dies to zero at the point of maximum sag — which is also where the slope changes sign. Maxwell's reciprocal law is just Betti's theorem in disguise: swap the load point and the read-out point and the deflection is unchanged, which is a fast cross-check in a multi-load problem." },
            { k: "trap", t: "In a propped cantilever, do not confuse 'deflection at the prop = 0' with 'deflection is zero everywhere' — it only fixes one point. The standard trick is to treat the propped cantilever as a plain cantilever plus an unknown prop force P, and solve P by equating the two deflections at the prop location (p.12)." },
          ],
        },

        /* ---------------------------------------------- 5.2 */
        {
          n: "5.2",
          title: "Double integration and Macaulay's method",
          hi: "द्वि-समाकलन और मैकाले विधि",
          blocks: [
            { k: "h", t: "📘 Notes — p.12" },
            { k: "h", t: "Double integration method (p.12)" },
            { k: "eq", expr: "∫(x−a)² dx = ∫(x²−2ax+a²) dx = x³/3 − 2ax²/2 + a²x + C = x³/3 − ax² + a²x + C     ;     ∫(x−a) dx = x²/2 − ax + C" },
            { k: "h", t: "Macaulay's integration method (p.12)" },
            { k: "eq", expr: "∫(x−a)² dx = (x−a)³/3 + C     ;     ∫(x−a) dx = (x−a)²/2 + C" },
            { k: "note", t: "Constants of integration are found from the boundary conditions, and by convention the constant is <b>added to the first term only</b>. (p.12)" },
            { k: "note", t: "<b>What that convention really means.</b> In Macaulay's method each bracket [x − a] is integrated <i>as a bracket</i> (never expanded), and the constants of integration are written <b>once</b>, outside all brackets — i.e. they belong to the first, bracket-free segment (x &lt; a). Because the brackets are integrated whole, the constants are automatically the same for every segment of the beam, which is the whole advantage of the method. Expanding the bracket, as in the notes' double-integration line, also works but then each segment needs its own constants." },
            { k: "steps", items: [
              "Write ONE moment expression for a section in the last segment, measuring x from the left end, with every load beyond a point a written as W[x − a] or w[x − a]²/2. A UDL that stops before the end is added and then cancelled with a negative UDL.",
              "EI·y'' = M. Integrate twice, keeping brackets intact: EI·y' = … + C₁, EI·y = … + C₁x + C₂.",
              "Apply boundary conditions (§5.1). When x is less than a, the bracket [x − a] is simply dropped (it is zero), not given a negative value.",
              "Find the maximum deflection where y' = 0 — check which segment it falls in.",
            ] },
            { k: "eg", title: "Worked example 5.1 — deriving 5wL⁴/384EI and checking an IS 456-type limit", given: "Simply supported beam, span L, UDL w. Then: L = 6 m, w = 10 kN/m, E = 2 × 10⁵ N/mm², I = 1.0458 × 10⁸ mm⁴ (the I-section of Worked example 4.6). Find: the deflection equation, mid-span deflection, and compare with span/250 and span/350.", steps: [
              { t: "Moment and first integration", w: "M = (wL/2)x − wx²/2\nEI·y' = wLx²/4 − wx³/6 + C₁" },
              { t: "Second integration and boundary conditions", w: "EI·y = wLx³/12 − wx⁴/24 + C₁x + C₂\ny(0) = 0 ⇒ C₂ = 0;  y(L) = 0 ⇒ C₁ = −wL³/24" },
              { t: "Mid-span", w: "EI·y(L/2) = wL⁴/96 − wL⁴/384 − wL⁴/48 = −5wL⁴/384  ✔ (downward)" },
              { t: "Numbers (w = 10 N/mm)", w: "y = 5 × 10 × 6000⁴ / (384 × 2 × 10⁵ × 1.0458 × 10⁸) = 8.07 mm" },
              { t: "Limits", w: "span/250 = 24 mm;  span/350 = 17.1 mm (and ≤ 20 mm)" },
            ], ans: "y_max = 5wL⁴/384EI = 8.07 mm — within both limits. Interpretation: the 5/384 is not magic — it falls straight out of two integrations and two boundary conditions. (IS 456 limits apply to RCC; they are used here only to show the scale of acceptable deflection.)" },
            { k: "eg", title: "Worked example 5.2 — Macaulay's method for an off-centre point load", given: "Simply supported beam AB, 6 m span, W = 60 kN at 2 m from A. EI = 20 916 kN·m² (same section). Find: deflection under the load, and the maximum deflection and its position.", steps: [
              { t: "Reactions", w: "R_A = 60 × 4/6 = 40 kN;  R_B = 20 kN" },
              { t: "One Macaulay expression (x from A, in m)", w: "EI·y'' = 40x − 60[x − 2]\nEI·y' = 20x² − 30[x − 2]² + C₁\nEI·y = (20/3)x³ − 10[x − 2]³ + C₁x + C₂" },
              { t: "Boundary conditions", w: "y(0) = 0 ⇒ C₂ = 0 (bracket dropped)\ny(6) = 0 ⇒ 1440 − 640 + 6C₁ = 0 ⇒ C₁ = −133.33" },
              { t: "Under the load (x = 2)", w: "EI·y = 53.33 − 266.67 = −213.33 kN·m³  (check Wa²b²/3L = 60 × 4 × 16/18 = 213.33 ✔)\ny = 213.33/20 916 = 0.0102 m = 10.2 mm" },
              { t: "Maximum: y' = 0 in the longer segment (x > 2)", w: "20x² − 30(x − 2)² − 133.33 = 0 ⇒ x² − 12x + 25.33 = 0 ⇒ x = 2.734 m\nEI·y = 136.25 − 3.96 − 364.53 = −232.25 ⇒ y = 11.1 mm" },
            ], ans: "10.2 mm under the load; maximum 11.1 mm at 2.73 m from A — between the load and mid-span, on the longer side. Cross-check: MATHalino's tabulated δ_max = Pb(L² − b²)^{3/2}/(9√3·EIL) with b = 2 m (the shorter segment) gives 232.25/EI ✔ (source in the note below)." },
            { k: "note", t: "Off-centre point-load formulas cross-checked against <a href=\"https://mathalino.com/node/1096\" target=\"_blank\" rel=\"noopener\">MATHalino — method of superposition</a>; in that formula b is the <i>shorter</i> distance from the load to a support and x is measured from the <i>far</i> support." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "All three methods solve the same EI·d²y/dx² = M equation, only the bookkeeping differs. <b>Moment-area</b> works directly with the area and centroid of the BMD — fast when you only need slope/deflection at one point. <b>Double integration</b> needs a separate moment expression (and separate constants) for every segment where the loading changes. <b>Macaulay's method</b> is the fix for that: writing every term as (x−a)ⁿ and integrating term by term lets one single expression cover the whole beam, with terms before 'a' switched off automatically." },
            { k: "trap", t: "The single most common slip in Macaulay's method: adding the boundary-condition constant C to every integrated term instead of only the first one. Also remember a (x−a)ⁿ term is dropped (not evaluated) whenever x &lt; a. Aur bracket ko kabhi expand mat karo — expand kiya to Macaulay ka fayda khatam." },
          ],
        },

        /* ---------------------------------------------- 5.3 */
        {
          n: "5.3",
          title: "Moment-area and conjugate-beam methods",
          hi: "मोमेंट-एरिया और संयुग्मी बीम विधियाँ",
          blocks: [
            { k: "h", t: "Moment-area method (p.12)" },
            { k: "eq", expr: "Slope θ = A/EI   ;   Deflection y = A·x̅/EI", where: [
              ["A", "area of the bending moment diagram (BMD)"],
              ["A·x̅", "first moment of area of the BMD"],
              ["x̅", "distance from the point of maximum slope to the centroid (C.G.) of the BMD"],
            ] },
            { k: "note", t: "<b>Stating the two theorems precisely</b> (derived from dθ = (M/EI)dx): <b>(1)</b> the <i>change</i> in slope between two points A and B equals the area of the M/EI diagram between them; <b>(2)</b> the vertical distance of B from the tangent drawn at A (the 'tangential deviation' t_B/A) equals the first moment of that same area <b>taken about B</b> — the point whose deviation you want. The notes' x̄ 'from the point of maximum slope' works for a cantilever only because there the tangent at the fixed end is horizontal, so the deviation of the tip from it is the tip deflection itself, and x̄ is measured from the tip." },
            { k: "dia", id: "hb-som-momarea" },
            { k: "eg", title: "Worked example 5.3 — cantilever tip slope and deflection by moment-area", given: "Cantilever, L = 3 m, W = 10 kN at the free end, EI = 20 916 kN·m². Find: tip slope and deflection.", steps: [
              { t: "BMD — a triangle, WL = 30 kN·m at the fixed end, zero at the tip", w: "Area A = ½ × 3 × 30 = 45 kN·m²" },
              { t: "Theorem 1 (tangent at the fixed end is horizontal)", w: "θ_B = A/EI = 45/20 916 = 2.15 × 10⁻³ rad" },
              { t: "Theorem 2 — first moment about the tip B; centroid is 2L/3 = 2 m from B", w: "y_B = A·x̄/EI = 45 × 2/20 916 = 4.30 × 10⁻³ m = 4.30 mm" },
              { t: "Check with the table", w: "WL³/3EI = 10 × 27/3/20 916 = 4.30 mm ✔;  WL²/2EI = 2.15 × 10⁻³ ✔" },
            ], ans: "θ = 0.00215 rad, y = 4.30 mm. Interpretation: no integration constants at all — the fixed end's horizontal tangent does the work." },
            { k: "h", t: "📘 Conjugate-beam method" },
            { k: "p", t: "Mohr's second graphical idea: build an imaginary <b>conjugate beam</b> of the same length, load it with the real beam's <b>M/EI diagram</b>, and then: <b>slope in the real beam = shear in the conjugate beam; deflection in the real beam = bending moment in the conjugate beam</b> (<a href=\"https://mathalino.com/node/1704\" target=\"_blank\" rel=\"noopener\">MATHalino — conjugate beam method</a>). Supports change so that these equalities hold at the ends:" },
            { k: "cmp", t: "Real support → conjugate support", cols: ["Conjugate beam", "Why"], rows: [
              ["Simple support (pin/roller)", "Simple support", "real y = 0 → conjugate M = 0; real θ ≠ 0 → conjugate V ≠ 0"],
              ["Fixed end", "Free end", "real y = θ = 0 → conjugate M = V = 0"],
              ["Free end", "Fixed end", "real y, θ ≠ 0 → conjugate needs M, V ≠ 0"],
              ["Interior support", "Interior hinge", "real y = 0 but θ continuous → conjugate M = 0, V continuous"],
            ] },
            { k: "note", t: "The first two rows are as given by MATHalino; the last two follow from the same logic (the same rule applied in reverse), and are the standard textbook table." },
            { k: "eg", title: "Worked example 5.4 — WL²/16EI and WL³/48EI by the conjugate beam", given: "Simply supported beam, span L, central point load W. Find: support slope and central deflection.", steps: [
              { t: "Conjugate beam: also simply supported, loaded with the M/EI triangle of peak WL/4EI at mid-span", w: "Total conjugate load = ½ × L × WL/4EI = WL²/8EI" },
              { t: "Conjugate reaction = real support slope", w: "θ_A = ½ × WL²/8EI = WL²/16EI ✔" },
              { t: "Conjugate moment at mid-span = real central deflection", w: "y_C = θ_A × L/2 − (WL²/16EI) × (L/6)\n    = WL³/32EI − WL³/96EI = WL³/48EI ✔" },
            ], ans: "θ = WL²/16EI, y = WL³/48EI — both table entries reproduced. (L/6 is the distance from mid-span to the centroid of the half-triangle load.)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Moment-area aur conjugate beam dono ek hi baat ko do tareeke se kehte hain: M/EI ko 'load' samjho — uska area slope deta hai, area ka moment deflection. Conjugate beam mein bas yeh calculation SFD/BMD ki tarah ho jaati hai jo tum Chapter 3 mein seekh chuke ho." },
            { k: "trap", t: "Conjugate beam mein fixed ↔ free ulta hota hai — sabse common galti yahi hai. Moment-area mein first moment hamesha us point ke baare mein lo jiska deviation chahiye." },
          ],
        },

        /* ---------------------------------------------- 5.4 */
        {
          n: "5.4",
          title: "Standard deflection table, superposition, propped cantilevers and deflection limits",
          hi: "मानक विक्षेपण तालिका, अध्यारोपण, प्रॉप्ड कैंटिलीवर और सीमाएँ",
          blocks: [
            { k: "h", t: "📘 Notes — p.13" },
            { k: "cmp", t: "Standard cases (L = span length) (p.13)", cols: ["Max slope θ_max", "Max deflection y_max", "Max SF (F)", "Max BM (M)"], rows: [
              ["Cantilever, moment M at free end", "ML/EI", "ML²/2EI", "0", "M"],
              ["Simply supported, moment M at centre", "ML/8EI", "ML²/24EI", "M/L", "M"],
              ["Cantilever, point load W at free end", "WL²/2EI", "WL³/3EI", "W", "WL"],
              ["Simply supported, point load W at centre", "WL²/16EI", "WL³/48EI", "W/2", "WL/4"],
              ["Cantilever, point load W at distance a from fixed end", "θ_A = Wa²/2EI", "y_A = Wa³/3EI", "W", "Wa"],
              ["Cantilever, UDL w over full span", "wL³/6EI", "wL⁴/8EI", "wL", "wL²/2"],
              ["Simply supported, UDL w over full span", "wL³/24EI", "5wL⁴/384EI", "wL/2", "wL²/8"],
              ["Cantilever, triangular (varying) load, 0 at fixed end to w at free end", "wL³/24EI", "wL⁴/30EI", "wL/2", "wL²/6"],
            ] },
            { k: "note", t: "<b>Correction 1 — 'simply supported, moment M at centre'.</b> That row does not match a couple at mid-span. With a couple M at the centre the reactions are M/L (a couple), the BMD jumps from −M/2 to +M/2, so the <b>maximum BM is M/2</b>; the beam deflects antisymmetrically (zero at the centre), each half behaving like a simply supported half-span with an end moment M/2. Using MATHalino's end-moment case (θ = Ml/3EI and Ml/6EI, δ_max = Ml²/9√3EI) on each half gives: <b>θ at the supports = ML/24EI, θ at the centre = ML/12EI, δ_max = ML²/(72√3·EI) ≈ 0.0080 ML²/EI</b> at 0.289L from each support. For a couple M at <b>one end</b> of a simply supported beam: θ = ML/3EI (at that end), ML/6EI (other end), δ_max = ML²/(9√3·EI) at L/√3 from the end without the couple, F = M/L, M_max = M. For <b>equal and opposite end couples</b> (uniform bending): θ = ML/2EI, δ = ML²/8EI. Derived and cross-checked with <a href=\"https://mathalino.com/node/1096\" target=\"_blank\" rel=\"noopener\">MATHalino</a>." },
            { k: "note", t: "<b>Correction 2 — the triangular-load cantilever.</b> wL³/24EI, wL⁴/30EI and M = wL²/6 belong to the load that is <b>maximum (w) at the fixed end and zero at the free end</b> (MATHalino, same page). The opposite case — zero at the fixed end, w at the free end — gives θ = wL³/8EI, y = 11wL⁴/120EI and M = wL²/3 (derived: it equals a full UDL minus the first case: wL⁴/8 − wL⁴/30 = 11wL⁴/120)." },
            { k: "cmp", t: "Two more cases worth knowing", cols: ["Result", "Source"], rows: [
              ["Cantilever, W at a from fixed end — TIP deflection", "Wa²(3L − a)/6EI = Wa³/3EI + (Wa²/2EI)(L − a)", "MATHalino; second form = table rows combined"],
              ["SS beam, W at a from A, b from B (a > b)", "y under load = Wa²b²/3EIL;  y_max = Wb(L² − b²)^{3/2}/(9√3·EIL) at √((L² − b²)/3) from the support farther from the load", "MATHalino; Worked example 5.2"],
            ] },
            { k: "h", t: "Two additional standard cases — propped cantilever (p.13)" },
            { k: "eq", expr: "Propped cantilever, point load W at midspan, prop at the far end:   P = 5W/16   ;   point of contraflexure = 8L/11 from the prop" },
            { k: "eq", expr: "Propped cantilever, UDL w over full span, prop at the far end:   P = 3wL/8   ;   point of contraflexure = 3L/4 from the prop" },
            { k: "p", t: "Both are checked by <b>superposition</b>: remove the prop, find the cantilever's tip deflection under the load, then find the prop force P whose own tip deflection PL³/3EI cancels it. For a UDL: wL⁴/8EI = PL³/3EI ⇒ P = 3wL/8 ✔. For a central load: tip deflection of a cantilever loaded at L/2 = W(L/2)²(3L − L/2)/6EI = 5WL³/48EI = PL³/3EI ⇒ P = 5W/16 ✔. Contraflexure points: setting M = 0 gives 3L/4 and 8L/11 from the prop ✔ (derived)." },
            { k: "eg", title: "Worked example 5.5 — propped cantilever with a UDL", given: "Propped cantilever, span 6 m, UDL 10 kN/m. Find: prop reaction, fixed-end moment, maximum sagging moment and where it occurs.", steps: [
              { t: "Prop reaction (superposition, above)", w: "P = 3wL/8 = 3 × 10 × 6/8 = 22.5 kN" },
              { t: "Fixed-end moment", w: "M_fixed = P·L − wL²/2 = 135 − 180 = −45 kN·m = −wL²/8 (hogging)" },
              { t: "Maximum sagging — where shear is zero, x from the prop", w: "22.5 − 10x = 0 ⇒ x = 2.25 m (= 3L/8)\nM = 22.5 × 2.25 − 10 × 2.25²/2 = 25.31 kN·m (= 9wL²/128)" },
              { t: "Contraflexure", w: "22.5x − 5x² = 0 ⇒ x = 4.5 m = 3L/4 from the prop ✔" },
            ], ans: "Prop 22.5 kN; fixed-end moment 45 kN·m hogging; max sagging 25.3 kN·m at 2.25 m from the prop; contraflexure at 4.5 m. Interpretation: adding one prop cuts the cantilever's 180 kN·m support moment to 45 — the reason continuous and propped construction is so economical." },
            { k: "h", t: "📘 How much deflection is acceptable — code limits" },
            { k: "list", items: [
              "<b>IS 456 cl. 23.2 (RCC):</b> final deflection under all loads, including temperature, creep and shrinkage ≤ <b>span/250</b>; deflection after partitions and finishes are in place ≤ <b>span/350 or 20 mm, whichever is less</b> (<a href=\"https://infralens.in/handbook/beam-deflection-limits\" target=\"_blank\" rel=\"noopener\">InfraLens</a>; the second limit also confirmed by <a href=\"https://testbook.com/question-answer/as-per-is-456-2000-the-acceptable-value-of-defle--69eb89031ee56e81a226bae7\" target=\"_blank\" rel=\"noopener\">Testbook</a>).",
              "<b>IS 456 cl. 23.2.1 — the shortcut used in practice:</b> instead of calculating deflection, RCC beams and slabs are given a minimum depth through a basic span/effective-depth ratio — <b>7 for cantilevers, 20 for simply supported, 26 for continuous</b> members (spans up to 10 m), then modified for steel percentage and flanges (<a href=\"https://infralens.in/handbook/slab-span-depth-ratios\" target=\"_blank\" rel=\"noopener\">InfraLens</a>; same values in <a href=\"https://frontdesk.co.in/forum/printthread.php?tid=3650\" target=\"_blank\" rel=\"noopener\">FrontDesk</a>). Why a depth ratio controls deflection: for a simply supported beam with UDL, combining y = 5wL⁴/384EI with f = M·(d/2)/I gives <b>y/L = (5/24)·(f/E)·(L/d)</b> (derived) — at a given working stress, limiting L/d limits y/L.",
              "<b>IS 800:2007 Table 6 (steel):</b> limits depend on member type and what it supports — far stricter for crane girders (e.g. span/500 for manually operated cranes, span/1000 for heavy electric overhead cranes) than for ordinary roof members (InfraLens, same page). Check the table for the exact case.",
            ] },
            { k: "note", t: "<b>Conflict noted between sources:</b> Testbook calls span/250 the limit for '<i>immediate</i>' deflection; InfraLens (and the wording of IS 456 cl. 23.2(a)) make it the <b>final</b> deflection including long-term effects. This handbook follows the latter — check the clause text itself." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Compare the point-load case at midspan: a simply supported beam deflects WL³/48EI, a cantilever of the same span under the same end load deflects WL³/3EI — sixteen times more, because the cantilever has only one support fighting the load instead of two, and the full moment arm to boot. This table is worth memorising rather than re-deriving every time, since it recurs constantly in superposition problems." },
            { k: "trap", t: "Keep the cantilever and simply-supported columns of this table strictly separate — the two most-confused pairs are WL³/3EI vs WL³/48EI (point load) and wL⁴/8EI vs 5wL⁴/384EI (UDL). A quick sanity check: a cantilever always deflects far more than a simply supported beam of the same span and load. Triangular-load row mein dekho load ka bhaari end kis taraf hai." },
          ],
        },

        /* ---------------------------------------------- 5.5 */
        {
          n: "5.5",
          title: "Columns and struts — slenderness ratio, Euler's and Rankine's formulas",
          hi: "स्तंभ और स्ट्रट — पतलापन अनुपात, यूलर व रैंकाइन सूत्र",
          blocks: [
            { k: "h", t: "📘 Notes — p.14" },
            { k: "def", term: "Strut", t: "A compression member in any position <b>other than vertical</b>; generally used to connect/support main members. (p.14)" },
            { k: "def", term: "Column", t: "A <b>vertical</b> compression member used in buildings. (p.14)" },
            { k: "h", t: "Slenderness ratio" },
            { k: "eq", expr: "λ = Leff/r_min   ;   r = √(I/A)  ⇒  r_min = √(I_min/A)", where: [
              ["Leff", "effective length of the column"], ["r_min", "least radius of gyration"],
            ] },
            { k: "p", t: "If r_yy &lt; r_xx, the column will fail in the <b>Y-Y direction</b> (i.e. about the axis giving the least radius of gyration). (p.14)" },
            { k: "def", term: "Buckling (crippling) load", t: "The maximum limiting load at which the column tends to displace laterally, or tends to buckle. (p.14)" },
            { k: "h", t: "Classification of columns (d = least lateral dimension)" },
            { k: "cmp", t: "Classification of columns (p.14)", cols: ["Criterion", "Failure mode"], rows: [
              ["Long columns", "L &gt; 30d and λ &gt; 120", "Fail due to <b>buckling only</b>"],
              ["Short columns", "L &lt; 8d and λ &lt; 80", "Fail due to <b>direct stresses only</b>"],
            ] },
            { k: "note", t: "<b>These limits are classroom conventions, not code rules — and they are not consistent with each other.</b> For a solid rectangle r = d/√12 = 0.289d, so L = 8d means λ ≈ 28, not 80. Textbooks also define a third class, <b>medium</b> columns, which fail by combined crushing and bending (<a href=\"https://sist.sathyabama.ac.in/sist_coursematerial/uploads/SCIA1401.pdf\" target=\"_blank\" rel=\"noopener\">Sathyabama Institute course material</a>). The rule that actually governs RCC design is <b>IS 456 cl. 25.1.2: a column is 'short' when l_ex/D and l_ey/b are both less than 12</b>; otherwise it is slender and additional moments must be designed for (<a href=\"https://infralens.in/handbook/effective-length-factors\" target=\"_blank\" rel=\"noopener\">InfraLens — effective length factors</a>). See <a href=\"#/code/is456\">IS 456</a>." },
            { k: "p", t: "Sign convention for bending in a column: <b>convexity is positive</b>, <b>concavity is negative</b>. (p.14)" },
            { k: "def", term: "Effective (equivalent / unsupported) length, Leff", t: "The length at which the column can resist compressive loads with respect to its end conditions; it is the length between the points of contraflexure of the curvature of the column. (p.14)" },
            { k: "dia", id: "hb-som-euler" },
            { k: "h", t: "Euler's formula (long columns only)" },
            { k: "eq", expr: "Crippling load  Pcr = π²EI/Leff²" },
            { k: "p", t: "<b>Where it comes from:</b> a pin-ended column bent slightly by P has M = −P·y, so EI·y'' + P·y = 0 — the equation of a sine wave. The ends (y = 0 at x = 0 and L) allow a non-zero shape only if √(P/EI)·L = π, giving Pcr = π²EI/L². Other end conditions change the wavelength, hence Leff. Assumptions: perfectly straight, axially loaded, elastic, homogeneous column — real columns are never perfect, which is why codes do not use Euler directly. (Standard derivation, general engineering knowledge.)" },
            { k: "eq", expr: "Euler stress  σ_cr = Pcr/A = π²E/λ²   ;   valid only while σ_cr ≤ crushing/yield stress  ⇒  λ ≥ λ_lim = π√(E/σ_c)", where: [
              ["E = 2 × 10⁵, σ_c = 320 N/mm²", "λ_lim = π√625 = 78.5 — the origin of the textbook statement 'Euler is valid for λ ≥ 80' (Sathyabama notes)"],
              ["E = 2 × 10⁵, fy = 250 N/mm²", "λ_lim = 88.9"],
            ] },
            { k: "h", t: "Rankine's formula (any type of column)" },
            { k: "eq", expr: "1/PR = 1/Pcr + 1/Pc   ;   PR = (f_y·A)/(1 + αλ²)", where: [
              ["Pc", "crushing load = f_y × A"],
              ["α", "Rankine's coefficient = f_y/(π²E)"],
            ] },
            { k: "cmp", t: "Empirical Rankine constants used in textbooks (Sathyabama course material)", cols: ["Crushing stress σ_c (N/mm²)", "Rankine constant α"], rows: [
              ["Mild steel", "320", "1/7500"],
              ["Cast iron", "550", "1/1600"],
              ["Timber", "varies", "1/1800 (other texts quote different values)"],
            ] },
            { k: "note", t: "Check: the theoretical α = σ_c/(π²E) for mild steel = 320/(9.87 × 2 × 10⁵) = 1/6170, close to the empirical 1/7500. Timber constants differ noticeably between Indian textbooks — use the value given in your syllabus or problem." },
            { k: "cmp", t: "Effective length for standard end conditions (p.14)", cols: ["Leff"], rows: [
              ["1) Upper end free (other end fixed)", "2L"],
              ["2) Both ends hinged", "L"],
              ["3) Upper end hinged, lower end fixed", "L/√2"],
              ["4) Both ends fixed", "L/2"],
            ] },
            { k: "cmp", t: "Theoretical vs IS 456 Table 28 recommended effective length (braced columns)", cols: ["Theoretical", "IS 456 recommended"], rows: [
              ["Both ends fixed (restrained in position and direction)", "0.50L", "0.65L"],
              ["One end fixed, other hinged", "0.70L", "0.80L"],
              ["Both ends hinged", "1.00L", "1.00L"],
              ["Fixed–free (cantilever)", "2.00L", "2.00L"],
            ] },
            { k: "note", t: "Code values from InfraLens's summary of IS 456 Table 28 (linked above), which also lists larger factors for unbraced (sway) frames (e.g. 1.2 for both ends restrained). The code values are larger than theory because no real joint is perfectly fixed. IS 800 Table 11 gives similar values for steel (0.65L for both ends restrained, 2.0L for a cantilever)." },
            { k: "note", t: "Based on theoretical considerations, an <b>equilateral triangle</b> is the optimum cross-sectional shape for a column. (p.14)" },
            { k: "note", t: "That statement is about <i>solid</i> sections of equal area: an equilateral triangle has I/A² ≈ 0.096 vs 0.080 for a circle and 0.083 for a square (derived). In practice hollow sections (tubes, built-up I and box sections) beat any solid shape by a wide margin (<a href=\"#/read/som/3\">Worked example 3.2</a>)." },
            { k: "eq", expr: "Safe load = Crippling load (Pcr) / Factor of safety" },
            { k: "cmp", t: "Factor of safety (p.14)", cols: ["FoS"], rows: [
              ["1) Wrought iron, mild steel & medium steel", "3"],
              ["2) Cast iron", "5"],
              ["3) Timber", "6"],
            ] },
            { k: "p", t: "Modern steel design (IS 800:2007) does not use Euler or Rankine with a FoS; it uses <b>buckling-class curves</b> that include initial imperfections and residual stresses to give a design compressive stress f_cd for each slenderness. Euler's load still appears inside those formulas as the reference elastic buckling load. See <a href=\"#/code/is800\">IS 800</a>. (General engineering knowledge.)" },
            { k: "eg", title: "Worked example 5.6 — Euler vs Rankine for a mild-steel strut", given: "Solid mild-steel bar, 50 mm diameter, 2 m long, both ends hinged. E = 2 × 10⁵ N/mm², σ_c = 320 N/mm², α = 1/7500. Find: λ, Euler and Rankine loads, safe load (FoS 3). Then repeat with both ends fixed.", steps: [
              { t: "Section properties", w: "A = π × 50²/4 = 1963.5 mm²;  I = π × 50⁴/64 = 3.068 × 10⁵ mm⁴;  r = d/4 = 12.5 mm" },
              { t: "Hinged–hinged: λ = 2000/12.5 = 160 (> 78.5, Euler valid)", w: "P_E = π² × 2 × 10⁵ × 3.068 × 10⁵ / 2000² = 151.4 kN\nP_R = 320 × 1963.5 / (1 + 160²/7500) = 628 320 / 4.413 = 142.4 kN\nSafe (Euler, FoS 3) = 50.5 kN" },
              { t: "Fixed–fixed: Leff = 1 m, λ = 80 (at the limit)", w: "P_E = 151.4 × 4 = 605.6 kN  (≈ crushing load 628 kN — unrealistic)\nP_R = 628 320 / (1 + 6400/7500) = 339.0 kN" },
            ], ans: "Long strut: Euler 151.4 kN, Rankine 142.4 kN — close. Stocky strut: Euler 606 kN vs Rankine 339 kN — Euler is unsafe near λ ≈ 80 because it ignores crushing. Interpretation: this is exactly the range where real columns live, and why codes use imperfection-based curves instead of Euler." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Euler's formula is a <b>pure buckling</b> equation — it says nothing about the material's crushing strength, so applied blindly to a short, stocky column it predicts an absurdly high 'safe' load. Rankine's formula fixes this by combining the buckling load Pcr and the crushing load Pc as reciprocals (like two springs in series): for a very short column λ is small, so 1/Pcr is negligible and PR → Pc (crushing governs); for a very long column 1/Pc is negligible and PR → Pcr (Euler buckling governs). That is why Rankine is described as valid for 'any type of column' while Euler is valid only for long ones." },
            { k: "real", t: "Scaffolding ke props, formwork ke bracing, truss ke compression members — sab buckling se fail hote hain, crushing se nahi. Site par props ke beech horizontal ledger/bracing lagane ka matlab hai effective length aadhi karna — Pcr chaar guna. Bracing hata do to wahi prop achanak buckle ho sakta hai." },
            { k: "trap", t: "Do not apply Euler's formula (Pcr = π²EI/Leff²) to a short column (L &lt; 8d, λ &lt; 80) — that regime fails by direct crushing, not buckling, and Euler's formula was derived assuming buckling governs. Use Rankine's formula when the column type is not stated or when λ falls in the intermediate range. Aur λ hamesha <b>least</b> r se nikalo — rectangular column apni patli side ki taraf buckle karta hai." },
          ],
        },

        /* ---------------------------------------------- 5.6 */
        {
          n: "5.6",
          title: "Quick revision — deflection and columns",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Curvature = 1/R = M/EI = d²y/dx² = dθ/dx; EI(dy/dx) = ∫M dx, EI·y = ∫∫M dx (p.12); boundary conditions table (§5.1).",
              "Cantilever: y, θ max at free end, zero at fixed end. Maxwell's reciprocal law y_C = y_B (p.12).",
              "Simply supported: y = 0 at supports, y_max where θ changes sign; θ = 0 at y_max (p.12).",
              "Moment-area: θ = A/EI, y = A·x̅/EI (first moment about the point whose deviation is sought); Macaulay's uses (x−a)ⁿ terms, brackets never expanded (p.12, §5.2–5.3).",
              "Conjugate beam: load M/EI; slope = conjugate shear, deflection = conjugate moment; fixed ↔ free (§5.3).",
              "Static indeterminacy = unknown reactions − 3 (p.12); propped cantilever 1, fixed–fixed 3 (corrected).",
              "Full standard deflection table, with corrected rows for a central couple and the triangular-load cantilever, plus the two propped-cantilever cases P = 5W/16 (8L/11) and P = 3wL/8 (3L/4) (p.13, §5.4).",
              "IS 456: span/250 final; span/350 or 20 mm after partitions (§5.4).",
              "λ = Leff/r_min; IS 456 short column if l_e/D < 12 (§5.5).",
              "Euler Pcr = π²EI/Leff², valid for λ ≥ π√(E/σ_c); Rankine 1/PR = 1/Pcr + 1/Pc, PR = f_yA/(1+αλ²), α = f_y/(π²E) (p.14).",
              "Leff for the four standard end conditions: 2L, L, L/√2, L/2 (p.14); IS 456 recommended 0.65L / 0.80L / L / 2L.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "y_p (propped cantilever) = PL³/3EI = y_max of the cantilever alone — this equation solves for the prop reaction P.",
              "Standard table: WL³/3EI (cantilever) vs WL³/48EI (SS) for a central point load; wL⁴/8EI vs 5wL⁴/384EI for a full UDL.",
              "Rankine's formula reduces to crushing (Pc) for short columns and to Euler buckling (Pcr) for long columns.",
              "FoS: 3 for wrought iron/mild/medium steel, 5 for cast iron, 6 for timber.",
              "Equilateral triangle = theoretically optimum column cross-section (among solid sections).",
            ] },
            { k: "h", t: "🔗 Related in Civil Educator" },
            { k: "list", items: [
              "<a href=\"#/read/som/3\">Ch. 3 — BMDs and radius of gyration</a> (inputs to every method here)",
              "<a href=\"#/read/som/4\">Ch. 4 — 1/R = M/EI</a> (the starting equation)",
              "<a href=\"#/read/som/8\">Ch. 8 — Castigliano and unit-load methods</a> (energy route to the same deflections)",
              "Codes: <a href=\"#/code/is456\">IS 456</a> (cl. 23.2 deflection, cl. 25.1.2 short columns), <a href=\"#/code/is800\">IS 800</a> (Table 6, Table 11, buckling curves)",
            ] },
          ],
        },
      ],
    },

    /* ============================================================ CH 6
       v32 — rebuilt through the Phase 1 chapter quality gate. Notes
       blocks kept with (p.N); errors corrected openly; new material
       web-researched and linked. Log: claude/research-log-som.md */
    {
      id: "som-6",
      n: 6,
      title: "Core of a Section, Torsion, Resilience and Springs",
      hi: "खंड का कोर, टॉर्शन, रेज़िलिएंस और स्प्रिंग",
      blurb: "Combined direct and bending stress under eccentric load and the core (kern) of a section; torsion of solid and hollow circular shafts — assumptions, design for strength and stiffness, power; combined bending and torsion by the two theories of failure with the IS 456 torsion link; resilience; and closely-coiled helical springs with the Wahl factor, springs in series/parallel and leaf springs — with 7 worked examples.",
      mins: 50,
      sections: [
        /* ---------------------------------------------- 6.1 */
        {
          n: "6.1",
          title: "Eccentric loading and the core of a cross-section",
          hi: "उत्केन्द्री भार और खंड का कोर",
          blocks: [
            { k: "p", t: "A compressive load P applied at a distance e from the centroid is equivalent to the same load at the centroid <b>plus</b> a bending moment M = P·e. The two stresses add: <b>σ = P/A ± M/Z</b>. For a rectangle (Z = bd²/6, bending about the axis parallel to b) this becomes <b>σ = (P/A)(1 ± 6e/d)</b>. (Superposition of Chapter 1 and Chapter 4 — derived.)" },
            { k: "h", t: "📘 Notes — p.15" },
            { k: "def", term: "Core (kern) of a cross-section", t: "The part of the cross-sectional area within which a direct load can be applied such that <b>no tensile stress develops anywhere</b> in the cross-section. (p.15)" },
            { k: "eq", expr: "Condition for no tension:  e ≤ 2r²/d", where: [
              ["e", "eccentricity = permissible distance of the load from the centre"],
              ["r", "radius of gyration = √(I/A)"],
              ["d", "least lateral dimension"],
            ] },
            { k: "note", t: "<b>Clarifying 'd'.</b> The no-tension condition comes from P/A = M/Z, i.e. e ≤ Z/A = r²/y_max. For a section symmetric about the bending axis y_max = d/2, giving 2r²/d — so <b>d is the depth in the direction of the eccentricity</b> (the plane of bending), not necessarily the least dimension. A rectangle therefore has two limits: b/6 when the load moves along b, d/6 when it moves along d. Check: rectangle r² = d²/12 → 2r²/d = d/6 ✔; circle r² = d²/16 → d/8 ✔ (derived)." },
            { k: "cmp", t: "Maximum eccentricity for the core of standard sections (p.15)", cols: ["e_max"], rows: [
              ["a) Circular section (dia. d)", "d/8 — core is a small central circle of diameter d/4"],
              ["b) Hollow circular section (outer dia. D, inner dia. d)", "(D²+d²)/8D — core is a small central circle"],
              ["c) Rectangular section (width b, depth d)", "b/6 or d/6 — core is a rhombus (diamond) at the centre"],
            ] },
            { k: "dia", id: "hb-som-kern" },
            { k: "eg", title: "Worked example 6.1 — short pier under an eccentric load", given: "A 400 × 600 mm masonry pier carries 800 kN at 80 mm from the centroid, along the 600 mm direction. Find: the extreme stresses; then the largest eccentricity with no tension, and the stresses if e = 120 mm.", steps: [
              { t: "Direct stress", w: "P/A = 800 000 / (400 × 600) = 3.33 N/mm²" },
              { t: "e = 80 mm: σ = (P/A)(1 ± 6e/d)", w: "6e/d = 480/600 = 0.8\nσ_max = 3.33 × 1.8 = 6.00 N/mm² (C);  σ_min = 3.33 × 0.2 = 0.67 N/mm² (C)" },
              { t: "No-tension limit", w: "e_max = d/6 = 600/6 = 100 mm" },
              { t: "e = 120 mm (outside the core)", w: "6e/d = 1.2 ⇒ σ_min = 3.33 × (1 − 1.2) = −0.67 N/mm² (tension)" },
            ], ans: "6.00 and 0.67 N/mm² compression at e = 80 mm; tension appears beyond e = 100 mm. Interpretation: masonry and plain-concrete foundations are proportioned so the resultant stays inside the middle third — the same rule as for gravity dams (Chapter 7.5) and footings." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The core is the region where the eccentric load's bending stress (±M·y/I) never exceeds the direct stress (P/A) in magnitude, so the combined stress stays compressive (or zero) everywhere — no tension anywhere in the section. For a rectangular section this rhombus-shaped core, with half-diagonals b/6 and d/6, is exactly the 'middle third' rule used later for the base of a gravity dam (p.15 and p.17) — a dam's base behaves like a rectangular section carrying an eccentric vertical resultant." },
            { k: "trap", t: "Do not confuse the core condition e ≤ 2r²/d (a general result via the radius of gyration) with the specific e_max values already worked out for circular, hollow and rectangular sections — the table values are the ready-to-use answers for those three shapes; the general formula is for any other shape." },
          ],
        },

        /* ---------------------------------------------- 6.2 */
        {
          n: "6.2",
          title: "Torsion of circular shafts",
          hi: "गोलाकार शाफ्ट में टॉर्शन",
          blocks: [
            { k: "h", t: "📘 Notes — p.15" },
            { k: "def", term: "Torsion", t: "The twisting of a straight bar when loaded by moments (torques) that tend to produce rotation about the longitudinal axis of the bar/shaft. (p.15)" },
            { k: "h", t: "📘 Assumptions and where the equation comes from" },
            { k: "p", t: "For a <b>circular</b> shaft, symmetry makes every cross-section rotate as a rigid disc: plane sections stay plane and undistorted, radii stay straight, and a line drawn along the surface twists into a helix. Shear strain therefore grows linearly from the axis, γ = ρ·(dθ/dx); with Hooke's law τ = Gγ, and with equilibrium ∫τ·ρ dA = T, this gives τ = Tρ/J and θ = TL/GJ (<a href=\"https://mechref.engr.illinois.edu/sol/torsion.html\" target=\"_blank\" rel=\"noopener\">Univ. of Illinois — Introductory Solid Mechanics</a>). Material must be linear-elastic and homogeneous. <b>Non-circular sections warp</b> — their cross-sections do not stay plane — so these formulas do not apply to rectangles, angles or I-sections (same source)." },
            { k: "h", t: "Torsion equation" },
            { k: "eq", expr: "T/J = Gθ/L = τ/R", where: [
              ["T", "average torque applied (kN·m)"],
              ["J", "polar moment of inertia = I_xx + I_yy = πd⁴/32"],
              ["G", "shear modulus (modulus of rigidity)"],
              ["θ", "angle of twist"], ["L", "length of shaft"],
              ["τ", "max. shear stress due to torsion"], ["R", "radius = D/2"],
            ] },
            { k: "dia", id: "hb-som-torsion" },
            { k: "eq", expr: "Angle of twist θ = TL/GJ   ;   Torsional rigidity = GJ   ;   Polar section modulus Z_p = J/R = πD³/16" },
            { k: "eq", expr: "Hollow shaft:  J = π(D⁴ − d⁴)/32   ;   Z_p = π(D⁴ − d⁴)/(16D)   ;   τ_max at the outer surface", where: [
              ["D, d", "outer and inner diameters (Illinois notes give the same J)"],
            ] },
            { k: "eq", expr: "Power transmitted by shaft  P = T·ω = 2πNT/60 watts   (ω = 2πN/60, N in rpm)" },
            { k: "eq", expr: "Diameter of shaft for a given permissible shear stress/torque:  d = (16T/πτ)^(1/3)" },
            { k: "p", t: "<b>Design for stiffness too.</b> A shaft strong enough may still twist too much (gears mesh badly, machines vibrate). If the twist is limited to θ_allow over a length L, then J ≥ T·L/(G·θ_allow) — use the larger diameter from the strength and stiffness conditions (Worked example 6.2)." },
            { k: "h", t: "📘 Thin-walled closed sections (box girders, tubes) — Bredt–Batho" },
            { k: "p", t: "For a closed thin-walled section of any shape (a rectangular box, an oval tube) the <b>shear flow</b> q = τ·t is constant all round the wall, and <b>τ = T/(2·A_m·t)</b>, where A_m is the area enclosed by the <b>mid-line</b> of the wall — not the material area. Twist per unit length = T/GJ with J = 4A_m²/∮(ds/t) (<a href=\"https://ocw.mit.edu/courses/16-20-structural-mechanics-fall-2002/d01996bd6822461f4dcbdc3fbf2ea16f_unit12.pdf\" target=\"_blank\" rel=\"noopener\">MIT OCW 16.20 — Unit 12</a>; same τ formula in <a href=\"https://engineersedge.com/calculators/torsion_in_thinwalled__16087.htm\" target=\"_blank\" rel=\"noopener\">Engineers Edge</a>). Example: a steel box 300 × 200 mm (mid-line), wall 10 mm, T = 50 kN·m → A_m = 60 000 mm², τ = 50 × 10⁶/(2 × 60 000 × 10) = 41.7 N/mm². An <b>open</b> section of the same material (an I or a channel, or the same box slit along one side) is many times weaker and more flexible in torsion — which is why curved and eccentrically loaded bridge decks use closed box girders." },
            { k: "h", t: "Strain energy due to torsion" },
            { k: "eq", expr: "U = (τ²/4G) × V = (T/2) × Φ    [V = volume = A × L]     ;     hollow shaft: U = (τ²/4G) × [(D²+d²)/D²] × V" },
            { k: "h", t: "Shafts in series and parallel" },
            { k: "list", items: [
              "<b>Series:</b> θ = θ₁ + θ₂ + … (angle of twist adds up).",
              "<b>Parallel:</b> θ = θ₁ = θ₂ = … (same angle of twist in each).",
            ] },
            { k: "eg", title: "Worked example 6.2 — designing a solid shaft for strength and stiffness", given: "A solid steel shaft transmits 50 kW at 300 rpm. τ_allow = 60 N/mm², twist not to exceed 1° per metre, G = 80 000 N/mm². Find: the required diameter.", steps: [
              { t: "Torque", w: "T = 60P/(2πN) = 60 × 50 000/(2π × 300) = 1591.5 N·m = 1.5915 × 10⁶ N·mm" },
              { t: "Strength", w: "d = (16T/πτ)^(1/3) = (16 × 1.5915 × 10⁶ / (π × 60))^(1/3) = 51.3 mm" },
              { t: "Stiffness (θ = 1° = 0.017453 rad over L = 1000 mm)", w: "J = TL/(Gθ) = 1.5915 × 10⁹ / (80 000 × 0.017453) = 1.140 × 10⁶ mm⁴\nd = (32J/π)^(1/4) = 58.4 mm" },
            ], ans: "Stiffness governs: d ≥ 58.4 mm → adopt 60 mm. Interpretation: long transmission shafts are usually stiffness-governed, short ones strength-governed." },
            { k: "eg", title: "Worked example 6.3 — hollow shaft of the same strength", given: "Replace the strength-designed 51.3 mm solid shaft of Worked example 6.2 by a hollow shaft with inner diameter = 0.6 × outer, same τ_allow. Find: diameters and weight saving.", steps: [
              { t: "Equal strength: D³(1 − k⁴) = d_solid³ with k = 0.6", w: "D = 51.3 / (1 − 0.1296)^(1/3) = 51.3 / 0.955 = 53.7 mm;  inner = 32.2 mm" },
              { t: "Weight ratio = area ratio", w: "(53.7² − 32.2²) / 51.3² = 0.70" },
            ], ans: "Hollow 53.7/32.2 mm carries the same torque with 30% less steel, for only a 5% larger outer diameter. Interpretation: the core of a solid shaft is lightly stressed (figure above) — the reason hollow drive shafts and tubular members are used." },
            { k: "eg", title: "Worked example 6.4 — strain energy stored in a twisted shaft", given: "A solid shaft 50 mm diameter, 1 m long, is twisted until τ_max = 60 N/mm². G = 80 000 N/mm². Find: strain energy.", steps: [
              { t: "Volume", w: "V = π × 25² × 1000 = 1.963 × 10⁶ mm³" },
              { t: "U = (τ²/4G)·V", w: "U = (60²/(4 × 80 000)) × 1.963 × 10⁶ = 0.01125 × 1.963 × 10⁶ = 22 090 N·mm ≈ 22.1 J" },
            ], ans: "≈ 22.1 J. Interpretation: half of what a uniformly stressed bar at 60 N/mm² would store (τ²/2G), because most of the shaft's material is below τ_max." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "This is the exact torsional counterpart of springs in series/parallel (section 6.5): shafts in <b>series</b> share the same torque but their twists add (like flexible springs stacked end to end); shafts in <b>parallel</b> share the total torque between them but must twist through the <b>same</b> angle (like two springs side by side). The shaft-diameter formula d = (16T/πτ)^(1/3) shows why diameter is so effective at controlling stress — doubling the torque only needs the diameter to grow by 2^(1/3) ≈ 1.26×, since diameter enters the stress formula as d³." },
            { k: "trap", t: "J = πd⁴/32 for a solid shaft is the <b>polar</b> moment of inertia (about the longitudinal axis), not the same as the second moment of area I = πd⁴/64 used in bending — J is exactly twice I for a circular section. Aur power formula mein T N·m mein aur N rpm mein ho tabhi P watts mein aata hai." },
          ],
        },

        /* ---------------------------------------------- 6.3 */
        {
          n: "6.3",
          title: "Combined bending and torsion",
          hi: "संयुक्त बेंडिंग व टॉर्शन",
          blocks: [
            { k: "h", t: "📘 Notes — p.15" },
            { k: "eq", expr: "Bending stress f = M/Z = 32M/πd³     ;     Shear stress τ = T/Z_p = 16T/πd³" },
            { k: "h", t: "Principal stresses" },
            { k: "eq", expr: "σ_p1 = f/2 + √[(f/2)² + τ²] = (16/πd³)(M + √(M²+T²))     ;     σ_p2 = f/2 − √[(f/2)² + τ²] = (16/πd³)(M − √(M²+T²))" },
            { k: "eq", expr: "τ_max = (σ_p1 − σ_p2)/2" },
            { k: "h", t: "Equivalent torque and equivalent bending moment" },
            { k: "eq", expr: "a) Equivalent torque  T_e = √(M² + T²)     b) Equivalent B.M.  M_e = (1/2)(M + √(M²+T²))" },
            { k: "note", t: "<b>Correcting the Samjho below — the two routes are two different theories of failure</b> (<a href=\"#/read/som/2\">Chapter 2.7</a>). T_e reproduces the maximum <i>shear</i> stress, so designing with T_e and τ_allow is the <b>maximum shear stress (Guest/Tresca) theory</b> — for ductile materials like mild steel. M_e reproduces the maximum <i>principal</i> stress, so designing with M_e and σ_allow is the <b>maximum principal stress (Rankine) theory</b> — for brittle materials like cast iron (<a href=\"https://www.rgpv.ac.in/campus/ME/Unit%202%20-%20Machine%20Component%20Design.pdf\" target=\"_blank\" rel=\"noopener\">RGPV machine-design notes</a>). The two generally give <b>different</b> diameters; when the governing theory is not specified, compute both and adopt the larger." },
            { k: "eg", title: "Worked example 6.5 — shaft under combined bending and torsion", given: "A shaft carries M = 3 kN·m and T = 4 kN·m. τ_allow = 60, σ_allow = 100 N/mm². Find: the diameter by each theory.", steps: [
              { t: "Equivalent torque (max shear stress theory)", w: "T_e = √(3² + 4²) = 5 kN·m\nd = (16 × 5 × 10⁶ / (π × 60))^(1/3) = 75.2 mm" },
              { t: "Equivalent moment (max principal stress theory)", w: "M_e = ½(3 + 5) = 4 kN·m\nd = (32 × 4 × 10⁶ / (π × 100))^(1/3) = 74.1 mm" },
            ], ans: "75.2 mm (Guest) vs 74.1 mm (Rankine) — adopt ≈ 76 mm (next standard size, e.g. 80 mm). The two happen to be close here; in general they differ, and the ratio of the allowables decides which governs." },
            { k: "p", t: "<b>Torsion in RCC beams.</b> Edge beams supporting a cantilever slab, or beams curved in plan, are twisted. IS 456 does not use T_e/M_e; it converts torsion into an <b>equivalent shear V_e = V_u + 1.6 T_u/b</b> (cl. 41.3.1) and an equivalent moment (cl. 41.4.2), then designs with the ordinary shear and flexure rules (<a href=\"https://prepp.in/question/determine-the-equivalent-nominal-shear-stress-in-a-6633b4310368feeaa5872107\" target=\"_blank\" rel=\"noopener\">Prepp worked example</a>; clause numbers also in <a href=\"https://DOCS.BENTLEY.COM/LiveContent/web/RAM%20Concept%20Help-v17/en/GUID-0471CB3A-3100-4A15-BA5B-D0C00D4B8E80.html\" target=\"_blank\" rel=\"noopener\">Bentley RAM Concept IS 456 docs</a>). See the RCC handbook and <a href=\"#/code/is456\">IS 456</a>." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "A shaft that carries both a bending moment M and a torque T (a very common site situation — e.g. a line shaft with a pulley hanging off it) is not designed twice over; instead the two effects are collapsed into one equivalent quantity. Design the shaft for T_e using the pure-torsion formula (d = (16T_e/πτ)^(1/3)), or for M_e using the pure-bending formula — both routes give the same diameter, because T_e and M_e are constructed exactly so that they reproduce the same maximum principal/shear stress as the combined M-and-T loading." },
            { k: "trap", t: "σ_p1 and σ_p2 use half the bending stress (f/2) under the square root term, not f itself — this is the standard Mohr's-circle result for a stress element with direct stress f and shear stress τ only (no stress on the other face). Missing the '/2' is the most common slip in this formula. Aur 'dono routes same diameter dete hain' wali baat sahi nahi — note dekho." },
          ],
        },

        /* ---------------------------------------------- 6.4 */
        {
          n: "6.4",
          title: "Resilience",
          hi: "रेज़िलिएंस",
          blocks: [
            { k: "h", t: "📘 Notes — p.16" },
            { k: "def", term: "Resilience", t: "The strain energy stored in a body due to external loading, within the elastic limit. (p.16)" },
            { k: "def", term: "Proof resilience", t: "The maximum resilience up to the elastic limit. (p.16)" },
            { k: "eq", expr: "Modulus of resilience = Proof resilience / Volume of material (V)" },
            { k: "cmp", t: "Strain energy stored (Resilience) (p.16)", cols: ["Proof resilience"], rows: [
              ["1) Bending (i.e. direct tension/compression)", "f²/2E × V"],
              ["2) Shear", "τ²/2G × V"],
              ["3) Torque", "U = Avg. torque × angle of twist = (T/2)×Φ = (τ²/4G)×V   [hollow shaft: × (D²+d²)/D²]"],
            ] },
            { k: "note", t: "<b>Label correction for row 1:</b> f²/2E × V is the energy for <b>direct (uniform) tension or compression</b>, not bending. In bending the stress varies from zero at the N.A, so the energy is ∫M²/2EI dx (<a href=\"#/read/som/8\">Chapter 8.1</a>); for a rectangular beam under uniform moment that works out to f_max²/6E × V — one-third of the direct value (derived)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "All three strain-energy formulas have the same shape — (stress)²/(2 × elastic modulus) × volume — except torsion, which carries a <b>4</b> in the denominator instead of a 2. The reason is that direct/shear stress is assumed uniform across the section, while shear stress due to torsion varies linearly from zero at the centre to τ_max at the surface; averaging that linear variation over the cross-section brings in the extra factor of 2, turning 2G into 4G." },
            { k: "real", t: "Proof resilience is why a car's leaf spring or coil spring is specified by how much energy it can absorb before permanent set, not just by its peak load rating — the area under the load-deflection curve up to the elastic limit is exactly the proof resilience. Sudden and impact loads are treated with these energy ideas in <a href=\"#/read/som/8\">Chapter 8.4</a>." },
          ],
        },

        /* ---------------------------------------------- 6.5 */
        {
          n: "6.5",
          title: "Springs — closely-coiled helical and leaf springs",
          hi: "स्प्रिंग्स — हेलिकल और लीफ स्प्रिंग",
          blocks: [
            { k: "h", t: "📘 Notes — p.16" },
            { k: "cmp", t: "Types of spring by function (p.16)", cols: ["Function"], rows: [
              ["Resilience spring", "Energy stored for future use (e.g. spring in a clock)"],
              ["Carriage (leaf) spring", "Absorbs excess energy (e.g. spring in a bike)"],
              ["Torsion spring", "A spring primarily subjected to torsion/twisting"],
            ] },
            { k: "note", t: "Naming trap: a 'torsion spring' (the kind in a clothes-peg or door hinge) is loaded by a twisting <i>couple</i>, but its <b>wire is in bending</b>. Conversely an ordinary compression/tension coil spring under an axial <i>load</i> has its <b>wire in torsion</b>. That is exactly why the two formulas below use G and EI respectively." },
            { k: "h", t: "Closely-coiled helical springs" },
            { k: "p", t: "n = number of turns; R = radius of coil (8D³ = 64R³, i.e. D = 2R); d = diameter of the spring wire. (p.16)" },
            { k: "eq", expr: "a) Subjected to external load W:  Deflection δ = 8nWD³/Gd⁴     ;     Stiffness = W/δ" },
            { k: "eq", expr: "Spring rate k = Gd⁴/(8nD³)   ;   wire shear stress τ = K_w · 8WD/(πd³)   ;   spring index C = D/d", where: [
              ["D", "MEAN coil diameter = (inner + outer)/2"],
              ["K_w", "Wahl factor = (4C − 1)/(4C − 4) + 0.615/C — corrects for coil curvature and direct shear; ≈1.58 at C = 3 down to ≈1.09 at C = 16"],
              ["source", "RoyMech — helical springs (deflection, stress, Wahl factor, C typically 3 to 12)"],
            ] },
            { k: "eq", expr: "b) Subjected to external couple/torque T:  Total twist Φ = (2πn)TR/EI     ;     Stiffness = T/Φ" },
            { k: "h", t: "Springs in series and parallel" },
            { k: "eq", expr: "Series (δ = δ₁ + δ₂):  W/k = W/k₁ + W/k₂   ⇒   1/k = 1/k₁ + 1/k₂   ⇒   k = k₁k₂/(k₁+k₂)" },
            { k: "eq", expr: "Parallel (W = W₁ + W₂):  δk = δk₁ + δk₂   ⇒   k = k₁ + k₂" },
            { k: "eg", title: "Worked example 6.6 — closely-coiled helical spring", given: "Mean coil diameter D = 80 mm, wire d = 10 mm, n = 10 active turns, axial load W = 500 N, G = 80 000 N/mm². Find: deflection, stiffness and wire shear stress (with and without the Wahl factor). Then put it in series and in parallel with a 30 N/mm spring.", steps: [
              { t: "Deflection and rate", w: "δ = 8nWD³/(Gd⁴) = 8 × 10 × 500 × 80³ / (80 000 × 10⁴) = 25.6 mm\nk = 500/25.6 = 19.5 N/mm" },
              { t: "Wire stress", w: "8WD/(πd³) = 8 × 500 × 80/(π × 1000) = 101.9 N/mm²\nC = 8;  K_w = 31/28 + 0.615/8 = 1.184  ⇒  τ = 120.6 N/mm²" },
              { t: "Combinations with k₂ = 30 N/mm (rounding k₁ to 20)", w: "Series: k = 20 × 30/50 = 12 N/mm\nParallel: k = 20 + 30 = 50 N/mm" },
            ], ans: "δ = 25.6 mm, k ≈ 19.5 N/mm; τ = 102 N/mm² (simple) or 121 N/mm² (with Wahl, 18% higher — the value to design with). Series 12, parallel 50 N/mm." },
            { k: "h", t: "📘 Leaf (laminated, carriage) springs" },
            { k: "eq", expr: "Semi-elliptic leaf spring, central load W, span l, n leaves of width b and thickness t:  σ_max = 3Wl/(2nbt²)   ;   δ = 3Wl³/(8Enbt³)", where: [
              ["assumes", "leaves tapered at their ends so the pack acts like a beam of uniform strength (§4.3); friction between leaves ignored"],
              ["source", "CodeCogs engineering reference — semi-elliptic leaf springs"],
            ] },
            { k: "eg", title: "Worked example 6.7 — leaf spring of a trailer", given: "8 leaves, each 60 × 8 mm, span 1.0 m, central load 6 kN, E = 2 × 10⁵ N/mm². Find: maximum stress and central deflection.", steps: [
              { t: "Stress", w: "σ = 3 × 6000 × 1000 / (2 × 8 × 60 × 8²) = 293 N/mm²" },
              { t: "Deflection", w: "δ = 3 × 6000 × 1000³ / (8 × 2 × 10⁵ × 8 × 60 × 8³) = 45.8 mm" },
            ], ans: "σ ≈ 293 N/mm², δ ≈ 45.8 mm — high stress is acceptable because spring steel has a very high elastic limit; the design aim is large elastic deflection (energy absorption), the opposite of a structural beam." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "In <b>series</b>, both springs carry the same load W but stretch by different amounts (δ = δ₁+δ₂) — the combination is more flexible than either spring alone, so the combined stiffness k is <b>smaller</b> than the smaller of k₁, k₂ (same maths as resistors in parallel). In <b>parallel</b>, both springs stretch by the same δ but share the load between them (W = W₁+W₂) — the combination is stiffer, so k = k₁+k₂ is simply additive, larger than either alone." },
            { k: "real", t: "Civil site par springs: vibration isolators under DG sets aur machine foundations, spring-loaded pipe hangers, aur bridge bearings ke elastomeric pads (rubber 'springs'). Stiffness k = Gd⁴/8nD³ dikhata hai ki wire thoda mota karo to spring bahut stiff ho jaata hai (d⁴)." },
            { k: "trap", t: "Do not mix up the two loading cases for a closely-coiled helical spring: an axial load W twists the wire (uses G, the shear modulus, in δ = 8nWD³/Gd⁴), while an axial couple/torque T bends the wire like a curved beam (uses EI, not GJ, in Φ = 2πnTR/EI). It is easy to reach for G in the second case by habit. Aur D hamesha <b>mean</b> coil diameter hai, outer nahi." },
          ],
        },

        /* ---------------------------------------------- 6.6 */
        {
          n: "6.6",
          title: "Quick revision — core, torsion, resilience and springs",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "σ = P/A ± M/Z; rectangle σ = (P/A)(1 ± 6e/d) (§6.1).",
              "Core condition e ≤ 2r²/d (d = depth in the plane of bending); e_max: circle d/8, hollow circle (D²+d²)/8D, rectangle b/6 or d/6 (p.15).",
              "Torsion equation T/J = Gθ/L = τ/R; J = πd⁴/32 (hollow π(D⁴−d⁴)/32); θ = TL/GJ; Z_p = πD³/16 (p.15); design for strength AND stiffness.",
              "Power P = 2πNT/60; shaft dia. d = (16T/πτ)^(1/3) (p.15).",
              "Strain energy in torsion U = τ²/4G × V = (T/2)Φ; hollow shaft factor (D²+d²)/D² (p.15–16).",
              "Combined bending & torsion: σ_p1,2 = f/2 ± √[(f/2)²+τ²]; T_e = √(M²+T²) (Guest, ductile); M_e = ½(M+√(M²+T²)) (Rankine, brittle) (p.15).",
              "Resilience — direct f²/2E·V, shear τ²/2G·V, torque τ²/4G·V (p.16).",
              "Helical spring: δ = 8nWD³/Gd⁴ (load); Φ = 2πnTR/EI (couple) (p.16); Wahl factor; leaf spring σ = 3Wl/2nbt², δ = 3Wl³/8Enbt³.",
              "Springs in series: 1/k = 1/k₁+1/k₂; in parallel: k = k₁+k₂ (p.16).",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "The rectangular-section core (b/6, d/6) is the same idea as the dam's 'middle-third of the base' in Chapter 7.",
              "J (polar) = 2 × I (bending) for a circular section — do not interchange them.",
              "Torsion's strain-energy factor is 4G, not 2G, because shear stress varies linearly across the section.",
              "A spring under axial load uses G (torsion of the wire); under axial couple it uses EI (bending of the wire).",
              "Hollow shafts save ~30% material for the same torque; torsion formulas apply to circular sections only.",
            ] },
            { k: "h", t: "🔗 Related in Civil Educator" },
            { k: "list", items: [
              "<a href=\"#/read/som/2\">Ch. 2 — Principal stresses and theories of failure</a> (basis of T_e and M_e)",
              "<a href=\"#/read/som/7\">Ch. 7 — Dams: middle-third rule</a> (core of a rectangle)",
              "<a href=\"#/read/som/8\">Ch. 8 — Strain energy methods</a> (resilience extended)",
              "Code: <a href=\"#/code/is456\">IS 456</a> (cl. 41 — torsion in RCC beams)",
            ] },
          ],
        },
      ],
    },

    /* ============================================================ CH 7
       v33 — rebuilt through the Phase 1 chapter quality gate (the
       Lamé section added in v26 is kept). Notes blocks kept with
       (p.N); errors corrected openly. Log: claude/research-log-som.md */
    {
      id: "som-7",
      n: 7,
      title: "Thin and Thick Cylinders, and Dams",
      hi: "पतले व मोटे सिलेंडर, और बांध",
      blurb: "Thin cylinders — hoop and longitudinal stress, in-plane and absolute maximum shear, joint efficiencies, change of diameter, length and volume, thin spheres and the hoop tension in circular water tanks; thick cylinders by Lamé's theory; and gravity dams — forces including uplift, resultant and eccentricity, base pressures, the middle-third rule, factors of safety and the elementary profile — with 5 worked examples.",
      mins: 50,
      sections: [
        /* ---------------------------------------------- 7.1 */
        {
          n: "7.1",
          title: "Thin cylinders — hoop and longitudinal stress",
          hi: "पतले सिलेंडर — हूप व अनुदैर्ध्य प्रतिबल",
          blocks: [
            { k: "h", t: "📘 Notes — p.17" },
            { k: "def", term: "Thin cylinder", t: "t &lt; d/20, where t = thickness of the tube, d = internal diameter of the tube, P = internal pressure. (p.17)" },
            { k: "def", term: "Thick cylinder", t: "t &gt; d/20. (p.17)" },
            { k: "h", t: "Hoop or circumferential stress (σ_h)" },
            { k: "eq", expr: "σ_h = Pd/2t" },
            { k: "h", t: "Longitudinal stress (σ_l)" },
            { k: "eq", expr: "σ_l = Pd/4t" },
            { k: "p", t: "∴ <b>Hoop stress (σ_h) = 2 × Longitudinal stress (σ_l)</b>; both σ_h and σ_l are <b>tensile</b> stresses. (p.17)" },
            { k: "dia", id: "hb-som-thincyl" },
            { k: "p", t: "Same formulas in the <a href=\"https://www.sathyabama.ac.in/sites/default/files/course-material/2020-10/UNIT-V_2.pdf\" target=\"_blank\" rel=\"noopener\">Sathyabama Institute course material</a>. The radial stress varies from −p inside to 0 outside; for a thin wall it is small compared with σ_h and is taken as zero — the basic 'thin' assumption, along with uniform stress through the thickness." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Think of a pressurised thin cylinder cut two different ways. Cut it along its <b>length</b> (a longitudinal section): the internal pressure pushes the two halves of the wall apart, resisted by the hoop stress acting on two longitudinal strips of area (t × length) each — this gives σ_h = Pd/2t. Cut it <b>across</b> (a transverse/circular section): the pressure pushes on the circular end cap of area πd²/4, resisted by the longitudinal stress acting all around the thin ring of area πdt — this gives σ_l = Pd/4t, exactly half of σ_h, because the ring resisting it has twice the effective area for the same net force." },
            { k: "trap", t: "Always check t against d/20 first — using the thin-cylinder formulas (σ_h = Pd/2t, σ_l = Pd/4t) on a thick cylinder (t &gt; d/20) is invalid, because they assume the stress is uniform across the wall thickness, which is not true once the wall is thick." },
          ],
        },

        /* ---------------------------------------------- 7.2 */
        {
          n: "7.2",
          title: "Thick cylinders — Lamé's theory",
          hi: "मोटे सिलेंडर — लेमे का सिद्धांत",
          blocks: [
            { k: "h", t: "📘 Notes — researched & verified (new, web-sourced — see note below)" },
            { k: "p", t: "7.1 defined a thick cylinder as t &gt; d/20, but its two formulas (σ_h = Pd/2t, σ_l = Pd/4t) assume uniform stress across the wall and are not valid there. For a thick cylinder, radial stress (σ_r) and hoop stress (σ_θ) both vary with radius r, and are found from Lamé's theory." },
            { k: "def", term: "Lamé's theory", t: "For a thick cylinder with internal radius a and external radius b, radial stress σ_r and hoop stress σ_θ at any radius r (a ≤ r ≤ b) are given by two constants A and B, found from the pressure boundary conditions at r = a and r = b." },
            { k: "eq", expr: "σ_r = A − B/r²      ;      σ_θ = A + B/r²", where: [
              ["A, B", "Lamé's constants for this cylinder, found below from the boundary conditions"],
              ["r", "radius at which the stress is wanted, a ≤ r ≤ b"],
            ] },
            { k: "h", t: "Cylinder under internal pressure p only (external pressure = 0)" },
            { k: "eq", expr: "A = p·a²/(b² − a²)      ;      B = p·a²·b²/(b² − a²)" },
            { k: "eq", expr: "At the bore (r = a) — maximum hoop stress:  σ_θ,max = p·(b² + a²)/(b² − a²)      ;      σ_r = −p (equal and opposite to the applied pressure)" },
            { k: "dia", id: "hb-som-lame" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "σ_θ aur σ_r dono hi radius ke saath change hote hain, magar <b>hoop stress hamesha radial stress se zyada</b> hota hai aur <b>bore (andar ki surface, r=a) par maximum</b> hota hai — isliye thick cylinder ka design hamesha bore ki hoop stress check karke hota hai. Radial stress bore par exactly −p hota hai (jo boundary condition se seedha follow karta hai: andar ki surface par radial stress = applied pressure ke barabar, compressive) aur outer surface (r=b) par zero ho jaata hai (koi external pressure nahi)." },
            { k: "eg", title: "Worked example 7.1 — hoop and radial stress in a thick cylinder", given: "A thick cylinder has internal diameter 200 mm and external diameter 300 mm, carrying an internal pressure of 20 N/mm² (no external pressure). Check whether it is genuinely a thick cylinder, then find the maximum hoop stress and the radial stress at the bore.", steps: [
              { t: "Check t against d/20", w: "a = 100 mm, b = 150 mm, t = b − a = 50 mm; d/20 = 200/20 = 10 mm. Since t (50) > d/20 (10), this is a thick cylinder — Lamé's theory applies, not the thin-cylinder formulas." },
              { t: "Compute b² − a²", w: "b² − a² = 150² − 100² = 22500 − 10000 = 12500 mm²" },
              { t: "Maximum hoop stress, at the bore", w: "σ_θ,max = p(b²+a²)/(b²−a²) = 20 × (22500+10000)/12500 = 20 × 2.6" },
              { t: "Constants and the outer surface (for the figure)", w: "A = 20 × 10 000/12 500 = 16;  B = 20 × 10 000 × 22 500/12 500 = 360 000\nσ_θ(150) = 16 + 360 000/22 500 = 32 N/mm²;  σ_r(150) = 0 ✔" },
              { t: "Compare with the thin-cylinder formula", w: "pd/2t = 20 × 200/(2 × 50) = 40 N/mm² — 23% below the true 52" },
            ], ans: "σ_θ,max = 52 N/mm² (tensile); σ_r at the bore = −20 N/mm² (compressive, equal to −p)" },
            { k: "note", t: "<b>Notation differs across sources — not a real conflict, just which letter carries the sign:</b> the form used above (σ_r = A − B/r², σ_θ = A + B/r², the convention most Indian textbooks use) is cross-checked against the physically identical result stated with the signs on A and B reversed (σ_r = A + B/r², σ_θ = A − B/r²) by <a href=\"https://roymech.org/Useful_Tables/Mechanics/Cylinders.html\" target=\"_blank\" rel=\"noopener\">RoyMech — Thick Cylinder basics</a>, and independently by <a href=\"https://danotes.mech.uwa.edu.au/cylinders/thick/thick.html\" target=\"_blank\" rel=\"noopener\">University of Western Australia — Thick Cylinders</a> (using its own σm/σv notation). All three reduce to the same σ_θ,max = p(b²+a²)/(b²−a²) at the bore once the boundary conditions are substituted — only the bookkeeping differs, never the physical stress." },
            { k: "trap", t: "The thin-cylinder result σ_h = 2σ_l (hoop is always twice the longitudinal stress) does NOT carry over to thick cylinders — Lamé's σ_θ and σ_r are a completely different pair of formulas, and there is no fixed ratio between them; the ratio changes with r." },
          ],
        },

        /* ---------------------------------------------- 7.3 */
        {
          n: "7.3",
          title: "Thin cylinders — shear, joint efficiency, strains, spheres and tanks",
          hi: "पतले सिलेंडर — कतरनी, जोड़ दक्षता, विकृति, गोले और टंकियाँ",
          blocks: [
            { k: "h", t: "📘 Notes — p.17" },
            { k: "eq", expr: "Max. shear stress  τ_max = (σ_h − σ_l)/2 = Pd/8t" },
            { k: "note", t: "<b>Which maximum shear?</b> Pd/8t is the <b>in-plane</b> maximum (between σ_h and σ_l). The cylinder wall actually has three principal stresses — σ_h, σ_l and σ_r ≈ 0 — so the <b>absolute</b> maximum shear is (σ_h − 0)/2 = <b>Pd/4t</b>, twice the notes' value. It is the absolute value that enters the Tresca and von Mises checks of <a href=\"#/read/som/2\">Chapter 2.7</a> (<a href=\"https://supertutor.ph/resources/exams/cele-civil-engineering/strength-of-materials/thin/summary/\" target=\"_blank\" rel=\"noopener\">SuperTutor — thin-walled vessels</a>; follows from Mohr's circle of the three stresses)." },
            { k: "h", t: "Efficiency of joints (η)" },
            { k: "eq", expr: "σ_h' = σ_h/η     ;     σ_l' = σ_l/η" },
            { k: "note", t: "<b>Two different efficiencies.</b> The hoop stress acts across the <b>longitudinal</b> seam, so it is divided by the longitudinal-joint efficiency: σ_h' = pd/(2t·η_l). The longitudinal stress acts across the <b>circumferential</b> seam: σ_l' = pd/(4t·η_c) (<a href=\"https://www.sathyabama.ac.in/sites/default/files/course-material/2020-10/UNIT-V_2.pdf\" target=\"_blank\" rel=\"noopener\">Sathyabama course material</a>). The notes' single η is correct only when both seams have the same efficiency." },
            { k: "h", t: "📘 Change of diameter, length and volume" },
            { k: "eq", expr: "ε_h = (σ_h − μσ_l)/E = (pd/4tE)(2 − μ)   ;   ε_l = (σ_l − μσ_h)/E = (pd/4tE)(1 − 2μ)   ;   ε_v = 2ε_h + ε_l = (pd/4tE)(5 − 4μ)", where: [
              ["δd = ε_h·d", "change of diameter"], ["δL = ε_l·L", "change of length"], ["δV = ε_v·V", "change of capacity"],
              ["source", "Sathyabama gives δd/d = (1 − μ/2)·pd/2tE and δL/L = (½ − μ)·pd/2tE — identical after rearranging; ε_v = 2ε_h + ε_l as in §1.4"],
            ] },
            { k: "h", t: "📘 Thin spherical shells" },
            { k: "eq", expr: "σ = pd/4t (every direction)   ;   ε_v = 3(1 − μ)·pd/(4tE)", where: [
              ["why", "any cut through the centre gives the transverse-cut free body of §7.1, so the stress equals the cylinder's longitudinal stress"],
              ["source", "Sathyabama course material; SuperTutor (absolute max shear = σ/2 = pd/8t)"],
            ] },
            { k: "p", t: "A sphere carries the same pressure with <b>half</b> the wall stress of a cylinder of the same diameter — the reason large gas holders (Horton spheres) are spherical, and why cylinders get hemispherical ends." },
            { k: "h", t: "📘 Circular water tanks — the same physics in RCC" },
            { k: "p", t: "The wall of a circular tank is a thin cylinder whose 'pressure' is the water pressure γ_w·h, which grows with depth. If the wall is free to slide at the base, the hoop tension per unit height at depth h is T = γ_w·h·D/2, maximum at the base: <b>T = γ_w·H·D/2</b>. It is carried by horizontal hoop steel at the low permissible stresses of IS 3370, which designs for no cracking or very fine cracks (<a href=\"https://www.studiomatrx.org/students/building-materials-construction-4/liquid-storage-structures\" target=\"_blank\" rel=\"noopener\">Studio Matrx — liquid storage structures</a>). A base fixed to the floor slab reduces the hoop tension near the bottom and introduces vertical bending — treated in the RCC handbook." },
            { k: "eg", title: "Worked example 7.2 — boiler shell with riveted joints", given: "Boiler shell d = 1.5 m, t = 15 mm, steam pressure 1.5 N/mm². Joint efficiencies: longitudinal 70%, circumferential 50%. Find: hoop and longitudinal stress (plate and at the joints), in-plane and absolute maximum shear. Then the thickness needed for an allowable 100 N/mm².", steps: [
              { t: "Plate stresses", w: "σ_h = 1.5 × 1500/(2 × 15) = 75 N/mm²;  σ_l = 37.5 N/mm²" },
              { t: "At the joints (each with its own η)", w: "σ_h' = 75/0.7 = 107.1 N/mm²;  σ_l' = 37.5/0.5 = 75.0 N/mm²" },
              { t: "Shear", w: "in-plane (75 − 37.5)/2 = 18.75;  absolute 75/2 = 37.5 N/mm²" },
              { t: "Thickness for 100 N/mm²", w: "Hoop: t = pd/(2ση_l) = 2250/(2 × 100 × 0.7) = 16.1 mm\nLongitudinal: t = pd/(4ση_c) = 2250/(4 × 100 × 0.5) = 11.25 mm  ⇒  hoop governs" },
            ], ans: "Joint stresses 107.1 and 75.0 N/mm²; absolute shear 37.5 N/mm² (twice the in-plane value); required t = 16.1 → 17 mm. Interpretation: even a weak circumferential seam rarely governs, because the longitudinal stress is only half the hoop stress." },
            { k: "eg", title: "Worked example 7.3 — how much a pressurised cylinder grows", given: "Cylinder d = 1.0 m, L = 3.0 m, t = 10 mm, p = 1.2 N/mm², E = 2 × 10⁵ N/mm², μ = 0.3. Find: change in diameter, length and volume.", steps: [
              { t: "Common factor", w: "pd/(4tE) = 1.2 × 1000/(4 × 10 × 2 × 10⁵) = 1.5 × 10⁻⁴" },
              { t: "Strains", w: "ε_h = 1.5 × 10⁻⁴ × 1.7 = 2.55 × 10⁻⁴;  ε_l = 1.5 × 10⁻⁴ × 0.4 = 0.60 × 10⁻⁴\nε_v = 1.5 × 10⁻⁴ × (5 − 1.2) = 5.70 × 10⁻⁴" },
              { t: "Changes", w: "δd = 2.55 × 10⁻⁴ × 1000 = 0.255 mm;  δL = 0.60 × 10⁻⁴ × 3000 = 0.18 mm\nV = π/4 × 1² × 3 = 2.356 m³;  δV = 5.70 × 10⁻⁴ × 2.356 = 1.34 × 10⁻³ m³ ≈ 1.34 litres" },
            ], ans: "δd = 0.255 mm, δL = 0.18 mm, δV ≈ 1.34 litres. Interpretation: this extra volume is why an additional quantity of water must be pumped in during a hydraulic pressure test before the gauge reaches test pressure." },
            { k: "eg", title: "Worked example 7.4 — sphere vs cylinder, and tank hoop tension", given: "(a) A spherical vessel of 2 m diameter and 12 mm wall holds gas at 1 N/mm². Find the wall stress. (b) A circular water tank of 10 m diameter holds 4 m of water, wall free at the base. Find the hoop tension at the base.", steps: [
              { t: "(a) Sphere", w: "σ = pd/4t = 1 × 2000/(4 × 12) = 41.7 N/mm²  (a cylinder of the same d and t: 83.3 in hoop)" },
              { t: "(b) Tank", w: "T = γ_w·H·D/2 = 9.81 × 4 × 10/2 = 196.2 kN per metre height" },
            ], ans: "(a) 41.7 N/mm²; (b) 196 kN/m at the base, falling linearly to zero at the water surface — so hoop steel is heaviest at the bottom and can be reduced upwards." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "τ_max = (σ_h − σ_l)/2 follows directly from the two principal stresses already found (σ_h and σ_l are themselves principal stresses on the cylinder wall, with the radial stress taken as negligible for a thin cylinder) — it is the same 'half the difference of the principal stresses' rule used for the combined bending-and-torsion shaft in Chapter 6. Dividing by the joint efficiency η (a fraction less than 1) always <b>increases</b> the design stress σ' above the plain-cylinder value, because a riveted or welded joint is inherently weaker than the solid parent plate." },
            { k: "trap", t: "η is always ≤ 1, so σ_h/η and σ_l/η are always ≥ σ_h and σ_l — do not divide the wrong way and end up reporting a joint stress lower than the plain-plate stress. Aur hoop ke saath longitudinal-joint ki η, longitudinal ke saath circumferential-joint ki η — ulta mat lagao." },
          ],
        },

        /* ---------------------------------------------- 7.4 */
        {
          n: "7.4",
          title: "Gravity dams — forces and the resultant's location",
          hi: "गुरुत्व बांध — बल और परिणामी की स्थिति",
          blocks: [
            { k: "h", t: "📘 Notes — p.17" },
            { k: "p", t: "A gravity dam has a trapezoidal cross-section, height H, base width b. Two forces act: the dam's self-weight W (vertical, through its centre of gravity) and the horizontal water pressure P (acting at H/3 above the base, pointing into the dam). Their resultant R is inclined at an angle θ to the vertical and crosses the base at some point away from mid-base — describing that point is the object of this section. (p.17)" },
            { k: "eq", expr: "Weight of the dam  W = γ × (A × 1)", where: [["γ", "unit weight of the dam material"], ["A", "cross-sectional area of the dam (per unit length)"]] },
            { k: "eq", expr: "Horizontal water pressure  P = (1/2)(wH)H = (1/2) w H²", where: [["w", "unit weight of water"], ["H", "height of water"]] },
            { k: "eq", expr: "x = (h/3) × (P/W)", where: [["x", "horizontal distance between the C.G. of the dam and the point where the resultant cuts the base"]] },
            { k: "note", t: "The notes derive x from P = R cos θ, W = R sin θ, so that P/W = cot θ = x/(h/3) — the algebra in this step is partly illegible in the transcript; the final results x = (h/3)(P/W) and e = (Z+x) − b/2 are given clearly and are what should be used. (p.17)" },
            { k: "note", t: "A cleaner route to the same x: take moments about the point where the resultant crosses the base. W acts x behind it and P acts H/3 above it, so W·x = P·H/3 ⇒ x = (H/3)(P/W) (derived)." },
            { k: "eq", expr: "e = (Z + x) − b/2", where: [
              ["e", "eccentricity — distance from the mid-point of the base to where the resultant cuts the base"],
              ["Z", "distance from the toe to the C.G. (projection on the base)"],
              ["x", "as defined above"], ["b", "base width"],
            ] },
            { k: "note", t: "With Z measured from the toe, Z + x would move the point the wrong way (P pushes the resultant <i>towards</i> the toe). The formula works as written if Z is measured from the <b>heel</b> (upstream end) — the convention used in Worked example 7.5." },
            { k: "h", t: "📘 The force the notes leave out — uplift" },
            { k: "p", t: "Water seeps under the dam and pushes <b>up</b> on its base. The usual assumption is a pressure varying linearly from the full head γ_w·H at the heel to zero (or the tailwater head) at the toe (<a href=\"https://bitmangalore.edu.in/wp-content/uploads/2025/05/Module-3.pdf\" target=\"_blank\" rel=\"noopener\">BIT Mangalore — gravity dam notes</a>). For full uplift that is U = ½·γ_w·H·b acting b/3 from the heel. Uplift reduces the effective weight <i>and</i> shifts the resultant towards the toe — the two most dangerous effects at once. Drainage galleries and grout curtains are provided to cut it down. Other forces (silt, waves, earthquake, ice) are listed in the same source and belong to the Irrigation/Hydraulic Structures handbook." },
            { k: "dia", id: "hb-som-dam" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "A gravity dam is stable purely by its own weight, so everything in this section is really just locating <b>where the resultant R of W and P lands on the base</b>. Z + x gives the distance of that landing point from the toe; subtracting b/2 converts that into an eccentricity e measured from the <b>middle</b> of the base — exactly the same 'e' that the core-of-a-section idea from Chapter 6 uses. That connection is the whole point of the next section: once e is known, the same no-tension logic as the core of a rectangular section decides whether the dam is safe." },
          ],
        },

        /* ---------------------------------------------- 7.5 */
        {
          n: "7.5",
          title: "Stresses at the base of a dam, the middle-third rule and stability",
          hi: "बांध के आधार पर प्रतिबल, मध्य-तिहाई नियम और स्थिरता",
          blocks: [
            { k: "h", t: "📘 Notes — p.17" },
            { k: "h", t: "Stresses developed at the base of the dam" },
            { k: "eq", expr: "σ_max = (W/b)(1 + 6e/b)     ;     σ_min = (W/b)(1 − 6e/b)" },
            { k: "note", t: "If σ_min comes out <b>negative</b>, it results in crippling/overturning of the dam, due to tensile stresses developing at the base (masonry/concrete dams cannot be relied on to resist tension). (p.17)" },
            { k: "p", t: "When uplift is included, W in these formulas becomes the <b>net</b> vertical force ΣV = W − U, and e is found from the resultant of all forces." },
            { k: "list", items: [
              "<b>Eccentricity e &lt; (b/2)/3 = b/6</b> → the resultant stays within the <b>middle third</b> of the base, which is required to resist tensile stress.",
              "<b>Eccentricity e &lt; b/2</b> → required to resist overturning of the dam (the resultant R must not cross outside the base).",
            ] },
            { k: "h", t: "📘 Factors of safety used in practice" },
            { k: "cmp", t: "Stability checks for a gravity dam", cols: ["Check", "Typical minimum"], rows: [
              ["Overturning", "FoS = Σ resisting moments / Σ overturning moments about the toe", "1.5"],
              ["Sliding (friction only)", "FoS = μ·ΣV / ΣH", "1.5 (BIT Mangalore notes)"],
              ["No tension", "resultant within the middle third (e ≤ b/6)", "—"],
              ["Crushing", "σ_max ≤ allowable compressive stress of masonry/concrete and of the foundation", "—"],
            ] },
            { k: "note", t: "Values from BIT Mangalore course notes (linked above). Detailed design of concrete gravity dams in India follows IS 6512 (criteria for design of solid gravity dams), which also uses a shear-friction factor that includes the shear strength of the foundation — not covered here." },
            { k: "h", t: "📘 Elementary profile — the minimum base width" },
            { k: "p", t: "The simplest gravity section is a right triangle (vertical upstream face, water to the top). Writing W = ½·b·H·γ_w·S (S = specific gravity of the masonry), P = ½·γ_w·H² and full uplift U = C·½·γ_w·H·b (C = 1 for full uplift) and requiring the resultant to pass through the downstream middle-third point gives (derived here):" },
            { k: "eq", expr: "No tension:  b = H/√S (no uplift)   ;   b = H/√(S − C) (with uplift)   ;   No sliding:  b = H/[μ(S − C)]", where: [
              ["S", "specific gravity of the dam material (≈ 2.2–2.4 for masonry/concrete)"],
              ["C", "uplift coefficient (1 = full uplift, 0 = none)"],
              ["μ", "coefficient of friction between dam and foundation"],
            ] },
            { k: "note", t: "<b>Source discrepancy caught:</b> the text extracted from one engineering-college note on this topic gives the two no-tension widths with the uplift / no-uplift labels the <i>other way round</i>. Uplift makes the dam lighter, so it must need a <b>wider</b> base — H/√(S − 1) > H/√S — which confirms the version above (also re-derived from moments). The swapped version is not used." },
            { k: "eg", title: "Worked example 7.5 — stability of a masonry gravity dam, with and without uplift", given: "Height 12 m with water to the top; vertical upstream face; top width 2 m; base 9 m. Masonry γ = 22.4 kN/m³, water γ_w = 9.81 kN/m³, μ = 0.7. Find: resultant position, base stresses, FoS against overturning and sliding — first ignoring uplift, then with full uplift.", steps: [
              { t: "Weights (per metre run) and their lever arms from the heel", w: "W₁ (rectangle 2 × 12) = 537.6 kN at 1.0 m\nW₂ (triangle 7 × 12/2) = 940.8 kN at 2 + 7/3 = 4.333 m\nΣW = 1478.4 kN at x̄ = 4614.4/1478.4 = 3.121 m" },
              { t: "Water thrust", w: "P = ½ × 9.81 × 12² = 706.3 kN at 4 m above the base" },
              { t: "No uplift — resultant and stresses", w: "Crosses base at 3.121 + 706.3 × 4/1478.4 = 5.032 m from heel\ne = 5.032 − 4.5 = 0.532 m < b/6 = 1.5 ✔\nσ = (1478.4/9)(1 ± 6 × 0.532/9) = 222.6 (toe) and 106.0 (heel) kPa" },
              { t: "No uplift — safety factors", w: "Overturning about toe: 1478.4 × (9 − 3.121)/(706.3 × 4) = 3.08\nSliding: 0.7 × 1478.4/706.3 = 1.47" },
              { t: "Full uplift", w: "U = ½ × 9.81 × 12 × 9 = 529.7 kN at 3 m from heel;  ΣV = 948.7 kN\nResultant at (4614.4 − 529.7 × 3 + 2825.2)/948.7 = 6.167 m ⇒ e = 1.667 > 1.5 ✘\nσ_heel = (948.7/9)(1 − 6 × 1.667/9) = −11.7 kPa (tension)" },
              { t: "Full uplift — safety factors", w: "Overturning: 1478.4 × 5.879/(2825.2 + 529.7 × 6) = 1.45 (< 1.5 ✘)\nSliding: 0.7 × 948.7/706.3 = 0.94 (< 1 — would slide ✘)" },
            ], ans: "Ignoring uplift the section passes every check (e = 0.53 m, FoS 3.08 and 1.47); with full uplift it fails all three (tension at the heel, overturning FoS 1.45, sliding 0.94). Cross-check with the elementary profile: S = 2.28 gives b = 7.9 m (no uplift) but 10.6 m (full uplift) for no tension — the 9 m base sits between them, exactly as found." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "σ_max = (W/b)(1+6e/b) and σ_min = (W/b)(1−6e/b) is exactly the direct-stress-plus-bending-stress formula (P/A ± M/Z) applied to a rectangular base of unit length: direct stress W/b plus/minus a bending term from the eccentric resultant. Setting σ_min = 0 and solving gives e = b/6 — which is precisely the rectangular-section core limit from Chapter 6 (e_max = b/6 for width b). So 'keep the resultant in the middle third' and 'keep the load inside the core of the (rectangular) base section' are the <b>same statement</b> in two different chapters of these notes." },
            { k: "real", t: "Isi liye bade dams mein foundation gallery aur drainage holes banaye jaate hain — uplift kam karne ke liye. Chhote check dams, retaining walls aur masonry weirs mein bhi wahi teen checks lagte hain: middle third, overturning aur sliding." },
            { k: "trap", t: "Two separate checks are needed and both must be satisfied: e &lt; b/6 (no tension anywhere at the base) is the <b>stricter</b> condition; e &lt; b/2 (resultant does not fall outside the base at all) only prevents outright overturning but still permits tension between b/6 and b/2. A dam can satisfy 'no overturning' (e &lt; b/2) while still failing the no-tension check (e &gt; b/6). Uplift ko ignore karna sabse badi galti hai — Worked example 7.5 dekho." },
          ],
        },

        /* ---------------------------------------------- 7.6 */
        {
          n: "7.6",
          title: "Quick revision — cylinders and dams",
          hi: "त्वरित पुनरावृत्ति",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Thin cylinder t &lt; d/20; thick cylinder t &gt; d/20 (p.17).",
              "σ_h = Pd/2t; σ_l = Pd/4t; σ_h = 2σ_l; both tensile (p.17).",
              "τ_max = (σ_h − σ_l)/2 = Pd/8t (p.17) in-plane; absolute τ_max = Pd/4t (§7.3).",
              "Thick cylinder (Lamé's theory): σ_r = A−B/r², σ_θ = A+B/r²; under internal pressure only, σ_θ,max = p(b²+a²)/(b²−a²) at the bore, σ_r = −p there (7.2, researched & verified).",
              "Joint efficiency: σ_h' = σ_h/η, σ_l' = σ_l/η (p.17) — η_l for hoop, η_c for longitudinal.",
              "ε_v = (pd/4tE)(5 − 4μ) cylinder; sphere σ = pd/4t, ε_v = 3(1 − μ)pd/4tE; tank hoop tension γHD/2 (§7.3).",
              "Dam: W = γ(A×1); P = ½wH²; x = (h/3)(P/W); e = (Z+x) − b/2 (p.17); uplift ½γ_wHb at b/3 from heel.",
              "σ_max = (W/b)(1+6e/b); σ_min = (W/b)(1−6e/b); negative σ_min → tension/crippling (p.17).",
              "e &lt; b/6 → middle third (no tension); e &lt; b/2 → no overturning (p.17); FoS overturning and sliding ≥ 1.5; elementary profile b = H/√(S − C).",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "Hoop stress is always the larger of the two thin-cylinder stresses (2× longitudinal) — the wall is more likely to split lengthwise than to pull apart at the ends.",
              "For a thick cylinder, that fixed 2:1 ratio disappears — Lamé's σ_θ and σ_r both vary with radius, and the design check always falls at the bore, where hoop stress is largest.",
              "The 'middle-third rule' for a dam base is exactly the rectangular-section core (e_max = b/6) from Chapter 6, applied to the dam's own base.",
              "A dam must pass both e &lt; b/6 (no tension, the stricter check) and e &lt; b/2 (no overturning).",
              "Uplift can turn a safe-looking dam unsafe on every check — never ignore it.",
            ] },
            { k: "h", t: "🔗 Related in Civil Educator" },
            { k: "list", items: [
              "<a href=\"#/read/som/6\">Ch. 6 — Core of a section</a> (middle third)",
              "<a href=\"#/read/som/2\">Ch. 2 — Principal stresses, theories of failure</a> (absolute shear)",
              "<a href=\"#/read/som/1\">Ch. 1 — Volumetric strain</a>",
              "Irrigation and Hydrology handbooks — dams, uplift, seepage in detail; RCC handbook — water tanks (IS 3370)",
            ] },
          ],
        },
      ],
    },
  );
})();
