/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: CONCRETE TECHNOLOGY handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.2 WATER-CEMENT RATIO */
  "hb-ct-wc": {
    label: "The water-cement ratio — the master variable",
    svg: `<svg viewBox="0 0 706 306" role="img" aria-label="A falling curve of concrete strength against water-cement ratio showing that strength drops sharply as more water is added, with a note that a little water is needed to hydrate the cement but any excess leaves voids that weaken the concrete.">
      ${hbmk("wc2")}
      <text class="em" x="350" y="24" text-anchor="middle">ONE NUMBER DECIDES STRENGTH MORE THAN ANY OTHER</text>
      <line class="s" x1="90" y1="230" x2="440" y2="230"/>
      <line class="s" x1="90" y1="56" x2="90" y2="230"/>
      <text class="lb" x="82" y="62" text-anchor="end">strength</text>
      <text class="lb" x="438" y="254" text-anchor="end">water / cement ratio →</text>
      ${[0.3,0.4,0.5,0.6,0.7].map((v,i)=>`<text class="lb" x="${120+i*72}" y="248" text-anchor="middle">${v}</text>`).join("")}
      <path class="hi" d="M104 72 C170 96 250 168 340 200 C380 214 410 222 428 226"/>
      <circle class="hif" cx="192" cy="140" r="5"/>
      <text class="ea" x="204" y="132">more water,</text>
      <text class="ea" x="204" y="150">weaker concrete</text>
      <text class="lb" x="300" y="120">Abram's law: strength falls</text>
      <text class="lb" x="300" y="138">as the w/c ratio rises</text>

      <line class="gl" x1="470" y1="56" x2="470" y2="290"/>
      <text class="em" x="488" y="82">why?</text>
      <text class="lb" x="486" y="108">cement needs only w/c ≈ 0.25</text>
      <text class="lb" x="488" y="126">to hydrate fully — chemically.</text>
      <text class="ea" x="486" y="156">every drop beyond that is there</text>
      <text class="ea" x="488" y="174">only to make it workable —</text>
      <text class="lb" x="488" y="200">and when it dries out it leaves</text>
      <text class="lb" x="488" y="218">VOIDS, and voids are weakness.</text>
      <text class="lb" x="486" y="252">use the LEAST water that still</text>
      <text class="lb" x="488" y="270">lets you place and compact it —</text>
      <text class="lb" x="486" y="288">workability: grading or admixture</text>
    </svg>`,
    caption: "This one ratio governs concrete more than the cement grade, the brand, or almost anything else. The cement needs only a little water to react; the rest is added merely to make the mix flow, and it evaporates later to leave voids. So the whole craft of concrete is a tension: enough water to place and compact it, as little water as possible so it ends up dense and strong. <strong>Every admixture and grading trick exists to place stiff, low-water concrete.</strong>",
  },

  /* ------------------------------------------- 3.1 SLUMP */
  "hb-ct-slump": {
    label: "The slump test — measuring workability",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A slump cone filled and lifted, with the concrete settling by an amount called the slump, and the three shapes of slump: a true slump for a cohesive mix, a shear slump where one side slips, and a collapse for a very wet mix.">
      ${hbmk("sl2")}
      <text class="em" x="350" y="24" text-anchor="middle">HOW FAR IT SETTLES = HOW WORKABLE IT IS</text>
      <path class="s" d="M70 200 L110 90 L150 90 L190 200 Z" fill="none"/>
      <text class="lb" x="130" y="220" text-anchor="middle">cone filled,</text>
      <text class="lb" x="130" y="238" text-anchor="middle">then lifted off</text>
      <line class="ac" x1="220" y1="145" x2="260" y2="145" marker-end="url(#sl2-c)"/>

      ${[["TRUE", 340, 40, "cohesive — good"], ["SHEAR", 470, 34, "one side slips"], ["COLLAPSE", 600, 20, "too wet — reject"]]
        .map(([t, x, h, n]) => `
        <text class="em" x="${x}" y="72" text-anchor="middle">${t}</text>
        <path class="hi dash" d="M${x - 34} 90 L${x + 34} 90"/>
        ${t === "TRUE"
          ? `<path class="soft" d="M${x - 30} ${200} L${x - 20} ${90 + h} L${x + 20} ${90 + h} L${x + 30} 200 Z"/>`
          : t === "SHEAR"
          ? `<path class="soft" d="M${x - 30} 200 L${x - 24} ${90 + h} L${x + 8} ${90 + h + 10} L${x + 30} 200 Z"/>`
          : `<path class="soft" d="M${x - 40} 200 L${x - 30} ${90 + h + 40} L${x + 30} ${90 + h + 46} L${x + 44} 200 Z"/>`}
        <line class="ac" x1="${x + 40}" y1="90" x2="${x + 40}" y2="${90 + h}" marker-end="url(#sl2-c)" marker-start="url(#sl2-c)"/>
        <text class="lb" x="${x}" y="234" text-anchor="middle">${n}</text>`).join("")}
      <text class="lb" x="130" y="262" text-anchor="middle">the drop in height is the SLUMP (mm)</text>
      <text class="lb" x="470" y="262" text-anchor="middle">only a TRUE slump is valid — shear / collapse = wrong mix</text>
      <text class="lb" x="350" y="288" text-anchor="middle">low slump = stiff, hard to place · high slump = wet, easy to place but watch the w/c</text>
    </svg>`,
    caption: "Workability is how easily concrete can be placed and compacted without segregating, and slump is its cheapest measure: fill a standard cone, lift it, and see how far the concrete sags. Only a true slump — the mass settling evenly — is a valid reading; a shear or collapse slump tells you the mix is harsh or too wet. <strong>The number you want is the lowest slump your placing method can still handle</strong>, because more slump usually means more water.",
  },

  /* ------------------------------------------- 3.3 COMPACTION / VOIDS */
  "hb-ct-voids": {
    label: "Why compaction matters — voids destroy strength",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two concrete samples: one poorly compacted and full of trapped air voids, one well compacted and dense, with a bar showing that only five percent of voids costs about thirty percent of the strength.">
      ${hbmk("vd")}
      <text class="em" x="350" y="24" text-anchor="middle">TRAPPED AIR IS THE ENEMY — AND IT IS FREE TO REMOVE</text>
      <text class="em" x="170" y="60" text-anchor="middle">POORLY COMPACTED</text>
      <rect class="conc" x="90" y="72" width="160" height="120"/>
      ${[[120,100],[180,96],[150,130],[210,120],[110,150],[190,160],[160,175],[128,120]].map(([cx,cy],i)=>
        `<circle class="softa an-pulse" style="--dur:3s;--del:${i*0.2}s" cx="${cx}" cy="${cy}" r="${7-i%3}"/>`).join("")}
      <text class="lb" x="170" y="210" text-anchor="middle">air pockets left behind</text>

      <text class="em" x="530" y="60" text-anchor="middle">WELL COMPACTED</text>
      <rect class="conc" x="450" y="72" width="160" height="120"/>
      ${[[480,100],[540,96],[510,130],[570,120],[470,150],[560,165],[520,175]].map(([cx,cy])=>
        `<circle class="steel" cx="${cx}" cy="${cy}" r="9"/>`).join("")}
      <text class="lb" x="530" y="210" text-anchor="middle">dense — vibrated tight</text>

      <line class="gl" x1="350" y1="66" x2="350" y2="200"/>
      <text class="em" x="350" y="248" text-anchor="middle">just 5% voids ≈ 30% loss of strength</text>
      <text class="lb" x="350" y="274" text-anchor="middle">compaction — rodding, vibrating — drives the trapped air out. It costs nothing but effort,</text>
      <text class="lb" x="350" y="292" text-anchor="middle">and it is the most common reason a good mix still gives a weak cube on site.</text>
    </svg>`,
    caption: "Compaction is the step that gets skipped and it is the one that quietly ruins good concrete. Air trapped during placing stays as voids, and voids are pure weakness — roughly 5% voids loses about 30% of the strength, a whole grade or more. The remedy costs nothing but effort: rod it, vibrate it, work the air out. <strong>A perfect mix, poorly compacted, gives a worse result than an ordinary mix well compacted.</strong>",
  },

  /* ------------------------------------------- 4.2 CUBE / CHAR STRENGTH */
  "hb-ct-cube": {
    label: "The cube test and characteristic strength",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A bell curve of concrete cube strengths with the characteristic strength marked at the point below which only five percent of results should fall, defined as the mean minus one point six five times the standard deviation, explaining why the target mean strength is set higher than the grade.">
      ${hbmk("cb")}
      <text class="em" x="350" y="24" text-anchor="middle">THE GRADE IS NOT THE AVERAGE — IT IS THE FLOOR</text>
      <line class="s" x1="70" y1="220" x2="630" y2="220"/>
      <path class="hi" d="M110 220 C230 220 250 80 350 80 C450 80 470 220 590 220" fill="none"/>
      <line class="thin dash" x1="350" y1="80" x2="350" y2="220"/>
      <text class="em" x="350" y="250" text-anchor="middle">target MEAN  fm</text>
      <line class="hi" x1="250" y1="220" x2="250" y2="150"/>
      <circle class="hif" cx="250" cy="150" r="5"/>
      <text class="em" x="250" y="250" text-anchor="middle">fck (the grade)</text>
      <path class="acf" d="M110 220 C200 220 225 175 250 150 L250 220 Z" opacity="0.5"/>
      <text class="ea" x="176" y="196">only 5%</text>
      <text class="lb" x="176" y="212">below fck</text>
      <line class="ac" x1="250" y1="120" x2="350" y2="120" marker-end="url(#cb-c)" marker-start="url(#cb-c)"/>
      <text class="lb" x="300" y="112" text-anchor="middle">1.65 σ</text>

      <text class="em" x="350" y="278" text-anchor="middle">fck = fm − 1.65 σ      so      target fm = fck + 1.65 σ</text>
      <text class="lb" x="350" y="296" text-anchor="middle">design for fm (above the grade) so that, even with scatter, only 1 in 20 cubes falls below fck</text>
    </svg>`,
    caption: "Concrete strength scatters — nominally identical cubes give a spread of results — so the grade cannot be the average, or half of every batch would be below spec. Instead fck, the characteristic strength, is the value only 5% of results should fall below. To hit it reliably you aim the mix at a higher <em>target mean</em>, fck + 1.65σ, where σ measures your site's scatter. <strong>Better control (smaller σ) lets you aim lower and use less cement.</strong>",
  },

  /* ------------------------------------------- 6.1 COVER / DURABILITY */
  "hb-ct-cover": {
    label: "Cover and exposure — how concrete protects steel",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A reinforced concrete section showing the cover as the depth of concrete over the steel, with carbonation and chloride advancing from the surface toward the bar over time, and the point that more aggressive exposure demands more cover and a lower water-cement ratio.">
      ${hbmk("cv")}
      <text class="em" x="350" y="24" text-anchor="middle">COVER IS A DURABILITY REQUIREMENT, NOT A DETAIL</text>
      <rect class="conc" x="90" y="70" width="300" height="150"/>
      <circle class="steel" cx="150" cy="180" r="12"/>
      <circle class="steel" cx="330" cy="180" r="12"/>
      <line class="ac" x1="90" y1="180" x2="138" y2="180" marker-end="url(#cv-c)" marker-start="url(#cv-c)"/>
      <text class="em" x="114" y="172" text-anchor="middle">cover</text>
      ${[0,1,2,3].map(i=>`<path class="hi dash" d="M90 ${92+i*30} L${138-i*8} ${92+i*30}"/>`).join("")}
      <text class="ea" x="240" y="104" text-anchor="middle">carbonation & chloride</text>
      <text class="lb" x="240" y="122" text-anchor="middle">advance inward with time →</text>
      <text class="lb" x="240" y="206" text-anchor="middle">the bar stays passive until the front reaches it</text>

      <line class="gl" x1="420" y1="56" x2="420" y2="290"/>
      <text class="em" x="438" y="82">two dials protect the steel:</text>
      <text class="ea" x="438" y="112">COVER — more depth = longer</text>
      <text class="lb" x="438" y="130">for the attack front to arrive</text>
      <text class="ea" x="438" y="160">w/c RATIO — lower = denser,</text>
      <text class="lb" x="438" y="178">less permeable, front moves slower</text>
      <text class="lb" x="438" y="212">IS 456 sets both by EXPOSURE:</text>
      <text class="lb" x="438" y="234">mild → severe → marine —</text>
      <text class="lb" x="438" y="256">harsher exposure demands more</text>
      <text class="lb" x="438" y="274">cover AND a lower maximum w/c</text>
    </svg>`,
    caption: "Concrete protects its reinforcement chemically — the alkaline paste keeps a passive film on the steel — but that protection is on a clock. Carbonation from the air and chloride from salt advance inward from the surface, and when the front reaches the bar the film breaks and rust begins. Two things buy time: more cover (a longer journey) and a lower w/c ratio (a denser, slower concrete). <strong>That is why the code ties both to exposure, not to the load.</strong>",
  },

});
