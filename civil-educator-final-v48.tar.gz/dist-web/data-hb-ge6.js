/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   Chapter 11 — Bearing Capacity of Shallow Foundations
   Chapter 12 — Piles, Deep Foundations and Site Investigation
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "ge"; });
  if (!hb) return;

  hb.chapters.push(

    /* =========================================================== CH 11 */
    {
      id: "ge-11",
      n: 11,
      title: "Bearing Capacity of Shallow Foundations",
      hi: "उथली नींव की वहन क्षमता",
      blurb: "Two separate questions that both have to be answered — and the one that usually decides is not the one students expect.",
      mins: 36,
      sections: [

        {
          n: "11.1",
          title: "Two criteria, not one",
          hi: "दो कसौटियाँ",
          blocks: [
            { k: "p", t: "A foundation must satisfy two quite separate requirements, and the allowable bearing pressure is whichever of them gives the smaller answer." },
            { k: "list", items: [
              "<strong>Shear failure</strong> — the soil must not fail in shear and let the footing punch into the ground. This chapter's Terzaghi analysis.",
              "<strong>Settlement</strong> — the foundation must not settle more than the structure can tolerate. Chapter 8.",
            ]},
            { k: "trap", t: "For footings on clay, and for almost all footings of any size, it is <strong>settlement that governs</strong>, not shear failure — often by a wide margin. A student who computes a beautiful ultimate bearing capacity and stops there has answered the easier half of the question. The safe bearing capacity quoted in a soil report is normally the settlement-limited value." },
            { k: "def", term: "Ultimate bearing capacity qu", t: "The gross pressure at which the soil fails in shear." },
            { k: "def", term: "Net ultimate bearing capacity qnu", t: "qu minus the overburden pressure γDf that was already there before the footing arrived. The soil at founding level was already carrying that, so it is not a new demand." },
            { k: "def", term: "Safe bearing capacity", t: "qnu divided by a factor of safety — conventionally 2.5 or 3 — plus the overburden added back if a gross value is wanted." },
            { k: "def", term: "Allowable bearing pressure", t: "The smaller of the safe bearing capacity and the pressure that produces the permissible settlement. <strong>This is the number that goes on the drawing.</strong>" },
          ],
        },

        {
          n: "11.2",
          title: "How a footing actually fails",
          hi: "फुटिंग कैसे फेल होती है",
          blocks: [
            { k: "dia", id: "hb-ge-bearing", cap: "A wedge pushed down, radial shear zones, and passive wedges lifted at the sides." },
            { k: "p", t: "Terzaghi's mechanism: a wedge of soil directly beneath the footing moves down with it, pushing two radial shear zones outwards, which in turn lift passive wedges at the sides. <strong>The footing can only go down if the soil beside it comes up</strong> — which is why founding deeper helps, and why a footing next to an excavation is in trouble." },
            { k: "eq", expr: "qu  =  c Nc  +  γ Df Nq  +  0.5 γ B Nγ", where: [
              ["c", "cohesion of the soil"],
              ["Df", "depth of founding below ground level"],
              ["B", "width of the footing"],
              ["Nc, Nq, Nγ", "bearing capacity factors, functions of φ alone"],
            ]},
            { k: "p", t: "Reading the three terms physically is what makes the formula stick:" },
            { k: "list", items: [
              "<strong>c Nc</strong> — the soil's cohesion resisting shear along the failure surface.",
              "<strong>γ Df Nq</strong> — the weight of soil <em>above</em> founding level, acting as a surcharge that has to be lifted. This is why <strong>going deeper increases capacity</strong>.",
              "<strong>0.5 γ B Nγ</strong> — the weight of soil <em>within</em> the failure zone. This is why a wider footing has a higher ultimate capacity, even though it may settle more.",
            ]},
            { k: "p", t: "IS 6403 gives the factors in closed form, which is more useful than a table because you can compute them for any φ:" },
            { k: "eq", expr: "Nq = e^(π tan φ) tan²(45 + φ/2)        Nc = (Nq − 1) cot φ        Nγ = 2(Nq + 1) tan φ", where: [] },
            { k: "note", t: "For a saturated clay under undrained conditions φ = 0, and the whole thing collapses: Nq = 1, Nγ = 0, Nc = 5.14. So <strong>qnu = 5.14 cu</strong> for a strip footing on clay — one of the most useful results in foundation engineering, and worth memorising because it needs no chart at all." },
            { k: "list", items: [
              "<strong>General shear failure</strong> — a well-defined failure surface reaching the ground surface, with heave beside the footing and a sudden collapse. Dense sand, stiff clay.",
              "<strong>Local shear failure</strong> — the surface does not develop fully; large settlement with no clear collapse. Loose sand, soft clay. Terzaghi suggested reducing c and tan φ to two-thirds of their values.",
              "<strong>Punching shear failure</strong> — the footing simply drives down with vertical shearing around its perimeter and no surface heave at all. Very loose or very soft soil.",
            ]},
          ],
        },

        {
          n: "11.3",
          title: "A footing worked through",
          hi: "एक उदाहरण",
          blocks: [
            { k: "eg",
              title: "Example 11.1 — Strip footing on sand",
              given: "A strip footing 2.0 m wide founded 1.5 m below ground level in a sand with φ = 32°, c = 0 and γ = 18 kN/m³. The water table is deep. Factor of safety 3.",
              steps: [
                { t: "Bearing capacity factors (IS 6403 expressions)", w: "tan 32° = 0.62487\ne^(π × 0.62487) = e^1.96307 = 7.121\ntan²(45 + 16) = tan²61° = 1.80405² = 3.2546\nNq = 7.121 × 3.2546 = 23.18" },
                { t: "The other two follow", w: "Nc = (Nq − 1) cot φ = 22.18/0.62487 = 35.49\nNγ = 2(Nq + 1) tan φ = 2 × 24.18 × 0.62487 = 30.21" },
                { t: "Ultimate bearing capacity", w: "c = 0, so the first term vanishes.\nqu = γ Df Nq + 0.5 γ B Nγ\n   = 18 × 1.5 × 23.18  +  0.5 × 18 × 2.0 × 30.21\n   = 625.8 + 543.8 = 1169.6 kPa" },
                { t: "Net ultimate", w: "qnu = qu − γ Df = 1169.6 − (18 × 1.5) = 1169.6 − 27.0\n    = 1142.6 kPa" },
                { t: "Net safe bearing capacity", w: "= 1142.6/3 = 380.9 kPa" },
                { t: "Gross safe bearing capacity", w: "= 380.9 + 27.0 = 407.9 kPa" },
              ],
              ans: "Net safe bearing capacity 381 kPa. But see the note below — this is the shear-failure answer only, and it is almost certainly not the number that would go on the drawing.",
            },
            { k: "trap", t: "381 kPa is an enormous pressure — far more than any ordinary building applies. Long before the sand came anywhere near shear failure, the footing would have settled more than the structure could take. <strong>This is precisely the case where settlement governs</strong>, and the allowable pressure would be set by a settlement calculation, probably in the range 150–250 kPa. Computing qnu and stopping is the classic mistake." },
            { k: "note", t: "IS 6403 also provides <strong>shape</strong> factors (a square or circular footing differs from a strip), <strong>depth</strong> factors, <strong>inclination</strong> factors for loads that are not vertical, and a <strong>water table</strong> correction — the γ in the Nγ term becomes γ′ when the water table is at or above the base, which nearly halves that term. Read them from the code; the physics of each is in the three terms above." },
            { k: "cmp", t: "IS 6403 shape and depth factors", cols: ["Strip", "Square", "Rectangle B × L"], rows: [
              ["sc", "1.0", "1.3", "1 + 0.2 B/L"],
              ["sq", "1.0", "1.2", "1 + 0.2 B/L"],
              ["sγ", "1.0", "0.8 (0.6 for a circle)", "1 − 0.4 B/L"],
              ["dc", "1 + 0.2 (Df/B) √Nφ", "same", "same"],
              ["dq = dγ", "1 + 0.1 (Df/B) √Nφ for φ > 10°; 1 for φ < 10°", "same", "same"],
            ]},
            { k: "note", t: "Factors as given in <a href=\"https://www.rcet.org.in/uploads/academics/rohini_87849619088.pdf\" target=\"_blank\" rel=\"noopener\">RCET notes</a> (Nφ = tan²(45 + φ/2)). <b>Conflict:</b> <a href=\"https://engineeringhulk.com/civil/geotechnical/bearing-capacity/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a> labels a different set (sq = 1 + tan φ, sγ = 0.6 for a square, dc = 1 + 0.4 Df/B) as IS 6403 — those are the Vesic/Hansen factors from international practice. Use the code's own table for Indian design." },
            { k: "eg",
              title: "Example 11.2 — Square footing on clay, undrained",
              given: "A 2.0 m square footing founded at 1.5 m in saturated clay, cu = 50 kPa, φ = 0. Factor of safety 3.",
              steps: [
                { t: "Factors for φ = 0", w: "Nc = 5.14, Nφ = 1\nsc = 1.3 (square);  dc = 1 + 0.2 × (1.5/2.0) × 1 = 1.15" },
                { t: "Net ultimate", w: "qnu = c Nc sc dc = 50 × 5.14 × 1.3 × 1.15 = 384.2 kPa" },
                { t: "Net safe", w: "384.2/3 = 128.1 kPa" },
              ],
              ans: "Net safe bearing capacity about 128 kPa — on clay this is close to what will actually be allowed, but the consolidation settlement of Chapter 8 must still be checked before it goes on the drawing." },
          ],
        },

        {
          n: "11.4",
          title: "Getting the numbers from the field",
          hi: "फ़ील्ड से मान",
          blocks: [
            { k: "p", t: "The analysis above needs c and φ. For sand, undisturbed sampling is essentially impossible, so field tests are used and correlations do the work." },
            { k: "list", items: [
              "<strong>Standard penetration test (SPT, IS 2131)</strong> — a split-spoon sampler driven by a 63.5 kg hammer falling 750 mm. N is the blows for the last 300 mm of a 450 mm drive. Correlations then give φ, relative density and allowable pressure. Corrections for overburden and for dilatancy in fine saturated sands must be applied before any correlation is used.",
              "<strong>Static cone penetration test (SCPT/CPT)</strong> — a cone pushed in at a steady rate, recording tip resistance and sleeve friction continuously. A far better record than the SPT's readings every 1.5 m, and it distinguishes strata a borehole log would miss.",
              "<strong>Plate load test (IS 1888)</strong> — a rigid plate loaded in increments on the ground at founding level, giving a direct load–settlement curve.",
            ]},
            { k: "trap", t: "The plate load test is the one to be careful with. A 300 mm plate stresses the soil to about half a metre; a 3 m footing stresses it to four or five metres. If there is a soft layer at 2 m depth, <strong>the plate never finds it and the footing certainly will</strong>. Plate load results must be extrapolated with the scale rules — and never trusted at all if the borehole log shows anything unpleasant within a footing width or two of the base." },
            { k: "real", t: "This is the same lesson as the pressure bulb in Chapter 6, and it is worth stating once more because it recurs everywhere: <strong>the depth of soil that matters scales with the size of the loaded area</strong>. The investigation must be designed around the largest foundation, not the average one." },
          ],
        },

        {
          n: "11.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Two criteria: shear failure and settlement. The smaller governs, and it is usually settlement.",
              "qu = cNc + γDf Nq + 0.5γB Nγ — cohesion, surcharge above, weight within.",
              "Nq = e^(π tanφ) tan²(45+φ/2); Nc = (Nq−1)cotφ; Nγ = 2(Nq+1)tanφ.",
              "For saturated clay, φ = 0 gives qnu = 5.14 cu.",
              "Net values exclude the overburden that was already there.",
              "Water table at or above the base nearly halves the Nγ term.",
              "SPT and CPT for sands; plate load tests only stress the soil to about twice the plate width.",
            ]},
            { k: "p", t: "Chapter 12 deals with what to do when none of this works — when the soil near the surface cannot carry the load at any width, and the structure has to reach past it." },
          ],
        },
      ],
    },

    /* =========================================================== CH 12 */
    {
      id: "ge-12",
      n: 12,
      title: "Piles, Deep Foundations and Site Investigation",
      hi: "पाइल, गहरी नींव और स्थल अन्वेषण",
      blurb: "Going through the bad ground rather than sitting on it — and the investigation that should have come first.",
      mins: 36,
      sections: [

        {
          n: "12.1",
          title: "When a shallow foundation will not do",
          hi: "जब उथली नींव काफ़ी न हो",
          blocks: [
            { k: "list", items: [
              "The soil near the surface is too weak or too compressible at any practical footing width.",
              "The loads are very heavy or concentrated.",
              "There is <strong>uplift</strong> to resist — a transmission tower, a basement below the water table.",
              "There are <strong>horizontal</strong> loads — a bridge pier, a quay wall.",
              "Scour is expected, as at any bridge in a river.",
              "The soil is expansive and seasonal movement must be bypassed — black cotton soil, where the foundation is taken below the zone of moisture change.",
            ]},
            { k: "p", t: "A pile transfers load to deeper, better ground. The confusion worth clearing at the start is that piles are usually named for one mechanism and rely on both." },
          ],
        },

        {
          n: "12.2",
          title: "Where the capacity comes from",
          hi: "क्षमता कहाँ से",
          blocks: [
            { k: "dia", id: "hb-ge-piles", cap: "Shaft friction along the side, end bearing at the toe — and a group that may fail as a block." },
            { k: "eq", expr: "Qu  =  Qp  +  Qs  =  qp Ap  +  Σ(fs As)", where: [
              ["Qp", "end bearing at the toe"],
              ["Qs", "shaft (skin) friction along the sides"],
            ]},
            { k: "eq", expr: "in clay:   Qp = 9 cu Ap        Qs = α cu × perimeter × L", where: [
              ["α", "adhesion factor — about 1.0 for soft clay, falling to 0.4 or less for stiff clay"],
            ]},
            { k: "p", t: "The 9 is Nc for a deep circular foundation — the same bearing capacity factor as Chapter 11, larger because the failure surface is fully confined and cannot reach the ground surface. The α factor accounts for the fact that driving or boring a pile remoulds the clay around it, so the adhesion available is less than the intact strength." },
            { k: "eg",
              title: "Example 12.1 — A single pile in clay",
              given: "A 400 mm diameter bored pile, 12 m long, in a uniform clay with cu = 60 kPa. Take the adhesion factor α = 0.5. Factor of safety 2.5.",
              steps: [
                { t: "Geometry", w: "perimeter = π × 0.4 = 1.2566 m\nend area  = (π/4) × 0.4² = 0.12566 m²" },
                { t: "Shaft friction", w: "Qs = α cu × perimeter × L\n   = 0.5 × 60 × 1.2566 × 12 = 452.4 kN" },
                { t: "End bearing", w: "Qp = 9 cu Ap = 9 × 60 × 0.12566 = 67.9 kN" },
                { t: "Ultimate and safe capacity", w: "Qu = 452.4 + 67.9 = 520.3 kN\nQsafe = 520.3/2.5 = 208.1 kN" },
                { t: "Where the capacity actually came from", w: "shaft: 452.4/520.3 = 87%\ntoe:    67.9/520.3 = 13%" },
              ],
              ans: "208 kN safe working load — and 87% of it comes from the shaft. A pile in uniform clay is a friction pile whatever anyone calls it, and lengthening it is far more effective than widening it.",
            },
            { k: "trap", t: "That last line is the design lesson. Shaft friction grows with <strong>perimeter × length</strong> and end bearing with <strong>area</strong>. Doubling the diameter doubles the friction and quadruples the end bearing — but in clay the end bearing was only 13% to begin with. <strong>For a friction pile, length beats diameter</strong>; for an end bearing pile founded on rock, the reverse." },
          ],
        },

        {
          n: "12.3",
          title: "Pile groups",
          hi: "पाइल समूह",
          blocks: [
            { k: "p", t: "Piles are almost never used singly — they come in groups under a pile cap, and a group is not simply the sum of its piles. Their stress zones overlap, so each pile's zone of influence is shared with its neighbours." },
            { k: "eq", expr: "group efficiency  η  =  capacity of the group / (n × capacity of a single pile)", where: [] },
            { k: "list", items: [
              "<strong>In sand</strong>, driving densifies the soil between piles, and η can exceed 1.0. Group action is usually not a problem.",
              "<strong>In clay</strong>, η is less than 1.0, and the group must also be checked for <strong>block failure</strong> — the piles, the cap and the soil between them failing as one large deep foundation.",
              "<strong>Spacing</strong> is typically 2.5 to 3.5 times the diameter. Closer and the efficiency falls sharply; wider and the pile cap becomes uneconomically large.",
            ]},
            { k: "eg",
              title: "Example 12.2 — Does the block govern?",
              given: "Nine of the piles from Example 12.1 in a 3 × 3 group at 1.2 m centres. Same clay, cu = 60 kPa.",
              steps: [
                { t: "Sum of the individual capacities", w: "9 × 520.3 = 4683 kN (ultimate)" },
                { t: "Block dimensions", w: "Bg = (3 − 1) × 1.2 + 0.4 = 2.8 m square" },
                { t: "Block capacity — base plus sides", w: "base: 9 cu Bg² = 9 × 60 × 2.8² = 9 × 60 × 7.84 = 4234 kN\nsides: cu × perimeter × L = 60 × (4 × 2.8) × 12 = 8064 kN\nQblock = 4234 + 8064 = 12,298 kN" },
                { t: "Which governs", w: "12,298 kN (block)  vs  4683 kN (sum of singles)\nThe smaller governs → individual pile failure, 4683 kN ultimate" },
              ],
              ans: "Individual failure governs here, at 4683 kN ultimate. Block failure would only become critical at much closer spacing — which is exactly why the 2.5–3.5 diameter spacing rule exists, and why it should not be reduced without checking this.",
            },
            { k: "trap", t: "A pile group settles far more than a single pile carrying the same load per pile, because the group's stress bulb is as wide as the whole group and reaches correspondingly deeper — the Chapter 6 lesson again. A group settlement check on the equivalent raft at two-thirds of the pile length is standard, and it is a separate calculation from capacity." },
          ],
        },

        {
          n: "12.4",
          title: "Types, and how they are proved",
          hi: "प्रकार और परीक्षण",
          blocks: [
            { k: "cmp", t: "Driven against bored — the choice is usually made by the site, not by the calculation.",
              cols: ["Driven (displacement)", "Bored (replacement)"],
              rows: [
                ["Installation", "Hammered or vibrated in; soil is displaced", "Soil is removed and the pile cast in the hole"],
                ["Effect on surrounding soil", "<strong>Densifies</strong> sand — helpful; remoulds clay", "Slight relief of stress; no densification"],
                ["Noise and vibration", "Severe — often unacceptable in a town", "Modest"],
                ["Quality control", "The driving record itself is evidence", "Concrete quality below ground is hard to verify — integrity testing needed"],
                ["Suits", "Sands, sites with room and no neighbours", "Urban sites, large diameters, sockets into rock"],
                ["Spoil", "None", "Arisings to dispose of, and possibly contaminated"],
              ] },
            { k: "list", items: [
              "<strong>Dynamic formulae</strong> (Engineering News, Hiley) estimate capacity from the set achieved per blow. Cheap, available on every driven pile, and unreliable in clay because they take no account of pore pressure.",
              "<strong>Static formulae</strong> — the Example 12.1 calculation, from soil parameters.",
              "<strong>Pile load test (IS 2911 Part 4)</strong> — the real answer. A pile is loaded in increments and its settlement recorded. <strong>Initial</strong> tests on sacrificial piles, taken to about 2.5 times the safe load, establish capacity; <strong>routine</strong> tests on working piles, to about 1.5 times, verify construction — and acceptance is by settlement criteria, not peak load alone (<a href=\"https://infralens.in/code/IS-2911-Part-1-Sec-1-2010/clause/load-test\" target=\"_blank\" rel=\"noopener\">InfraLens</a>).",
              "<strong>Integrity testing</strong> — low-strain sonic methods that detect necking or a soft toe in a bored pile. Not a capacity test; a construction check.",
            ]},
            { k: "trap", t: "<strong>Negative skin friction</strong> is the failure mode that catches people. If the ground around a pile is consolidating — because of a new fill, a lowered water table, or Chapter 8's settlement — the soil moves <em>down relative to the pile</em>. The friction then acts downwards, adding load instead of carrying it. A pile designed for 200 kN of positive friction can receive a comparable downdrag instead, and the error is nearly 2:1." },
          ],
        },

        {
          n: "12.5",
          title: "Site investigation, and closing the loop",
          hi: "स्थल अन्वेषण और निष्कर्ष",
          blocks: [
            { k: "eg",
              title: "Example 12.3 — Downdrag from a new fill",
              given: "The 400 mm pile of Example 12.1 passes through 4.0 m of soft clay (cu = 20 kPa) that will consolidate under a new fill. Take α = 1.0 for the downdrag zone.",
              steps: [
                { t: "Negative skin friction", w: "Fn = α cu × perimeter × length = 1.0 × 20 × 1.2566 × 4.0 = 100.5 kN" },
                { t: "Effect on the safe load", w: "the friction lost in that zone no longer helps, and 100.5 kN is added as load:\nsafe working load must be reduced accordingly — here by nearly half of 208 kN" },
              ],
              ans: "About 100 kN of downdrag on a pile whose safe capacity was 208 kN. It must be designed for — or the pile sleeved/coated through the consolidating layer." },
            { k: "p", t: "Everything in this handbook has assumed you know what the soil is. Site investigation is where that knowledge comes from, and it is the cheapest risk reduction available on any project — typically well under 1% of the construction cost, and the single most common source of claims when it is skimped." },
            { k: "list", items: [
              "<strong>Desk study and walkover</strong> first. Geological maps, old plans, aerial photographs, and half an hour walking the site. Free, and it tells you where to put the boreholes.",
              "<strong>Depth</strong> — to at least 1.5 times the width of the largest loaded area, or to a proven competent stratum, whichever is deeper. For a pile group, well below the toe.",
              "<strong>Spacing</strong> — closer where the geology is erratic. Two boreholes that agree tell you less than two that disagree.",
              "<strong>Sampling</strong> — disturbed samples for classification, undisturbed for strength and consolidation. An undisturbed sample of soft clay is a matter of degree, not of fact.",
              "<strong>Groundwater</strong> — the level, the seasonal variation, and any artesian pressure. Chapter 5 explains why this is the most important single observation in the report.",
            ]},
            { k: "p", t: "Twelve chapters back this handbook began by saying that soil is the material nobody specified. It is worth seeing what held the subject together all the same." },
            { k: "list", items: [
              "<strong>Effective stress</strong> (Ch 5) is the thread. A rising water table, seepage at a dam toe, a clay consolidating, a cutting swelling over decades, a sand liquefying — every one of them is σ′ changing while σ stays exactly where it was.",
              "<strong>Drainage and time</strong> decide which material you have. The same clay is one thing in an hour and another in ten years, and choosing the wrong one is not conservative — it is the wrong question.",
              "<strong>Scale</strong> recurs: the depth that matters grows with the width of the loaded area, whether it is a footing, a plate test or a pile group.",
              "<strong>Everything is measured on a sample</strong> that is no longer in the ground. Respect for that gap is what separates a geotechnical engineer from a calculator.",
            ]},
            { k: "note", t: "Values and methods here are set out for learning. Before using any of them on work that will be built, confirm against the governing standard — IS 1498 for classification, the IS 2720 series for testing, IS 6403 for bearing capacity, IS 1904 for foundation design, IS 2911 for piles — and against a site investigation that actually went deep enough." },
          ],
        },
      ],
    }

  );
})();
