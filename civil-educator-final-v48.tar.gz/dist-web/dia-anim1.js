/* ============================================================
   CIVIL EDUCATOR — ANIMATED DIAGRAMS, SET 1
   The mechanisms a still picture cannot teach: things that
   HAPPEN. Buckling, twisting, rippling, a block forming.

   Contract for every figure in this file:
     · anim: true          → the reader gets a "▶ animated" marker
     · authored AT REST    → with motion turned off it still reads
                             correctly as an ordinary diagram
     · the caption says what to watch for, because a reader who
       cannot see motion must still get the lesson in words.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ======================================================= STEEL: BUCKLING */
  "an-st-buckle": {
    label: "Watch a slender column go",
    anim: true,
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Three columns of the same steel and area under increasing load. The short one stays straight and squashes at full strength. The medium one bows moderately. The slender one bows far out to the side and fails at a small fraction of the load, showing that length and not material decides the capacity.">
      ${hbmk("anb")}
      <text class="em" x="350" y="24" text-anchor="middle">SAME STEEL · SAME AREA · WATCH WHICH ONE MOVES</text>

      ${[["SHORT", 120, "KL/r = 30", "fails at fy — full strength", 0],
         ["MEDIUM", 350, "KL/r = 90", "bows, then fails early", 10],
         ["SLENDER", 580, "KL/r = 160", "buckles long before fy", 26]]
        .map(([t, x, sl, note, amp]) => `
        <text class="em" x="${x}" y="52" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="70" text-anchor="middle">${sl}</text>
        ${grd(x - 34, 250, 68)}
        <line class="thin dash" x1="${x}" y1="96" x2="${x}" y2="250"/>
        <path class="hi an-sway" style="--amp:${amp};--dur:3.4s" d="M${x} 250 C${x} 210 ${x} 140 ${x} 96"/>
        <line class="ac an-sway" style="--amp:${Math.round(amp * 0.9)};--dur:3.4s" x1="${x}" y1="66" x2="${x}" y2="90" marker-end="url(#anb-c)"/>
        <text class="lb" x="${x}" y="276" text-anchor="middle">${note}</text>`).join("")}

      <line class="gl" x1="236" y1="42" x2="236" y2="284"/>
      <line class="gl" x1="466" y1="42" x2="466" y2="284"/>
      <text class="em" x="350" y="306" text-anchor="middle">nothing about the MATERIAL changed — only the length</text>
    </svg>`,
    caption: "Watch only the third column. All three are the same grade and the same area, and the first two are still nearly straight when the slender one has already swung out. That is why Chapter 6 spends its time on KL/r and not on fy — <strong>length decides a column, not strength</strong>.",
  },

  /* ============================================== STEEL: LATERAL-TORSIONAL */
  "an-st-ltb": {
    label: "Lateral-torsional buckling, happening",
    anim: true,
    svg: `<svg viewBox="0 0 750 330" role="img" aria-label="A beam seen in elevation and in cross section. As load is applied the top compression flange swings sideways out of the plane while the bottom tension flange stays in place, so the cross section both translates and rotates. Beside it, the same beam with a restraint at mid span barely moves.">
      ${hbmk("anl")}
      <text class="em" x="350" y="24" text-anchor="middle">THE TOP FLANGE LEAVES · THE BOTTOM ONE STAYS · SO IT TWISTS</text>

      <text class="lb" x="60" y="60">UNRESTRAINED — plan view of the flanges</text>
      <line class="thin dash" x1="70" y1="92" x2="560" y2="92"/>
      <path class="hi an-sway" style="--amp:22;--dur:3.8s" d="M70 92 C210 58 420 58 560 92"/>
      <text class="ea" x="570" y="96">compression flange</text>
      <line class="s" x1="70" y1="130" x2="560" y2="130"/>
      <text class="lb" x="570" y="134">tension flange — stays put</text>
      <line class="ac" x1="315" y1="152" x2="315" y2="176" marker-end="url(#anl-c)"/>
      <text class="lb" x="327" y="172">load, in the plane of the web</text>

      <text class="lb" x="60" y="212">SECTION AT MID-SPAN</text>
      <g class="an-twist" style="--rot:15;--amp:14;--dur:3.8s" transform-origin="150 262">
        <rect class="conc" x="104" y="222" width="92" height="10"/>
        <rect class="conc" x="145" y="232" width="10" height="60"/>
        <rect class="conc" x="104" y="292" width="92" height="10"/>
      </g>
      <text class="lb" x="222" y="250">it moves sideways</text>
      <text class="lb" x="222" y="270">AND rotates —</text>
      <text class="em" x="222" y="292">both at the same instant</text>

      <line class="gl" x1="398" y1="196" x2="398" y2="316"/>
      <text class="lb" x="424" y="212">NOW HOLD IT AT MID-SPAN</text>
      <line class="thin dash" x1="424" y1="248" x2="664" y2="248"/>
      <path class="hi an-sway" style="--amp:5;--dur:3.8s" d="M424 248 C484 238 604 238 664 248"/>
      <rect class="steel" x="538" y="232" width="12" height="32"/>
      <text class="ea" x="544" y="226" text-anchor="middle">restraint</text>
      <text class="em" x="424" y="286">barely moves — and the beam is</text>
      <text class="em" x="424" y="306">worth 79% more (Example 8.2)</text>
    </svg>`,
    caption: "The reason the mode is called lateral-<em>torsional</em> is in the section at the bottom left: the top flange is trying to go and the bottom flange will not let it, so the section has no option but to rotate. Compare the right-hand side — <strong>one restraint at mid-span, and almost all the movement is gone</strong>.",
  },

  /* ===================================================== STEEL: LOCAL BUCKLE */
  "an-st-local": {
    label: "A flange outstand rippling",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two I sections in compression. The one with a thick stocky flange stays flat and reaches its full strength. The one with a thin wide flange outstand ripples out of plane and loses capacity before the member as a whole has done anything.">
      ${hbmk("anlo")}
      <text class="em" x="350" y="24" text-anchor="middle">THE PLATE GIVES UP BEFORE THE MEMBER DOES</text>

      <text class="em" x="168" y="58" text-anchor="middle">b/tf = 7  ·  STOCKY</text>
      <rect class="conc" x="84" y="86" width="168" height="18"/>
      <rect class="conc" x="152" y="104" width="32" height="96"/>
      <rect class="conc" x="84" y="200" width="168" height="18"/>
      <line class="ac" x1="168" y1="60" x2="168" y2="80" marker-end="url(#anlo-c)"/>
      <text class="lb" x="168" y="244" text-anchor="middle">stays flat all the way</text>
      <text class="em" x="168" y="268" text-anchor="middle">reaches Zp fy — CLASS 1</text>

      <line class="gl" x1="348" y1="46" x2="348" y2="284"/>

      <text class="em" x="524" y="58" text-anchor="middle">b/tf = 17  ·  THIN AND WIDE</text>
      <rect class="conc" x="418" y="94" width="212" height="8"/>
      <path class="hi an-ripple" style="--sc:2.6;--dur:2.2s" transform-box="fill-box" transform-origin="center"
            d="M418 94 C452 82 486 106 524 94 C562 82 596 106 630 94"/>
      <rect class="conc" x="514" y="102" width="20" height="98"/>
      <rect class="conc" x="418" y="200" width="212" height="8"/>
      <path class="hi an-ripple" style="--sc:2.6;--dur:2.2s;--del:.3s" transform-box="fill-box" transform-origin="center"
            d="M418 208 C452 220 486 196 524 208 C562 220 596 196 630 208"/>
      <line class="ac" x1="524" y1="60" x2="524" y2="86" marker-end="url(#anlo-c)"/>
      <text class="lb" x="524" y="244" text-anchor="middle">the outstand waves out of plane</text>
      <text class="em" x="524" y="268" text-anchor="middle">never gets there — CLASS 4</text>
    </svg>`,
    caption: "Both sections have the same depth, the same steel and nearly the same area. The only difference is how the flange metal is spread. <strong>ε = √(250/fy) and the b/tf limits of Table 2 are entirely about which of these two you have built</strong> — and a class 4 section never delivers what the section table promises.",
  },

  /* ================================================= STEEL: WEB SHEAR BUCKLE */
  "an-st-webbuckle": {
    label: "A plate girder web buckling in shear",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two plate girder web panels carrying the same shear. The wide panel between distant stiffeners buckles into diagonal waves along its compression diagonal. The short panel between close stiffeners stays flat and reaches its full shear yield capacity.">
      ${hbmk("anw")}
      <text class="em" x="350" y="24" text-anchor="middle">SAME WEB · SAME SHEAR · ONLY THE STIFFENER SPACING DIFFERS</text>

      <text class="lb" x="168" y="56" text-anchor="middle">c/d = 1.0 — stiffeners 1500 apart</text>
      <rect class="soft" x="62" y="72" width="212" height="132"/>
      <rect class="steel" x="62" y="72" width="11" height="132"/>
      <rect class="steel" x="263" y="72" width="11" height="132"/>
      ${[0, 1, 2, 3].map(i => `<path class="hi an-ripple" style="--sc:${2.2 + i * 0.1};--dur:2.6s;--del:${i * 0.12}s"
            transform-box="fill-box" transform-origin="center"
            d="M${84 + i * 46} 198 C${100 + i * 46} 160 ${112 + i * 46} 118 ${128 + i * 46} 78"/>`).join("")}
      <text class="em" x="168" y="230" text-anchor="middle">it ripples along the compression diagonal</text>
      <text class="lb" x="168" y="254" text-anchor="middle">τb = 43 N/mm²  ·  Vd = 586 kN</text>
      <text class="lb" x="168" y="276" text-anchor="middle">only 30% of what the steel could give</text>

      <line class="gl" x1="348" y1="44" x2="348" y2="288"/>

      <text class="lb" x="524" y="56" text-anchor="middle">c/d = 0.5 — stiffeners 750 apart</text>
      <rect class="soft" x="418" y="72" width="212" height="132"/>
      ${[0, 1, 2, 3, 4].map(i => `<rect class="steel" x="${418 + i * 50}" y="72" width="11" height="132"/>`).join("")}
      <rect class="steel" x="619" y="72" width="11" height="132"/>
      ${[0, 1, 2, 3].map(i => `<line class="thin dash" x1="${436 + i * 50}" y1="198" x2="${466 + i * 50}" y2="78"/>`).join("")}
      <text class="em" x="524" y="230" text-anchor="middle">each panel is too short to buckle</text>
      <text class="lb" x="524" y="254" text-anchor="middle">τb = 140 N/mm²  ·  Vd = 1904 kN</text>
      <text class="em" x="524" y="276" text-anchor="middle">3.25 × the capacity, from a few plates</text>
    </svg>`,
    caption: "The stiffeners are carrying almost no shear themselves. They are shortening the panel so the compression diagonal has less length in which to buckle — kv climbs from 5.35 to 25.4, and with it the whole capacity. <strong>Geometry, not steel</strong>.",
  },

  /* ===================================================== RCC: STRESS BLOCK */
  "an-rcc-block": {
    label: "The stress block forming as load increases",
    anim: true,
    svg: `<svg viewBox="0 0 744 320" role="img" aria-label="A reinforced concrete beam section under increasing load. The strain diagram grows and stays straight, while the stress diagram starts almost triangular and becomes the parabolic rectangular block as the top fibre strain reaches its limit of 0.0035, at which point the compressive force is 0.36 fck b xu acting at 0.42 xu from the top.">
      ${hbmk("anr")}
      <text class="em" x="350" y="24" text-anchor="middle">LOAD GOING UP · WATCH THE STRESS SHAPE CHANGE</text>

      <text class="lb" x="96" y="56" text-anchor="middle">SECTION</text>
      <rect class="conc" x="52" y="72" width="88" height="182"/>
      <line class="thin dash" x1="40" y1="150" x2="286" y2="150"/>
      <text class="lb" x="36" y="154" text-anchor="end">N.A.</text>
      <circle class="steel" cx="70" cy="234" r="8"/>
      <circle class="steel" cx="96" cy="234" r="8"/>
      <circle class="steel" cx="122" cy="234" r="8"/>

      <text class="lb" x="216" y="56" text-anchor="middle">STRAIN</text>
      <line class="s" x1="180" y1="72" x2="180" y2="254"/>
      <path class="softa an-growx" style="--dur:5s" transform-box="fill-box" transform-origin="right center"
            d="M180 150 L180 72 L262 72 Z"/>
      <path class="soft-b an-growx" style="--dur:5s" transform-box="fill-box" transform-origin="left center"
            d="M180 150 L180 254 L104 254 Z"/>
      <text class="ea" x="268" y="68">0.0035</text>
      <text class="lb" x="216" y="278" text-anchor="middle">always a straight line —</text>
      <text class="lb" x="216" y="296" text-anchor="middle">plane sections stay plane</text>

      <line class="gl" x1="312" y1="44" x2="312" y2="304"/>

      <text class="lb" x="430" y="56" text-anchor="middle">STRESS — early load</text>
      <line class="s" x1="366" y1="72" x2="366" y2="254"/>
      <path class="softa" d="M366 150 L366 100 L404 100 Z"/>
      <text class="lb" x="430" y="200" text-anchor="middle">nearly triangular —</text>
      <text class="lb" x="430" y="218" text-anchor="middle">concrete still elastic</text>

      <text class="em" x="588" y="56" text-anchor="middle">STRESS — at collapse</text>
      <line class="s" x1="518" y1="72" x2="518" y2="254"/>
      <path class="softa an-grow" style="--dur:5s" d="M518 72 L570 72 L570 105 C566 124 548 140 518 150 Z"/>
      <line class="thin dash" x1="518" y1="105" x2="600" y2="105"/>
      <text class="lb" x="606" y="86">0.446 fck</text>
      <text class="lb" x="606" y="109">3/7 xu — rectangular</text>
      <text class="lb" x="606" y="134">4/7 xu — parabolic</text>
      <line class="hi an-blink" style="--dur:5s" x1="518" y1="122" x2="576" y2="122" marker-end="url(#anr-m)"/>
      <text class="em" x="518" y="200">Cu = 0.36 fck b xu</text>
      <text class="em" x="518" y="222">acting at 0.42 xu from the top</text>
      <text class="lb" x="518" y="248">— and §3.3 derives both numbers</text>
    </svg>`,
    caption: "The strain diagram stays a straight line the whole way — that is the plane-sections assumption doing its work. The <em>stress</em> diagram is the one that changes shape, because concrete stops being elastic long before it crushes. <strong>0.36 and 0.42 are just the area and the centroid of the final shape</strong>.",
  },

  /* ================================================ RCC: TWO FAILURE MODES */
  "an-rcc-fail": {
    label: "Under-reinforced against over-reinforced, side by side",
    anim: true,
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Two beams under the same increasing load. The under reinforced beam sags a great deal and opens wide cracks over a long period before the concrete finally crushes. The over reinforced beam stays almost straight with hairline cracks and then the compression zone crushes suddenly with no warning.">
      ${hbmk("anf")}
      <text class="em" x="350" y="24" text-anchor="middle">BOTH FAIL AT A SIMILAR LOAD — WATCH HOW DIFFERENTLY</text>

      <text class="em" x="168" y="56" text-anchor="middle">UNDER-REINFORCED  (xu &lt; xu,max)</text>
      <line class="thin dash" x1="48" y1="92" x2="292" y2="92"/>
      <path class="hi an-sag" style="--amp:30;--dur:4s" d="M48 92 C130 92 210 92 292 92"/>
      ${grd(38, 98, 22)} ${grd(282, 98, 22)}
      ${[0, 1, 2, 3, 4].map(i => `<line class="ac an-sag" style="--amp:${26 - Math.abs(i - 2) * 4};--dur:4s"
            x1="${120 + i * 24}" y1="96" x2="${120 + i * 24}" y2="${118 - Math.abs(i - 2) * 3}"/>`).join("")}
      <text class="lb" x="168" y="170" text-anchor="middle">it sags visibly, and the cracks</text>
      <text class="lb" x="168" y="190" text-anchor="middle">open wide, for a long time first</text>
      <text class="em" x="168" y="220" text-anchor="middle">STEEL YIELDS FIRST</text>
      <text class="lb" x="168" y="248" text-anchor="middle">plenty of warning — you can</text>
      <text class="lb" x="168" y="268" text-anchor="middle">walk out of the building</text>
      <text class="em" x="168" y="292" text-anchor="middle">the only kind IS 456 permits</text>

      <line class="gl" x1="348" y1="44" x2="348" y2="296"/>

      <text class="em" x="524" y="56" text-anchor="middle">OVER-REINFORCED  (xu &gt; xu,max)</text>
      <line class="thin dash" x1="404" y1="92" x2="648" y2="92"/>
      <path class="hi an-sag" style="--amp:5;--dur:4s" d="M404 92 C486 92 566 92 648 92"/>
      ${grd(394, 98, 22)} ${grd(638, 98, 22)}
      <path class="soft-b an-blink" style="--dur:4s" d="M496 78 L556 78 L556 92 L496 92 Z"/>
      <text class="em" x="526" y="72" text-anchor="middle">crush</text>
      <text class="lb" x="524" y="170" text-anchor="middle">hairline cracks, hardly any sag —</text>
      <text class="lb" x="524" y="190" text-anchor="middle">and then it simply goes</text>
      <text class="em" x="524" y="220" text-anchor="middle">CONCRETE CRUSHES FIRST</text>
      <text class="lb" x="524" y="248" text-anchor="middle">no warning at all — the steel</text>
      <text class="lb" x="524" y="268" text-anchor="middle">never even reaches yield</text>
      <text class="em" x="524" y="292" text-anchor="middle">which is why the code forbids it</text>
    </svg>`,
    caption: "Watch the sag. The left-hand beam is still moving long after the right-hand one has finished — and that movement is the warning. <strong>Capping xu at xu,max is how IS 456 buys it</strong>, and it is why an over-reinforced beam being <em>stronger</em> is beside the point.",
  },

});
