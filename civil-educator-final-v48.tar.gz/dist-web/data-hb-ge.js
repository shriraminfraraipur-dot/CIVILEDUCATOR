/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   ------------------------------------------------------------
   The fifth handbook, and the one with the most awkward
   material. Concrete and steel are made to a specification and
   tested; soil is whatever is already there, it varies over a
   few metres, and the same soil behaves as two different
   materials depending only on how fast you load it.

   One idea holds the subject together and it is introduced in
   Chapter 5: only the EFFECTIVE stress — the part carried at
   the grain contacts — controls strength and compression.
   Almost every failure in this handbook is effective stress
   changing while the total stress stays exactly where it was.

   Standards are named where they govern (IS 1498 for
   classification, the IS 2720 series for testing, IS 6403 for
   bearing capacity, IS 2911 for piles). Confirm any value
   against the published standard before using it on real work.

   Chapters 1–2 follow here; later chapters are pushed by
   data-hb-ge2.js onwards.
   ============================================================ */

window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "ge",
  subject: "geotech",
  name: "Geotechnical Engineering",
  hi: "भू-तकनीकी इंजीनियरिंग",
  icon: "🪨",
  blurb: "Mitti ko samajhne ka poora course — phase relationships se lekar bearing capacity aur piles tak, har derivation ke saath aur har example ka hisaab likha hua.",
  note: "Every worked value here is computed from first principles and shown in full so you can check it. Where a standard governs — IS 1498, IS 2720, IS 6403, IS 2911 — it is named; confirm against the published document before using a value in design.",
  chapters: [

    /* ============================================================ CH 1 */
    {
      id: "ge-1",
      n: 1,
      title: "Soil as an Engineering Material",
      hi: "इंजीनियरिंग सामग्री के रूप में मिट्टी",
      blurb: "Three phases in a box, and the half-dozen relationships that come out of drawing it properly.",
      mins: 34,
      sections: [

        {
          n: "1.1",
          title: "The material nobody specified",
          hi: "वह सामग्री जो किसी ने तय नहीं की",
          blocks: [
            { k: "p", t: "Every other handbook in this app deals with a material that was <em>made</em>. Concrete is mixed to a grade and cube-tested; steel is rolled to IS 2062 and comes with a mill certificate. Soil is none of that. It is whatever the last few million years left on the site, and the engineer's job begins by finding out what that is." },
            { k: "list", items: [
              "<strong>It varies</strong> — across a site, and with depth, sometimes dramatically over a few metres.",
              "<strong>It cannot be rejected</strong> — if the soil is poor you must design around it, improve it, or go through it to something better.",
              "<strong>It is three materials at once</strong> — solid grains, water and air — and its behaviour depends on the proportions.",
              "<strong>It behaves differently depending on how fast you load it</strong>, because water takes time to escape. The same clay is one material in an hour and a different one in ten years.",
              "<strong>Its properties are measured on samples</strong> that are, by definition, no longer in the ground and no longer under the stress they came from.",
            ]},
            { k: "p", t: "That last point deserves more respect than it usually gets. A triaxial result is not the strength of the ground; it is the strength of a 38 mm cylinder that was drilled, tubed, transported, extruded and trimmed. Good practice is a running argument about how much of the original soil survived that journey." },
            { k: "real", t: "You can see the variability on any site where trial pits are open. Two pits 20 m apart in the same field will often show different strata at different depths — and the foundation design has to cover both, because the building does not get to sit only over the good pit." },
          ],
        },

        {
          n: "1.2",
          title: "Origin, and why it matters",
          hi: "उत्पत्ति और उसका महत्व",
          blocks: [
            { k: "p", t: "Soil is rock that has been broken down and, usually, moved. How it was broken and how far it travelled decides almost everything about its engineering behaviour, which is why a geotechnical report starts with geology rather than with numbers." },
            { k: "list", items: [
              "<strong>Residual soil</strong> — weathered in place, still sitting on its parent rock. Grades downward into rock, with no sharp boundary. Common in the Deccan and in much of peninsular India.",
              "<strong>Alluvial</strong> — deposited by rivers. Layered, often with sudden changes between sand and clay, and the layering is the engineering problem. The Indo-Gangetic plain is alluvium hundreds of metres deep.",
              "<strong>Marine</strong> — deposited in the sea. Very soft, very compressible, often with high organic content. The reason coastal construction is difficult.",
              "<strong>Aeolian</strong> — carried by wind. Uniformly graded and loose; loess and desert sand.",
              "<strong>Glacial, lacustrine, colluvial</strong> — ice, lakes and gravity, each leaving a characteristic deposit.",
              "<strong>Black cotton soil</strong> — the expansive clay of central and western India. Swells when wet and shrinks when dry, cracking buildings founded on it. The volume change, not the strength, is the problem.",
            ]},
            { k: "note", t: "Transport sorts particles: a river drops gravel first and silt last, so an alluvial deposit is layered and each layer is reasonably uniform. A residual soil has never been sorted at all, so it contains everything from clay to boulders together. <strong>That is why grading curves look so different for the two</strong>, and why the sampling strategy has to differ too." },
          ],
        },

        {
          n: "1.3",
          title: "The three-phase diagram",
          hi: "त्रि-कला आरेख",
          blocks: [
            { k: "p", t: "Soil is grains, water and air. Almost every basic relationship in this chapter comes from drawing those three as separate blocks and labelling volumes on one side and weights on the other." },
            { k: "dia", id: "hb-ge-phase", cap: "Volumes on the left, weights on the right — and air has volume but no weight, which is what makes the diagram work." },
            { k: "eq", expr: "void ratio      e = Vv / Vs            porosity      n = Vv / V", where: [
              ["Vv", "volume of voids — air plus water"],
              ["Vs", "volume of solids"],
              ["V", "total volume"],
            ]},
            { k: "eq", expr: "e = n/(1 − n)          n = e/(1 + e)", where: [] },
            { k: "p", t: "Both describe the same thing. Void ratio is preferred in soil mechanics because its denominator, Vs, <strong>does not change when the soil compresses</strong> — only the voids do. Porosity's denominator is the total volume, which changes, so a change in porosity is harder to interpret." },
            { k: "eq", expr: "water content     w = Ww / Ws          degree of saturation     S = Vw / Vv", where: [] },
            { k: "trap", t: "Water content is the weight of water divided by the weight of <strong>solids</strong>, not by the total weight. It can therefore exceed 100% — and for a soft marine clay it routinely does, sometimes reaching 150% or more. A value above 100 is not a mistake in the arithmetic." },
            { k: "eq", expr: "S e  =  w G", where: [
              ["G", "specific gravity of the solids, typically 2.65–2.70 for common soils"],
            ]},
            { k: "p", t: "That identity is the hinge of the whole chapter. It links the two things you measure in a laboratory — w and G — with the two you want, e and S. Derive it once from the diagram and you never need to memorise it: Ww = w Ws = w G Vs γw, and Vw = S Vv = S e Vs, so w G Vs γw = S e Vs γw." },
          ],
        },

        {
          n: "1.4",
          title: "The unit weights",
          hi: "इकाई भार",
          blocks: [
            { k: "p", t: "Four unit weights are in use, they are constantly confused, and all four come from the same diagram." },
            { k: "eq", expr: "bulk (moist)    γ = G γw (1 + w) / (1 + e)", where: [] },
            { k: "eq", expr: "dry             γd = G γw / (1 + e)  =  γ / (1 + w)", where: [] },
            { k: "eq", expr: "saturated       γsat = (G + e) γw / (1 + e)", where: [] },
            { k: "eq", expr: "submerged       γ′ = (G − 1) γw / (1 + e)  =  γsat − γw", where: [] },
            { k: "p", t: "The submerged unit weight is the one that does real work later. A soil below the water table is buoyed by the water it displaces, so the effective stress it generates is computed with γ′ and not γsat — and γ′ is typically only about half of γsat. Chapter 5 uses this constantly." },
            { k: "def", term: "Relative density", t: "ID = (emax − e)/(emax − emin), expressed as a percentage. It says where a <em>sand</em> sits between its loosest and densest possible states, which matters far more than its absolute void ratio. Below 35% is loose, 35–65% medium, above 65% dense. It has no meaning for clays." },
            { k: "eg",
              title: "Example 1.1 — From two measurements to everything else",
              given: "A soil sample has G = 2.67, water content w = 18%, and void ratio e = 0.72. Take γw = 9.81 kN/m³.",
              steps: [
                { t: "Degree of saturation, from Se = wG", w: "S = wG/e = 0.18 × 2.67/0.72 = 0.4806/0.72 = 0.668\n= 66.8% — the soil is partly saturated" },
                { t: "Dry unit weight", w: "γd = G γw/(1 + e) = 2.67 × 9.81/1.72\n   = 26.193/1.72 = 15.228 kN/m³" },
                { t: "Bulk unit weight", w: "γ = G γw(1 + w)/(1 + e) = 2.67 × 9.81 × 1.18/1.72\n  = 30.908/1.72 = 17.969 kN/m³" },
                { t: "Check that against the other route", w: "γd = γ/(1 + w) = 17.969/1.18 = 15.228  ✓ same" },
                { t: "Saturated unit weight — if the voids were filled", w: "γsat = (G + e)γw/(1 + e) = (2.67 + 0.72) × 9.81/1.72\n     = 33.253/1.72 = 19.335 kN/m³" },
                { t: "Submerged unit weight", w: "γ′ = (G − 1)γw/(1 + e) = 1.67 × 9.81/1.72 = 9.525 kN/m³\nCheck: γsat − γw = 19.335 − 9.81 = 9.525  ✓" },
                { t: "Porosity", w: "n = e/(1 + e) = 0.72/1.72 = 0.4186 = 41.9%" },
              ],
              ans: "S = 66.8%, γd = 15.23, γ = 17.97, γsat = 19.34, γ′ = 9.53 kN/m³, n = 41.9%. Note how much smaller γ′ is than γsat — barely half — which is the whole reason a rising water table is so damaging.",
            },
            { k: "eg",
              title: "Example 1.2 — A core-cutter field density test",
              given: "A core cutter of internal volume 1000 cm³ is driven into a compacted fill. The soil in it weighs 1950 g; its water content is 14.0%; G = 2.68.",
              steps: [
                { t: "Bulk density", w: "ρ = 1950/1000 = 1.950 g/cm³  →  γ = 1.950 × 9.81 = 19.13 kN/m³" },
                { t: "Dry density", w: "ρd = ρ/(1 + w) = 1.950/1.14 = 1.711 g/cm³  →  γd = 16.78 kN/m³" },
                { t: "Void ratio", w: "e = G ρw/ρd − 1 = 2.68/1.711 − 1 = 0.567" },
                { t: "Degree of saturation", w: "S = wG/e = 0.14 × 2.68/0.567 = 0.662 = 66.2%" },
              ],
              ans: "ρd = 1.71 g/cm³, e = 0.57, S = 66%. The dry density is the number compared with the Proctor maximum in Chapter 7; the rest follows from the same three-phase identities." },
            { k: "trap", t: "Do the two checks in that example every single time. γ/(1 + w) must equal γd, and γsat − γw must equal γ′. They cost ten seconds and they catch the arithmetic slip that otherwise propagates through an entire settlement or bearing capacity calculation." },
          ],
        },

        {
          n: "1.5",
          title: "What this handbook does next",
          hi: "आगे क्या",
          blocks: [
            { k: "list", items: [
              "<strong>Ch 2</strong> — index properties: the simple tests that classify a soil and predict how it will behave.",
              "<strong>Ch 3–4</strong> — water moving through soil: permeability, then seepage and the flow net.",
              "<strong>Ch 5</strong> — effective stress. The most important chapter in the handbook.",
              "<strong>Ch 6</strong> — how a load at the surface spreads into the ground.",
              "<strong>Ch 7</strong> — compaction: making a fill behave.",
              "<strong>Ch 8</strong> — consolidation: why clay settles for years.",
              "<strong>Ch 9</strong> — shear strength, and why one soil gives several answers.",
              "<strong>Ch 10</strong> — earth pressure and retaining walls.",
              "<strong>Ch 11</strong> — bearing capacity of shallow foundations.",
              "<strong>Ch 12</strong> — piles, deep foundations and site investigation.",
            ]},
            { k: "p", t: "Chapter 5 is placed where it is deliberately. Everything before it is description — what a soil is and how water moves through it. Everything after it is behaviour, and every bit of that behaviour depends on effective stress. Read Chapter 5 twice." },
          ],
        },
      ],
    },

    /* ============================================================ CH 2 */
    {
      id: "ge-2",
      n: 2,
      title: "Index Properties and Classification",
      hi: "सूचकांक गुण और वर्गीकरण",
      blurb: "Cheap tests that predict expensive behaviour — and the chart that turns two numbers into a name.",
      mins: 42,
      sections: [

        {
          n: "2.1",
          title: "Why classify at all",
          hi: "वर्गीकरण क्यों",
          blocks: [
            { k: "p", t: "A triaxial test takes days and costs money. A sieve analysis and a set of Atterberg limits take an afternoon and cost very little — and they tell you enough to know what kind of soil you are dealing with, what problems to expect, and which expensive tests are actually worth commissioning." },
            { k: "def", term: "Index properties", t: "Simple, quickly measured properties used to classify a soil and to indicate its likely engineering behaviour. They are indicators, not design parameters: you classify with them and design with something else." },
            { k: "p", t: "The great divide is between <strong>coarse-grained</strong> soils (gravel and sand), whose behaviour is governed by particle size and packing, and <strong>fine-grained</strong> soils (silt and clay), whose behaviour is governed by the water they hold and the electrochemistry of their mineral surfaces." },
            { k: "cmp", t: "The two families behave so differently that almost every rule in this handbook needs qualifying by which one you have.",
              cols: ["Coarse-grained (sand, gravel)", "Fine-grained (silt, clay)"],
              rows: [
                ["Classified by", "Grain size distribution", "Plasticity — Atterberg limits"],
                ["Permeability", "High — drains in seconds to hours", "Very low — years to drain"],
                ["Strength from", "Friction between grains", "Cohesion, plus friction"],
                ["Settlement", "Immediate, essentially over when construction ends", "Slow — consolidation over years"],
                ["Strength depends on", "Density and confining stress", "Water content and stress history"],
                ["Loading rate", "Irrelevant — always drained", "<strong>Decides everything</strong> — drained and undrained are different materials"],
                ["Sampling", "Disturbed sampling acceptable", "Undisturbed samples essential and difficult"],
              ] },
          ],
        },

        {
          n: "2.2",
          title: "Grain size",
          hi: "कण आकार",
          blocks: [
            { k: "p", t: "Coarse particles are separated by <strong>sieving</strong>; particles finer than 75 μm will not sieve reliably and are measured by <strong>sedimentation</strong> — a hydrometer or pipette test using Stokes' law, since a larger particle settles faster through water than a smaller one." },
            { k: "eq", expr: "Stokes' law:   v = (G − 1) γw D² / (18 η)", where: [
              ["v", "terminal settling velocity of a sphere of diameter D"],
              ["η", "dynamic viscosity of water, about 0.001 Pa·s at 20 °C"],
            ]},
            { k: "eg",
              title: "Example 2.1 — How long does silt take to settle?",
              given: "A silt particle of D = 0.01 mm, G = 2.68, in water at 20 °C (η = 0.001 Pa·s, γw = 9810 N/m³). How long to fall 100 mm?",
              steps: [
                { t: "Velocity", w: "v = 1.68 × 9810 × (0.01 × 10⁻³)²/(18 × 0.001) = 9.16 × 10⁻⁵ m/s ≈ 0.092 mm/s" },
                { t: "Time for 100 mm", w: "t = 100/0.0916 = 1092 s ≈ 18 minutes" },
              ],
              ans: "About 18 minutes — and a 0.001 mm clay particle, with a hundredth of the velocity, would take about 30 hours. That is why a hydrometer test runs for a day and why sieving stops at 75 µm." },
            { k: "dia", id: "hb-ge-grading", cap: "Well graded, poorly graded, gap graded — and the two coefficients that tell them apart." },
            { k: "eq", expr: "uniformity coefficient   Cu = D60 / D10          coefficient of curvature   Cc = D30² / (D10 × D60)", where: [
              ["D10", "the size below which 10% of the soil by weight lies — the effective size"],
            ]},
            { k: "list", items: [
              "<strong>Well graded sand</strong>: Cu > 6 <em>and</em> Cc between 1 and 3.",
              "<strong>Well graded gravel</strong>: Cu > 4 <em>and</em> Cc between 1 and 3.",
              "Fail either test and the soil is poorly graded.",
            ]},
            { k: "p", t: "A well graded soil compacts to a higher density and a higher strength, because small grains fill the voids between large ones. A uniform soil has nothing to fill its voids, which is why clean uniform sand is both very permeable and relatively loose." },
            { k: "eg",
              title: "Example 2.2 — Grading, and a soil that passes one test and fails the other",
              given: "From a sieve analysis: D10 = 0.18 mm, D30 = 0.42 mm, D60 = 1.35 mm.",
              steps: [
                { t: "Uniformity coefficient", w: "Cu = D60/D10 = 1.35/0.18 = 7.50\n7.50 > 6  ✓ passes the first criterion for a sand" },
                { t: "Coefficient of curvature", w: "Cc = D30²/(D10 × D60) = 0.42²/(0.18 × 1.35)\n   = 0.1764/0.243 = 0.726" },
                { t: "Verdict", w: "Cc = 0.726 is NOT between 1 and 3  ✗\nBoth criteria must be met, so the soil is POORLY graded — SP" },
              ],
              ans: "Cu = 7.5, Cc = 0.73 — poorly graded sand (SP). A Cc below 1 means the curve has a flat step in it: a range of intermediate sizes is missing, which is the signature of a gap-graded soil.",
            },
            { k: "trap", t: "Cu alone is a trap and this example is exactly why. A wide range of sizes is necessary for good grading but not sufficient — if the middle of the range is missing, the fine particles are too small to fill the voids between the coarse ones and the packing is poor. <strong>Always compute both.</strong>" },
          ],
        },

        {
          n: "2.3",
          title: "Atterberg limits",
          hi: "एटरबर्ग सीमाएँ",
          blocks: [
            { k: "p", t: "For a fine-grained soil, grain size tells you very little. What matters is how the soil responds to water — and Atterberg's insight, a century old and still the basis of classification, was to measure the water contents at which its behaviour changes." },
            { k: "dia", id: "hb-ge-atterberg", cap: "Four states along one axis, and three boundaries between them." },
            { k: "list", items: [
              "<strong>Liquid limit (LL)</strong> — the water content at which the soil starts to flow. Measured in a Casagrande cup (25 blows to close a standard groove) or by cone penetrometer, per IS 2720 Part 5.",
              "<strong>Plastic limit (PL)</strong> — the water content at which a 3 mm thread just begins to crumble when rolled. Crude-sounding and remarkably repeatable.",
              "<strong>Shrinkage limit (SL)</strong> — the water content below which further drying causes no further reduction in volume.",
            ]},
            { k: "eq", expr: "plasticity index   PI = LL − PL", where: [] },
            { k: "eg",
              title: "Example 2.3 — Liquid limit from the flow curve",
              given: "Casagrande cup results: 34 blows at w = 42.0%, 18 blows at w = 47.6%. Water content plotted against log(blows) is a straight line (the flow curve).",
              steps: [
                { t: "Flow index", w: "If = (47.6 − 42.0)/log₁₀(34/18) = 5.6/0.2762 = 20.3" },
                { t: "Water content at 25 blows", w: "LL = 42.0 + 20.3 × log₁₀(34/25) = 42.0 + 20.3 × 0.1335 = 44.7%" },
              ],
              ans: "LL ≈ 44.7%. In practice at least four points spanning about 15–35 blows are used and the line is fitted, but the logic is exactly this interpolation on a log scale." },
            { k: "p", t: "PI is the <em>width</em> of the range over which the soil is plastic, and it is essentially a measurement of how much clay mineral is present. A pure sand has no plastic range at all; a montmorillonite clay has an enormous one." },
            { k: "eq", expr: "consistency index   Ic = (LL − w)/PI          liquidity index   IL = (w − PL)/PI", where: [
              ["w", "the soil's natural water content in the ground"],
            ]},
            { k: "p", t: "Those two put the soil's <em>actual</em> state onto the scale. IL near 0 means the soil sits at its plastic limit and is stiff; IL near 1 means it is at its liquid limit and is very soft; IL above 1 means it is wetter than its liquid limit, which happens in sensitive clays and is a warning." },
            { k: "note", t: "Two further indices are worth knowing. <strong>Activity</strong> = PI / (% clay finer than 2 μm) identifies the clay mineral: below 0.75 inactive (kaolinite), 0.75–1.25 normal (illite), above 1.25 active (montmorillonite, and the black cotton soils). <strong>Sensitivity</strong> = undisturbed strength / remoulded strength, which says how much a clay loses when it is worked." },
          ],
        },

        {
          n: "2.4",
          title: "IS classification",
          hi: "IS वर्गीकरण",
          blocks: [
            { k: "p", t: "IS 1498 classifies soils by grain size for coarse soils and by plasticity for fine ones, giving a two-letter symbol. The first letter is the soil type, the second its qualifier." },
            { k: "list", items: [
              "<strong>Coarse-grained</strong> (more than 50% retained on 75 μm): G for gravel, S for sand; then W well graded, P poorly graded, M silty, C clayey. GW, GP, GM, GC, SW, SP, SM, SC.",
              "<strong>Fine-grained</strong> (more than 50% passing 75 μm): M for silt, C for clay, O for organic; then L, I or H for low, intermediate or high compressibility. ML, CL, OL, MI, CI, OI, MH, CH, OH.",
              "<strong>Pt</strong> — peat and highly organic soils, in a class of their own.",
            ]},
            { k: "dia", id: "hb-ge-plasticity", cap: "Liquid limit across, plasticity index up, and the A-line dividing clays from silts." },
            { k: "eq", expr: "A-line:   PI = 0.73 (LL − 20)", where: [] },
            { k: "note", t: "The A-line and the grading criteria (gravel Cu ≥ 4, sand Cu ≥ 6, 1 ≤ Cc ≤ 3) match <a href=\"https://engineeringhulk.com/?p=5571\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>; some texts write the Cu limits as strict inequalities — the difference only matters for a soil exactly on the boundary." },
            { k: "trap", t: "IS 1498 divides compressibility at LL = 35 and LL = 50, giving <strong>three</strong> bands — low, intermediate and high. The international USCS chart has only one division, at LL = 50, and therefore no 'I' symbols at all. A soil that is CI to IS 1498 is CH to USCS, and mixing the two systems in one report is a real and common error." },
            { k: "eg",
              title: "Example 2.4 — Classifying a fine-grained soil",
              given: "A soil with 78% passing the 75 μm sieve. Liquid limit 48%, plastic limit 22%, natural water content 31%.",
              steps: [
                { t: "Coarse or fine?", w: "78% passes 75 μm, which is more than 50%\n→ FINE-GRAINED, so classify by plasticity" },
                { t: "Plasticity index", w: "PI = LL − PL = 48 − 22 = 26" },
                { t: "Which side of the A-line?", w: "A-line PI at LL = 48:  0.73 × (48 − 20) = 0.73 × 28 = 20.4\nActual PI = 26  >  20.4\n→ ABOVE the A-line, so it is a CLAY (C)" },
                { t: "Compressibility band (IS 1498)", w: "LL = 48, which lies between 35 and 50\n→ INTERMEDIATE compressibility (I)" },
                { t: "Classification", w: "CI — clay of intermediate compressibility" },
                { t: "And its state in the ground", w: "Ic = (LL − w)/PI = (48 − 31)/26 = 0.654\nIL = (w − PL)/PI = (31 − 22)/26 = 0.346\n(the two must sum to 1.0 — 0.654 + 0.346 = 1.000  ✓)" },
              ],
              ans: "CI, a clay of intermediate compressibility, sitting at a liquidity index of 0.35 — nearer its plastic limit than its liquid limit, so it is in a firm to stiff state rather than a soft one.",
            },
            { k: "note", t: "That final check, Ic + IL = 1, follows straight from the definitions and catches an arithmetic slip instantly. It is the same kind of free check as γsat − γw = γ′ in Chapter 1." },
          ],
        },

        {
          n: "2.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Coarse soils are classified by size, fine soils by plasticity, and they behave as different subjects.",
              "Cu = D60/D10 and Cc = D30²/(D10 D60) — BOTH must pass.",
              "PI = LL − PL, and it measures how much clay mineral is present.",
              "IL places the soil's actual water content on the plastic range; IL near 1 is soft, above 1 is a warning.",
              "A-line PI = 0.73(LL − 20): above it clay, below it silt.",
              "IS 1498 uses three compressibility bands at LL = 35 and 50; USCS uses one at 50.",
              "Activity identifies the clay mineral — above 1.25 means an expansive soil.",
            ]},
            { k: "p", t: "Chapter 3 turns to the phase the classification tests have been implicitly measuring all along: the water, and how fast it can move through the soil." },
          ],
        },
      ],
    },

  ],
});
