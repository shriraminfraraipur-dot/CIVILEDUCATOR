/* Surveying class notes — Contouring, notes p.174–178 — inserted into sv chapter 7 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 7; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- p.174–175 */
    {
      n: "",
      title: "Class notes — Contour: definition and uses",
      hi: "कंटूर — परिभाषा और उपयोग",
      blocks: [
        { k: "h", t: "📘 Notes — p.174–175" },
        { k: "def", term: "Contour", t: "Contour may be defined as the <b>imaginary line</b> passing through the points of <b>equal elevation</b> on the earth surface. (p.174)" },
        { k: "def", term: "Submarine contours / Fathoms / Bathymetric curves", t: "When the contours are drawn <b>under water</b>, these are called <b>submarine contours / Fathoms / Bathymetric curves</b>. (p.174)" },
        { k: "h", t: "Uses of contour (p.174–175)" },
        { k: "def", term: "1) Determination of intervisibility", t: "With the help of contour we can determine whether two points are intervisible or not. (p.174)" },
        { k: "def", term: "2) Drainage area", t: "Extent of drainage can be estimated with the help of a contour map by locating the <b>ridge line</b> around the <b>water shed</b>. (p.174)" },
        { k: "def", term: "3) Capacity of reservoir", t: "Volume of water can be found out by drawing close contour lines in the reservoir, and with the help of the <b>prismoidal</b> or <b>end area formula</b> the volume/area can be calculated. (p.174)" },
        { k: "def", term: "4) Earthwork estimate", t: "By drawing contour lines of the <b>original ground</b> on the contour of the <b>desired surface</b>, the quantity of <b>excavation &amp; filling</b> can be found out. (p.174)" },
        { k: "def", term: "5) Route location", t: "By inspection of a contour map, the most suitable site for <b>road, railways, canal, sewer system</b> can be located. (p.175)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Contour ek <b>imaginary</b> line hai — ground par aisi koi line bani nahi hoti. Socho pahaad ko paani mein dheere-dheere dubo rahe ho: har level par paani ki kinari jahan ground ko chhooti hai, wahi ek contour hai. Isliye ek contour ke har point ki height same hoti hai. Paani ke andar (samudra / reservoir ki tali) yahi lines banao to unhe <b>bathymetric curves</b> ya <b>fathoms</b> kehte hain." },
        { k: "p", t: "Paanchon uses ek hi baat se nikalte hain: contour map ground ki <b>teen-dimensional</b> shakal ko kaagaz par rakh deta hai. Do points ke beech ki ground profile dekh kar intervisibility, ridge line se catchment ki seema, contour areas se reservoir ka volume, original aur desired surface ki tulna se cut–fill, aur slope dekh kar road/canal ka route — sab map par hi ho jata hai. Ye uses section 7.4 mein detail se bhi aaye hain." },
        { k: "trap", t: "Drainage area ki boundary <b>ridge line (water shed)</b> se banti hai, valley line se nahi. Ridge ke ek taraf gira paani ek catchment mein jaata hai, doosri taraf gira paani doosre mein — isliye catchment ki seema hamesha ridge par hoti hai." },
        { k: "real", t: "Dam project mein reservoir ki har contour ke andar ka area plan se naapa jata hai, aur un areas ko contour interval ki doori par rakh kar prismoidal / end-area formula se storage nikaala jata hai (p.174)." },
      ],
    },

    /* ---------------------------------------------------------- p.175–176 */
    {
      n: "",
      title: "Class notes — Contour interval and the factors it depends on",
      hi: "कंटूर अंतराल और उसे प्रभावित करने वाले कारक",
      blocks: [
        { k: "h", t: "📘 Notes — p.175–176" },
        { k: "def", term: "Contour interval", t: "The <b>vertical distance</b> between two <b>consecutive contours</b> is called contour interval. (p.175)" },
        { k: "p", t: "Figure (p.175): two concentric closed contours — the inner one labelled <b>100</b>, the outer one labelled <b>110</b>. Written beside it: <b>contour interval = 10 m</b>. (p.175)" },
        { k: "eg",
          title: "Notes example — contour interval from the sketch",
          given: "Two consecutive closed contours are labelled 100 (inner) and 110 (outer). Find the contour interval.",
          steps: [
            { t: "Contour interval = vertical distance between consecutive contours", w: "110 − 100 = 10 m" },
          ],
          ans: "Contour interval = 10 m (p.175)",
        },
        { k: "h", t: "Contour interval depends on the following factors (p.175)" },
        { k: "list", items: [
          "1) Scale of map",
          "2) Purpose of map",
          "3) Nature of the ground",
          "4) Time",
          "5) Fund",
        ] },
        { k: "cmp", t: "Effect of each factor on the contour interval (p.175–176)", cols: ["Rule in the notes"], rows: [
          ["1) Scale of map", "If scale is <b>small</b>, contour interval is <b>large</b>, so that there is no overcrowding of contours. Eg — 1/500 or 1/50000 (p.175)"],
          ["2) Purpose of map", "Contour interval should be kept <b>small</b> when the plan is required for <b>detail design</b>. (p.175)"],
          ["3) Nature of ground", "For <b>flat</b> ground contour interval is <b>large</b>, whereas for <b>steep</b> ground contour interval is <b>small</b>. (p.176)"],
          ["4) Time", "Contour interval is <b>large</b> when time is <b>less</b>. (p.176)"],
          ["5) Fund", "Contour interval is <b>large</b> when fund is <b>less</b>. (p.176)"],
        ] },
        { k: "p", t: "Figure (p.175): under the scale example, below <b>1/500</b> two short curved lines are drawn close together, and below <b>1/50000</b> two short curved lines are drawn wider apart — a sketch of contour lines as they appear at the two scales. (p.175)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "1/500 ek <b>large scale</b> hai (1 cm = 5 m) aur 1/50000 ek <b>small scale</b> (1 cm = 500 m). Small scale map par bahut bada area chhote kaagaz mein aata hai; agar interval bhi chhota rakha to lines aapas mein chipak jaayengi aur map padha nahi jayega — isliye small scale → large interval. Detail design ke liye chhota interval chahiye kyunki wahan chhote-chhote level differences bhi kaam ke hote hain." },
        { k: "p", t: "Time aur fund wale rules practical hain: chhota interval matlab zyada levels lene padenge, zyada field kaam, zyada kharcha. Kam samay ya kam paisa ho to interval bada rakhna padta hai. Typical interval values ki table section 7.1 mein di hai." },
        { k: "trap", t: "Nature of ground wala rule ulta yaad ho jaata hai. Notes ke hisaab se <b>flat ground → large interval</b>, <b>steep ground → small interval</b>. 'Steep ground par lines waise hi paas aati hain' sochkar students yahan interval bada likh dete hain — exam mein notes wala rule hi likho." },
      ],
    },

    /* ---------------------------------------------------------- p.176–177 */
    {
      n: "",
      title: "Class notes — Characteristics of contours 1–3: vertical and overhanging cliffs",
      hi: "कंटूर की विशेषताएँ 1–3: ऊर्ध्वाधर और लटकती चट्टान",
      blocks: [
        { k: "h", t: "📘 Notes — p.176–177" },
        { k: "p", t: "<b>Characteristics of contour lines</b> — heading marked in the margin as an important (\"4M\") question. (p.176)" },
        { k: "list", items: [
          "<b>1)</b> All the points of a contour line have the <b>same elevation</b>. (p.176)",
          "<b>2)</b> <b>Zero metre</b> value of contour line represents <b>Datum</b> or <b>coastal line</b>. (p.176)",
          "<b>3)</b> Two contour lines do <b>not intersect</b> each other. There are two exceptions, where contour lines <b>intersect each other</b>:<br>— <b>overhanging cliff</b><br>— <b>cave penetration hill</b> (पहाड़ के अंदर गुफा — a cave inside the hill)<br>In case of a <b>vertical cliff</b>, contour lines <b>meet, but do not intersect</b>. (p.176)",
        ] },
        { k: "def", term: "Contour equivalent", t: "<b>Horizontal distance</b> between two contour lines. (p.176)" },
        { k: "h", t: "Figures (p.177)" },
        { k: "p", t: "Figure (p.177) — <b>Vertical cliff or vertical wall</b>: an elevation (section) at the top shows the ground rising from the left, crossing horizontal level lines <b>60, 70, 80, 90</b> and reaching the top at <b>100</b>; the right-hand face is a <b>vertical line</b> from the base up to 100. Vertical projection lines are dropped from the points where the profile cuts each level line. The plan below shows nested closed contours that grow smaller towards the right and all <b>meet at one common place on the right side</b> (under the vertical face) — they touch but do not cross. (p.177)" },
        { k: "p", t: "Figure (p.177) — <b>Overhanging cliff</b>: an elevation at the top shows a hook-shaped profile — the ground rises on the left to the top at <b>103</b>, then the top runs over to the right and the face hangs back down, forming an overhanging lip; horizontal level lines are labelled on the right <b>103, 102, 101, 100</b>. Vertical projection lines drop to the plan. The plan below shows closed contours <b>100, 101, 102</b> (small, on the left) and <b>103</b> (a large elongated oval extending to the right) which <b>cross / intersect</b> each other. (p.177)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Do contour aapas mein kaatenge to kaatne wale point ki do alag heights hongi — ek hi jagah par ground do level par kaise ho sakti hai? Normally nahi ho sakti, isliye contours intersect nahi karte. Lekin <b>overhanging cliff</b> mein upar latakti chattan aur neeche ki zameen plan mein ek hi jagah aati hain — upar wala hissa neeche wale ke <i>upar</i> hai. Isliye plan par upar wale contours neeche walon ko kaat dete hain. Pahaad ke andar gufa (cave) mein bhi yahi hota hai: gufa ki chhat aur farsh ek hi plan position par alag heights par hain." },
        { k: "p", t: "<b>Vertical cliff</b> mein face bilkul seedha khada hai, to 60, 70, 80, 90, 100 — sab levels plan mein ek hi line par aa jaate hain. Contours wahan <b>mil jaate hain (meet)</b> par ek doosre ke paar nahi jaate. Contour interval vertical doori hai; <b>contour equivalent</b> (horizontal equivalent) horizontal doori — dono ka ratio hi slope batata hai." },
        { k: "trap", t: "'Meet' aur 'intersect' alag hain. Vertical cliff → contours <b>meet</b> (touch) but do not intersect. Overhanging cliff aur cave penetration hill → contours <b>intersect</b>. MCQ mein vertical cliff ko intersection ka exception likhna galat hai." },
        { k: "real", t: "Contour map par contours ek hi jagah par ikatthe dikhen to site par wahan khada face (cliff, retaining wall, quarry face) hai; crossing contours dikhen to overhang ya gufa — wahan neeche khudai ya building karna khatarnak ho sakta hai." },
      ],
    },

    /* ---------------------------------------------------------- p.177–178 */
    {
      n: "",
      title: "Class notes — Characteristics 4–8: hillock, pond, slopes, ridge and valley",
      hi: "विशेषताएँ 4–8: टीला, तालाब, ढाल, रिज और घाटी",
      blocks: [
        { k: "h", t: "📘 Notes — p.177–178" },
        { k: "list", items: [
          "<b>4)</b> In a contour map, <b>higher figure inside</b> will represent a <b>hillock</b>, and <b>higher figure outside</b> will represent a <b>depression / dispersion</b> (eg — lake, pond). (p.177)",
        ] },
        { k: "p", t: "Figure (p.177) — <b>Hillock</b>: elevation of a dome-shaped hill with level lines <b>100</b> (bottom), <b>110</b>, <b>120</b> (top); vertical projection lines dropped to the plan. Plan: nested closed contours — outer <b>100</b>, middle <b>110</b>, inner <b>120</b>. (p.177)" },
        { k: "p", t: "Figure (p.177) — <b>Pond</b>: elevation of a bowl-shaped depression with level lines <b>80</b> (top), <b>70</b>, <b>60</b> (bottom); vertical projection lines dropped to the plan. Plan: nested closed contours — inner <b>60</b>, middle <b>70</b>, outer <b>80</b>. (p.177)" },
        { k: "list", items: [
          "<b>5)</b> <b>Equally spaced</b> contours represent <b>uniform slope</b>, and the contours that are <b>well apart</b> represent <b>gentle slope</b>. (p.178)",
          "<b>6)</b> <b>Irregular</b> contour represents <b>uneven ground surface</b>. (p.178)",
          "<b>7)</b> A <b>ridge line / water shed</b> (line joining the highest points of a series of hills) and <b>valley line</b> (line joining the lowest points of a valley) cross the contour lines at <b>right angle</b>. (p.178)",
          "<b>8)</b> If the contours are at <b>closer interval</b>, it will represent <b>steep slope</b>. (p.178)",
        ] },
        { k: "p", t: "Figure (p.178) — <b>Ridge line</b> (drawn in red): an inclined ridge line with contours crossing it in inverted-V (Λ) shapes, the apex of each on the ridge line; contours labelled <b>100</b> (lowest on the sketch), <b>110</b>, <b>120</b> (highest); a <b>90°</b> angle is marked between the ridge line and contour 120. (p.178)" },
        { k: "p", t: "Figure (p.178) — <b>Valley line</b> (drawn in red): an inclined valley line with contours crossing it in V shapes, the apex of each on the valley line; contours labelled <b>90</b> (lowest on the sketch), <b>100</b>, <b>110</b> (highest); a <b>90°</b> angle is marked between the valley line and contour 110. (p.178)" },
        { k: "note", t: "<b>General Engineering Knowledge — reading the ridge/valley sketches:</b> the sketches on p.178 show the Λ shape for the ridge and the V shape for the valley, which is how the two look in <i>cross-section</i>. In <i>plan</i> (on a contour map) the standard rule is the reverse-looking one given in section 7.2: for a <b>valley</b> the V of the contours points <b>uphill</b> (towards the higher values), and for a <b>ridge</b> the contours bend <b>downhill</b> (towards the lower values). The notes' labels place the Λ apexes towards the higher contour on the ridge sketch and the V apexes towards the lower contour on the valley sketch, so read them as shape sketches, not as plan conventions. The right-angle crossing (rule 7) holds in both cases." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Hillock aur pond ka plan <b>bilkul ek jaisa</b> dikhta hai — dono mein closed rings ek ke andar ek. Fark sirf numbers ka hai: andar ki taraf value badhe (100 → 110 → 120) to tila / hillock; andar ki taraf value ghate (80 → 70 → 60) to gaddha / pond / lake. Isliye contour map par figures likhna zaroori hai." },
        { k: "p", t: "Slope ka rule ek line mein: <b>paas-paas contours = steep</b>, <b>door-door = gentle</b>, <b>barabar doori = uniform</b>. Ridge aur valley line hamesha contours ko <b>90°</b> par kaatti hain, kyunki ye lines steepest slope ki disha mein chalti hain aur contour us disha ke perpendicular hota hai — paani bhi contours ko right angle par hi kaat kar behta hai." },
        { k: "trap", t: "Do galtiyan common hain: (1) closed rings dekh kar bina numbers padhe 'hill' likh dena — pond bhi waisa hi dikhta hai; (2) ridge/valley ki plan pehchaan ko cross-section shape se mila dena. Plan mein valley ka V <b>uphill</b> point karta hai — notes ke Λ/V sketch section ki shakal dikhate hain." },
        { k: "real", t: "Canal ya road alignment mein valley line (jahan nala behta hai) par culvert / cross-drainage work aata hai, aur ridge line par canal chalane se dono taraf gravity se paani diya ja sakta hai — dono lines contour map par contours ke 90° crossing se pehchaani jaati hain." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — Contouring (p.174–178)",
      hi: "नोट्स पुनरावृत्ति — कंटूरिंग",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "✅ Contour = imaginary line through points of equal elevation on the earth surface. (p.174)",
          "✅ Contours under water = submarine contours / Fathoms / Bathymetric curves. (p.174)",
          "✅ Uses: intervisibility, drainage area (ridge line around water shed), reservoir capacity (prismoidal / end area formula), earthwork (cut &amp; fill), route location (road, railway, canal, sewer). (p.174–175)",
          "✅ Contour interval = vertical distance between two consecutive contours; e.g. 110 − 100 = 10 m. (p.175)",
          "✅ Contour interval depends on: scale, purpose, nature of ground, time, fund. (p.175)",
          "✅ Small scale → large interval (no overcrowding); detail design → small interval. (p.175)",
          "✅ Flat ground → large interval; steep ground → small interval; less time or less fund → large interval. (p.176)",
          "✅ Contour equivalent = horizontal distance between two contour lines. (p.176)",
          "✅ Char. 1: all points on a contour have the same elevation. (p.176)",
          "✅ Char. 2: zero metre contour = datum or coastal line. (p.176)",
          "✅ Char. 3: contours do not intersect — exceptions: overhanging cliff, cave penetration hill (they intersect); vertical cliff → contours meet but do not intersect. (p.176–177)",
          "✅ Char. 4: higher figure inside → hillock; higher figure outside → depression (lake, pond). (p.177)",
          "✅ Char. 5: equally spaced → uniform slope; well apart → gentle slope. (p.178)",
          "✅ Char. 6: irregular contours → uneven ground. (p.178)",
          "✅ Char. 7: ridge line / water shed and valley line cross contours at right angle. (p.178)",
          "✅ Char. 8: contours at closer interval → steep slope. (p.178)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
