/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: BUILDING SERVICES & SAFETY handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   Design flow follows the National Building Code (NBC) — a BIS
   publication — named as NBC.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.1 THE INVISIBLE BUILDING */
  "hb-bs-services": {
    label: "The invisible half of a building",
    svg: `<svg viewBox="-30 0 760 290" role="img" aria-label="A building shown with its services: clean water coming in and stored in tanks, wastewater leaving through drains, air moving for ventilation, power and light, and the fire-safety systems, making the point that services are the half of a building you do not see but cannot live without.">
      ${hbmk("sv3")}
      <text class="em" x="350" y="24" text-anchor="middle">A BUILDING IS HALF STRUCTURE, HALF SERVICES</text>
      <rect class="soft" x="250" y="70" width="200" height="150"/>
      ${[100,130,160,190].map(y=>`<line class="thin" x1="250" y1="${y}" x2="450" y2="${y}"/>`).join("")}
      <text class="lb" x="350" y="150" text-anchor="middle">the building</text>
      <line class="hi" x1="120" y1="110" x2="250" y2="110" marker-end="url(#sv3-c)"/>
      <text class="ea" x="120" y="102">clean water in</text>
      <line class="ac" x1="450" y1="200" x2="580" y2="200" marker-end="url(#sv3-c)"/>
      <text class="ea" x="470" y="192">wastewater out</text>
      <line class="hi" x1="120" y1="180" x2="250" y2="180" marker-end="url(#sv3-c)"/>
      <text class="ea" x="120" y="172">air, light, power</text>
      <line class="ac" x1="350" y1="70" x2="350" y2="50" marker-end="url(#sv3-c)" marker-start="url(#sv3-c)"/>
      <text class="ea" x="360" y="58">fire safety wraps it all</text>

      <text class="lb" x="350" y="248" text-anchor="middle">structure keeps a building STANDING; services keep it LIVABLE and SAFE</text>
      <text class="lb" x="350" y="270" text-anchor="middle">this handbook is the services a civil engineer designs into a building — mostly to the National Building Code (NBC)</text>
    </svg>`,
    caption: "Half of what makes a building work is invisible: the water piped in and stored, the waste carried out, the air moved for ventilation, the power and light, and the fire-safety systems that protect all of it. The structure keeps the building standing; the services keep it livable and safe. <strong>A structurally perfect building with no water, no drainage and no fire escape is uninhabitable</strong> — which is why the National Building Code devotes as much attention to services as to structure.",
  },

  /* ------------------------------------------- 2.1 WATER SUPPLY */
  "hb-bs-water": {
    label: "Getting water to every tap — the down-feed system",
    svg: `<svg viewBox="0 0 744 300" role="img" aria-label="A building water supply: the mains fills an underground tank, a pump lifts water to an overhead tank on the roof, and gravity then feeds every tap below, so that pressure is provided by the height of the overhead tank rather than by running the pump continuously.">
      ${hbmk("wa2")}
      <text class="em" x="350" y="24" text-anchor="middle">STORE HIGH, LET GRAVITY DO THE WORK</text>
      <rect class="softa" x="120" y="60" width="150" height="40"/>
      <text class="lb" x="195" y="52" text-anchor="middle">overhead tank (roof)</text>
      <line class="ac" x1="270" y1="90" x2="420" y2="90"/>
      ${[110,150,190].map(y=>`<line class="ac" x1="360" y1="90" x2="360" y2="${y}"/>
        <circle class="hif" cx="360" cy="${y}" r="4"/><text class="lb" x="372" y="${y+4}">tap</text>`).join("")}
      <path class="ac" d="M420 90 L420 230"/>
      <text class="ea" x="430" y="160">gravity DOWN-FEED —</text>
      <text class="lb" x="430" y="178">pressure from the tank's height</text>

      <rect class="softa" x="120" y="230" width="150" height="40"/>
      <text class="lb" x="195" y="258" text-anchor="middle">underground tank</text>
      <line class="hi" x1="60" y1="250" x2="120" y2="250" marker-end="url(#wa2-c)"/>
      <text class="ea" x="60" y="242">mains</text>
      <circle class="steel" cx="195" cy="165" r="14"/>
      <text class="lb" x="195" y="169" text-anchor="middle">P</text>
      <path class="hi" d="M195 230 L195 179"/>
      <path class="hi" d="M195 151 L195 100"/>
      <text class="ea" x="210" y="130">pump lifts once,</text>
      <text class="lb" x="210" y="148">fills the tank</text>

      <line class="gl" x1="500" y1="56" x2="500" y2="286"/>
      <text class="em" x="518" y="84">why store on the roof?</text>
      <text class="lb" x="518" y="110">the mains supply is intermittent</text>
      <text class="lb" x="518" y="128">and low-pressure — you cannot</text>
      <text class="lb" x="518" y="146">rely on it at the tap directly</text>
      <text class="ea" x="518" y="176">so: fill a roof tank when water</text>
      <text class="lb" x="518" y="194">is available, then feed every tap</text>
      <text class="lb" x="518" y="212">by gravity — steady pressure,</text>
      <text class="lb" x="518" y="230">no pump running all day</text>
      <text class="lb" x="518" y="262">demand ~135 litres per person</text>
      <text class="lb" x="518" y="280">per day for housing (NBC)</text>
    </svg>`,
    caption: "Municipal water arrives intermittently and at low pressure, so you cannot simply plumb it to the taps. The universal solution is to store high: fill an underground tank from the mains whenever water is available, pump it once up to an overhead tank on the roof, and let gravity feed every tap below at a steady pressure. <strong>The height of the roof tank is what gives every tap its pressure</strong> — the pump only has to fill it, not run all day, which is why almost every Indian building has a tank on its roof.",
  },

  /* ------------------------------------------- 3.1 THE TRAP */
  "hb-bs-trap": {
    label: "The trap — a water seal against sewer gas",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A drainage trap shown as a U-bend that holds a plug of water, sealing the drain so foul sewer gases cannot rise back into the room, with a vent pipe that lets air in so the seal is not siphoned away when water rushes past.">
      ${hbmk("tp2")}
      <text class="em" x="350" y="24" text-anchor="middle">A CUPFUL OF WATER IS ALL THAT KEEPS THE SEWER OUT</text>
      <rect class="softa" x="120" y="70" width="70" height="30"/>
      <text class="lb" x="155" y="62" text-anchor="middle">basin</text>
      <path class="s" d="M140 100 L140 160 Q140 200 180 200 Q220 200 220 160 L220 130" fill="none" stroke-width="3"/>
      <path class="soft-b" d="M148 160 Q148 192 180 192 Q212 192 212 160 L212 152 Q180 172 148 152 Z"/>
      <text class="lb" x="180" y="178" text-anchor="middle">seal</text>
      <line class="ac" x1="150" y1="230" x2="150" y2="200" marker-end="url(#tp2-c)"/>
      <text class="ea" x="150" y="248" text-anchor="middle">water plug</text>
      <path class="s" d="M220 130 L260 130 L260 230" fill="none" stroke-width="3"/>
      <text class="lb" x="290" y="150">to drain →</text>
      <path class="hi" d="M280 130 L280 60" stroke-dasharray="5 4"/>
      <text class="ea" x="290" y="80">vent pipe</text>
      <path class="ac" d="M280 60 L280 46"/><text class="lb" x="300" y="50">air in</text>
      <text class="lb" x="180" y="278" text-anchor="middle">foul gas ✗ cannot pass the water</text>

      <line class="gl" x1="400" y1="56" x2="400" y2="286"/>
      <text class="em" x="418" y="84">the trap does one job:</text>
      <text class="lb" x="418" y="110">it holds a plug of water in a U-bend</text>
      <text class="lb" x="418" y="128">that seals the pipe. Foul, dangerous</text>
      <text class="lb" x="418" y="146">sewer gas cannot bubble back up</text>
      <text class="lb" x="418" y="164">through it into the room.</text>
      <text class="em" x="418" y="196">why the VENT matters:</text>
      <text class="lb" x="418" y="222">a rush of water down the pipe can</text>
      <text class="lb" x="418" y="240">siphon the seal out, breaking it.</text>
      <text class="lb" x="418" y="258">the vent lets air in behind the flow</text>
      <text class="lb" x="418" y="276">so the seal is not sucked away.</text>
    </svg>`,
    caption: "Every fixture that drains — basin, WC, floor trap — has a trap, and its entire job is to hold a small plug of water in a U-bend. That plug seals the pipe so that foul, sometimes explosive, sewer gas cannot rise back into the room. It is a tiny detail doing a vital job. <strong>The vent pipe is its silent partner</strong>: without a vent, a rush of water down the stack can siphon the water seal straight out, and a dry trap is an open sewer into the room — which is why drainage is never just pipes, but pipes and vents together.",
  },

  /* ------------------------------------------- 4.1 TREATMENT TRAIN */
  "hb-bs-treatment": {
    label: "Making water safe — the treatment train",
    svg: `<svg viewBox="-58 0 816 270" role="img" aria-label="A water treatment train shown as a sequence: screening to remove large debris, sedimentation to settle suspended solids, filtration to catch fine particles, and disinfection to kill pathogens, each step removing something the next could not.">
      ${hbmk("tt")}
      <text class="em" x="350" y="24" text-anchor="middle">EACH STEP REMOVES WHAT THE LAST ONE COULD NOT</text>
      ${[["SCREENING", 110, "leaves, rags,", "large debris"],
         ["SEDIMENTATION", 270, "suspended solids", "settle out (slow)"],
         ["FILTRATION", 430, "fine particles", "caught in sand"],
         ["DISINFECTION", 590, "pathogens killed", "(chlorine)"]]
        .map(([t, x, a, b], i) => `
        <rect class="${i===3?'soft-b':'conc'}" x="${x - 62}" y="80" width="124" height="60"/>
        <text class="em" x="${x}" y="106" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="126" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="160" text-anchor="middle">${b}</text>
        ${i<3?`<line class="ac" x1="${x+64}" y1="110" x2="${x+94}" y2="110" marker-end="url(#tt-c)"/>`:""}`).join("")}
      <line class="hi" x1="30" y1="110" x2="46" y2="110" marker-end="url(#tt-c)"/>
      <text class="lb" x="30" y="100">raw</text>
      <line class="hi" x1="654" y1="110" x2="670" y2="110" marker-end="url(#tt-c)"/>
      <text class="lb" x="662" y="100" text-anchor="end">safe</text>
      <text class="lb" x="350" y="202" text-anchor="middle">solids first (cheap, physical), pathogens last (chemical) — the order is deliberate, coarse to fine to invisible</text>
      <text class="lb" x="350" y="228" text-anchor="middle">wastewater treatment runs the same logic in reverse-ish: screen, settle, treat biologically, then disinfect before release</text>
      <text class="lb" x="350" y="252" text-anchor="middle">(the deep environmental-engineering theory of these processes is its own subject — this is the services overview)</text>
    </svg>`,
    caption: "Treating water is a train of steps, each removing what the previous one left behind, arranged from coarse to fine. Screening catches the leaves and rags; sedimentation lets the suspended solids settle out slowly; filtration through sand traps the fine particles; and disinfection, usually with chlorine, kills the pathogens too small to filter. <strong>The order is deliberate — physical and cheap first, chemical and precise last</strong> — because settling out the bulk of the solids first makes every later step easier and cheaper. Wastewater treatment follows the same logic before the water is safely returned to a river.",
  },

  /* ------------------------------------------- 5.1 MEANS OF EGRESS */
  "hb-bs-egress": {
    label: "Means of egress — getting everyone out in time",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A floor plan showing occupants reaching exits, with the travel distance from the farthest point to an exit limited by code, two exits provided so one blocked route is not fatal, and dead-end corridors avoided.">
      ${hbmk("eg2")}
      <text class="em" x="350" y="24" text-anchor="middle">IN A FIRE, THE BUILDING IS JUDGED BY HOW FAST IT EMPTIES</text>
      <rect class="soft" x="90" y="60" width="330" height="170" fill="none"/>
      <rect class="soft-b" x="90" y="130" width="24" height="40"/>
      <text class="lb" x="102" y="186" text-anchor="middle">EXIT</text>
      <rect class="soft-b" x="396" y="90" width="24" height="40"/>
      <text class="lb" x="408" y="146" text-anchor="middle">EXIT</text>
      <circle class="hif" cx="300" cy="190" r="5"/>
      <text class="lb" x="300" y="210" text-anchor="middle">farthest point</text>
      <path class="ac" d="M300 190 Q220 175 114 150" stroke-dasharray="6 4" marker-end="url(#eg2-c)"/>
      <text class="ea" x="220" y="160">travel distance (limited)</text>
      <path class="hi" d="M340 90 L420 90" stroke-dasharray="6 4"/>
      <text class="lb" x="360" y="82">second route</text>

      <line class="gl" x1="450" y1="56" x2="450" y2="286"/>
      <text class="em" x="468" y="84">three rules keep people alive:</text>
      <text class="ea" x="468" y="112">TRAVEL DISTANCE</text>
      <text class="lb" x="468" y="130">no point too far from an exit</text>
      <text class="lb" x="468" y="148">(NBC limits it by occupancy)</text>
      <text class="ea" x="468" y="176">TWO EXITS</text>
      <text class="lb" x="468" y="194">so one blocked route is not fatal —</text>
      <text class="lb" x="468" y="212">remote from each other</text>
      <text class="ea" x="468" y="240">EXIT WIDTH</text>
      <text class="lb" x="468" y="258">enough for the occupant load —</text>
      <text class="lb" x="468" y="276">more people, wider exits</text>
    </svg>`,
    caption: "Fire safety begins not with putting the fire out but with getting people out, and the plan is judged by how fast it can empty. Three rules do most of the work: no point on the floor may be further than a set travel distance from an exit; there must be at least two exits, remote from each other, so a single blocked route is not a death trap; and the exits must be wide enough for the number of people (the occupant load) to pass in time. <strong>The exits are sized for the crowd, not the doorway</strong> — the NBC ties every dimension to how many people must escape.",
  },

  /* ------------------------------------------- 6.1 FIRE RESISTANCE */
  "hb-bs-fire": {
    label: "Fire load, resistance rating and compartmentation",
    svg: `<svg viewBox="0 0 732 290" role="img" aria-label="The fire triangle of fuel, heat and oxygen, the idea of fire load as the fuel per unit floor area, and compartmentation where fire-resistant walls and floors box a fire into one part of a building for a rated number of hours.">
      ${hbmk("fi")}
      <text class="em" x="350" y="24" text-anchor="middle">BUY TIME: BOX THE FIRE IN AND RATE THE WALLS BY HOURS</text>
      <path class="hi" d="M150 170 L110 240 L190 240 Z" fill="none" stroke-width="2"/>
      <text class="ea" x="150" y="164" text-anchor="middle">FUEL</text>
      <text class="lb" x="96" y="256">HEAT</text>
      <text class="lb" x="204" y="256">OXYGEN</text>
      <text class="lb" x="150" y="212" text-anchor="middle">fire needs</text>
      <text class="lb" x="150" y="228" text-anchor="middle">all three</text>

      <rect class="soft" x="270" y="70" width="180" height="150"/>
      <line class="s" x1="360" y1="70" x2="360" y2="220" stroke-width="4"/>
      <rect class="soft-b" x="272" y="72" width="86" height="146"/>
      <path class="ac" d="M300 120 q10 -14 20 0 q10 14 20 0" />
      <text class="lb" x="315" y="170" text-anchor="middle">fire</text>
      <text class="lb" x="405" y="150" text-anchor="middle">safe,</text>
      <text class="lb" x="405" y="168" text-anchor="middle">for now</text>
      <text class="ea" x="360" y="240" text-anchor="middle">a rated wall holds it back</text>

      <line class="gl" x1="480" y1="56" x2="480" y2="286"/>
      <text class="em" x="498" y="84">FIRE LOAD</text>
      <text class="lb" x="498" y="106">= fuel (contents) per m² of floor.</text>
      <text class="lb" x="498" y="124">more fuel → hotter, longer fire</text>
      <text class="em" x="498" y="154">FIRE-RESISTANCE RATING</text>
      <text class="lb" x="498" y="176">how long a wall/floor holds back</text>
      <text class="lb" x="498" y="194">fire — rated in HOURS (1h, 2h, 4h)</text>
      <text class="em" x="498" y="224">COMPARTMENTATION</text>
      <text class="lb" x="498" y="246">rated walls box the fire into one</text>
      <text class="lb" x="498" y="264">part, so it cannot spread while</text>
      <text class="lb" x="498" y="282">people escape and crews arrive</text>
    </svg>`,
    caption: "Fire needs three things — fuel, heat and oxygen — and fire safety works by buying time against it. The fire load is how much fuel (the building's contents) sits on each square metre of floor; more fuel means a hotter, longer fire. Walls and floors are given a fire-resistance rating in hours — how long they hold the fire back — and compartmentation uses those rated barriers to box a fire into one part of the building. <strong>None of this puts the fire out; it holds it in place</strong> long enough for people to escape and the fire service to arrive.",
  },

});
