/* ============================================================
   CIVIL EDUCATOR — Hindi explanations (भाग 1)
   हर topic के चार हिस्सों का हिन्दी रूपांतर: what / why / example / tip.
   तकनीकी शब्द जान-बूझकर अंग्रेज़ी में रखे गए हैं, क्योंकि परीक्षा,
   drawing और site पर वही शब्द चलते हैं।

   आकार:  DB.hindi[topicId] = { what, why, eg, tip }
   app.js इन्हें तभी दिखाता है जब भाषा हिन्दी चुनी हो और entry मौजूद हो।
   ============================================================ */

window.DB = window.DB || {};
DB.hindi = DB.hindi || {};

Object.assign(DB.hindi, {

  "t-grades": {
    what: "कंक्रीट को उसकी characteristic compressive strength से श्रेणी दी जाती है — 28 दिन बाद 150 mm के cube पर नापी गई ताक़त। लिखा जाता है M के बाद वह ताक़त N/mm² में। M25 यानी characteristic strength 25 N/mm²। IS 456 इन्हें तीन समूहों में बाँटता है — ordinary (M10–M20), standard (M25–M55) और high strength (M60–M80)।",
    why: "Grade तय होते ही आगे का लगभग सब कुछ तय हो जाता है — design strength 0.67 fck/1.5, shear capacity, modulus of elasticity, bond stress, और आपकी exposure condition के लिए अनुमत न्यूनतम grade। Grade चुनना सिर्फ़ खर्च का फ़ैसला नहीं है; durability के नियम अक्सर strength से ज़्यादा ऊँचा grade माँग लेते हैं।",
    eg: "M20 के हिसाब से design किया गया residential slab अगर समुद्र किनारे (severe exposure) बन रहा है तो मान्य नहीं होगा — Table 5 severe exposure में RCC के लिए कम से कम M30 माँगता है, चाहे strength की गणना M20 से पूरी हो रही हो।",
    tip: "'Characteristic strength' का मतलब — वह मान जिससे नीचे 5% से ज़्यादा test result आने की उम्मीद नहीं (Cl. 36.1)। यह औसत ताक़त नहीं है; mix design में target mean strength हमेशा इससे ऊपर रखी जाती है।",
  },

  "t-exposure": {
    what: "IS 456 पाँच environmental exposure conditions बताता है — mild, moderate, severe, very severe और extreme — जो इस बात से तय होती हैं कि कंक्रीट की सतह किस माहौल में रहेगी। हर एक के लिए Table 5 न्यूनतम cement content, अधिकतम free water-cement ratio और न्यूनतम grade तय करता है।",
    why: "ज़्यादातर कंक्रीट crushing से fail नहीं होता; वह reinforcement की corrosion, sulphate attack या chloride ingress से fail होता है। इसलिए durability की शर्तें mix को strength से बहुत पहले control कर लेती हैं — और ये सलाह नहीं, अनिवार्य नियम हैं।",
    eg: "समुद्र तट से 500 m दूर की इमारत 'severe' exposure में आती है। RCC के लिए इसका मतलब — कम से कम 320 kg/m³ cement, अधिकतम w/c 0.45 और न्यूनतम M30 — साथ में Table 16 से 45 mm nominal cover।",
    tip: "परीक्षा का पसंदीदा सवाल: Table के मान 20 mm nominal maximum size aggregate के लिए हैं। 40 mm aggregate पर cement content घटाई जा सकती है और 10 mm पर बढ़ानी पड़ती है — Table 5 के नीचे के notes ज़रूर पढ़ें।",
  },

  "t-cover": {
    what: "Nominal cover कंक्रीट की सतह से सारे steel की सबसे बाहरी सतह तक की design दूरी है — इसमें stirrup या link भी शामिल है, सिर्फ़ main bar नहीं। यह दो चीज़ों से तय होती है: durability (Table 16, exposure के अनुसार) और fire resistance (Table 16A, ज़रूरी fire rating के अनुसार)।",
    why: "Steel की एकमात्र सुरक्षा cover ही है। कम हुआ तो bar में जंग लगेगी, cover उखड़ेगा और member की capacity घट जाएगी। ज़्यादा हुआ तो effective depth घट जाएगी, cracking बढ़ेगी और member flexure में design से कमज़ोर निकलेगा।",
    eg: "Mild exposure में अंदरूनी beam: nominal cover 20 mm। वही beam समुद्र किनारे severe exposure में जाए तो 45 mm हो जाती है — 450 mm गहरी beam में यह effective depth का 25 mm नुकसान है, जिसे design में वापस जोड़ना पड़ेगा।",
    tip: "तीन नियम जो छात्र भूल जाते हैं: (क) nominal cover कभी bar के व्यास से कम नहीं होगी (Cl. 26.4.1); (ख) footing में कम से कम 50 mm; (ग) column में longitudinal bars तक cover आम तौर पर न 40 mm से कम, न bar के व्यास से कम (Cl. 26.5.3.1)।",
  },

  "t-ld": {
    what: "Development length वह लंबाई है जितनी bar चाहिए ताकि वह अपना बल bond के ज़रिए कंक्रीट में पहुँचा सके और सचमुच अपनी design stress तक पहुँच पाए। IS 456 देता है Ld = φ σs / (4 τbd), जहाँ φ bar का व्यास है, σs उस section पर bar में stress (पूरी capacity पर 0.87 fy) और τbd उस grade के लिए design bond stress।",
    why: "जो bar develop नहीं हुई वह बस खिंचकर बाहर आ जाती है — drawing पर लिखा steel area बेमानी है अगर bar को पकड़ने की जगह ही नहीं। Development length तय करती है कि bar कहाँ curtail हो सकती है, support के अंदर कितनी जानी चाहिए, और हर hook व bend का आकार क्या होगा।",
    eg: "M25 में Fe 500 bars: plain bars के लिए τbd = 1.4 N/mm², deformed bars के लिए 60% बढ़ाकर → 2.24 N/mm²। Ld = φ × 0.87 × 500 / (4 × 2.24) = 48.5 φ। 16 mm bar के लिए लगभग 780 mm।",
    tip: "Compression में bars के लिए τbd और 25% बढ़ जाती है (Cl. 26.2.1.1), इसलिए compression development length छोटी होती है। दोनों गुणक अलग-अलग याद रखें: deformed bars के लिए ×1.6, compression के लिए ×1.25।",
  },

  "t-lap": {
    what: "जहाँ bar जोड़नी पड़े, IS 456 lap splice की अनुमति देता है। Flexural tension में lap — Ld या 30 φ, जो बड़ा हो। Direct tension में — 2 Ld या 30 φ, जो बड़ा हो। Compression में — compression की development length या 24 φ, जो बड़ा हो।",
    why: "Bars तय लंबाई में आती हैं (आम तौर पर 12 m); हर लंबे member में splice चाहिए ही। High-stress ज़ोन में रखे गए या छोटे रह गए lap site की सबसे आम ख़ामियों में हैं और distress का बार-बार दिखने वाला कारण।",
    eg: "M25 में Fe 500, 16 mm bar, flexural tension: Ld ≈ 48.5 φ = 776 mm; 30 φ = 480 mm। Lap = 776 mm, जिसे bar bending schedule में ऊपर round कर लिया जाता है।",
    tip: "Cl. 26.2.5.1 यह भी कहता है कि splice stagger होने चाहिए और जहाँ तक हो सके maximum stress वाले section से दूर। Column में lap आम तौर पर storey height के बीच वाले तिहाई में रखे जाते हैं, floor level पर नहीं।",
  },

  "t-minmax-beam": {
    what: "Beam में न्यूनतम tension reinforcement As/(b d) = 0.85/fy है। अधिकतम tension reinforcement 0.04 b D है, और अधिकतम compression reinforcement भी 0.04 b D। जहाँ overall depth 750 mm से ज़्यादा हो, वहाँ web area का 0.1% side face reinforcement देना होगा — दोनों फलकों पर बाँटकर, spacing 300 mm या web की मोटाई, जो कम हो, से ज़्यादा नहीं।",
    why: "न्यूनतम सीमा अचानक (brittle) failure से बचाती है — बहुत कम steel वाली beam उसी क्षण crack होकर fail हो जाती है जिस क्षण कंक्रीट की tensile strength पार होती है। अधिकतम सीमा section को डालने और compact करने लायक रखती है और lap पर भीड़ नहीं होने देती।",
    eg: "Beam 300 × 500 mm, d = 460 mm, Fe 415: न्यूनतम As = 0.85/415 × 300 × 460 = 283 mm² — दो 16 mm bars (402 mm²) आराम से पूरा कर देती हैं। अधिकतम = 0.04 × 300 × 500 = 6000 mm²।",
    tip: "दोनों सूत्रों का फ़र्क़ ध्यान से देखें: न्यूनतम में effective depth d है, अधिकतम में overall depth D। यही फ़र्क़ भूलने पर हर university पेपर में नंबर कटते हैं।",
  },

  "t-minmax-slab": {
    what: "Slab में हर दिशा का न्यूनतम reinforcement — mild steel के लिए gross cross-sectional area का 0.15% और high strength deformed bars के लिए 0.12%। Slab में bar का अधिकतम व्यास slab की कुल मोटाई का आठवाँ हिस्सा। Main bars की spacing 3 d या 300 mm, जो कम हो, से ज़्यादा नहीं; distribution bars 5 d या 450 mm, जो कम हो, से ज़्यादा नहीं।",
    why: "Slab पतले होते हैं और उन पर stress कम पड़ता है, इसलिए अक्सर गणना से निकला area नहीं बल्कि न्यूनतम सीमा ही चलती है। यह न्यूनतम जितना strength के लिए है, उतना ही shrinkage और temperature cracking रोकने के लिए।",
    eg: "150 mm slab, Fe 500: न्यूनतम As = 0.0012 × 1000 × 150 = 180 mm²/m। 8 mm bars 250 mm c/c पर दें (201 mm²/m)। अनुमत अधिकतम व्यास = 150/8 = 18.75 mm, इसलिए 8 mm ठीक है।",
    tip: "0.12% कुल (gross) area b × D पर निकाला जाता है, b × d पर नहीं। यह beam के न्यूनतम से अलग है, जहाँ b × d चलता है।",
  },

  "t-colreinf": {
    what: "Column में longitudinal steel gross cross-sectional area का न्यूनतम 0.8% और अधिकतम 6%। Rectangular column में कम से कम चार bars, circular में छह; न्यूनतम bar व्यास 12 mm; परिधि के साथ नापी गई longitudinal bars की दूरी 300 mm से ज़्यादा नहीं। Lateral ties सबसे बड़ी longitudinal bar के व्यास के कम से कम एक-चौथाई और 6 mm से कम नहीं, और pitch least lateral dimension, सबसे छोटी longitudinal bar के व्यास का 16 गुना, या 300 mm — इनमें से किसी से ज़्यादा नहीं।",
    why: "Longitudinal bars कंक्रीट के साथ axial load उठाती हैं और bending सहती हैं; ties उन्हें बाहर की ओर buckle होने से रोकती हैं और core को confine करती हैं। Ductile column और फट जाने वाले column के बीच का फ़र्क़ tie spacing ही है।",
    eg: "Column 300 × 450 mm, 20 mm main bars और 8 mm ties: pitch ≤ इनमें सबसे कम — 300 mm (least dimension), 16 × 20 = 320 mm, और 300 mm → यानी 300 mm। व्यवहार में designer 150–200 mm लेते हैं, और IS 13920 confining ज़ोन में इससे भी बहुत क़रीब spacing माँगता है।",
    tip: "6% code की अधिकतम सीमा है पर जहाँ bars lap होती हैं वहाँ व्यावहारिक रूप से बन ही नहीं सकती — code ख़ुद कहता है कि lap वाली जगह पर यह 4% से ऊपर नहीं जानी चाहिए। ज़्यादातर design office 4% को ही असली छत मानते हैं।",
  },

  "t-spandepth": {
    what: "Deflection आम तौर पर बिना गणना के, span to effective depth ratio सीमित करके control की जाती है। 10 m तक के span के लिए मूल मान — cantilever 7, simply supported 20, continuous 26। फिर इन्हें tension reinforcement (Fig. 4), compression reinforcement (Fig. 5) और flanged sections (Fig. 6) के modification factors से गुणा किया जाता है।",
    why: "प्रारंभिक depth तय करने का यह सबसे तेज़ तरीक़ा है, और slab में तो यही पूरा design चला देता है। ज़्यादातर floor slab जितने मोटे होते हैं, वे strength की वजह से नहीं — serviceability की वजह से होते हैं।",
    eg: "4 m clear span का simply supported one-way slab, Fe 415, हल्का reinforced जिससे tension-steel modification factor लगभग 1.4: d ≥ 4000 / (20 × 1.4) = 143 mm। Cover और आधा bar व्यास जोड़कर → लगभग 165 mm overall।",
    tip: "10 m से ऊपर के span के लिए मूल मानों को 10/span (metre में) से गुणा किया जाता है — cantilever को छोड़कर, जहाँ इसकी जगह पूरी deflection गणना करनी पड़ती है।",
  },

  "t-limitstate": {
    what: "Design दो limit states के लिए किया जाता है — collapse और serviceability। Material के partial safety factors: कंक्रीट के लिए 1.5 और steel के लिए 1.15 (Cl. 36.4.2), जिससे design strengths बनती हैं 0.67 fck/1.5 = 0.446 fck और fy/1.15 = 0.87 fy। Load factors Table 18 से आते हैं — सबसे आम 1.5 (DL + LL)।",
    why: "Partial safety factors ही वह जगह हैं जहाँ code अपनी सुरक्षा का margin रखता है: अलग से loads पर (जो बढ़ सकते हैं) और अलग से materials पर (जो कमज़ोर निकल सकते हैं)। working stress design और limit state design का फ़र्क़ यही है।",
    eg: "6.0 kN/m² dead और 3.0 kN/m² live उठाने वाला slab: design load = 1.5 (6.0 + 3.0) = 13.5 kN/m²। RCC के हर सूत्र में दिखने वाला 0.87 fy दरअसल fy/1.15 से ही आता है।",
    tip: "कंक्रीट को बड़ा factor (1.5) मिलता है क्योंकि उसकी ताक़त ज़्यादा बदलती है और workmanship पर निर्भर है; steel कारखाने में बनता है, इसलिए उसे 1.15 मिलता है।",
  },

  "t-mulim": {
    what: "Ductile (under-reinforced) failure पक्का करने के लिए IS 456 neutral axis की गहराई सीमित करता है: xu,max/d = Fe 250 के लिए 0.53, Fe 415 के लिए 0.48 और Fe 500 के लिए 0.46। इसे stress block में रखने पर (C = 0.36 fck b xu, lever arm d − 0.42 xu) limiting moment of resistance मिलता है — Mu,lim = 0.148 fck bd² (Fe 250), 0.138 fck bd² (Fe 415) और 0.133 fck bd² (Fe 500)।",
    why: "यही एक जाँच तय करती है कि आपका section singly reinforced रहेगा या उसे compression steel चाहिए। साथ ही यह पक्का करती है कि कंक्रीट के crush होने से पहले steel yield हो जाए — यानी beam fail होने से पहले चेतावनी दे।",
    eg: "Beam 300 mm चौड़ी × 450 mm effective depth, M25, Fe 415: Mu,lim = 0.138 × 25 × 300 × 450² = 209.6 kN·m। अगर factored moment 250 kN·m है तो section या तो doubly reinforced करना होगा या गहरा करना होगा।",
    tip: "0.36 और 0.42 रट लें — यही stress block के स्थिरांक हैं। 0.36 fck b xu compressive force है; 0.42 xu उसके centroid की extreme compression fibre से गहराई।",
  },

  "t-shear": {
    what: "Nominal shear stress τv = Vu/(b d)। इसकी तुलना कंक्रीट की design shear strength τc से की जाती है, जो grade और tension steel के प्रतिशत पर निर्भर है (Table 19), और यह कभी अधिकतम shear stress τc,max (Table 20) से ऊपर नहीं जा सकती। अगर τv ≤ τc तो सिर्फ़ न्यूनतम shear reinforcement चाहिए; अगर τc < τv ≤ τc,max तो बचे हुए हिस्से के लिए stirrups design होंगे; और अगर τv > τc,max तो section का आकार ही बढ़ाना पड़ेगा।",
    why: "कंक्रीट में shear failure अचानक और brittle होता है — flexure की तरह कोई चेतावनी नहीं मिलती। इसीलिए code एक ऐसी अंतिम सीमा τc,max देता है जिसे कितने भी stirrups लगाकर नहीं बढ़ाया जा सकता।",
    eg: "Beam b = 300 mm, d = 450 mm, Vu = 150 kN: τv = 150000/(300 × 450) = 1.11 N/mm²। M25 और pt = 0.75% पर τc ≈ 0.57 N/mm², इसलिए stirrups को उठाना है Vus = 150 − 0.57 × 300 × 450/1000 = 73 kN। M25 के लिए τc,max = 3.1 N/mm², यानी section का आकार ठीक है।",
    tip: "tension steel का प्रतिशत बढ़ने पर τc बढ़ती है, क्योंकि ज़्यादा steel से cracks महीन रहती हैं और aggregate interlock बेहतर होता है — Table 19 में pt का column इसीलिए है।",
  },

  "t-minshear": {
    what: "न्यूनतम shear reinforcement — Asv/(b sv) ≥ 0.4/(0.87 fy)। Vertical stirrups की अधिकतम spacing 0.75 d, और 45° पर झुके stirrups के लिए d — पर किसी भी हाल में 300 mm से ज़्यादा नहीं।",
    why: "न्यूनतम stirrups पूरे cage को बाँधकर रखते हैं, longitudinal bars को buckle होने से रोकते हैं, और brittle shear failure में थोड़ी ductility ले आते हैं। Spacing की सीमा यह पक्का करती है कि कोई भी diagonal crack कम से कम एक stirrup को ज़रूर काटे।",
    eg: "Beam b = 300 mm, Fe 415, 8 mm दो-टाँग वाले stirrups (Asv = 100 mm²): sv ≤ 0.87 × 415 × 100 / (0.4 × 300) = 301 mm; साथ ही ≤ 0.75 d और ≤ 300 mm। d = 450 mm पर 0.75 d = 337 mm, इसलिए 300 mm ही चलेगा।",
    tip: "Seismic design में IS 13920 beam के सिरों के पास ये सारे आँकड़े पूरी तरह बदल देता है — confining ज़ोन में spacing गिरकर d/4 या 100 mm हो जाती है।",
  },

  "t-curing": {
    what: "Ordinary Portland cement के कंक्रीट में खुली सतहों को डालने की तारीख़ से कम से कम सात दिन लगातार नम रखना ज़रूरी है। जहाँ mineral admixture या blended cement इस्तेमाल हुआ हो, यह अवधि बढ़कर दस दिन हो जाती है। गर्म और सूखे मौसम में ये अवधि और बढ़ा दी जाती है (Cl. 13.5.1)।",
    why: "Hydration तभी तक चलती है जब तक पानी मौजूद है। सात की जगह तीन दिन cure हुआ कंक्रीट अपनी संभावित 28-दिन strength का बड़ा हिस्सा खो सकता है और — इससे भी ज़्यादा अहम — कहीं ज़्यादा permeable हो जाता है, जो strength नहीं बल्कि durability की समस्या है।",
    eg: "सोमवार को डाला गया PPC slab कम से कम अगले गुरुवार (10 दिन) तक गीला रखना होगा, सिर्फ़ एक हफ़्ता नहीं — कई site engineer आदतन OPC वाला आँकड़ा लगा देते हैं।",
    tip: "जहाँ ponding व्यावहारिक न हो वहाँ curing compound विकल्प के रूप में मान्य हैं, बशर्ते वे evaporation को पर्याप्त रूप से रोकते सिद्ध हों। Curing तभी शुरू कर देनी चाहिए जब कंक्रीट इतना सख़्त हो जाए कि नुकसान न पहुँचे।",
  },

  "t-formwork": {
    what: "IS 456 सामान्य तापमान पर OPC कंक्रीट के लिए formwork हटाने से पहले की न्यूनतम अवधि देता है: column, wall और beam के किनारों का vertical formwork 16–24 घंटे; slab का soffit formwork (props नीचे रहते हुए) 3 दिन; beam का soffit formwork (props नीचे रहते हुए) 7 दिन; 4.5 m तक span वाले slab के props 7 दिन और उससे ज़्यादा पर 14 दिन; 6 m तक span वाली beam और arch के props 14 दिन और उससे ज़्यादा पर 21 दिन।",
    why: "Props जल्दी हटाना construction-stage collapse के सबसे आम कारणों में है। कंक्रीट set भले हो गया हो, पर उसने अभी अपना ही वज़न और अगली मंज़िल का load उठाने लायक ताक़त नहीं पाई होती।",
    eg: "1 जून को डाली गई 6 m span की beam: किनारे 2 जून को खुल सकते हैं, soffit shuttering 8 जून को (props रहने देकर), और props ख़ुद 15 जून को।",
    tip: "ये सामान्य मौसम में OPC के लिए न्यूनतम अवधियाँ हैं। Blended cement के साथ, ठंडे मौसम में, या जहाँ member पर जल्दी load आ जाए — अवधि बढ़ानी पड़ेगी। Code यह भी मानता है कि site-cured cubes की असली strength के आधार पर formwork हटाया जा सकता है।",
  },

  "t-acceptance": {
    what: "Sampling की दर — 1–5 m³ कंक्रीट पर एक sample, 6–15 m³ पर दो, 16–30 m³ पर तीन, 31–50 m³ पर चार, और उसके बाद हर अतिरिक्त 50 m³ या उसके हिस्से पर एक और। कंक्रीट तब स्वीकार होता है जब लगातार चार non-overlapping samples के किसी भी समूह की औसत strength fck + 0.825 × स्थापित standard deviation से ऊपर हो (या M20 और उससे ऊपर के लिए fck + 4 N/mm², जो बड़ा हो), और कोई भी individual test result fck − 4 N/mm² से नीचे न गिरे।",
    why: "कंक्रीट की strength एक सांख्यिकीय राशि है। एक कम cube देखकर पूरे pour को ख़ारिज करना — या एक ऊँचे cube पर स्वीकार कर लेना — code की असली माँग को ग़लत पढ़ना है।",
    eg: "M25, लगातार चार samples का औसत 30.2 N/mm² और कोई individual result 21 N/mm² से नीचे नहीं — स्वीकार्य है: औसत ≥ 25 + 4 = 29, individual ≥ 25 − 4 = 21।",
    tip: "एक test result दरअसल एक ही sample के तीन cubes का औसत होता है, और कोई भी cube उस औसत से ±15% से ज़्यादा अलग नहीं हो सकता। 'Sample' और 'cube' एक चीज़ नहीं हैं।",
  },

  "t-800-psf": {
    what: "IS 800 में γm0 = 1.10 उस resistance के लिए जो yielding या buckling से तय हो, γm1 = 1.25 उस resistance के लिए जो ultimate stress से तय हो (net section rupture), bolts के लिए γmb = 1.25, और welds के लिए γmw = 1.25 shop welding में तथा 1.50 site welding में।",
    why: "कौन-सा factor लगेगा, यही बताता है कि code किस failure mode को ज़्यादा ख़तरनाक मानता है। Rupture brittle है, इसलिए उसे बड़ा factor मिलता है; yielding ductile है, उसे छोटा।",
    eg: "Tension में एक plate: yielding capacity Ag fy/1.10 से, net section की rupture 0.9 An fu/1.25 से। दोनों में से जो कम हो, वही design चलाएगा।",
    tip: "Site welds को 1.25 की जगह 1.50 सिर्फ़ workmanship और inspection की परिस्थितियों की वजह से मिलता है — viva का पसंदीदा सवाल।",
  },

  "t-800-tension": {
    what: "Tension member की design strength इन तीन में सबसे कम होती है: gross section का yielding Tdg = Ag fy/γm0; net section की rupture Tdn (plates के लिए 0.9 An fu/γm1, और एक ही leg से जुड़े angles में shear-lag सुधार के साथ); और block shear failure Tdb, जैसा Cl. 6.4 में दिया है।",
    why: "Tension member सबसे सरल steel member है और यहीं तीनों mode वाली जाँच सबसे साफ़ दिखती है। Block shear छूट जाना gusset plate connection की क्लासिक design ग़लती है।",
    eg: "ISA 75×75×8, एक ही leg से 4 bolts द्वारा जुड़ा: पहले gross yielding निकालें, फिर Cl. 6.3.3 के shear-lag factor के साथ net section rupture, फिर bolt line के आर-पार block shear — design strength इनमें सबसे कम।",
    tip: "जहाँ bolt holes कम हों वहाँ आम तौर पर gross yielding ही चलता है; holes की संख्या बढ़ने या end distance घटने पर net rupture और block shear आगे आ जाते हैं।",
  },

  "t-800-comp": {
    what: "Design compressive strength Pd = Ae fcd, जहाँ fcd उपयुक्त buckling class (a, b, c या d — imperfection factor α क्रमशः 0.21, 0.34, 0.49 और 0.76) के column curve से मिलता है। Slenderness ratio KL/r की सीमा Table 3 में है — उदाहरण के लिए dead और imposed load से compressive load उठाने वाले members के लिए 180, और उन members के लिए 250 जो सामान्यतः tension में रहते हैं पर हवा में उलट सकते हैं।",
    why: "Compression members yield stress तक पहुँचने से बहुत पहले buckling से fail हो जाते हैं, और buckling class उन residual stresses व शुरुआती टेढ़ेपन का हिसाब रखती है जो rolled, welded और hollow sections में अलग-अलग होते हैं।",
    eg: "ISMB 200 column, 3.5 m effective length: λ = KL/r निकालें, Table 10 से buckling class लें, IS 800 की Table 9 से fcd पढ़ें, और effective area से गुणा कर दें।",
    tip: "Effective length factor K सिरों की restraint पर निर्भर है (Table 11) — पूरी तरह fixed सिरों के लिए 0.65 से लेकर स्वतंत्र खड़े cantilever column के लिए 2.0 तक। K ग़लत हो जाए तो गणना की बाक़ी सारी बारीकियाँ बेकार हो जाती हैं।",
  },

  "t-800-bend": {
    what: "Laterally supported beam की design bending strength Md = βb Zp fy/γm0, जहाँ βb plastic और compact sections के लिए 1.0 है और semi-compact के लिए Ze/Zp। Laterally unsupported beams में lateral torsional buckling के कारण strength घटाई जाती है — Cl. 8.2.2 के अनुसार।",
    why: "IS 800:2007 ने steel design को allowable stress से हटाकर plastic section capacity पर ला दिया — एक compact section elastic Ze fy से काफ़ी ज़्यादा moment उठा सकता है, पर तभी जब section compact हो और laterally restrained भी।",
    eg: "ISMB 400, Fe 410 (fy = 250), laterally supported: Md = 1.0 × Zp × 250/1.10। Code simply supported beams में Md को 1.2 Ze fy/γm0 पर सीमित भी कर देता है, ताकि service load पर deflection क़ाबू में रहे।",
    tip: "सबसे पहले section को वर्गीकृत करें (plastic / compact / semi-compact / slender, Table 2)। यही वर्गीकरण तय करता है कि आप कौन-सा सूत्र इस्तेमाल करने के हक़दार भी हैं।",
  },

  "t-800-bolt": {
    what: "Bearing-type bolt की दो जाँच होती हैं — shear (Vdsb, जिसमें fub/√3 threaded या shank area पर काम करता है) और जुड़ी हुई plate पर bearing (Vdpb = 2.5 kb d t fu/γmb); जो कम हो वही चलेगा। न्यूनतम pitch bolt के व्यास का 2.5 गुना; न्यूनतम edge distance rolled या machine flame cut किनारों के लिए hole व्यास का 1.5 गुना और sheared या hand flame cut किनारों के लिए 1.7 गुना।",
    why: "असली सीमा शायद ही कभी bolt की capacity होती है — आम तौर पर पतली plate पर bearing या कम edge distance ही तय करता है, और छोटी edge distance yield होने की जगह फाड़कर निकल जाती है।",
    eg: "10 mm plates में M20 grade 4.6 bolts: न्यूनतम pitch = 2.5 × 20 = 50 mm; 22 mm hole के साथ machine flame cut किनारे के लिए न्यूनतम edge distance = 1.5 × 22 = 33 mm।",
    tip: "Bearing के सूत्र में kb चार राशियों में सबसे छोटी होती है — edge distance, pitch, bolt-to-plate strength ratio और 1.0 — और यहीं ज़्यादातर छात्रों के नंबर कटते हैं।",
  },

  "t-800-weld": {
    what: "90° पर मिले हिस्सों के बीच fillet weld की effective throat thickness weld के आकार का 0.7 गुना होती है। Effective length कुल लंबाई में से weld size का दोगुना घटाकर मिलती है, और वह weld size के कम से कम चार गुना होनी चाहिए। Design stress = fu/(√3 γmw)।",
    why: "Weld का आकार दोनों तरफ़ से सीमित है — बहुत छोटा हुआ तो जल्दी ठंडा होकर crack करेगा, plate के मुक़ाबले बहुत बड़ा हुआ तो member को टेढ़ा कर देगा। Cl. 10.5.2 के न्यूनतम आकार जुड़ रहे मोटे हिस्से के आधार पर तय होते हैं।",
    eg: "6 mm fillet weld, 200 mm लंबा, Fe 410, shop welded: throat = 0.7 × 6 = 4.2 mm; effective length = 200 − 12 = 188 mm; capacity = 4.2 × 188 × 410/(√3 × 1.25) N।",
    tip: "Fillet weld की ताक़त हमेशा throat पर निकाली जाती है, leg size पर कभी नहीं। और plate के किनारे के साथ अधिकतम आकार इसलिए सीमित है कि weld plate के कोने से बाहर न निकल जाए।",
  },

  "t-deadload": {
    what: "Dead load स्थायी निर्माण का अपना वज़न है। IS 875 Part 1 सामग्रियों के unit weights की सूची देता है — reinforced concrete आम तौर पर 25 kN/m³, plain concrete 24 kN/m³, brick masonry लगभग 19–20 kN/m³ और structural steel 78.5 kN/m³।",
    why: "ज़्यादातर कंक्रीट इमारतों में dead load ही हावी रहता है। पूरी इमारत में floor finish की मोटाई में मान ली गई 5% की ग़लती अधिकांश live load की बारीकियों से बड़ा आँकड़ा बन जाती है।",
    eg: "150 mm RC slab: अपना वज़न = 0.15 × 25 = 3.75 kN/m²। 24 kN/m³ पर 50 mm floor finish जोड़ें = 1.2 kN/m², यानी partition से पहले ही 4.95 kN/m² dead load।",
    tip: "Partition का load भूलें नहीं। जहाँ partition की जगह तय न हो, वहाँ एक समान रूप से फैला हुआ भत्ता (आम तौर पर 1.0 kN/m² या उससे ज़्यादा) dead load में जोड़ा जाता है।",
  },

  "t-liveload": {
    what: "IS 875 Part 2 occupancy के हिसाब से imposed floor loads देता है। अक्सर उद्धृत मान — residential कमरों के लिए 2.0 kN/m², balcony और classroom के लिए 3.0 kN/m², कमरे के प्रकार के अनुसार office के लिए 2.5–4.0 kN/m², और corridor, सीढ़ी व assembly क्षेत्रों के लिए 4.0 kN/m²। अपनी ठीक-ठीक occupancy का मान हमेशा code की table से ही पढ़ें।",
    why: "Live load वह load है जो आपके क़ाबू में नहीं। Corridor और सीढ़ियाँ उन कमरों से ज़्यादा उठाती हैं जिनकी वे सेवा करती हैं, क्योंकि निकासी के समय की भीड़ ही design case होती है।",
    eg: "एक residential flat: कमरों में 2.0 kN/m², पर balcony पर 3.0 kN/m² और साझा सीढ़ी पर 4.0 kN/m² — एक ही इमारत में तीन अलग मान।",
    tip: "Part 2 कई मंज़िलें उठाने वाले columns और foundations के लिए imposed load में कटौती की अनुमति भी देता है (यह संभावना कम है कि हर मंज़िल एक साथ पूरी भरी हो) — पर slab और beam के लिए कभी नहीं।",
  },

  "t-windload": {
    what: "z ऊँचाई पर design wind speed Vz = Vb k1 k2 k3 k4, जहाँ Vb wind map से basic wind speed है, k1 probability (risk) factor, k2 terrain-roughness और height factor, k3 topography factor, और k4 cyclonic क्षेत्रों के लिए importance factor (2015 revision में जोड़ा गया)। Design wind pressure pz = 0.6 Vz² N/m² में, Vz m/s में लेकर — जिसे आगे area averaging और combination factors से बदलकर pd मिलता है।",
        why: "ज़्यादातर ऊँची और हल्की संरचनाओं का lateral design हवा ही तय करती है, और 2015 revision में सबसे ज़्यादा यही load case बदला — जो अब भी 1987 संस्करण चला रहे हैं उनसे k4 और संशोधित pressure coefficients दोनों छूट रहे हैं।",
    eg: "रायपुर क्षेत्र, Vb = 39 m/s, k1 = 1.0, k2 = 1.05, k3 = 1.0, k4 = 1.0: Vz = 40.95 m/s और pz = 0.6 × 40.95² = 1006 N/m² ≈ 1.01 kN/m²।",
    tip: "याद रखें कि pz = 0.6 Vz² वाला 0.6 विमाहीन (dimensionless) नहीं है — उसमें हवा का घनत्व और unit conversion दोनों छिपे हैं। Vz m/s में डालना होगा और उत्तर N/m² में आएगा।",
  },

  "t-seismic": {
    what: "Design horizontal seismic coefficient Ah = (Z/2)(Sa/g)/(R/I), और design base shear VB = Ah W, जहाँ W seismic weight है। Z zone factor है, Sa/g इमारत के fundamental period और मिट्टी के प्रकार के लिए spectral acceleration, R response reduction factor और I importance factor।",
    why: "हर पद का एक भौतिक अर्थ है: Z/2 maximum considered earthquake को design basis earthquake में बदलता है, Sa/g dynamic amplification लाता है, R उस ductility का श्रेय देता है जिसके लिए संरचना detail की गई है, और I उन इमारतों की माँग बढ़ा देता है जिन्हें भूकंप के बाद भी चालू रहना है।",
    eg: "Zone IV में medium soil पर 5-मंज़िला SMRF अस्पताल, T = 0.5 s: Z = 0.24, Sa/g = 2.5, R = 5.0, I = 1.5 → Ah = (0.24/2)(2.5)/(5/1.5) = 0.09। Base shear = 0.09 W।",
    tip: "R सिर्फ़ detailing से कमाया जाता है। Special moment resisting frame के लिए R = 5 तब तक नहीं ले सकते जब तक frame सचमुच IS 13920 के अनुसार detail न हो — दोनों code एक साथ ही चलते हैं।",
  },

  "t-period": {
    what: "खाली (bare) RC moment resisting frame के लिए अनुमानित fundamental period Ta = 0.075 h^0.75; खाली steel moment resisting frame के लिए Ta = 0.085 h^0.75; RC-steel composite frame के लिए 0.080 h^0.75; और जहाँ frame में unreinforced masonry infill panels हों वहाँ Ta = 0.09 h/√d — जिसमें h ऊँचाई metre में और d विचाराधीन दिशा में base का माप।",
    why: "Period तय करता है कि आप response spectrum पर कहाँ बैठते हैं — और इसलिए Sa/g भी। एक जैसे वज़न वाली दो इमारतें सिर्फ़ period के फ़र्क़ से बहुत अलग base shear खींच सकती हैं।",
    eg: "15 m ऊँचा RC frame, brick infill के साथ, विचाराधीन दिशा में 20 m लंबा: Ta = 0.09 × 15/√20 = 0.30 s — जो spectrum के उस समतल हिस्से पर आता है जहाँ Sa/g = 2.5।",
    tip: "Infill इमारत को कड़ा करता है और period छोटा कर देता है, जिससे आम तौर पर seismic force बढ़ जाती है। इसलिए infill को नज़रअंदाज़ करना अपने आप conservative नहीं होता।",
  },

  "t-drift": {
    what: "Design lateral force के अंतर्गत storey drift, जो partial load factor 1.0 के साथ निकाली जाए, storey height के 0.004 गुना से ज़्यादा नहीं होनी चाहिए।",
    why: "Drift पर नियंत्रण non-structural elements — infill दीवारें, glazing, services — की रक्षा करता है और P-delta प्रभाव सीमित रखता है। एक frame पर्याप्त मज़बूत होकर भी मध्यम भूकंप के बाद drift से हुए नुकसान की वजह से इस्तेमाल लायक नहीं बचता।",
    eg: "3.2 m ऊँची storey: अधिकतम अनुमत drift = 0.004 × 3200 = 12.8 mm।",
    tip: "Drift की जाँच बिना factor वाले design lateral force से होती है — छात्र अक्सर यहाँ 1.5 लगा देते हैं और फिर ग़लत नतीजा निकालते हैं कि frame fail हो रहा है।",
  },

  "t-seismiczone": {
    what: "भारत चार seismic zones में बँटा है — II, III, IV और V — जिनके zone factor Z क्रमशः 0.10, 0.16, 0.24 और 0.36 हैं। Z maximum considered earthquake के लिए effective peak ground acceleration दर्शाता है, और design basis earthquake के लिए Z/2 इस्तेमाल होता है।",
    why: "Seismic force में सबसे बड़ा एकल गुणक zone factor ही है। Zone III से Zone V में जाने भर से माँग 2.25 गुना हो जाती है, बाक़ी किसी factor को छूने से पहले ही।",
    eg: "Zone III (Z = 0.16) मध्य भारत के बड़े हिस्से को ढकता है, जिसमें छत्तीसगढ़ से लगे क्षेत्र भी हैं; Zone V में पूर्वोत्तर, हिमालय के हिस्से, कच्छ क्षेत्र और अंडमान-निकोबार आते हैं।",
    tip: "Zone I को एक पुराने revision में Zone II में मिला दिया गया था — मौजूदा code में Zone I है ही नहीं। परीक्षा में उसका ज़िक्र तुरंत पकड़ में आ जाता है।",
  },

  "t-13920-mat": {
    what: "कोई भी detailing नियम लागू होने से पहले IS 13920 न्यूनतम गुणवत्ता और ज्यामिति तय करता है: न्यूनतम कंक्रीट grade M20 (Zone III, IV और V में 15 m से ऊँची इमारतों के लिए M25), reinforcement Fe 415 या उससे नीचे — Fe 500 और Fe 550 केवल D (ductile) पदनाम में ही मान्य। Beam कम से कम 200 mm चौड़ी हो, width-to-depth ratio 0.3 से कम नहीं, और clear span से effective depth का अनुपात भी सीमित है।",
    why: "Ductile detailing तभी काम करती है जब materials सचमुच विकृत हो सकें। बिना गारंटीशुदा elongation वाला बहुत ऊँची strength का steel yield होने की जगह टूट जाता है, और detailing का पूरा मक़सद ही ख़त्म हो जाता है।",
    eg: "Zone IV में 12-मंज़िला इमारत में M25 या बेहतर चाहिए, और अगर Fe 500 bars लिखी हैं तो वे Fe 500D होनी चाहिए — IS 1786 की ऊँची elongation शर्त के साथ।",
    tip: "Fe 500D का 'D' ductility के लिए है — ज़्यादा न्यूनतम elongation और नियंत्रित tensile-to-yield strength अनुपात। यह कोई marketing का suffix नहीं है।",
  },

  "t-13920-beam": {
    what: "Beam के हर फलक पर न्यूनतम longitudinal reinforcement 0.24 √fck/fy, और किसी भी फलक पर अधिकतम 2.5%। ऊपर और नीचे कम से कम दो bars लगातार चलनी चाहिए। Beam के सिरों के पास, effective depth के दोगुने की लंबाई में, hoops की दूरी effective depth के एक-चौथाई, सबसे छोटी longitudinal bar के व्यास के छह गुना, या 100 mm — इनमें से किसी से ज़्यादा नहीं।",
    why: "भूकंप के दौरान beam के सिरों पर plastic hinge बनते हैं। वहाँ पास-पास लगे hoops कंक्रीट को confine करते हैं और longitudinal bars को buckle नहीं होने देते, जिससे hinge बार-बार घूम सकता है और ताक़त नहीं खोता।",
    eg: "d = 450 mm वाली beam, नीचे 16 mm bars: सिरे वाले ज़ोन में hoop spacing ≤ इनमें सबसे कम — 450/4 = 112 mm, 6 × 16 = 96 mm, और 100 mm → 96 mm, इसलिए हर फलक से 900 mm तक 90 mm c/c रखा जाता है।",
    tip: "विशेष hoop ज़ोन support के फलक से 2d है — इसे column के फलक से नापें, column की केंद्र रेखा से नहीं।",
  },

  "t-confining": {
    what: "Column के हर सिरे पर lo लंबाई में special confining reinforcement देना ज़रूरी है — lo = बड़ी lateral dimension, clear height का छठा हिस्सा, और 450 mm में जो सबसे बड़ा हो। lo के भीतर hoops की दूरी column के न्यूनतम माप के एक-चौथाई, सबसे छोटी longitudinal bar के व्यास के छह गुना, या 100 mm से ज़्यादा नहीं — और 75 mm से कम भी नहीं।",
    why: "Confinement ही brittle column को ductile बनाता है: पास-पास लगे hoops cover उखड़ जाने के बाद भी core के कंक्रीट को बाँधे रखते हैं, जिससे frame के हिलते रहने पर भी column axial load उठाता रहता है।",
    eg: "Column 400 × 500 mm, 3 m clear height, 20 mm bars: lo = इनमें सबसे बड़ा — 500 mm, 3000/6 = 500 mm, और 450 mm → 500 mm। Spacing ≤ इनमें सबसे कम — 400/4 = 100 mm, 6 × 20 = 120 mm, और 100 mm → 100 mm।",
    tip: "जो column किसी टूटे हुए कड़े member को उठा रहा हो (जैसे shear wall के नीचे खड़ा column), उसमें confining reinforcement पूरी ऊँचाई पर देनी होगी — यही soft-storey का क्लासिक इलाज है।",
  },

  "t-scwb": {
    what: "Moment frame के हर beam-column joint पर, columns की design moment capacities का योग उस joint में विचाराधीन तल में आ रही beams की design moment capacities के योग का कम से कम 1.4 गुना होना चाहिए।",
    why: "Beam में बने hinge स्थानीय होते हैं और उनकी मरम्मत हो सकती है; column में बने hinge पूरी मंज़िल गिरा सकते हैं। यह एक नियम नुकसान को ज़बरदस्ती वहीं ले जाता है जहाँ संरचना उसे झेल सकती है।",
    eg: "अगर किसी joint पर beams की संयुक्त capacity 200 kN·m है, तो ऊपर और नीचे के columns को मिलकर कम से कम 280 kN·m देना होगा।",
    tip: "यह शर्त अक्सर column का आकार axial load की गणना से कहीं ज़्यादा बढ़ा देती है — इसीलिए उतनी ही ऊँचाई के gravity frame के मुक़ाबले seismic frame में columns ज़्यादा गहरे होते हैं।",
  },

  "t-soilclass": {
    what: "मिट्टी को पहले कण के आकार से बाँटा जाता है: अगर 50% से ज़्यादा 75 micron छलनी पर रुक जाए तो मिट्टी coarse grained है (gravel G और sand S), वरना fine grained (silt M, clay C, organic O)। Fine grained मिट्टी को फिर plasticity chart से वर्गीकृत किया जाता है, जिसकी A-line है Ip = 0.73 (wL − 20); A-line के ऊपर वाली मिट्टी clay है, नीचे वाली silt, और liquid limit इसे low (<35), intermediate (35–50) और high (>50) compressibility में बाँटती है।",
    why: "Group symbol इंजीनियरिंग की शॉर्टहैंड है। CH सुनते ही पता चल जाता है कि ऊँची shrink-swell, कम permeability और settlement की दिक़्क़त मिलेगी; SW बताता है कि drainage अच्छी है और bearing भी।",
    eg: "एक मिट्टी जिसमें wL = 45 और Ip = 22: A-line का मान = 0.73 (45 − 20) = 18.25। चूँकि 22 > 18.25, बिंदु A-line के ऊपर है, और wL 35 से 50 के बीच होने से मिट्टी CI है — intermediate compressibility की clay।",
    tip: "मध्य भारत में आम काली कपास मिट्टी (black cotton soil) आम तौर पर CH में आती है — ऊँची liquid limit, A-line के ऊपर, और फूलने के लिए बदनाम। वहाँ नींव active zone के नीचे ले जाई जाती है या under-reamed piles के रूप में design की जाती है।",
  },

  "t-bearing": {
    what: "IS 6403 shear strength parameters से net ultimate bearing capacity देता है, जिसमें bearing capacity factors Nc, Nq और Nγ को shape, depth व inclination factors और water table correction factor से बदला जाता है। Net safe bearing capacity = net ultimate ÷ factor of safety, जो सामान्यतः 2.5 से कम नहीं। Allowable bearing pressure — safe bearing capacity और उस दबाव में जो कम हो, जिस पर settlement अनुमत सीमा में रहे।",
    why: "Footing का आकार दो अलग कसौटियाँ तय करती हैं — shear failure और settlement — और भारत की ज़्यादातर मिट्टियों में settlement ही चलता है। यह बताए बिना 'SBC' लिख देना कि वह किस कसौटी से आया, निरर्थक है।",
    eg: "cu = 60 kPa वाली clay में 1.5 m गहराई पर 2 m वर्गाकार footing: net ultimate ≈ cu Nc sc dc ≈ 60 × 5.14 × 1.2 × 1.1 ≈ 407 kPa; net safe = 407/2.5 ≈ 163 kPa।",
    tip: "रेत में ऊँची water table bearing capacity लगभग आधी कर सकती है, क्योंकि effective unit weight घटकर submerged मान पर आ जाता है। हमेशा पूछें कि water table कहाँ और किस मौसम में दर्ज हुई थी।",
  },

  "t-pile": {
    what: "Pile की ultimate capacity end bearing (Ap × point resistance) और skin friction (shaft पर unit friction × सतह क्षेत्रफल का योग) का जोड़ है। Cohesive मिट्टी में point resistance 9 cp ली जाती है और shaft friction औसत cohesion का α गुना। Safe load आम तौर पर ultimate ÷ 2.5 होता है, और उसकी पुष्टि Part 4 के अनुसार initial load test से करनी होती है। Friction piles की न्यूनतम केंद्र-से-केंद्र दूरी आम तौर पर pile व्यास का 2.5 गुना, और व्यवहार में 3 गुना आम है।",
    why: "Pile एक बार डल जाने के बाद दिखती नहीं, इसलिए code load testing पर बहुत भरोसा करता है। सिर्फ़ मिट्टी के parameters से निकली pile capacity एक अनुमान है; स्वीकृति load test ही है।",
    eg: "500 mm bored pile, 12 m लंबी, औसत cu = 50 kPa वाली clay में, α = 0.5: skin friction = 0.5 × 50 × π × 0.5 × 12 = 471 kN; end bearing = 9 × 50 × π/4 × 0.5² = 88 kN; ultimate ≈ 559 kN; safe ≈ 224 kN।",
    tip: "Negative skin friction — बैठती हुई भराई या consolidate होती clay से आने वाला down-drag — प्रतिरोध नहीं, अतिरिक्त load है। वह capacity में से घटती है और load में जुड़ती है, यानी दोहरा नुकसान करती है।",
  },

  "t-soiltests": {
    what: "IS 2720 श्रृंखला मिट्टी के मानक परीक्षण कवर करती है: water content (Part 2), specific gravity (Part 3), grain size (Part 4), liquid और plastic limits (Part 5), light व heavy compaction (Parts 7 और 8), unconfined compression (Part 10), triaxial (Part 11), direct shear (Part 13), consolidation (Part 15), CBR (Part 16), permeability (Part 17), और sand replacement व core cutter से field density (Parts 28 और 29)। Standard Penetration Test अलग से IS 2131 में है।",
    why: "हर foundation और pavement design का input इन्हीं में से किसी परीक्षण से आता है। कौन-सा Part कौन-सा parameter देता है — यह जान लेना आधा geotechnical viva जीत लेना है।",
    eg: "किसी सड़क परियोजना को subgrade CBR चाहिए — यानी IS 2720 Part 16, चार दिन soaked, और CBR 2.5 mm या 5 mm penetration पर जो ज़्यादा हो वह लिया जाता है।",
    tip: "Light compaction (Part 7, Standard Proctor) और heavy compaction (Part 8, Modified Proctor) एक ही मिट्टी के लिए अलग maximum dry density देते हैं। '95% of MDD' लिखी specification तब तक निरर्थक है जब तक यह न बताए कि कौन-सा परीक्षण।",
  },

  "t-brick": {
    what: "साधारण burnt clay bricks को उनकी औसत compressive strength (N/mm²) से पदनाम मिलता है, class 3.5 से शुरू। Modular ईंट का आकार 190 × 90 × 90 mm है, जो 10 mm mortar joint के साथ 200 × 100 × 100 mm बन जाता है। Water absorption — class 12.5 तक की साधारण ईंटों के लिए वज़न का अधिकतम 20% और उससे ऊँची classes के लिए 15%; और सामान्य काम के लिए efflorescence 'moderate' रेटिंग से ऊपर नहीं जानी चाहिए।",
    why: "ईंट की class IS 1905 में masonry की मूल compressive stress तय करती है, और water absorption यह तय करती है कि ईंट mortar से कितना पानी खींच लेगी — इसीलिए चिनाई से पहले ईंटें भिगोई जाती हैं।",
    eg: "Modular ईंटों से 1 m³ brickwork में 500 ईंटें लगती हैं: 1/(0.20 × 0.10 × 0.10) = 500, और बची हुई लगभग 0.23 m³ जगह mortar की।",
    tip: "ईंट की compressive strength पाँच नमूनों का औसत होती है, और कोई भी ईंट class strength के 80% से नीचे नहीं जा सकती। परीक्षण ईंट पर होता है, चिनाई पर नहीं — चिनाई की strength ईंट से कहीं कम होती है।",
  },

  "t-cbr": {
    what: "Flexible pavement की मोटाई design life में अपेक्षित standard axles की संचयी संख्या (million standard axles, msa) के लिए design होती है, जो शुरुआती commercial vehicle count, traffic growth rate, vehicle damage factor और lane distribution factor से निकलती है। Subgrade को उसकी चार-दिन soaked CBR से पहचाना जाता है, जिसे mechanistic विश्लेषण के लिए resilient modulus में बदला जाता है।",
    why: "msa और CBR — यही दो आँकड़े pavement की पूरी बनावट तय करते हैं। Catalogue में बाक़ी सब इन्हीं से निकलता है।",
    eg: "प्रतिदिन 1500 commercial vehicles, 6% growth, 15-वर्षीय design life, VDF 3.5, lane distribution 0.75: संचयी repetitions लगभग 30 msa बनते हैं, जो 7% CBR वाले subgrade के साथ design catalogue से bituminous और granular परतों की मोटाई तय कर देते हैं।",
    tip: "Design के लिए CBR सबसे ख़राब नमी की स्थिति वाला soaked मान होता है, उसी दिन जाँचे गए सूखे compacted नमूने का नहीं। Unsoaked CBR पर design करना आम और महँगी ग़लती है।",
  },

  "t-cubetest": {
    what: "Compressive strength 150 mm cubes पर निकाली जाती है (या जहाँ aggregate का आकार अनुमति दे वहाँ 100 mm cubes पर), जो तीन परतों में मानक compaction के साथ ढाले जाते हैं, 24 घंटे बाद साँचे से निकाले जाते हैं और परीक्षण तक पानी में cure होते हैं — आम तौर पर 7 और 28 दिन पर। Load स्थिर दर से failure तक लगाया जाता है, और एक test का परिणाम एक ही sample के तीन cubes का औसत होता है।",
    why: "Cube का परिणाम ही कंक्रीट की क़ानूनी स्वीकृति है। परीक्षण का हर पहलू — नमूने का आकार, curing, loading rate — इसीलिए मानकीकृत है क्योंकि यह आँकड़ा अनुबंध में इस्तेमाल होता है।",
    eg: "एक sample के तीन cubes 620, 640 और 660 kN पर fail होते हैं। Strengths हुईं 27.6, 28.4 और 29.3 N/mm², औसत 28.4 N/mm²। कोई cube औसत से 15% से ज़्यादा अलग नहीं, इसलिए test मान्य है।",
    tip: "OPC कंक्रीट में 7-दिन strength आम तौर पर 28-दिन strength की लगभग दो-तिहाई होती है — शुरुआती चेतावनी के लिए उपयोगी, पर यह स्वीकृति की कसौटी कभी नहीं।",
  },

  "t-cementtests": {
    what: "Standard consistency (Part 4) वह पानी की मात्रा है जिस पर Vicat plunger निर्धारित गहराई तक धँसता है। Setting times (Part 5) Vicat needle से नापे जाते हैं — ordinary Portland cement का initial setting time 30 मिनट से कम नहीं और final setting time 600 मिनट से ज़्यादा नहीं। Soundness (Part 3) Le Chatelier expansion से नापी जाती है, जिसकी सीमा 10 mm है, या autoclave test से।",
    why: "Initial setting time ही आपकी काम करने की खिड़की है — मिलाने, ले जाने, डालने और compact करने का उपलब्ध समय। Soundness मुक्त चूने या मैग्नीशिया से बचाती है, जो कंक्रीट के सख़्त होने के बहुत बाद फैलते हैं और उसे भीतर से तोड़ देते हैं।",
    eg: "25 मिनट के initial setting time वाला cement site पर अस्वीकार कर दिया जाएगा: slab को सख़्त होने से पहले डालने और compact करने का समय ही नहीं बचेगा।",
    tip: "Standard consistency अपने आप में कोई शर्त नहीं है — यह वह संदर्भ पानी-मात्रा है जिस पर setting time और soundness के परीक्षण चलाए जाते हैं, इसलिए इसे सबसे पहले निकालना पड़ता है।",
  },

  "t-levelling": {
    what: "Height of instrument विधि में instrument height = benchmark का reduced level + backsight, और हर दूसरा reduced level = instrument height − संबंधित intermediate या foresight reading। Rise and fall विधि में क्रमागत readings का अंतर निकालकर rise या fall मिलता है, जिसे पिछले reduced level पर लगाया जाता है।",
    why: "Levelling site का हर ऊर्ध्वाधर माप तय करती है — plinth level, invert level, formation level। यहाँ की ग़लती आगे की हर drawing में फैल जाती है।",
    eg: "BM का RL 100.000 m, backsight 1.250 → HI = 101.250। अगले बिंदु पर foresight 2.100 देने पर RL = 101.250 − 2.100 = 99.150 m।",
    tip: "दोनों विधियों की गणितीय जाँच अलग है: HI विधि में ΣBS − ΣFS = अंतिम RL − पहला RL। Rise and fall में ΣBS − ΣFS = Σrise − Σfall = अंतिम RL − पहला RL। Rise and fall हर बीच वाले बिंदु की भी जाँच कर लेती है, इसीलिए सटीक काम में यही पसंद की जाती है।",
  },

  "t-area": {
    what: "Offsets से क्षेत्रफल trapezoidal नियम या Simpson के नियम से निकाला जाता है — Simpson क्रमागत अंतराल-जोड़ों में एक परवलय बिठाता है और इसके लिए ordinates की संख्या विषम चाहिए। Coordinates से क्षेत्रफल cross-multiplication (shoelace) विधि से आता है। Earthwork के आयतन cross-sectional क्षेत्रफलों से trapezoidal या prismoidal सूत्र द्वारा निकाले जाते हैं।",
    why: "हर earthwork bill और हर plot area प्रमाणपत्र इन्हीं सूत्रों पर टिका है। लंबे embankment पर trapezoidal और prismoidal परिणामों का अंतर काफ़ी बड़ी मात्रा बन सकता है।",
    eg: "10 m अंतराल पर ordinates 2.0, 3.5, 4.2, 3.8, 2.5 m के साथ Simpson का नियम: क्षेत्रफल = (10/3)[2.0 + 2.5 + 4(3.5 + 3.8) + 2(4.2)] = (10/3)(4.5 + 29.2 + 8.4) = 140.3 m²।",
    tip: "Simpson के नियम को अंतरालों की सम संख्या चाहिए (यानी ordinates विषम)। अगर ordinates सम संख्या में हों, तो आख़िरी पट्टी छोड़कर बाक़ी पर Simpson और उस एक पट्टी पर trapezoidal नियम लगाएँ।",
  },

  "t-egress": {
    what: "NBC का Part 4 निकासी के साधनों की शर्तें तय करता है: occupant load के आधार पर exits की संख्या और चौड़ाई, संरक्षित exit तक अधिकतम travel distance (जो occupancy के अनुसार बदलती है — residential और office में आम तौर पर लगभग 30 m के क्रम में, और high hazard में इससे कम), सीढ़ी का enclosure, निकासी की दिशा में खुलने वाले दरवाज़े, तथा exit के संकेत और रोशनी।",
    why: "अग्नि सुरक्षा का design मूल रूप से समय का मामला है — लोगों के संरक्षित रास्ते तक पहुँचने का समय बनाम परिस्थितियों के असह्य हो जाने का समय। Travel distance उसी विचार को एक माप में बदल देती है।",
    eg: "300 occupant load वाली office मंज़िल में NBC के occupant load factor और unit exit width tables से निकाली गई exit चौड़ाइयाँ और कम से कम दो दूर-दूर exits चाहिए, और मंज़िल का कोई भी बिंदु सीढ़ी से अनुमत travel distance से ज़्यादा दूर न हो।",
    tip: "दो exits एक-दूसरे से दूर होने चाहिए — दोनों सीढ़ियाँ एक ही core में रख देने से एक ही आग दोनों रोक सकती है, जो गिनती तो पूरी कर देती है पर मक़सद ख़त्म कर देती है।",
  },

  "t-chloride": {
    what: "Cl. 8.2.5.2 कंक्रीट mix की कुल acid-soluble chloride मात्रा पर सीमा लगाता है, जिसमें हर सामग्री का योगदान गिना जाता है — cement, aggregate, पानी और admixture, सब मिलाकर। सीमाएँ प्रति घन मीटर कंक्रीट में chloride ion के किलोग्राम में हैं: prestressed कंक्रीट और embedded metal वाले heat-cured कंक्रीट के लिए 0.4; severe, very severe या extreme exposure में reinforced कंक्रीट के लिए 0.6; और mild या moderate exposure में reinforced कंक्रीट के लिए 3.0। Cl. 8.2.5.3 अलग से कुल water-soluble sulphate (SO₃ के रूप में) को mix के cement के द्रव्यमान का 4 प्रतिशत तक सीमित करता है।",
    why: "Reinforcement में जंग का सबसे आक्रामक कारण अकेले chloride ही है। यह उस passive परत को तोड़ देता है जो क्षारीय pore water bar पर बनाती है, और परत जाते ही bar जंग खाने लगती है — चाहे कंक्रीट ठोस और बिना carbonation वाला ही क्यों न हो। जंग अपने मूल steel से कई गुना जगह घेरती है, इसलिए पहला दिखने वाला लक्षण bar की रेखा के साथ एक crack होता है, फिर cover का उखड़ना। Sulphate सीधे सख़्त हो चुके paste पर हमला करता है और फैलने वाले यौगिक बना देता है।",
    eg: "बिना धुली समुद्री रेत भारतीय तट की क्लासिक विफलता है। वह अकेले ही इतना chloride ला सकती है कि severe-exposure संरचना की 0.6 kg/m³ सीमा पार हो जाए — और यही वह माहौल है जहाँ समुद्री रेत सबसे ज़्यादा ललचाती है। रेत की chloride मात्रा मान मत लीजिए, जाँच कराइए।",
    tip: "चूँकि सीमा कुल मात्रा पर है, इसलिए chloride वाला accelerating admixture reinforced काम में व्यावहारिक रूप से प्रतिबंधित है। हर सामग्री के test certificate पर chloride मात्रा माँगिए, सिर्फ़ पानी की नहीं।",
  },

  "t-batching": {
    what: "Cl. 10.2 के अनुसार कंक्रीट द्रव्यमान (mass) से batch होना चाहिए। अनुमत सहनशीलता — cement और पानी पर ±2 प्रतिशत, aggregates पर ±3 प्रतिशत। Volume batching सिर्फ़ nominal mix कंक्रीट के लिए और तभी मान्य है जब weigh-batching सचमुच अव्यावहारिक हो, और boxes ठीक एक बोरी cement के बराबर बने हों। Aggregate में पहले से मौजूद नमी और उसका bulking batching के समय नापकर समायोजित करना होगा। Cl. 10.3 के अनुसार मिलाना mechanical mixer में होगा, निर्माता की गति पर, जब तक रंग और consistency एक समान न हो जाए — और किसी भी हाल में दो मिनट से कम नहीं। जहाँ हाथ से मिलाने की विशेष अनुमति हो, वहाँ mix में 10 प्रतिशत अतिरिक्त cement देना होगा।",
    why: "आपकी हर strength की गणना एक water-cement ratio पर टिकी है। अगर पानी कोई नापता ही नहीं — या cement 'लगभग डेढ़ बोरी' से नापा जाता है — तो काग़ज़ पर लिखे ratio का truck के अंदर वाले ratio से कोई रिश्ता नहीं। Batching tolerance ही design और हक़ीक़त के बीच की कड़ी है, और सबसे सख़्त tolerance जान-बूझकर उन्हीं दो सामग्रियों पर रखी गई है जो ratio तय करती हैं।",
    eg: "w/c = 0.45 पर 350 kg cement वाले mix को 157.5 लीटर पानी चाहिए। अगर रेत 6 प्रतिशत गीली है और कोई उसे घटाता नहीं, तो 700 kg रेत वाला 1 m³ कंक्रीट लगभग 42 लीटर अतिरिक्त पानी ले आता है — असली w/c 0.57 हो जाता है और 28-दिन strength लगभग एक पूरे grade गिर जाती है।",
    tip: "नम रेत का bulking उसका आयतन 20–30 प्रतिशत तक बढ़ा देता है। Bulking test के बिना volume batching चुपचाप रेत कम कर देती है — इसीलिए volume-batched कंक्रीट अक्सर रूखा दिखता है और honeycomb करता है।",
  },

  "t-placing": {
    what: "Cl. 13.1 के अनुसार कंक्रीट ऐसे तरीक़े से ले जाया जाए कि segregation या सामग्री का नुकसान न हो, और उसे उसकी अंतिम जगह के जितना संभव हो उतना क़रीब डाला जाए — एक ढेर में गिराकर बग़ल में खींचकर नहीं। Cl. 13.2 कहता है कि इसे initial setting time बीतने से पहले डालकर compact कर लेना होगा, और उसके बाद हिलाना नहीं होगा। Cl. 13.3 पूरी तरह compaction माँगता है ताकि कंक्रीट reinforcement के चारों ओर और form के कोनों तक अधिकतम घनत्व तक पहुँचे — साथ ही over-vibration से चेताता है, जो mortar को ऊपर ले आता है और नीचे मोटा aggregate छोड़ देता है।",
    why: "Compaction सबसे सस्ती strength है जो आप कभी ख़रीदेंगे। लगभग 5 प्रतिशत फँसी हुई हवा compressive strength का लगभग 30 प्रतिशत खा जाती है, और वह हवा समान रूप से नहीं बँटती — वह ठीक वहीं जमा होती है जहाँ bars की भीड़ है और cover सबसे पतला। Honeycomb हुआ beam का soffit सौंदर्य की ख़राबी नहीं है; वह reinforcement का एक ऐसा हिस्सा है जिस पर cover ही नहीं, और वह भी उसी ज़ोन में जहाँ code ने पूरा bond मान रखा था।",
    eg: "घनी reinforcement वाले beam-column joint में 40 mm का needle vibrator bars के बीच से निकलेगा ही नहीं; इसका उत्तर छोटा needle और उस भीड़ के लिए design किया गया ज़्यादा workable mix है — pour के समय और पानी डालना नहीं। Site पर पानी डालना ही वह तरीक़ा है जिससे design का M30 बनकर M20 खड़ा होता है।",
    tip: "Needle को सीधा रखें, तेज़ी से डालें और धीरे निकालें, और उसके प्रभाव-क्षेत्र को ओवरलैप करें। जब सतह चमकने लगे और हवा के बुलबुले उठना बंद हो जाएँ, तब रोक दें — उससे आगे चलाना over-vibration है, अतिरिक्त सुरक्षा नहीं।",
  },

  "t-assessment": {
    what: "Cl. 17 वही है जहाँ आप तब जाते हैं जब cubes fail हो गए हों या किसी member का कंक्रीट संदेह में हो। दो रास्ते दिए गए हैं। Core test में कंक्रीट तब स्वीकार होता है जब cores की औसत equivalent cube strength निर्दिष्ट grade की कम से कम 85 प्रतिशत हो और कोई भी individual core 75 प्रतिशत से नीचे न गिरे। Flexural member के load test में member पर पूरा dead load और imposed load का 1.25 गुना लगाकर 24 घंटे रखा जाता है। परीक्षण के दौरान अधिकतम deflection 40 l²/D मिलीमीटर से ज़्यादा नहीं होनी चाहिए (l metre में, D overall depth मिलीमीटर में), और load हटाने के 24 घंटे के भीतर कम से कम 75 प्रतिशत deflection वापस आनी चाहिए; न आए तो परीक्षण एक बार दोहराया जा सकता है, और दोहराने के बाद recovery कम से कम 80 प्रतिशत होनी चाहिए।",
    why: "एक fail हुआ cube पूरी संरचना को दोषी नहीं ठहराता — वह उस कंक्रीट पर सवाल उठाता है जो सचमुच member में है, और Cl. 17 उसी का जवाब देता है। स्वीकृति के दोनों आँकड़े जान-बूझकर निर्दिष्ट grade से नीचे रखे गए हैं: core ड्रिल किया, काटा और अनिवार्य रूप से क्षतिग्रस्त होता है, और in-situ कंक्रीट lab के cube जितनी अच्छी तरह compact और cure नहीं होता — इसलिए core से पूरा grade माँगना अच्छे काम को भी दोषी ठहरा देगा।",
    eg: "M25 निर्दिष्ट है, एक slab संदेह में। Cores की औसत equivalent cube strength कम से कम 21.25 N/mm² होनी चाहिए और कोई भी core 18.75 N/mm² से नीचे नहीं। 150 mm गहरे, 4 m simply supported slab के load test में deflection की सीमा = 40 × 4²/150 = 4.27 mm।",
    tip: "Cores bars से दूर और member के किनारों से दूर लिए जाते हैं, और परिणाम को equivalent cube strength कहने से पहले length-to-diameter अनुपात तथा ड्रिलिंग की दिशा के लिए सुधारा जाता है। कच्ची core reading की सीधी तुलना cube के परिणाम से मत कीजिए।",
  },

  "t-designmethod": {
    what: "Cl. 18.2 उन विधियों के नाम देता है जिन्हें code मान्यता देता है। Section 5 की limit state विधि सामान्य रास्ता है और बाक़ी पूरा code उसी के इर्द-गिर्द लिखा गया है। Working stress विधि Annex B में रखी गई है और वहाँ मान्य है जहाँ limit state विधि सुविधाजनक रूप से अपनाई न जा सके। प्रायोगिक जाँच की सहायता से design भी मान्य है, बशर्ते इंजीनियर की स्वीकृति हो। Section 5 फिर limit states को बाँटता है — collapse (flexure, compression, shear और torsion) और serviceability (मुख्यतः deflection और cracking)।",
    why: "दोनों विधियाँ safety factor को उल्टे नज़रिये से देखती हैं। Working stress सामग्री को उसकी elastic सीमा में रखती है और stress पर एक ही factor of safety लगाती है, जिससे collapse पर आने वाला load अज्ञात रह जाता है। Limit state loads और materials पर अलग-अलग partial factors लगाती है, इसलिए संरचना उसी अवस्था पर जाँची जाती है जिसकी सचमुच चिंता है — collapse — और अलग से उस अवस्था पर भी जो उपयोगकर्ता को दिखती है — deflection और cracking।",
    eg: "एक ही beam दोनों विधियों से design करने पर एक जैसी नहीं निकलेगी। Limit state आम तौर पर flexure के लिए कम steel देती है क्योंकि वह section की पूरी plastic capacity इस्तेमाल करती है, जबकि water-retaining संरचनाओं में अक्सर आज भी working stress ही निर्दिष्ट होती है, जहाँ कंक्रीट को कम-stress और बिना crack वाली अवस्था में रखना ही पूरा मक़सद है।",
    tip: "दोनों विधियाँ एक ही गणना के भीतर मिलाई नहीं जानी चाहिए। या तो limit state से design करके Annex F से crack width जाँचें, या पूरे काम में working stress चलाएँ — एक से load factor और दूसरी से permissible stress कभी न उठाएँ।",
  },

  "t-momentcoeff": {
    what: "Cl. 22.5 आपको continuous beam या one-way slab के लिए पूरा frame विश्लेषण छोड़कर moments और shears दो tables से पढ़ने देता है। Table 12 bending moment coefficients देता है — end span के बीच के पास dead load moment का 1/12 और imposed load moment का 1/10; interior span के बीच में 1/16 और 1/12; end support से लगे support पर 1/10 और 1/9 hogging; बाक़ी interior supports पर 1/12 और 1/9। Table 13 shear coefficients देता है, end support पर dead load के 0.4 से लेकर पहले interior support पर 0.6 तक। Moment = coefficient × span पर कुल load × effective span। ये tables तभी इस्तेमाल हो सकती हैं जब loading तीन या ज़्यादा spans पर लगभग समान हो और spans सबसे लंबे के 15 प्रतिशत से ज़्यादा अलग न हों।",
    why: "यह एक redundant संरचना को दो table lookups में बदल देता है — बराबर bays वाली सामान्य मंज़िल के लिए और model बनाने से पहले के sketch design के लिए बिल्कुल यही चाहिए। इन coefficients में pattern loading का थोड़ा भत्ता पहले से शामिल है, इसलिए end span समान रूप से भरी beam के सीधे elastic विश्लेषण से बुरा निकलता है।",
    eg: "चार बराबर 5 m spans, dead load 20 kN/m, imposed 12 kN/m। End span का sagging moment = 20 × 5 × 5/12 + 12 × 5 × 5/10 = 41.7 + 30 = 71.7 kN·m। पहला interior support = 20 × 5 × 5/10 + 12 × 5 × 5/9 = 50 + 33.3 = 83.3 kN·m hogging।",
    tip: "दो फंदे। Table उठाने से पहले 15 प्रतिशत वाला span नियम जाँच लें — एक span लंबा हुआ और coefficients अमान्य। और याद रखें कि इन coefficients से निकले moments पर code redistribution की अनुमति नहीं देता; उनमें अपना भत्ता पहले से है।",
  },

  "t-slabtypes": {
    what: "चारों तरफ़ से टिका slab दोनों दिशाओं में span करता है, पर panel जितना लंबा होता जाता है, छोटा span लगभग पूरा load ले लेता है। Code की विभाजक रेखा है लंबे effective span और छोटे का अनुपात: 2 से ऊपर slab one-way design होता है — छोटी दिशा में span करता हुआ, लंबी दिशा में distribution steel के साथ; 2 या उससे कम पर two-way। Two-way slabs के लिए Annex D moment coefficients αx और αy देता है — restrained slabs के लिए Table 26, जो edge continuity के नौ मामले कवर करती है, और चारों तरफ़ simply supported slabs के लिए Table 27, जहाँ corner lift रोकने का कोई प्रबंध नहीं। हर दिशा का moment α w lx² होता है, और हमेशा छोटा effective span ही लिया जाता है। जिन restrained panels के कोने नीचे बाँधे गए हैं, उनमें Cl. D-1.8 की torsion reinforcement भी कोनों पर चाहिए।",
    why: "यह ग़लत होना दोनों तरफ़ महँगा है। सचमुच two-way panel को one-way design करना लगभग एक-तिहाई steel बरबाद करता है; 2.5:1 वाले panel को two-way design करने पर छोटा span कम reinforced रह जाता है, क्योंकि वह जिस long-span coefficient पर भरोसा कर रहा है वह लगभग शून्य है। कोने का steel भी मायने रखता है — नीचे बाँधा गया पर बिना reinforcement वाला कोना ऊपरी सतह पर तिरछा crack करता है।",
    eg: "4 m × 6 m panel में ly/lx = 1.5, इसलिए two-way। 3 m × 7 m panel का अनुपात 2.33 है, इसलिए वह 3 m span करता one-way design होगा, और 7 m दिशा में distribution steel विश्लेषण से नहीं बल्कि न्यूनतम reinforcement नियम से तय होगा।",
    tip: "Moment हमेशा α w lx² है — छोटे span का वर्ग, दोनों दिशाओं में। αy w ly² लिख देना two-way slab के सवालों की सबसे आम ग़लती है और लंबे span का moment बेतहाशा बड़ा कर देती है।",
  },

  "t-efflength": {
    what: "Effective length उस समतुल्य pin-ended column की लंबाई है जो उसी load पर buckle होता, यानी यह असली सिरा-स्थितियों को एक ही आँकड़े में बदल देती है। Cl. 25.2 और Table 28 सिरा-स्थिति के अनुसार मान देते हैं: braced frame में — दोनों सिरे जगह पर टिके और rotation से रुके हों तो 0.65 l, सिर्फ़ एक सिरा rotation से रुका हो तो 0.80 l, और कोई न रुका हो तो 1.00 l; unbraced frame में उन्हीं स्थितियों के लिए 1.20 l, 1.50 l और 2.00 l — आख़िरी यानी स्वतंत्र खड़ा cantilever column। Annex E ऐसे charts देता है जो हर joint पर मिल रही beams और columns की सापेक्ष कठोरता β से effective length पढ़ लेते हैं, और जहाँ आदर्श मामले फिट न बैठें वहाँ यही इस्तेमाल होता है।",
    why: "Column के slenderness का सब कुछ इसी एक आँकड़े से निकलता है। वही 3 m column braced frame में 0.65 × 3 = 1.95 m पर short है और cantilever के रूप में 2 × 3 = 6 m पर slender — और दूसरे को वे अतिरिक्त moments चाहिए जो पहले को नहीं। यह भी ध्यान दें कि अनुशंसित मान सैद्धांतिक मानों से ज़्यादा conservative हैं — code किसी असली joint को पूरी तरह fixed मानता ही नहीं।",
    eg: "3.5 m storey-height का column, shear walls से braced, ऊपर-नीचे beams में monolithic: lex = 0.65 × 3.5 = 2.275 m। 450 mm depth के सामने lex/D = 5.06, आराम से short। उसी column का ऊपरी सिरा मुक्त कर दें — जैसे canopy उठाता column — तो lex = 7 m, lex/D = 15.6, अब slender और अतिरिक्त moments की ज़रूरत।",
    tip: "'Braced' सवाल frame के बारे में है, column के बारे में नहीं: क्या कोई shear wall, core या bracing lateral load उठा रहा है? अगर frame को ख़ुद sway रोकना है, तो उसका हर column unbraced है — चाहे वह कितना ही मज़बूत दिखे।",
  },

  "t-slenderness": {
    what: "Cl. 25.1.2 किसी compression member को short कहता है जब lex/D और ley/b दोनों 12 से कम हों; इनमें से कोई भी 12 पार कर जाए तो column slender है और उसे buckling से आने वाले अतिरिक्त moments के लिए design करना होगा। Cl. 25.3 गणना से अलग, ज्यामिति पर पक्की सीमाएँ भी लगाता है: restraints के बीच unsupported length सबसे छोटे lateral माप के 60 गुना से ज़्यादा नहीं, और जहाँ column का एक सिरा unrestrained हो वहाँ unsupported length 100 b²/D से ज़्यादा नहीं — जिसमें b चौड़ाई और D गहराई है।",
    why: "Short column crushing से fail होता है, जो सामग्री की समस्या है और axial सूत्र उसे सँभाल लेता है। Slender column buckling से fail होता है, जहाँ lateral deflection ख़ुद अतिरिक्त moment पैदा कर देती है — एक second-order प्रभाव, जिसकी सरल सूत्र को ख़बर तक नहीं। 60 b और 100 b²/D की सीमाएँ इसलिए हैं कि उनसे आगे buckling की गणना भरोसेमंद रह ही नहीं जाती, इसलिए code गणना करने की कोशिश करने के बजाय उस ज्यामिति को ही मना कर देता है।",
    eg: "230 × 450 का column, lex = 3.0 m और ley = 3.0 m: lex/D = 3000/450 = 6.7, ley/b = 3000/230 = 13.0। एक अनुपात 12 पार कर रहा है, इसलिए column अपने minor axis के बारे में slender है और उस दिशा में Cl. 39.7 का अतिरिक्त moment चाहिए — भले ही major axis के बारे में वह short है।",
    tip: "दोनों दिशाएँ हमेशा अलग-अलग जाँचें — rectangular column आम तौर पर एक तरफ़ short और दूसरी तरफ़ slender होता है, और चलती कमज़ोर दिशा ही है। अतिरिक्त moment Max = Pu D (lex/D)²/2000 है, जो slenderness के वर्ग के साथ बढ़ता है।",
  },

  "t-mineccentricity": {
    what: "Cl. 25.4 हर column को न्यूनतम eccentricity के लिए design करने को कहता है — unsupported length ÷ 500 + lateral माप ÷ 30, और कम से कम 20 मिलीमीटर। यह जाँच हर principal axis के बारे में अलग से होती है। Code इसी तरीक़े से कहता है कि सचमुच का axially loaded column होता ही नहीं — निर्माण की tolerances, थोड़ी हटकर बैठी beam की reaction और कंक्रीट में अपरिहार्य विविधता, ये सब कुछ न कुछ eccentricity पक्की कर देते हैं।",
    why: "यही पूरी column design प्रक्रिया का द्वार है। Cl. 39.3 सरल axial capacity सूत्र की अनुमति तभी देता है जब न्यूनतम eccentricity किसी भी दिशा में lateral माप के 0.05 गुना से ज़्यादा न हो। उससे ऊपर जाते ही column को axial load और moment दोनों के लिए interaction chart से design करना होगा — जो पूरी तरह अलग गणना है।",
    eg: "300 × 450 का column, unsupported length 3 m। 450 mm अक्ष के बारे में: 3000/500 + 450/30 = 21 mm, और 0.05 × 450 = 22.5 mm — यानी axial सूत्र अब भी मान्य। 300 mm अक्ष के बारे में: 3000/500 + 300/30 = 16 mm, जो 20 mm की न्यूनतम सीमा तक बढ़ जाता है, जबकि 0.05 × 300 = 15 mm — अब eccentricity सीमा पार कर गई और उस दिशा को moment के साथ design करना होगा।",
    tip: "20 mm की न्यूनतम सीमा छोटे और पतले columns को पकड़ती है और आसानी से भूल जाती है। दोनों पद निकालें, परिणाम और 20 mm में जो बड़ा हो वह लें, और तभी उसकी तुलना 0.05 D से करें।",
  },

  "t-footing": {
    what: "Cl. 34 तीन जाँचें तय करता है जो isolated footing की गहराई तय करती हैं, और हर जाँच का अपना critical section है। Bending moment कंक्रीट के column या pedestal के फलक पर लिया जाता है। One-way shear column के फलक से d दूरी पर एक ऊर्ध्वाधर section पर, footing की पूरी चौड़ाई में जाँची जाती है, और प्रतिरोध साधारण design shear strength τc है। Two-way यानी punching shear column के फलक से चारों ओर d/2 पर बनी परिधि पर जाँची जाती है, और Cl. 31.6.3 से अनुमत stress ks × 0.25 √fck है, जहाँ ks = 0.5 + βc पर 1 से ज़्यादा नहीं, और βc column की छोटी भुजा और लंबी भुजा का अनुपात। मिट्टी पर टिकी footing के किनारे की मोटाई कम से कम 150 mm, और pile cap में piles के शीर्ष से ऊपर कम से कम 300 mm। Cl. 34.4 column से footing में load के स्थानांतरण को देखता है, जहाँ अनुमत bearing stress को √(A1/A2) गुणक से बढ़ाया जा सकता है, पर 2 से ज़्यादा नहीं।",
    why: "Footing में stirrups नहीं होते, इसलिए उसकी पूरी shear capacity सादा कंक्रीट का section ही है — यही कारण है कि गहराई लगभग हमेशा shear तय करती है, flexure नहीं। दोनों shear जाँचें दो अलग failure आकृतियाँ देखती हैं: one-way shear पूरी footing के आर-पार beam जैसी तिरछी crack है, जबकि punching में column एक कटा हुआ पिरामिड सीधे slab से पार धकेल देता है। वर्गाकार column के नीचे वर्गाकार footing में लगभग हमेशा punching ही चलता है।",
    eg: "2.5 m वर्गाकार footing, 450 mm गहरी, effective depth 400 mm, 400 mm वर्गाकार column के नीचे, M25 कंक्रीट। One-way shear column के फलक से 400 mm पर जाँची जाती है; punching 400 + 400 = 800 mm भुजा वाली वर्गाकार परिधि पर। βc = 1 होने से ks = 0.5 + 1 = 1.5, जो 1 पर सीमित हो जाता है, इसलिए अनुमत punching stress = 0.25 √25 = 1.25 N/mm²।",
    tip: "Rectangular two-way footing में छोटी दिशा का reinforcement समान रूप से नहीं फैलाया जाता। footing की छोटी भुजा जितनी चौड़ी एक केंद्रीय पट्टी उस दिशा के कुल steel का 2/(β + 1) भाग उठाती है, जहाँ β लंबी और छोटी भुजा का अनुपात है — बाक़ी steel दोनों बाहरी हिस्सों में बाँटा जाता है।",
  },

  "t-columndesign": {
    what: "Cl. 39 compression के प्रावधान देता है। जिस short column में न्यूनतम eccentricity दोनों दिशाओं में 0.05 D के भीतर हो, उसकी axial capacity 0.4 fck Ac + 0.67 fy Asc है। Cl. 39.4.1 की आयतन शर्त पूरी करने वाली helical reinforcement वाले column को उससे 1.05 गुना strength मिलती है, क्योंकि helix core को confine करके cover उखड़ने के बाद भी load उठाते रहने देती है। जहाँ moment मौजूद हो, वहाँ section को Pu/fck b D और Mu/fck b D² को जोड़ने वाले interaction diagram से design किया जाता है, और जहाँ moments दोनों अक्षों के बारे में लगें वहाँ Cl. 39.6 एक interaction जाँच देता है जिसका घातांक αn axial load और शुद्ध axial capacity के अनुपात पर निर्भर है। Slender column में Cl. 39.7 हर उस अक्ष के बारे में Pu D (lex/D)²/2000 का अतिरिक्त moment जोड़ता है जिसमें column slender है।",
    why: "0.4 और 0.67 वे सामान्य 0.446 fck और 0.87 fy नहीं हैं जो flexure में दिखते हैं, और इसकी वजह न्यूनतम eccentricity है। Code ने 0.05 D की आकस्मिक eccentricity का भत्ता पहले ही इन गुणांकों में सोख लिया है — ठीक इसीलिए यह सूत्र तभी तक इस्तेमाल हो सकता है जब असली eccentricity उस आँकड़े के भीतर रहे।",
    eg: "300 × 450 का M25 column, 20 mm की छह Fe 500 bars: Asc = 1885 mm², Ac = 133115 mm², इसलिए Pu = 0.4 × 25 × 133115 + 0.67 × 500 × 1885 ≈ 1962 kN। Moment जोड़ते ही capacity interaction curve के साथ गिरने लगती है — balanced failure पर column इससे कहीं कम axial load उठाता है।",
    tip: "Spiral वाला 1.05 का बोनस असली है पर शर्तों के साथ: helix को आयतन नियम पूरा करना होगा, मोटे तौर पर यह कि प्रति इकाई लंबाई helical reinforcement का आयतन core के आयतन का कम से कम 0.36 (Ag/Ac − 1) fck/fy गुना हो। नाममात्र का spiral कुछ नहीं कमाता।",
  },

  "t-torsion": {
    what: "IS 456 torsion के लिए सीधे design नहीं करता; Cl. 41 torsion को एक equivalent shear और एक equivalent moment में बदलकर फिर साधारण shear और flexure के प्रावधान चलाता है। Equivalent shear Ve = Vu + 1.6 Tu/b है, और section को Ve के लिए ठीक वैसे ही जाँचा जाता है जैसे Vu के लिए। Equivalent moment Mt = Tu (1 + D/b)/1.7 है, जिसे bending moment में जोड़कर tension steel के लिए Me1 = Mu + Mt मिलता है; जहाँ Mt, Mu से ज़्यादा हो वहाँ बचे हुए Mt − Mu को उल्टे चिह्न का moment मानकर design किया जाता है, यानी flexural compression फलक पर भी longitudinal steel चाहिए। Torsion का transverse reinforcement बाहरी कोनों के चारों ओर लगी बंद stirrups होनी चाहिए, और Cl. 26.5.1.7 परिधि पर बाँटी गई longitudinal bars माँगता है, साथ ही 450 mm से गहरे webs पर side face reinforcement।",
    why: "Torsion member की पूरी सतह पर एक सर्पिल tension क्षेत्र बना देता है — इसीलिए खुली stirrups उसके ख़िलाफ़ बेकार हैं, क्योंकि tension को पूरे section के चारों ओर घूमकर उठाना पड़ता है। और चूँकि torsion की shear stress beam के एक फलक पर ऊर्ध्वाधर shear की stress में जुड़ती है और दूसरे पर घटती है, इसलिए दोनों को एक equivalent shear में मिला देना code का conservative तरीक़ा है — ख़राब वाले फलक के लिए design कर लेने का।",
    eg: "300 × 500 की spandrel beam, Vu = 80 kN और Tu = 20 kN·m: Ve = 80 + 1.6 × 20/0.3 = 186.7 kN — अकेली ऊर्ध्वाधर shear से दोगुने से भी ज़्यादा। Mt = 20 (1 + 500/300)/1.7 = 31.4 kN·m, इसलिए Mu = 90 kN·m वाली beam को 121.4 kN·m के लिए reinforced किया जाता है।",
    tip: "Equilibrium torsion और compatibility torsion का फ़र्क़ समझें। Cantilever slab उठाती edge beam को अपना torsion खड़े रहने के लिए ही चाहिए, इसलिए उसे पूरा design करना होगा; जो torsion सिर्फ़ इसलिए पैदा होता है कि frame monolithic है, वह crack होकर ख़ुद को काफ़ी हद तक छोड़ देता है, और code के अपने detailing नियम उसे सँभाल लेते हैं।",
  },

  "t-deflection": {
    what: "Cl. 42 दो सीमाएँ तय करता है। किसी क्षैतिज member की अंतिम deflection, उसके supports के स्तर से नीचे, तापमान, creep और shrinkage के प्रभाव सहित और ढलाई के समय की आकृति से नापी गई, span ÷ 250 से ज़्यादा नहीं होनी चाहिए। अलग से, partitions और finishes बन जाने के बाद होने वाली deflection — फिर से creep, shrinkage और तापमान सहित — span ÷ 350 या 20 मिलीमीटर, जो कम हो, से ज़्यादा नहीं होनी चाहिए। Cl. 23.2 आपको बिना गणना के इन सीमाओं को पूरा करने देता है, बस संशोधित span से effective depth अनुपातों के भीतर रहकर। जहाँ सचमुच आँकड़े चाहिए वहाँ Annex C गणना का रास्ता देता है: short-term deflection cracked और gross मानों के बीच का effective moment of inertia इस्तेमाल करती है, जिसमें cracking moment 0.7 √fck की flexural tensile strength से निकलता है, और creep के लिए effective modulus तथा shrinkage curvature के लिए अलग पद जोड़े जाते हैं।",
    why: "दो सीमाएँ इसलिए हैं क्योंकि शिकायत करने वाले दो अलग लोग हैं। span/250 वाली सीमा संरचना की अपनी शक्ल और काम के बारे में है — छत पर पानी जमा होना, दरवाज़े का बंद न होना। span/350-या-20 mm वाली सीमा बाद में बनी हर चीज़ की रक्षा करती है: भुरभुरे partitions, glazing और पत्थर की cladding हैरान कर देने वाली छोटी हरकत पर चटक जाते हैं, और उन्हें सिर्फ़ इस बात से मतलब है कि उनके लगने के बाद क्या हुआ — पहले से मौजूद झुकाव से नहीं।",
    eg: "6 m span का slab: कुल सीमा 6000/250 = 24 mm, और निर्माण-पश्चात सीमा 6000/350 = 17.1 mm और 20 mm में जो कम हो, यानी 17.1 mm। ध्यान दें कि span 7 m के पार जाते ही अनुपात की जगह 20 mm की छत चलने लगती है।",
    tip: "परीक्षा में लगभग हमेशा Cl. 23.2 वाला रास्ता ही अपेक्षित होता है — cantilever, simply supported और continuous के लिए मूल अनुपात 7, 20 या 26, और उन पर tension steel, compression steel तथा flanged sections के modification factors। Annex C तब के लिए है जब span/depth जाँच fail हो जाए और आपको साबित करना हो कि slab सचमुच स्वीकार्य है।",
  },

  "t-800-lsd": {
    what: "2007 के revision ने भारत में steel design का आधार ही बदल दिया। IS 800:1984 working stress code था; IS 800:2007 limit state विधि को मुख्य विधि बनाता है और working stress design को Section 11 में विकल्प के रूप में रखता है। Section 5 ढाँचा तय करता है: design action = characteristic load × partial safety factor γf (जो load combination पर निर्भर है), और design strength = characteristic strength ÷ partial safety factor γm — yielding से तय होने वाले प्रतिरोध के लिए 1.10, ultimate stress से तय होने वाले के लिए 1.25, और bolts व welds के लिए अलग मान। Strength के limit states में yielding, rupture, buckling, stability, fatigue और brittle fracture आते हैं, और serviceability के limit states में deflection, vibration, corrosion तथा fire।",
    why: "यही वह दरार है जो पुरानी पाठ्यपुस्तक और मौजूदा पाठ्यपुस्तक को अलग करती है। Permissible-stress सूत्र, modular ratio वाला तरीक़ा और 1984 की tables अब IS 800:2007 की गणना में नहीं चलतीं, और इस बदलाव ने वे विचार भी लाए जो पुराने code में थे ही नहीं — section classification, block shear, buckling curve विधि से lateral torsional buckling, और समीकरण के दोनों तरफ़ स्पष्ट partial factors।",
    eg: "एक ही tension member दोनों तरीक़ों से: 1984 वाला रास्ता gross area पर 0.6 fy की permissible stress देता था; 2007 वाला रास्ता तीन अलग जाँचें माँगता है — gross section का yielding, net section की rupture अपने γm1 = 1.25 के साथ, और block shear — और तीनों में सबसे छोटी चलती है। अक्सर rupture वाली जाँच ही member तय करती है, और पुराना code उसे स्पष्ट रूप से माँगता ही नहीं था।",
    tip: "दोनों partial safety factors ही जाँचों के दो परिवारों को पहचानने का सबसे तेज़ तरीक़ा हैं। γm0 = 1.10 gross section के yielding के साथ जाता है; γm1 = 1.25 उस हर चीज़ के साथ जो ultimate stress पर fail होती है — net section rupture, block shear, bolts और welds।",
  },

  "t-800-materials": {
    what: "Section 2 बताता है कि बाक़ी पूरा code सामग्री के बारे में क्या मान रहा है। Structural steel IS 2062 के अनुसार होगा, जिसका पदनाम E के बाद yield stress N/mm² में — E 250, E 275, E 300, E 350, E 410, E 450 — और हर एक के साथ उसका ultimate stress fu। Table में दी गई yield stress plate के मोटे होने पर थोड़ी गिरती है, इसलिए fy को असल में इस्तेमाल हो रही मोटाई के लिए ही पढ़ना होगा। Elastic स्थिरांक हर grade के लिए एक ही हैं: modulus of elasticity 2.0 × 10⁵ N/mm², shear modulus 0.769 × 10⁵ N/mm², Poisson's ratio 0.3, coefficient of thermal expansion 12 × 10⁻⁶ प्रति °C और unit mass 7850 kg/m³। Section 2 bolts, nuts, washers और welding consumables को भी कवर करता है — हर एक अपने अलग मानक के अनुसार।",
    why: "Steel design में यह बात असामान्य है कि grade बढ़ाने से कठोरता नहीं बढ़ती — E 410, E 250 से कठोर नहीं है, सिर्फ़ मज़बूत है। हर deflection, हर buckling गणना और हर lateral torsional buckling जाँच उसी एक E पर चलती है। इसलिए grade ऊपर ले जाने से सिर्फ़ ताक़त मिलती है, और कुछ नहीं — और जिस लंबे span वाली beam में deflection चलती हो, वहाँ तो कुछ भी नहीं मिलता।",
    eg: "span/depth की deflection सीमा से तय होने वाली 12 m की purlin E 350 लिखकर हल्की नहीं की जा सकती — section वही रहेगा क्योंकि E नहीं बदला। पर छोटा भारी load वाला column या tension member, जो ताक़त से तय होते हैं, ज़रूर हल्के हो जाएँगे।",
    tip: "IS 2062 के साथ एक sub-grade अक्षर (A, BR, B0, C) भी आता है जो impact toughness तय करता है। Dynamic या कम तापमान वाले load उठाने वाले members में, या मोटी welded plates में, sub-grade उतना ही मायने रखता है जितना E का आँकड़ा — brittle fracture से वही बचाता है।",
  },

  "t-800-class": {
    what: "IS 800 में कोई भी strength निकालने से पहले section को वर्गीकृत करना पड़ता है। Class 1 (plastic) sections plastic hinge बना सकते हैं और plastic विश्लेषण लायक घूम सकते हैं। Class 2 (compact) पूरा plastic moment विकसित कर सकते हैं पर घूमने की क्षमता सीमित है। Class 3 (semi-compact) बाहरी fibre पर yield तक पहुँच सकते हैं पर local buckling उन्हें plastic moment से पहले रोक देती है। Class 4 (slender) yield से पहले ही locally buckle हो जाते हैं और घटे हुए effective cross section पर design होते हैं। Class हर plate element के width-to-thickness अनुपात से तय होता है, जिसे Table 2 की उन सीमाओं से जाँचा जाता है जो सभी ε = √(250/fy) के गुणज हैं; section को उसके किसी भी element का सबसे प्रतिकूल class मिलता है।",
    why: "यह वह द्वार है जिससे आगे की हर गणना गुज़रती है। Design bending strength βb Zp fy/γm0 है, जिसमें Class 1 और 2 के लिए βb = 1 पर Class 3 के लिए βb = Ze/Zp — यानी अकेला वर्गीकरण ही moment capacity दस से बीस प्रतिशत बदल देता है। Plastic विश्लेषण सिर्फ़ Class 1 sections के लिए मान्य है। और Class 4 section अपना पूरा क्षेत्रफल इस्तेमाल कर ही नहीं सकता — पहले effective section निकालना पड़ता है।",
    eg: "E 250 में ISMB 300: flange outstand b = (140 − 7.5)/2 = 66.25 mm और tf = 12.4 mm, इसलिए b/tf = 5.3 — 9.4 ε की plastic सीमा के अच्छे-ख़ासे भीतर। वही आकार E 350 में rolled हो तो ε = 0.845 और plastic सीमा गिरकर 7.9 हो जाती है — तब भी पूरी होती है, पर पतले flanges वाला welded plate girder नहीं कर पाता।",
    tip: "Flange और web अलग-अलग जाँचें और जो बुरा निकले वही लें। व्यवहार में भारतीय rolled sections लगभग हमेशा Class 1 या 2 होते हैं; Class 3 और 4 में welded plate girders और cold-formed sections गिरते हैं।",
  },

  "t-800-shear": {
    what: "Cl. 8.4 design shear strength Vd = Vn/γm0 देता है, जिसमें γm0 = 1.10 और nominal plastic shear resistance Vn = Av fyw/√3 — यह √3 सीधे von Mises कसौटी से आता है, जो shear yield को tensile yield के 1/√3 पर रखती है। Shear area Av आकार पर निर्भर है: major axis के बारे में मुड़े hot-rolled I-section या channel में, जहाँ load web के समांतर हो, यह overall depth × web thickness है; welded section में clear web depth × web thickness; अपनी गहराई के समांतर load वाले rectangular hollow section में A h/(b + h); circular hollow section में 2A/π; और plates व ठोस bars में पूरा क्षेत्रफल। जहाँ web पतला हो — code की सीमा unstiffened web के लिए depth-to-thickness अनुपात 67 ε से ज़्यादा — वहाँ web yield होने से पहले shear में buckle कर सकता है, इसलिए shear buckling जाँचनी होगी, या तो सरल post-critical विधि से या tension field विधि से।",
    why: "Rolled beam में shear शायद ही कभी चलती है, क्योंकि web मोटा होता है और section moment के लिए चुना गया था। यह ठीक उन्हीं मामलों में चलती है जिन्हें छात्र कम आँकते हैं: छोटे पर भारी load वाले spans, बड़े web openings वाली beams, और plate girders — जहाँ वज़न बचाने के लिए web जितना पतला हो सके बनाया जाता है और फिर वह पूरी तरह stiffeners के भरोसे जीता है।",
    eg: "E 250 में ISMB 400: Av = 400 × 8.9 = 3560 mm², Vn = 3560 × 250/√3 = 513.8 kN, Vd = 467 kN। d/tw की तुलना 67 ε = 67 से करें: लगभग 341 mm clear web depth और tw = 8.9 mm पर d/tw = 38 — काफ़ी नीचे, इसलिए shear buckling जाँचने की ज़रूरत नहीं।",
    tip: "ऊँची shear से सावधान। जब साथ चल रही shear 0.6 Vd पार कर जाए, तो Cl. 9.2 moment capacity घटाने को कहता है — क्योंकि web का एक हिस्सा पहले ही shear उठाने में लगा है और वह साथ-साथ flexural stress नहीं उठा सकता।",
  },

  "t-800-combined": {
    what: "Section 9 उन members को सँभालता है जो एक साथ एक से ज़्यादा action उठाते हैं। Cl. 9.2 shear और bending के मेल को देखता है: जब तक shear 0.6 Vd या उससे नीचे है, पूरी moment capacity उपलब्ध है; उससे ऊपर design moment capacity एक ऐसे गुणक से घटा दी जाती है जो लगी हुई shear और design shear के अनुपात से बनता है। Cl. 9.3 axial force और bending के मेल को देखता है और दो अलग जाँचें माँगता है। Cl. 9.3.1 की section strength जाँच पूछती है कि cross section यह संयोजन उठा भी सकता है या नहीं, और इसमें ऐसा interaction व्यंजक चलता है जिसमें axial load की मौजूदगी के कारण moment capacity घटा दी जाती है। फिर Cl. 9.3.2 की overall member strength जाँच पूछती है कि member इसे buckle हुए बिना उठा सकता है या नहीं — जिसमें axial पद के साथ दोनों अक्षों के बढ़े हुए bending पद और एक lateral torsional buckling पद जुड़ते हैं।",
    why: "असल में लगभग हर column एक beam-column है। वह ऊपर की मंज़िलों से axial load उठाता है और उसमें आ रही beams से moment — और न शुद्ध axial सूत्र उसे बताता है, न शुद्ध bending सूत्र। दो जाँचों वाला ढाँचा जान-बूझकर है: छोटा मोटा member cross section के कुचलने से fail हो सकता है, लंबा member section की क्षमता ख़त्म होने से बहुत पहले buckling से — और दोनों को पकड़ने के लिए दोनों जाँचें चाहिए।",
    eg: "Unbraced frame का वह column जिस पर बड़ा axial load और मामूली moment हो, आम तौर पर section जाँच से बहुत पहले overall member जाँच में fail होता है, क्योंकि axial load अपनी पैदा की हुई deflection के ज़रिए moment बढ़ा देता है। Transfer level का छोटा कड़ा column आम तौर पर पहले section जाँच में fail होता है।",
    tip: "Section strength जाँच में moment capacity घटी हुई वाली ही होती है, पूरी plastic capacity नहीं — ऊँचा axial load bending के लिए उपलब्ध क्षेत्रफल खा जाता है। Interaction समीकरण में बिना घटाया Mp इस्तेमाल करना आम और असुरक्षित ग़लती है।",
  },

  "t-13920-joint": {
    what: "Cl. 9 joint को अपने आप में एक member मानता है। Joint में design shear दोनों तरफ़ की beam reinforcement से निकाली जाती है, उसकी yield strength का 1.25 गुना लेकर — यह overstrength मान है, क्योंकि bars सचमुच इतना बल दे सकती हैं — और उसमें से column shear घटा दी जाती है। फिर joint की nominal shear strength इस पर निर्भर है कि उसमें आ रही beams उसे कितना confine करती हैं: जहाँ beams चारों फलक confine करें वहाँ effective joint area का 1.5 √fck गुना, जहाँ तीन फलक या दो आमने-सामने के फलक confine हों वहाँ 1.2 √fck, और बाक़ी हर स्थिति में 1.0 √fck। Column का transverse reinforcement joint के आर-पार जारी रखा जाता है, और beam bars ठीक से anchor होनी चाहिए — exterior joint में उन्हें दूर वाले फलक तक ले जाकर नीचे मोड़कर, और interior joint में column को bars की दिशा में इतना गहरा बनाकर कि वह bar व्यास का निर्धारित गुणज हो जाए।",
    why: "Joint frame का सबसे छोटा और सबसे ज़्यादा stress झेलने वाला हिस्सा है, और यहीं ductile design सबसे अक्सर चुपचाप ductile रहना बंद कर देता है। अगर joint shear में fail हो जाए, तो beams में इतनी मेहनत से detail किए गए plastic hinges बनते ही नहीं और frame वह ductility खो देता है जो उसके response reduction factor ने मान रखी थी। Joint की विफलताएँ brittle भी होती हैं और व्यावहारिक रूप से मरम्मत के परे — और भारतीय भूकंपों में देखी गई सबसे आम विफलताओं में यही थीं।",
    eg: "इमारत की सबसे ऊपरी मंज़िल का कोने वाला joint — उसमें beams सिर्फ़ दो सटे हुए फलकों पर हैं, इसलिए उसे सबसे कम strength 1.0 √fck मिलती है — और वहीं beam bars को anchor होने की सबसे कम जगह भी मिलती है। यही मेल है जिसकी वजह से भूकंप में सबसे पहले अक्सर कोने वाले columns ही टूटते हैं।",
    tip: "Site पर सबसे मुश्किल हिस्सा गणना नहीं, बल्कि joint के आर-पार beam bars की चार परतें गुज़रते हुए column के hoops बिठाना है। Drawings जारी होने से पहले joint को पूरे आकार में बनाकर देखें — अगर bars भौतिक रूप से बैठती ही नहीं, तो site पर वह detail चुपचाप छोड़ दी जाएगी।",
  },

  "t-13920-wall": {
    what: "Cl. 10 बताता है कि भूकंप बल उठाने के लिए भरोसा की गई दीवार कैसे बननी चाहिए। दीवार की मोटाई 150 mm से कम नहीं। Reinforcement दोनों दिशाओं में, gross क्षेत्रफल के न्यूनतम 0.25 प्रतिशत के अनुपात में, और उनके बीच की दूरी दीवार की लंबाई का पाँचवाँ हिस्सा, मोटाई का तीन गुना और 450 mm — इनमें सबसे कम से ज़्यादा नहीं; bar का व्यास मोटाई के दसवें हिस्से तक सीमित। जहाँ factored shear stress 0.25 √fck पार करे या दीवार 200 mm से मोटी हो, वहाँ reinforcement के दो पर्दे चाहिए। जहाँ बाहरी fibre की compressive stress 0.2 fck पार करे, वहाँ boundary elements — दीवार के सिरों पर मोटे किए गए, घने confine किए गए क्षेत्र — देने होंगे, और जहाँ वह stress 0.15 fck से नीचे आ जाए वहाँ उन्हें बंद किया जा सकता है।",
    why: "जिन इमारतों में shear wall है, उनमें ज़्यादातर lateral load वही उठाती है, इसलिए उसका व्यवहार पूरी इमारत का व्यवहार तय कर देता है। अपने हाल पर छोड़ दी जाए तो वह brittle तिरछे shear mode में fail होती है; detailing के नियम उसे इसके बजाय ductile flexural mode की ओर धकेलते हैं, जिसमें yielding आधार पर केंद्रित हो जाती है। Boundary elements ही असली कुंजी हैं: दीवार के सिरे वही जगह हैं जहाँ flexural compression केंद्रित होती है, और उन्हें confine करना ही दीवार को बड़े उलटफेरों के दौरान load उठाते रहने देता है, बजाय किसी कोने पर कुचल जाने के।",
    eg: "250 mm मोटी, 5 m लंबी दीवार को मोटाई की वजह से दो पर्दे चाहिए, जिनमें हर दिशा में न्यूनतम steel 0.0025 × 250 × 1000 = 625 mm² प्रति मीटर, और दूरी 5000/5 = 1000 mm, 3 × 250 = 750 mm तथा 450 mm में सबसे कम — यानी 450 mm चलेगा।",
    tip: "Openings सब कुछ बदल देते हैं। Openings की एक पंक्ति एक दीवार को coupling beams से जुड़ी coupled walls में बदल देती है, और वे beams बहुत ऊँचे shear उलटफेर खींचती हैं — उन्हें आम तौर पर diagonal reinforcement चाहिए, और यह वह detail है जिसे bar bender पर छोड़ने के बजाय साफ़-साफ़ बनाकर देना चाहिए।",
  },

  "t-1893-principles": {
    what: "Cl. 6 बताता है कि code सचमुच क्या हासिल करने की कोशिश कर रहा है — और वह ऐसी संरचना नहीं है जो भूकंप से बिना नुकसान बच जाए। मंशा यह है कि संरचना हल्के झटके बिना नुकसान के झेले, मध्यम झटके बिना उल्लेखनीय structural नुकसान के (हालाँकि कुछ non-structural नुकसान हो सकता है), और तेज़ झटके बिना ढहे — ताकि जानें बच जाएँ, भले ही इमारत बाद में मरम्मत के परे हो। इसे किफ़ायत से देने के लिए code उस elastic बल से बहुत छोटे बल के लिए design करता है जो एक तेज़ भूकंप पैदा करता, और बाक़ी अंतर सोखने के लिए ductility तथा overstrength पर भरोसा करता है। Cl. 6 यह भी साफ़ करता है कि यह code साधारण इमारतों और संरचनाओं के लिए लिखा गया है, नाभिकीय संयंत्र, बड़े बाँध या offshore प्रतिष्ठान जैसी विशेष संरचनाओं के लिए नहीं — उनके अपने मानक हैं।",
    why: "यही code के सबसे भ्रामक आँकड़े — response reduction factor R — को समझा देता है। R न कोई safety factor है, न विश्लेषण से कमाई गई load में छूट; यह इस वादे की क़ीमत है कि संरचना नियंत्रित, ductile ढंग से yield होगी। IS 13920 का IS 1893 के साथ-साथ होने की पूरी वजह यही है: एक में घटा हुआ बल तभी जायज़ है जब दूसरे की detailing सचमुच बनाई गई हो।",
    eg: "Special moment resisting frame को साधारण frame से कहीं बड़ा R मिलता है, इसलिए उसका design seismic force बहुत छोटा होता है — पर सिर्फ़ इसलिए कि IS 13920 की detailing उसे कई चक्रों तक स्थिर plastic hinges बनाने देती है। R ले लिया और detailing छोड़ दी, तो इमारत अपनी असली माँग के एक अंश के लिए design हो जाती है और अंतर पाटने को कोई ductility नहीं बचती।",
    tip: "Design base shear को सिर्फ़ एक load नहीं, एक detailing की ज़िम्मेदारी की तरह पढ़ें। जब भी सवाल पूछे कि code के अनुसार design होने के बावजूद इमारत ने भूकंप में बुरा प्रदर्शन क्यों किया, उत्तर लगभग हमेशा बल और detailing के इसी अंतर में होता है।",
  },

  "t-1893-loadcomb": {
    what: "दो जुड़े हुए नियम। Limit state design के लिए Cl. 6.3 जाँचे जाने वाले संयोजन देता है: 1.5 (DL + IL); 1.2 (DL + IL ± EL); 1.5 (DL ± EL); और 0.9 DL ± 1.5 EL। अलग से, Cl. 7.3 तय करता है कि जड़त्व बल पैदा करने वाले seismic weight में imposed load कितना गिना जाएगा: जहाँ imposed load 3 kN/m² तक हो वहाँ उसका एक-चौथाई; जहाँ 3 kN/m² से ज़्यादा हो वहाँ आधा; और छत का imposed load बिल्कुल नहीं।",
    why: "छात्र जिन दो संयोजनों को छोड़ देते हैं, वही सबसे ज़्यादा मायने रखते हैं। 0.9 DL ± 1.5 EL इसलिए है कि संरचना को नीचे दबाकर रखने वाली इकलौती चीज़ dead load ही है — उसे घटाकर ही footing में uplift या column में net tension सामने आती है, और पूरा dead load लेने पर वह छिप जाती। और seismic weight में घटा हुआ imposed load हक़ीक़त दिखाता है: भूकंप बल द्रव्यमान से पैदा होता है, और code यह नहीं मानता कि भूकंप आने के ठीक उस क्षण हर मंज़िल पूरी भरी होगी।",
    eg: "Moment frame का सिरे वाला column 1.2 (DL + IL + EL) के तहत compression में हो सकता है, पर 0.9 DL − 1.5 EL के तहत net tension में — जो उसका reinforcement बदल देता है और उससे भी ज़्यादा अहम, उसकी footing। सिर्फ़ compression के लिए design की गई footing उखड़ सकती है।",
    tip: "भूकंप load का कोई चिह्न नहीं होता। EL वाला हर संयोजन दोनों दिशाओं में, और इमारत के दोनों principal directions में चलाना पड़ता है — इसीलिए seismic run gravity वाले से कहीं ज़्यादा load cases पैदा करता है।",
  },

  "t-anchorage": {
    what: "जहाँ सीधी लंबाई न मिले, वहाँ bond bends और hooks से पूरा किया जाता है। IS 456 anchorage के मान देता है: हर 45° bend bar के व्यास का 4 गुना गिना जाता है (सभी bends मिलाकर अधिकतम 16 φ तक), और मानक U-प्रकार के hook का anchorage मान 16 φ है।",
    why: "Anchorage bar को ऐसे support या joint के अंदर भी अपनी stress विकसित करने देती है जो भौतिक रूप से Ld से छोटा है। इसके बिना संकरे column में घुसने वाली beam की नीचे वाली bars कभी develop हो ही नहीं पातीं।",
    eg: "जिस bar को 600 mm development चाहिए पर column के अंदर सिर्फ़ 450 mm मिल रहा हो, वह बची हुई लंबाई मानक 90° bend और उसकी extension से पूरी कर सकती है — Cl. 26.2.2 के anchorage मानों से जाँचकर।",
    tip: "Anchorage मान bar की केंद्र रेखा के साथ नापा जाता है। Tension में mild steel bars हमेशा hook पर ख़त्म होती हैं; deformed bars को आम तौर पर hook नहीं चाहिए क्योंकि उनकी पसलियाँ ख़ुद bond देती हैं।",
  },

  "t-effspan": {
    what: "Simply supported member का effective span — clear span + effective depth, या supports की केंद्र-से-केंद्र दूरी, जो कम हो। जिस continuous member के supports clear span के बारहवें हिस्से से चौड़े हों, उस पर Cl. 22.2(b) के नियम लगते हैं, और cantilever का effective length support के फलक तक की लंबाई + आधा effective depth होता है।",
    why: "आप जो भी bending moment निकालते हैं, वह इसी लंबाई पर टिका है। जहाँ code clear-span वाला नियम मानता है वहाँ केंद्र-से-केंद्र लेने पर moment कुछ प्रतिशत ज़्यादा आ जाता है — और जहाँ code c/c माँगता है वहाँ clear span लेने पर कम।",
    eg: "5.0 m clear span वाली beam, 300 mm चौड़े supports पर, d = 450 mm: clear span + d = 5.45 m; c/c = 5.3 m। Effective span = 5.3 m (जो कम है)।",
    tip: "जिस frame का विश्लेषण frame की तरह हुआ हो, वह केंद्र-से-केंद्र spans इस्तेमाल करता है। Cl. 22.2 का नियम उन beams और slabs के लिए है जिनका विश्लेषण अलग-थलग member के रूप में हुआ है।",
  },

  "t-barspacing": {
    what: "समांतर bars के बीच क्षैतिज clear दूरी बड़ी bar के व्यास से, या coarse aggregate के अधिकतम आकार + 5 mm से कम नहीं होनी चाहिए। ऊर्ध्वाधर दिशा में clear दूरी 15 mm से, coarse aggregate के अधिकतम आकार के दो-तिहाई से, या सबसे बड़ी bar के व्यास से कम नहीं। Tension ज़ोन में अधिकतम spacing crack नियंत्रण के लिए Cl. 26.3.3 तय करता है।",
    why: "कंक्रीट को bars के बीच से और vibrator के needle के चारों ओर बहना पड़ता है। कम दूरी पर लगी bars ठीक वहीं honeycombing देती हैं जहाँ steel को bond की सबसे ज़्यादा ज़रूरत है।",
    eg: "20 mm coarse aggregate और 20 mm bars के साथ: न्यूनतम क्षैतिज clear spacing = 20 mm और (20 + 5) = 25 mm में जो बड़ा हो, यानी 25 mm।",
    tip: "जहाँ beam में भीड़ हो, वहाँ code bars को जोड़ों या bundles में रखने की अनुमति देता है (Cl. 26.3.3.1) — पर तब bundle को development length के लिए समतुल्य क्षेत्रफल की एक ही bar माना जाता है।",
  },

  "t-curtail": {
    what: "Bars वहाँ curtail की जा सकती हैं जहाँ वे moment के लिए अब ज़रूरी न हों, पर हर bar को अपने सैद्धांतिक cut-off बिंदु से आगे effective depth या bar के व्यास का बारह गुना — जो बड़ा हो — तक बढ़ना होगा, और cut-off बिंदु पर shear को Cl. 26.2.3.2 की अतिरिक्त शर्तें पूरी करनी होंगी।",
    why: "Bending moment का चित्र पूरी कहानी नहीं है — तिरछी cracking tension को bar के साथ आगे खिसका देती है। ठीक सैद्धांतिक बिंदु पर काट देने से bar वहीं अधूरी develop रह जाती है जहाँ shear crack उसे काट रही होती है।",
    eg: "d = 450 mm और 20 mm bars वाली beam: सैद्धांतिक cut-off से आगे बढ़ाव 450 mm और 12 × 20 = 240 mm में जो बड़ा हो — यानी 450 mm।",
    tip: "Simple support पर positive moment वाले steel का कम से कम एक-तिहाई support के अंदर जाना ज़रूरी है (Cl. 26.2.3.3) — एक नंबर वाला पसंदीदा सवाल।",
  },

  "t-workability": {
    what: "Workability डालने की परिस्थिति से तय होती है, और IS 456 का Cl. 7.1 workability की श्रेणियाँ उनके slump रेंज के साथ देता है — pavement और mass concrete के लिए very low से लेकर low (25–75 mm), medium (50–100 / 75–100 mm), और घनी reinforcement वाले sections तथा pump या पानी के नीचे डाले जाने वाले कंक्रीट के लिए high (100–150 mm) तक।",
    why: "जो कंक्रीट compact ही न हो सके, वह mix design की कमाई हुई ताक़त से कहीं ज़्यादा गँवा देता है। 5% void ही लगभग 30% strength ले जाता है।",
    eg: "Slab, beam और column के हल्के reinforced sections में आम तौर पर 50–100 mm slump रखा जाता है; घनी reinforcement और pumped कंक्रीट को इससे ज़्यादा चाहिए।",
    tip: "Workability सुधारने के लिए site पर पानी डालना w/c ratio बदल देता है और Table 5 का उल्लंघन है। सही इलाज admixture है, पानी की बाल्टी नहीं।",
  },

  "t-ec": {
    what: "Short-term static modulus of elasticity Ec = 5000 √fck N/mm² लिया जाता है, और flexural strength (modulus of rupture) fcr = 0.7 √fck N/mm²।",
    why: "Frame विश्लेषण की हर deflection और हर stiffness Ec से चलती है; fcr cracking moment तय करता है, जो यह तय करता है कि deflection जाँच के लिए member cracked section की तरह बर्ताव कर रहा है या uncracked की तरह।",
    eg: "M25 के लिए: Ec = 5000 √25 = 25 000 N/mm² = 25 GPa; fcr = 0.7 √25 = 3.5 N/mm²।",
    tip: "Code ख़ुद कहता है कि असल में नापा गया मान सूत्र से ±20% तक अलग हो सकता है, क्योंकि modulus काफ़ी हद तक aggregate पर निर्भर करता है। Design के लिए सूत्र, और किसी बनी हुई संरचना के आकलन के लिए नापा गया मान।",
  },

  "t-nominalmix": {
    what: "छोटे कामों के लिए IS 456 M20 तक nominal mixes की अनुमति देता है: M5 पर 1:5:10, M7.5 पर 1:4:8, M10 पर 1:3:6, M15 पर 1:2:4 और M20 पर 1:1.5:3 — द्रव्यमान से; और Table 9 प्रति 50 kg cement पर सूखे aggregate की कुल मात्रा तथा अधिकतम पानी बताता है। M20 से ऊपर mix को IS 10262 के अनुसार अनुपातित design mix होना ही होगा।",
    why: "Footing, plinth beam और छोटे आवासीय काम में nominal mix आज भी चलते हैं। सीमा — M20 — जान लेना ही वह चीज़ है जो nominal mix को वहाँ इस्तेमाल होने से रोकती है जहाँ code design mix माँगता है।",
    eg: "M20 nominal mix, द्रव्यमान से 1:1.5:3: 1 m³ कंक्रीट के लिए सूखा आयतन लगभग 1.54 m³, इसलिए cement ≈ 1.54 × (1/5.5) = 0.28 m³ ≈ 8 बोरी, रेत ≈ 0.42 m³, coarse aggregate ≈ 0.84 m³।",
    tip: "IS 456 की Table 9 वाले nominal mix अनुपात द्रव्यमान से हैं, आयतन से नहीं। तसले से site पर की जाने वाली volume batching उनका अनुमान भर है, code की असली शर्त नहीं।",
  },

  "t-800-defl": {
    what: "Table 6 element और cladding के प्रकार के अनुसार serviceability की deflection सीमाएँ देता है — जैसे elastic cladding वाली beams के लिए live load पर span/300, और भुरभुरी (brittle) cladding पर span/360। Purlins, gantry girders और column sway के लिए भी सीमाएँ दी गई हैं।",
    why: "Steel के sections मज़बूत तो होते हैं पर लचीले भी। जो beam strength में पास हो जाती है, वह नीचे लगी false ceiling चटका सकती है या फ़र्श को असुरक्षित महसूस करा सकती है — छात्रों की अपेक्षा से कहीं ज़्यादा steel beams serviceability से ही तय होती हैं।",
    eg: "भुरभुरी cladding वाली 6 m simply supported floor beam: अनुमत live load deflection = 6000/360 = 16.7 mm।",
    tip: "Deflection working (बिना factor वाले) load पर जाँची जाती है, factored load पर नहीं। इस जाँच में design load इस्तेमाल कर लेना सबसे आम ग़लती है।",
  },

  "t-loadcomb": {
    what: "Loads इस तरह जोड़े जाते हैं कि सबसे प्रतिकूल प्रभाव पकड़ में आ जाए। कंक्रीट के limit state design के लिए IS 456 की Table 18 देती है: 1.5 (DL + IL); 1.5 (DL + WL) या जहाँ dead load स्थिर रखने वाला हो वहाँ 0.9 DL + 1.5 WL; और जब तीनों साथ लगें तो 1.2 (DL + IL + WL)।",
    why: "0.9 DL वाला मामला इसलिए है कि कभी-कभी dead load ही स्थिर रखने वाला बल होता है — overturning और uplift में कम dead load ही बुरा मामला है, इसलिए factor 1.0 से नीचे चला जाता है।",
    eg: "हल्का steel canopy: uplift 0.9 DL + 1.5 WL से जाँचा जाता है, जो holding-down bolts में net tension पैदा कर सकता है — और 1.5 (DL + WL) वाला मामला उसे पूरी तरह छिपा देता है।",
    tip: "हवा और भूकंप कभी एक-दूसरे के साथ नहीं जोड़े जाते — दोनों के एक ही समय design तीव्रता पर होने की संभावना नगण्य मानी जाती है।",
  },

  "t-irregular": {
    what: "Code plan की अनियमितताएँ (torsional, re-entrant corners, floor slab का टूटना, out-of-plane offsets, non-parallel systems) और ऊर्ध्वाधर अनियमितताएँ (stiffness या soft storey, mass, vertical geometric, in-plane discontinuity, strength या weak storey) वर्गीकृत करता है। इनमें से कई अनिवार्य dynamic विश्लेषण या स्पष्ट design दंड ले आती हैं।",
    why: "भारतीय इमारतों में ज़्यादातर भूकंप-नुकसान की जड़ configuration में है, गणना में नहीं। खुला ground storey (stilt parking) क्लासिक soft-storey विफलता है और code उससे सीधे निपटता है।",
    eg: "जिस इमारत में ground level पर parking और ऊपर infill दीवारें हों, उसमें soft storey है; code माँगता है कि ground storey के columns और beams बढ़े हुए बलों के लिए design हों, या stiffness की अनियमितता ही हटाई जाए।",
    tip: "Configuration architect बहुत पहले तय कर देता है — structural engineer के spreadsheet खोलने से भी पहले। Sketch वाले चरण पर ही अनियमितता का सवाल उठा देना बाद के किसी भी विश्लेषण से ज़्यादा क़ीमती है।",
  },

  "t-settlement": {
    what: "IS 1904 संरचना के प्रकार और मिट्टी के अनुसार कुल तथा differential settlement पर सीमाएँ रखता है। रेत पर isolated foundations आम तौर पर लगभग 50 mm कुल settlement तक और clay पर लगभग 75 mm तक सीमित होते हैं, जबकि differential settlement और angular distortion इससे कहीं सख़्ती से सीमित हैं — क्योंकि संरचना को नुकसान असल में वही पहुँचाते हैं।",
    why: "इमारतें समान settlement हैरतअंगेज़ ढंग से झेल लेती हैं — दीवारें चटकाना और दरवाज़े जाम करना differential settlement का काम है। पीसा की मीनार का settlement बहुत बड़ा है, पर समस्या उसका differential हिस्सा ही है।",
    eg: "5 m दूरी पर दो सटे हुए columns 30 mm और 10 mm बैठें तो differential 20 mm और angular distortion 1/250 — जो भुरभुरी finishes वाली ज़्यादातर framed संरचनाओं की सहनशक्ति से बाहर है।",
    tip: "Settlement के तीन हिस्से हैं: तात्कालिक (elastic), primary consolidation और secondary compression। रेत में लगभग पूरा तात्कालिक होता है; मुलायम clay में consolidation वाला हिस्सा सालों ले सकता है।",
  },

  "t-masonry": {
    what: "Masonry में अनुमत compressive stress = मूल compressive stress (unit की strength और mortar grade से) × slenderness तथा eccentricity के लिए stress reduction factor × छोटे sections के लिए area reduction factor × unit के अनुपातों के लिए shape modification factor। Slenderness ratio effective height या effective length ÷ effective thickness है, और load bearing दीवारों के लिए code उसे सीमित करता है।",
    why: "Masonry compression में मज़बूत और बाक़ी हर चीज़ में कमज़ोर है। Design असल में slenderness और eccentricity की जाँच ही है — कम ऊँचाई की इमारतों में compressive stress शायद ही कभी सीमित करने वाला कारक बनता है।",
    eg: "3 m ऊँची 230 mm ईंट की दीवार, ऊपर और नीचे lateral support के साथ: effective height = 0.75 × 3000 = 2250 mm, slenderness ratio = 2250/230 ≈ 9.8 — सीमाओं के अच्छे-ख़ासे भीतर।",
    tip: "Cavity wall या pier वाली दीवार की effective thickness सीधे-सीधे उसकी भौतिक मोटाई नहीं होती — code अलग नियम देता है, और उन्हें ग़लत लगाने पर slenderness की जाँच निरर्थक हो जाती है।",
  },

  "t-mortar": {
    what: "IS 2250 mortars को उनकी compressive strength grade से पदनाम देता है और हर एक के लिए cement, चूना, cement-चूना तथा मिट्टी के mortar के अनुपात बताता है। Site पर आम cement mortar — superstructure की चिनाई के लिए 1:6, load bearing और बाहरी काम के लिए 1:4, और pointing तथा पतले जोड़ों के लिए 1:3।",
    why: "ईंट से ज़्यादा मज़बूत mortar चिनाई को मज़बूत नहीं बनाता — वह उसे भुरभुरा बना देता है, जिसमें crack जोड़ से नहीं बल्कि ईंटों के आर-पार जाती है। Mortar को कमज़ोर और झेल लेने वाला साथी ही रहना चाहिए।",
    eg: "1:6 cement mortar के 1 m³ के लिए लगभग 0.22 m³ के बराबर सूखा cement आयतन चाहिए — सूखे आयतन का गुणक लगाने के बाद लगभग 4.5 बोरी cement और 0.95 m³ रेत।",
    tip: "Cement mortar को पानी मिलाने के लगभग 30 मिनट के भीतर इस्तेमाल कर लेना चाहिए (चूने वाले mortar में इससे दोगुना समय)। Initial set के बाद और पानी डालकर दोबारा गूँथना (retempering) मान्य नहीं है।",
  },

  "t-brickwork": {
    what: "ईंटें चिनाई से पहले तब तक भिगोई जाती हैं जब तक बुलबुले उठना बंद न हो जाएँ, जोड़ लगभग 10 mm रखे जाते हैं और mortar से पूरी तरह भरे जाते हैं, और चिनाई समान रूप से उठाई जाती है — cement mortar वाली दीवारों में एक दिन में लगभग 1 m से ज़्यादा नहीं। English bond (बारी-बारी से headers और stretchers के courses) ज़्यादा मज़बूत है और भारत में ज़्यादा चलता है; Flemish bond एक ही course में headers और stretchers बदलता है और देखने में बेहतर लगता है।",
    why: "Masonry की ताक़त पर सबसे बड़ा असर कारीगरी का है। बिना भिगोई ईंट mortar से पानी खींच लेती है और जोड़ को कमज़ोर, भुरभुरा छोड़ देती है — mix चाहे कितना ही अच्छा क्यों न हो।",
    eg: "English bond में 230 mm मोटी दीवार: हर course बारी-बारी पूरा headers और पूरा stretchers का होता है, और lap शुरू करने के लिए quoin header के बग़ल में एक queen closer रखा जाता है।",
    tip: "जहाँ दीवार पर plaster होना है, वहाँ mortar के कच्चे रहते ही जोड़ लगभग 10–15 mm गहरे खुरच दिए जाते हैं — इससे plaster को पकड़ मिलती है। खुली रहने वाली चिनाई में जोड़ खुरचने की जगह pointing से फ़िनिश किए जाते हैं।",
  },

  "t-plaster": {
    what: "Plaster पृष्ठभूमि और exposure के अनुसार एक, दो या तीन coats में लगाया जाता है। ईंट की चिनाई पर अंदरूनी plaster आम तौर पर एक coat में 12 mm; बाहरी plaster आम तौर पर दो coats में 15 से 20 mm, जिसमें नीचे वाले coat को खुरचकर ऊपरी coat के लिए पकड़ बनाई जाती है। लगाने से पहले सतह साफ़, खुरची और गीली की जाती है, और plaster कम से कम सात दिन cure होता है।",
    why: "Plaster की ज़्यादातर ख़राबियाँ — खोखलापन, cracking, उखड़ना — पृष्ठभूमि की तैयारी की ख़राबी हैं, mix की नहीं। सूखी, धूल भरी या चिकनी कंक्रीट की सतह पर लगा plaster उखड़ेगा ही, mortar चाहे कितना ही अच्छा हो।",
    eg: "100 m² पर 1:6 cement mortar में 12 mm अंदरूनी plaster: गीले mortar का आयतन = 100 × 0.012 = 1.2 m³; लगभग 1.27 के सूखे आयतन गुणक के साथ ज़रूरी सूखा mix लगभग 1.52 m³।",
    tip: "जहाँ plaster दो अलग सामग्रियों के जोड़ के आर-पार जाता है — ईंट की चिनाई और RCC beam का मिलन — वहाँ जोड़ पर chicken mesh लगाई जाती है, वरना वहाँ बाल जैसी crack हमेशा आती ही है।",
  },

  "t-seismicband": {
    what: "भूकंप-रोधी चिनाई plinth, sill, lintel, छत और gable स्तरों पर क्षैतिज reinforced concrete bands पर टिकी है, साथ में कोनों, दीवारों के जोड़ों और openings के चारों ओर ऊर्ध्वाधर reinforcement। कितनी bands चाहिए, यह seismic zone और इमारत के महत्व के साथ बढ़ता जाता है।",
    why: "बिना reinforcement वाली चिनाई में tensile क्षमता लगभग शून्य है। Bands दीवारों को आपस में बाँधकर एक डिब्बा बना देती हैं, जिससे इमारत एक इकाई की तरह प्रतिक्रिया करती है — न कि अलग-अलग दीवारें कोनों पर खुलकर बिखरने लगें।",
    eg: "Zone IV में एक मंज़िला load bearing घर को आम तौर पर plinth band, सभी दीवारों पर लगातार चलने वाला lintel band, और plinth से छत की band तक जाती हर कोने व दरवाज़े की चौखट पर ऊर्ध्वाधर bars चाहिए।",
    tip: "Lintel band पूरी इमारत के चारों ओर एक ही स्तर पर लगातार होनी चाहिए — जो band किसी दरवाज़े पर रुक जाए या ऊपर-नीचे चढ़ती-उतरती हो, वह संरचनात्मक रूप से कहीं कम असरदार है।",
  },

  "t-pavementlayers": {
    what: "भारत का आम flexible pavement, नीचे से ऊपर: तैयार subgrade, granular sub-base (GSB), wet mix macadam (WMM) base, dense bituminous macadam (DBM) binder course और bituminous concrete (BC) wearing course — साथ में granular base पर prime coat और bituminous परतों के बीच tack coats।",
    why: "हर परत पहिये के load को और चौड़े क्षेत्र में फैलाती है, ताकि subgrade तक पहुँचने वाली stress इतनी कम रह जाए कि वह उसे उठा सके। परत की मोटाई तंत्र है, परत की गुणवत्ता टिकाऊपन।",
    eg: "7% CBR subgrade पर 30 msa के design में 200 mm GSB, 250 mm WMM, 80 mm DBM और 40 mm BC लग सकते हैं — IRC:37 के design catalogue से पढ़कर और MoRTH specification के अनुसार detail करके।",
    tip: "Prime coat सोखने वाली granular सतह पर लगता है; tack coat दो bituminous परतों के बीच या prime की हुई सतह पर। दोनों को आपस में गड्ड-मड्ड कर देना site की आम ग़लती और परीक्षा का आम सवाल है।",
  },

  "t-rigidpavement": {
    what: "Concrete pavement पहिये के load और तापमान (warping) की stress के मेल के लिए design होता है, और उसकी जाँच cumulative fatigue damage से होती है। नियमित दूरी पर transverse contraction joints दिए जाते हैं, जिनमें joint के आर-पार load पहुँचाने के लिए dowel bars होती हैं; और longitudinal joints में tie bars लगती हैं जो सटी हुई lanes को अलग नहीं होने देतीं।",
    why: "Concrete pavement crack होता ही है — design सिर्फ़ यह तय करता है कि कहाँ। Joints जान-बूझकर बनाए गए कमज़ोर तल हैं, जो crack को slab पर कहीं भी जाने के बजाय एक नियंत्रित, sealed जगह पर होने को मजबूर करते हैं।",
    eg: "250 mm मोटा slab, 4.5 m दूरी पर contraction joints, 300 mm केंद्र पर 500 mm लंबी 32 mm व्यास की dowel bars, और longitudinal joint में 12 mm की tie bars।",
    tip: "Dowel bars load पहुँचाती हैं और उन्हें खिसकने की छूट चाहिए (आधी bar पर ग्रीस या sleeve लगता है); tie bars अलगाव रोकती हैं और पूरी तरह bonded होती हैं। Drawing पर दोनों एक जैसी दिखती हैं और काम एक-दूसरे के उलट करती हैं।",
  },

  "t-aggtests": {
    what: "Aggregate के मुख्य परीक्षण: flakiness और elongation index से कण का आकार (Part 1); specific gravity, water absorption और रेत का bulking (Part 3); तथा aggregate impact value, aggregate crushing value और Los Angeles abrasion value से यांत्रिक ताक़त (Part 4)। स्वीकृति की सीमाएँ कंक्रीट के लिए IS 383 में और सड़क की परतों के लिए MoRTH / IRC दस्तावेज़ों में हैं।",
    why: "Aggregate कंक्रीट के आयतन का लगभग 70% है। चपटे कण workability और strength दोनों घटाते हैं; कमज़ोर aggregate हासिल किए जा सकने वाले कंक्रीट grade को सीमित कर देता है — cement चाहे कितना भी डाल लें।",
    eg: "रेत का bulking: नम रेत सूखी रेत से 20–30% ज़्यादा जगह घेर सकती है। आयतन से batching करते site पर bulking को नज़रअंदाज़ करने का मतलब है कि mix में रेत कम पड़ रही है और batch sheet पर रेत ज़्यादा दिख रही है — एक ही समय पर दोनों।",
    tip: "Impact, crushing और abrasion तीनों कठोरता नापते हैं, पर अलग-अलग तरीक़े से — impact गतिशील load है, crushing स्थिर load, और Los Angeles abrasion मिला-जुला घिसाव। सड़क की specifications आम तौर पर तीनों माँगती हैं।",
  },

  "t-ndt": {
    what: "Ultrasonic pulse velocity (Part 1) नापती है कि pulse कंक्रीट से कितनी तेज़ गुज़रती है, और उस गति को गुणवत्ता की श्रेणियों में बाँटा जाता है — ज़्यादा गति यानी सघन और ठोस कंक्रीट। Rebound hammer (Part 2) सतह की कठोरता नापता है, जो strength से मोटे तौर पर मेल खाती है। दोनों संकेत देने वाले परीक्षण हैं, cube या core strength की जगह नहीं।",
    why: "संरचना बन जाने के बाद cubes तो जा चुके होते हैं। मौजूदा कंक्रीट की एकरूपता, voids, cracking और अनुमानित strength आँकने का तरीक़ा NDT ही है — जैसे structural audit के दौरान या आग लगने के बाद।",
    eg: "जिस column में pulse velocity ठोस हिस्सों के 4.2 km/s से गिरकर एक जगह 2.8 km/s हो जाए, वहाँ void या honeycomb का संकेत है — जिसकी पुष्टि उसी जगह core ड्रिल करके की जा सकती है।",
    tip: "Rebound hammer की reading कंक्रीट के सिर्फ़ बाहरी 30 mm के आसपास को नापती है, और उस पर सतह की नमी, carbonation तथा सतह पर आया aggregate असर डालते हैं। बिना correlation के rebound के आँकड़े को 'strength' कभी मत कहिए।",
  },

  "t-contour": {
    what: "Contour एक ऐसी रेखा है जो समान reduced level के बिंदुओं को जोड़ती है। Contours कभी एक-दूसरे को नहीं काटतीं (सिवाय झुकी हुई चट्टान के), नक़्शे के भीतर या बाहर अपने आप बंद होती हैं, ढलान वाली ज़मीन पर पास-पास और समतल पर दूर-दूर होती हैं, और ridge या valley की रेखा को समकोण पर काटती हैं — valley में V का सिरा ऊपर की ओर (धारा की दिशा के विपरीत) और ridge पर नीचे की ओर।",
    why: "Contour का नक़्शा ही वह तरीक़ा है जिससे किसी site की शक्ल drawing बनती है। Alignment, cut और fill, drainage और catchment क्षेत्र — सब इसे ठीक पढ़ने से निकलते हैं।",
    eg: "समतल building site के लिए 0.5 m का contour interval आम है; पहाड़ी इलाक़े या छोटे पैमाने के नक़्शों में 5 m या उससे ज़्यादा।",
    tip: "समान दूरी पर contours यानी एक समान ढलान; ऊपर की ओर जाते हुए पास आती contours यानी अवतल (concave) ढलान। दूरी से ढलान की शक्ल पढ़ना एक मानक व्याख्या-प्रश्न है।",
  },

  "t-traverse": {
    what: "बंद traverse में हर रेखा का latitude उसकी लंबाई × bearing का cosine है, और departure लंबाई × bearing का sine। बंद traverse में latitudes का योग और departures का योग दोनों शून्य आने चाहिए; जो बचे वही closing error है, जिसे Bowditch (compass) नियम या transit नियम से बाँटा जाता है।",
    why: "कोई भी detail उठाने से पहले ज़मीन पर control का ढाँचा traversing से ही बनता है। Closing error traverse की अपनी सटीकता की ख़ुद-जाँच है।",
    eg: "120 m लंबी रेखा, whole circle bearing 60°: latitude = 120 cos 60° = +60.0 m (N), departure = 120 sin 60° = +103.9 m (E)।",
    tip: "Bowditch का नियम त्रुटि को रेखा की लंबाई के अनुपात में बाँटता है और तब इस्तेमाल होता है जब कोण और लंबाई की माप की सटीकता तुलनीय हो; transit नियम तब चलता है जब कोण लंबाई से ज़्यादा सटीक नापे गए हों।",
  },

  "t-earthwork": {
    what: "Earthwork खोदे या भरे गए शुद्ध आयतन के घन मीटर में नापा जाता है, और मिट्टी के प्रकार तथा गहराई की श्रेणियों के अनुसार वर्गीकृत होता है। Lead (क्षैतिज ढुलाई दूरी) और lift (ऊर्ध्वाधर) अलग से नापे जाते हैं जहाँ अनुबंध में उनका प्रावधान हो, और खुदाई का भुगतान आम तौर पर स्वीकृत मापों पर होता है, ज़्यादा खोद देने पर नहीं।",
    why: "Earthwork आम तौर पर परियोजना के bill की पहली मद होती है और सबसे ज़्यादा विवाद भी इसी पर होता है। जो खोदा गया उस पर नहीं, बल्कि स्वीकृत section पर नापना — पूरा bill इसी सिद्धांत पर टिका है।",
    eg: "10 m लंबी, 1.0 m चौड़ी और 1.5 m गहरी trench: आयतन = 15 m³, स्वीकृत मापों पर नापा गया — भले ही काम करने की जगह के लिए किनारे और चौड़े खोदे गए हों।",
    tip: "नींव की खुदाई नींव के कंक्रीट के बाहरी मापों तक नापी जाती है, खोदे गए गड्ढे के मापों तक नहीं — काम करने की जगह ठेकेदार का ख़र्च है, नापी जाने वाली मद नहीं।",
  },

  "t-quantities": {
    what: "कंक्रीट बने हुए member के घन मीटर में नापा जाता है, जिसमें बताए गए आकार से बड़े openings और embedded सामान की कटौती होती है, पर reinforcement तथा छोटे openings की कोई कटौती नहीं। Reinforcement लगाई गई bars की असली लंबाई के किलोग्राम में नापा जाता है, जो bar bending schedule से मानक प्रति-मीटर द्रव्यमान लगाकर निकलता है — गोल bars के लिए d²/162 किलो प्रति मीटर, d मिलीमीटर में।",
    why: "d²/162 वाला शॉर्टकट सीधे steel के घनत्व 7850 kg/m³ से आता है: (π/4)d² × 7850 × 10⁻⁶ = d²/162.3। यह कहाँ से आया है — यह पता हो तो भूल जाने पर आप उसे ख़ुद निकाल सकते हैं।",
    eg: "8 m लंबी 12 mm bar: द्रव्यमान = 12²/162 × 8 = 0.889 × 8 = 7.11 kg।",
    tip: "Laps, hooks और chairs अगर drawing में दिखाए गए हैं तो लगाए गए असली steel के हिस्से के रूप में नापे जाते हैं। बरबादी (wastage) rate का मामला है, माप का नहीं।",
  },

  "t-waterdemand": {
    what: "IS 1172 इमारतों के लिए प्रति व्यक्ति मूल पानी की ज़रूरत देता है — पूरी flushing व्यवस्था वाली आवासीय इमारतों के लिए यह आम तौर पर 135 लीटर प्रति व्यक्ति प्रति दिन लिया जाता है, और hostel, अस्पताल, कारख़ाना, स्कूल तथा दूसरी occupancies के लिए अलग मान। यह occupancy और occupant load के अनुसार ज़रूरी sanitary fixtures की संख्या भी बताता है।",
    why: "प्रति व्यक्ति वाला आँकड़ा ही टंकी, pump, pipe और drainage तंत्र का आकार तय करता है। शुरुआत में ही ग़लत हो जाए तो वह पूरी plumbing design में आगे तक फैलता चला जाता है।",
    eg: "40 flats वाली आवासीय इमारत, औसत 5 व्यक्ति प्रति flat: 200 व्यक्ति × 135 = 27 000 लीटर प्रतिदिन। भंडारण आम तौर पर दैनिक माँग के एक अनुपात के रूप में, underground और overhead टंकियों में बाँटकर दिया जाता है।",
    tip: "135 lpcd में flushing शामिल है। जहाँ flushing के लिए अलग non-potable आपूर्ति हो, वहाँ घरेलू और flushing वाले हिस्से अलग-अलग गिने जाते हैं — dual-plumbing और recycled water की योजनाओं के लिए यह फ़र्क़ मायने रखता है।",
  },

  "t-drainage": {
    what: "इमारत की drainage पानी की सील वाले traps पर टिकी है जो sewer की गैसें बाहर रखते हैं, पर्याप्त आकार और हवादारी वाले soil तथा waste pipes पर, और ऐसे ढाल पर बिछी नालियों पर जो ख़ुद-सफ़ाई वाली गति दे सकें। दिशा, ढाल या pipe के आकार के हर बदलाव पर और जोड़ों पर manhole या inspection chamber दिया जाता है।",
    why: "Drainage दो तरीक़ों से fail होती है: ढाल बहुत सपाट हो तो ठोस पदार्थ बैठ जाते हैं, और हवादारी कम हो तो traps siphon होकर सूख जाते हैं। दोनों design की ग़लतियाँ हैं, रखरखाव की समस्या नहीं।",
    eg: "100 mm की घरेलू drain आम तौर पर लगभग 1 in 60 के ढाल पर बिछाई जाती है, जो इसलिए चुना जाता है कि अपेक्षित बहाव पर गति ख़ुद-सफ़ाई वाली बनी रहे।",
    tip: "घरेलू trap में पानी की सील आम तौर पर 50 mm गहरी होती है। कम इस्तेमाल होने वाले floor trap में वाष्पीकरण से सील ख़त्म हो जाना ही bathroom से बदबू आने की आम वजह है — रुकावट नहीं।",
  },

  "t-firegrading": {
    what: "Fire load प्रति इकाई फ़र्श क्षेत्रफल पर जलने वाली सामग्री की कैलोरी ऊर्जा है, और यही किसी occupancy की fire grading तय करता है। फिर structural elements के लिए fire resistance rating — घंटों में — ज़रूरी होती है, जो मानक fire test में stability, integrity और insulation बनाए रखने की उनकी क्षमता से स्थापित होती है।",
    why: "दो घंटे की rating का मतलब यह नहीं कि element असली आग में दो घंटे टिकेगा; मतलब यह है कि उसने उतनी देर एक मानकीकृत तापन वक्र झेला। यह एक तुलनात्मक माप है, जिससे एक सुसंगत code बनाया जाता है।",
    eg: "RCC निर्माण में ज़रूरी fire rating बड़े हिस्से में cover से ही मिलती है — IS 456 की Table 16A निर्धारित fire resistance अवधियों के लिए nominal cover देती है, जो अक्सर durability वाली cover से ज़्यादा होती है।",
    tip: "कंक्रीट में fire resistance और durability दोनों cover तय करते हैं, और दोनों में जो बड़ा हो वही चलता है। बहुत से छात्र सिर्फ़ Table 16 से cover निकालते हैं और भूल जाते हैं कि Table 16A भी है।",
  },

  "t-shrinkcreep": {
    what: "कंक्रीट सख़्त होने के बाद भी हिलता-डुलता रहता है। Drying shrinkage मुक्त पानी निकलने पर होने वाला संकुचन है; परीक्षण के आँकड़े न हों तो code कुल shrinkage strain 0.0003 मान लेने देता है। Creep लगातार लगे load के नीचे धीरे-धीरे बढ़ती अतिरिक्त strain है; इसे creep coefficient θ से बताया जाता है, जो मुख्यतः इस पर निर्भर है कि load पहली बार किस उम्र में लगा — 7 दिन पर 2.2, 28 दिन पर 1.6, एक साल पर 1.1। Creep को short-term Ec की जगह effective modulus Ece = Ec/(1 + θ) इस्तेमाल करके सँभाला जाता है। Coefficient of thermal expansion लगभग 6 से 12 × 10⁻⁶ प्रति °C लिया जाता है — चूना-पत्थर के aggregate के लिए नीचे वाला सिरा और quartzite के लिए ऊपर वाला।",
    why: "ये तीनों प्रभाव अंतिम strength नहीं बदलते, पर serviceability पर इन्हीं का राज है। Slab की दीर्घकालीन deflection अक्सर तात्कालिक deflection की दो से तीन गुना होती है, और उस पूरे अंतर का लगभग सारा हिस्सा creep और shrinkage है। रुकी हुई (restrained) shrinkage ही वह आम वजह है जिससे नए slabs और लंबी दीवारों पर जाल जैसी cracking दिखती है। अगर आपने deflection सिर्फ़ short-term modulus से जाँची, तो slab काग़ज़ पर पास होगा और site पर झुक जाएगा।",
    eg: "कोई slab सातवें दिन से अपना वज़न उठा रहा है। M25 के लिए Ec = 5000√25 = 25000 N/mm²। उस उम्र पर θ = 2.2 के साथ Ece = 25000/3.2 = 7813 N/mm² — यानी slab ऐसे बर्ताव कर रहा है मानो कंक्रीट सिर्फ़ एक-तिहाई कड़ा हो। इसीलिए Cl. 23.2 का span/depth नियम इतनी उदार गुंजाइश के साथ लिखा गया है।",
    tip: "परीक्षा का शॉर्टकट: तीनों creep coefficients 2.2 / 1.6 / 1.1 क्रमशः 7 दिन / 28 दिन / 1 साल के साथ जाते हैं। किसी member पर जल्दी load डाल दिया, तो उसकी पूरी उम्र creep के रूप में उसकी क़ीमत चुकानी पड़ती है — props जल्दी न हटाने का यह असली तर्क है।",
  },

  "t-consjoint": {
    what: "Construction joint कंक्रीटिंग में सोच-समझकर लिया गया विराम है; cold joint बिना योजना का विराम है, जहाँ अगली परत आने से पहले पिछली परत set होने लगी थी। Cl. 13.4 joints को कमज़ोरी का स्रोत मानता है जिनसे जहाँ तक हो सके बचना चाहिए, उनकी जगह पहले से तय करने को कहता है, और detailing के लिए IS 11817 का हवाला देता है। सख़्त हो चुकी सतह पर काम दोबारा शुरू करते समय code माँगता है कि laitance हटाई जाए और सतह खुरदरी की जाए, झाड़कर साफ़ की जाए और अच्छी तरह गीली की जाए — तभी उसके सामने ताज़ा कंक्रीट डाला जाए।",
    why: "जो joint ऊँची shear वाली जगह पर पड़ जाए, या चिकना और धूल भरा छोड़ दिया जाए, वह एक ऐसा तल बन जाता है जिसके आर-पार घर्षण के अलावा कुछ ख़ास नहीं होता। Joint को कम shear वाली जगह पर रखना और उसका फलक खुरदरा करना aggregate interlock देता है, जिससे member लगभग monolithic जैसा बर्ताव करता है।",
    eg: "Simply supported beam में मानक तरीक़ा यह है कि span के बीच वाले तिहाई में रोका जाए, जहाँ shear सबसे कम है, और joint का फलक ऊर्ध्वाधर रखा जाए। Column में ऊपर की beam या slab के soffit पर रोका जाता है, और floor के साथ एक छोटा kicker ढाल दिया जाता है ताकि अगली lift की शुरुआत साफ़ और सीध में हो।",
    tip: "Joint का फलक कभी ढलवाँ ढेर के रूप में मत छोड़िए, और beam को support के ऊपर कभी मत रोकिए। अगर कंक्रीटिंग अचानक रुक जाए और सतह कड़ी हो चुकी हो, तो रुक जाइए और उसे विधिवत joint की तरह treat कीजिए — आधे set हुए तल के ऊपर काम जारी रखना ही वह तरीक़ा है जिससे cold joint ज़िंदगी भर के लिए रिसाव का रास्ता बन जाता है।",
  },

  "t-specialconcreting": {
    what: "Cl. 14.1 अति मौसम में काम को देखता है। गर्मी में चिंता है workability का तेज़ी से खोना, setting time का छोटा होना और plastic shrinkage cracking — जिसका इलाज सामग्री को ठंडा रखना (छाँव में aggregate, ठंडा या बर्फ़ वाला mixing पानी), रात में डालना और तुरंत curing शुरू करना है। ठंड में चिंता यह है कि जमाव के पास hydration लगभग रुक जाती है और अगर नए कंक्रीट का पानी जम जाए तो वह नष्ट हो जाता है — इसलिए जब तक पर्याप्त strength न आ जाए, कंक्रीट को ढककर बचाया जाता है। Cl. 14.2 पानी के नीचे की कंक्रीटिंग को देखता है और tremie, bottom-dump bucket, बोरियाँ या grouted aggregate की अनुमति देता है। Tremie का कंक्रीट जान-बूझकर cohesive और समृद्ध बनाया जाता है — code उसी mix के सूखे में डाले जाने की तुलना में लगभग 10 प्रतिशत ज़्यादा cement माँगता है, और slump लगभग 100 से 180 mm — और tremie की नली पूरे समय ताज़े कंक्रीट में डूबी रखी जाती है ताकि डाला हुआ कंक्रीट आसपास के पानी से कभी न धुले।",
    why: "दोनों परिस्थितियाँ कंक्रीट पर तब हमला करती हैं जब उसके पास लड़ने लायक कोई strength ही नहीं होती। गर्मी में slab पहले दो घंटों में ही crack कर सकता है, सिर्फ़ इसलिए कि सतह से पानी उतनी तेज़ी से उड़ रहा है जितनी तेज़ी से bleed water उसकी भरपाई नहीं कर पा रहा — इसमें load का कोई हाथ ही नहीं। पानी के नीचे ख़तरा यह है कि cement का paste धुलकर बह जाए और पीछे साफ़ aggregate का ढेर बचे, जो log sheet पर कंक्रीट जैसा ही दिखेगा।",
    eg: "Tremie से pile की कंक्रीटिंग भारतीय व्यवहार में पानी के नीचे का सबसे आम मामला है। अगर tremie एक बार भी कंक्रीट की सतह से ऊपर उठ जाए, तो नली में पानी घुसता है, धुले हुए aggregate की एक परत बन जाती है, और वह ख़राबी बहुत बाद में integrity test में कम-strength वाली पट्टी के रूप में सामने आती है।",
    tip: "गर्मी का मोटा नियम: जो भी सामग्री ठंडी करेंगे फ़ायदा होगा, पर प्रति रुपया सबसे ज़्यादा फ़ायदा ठंडा पानी देता है, और aggregate के ढेर पर छाँव करना तो मुफ़्त है। IS 7861 (Part 1 गर्म मौसम, Part 2 ठंडा मौसम) विस्तृत तरीक़ा देता है।",
  },

  "t-stability": {
    what: "Cl. 20.1 माँगता है कि restoring moment, characteristic dead load से पैदा overturning moment के 1.2 गुना और characteristic imposed load से पैदा overturning moment के 1.4 गुना के जोड़ से कम न हो। जहाँ dead load ही restoring moment दे रहा हो, वहाँ characteristic dead load का सिर्फ़ 0.9 गुना ही गिना जा सकता है। Cl. 20.2 characteristic बलों के सबसे प्रतिकूल संयोजन पर sliding के विरुद्ध कम से कम 1.4 का factor of safety माँगता है — यहाँ भी dead load का सिर्फ़ 0.9 गिनते हुए।",
    why: "0.9 वाला factor ही वह हिस्सा है जो छात्र सबसे ज़्यादा छोड़ देते हैं, और पूरे clause का विचार यही है। Dead load हमेशा दोस्त नहीं होता — जब वह संरचना को नीचे दबाए रख रहा हो तो हो सकता है वह अनुमान से कम निकले, इसलिए code उसे घटा देता है; और जब वह संरचना को गिरा रहा हो तो हो सकता है ज़्यादा निकले, इसलिए code उसे बढ़ा देता है। एक ही load, समीकरण के किस तरफ़ बैठा है उसके हिसाब से उल्टी दिशाओं में factored होता है।",
    eg: "Cantilever retaining wall जिसका अपना वज़न और heel पर की मिट्टी overturning का विरोध कर रहे हैं: उन्हें 0.9 पर लीजिए, active earth pressure के moment को 1.4 पर, और जाँच तभी पास होगी जब restoring वाला पक्ष फिर भी जीत जाए। बिना factor वाले 1.0 dead load से design करने पर असुरक्षित दीवार भी स्थिर दिखने लगती है।",
    tip: "Stability एक दृढ़ पिंड (rigid body) की तरह जाँची जाती है — किसी भी member design से पहले और अलग से। कोई दीवार flexure और shear में पूरी तरह पर्याप्त होकर भी अपने आधार से खिसक सकती है।",
  },

  "t-redistribution": {
    what: "Limit state विधि से design की गई statically indeterminate संरचना में Cl. 37.1.1 design से पहले elastic moments को समायोजित करने की अनुमति देता है, बशर्ते चार शर्तें पूरी हों: समायोजित moments और लगे हुए loads के बीच संतुलन बना रहे; किसी भी section पर कमी उस member में कहीं भी मौजूद संख्यात्मक रूप से सबसे बड़े moment के 30 प्रतिशत से ज़्यादा न हो; section में पर्याप्त घूमने की क्षमता हो, जिसे xu/d के 0.6 − δM/100 से ज़्यादा न होने के रूप में लिखा जाता है, जहाँ δM प्रतिशत कमी है; और जहाँ पार्श्व स्थिरता frames पर निर्भर हो, वहाँ चार से ऊँची मंज़िलों की संरचनाओं में कमी 10 प्रतिशत तक सीमित रहे।",
    why: "Continuous beam का सबसे बड़ा elastic moment interior support पर होता है, और वही सबसे ज़्यादा भीड़ वाली जगह भी है जहाँ steel रखना पड़ता है। Redistribution उस section को वहाँ yield होने देता है, अपने moment का एक हिस्सा span में बहा देने देता है, और सचमुच ऊँचे collapse load तक पहुँचा देता है। xu/d वाली शर्त ही इसे सुरक्षित बनाती है — section इतना under-reinforced होना चाहिए कि span के पकड़ने से पहले वह कुचलने के बजाय घूम सके।",
    eg: "100 kN·m का support moment 20 प्रतिशत घटाकर 80 kN·m के लिए design किया जाए, तो δM = 20, इसलिए section को xu/d ≤ 0.6 − 0.20 = 0.40 पूरा करना होगा। Span का moment इतना बढ़ाना होगा कि संतुलन बना रहे — redistribution moment को खिसकाता है, मिटाता कभी नहीं।",
    tip: "Redistribution सिर्फ़ limit state विधि पर और सिर्फ़ elastic विश्लेषण से आए moments पर लागू होता है। Cl. 22.5 की coefficient tables से लिए गए moments पर यह लागू नहीं होता, और working stress विधि पर भी नहीं।",
  },

  "t-expjoint": {
    what: "Cl. 27 माँगता है कि जहाँ plan के मापों में बदलाव से हानिकारक cracking की संभावना हो वहाँ संरचना को expansion joints से बाँटा जाए, और बताता है कि लगभग 45 मीटर से ज़्यादा लंबाई वाली संरचनाओं में आम तौर पर एक या ज़्यादा ऐसे joint दिए जाते हैं। Joint नींव के स्तर से ऊपर पूरे superstructure से होकर गुज़रता है, ताकि दोनों हिस्से स्वतंत्र रूप से हिल सकें; reinforcement उसके आर-पार नहीं ले जाई जाती, और detailing IS 3414 में है। Expansion joint वही चीज़ नहीं है जो construction joint (डालने में विराम) या contraction joint (shrinkage की cracking क़ाबू करने के लिए slab में जान-बूझकर रखी कमज़ोरी) है।",
    why: "कंक्रीट लगभग 10 microstrain प्रति डिग्री सेल्सियस हिलता है। 60 मीटर की इमारत और 30 °C के मौसमी उतार-चढ़ाव पर यह लगभग 18 मिलीमीटर की हरकत है। अगर frame लगातार है और आधार बँधा हुआ है, तो वह हरकत या तो उस joint पर होगी जो आपने चुना, या उन जगहों पर cracks के रूप में जो आपने नहीं चुनीं — आम तौर पर सिरे वाले bays में और उन कड़े cores के आसपास जो उस हरकत को रोक रहे हैं।",
    eg: "90 m लंबा school block आम तौर पर बीच के पास एक joint से दो संरचनात्मक रूप से स्वतंत्र blocks में बाँटा जाता है, और दरार के दोनों तरफ़ अपने-अपने columns होते हैं। चूँकि भूकंप में दोनों हिस्से स्वतंत्र रूप से हिल भी सकते हैं, दरार की चौड़ाई IS 1893 की separation शर्त से भी जाँची जाती है — जो आम तौर पर दोनों कसौटियों में चौड़ी वाली निकलती है।",
    tip: "Seismic ज़ोन में joint की चौड़ाई सिर्फ़ तापीय हरकत से निकाल लेना काफ़ी नहीं — सटी हुई इकाइयों के बीच अलगाव IS 1893 तय करता है, और बहुत पास बने blocks के आपस में टकराने (pounding) का नुकसान भूकंपों में बार-बार देखा गया है।",
  },

  "t-deepbeam": {
    what: "Cl. 29 किसी beam को deep तब मानता है जब effective span और overall depth का अनुपात simply supported beam में 2 से कम और continuous beam में 2.5 से कम हो। ऐसे member में यह सामान्य मान्यता कि समतल sections समतल रहते हैं, अब नहीं चलती — इसलिए code आपको strain diagram से lever arm निकालने नहीं देता; वह ख़ुद उसे तय कर देता है। Simply supported deep beam में lever arm 0.2 (l + 2D) है जब l/D 1 और 2 के बीच हो, और 0.6 l जब l/D 1 से कम हो; continuous deep beam में ये मान क्रमशः 0.2 (l + 1.5D) और 0.5 l हैं। Positive reinforcement बिल्कुल नीचे जमा करने के बजाय soffit के पास एक ज़ोन में फैलाया जाता है, और code दोनों फलकों पर side face reinforcement माँगता है।",
    why: "Deep beam में load supports तक arch या strut क्रिया से पहुँचता है, न कि उस flexure-और-shear तंत्र से जो बाक़ी पूरा code मानकर चलता है। Compression section में ऊँची बनी रहती है और नीचे का tension tie span भर लगभग स्थिर बल उठाता है — इसीलिए reinforcement सामान्य तरीक़े से curtail नहीं होता और supports पर की anchorage ही सबसे नाज़ुक detail बन जाती है।",
    eg: "खुले ground storey के ऊपर के columns को उठाता transfer girder इसका क्लासिक उदाहरण है — 6 m span और 3 m गहरे member में l/D = 2, इसलिए Cl. 38 की सामान्य beam theory लागू नहीं होती और Cl. 29 चलता है। चौड़े opening के ऊपर की wall beam भी यही है।",
    tip: "Deep beam का tension steel supports पर पूरी तरह anchor होना चाहिए — क्षैतिज loop में मोड़कर या plates लगाकर — क्योंकि tie का बल सिरों की ओर उस तरह घटता नहीं जैसे उथली beam में घटता है।",
  },

  "t-walls": {
    what: "Cl. 32 ऊर्ध्वाधर load उठाने वाली दीवारों को देखता है। Braced दीवार वह है जिसकी पार्श्व स्थिरता कोई और चीज़ दे रही हो; दीवार का slenderness ratio उसकी effective height और मोटाई का अनुपात है, और code उसे 30 तक सीमित करता है। जिस braced दीवार पर उल्लेखनीय transverse moment न हो, उसकी प्रति इकाई लंबाई design axial strength एक अनुभवजन्य व्यंजक से मिलती है, जो slenderness और load की eccentricity के लिए strength घटा देता है — और वह eccentricity मोटाई के 0.05 गुना से कम नहीं ली जाती। Reinforced दीवार के लिए Cl. 32.5 gross कंक्रीट क्षेत्रफल पर न्यूनतम reinforcement अनुपात तय करता है: ऊर्ध्वाधर दिशा में Fe 415 या उससे ऊँचे grade की 16 mm से बड़ी न होने वाली deformed bars के लिए 0.0012 और बाक़ी bars के लिए 0.0015; क्षैतिज दिशा में उन्हीं deformed bars के लिए 0.0020 और अन्यथा 0.0025।",
    why: "दीवार सिर्फ़ एक बहुत चौड़ा column नहीं है। वह अपनी पूरी ऊँचाई पर अपने पतले अक्ष के बारे में buckle होती है, इसलिए slenderness हावी रहती है; और reinforcement के नियम axial load उठाने के लिए नहीं, बल्कि एक लंबे element की लंबाई में shrinkage तथा तापीय cracking क़ाबू करने के लिए लिखे गए हैं। Seismic design में वही दीवार मुख्य पार्श्व-load element भी बन जाती है, और तब IS 13920 कहीं ज़्यादा सख़्त नियमों के साथ कमान सँभाल लेता है।",
    eg: "3 m ऊँची 200 mm मोटी braced basement दीवार का effective height से मोटाई का अनुपात 30 की सीमा के अच्छे-ख़ासे भीतर है, इसलिए वह axial strength और न्यूनतम reinforcement से तय होती है — जो Fe 500 की 12 mm bars के लिए gross section पर ऊर्ध्वाधर दिशा में 0.0012 × 200 × 1000 = 240 mm² प्रति मीटर बनता है।",
    tip: "दीवार में न्यूनतम क्षैतिज steel ऊर्ध्वाधर से ज़्यादा है। यह उल्टा लगता है — जब तक याद न आए कि वह किसलिए है: दीवार की लंबाई के साथ रुकी हुई shrinkage ही उसे चटकाती है, और वे cracks ऊर्ध्वाधर होती हैं, इसलिए उन्हें बाँधने वाला steel क्षैतिज ही होगा।",
  },

  "t-flatslab": {
    what: "Flat slab सीधे columns पर टिका होता है, बीच में कोई beam नहीं। Cl. 31 हर panel को column strip और middle strip में बाँटता है: column strip column की केंद्र-रेखा के दोनों ओर panel की चौड़ाई का एक-चौथाई है, जिसे panel के दो मापों में छोटे के एक-चौथाई के रूप में नापा जाता है, और जो बचे वह middle strip। जहाँ drop panel हो, वह उस दिशा में panel की लंबाई का कम से कम एक-तिहाई फैलता है, और column head column के 45 डिग्री के भीतर का फैला हुआ हिस्सा है। Cl. 31.4 की direct design विधि तब इस्तेमाल हो सकती है जब हर दिशा में कम से कम तीन continuous spans हों, panels आयताकार हों और लंबाई-चौड़ाई का अनुपात 2 से ज़्यादा न हो, क्रमागत spans लंबे वाले के एक-तिहाई से ज़्यादा अलग न हों, और design imposed load dead load के तीन गुना से ज़्यादा न हो। किसी span का कुल design moment Mo = W ln / 8 है, जो interior span में supports पर negative moment को 0.65 और बीच में positive moment को 0.35 के रूप में बँटता है, और फिर column तथा middle strips में बाँटा जाता है।",
    why: "Flat slab साफ़ soffit और घटी हुई storey ऊँचाई के लिए चुने जाते हैं, पर वे पूरी समस्या column के इलाक़े में सरका देते हैं। Shear उठाने के लिए वहाँ कोई beam नहीं है, इसलिए column के चारों ओर की punching shear ही design तय करती है — और यही वह failure है जिसकी चेतावनी सबसे कम मिलती है: punching अचानक होती है और एक column से दूसरे तक फैलती है। Drops और column heads इसीलिए हैं: वे ठीक वहीं shear की परिधि और गहराई बढ़ाते हैं जहाँ shear है।",
    eg: "500 mm वर्गाकार columns वाले 6 m × 6 m panel का clear span ln = 5.5 m। Panel पर कुल factored load W के साथ Mo = W × 5.5/8। Interior span में 0.65 Mo supports पर hogging moment और 0.35 Mo span में sagging moment है, और hogging का बड़ा हिस्सा column strip उठाती है।",
    tip: "Flexural steel से पहले punching shear जाँचिए। परिधि column या drop के फलक से d/2 पर ली जाती है, और अनुमत stress ks × 0.25 √fck है, जिसमें ks = 0.5 + βc पर 1 से ज़्यादा नहीं, और βc column की छोटी भुजा और लंबी भुजा का अनुपात है।",
  },

  "t-stairs": {
    what: "Cl. 33 सीढ़ी की flight को एक झुके हुए slab की तरह मानता है। जो सीढ़ी going की दिशा में लंबाई के साथ span करती हो, उसका effective span = going + हर सिरे पर landing की चौड़ाई का आधा या एक मीटर, जो कम हो। जहाँ एक या दोनों सिरों की landing flight के समकोण पर span कर रही हो — यानी दो flights के बीच half landing वाला आम dog-leg — वहाँ Cl. 33.2 साझा landing के load का पचास प्रतिशत वहाँ मिलने वाले दोनों spans में से हर एक पर लेने की अनुमति देता है। Section की गहराई waist slab के soffit के लंबवत नापी जाती है, और loads IS 875 Part 2 से आते हैं।",
    why: "सीढ़ी वह member है जिसे छात्र सबसे ज़्यादा सपाट slab मानकर design कर बैठते हैं, और जो दो चीज़ें उसे अलग बनाती हैं, Cl. 33 ठीक उन्हीं को सँभालता है। Span सिर्फ़ going नहीं है, क्योंकि flight landings पर टिकी होती है; और साझा landing का load दो बार — हर flight के लिए एक-एक बार — नहीं गिना जाना चाहिए, वरना पूरी सीढ़ी ज़रूरत से बड़ी बन जाएगी।",
    eg: "2.7 m going और दोनों सिरों पर 1.2 m landings वाली dog-leg सीढ़ी: effective span = 2.7 + 0.6 + 0.6 = 3.9 m, क्योंकि 1.2 m का आधा 1 m से कम है। अगर landings 2.4 m चौड़ी होतीं, तो हर सिरे पर जुड़ाव 1 m पर रुक जाता और effective span 4.7 m होता।",
    tip: "सीढ़ियों (steps) का अपना वज़न अक्सर भूल जाया जाता है। पहले waist slab का वज़न झुकी हुई लंबाई पर लीजिए, फिर त्रिकोणीय steps को plan पर एक समतुल्य समान load के रूप में जोड़िए — दोनों मिलकर अकेले waist slab से साफ़ तौर पर ज़्यादा होते हैं।",
  },

  "t-enhancedshear": {
    what: "Cl. 40.5 मानता है कि support के बहुत पास लगा load उस तक पहुँचने के लिए पूरे beam-action वाले shear तंत्र का मोहताज नहीं — वह सीधे arch बनाकर support में चला जाता है। Support के फलक से 2d की दूरी के भीतर के section के लिए कंक्रीट की design shear strength τc × 2d/av तक बढ़ाई जा सकती है, जहाँ av support के फलक से उस section तक की दूरी है। बढ़ा हुआ मान अधिकतम shear stress τc,max पर सीमित रहता है। साथ का प्रावधान यह है कि support से d से भी क़रीब के section की shear, d पर की shear से जाँची जा सकती है — बशर्ते load beam के ऊपर लगा हो और support की reaction member के सिरे में compression डाल रही हो।",
    why: "इस clause के बिना shear force का चित्र ठीक support पर चरम पर होता और आख़िरी कुछ सौ मिलीमीटर में असंभव stirrup भीड़ माँगता। भौतिक हक़ीक़त यह है कि गहराई के लगभग दोगुने के भीतर compression सीधे load से support तक पंखे की तरह फैलती है — जिस तिरछी crack के इर्द-गिर्द shear का पूरा सिद्धांत खड़ा है, वह इतनी कम दूरी में बन ही नहीं सकती।",
    eg: "500 mm effective depth वाली beam जिस पर support के फलक से 400 mm दूर संकेंद्रित load है: av = 400 mm, इसलिए कंक्रीट की shear strength τc × 2 × 500/400 = 2.5 τc ली जा सकती है, τc,max की सीमा के अधीन। यही arching तंत्र Cl. 28 के अंतर्गत corbels को भी चलाता है।",
    tip: "यह बढ़ोतरी तभी लागू होती है जब support की reaction member के सिरे को compression में डाले — जो beam किसी दूसरी beam से लटक रही हो उसे यह नहीं मिलती, क्योंकि वहाँ load नीचे के पास आता है और उसे stirrups के ज़रिए section में ऊपर टाँगना पड़ता है।",
  },

  "t-crackwidth": {
    what: "Cl. 35.3.2 सतह पर स्वीकार्य crack की चौड़ाई तय करता है। आम तौर पर, जहाँ cracking member की शक्ल या durability के लिए हानिकारक न हो, वहाँ आँकी गई सतही चौड़ाई 0.3 मिलीमीटर से ज़्यादा नहीं होनी चाहिए; और ख़ास तौर पर आक्रामक माहौल में, जैसे severe exposure श्रेणी में, 0.2 मिलीमीटर से ज़्यादा नहीं। फिर Cl. 43 कहता है कि सामान्य reinforced members में flexural cracking की सीमा तब पूरी मानी जाती है जब Cl. 26.3.2 के bar spacing वाले detailing नियम माने गए हों — इसलिए अलग से गणना आम तौर पर ज़रूरी नहीं पड़ती। जहाँ ज़रूरी पड़े, वहाँ Annex F crack width का सूत्र देता है, जिसमें चौड़ाई निकटतम bar से दूरी के साथ और विचाराधीन स्तर पर कंक्रीट की strain के साथ बढ़ती है।",
    why: "Reinforced कंक्रीट में cracks अपरिहार्य हैं — design ख़ुद मानकर चलता है कि neutral axis के नीचे का कंक्रीट crack हो चुका है और कोई tension नहीं उठा रहा। मायने यह रखता है कि cracks बहुत सारी और महीन हैं — जो हानिरहित है — या कम और चौड़ी, जो नमी और chloride को bars तक पहुँचने देती हैं। पास-पास लगी बहुत सी छोटी bars पहला नतीजा देती हैं; दूर-दूर लगी कुछ बड़ी bars दूसरा — और वह भी बिल्कुल उतने ही steel क्षेत्रफल पर।",
    eg: "Slab में प्रति मीटर उतने ही 1000 mm² steel के लिए, 110 mm केंद्र पर 12 mm bars, 310 mm केंद्र पर 20 mm bars की तुलना में कहीं महीन cracking देंगी। इसीलिए Cl. 26.3.2 slabs में spacing को effective depth के तीन गुना या 300 mm, जो कम हो, पर सीमित करता है।",
    tip: "Crack नियंत्रण गणना की समस्या होने से पहले detailing की समस्या है। Cover भी मायने रखता है और दोनों तरफ़ काटता है — ज़्यादा cover bar की रक्षा करता है पर उसी bar strain पर सतह की crack चौड़ी कर देता है, जो एक वजह है कि कुछ स्थितियों में code न्यूनतम के साथ-साथ अधिकतम भी तय करता है।",
  },

  "t-wsm": {
    what: "Annex B पुरानी elastic विधि को बनाए रखता है। कंक्रीट और steel दोनों elastic बर्ताव करते माने जाते हैं, neutral axis के नीचे का कंक्रीट कोई tension नहीं उठाता माना जाता है, और steel को modular ratio m = 280/(3 σcbc) के ज़रिए कंक्रीट के समतुल्य क्षेत्रफल में बदल दिया जाता है, जहाँ σcbc bending में अनुमत compressive stress है। Balanced section के लिए neutral axis depth factor k = 1/(1 + σst/(m σcbc)), lever arm factor j = 1 − k/3, और moment of resistance ½ σcbc k j b d² — जिसे आम तौर पर R b d² लिखा जाता है। अगर असली neutral axis balanced स्थिति से ऊपर है तो section under-reinforced है और steel की stress चलेगी; नीचे है तो over-reinforced है और कंक्रीट चलेगा।",
    why: "यह आज भी दो ऐसी जगहों पर आता है जिनसे बचा नहीं जा सकता। IS 3370 के अनुसार design होने वाली water-retaining संरचनाएँ इसी को इस्तेमाल करती हैं, क्योंकि वहाँ पूरा design उद्देश्य ही यह है कि कंक्रीट कम stress में और व्यावहारिक रूप से बिना crack के रहे; और विश्वविद्यालयों के पाठ्यक्रम तथा कई प्रतियोगी परीक्षाएँ आज भी इसे पूछती हैं। इसे समझ लेना यह भी साफ़ कर देता है कि limit state विधि ने क्या बदला: section का यांत्रिकी नहीं, बल्कि यह कि factor of safety कहाँ लगाया जाता है।",
    eg: "M20 के साथ Fe 415: σcbc = 7, m = 280/21 = 13.33, σst = 230। k = 1/(1 + 230/(13.33 × 7)) = 1/(1 + 2.464) = 0.289। j = 1 − 0.289/3 = 0.904। R = 0.5 × 7 × 0.289 × 0.904 = 0.914। इसलिए Mbal = 0.914 b d²।",
    tip: "Modular ratio को table की तरह नहीं, सूत्र की तरह याद कीजिए — m = 280/(3 σcbc) हर ज़रूरी मान बना देता है, और 280 हर grade पर वही रहता है। Annex B की कोई permissible stress limit state की गणना में कभी मत मिलाइए।",
  },

  "t-800-slender": {
    what: "Cl. 3.8 effective slenderness ratio KL/r पर सीमा लगा देता है — strength की गणना चाहे जो कहे। Dead और imposed load से compression उठाने वाले member के लिए 180; सिर्फ़ हवा या भूकंप के साथ मिलकर compression उठाने वाले के लिए 250; lateral torsional buckling के विरुद्ध compression flange के लिए 300; आम तौर पर tie का काम करने वाले पर हवा या भूकंप में stress उलट सकने वाले member के लिए 350; और हमेशा tension में रहने वाले के लिए 400।",
    why: "ये सीमाएँ strength के बारे में नहीं हैं — ये उस member के बारे में हैं जो इतना लचर हो कि member ही न रह जाए। बहुत slender tie अपने ही वज़न से साफ़ झुक जाती है, हवा में खड़कती है, ढुलाई और erection में मुड़ जाती है, और अपनी सीध इतनी खो देती है कि compression का सूत्र भरोसे लायक ही नहीं बचता। श्रेणीबद्ध सीमाएँ बताती हैं कि code किसकी कितनी परवाह करता है: पूरी compression पर सबसे सख़्ती, शुद्ध tension पर सबसे ढील।",
    eg: "4 m लंबी single angle bracing, दोनों सिरों पर pinned: ISA 65×65×6 का rmin ≈ 12.6 mm, इसलिए KL/r = 4000/12.6 = 317। हवा के नीचे compression bracing के रूप में यह 250 की सीमा में fail है; शुद्ध tension tie के रूप में 400 के भीतर है और मान्य है। आम इलाज है बड़ा angle, या बीच में एक tie लगाकर unsupported लंबाई आधी कर देना।",
    tip: "हमेशा rmin — सबसे छोटा radius of gyration — इस्तेमाल कीजिए, जब तक member सचमुच उस अक्ष के बारे में restrained न हो। Single angle में वह अक्ष heel से होकर जाता है, किसी leg की दिशा में नहीं — और यही भूलना truss design की क्लासिक ग़लती है।",
  },

  "t-800-analysis": {
    what: "Section 4 बताता है कि किसी member को design करने से पहले frame के बल कैसे निकाले जाएँ। Code तीन को मान्यता देता है: elastic विश्लेषण, जो सामान्य रास्ता है; plastic विश्लेषण, जो hinges के ज़रिए moments को बाँटता है और सिर्फ़ ductility की शर्तें पूरी करने वाले steel के Class 1 sections के लिए मान्य है; और advanced या second-order विश्लेषण, जो विकृत ज्यामिति का सीधे पीछा करता है। वह यह तय करने को भी कहता है कि connections को कैसे model किया जा रहा है — simple (जोड़ कोई उल्लेखनीय moment नहीं भेजता), rigid (members के बीच का कोण बना रहता है), या semi-rigid (जोड़ का moment-rotation बर्ताव ज्ञात है) — और frame को sway या non-sway वर्गीकृत करने को भी, क्योंकि sway frame को अपनी ही पार्श्व deflection से पैदा होने वाले अतिरिक्त moments का हिसाब रखना पड़ता है।",
    why: "विश्लेषण की मान्यता और connection की detail में मेल होना ही चाहिए, और असली designs यहीं बिगड़ते हैं। अगर आपने beam को simply supported model किया और fabricator ने पूरा moment connection वेल्ड कर दिया, तो column पर ऐसे moments आ जाएँगे जिनके लिए किसी ने design नहीं किया। और अगर आपने rigid frame model किया और site पर लचीला cleat बोल्ट हो गया, तो frame model के कहे से कहीं ज़्यादा sway करेगा।",
    eg: "आम भारतीय औद्योगिक shed simple frame के रूप में विश्लेषित होता है — pinned bases, beams अपने span के moment के लिए design, और पूरा पार्श्व load bracing पर। बहुमंज़िला unbraced moment frame को sway frame की तरह विश्लेषित करना पड़ता है, जिसमें column की effective lengths storey की ऊँचाई से ज़्यादा ली जाती हैं और P-delta प्रभाव भी गिने जाते हैं।",
    tip: "Plastic विश्लेषण कोई ऐसा शॉर्टकट नहीं जो किसी भी steel frame पर लगा दिया जाए। इसके लिए पूरे में Class 1 sections चाहिए, हर hinge वाली जगह पर पर्याप्त lateral restraint, और निर्धारित न्यूनतम ductility वाला steel — इस्तेमाल से पहले ये तीनों जाँच लीजिए।",
  },

  "t-800-details": {
    what: "Compression member का आकार तय हो जाने के बाद Cl. 7.3 से आगे यह तय होता है कि वह बनेगा कैसे। Cl. 7.3 plate की मोटाई और उस eccentricity को देखता है जो column में beam आने पर मान लेनी होती है। Cl. 7.4 column bases को देखता है — मोटी plate से load फैलाता slab base, या बड़े loads के लिए gusseted base — जिसमें base plate की मोटाई उसके नीचे के bearing दबाव से पैदा bending से तय होती है। Cl. 7.5 single और double angle struts को देखता है, जहाँ code पूरे eccentric-load विश्लेषण की जगह एक समतुल्य slenderness रख देता है। Cl. 7.6 और 7.7 lacing या battens से जुड़े built-up columns को देखते हैं: lacing या battens column के axial बल के 2.5 प्रतिशत के transverse shear के लिए design होते हैं, और connections के बीच हर अलग घटक की slenderness पूरे member की slenderness से नीचे रखी जाती है ताकि कोई एक element पहले buckle न कर जाए।",
    why: "Built-up column उतना ही अच्छा है जितना उसके दोनों हिस्सों को जोड़े रखने वाली चीज़। अगर lacing बहुत हल्की हो या battens बहुत दूर-दूर, तो connections के बीच एक channel अकेले buckle कर जाता है और column अपनी गणना किए गए load के एक अंश पर ही fail हो जाता है — और यह वह failure है जो मुख्य strength गणना को कभी दिखता ही नहीं। 2.5 प्रतिशत वाला shear नियम इसलिए है कि compression member कभी बिल्कुल सीधा होता ही नहीं, और उसका टेढ़ापन एक असली transverse बल पैदा करता है।",
    eg: "दो ISMC 300 को lace करके बना column: lacing की पट्टियाँ factored axial load के 2.5 प्रतिशत के लिए design होती हैं, जो दोनों lacing तलों में बँटता है; और दूरी इस तरह तय होती है कि एक channel की अपने minor axis के बारे में slenderness 50 से नीचे रहे, और पूरे column की slenderness के 0.7 गुना से भी नीचे।",
    tip: "उसी column के लिए lacing battening से हल्की और ज़्यादा कड़ी होती है, पर battens बनाना और रंगना कहीं आसान है। Battened columns shear में ज़्यादा लचीले भी होते हैं — इसीलिए code उनकी effective slenderness के साथ कम उदारता बरतता है।",
  },

  "t-800-hsfg": {
    what: "High strength friction grip bolt को shear में load उठाने के लिए design किया ही नहीं जाता। उसे net tensile stress area के 0.70 fub गुना के निर्धारित proof load तक कसा जाता है, और वही जकड़न plates के बीच घर्षण पैदा करती है जो shear उठाता है। Cl. 10.4.3 nominal slip resistance μf ne Kh F0 देता है — slip factor, प्रभावी सतहों की संख्या, hole के प्रकार का factor, और bolt का tension — जिसे γmf से भाग दिया जाता है: 1.10 जब slip न होना serviceability की शर्त हो, और 1.25 जब joint को ultimate load पर भी slip नहीं करना चाहिए। Slip factor 0.55 तक सीमित है और पूरी तरह सतह की हालत पर निर्भर है; hole factor clearance holes के लिए 1.0, oversized या short slotted holes के लिए 0.85, और slot के समांतर load वाले long slotted holes के लिए 0.7 है।",
    why: "Bearing bolts को कुछ भी उठाने से पहले खिसककर bearing में आना पड़ता है, और वह छोटी सी हरकत — line के हर bolt पर hole की clearance जितनी — वहाँ अस्वीकार्य है जहाँ कड़ापन या fatigue मायने रखती हो। Friction grip joints service load पर हिलते ही नहीं, इसीलिए वे पुल की girder के splices, crane gantry के connections और उलटफेर उठाने वाले हर joint के लिए मानक हैं।",
    eg: "एक M20 grade 8.8 bolt, एक ही सतह, μf = 0.5 वाली साफ़ mill scale सतह, clearance holes: F0 = 0.7 × 800 × 245 = 137.2 kN, Vnsf = 0.5 × 1 × 1.0 × 137.2 = 68.6 kN, और ultimate load पर Vdsf = 68.6/1.25 = 54.9 kN।",
    tip: "पूरी capacity दो ऐसी चीज़ों पर टिकी है जिन्हें drawing अकेले लागू नहीं करा सकती — सतह की तैयारी और कसावट। रंगी या तेल लगी faying सतहें μf को तबाह कर देती हैं, और अंदाज़े से कसा गया bolt अपने proof load का कितना हिस्सा उठा रहा है, यह किसी को नहीं पता। सतह का उपचार और कसने का तरीक़ा (calibrated torque wrench या turn-of-nut) लिखिए, और उनकी जाँच भी कराइए।",
  },

  "t-800-wsd": {
    what: "Section 11 उन स्थितियों के लिए working stress design उपलब्ध रखता है जहाँ limit state design सुविधाजनक रूप से लागू न हो सके। इसकी permissible stresses कोई स्वतंत्र समूह नहीं हैं, बल्कि पिछली sections की limit state design strengths से ही निकाली गई हैं: उपयुक्त क्षेत्रफल पर permissible axial tensile stress 0.6 fy है, permissible bending stress design bending strength को stress के रूप में लिखकर उसका 0.66 गुना है, और permissible axial compressive stress Section 7 के design compressive stress fcd का 0.60 गुना — यानी उत्तर अब भी limit state विधि के buckling curves ही चलाते हैं। Connections भी इसी तरह जाँचे जाते हैं, संबंधित design capacities से निकाली गई permissible मानों के साथ।",
    why: "यह दो वजहों से बचा हुआ है। कुछ ग्राहक और पुरानी specifications आज भी allowable-stress design माँगते हैं; और कुछ स्थितियाँ — 1984 के code से design हुई किसी मौजूदा संरचना की जाँच, या एक जल्दी की तुलना — stress की भाषा में कहीं आसान पड़ती हैं। पुरानी drawing को ईमानदारी से पढ़ने का तरीक़ा भी यही है: उस पर लिखी stresses का मतलब इसी ढाँचे में बनता है।",
    eg: "E 250 में 1200 mm² gross क्षेत्रफल वाला tension member: working stress की भाषा में अनुमत load = 0.6 × 250 × 1200 = 180 kN, जबकि limit state की design yield strength 250 × 1200/1.10 = 273 kN है, जो factored loads उठाती है। Load factors लगाने के बाद दोनों सुसंगत हैं — ये दो अलग उत्तर नहीं हैं।",
    tip: "दोनों विधियाँ मत मिलाइए। Section 11 की stresses बिना factor वाले characteristic loads के साथ जाती हैं; Section 6 से 9 की strengths factored loads के साथ। Permissible stress के सामने factored load रख देना मोटे तौर पर पचास प्रतिशत की ग़लती है, और वह भी ग़लत दिशा में।",
  },

  "t-800-eq": {
    what: "Section 12 वह सब जोड़ता है जो किसी steel frame को वह response reduction factor कमाने के लिए चाहिए जो IS 1893 उसके लिए मान लेता है। Loads और संयोजन IS 1893 से आते हैं; Section 12 उस detailing को चलाता है जो मानी हुई ductility को सच बनाती है। वह ordinary और special moment frames में तथा ordinary, special और eccentrically braced frames में भेद करता है, हर एक की अपनी शर्तों के साथ; और पूरे में capacity design का विचार लागू करता है: connections, joints और fasteners उस बल के लिए design होते हैं जो जुड़ा हुआ member सचमुच दे सकता है, न कि उस बल के लिए जो विश्लेषण ने लौटाया — ताकि yielding चुने हुए ductile element में ही हो, और कहीं नहीं। जिन members से yield होने की उम्मीद है, उनकी width-to-thickness सीमाएँ सामान्य Class 1 सीमाओं से भी सख़्त हैं, क्योंकि जो plate locally buckle कर जाए वह ductility के बार-बार के चक्र नहीं दे सकती।",
    why: "IS 1893 का response reduction factor R यह वादा है कि frame टूटने के बजाय yield होकर ऊर्जा सोखेगा। जो frame घटे हुए बल के लिए design हो पर बिना ductility के detail हो, उसे छूट तो मिल जाती है पर कमाई नहीं — वह elastic बल के शायद एक-चौथाई के लिए design होता है और बाक़ी झेलने का कोई तंत्र उसके पास नहीं। Special moment frame और ordinary frame के R मान इतने अलग ठीक इसीलिए हैं कि Section 12 उनसे बहुत अलग चीज़ें माँगता है।",
    eg: "Concentrically braced frame में brace के connections brace की पूरी अपेक्षित tensile yield capacity के लिए design होते हैं, विश्लेषण वाले बल के लिए नहीं — ताकि brace yield होकर ऊर्जा बिखेरे जबकि उसका gusset plate, bolts और welds सही-सलामत रहें। यही तर्क moment frame के beam-to-column connection से beam का plastic moment विकसित कराता है।",
    tip: "Ductile detailing strength design के ऊपर लगी कोई वैकल्पिक सजावट नहीं है — यह वह शर्त है जिस पर घटा हुआ design बल मिला था। अगर detailing हो ही न सकती हो, तो ईमानदार जवाब यही है कि कम R और ज़्यादा बल के लिए design किया जाए।",
  },

  "t-800-fatigue": {
    what: "Fatigue उस stress की कई बार की पुनरावृत्ति से होने वाली विफलता है जो एक बार में पूरी तरह सुरक्षित होती। Section 13 पूरी तरह stress range की भाषा में काम करता है — एक चक्र में अधिकतम और न्यूनतम stress का अंतर — न कि चरम stress की, और न औसत की। हर structural detail को tables से एक detail category मिलती है, जो मूलतः यह बताने वाला अंक है कि उस detail पर stress का जमाव कितना गंभीर है; और हर category का अपना strength वक्र होता है जो अनुमत stress range को चक्रों की संख्या से जोड़ता है। Cl. 13.2.2.3 किसी detail को आकलन से पूरी तरह छूट दे देता है जब design stress range 27/γmft N/mm² से नीचे रहे, या जब stress चक्रों की संख्या 5 × 10⁶ (27/(γmft f))³ से कम हो।",
    why: "Fatigue की cracks details पर शुरू होती हैं, cross sections पर नहीं। एक जैसी stress उठाने वाले दो members की fatigue उम्र बिल्कुल अलग हो सकती है, सिर्फ़ इसलिए कि एक की सतह चिकनी rolled है और दूसरे पर बिना घिसे toe वाला transverse fillet weld है। इसीलिए code आपसे सिर्फ़ stress नहीं, detail भी देखने को कहता है — और इसीलिए fatigue की समस्या का इलाज आम तौर पर बड़ा member नहीं, बेहतर detail होता है।",
    eg: "किसी ढलाईख़ाने की crane gantry girder अपनी उम्र में लाखों चक्र चलती है और fatigue का क्लासिक मामला है; पुल की girders और मशीन उठाने वाली संरचनाएँ भी। हवा और floor load उठाता साधारण building frame उन चक्र-संख्याओं के आसपास भी नहीं पहुँचता, इसलिए उसे छूट है।",
    tip: "चूँकि fatigue stress range पर निर्भर है, इसलिए +80 से −80 N/mm² तक घूमने वाला member 0 से 120 तक घूमने वाले से कहीं बुरी हालत में है — भले ही दूसरे की चरम stress ज़्यादा हो। उलटफेर ही असली दुश्मन है।",
  },

  "t-800-durability": {
    what: "Section 15 कहता है कि steelwork को इस तरह design कीजिए कि उसकी रक्षा की जा सके और वह रक्षा बनी भी रहे। यह उन कारकों की सूची देता है जो टिकाऊपन तय करते हैं — माहौल और exposure की मात्रा, member का आकार और नाप, धातु की मोटाई, सुरक्षात्मक coating का प्रकार, और उसे बनाए रखने की सहूलियत — और माँगता है कि details ख़ुद मदद करें: कोई ऐसी जेब नहीं जिसमें पानी रुके, मिलने वाली सतहों के बीच कोई ऐसी दरार नहीं जहाँ हाथ न पहुँचे, और हर क्षैतिज सतह से पानी की निकासी। जिन सुरक्षा प्रणालियों को यह मान्यता देता है, वे paint से लेकर hot dip galvanizing और metal spraying तथा cathodic protection तक हैं — और जहाँ exposure उपयुक्त हो, वहाँ weathering steel, जो अपनी स्थिर oxide परत ख़ुद बना लेता है और खुला ही छोड़ा जाता है।",
    why: "Steel की संरचनाएँ जिस मुख्य वजह से गिराई जाती हैं वह corrosion है, और उसकी रफ़्तार grade से कहीं ज़्यादा detail पर निर्भर है। जिस section में पानी ठहरता हो वह जंग खाकर छेद हो जाएगा, जबकि वैसा ही section जिससे पानी बह जाता हो सही-सलामत रहेगा। और चूँकि corrosion पहले पतले हिस्सों को खाती है, इसलिए उतनी ही गहराई के हमले पर 6 mm का gusset अपनी strength का 20 mm के flange से कहीं बड़ा हिस्सा गँवा देता है।",
    eg: "तटीय या औद्योगिक वातावरण में पीठ-से-पीठ लगे angles के बीच छोटा सा अंतर बहुत ख़राब चुनाव है — वह अंतर रंगने के लिए बहुत तंग है और seal करने के लिए बहुत चौड़ा, इसलिए नमी फँसाता है और अंदर से बाहर की ओर जंग खाता है। उतने ही steel के वज़न में एक अकेला angle, या ठीक से seal किए संपर्क वाले दो angles, कहीं ज़्यादा चलते हैं।",
    tip: "सुरक्षा प्रणाली और रखरखाव की पहुँच design के चरण पर तय कीजिए, fabrication के बाद नहीं। जिन members को कभी दोबारा नहीं रंगा जा सकेगा, उनके लिए पूरी design उम्र के हिसाब से प्रणाली चुननी होगी — आम तौर पर galvanizing या भारी coating — और वह फ़ैसला connection की details भी बदल देता है।",
  },

  "t-800-fire": {
    what: "Section 16 पूछता है कि आग के दौरान संरचना इतनी देर टिक पाएगी या नहीं। ज़रूरी fire resistance level उस occupancy के भवन नियमों से आता है; code का काम यह दिखाना है कि period of structural adequacy — यानी वह समय जिसमें member उस तापमान तक पहुँचता है जिस पर वह आग की स्थिति में अपना load नहीं उठा सकता — कम से कम उतना लंबा है। गणना तीन चरणों में चलती है: एक limiting steel temperature, जो इस पर निर्भर है कि member अपनी capacity के मुक़ाबले कितना load उठा रहा है; member के गर्म होने की दर, जो section factor यानी गर्म होने वाली परिधि और cross-sectional क्षेत्रफल के अनुपात से तथा लगाई गई सुरक्षा से तय होती है; और limiting तापमान तक पहुँचने में लगा समय। Section 16 तापमान के साथ yield strength तथा modulus की कमी भी देता है, और protected व unprotected दोनों members को कवर करता है।",
    why: "Steel जलता नहीं, पर नरम पड़ जाता है: लगभग 550 से 600 °C तक वह कमरे के तापमान वाली yield strength का लगभग आधा ही रख पाता है, और पूरी तरह भड़की आग में बिना सुरक्षा वाला member पंद्रह-बीस मिनट में वहाँ पहुँच सकता है। यहाँ design का चर समय है, strength नहीं — इसीलिए जवाब आम तौर पर बड़ा section नहीं, insulation होता है।",
    eg: "हल्के load वाले member का limiting तापमान पूरी तरह तनी हुई member से ऊँचा होता है, क्योंकि उसके पास strength बची हुई है और वह ज़्यादा गँवा सकता है — इसीलिए बची हुई क्षमता के साथ design किए गए column को उतना ही load उठाते पतले column से कम fire protection चाहिए हो सकती है। इसी तरह कम section factor वाला भारी section हल्के section से धीरे गर्म होता है और उसी rating के लिए पतली सुरक्षा से काम चल सकता है।",
    tip: "कंक्रीट की encasement, board प्रणालियाँ, छिड़का हुआ vermiculite और intumescent paint — सब अलग-अलग तरीक़ों से, और बहुत अलग क़ीमतों तथा शक्लों पर, समय ख़रीदते हैं। Intumescent coatings steel को दिखता हुआ रखती हैं, इसीलिए क़ीमत के बावजूद खुली architectural steelwork के लिए वही चुनी जाती हैं।",
  },

  "t-800-fab": {
    what: "Section 17 drawing और बने हुए frame के बीच का सब कुछ कवर करता है — सीधा करना और काटना, किनारों की तैयारी, छेद ड्रिल करना या punch करना, assembly और shop erection, bolting तथा welding की प्रक्रियाएँ, bearing सतहों की machining, रंगाई, members पर निशान लगाना, packing और भेजना, निरीक्षण तथा परीक्षण, और अपनी रंगाई व bedding की शर्तों समेत site पर erection। यह member की सीध, लंबाई, ऐंठन और खड़े किए गए frame की स्थिति पर tolerances भी तय करता है, और माँगता है कि erection के दौरान अस्थायी bracing दी जाए और स्थायी bracing के कमान सँभालने तक वहीं रहने दी जाए।",
    why: "हर strength की गणना एक सीधे member को उसकी design की गई जगह पर मानकर चलती है। Fabrication की tolerance ही वह चीज़ है जो उस मान्यता को उस गुंजाइश के भीतर सच बनाती है जो code के buckling curves पहले से रखते हैं। और steel संरचना की ज़िंदगी का सबसे ख़तरनाक क्षण erection के दौरान होता है, जब frame अधूरा है: उस पर पूरा वज़न आ चुका है पर उसका पार्श्व तंत्र अभी नहीं आया — इसीलिए अस्थायी bracing code की शर्त है, site की मर्ज़ी नहीं।",
    eg: "मोटी या dynamic load उठाने वाली सामग्री में छेद आम तौर पर punch करने के बजाय ड्रिल किए जाते हैं, क्योंकि punching छेद के किनारे को work-harden कर देती है और सूक्ष्म cracks छोड़ती है — हल्के static member में स्वीकार्य, पर crane girder में fatigue crack की शुरुआत।",
    tip: "जटिल nodes की shop assembly या trial erection उस ख़र्च के लायक है जिसके बारे में लगता है कि नहीं है। Shop के फ़र्श पर बेमेल पकड़ने में घंटे लगते हैं; वही बेमेल चालीस मीटर ऊपर, crane खड़ी रखकर पकड़ने में दिन लगते हैं।",
  },

  "t-1893-dynamic": {
    what: "Cl. 7.8 बताता है कि equivalent static विधि कब नाकाफ़ी हो जाती है। Dynamic विश्लेषण उन ऊँचाई-सीमाओं से ऊपर अनिवार्य हो जाता है जो यह clause table में देता है, और वे seismic zone पर तथा इस पर निर्भर हैं कि इमारत नियमित है या अनियमित — अनियमित इमारतें नियमित इमारतों से कहीं कम ऊँचाई पर ही सीमा पार कर जाती हैं। विश्लेषण code के design spectrum से response spectrum विश्लेषण हो सकता है, या उपयुक्त ground motions से time history विश्लेषण। इसके साथ तीन प्रक्रियागत शर्तें चलती हैं: इतने modes शामिल हों कि कुल seismic द्रव्यमान का कम से कम 90 प्रतिशत पकड़ में आए; modal प्रतिक्रियाएँ किसी मान्य विधि जैसे SRSS से, या पास-पास modes होने पर CQC से जोड़ी जाएँ; और अगर dynamic विश्लेषण का base shear equivalent static विधि से कम निकले, तो सारी response राशियाँ उसी अनुपात में बढ़ानी होंगी।",
    why: "Equivalent static विधि मानकर चलती है कि इमारत मूलतः अपने पहले mode में प्रतिक्रिया करती है, और बल का वितरण लगभग उलटे त्रिकोण जैसा होता है। नियमित, कम ऊँचाई वाले frame के लिए यह अच्छी मान्यता है और ऊँची या अनियमित इमारत के लिए ख़राब — जहाँ ऊँचे modes का उल्लेखनीय योगदान होता है और torsion प्रतिक्रिया को आपस में जोड़ देती है। Scaling वाला नियम code की अपनी सुरक्षा है: dynamic विश्लेषण उतना ही अच्छा है जितना उसका निकाला हुआ period, और ज़रूरत से ज़्यादा लचीला model वरना एक सुकून देने वाला छोटा बल लौटा देता।",
    eg: "Zone III में 20-मंज़िला नियमित frame का response spectrum से विश्लेषण होता है, और अगर उससे निकला base shear मान लीजिए static मान का 80 प्रतिशत आए, तो परिणामों का हर बल और विस्थापन design से पहले 1.25 से गुणा किया जाएगा।",
    tip: "कड़े podium या basement वाली इमारत में 90 प्रतिशत mass participation का पीछा करना model बनाने का आम फंदा है — restrained स्तरों में बँधा द्रव्यमान कभी भाग लेता ही नहीं। जाँच लीजिए कि आप जो modes गिन रहे हैं वे इमारत के उसी हिस्से के हैं जो सचमुच हिलने के लिए स्वतंत्र है।",
  },

  "t-1893-separation": {
    what: "Cl. 7.11.3 माँगता है कि दो सटी हुई इमारतें, या एक ही इमारत की joint से अलग की गई दो इकाइयाँ, कम से कम उनके निकाले गए storey विस्थापनों के योग के R गुना दूर रखी जाएँ, ताकि एक-दूसरे की ओर झुकने पर वे टकराएँ नहीं। जहाँ दोनों इकाइयों के floor एक ही ऊँचाई पर हों, वहाँ R की जगह R/2 लिया जा सकता है — क्योंकि floor का floor से टकराना उस नुकसान से कहीं कम है जो floor slab के किसी column को उसकी आधी ऊँचाई पर मारने से होता है।",
    why: "R यहाँ भी उसी वजह से आता है जिस वजह से हर जगह आता है: निकाले गए विस्थापन घटे हुए design बल से आए हैं, इसलिए तेज़ भूकंप में असली विस्थापन कई गुना बड़े होंगे। सिर्फ़ विश्लेषण के विस्थापन से दरार का आकार निकालना उसे कई गुना छोटा कर देता है। अपर्याप्त दूरी वाली इमारतों का आपस में टकराना (pounding) घनी शहरी बस्तियों में भूकंप-नुकसान का सबसे बार-बार दिखने वाला रूप है, और उसका सबसे बुरा प्रकार ठीक वही है जिसे R/2 की छूट बाहर रखती है — एक इमारत का कड़ा floor slab बग़ल वाली इमारत के column को उसकी आधी ऊँचाई पर हथौड़े की तरह मारे।",
    eg: "एक ही इमारत के दो blocks, floor मेल खाती ऊँचाइयों पर, R = 5, और हर एक की छत पर निकाला गया storey विस्थापन 20 mm: ज़रूरी अलगाव = (5/2) × (20 + 20) = 100 mm — जो तापीय expansion joint के लिए चाहिए होने वाले 25 या 50 mm से कहीं ज़्यादा है।",
    tip: "Seismic ज़ोन में expansion joint की चौड़ाई यही clause तय करता है, तापीय हरकत की गणना नहीं। दोनों निकालिए और बड़ा वाला लीजिए; Zones IV और V में seismic वाली शर्त लगभग हमेशा जीतती है।",
  },

});
