/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   Chapter 11 — Staircases, Walls and Other Elements
   Chapter 12 — Detailing and Bar Bending Schedule

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "rcc"; });
  if (!hb) return;

  hb.chapters.push(

    /* =========================================================== CH 11 */
    {
      id: "rcc-11",
      n: 11,
      title: "Staircases, Walls and Other Elements",
      hi: "सीढ़ियाँ, दीवारें और अन्य अंग",
      blurb: "The members that are not beams, slabs or columns — and how each one is handled by bending the same rules to a different geometry.",
      mins: 58,
      sections: [

        {
          n: "11.1",
          title: "Staircases",
          hi: "सीढ़ियाँ",
          blocks: [
            { k: "p", t: "A stair flight is an inclined one-way slab. The steps are not structure — they are load sitting on the <em>waist</em>, the sloping slab that actually spans. Recognising that is most of the design." },
            { k: "dia", id: "hb-rcc-stair", cap: "The waist spans; the steps ride on it. The effective span runs from landing to landing." },
            { k: "def", term: "Rise, tread and going", t: "The <strong>rise</strong> R is the height of one step and the <strong>tread</strong> T its horizontal depth. The <strong>going</strong> is the total horizontal length of the flight — the number of treads times T, which is one less than the number of risers. A comfortable stair satisfies roughly 2R + T ≈ 600 mm; 150/300 and 165/270 are the usual Indian combinations." },
            { k: "cmp", t: "Step proportions — planning guidelines", cols: ["Public buildings", "Residential / factory"], rows: [["Tread T", "≈ 300 mm (250–300)", "down to ≈ 250 mm (220–250)"], ["Rise R", "≈ 150 mm (120–150)", "up to ≈ 190 mm (150–180)"], ["Comfort rule", "T + 2R between 500 and 650 mm", "same"]] },
            { k: "note", t: "These are planning guidelines, not IS 456 requirements — IS 456 does not fix step proportions; building bye-laws and the National Building Code do. Values outside brackets are from <a href=\"https://bitmangalore.edu.in/wp-content/uploads/2025/05/BCV601-MODULE_4.pdf\" target=\"_blank\" rel=\"noopener\">BIT Mangalore BCV601 lecture notes</a> (300/150 ideal for public buildings; treads down to 250 mm with risers up to 190 mm in residential and factory buildings); the bracketed ranges and the T + 2R band are from <a href=\"https://sist.sathyabama.ac.in/sist_coursematerial/uploads/SCI1308.pdf\" target=\"_blank\" rel=\"noopener\">Sathyabama SCI1308 notes</a>. The two sources overlap but are not identical, so check the bye-law that applies to your project." },
            { k: "h", t: "Effective span" },
            { k: "p", t: "Cl. 33.1 distinguishes three support arrangements, and the span rule depends on which one you have (summarised this way, with the clause letters, in <a href=\"https://bitmangalore.edu.in/wp-content/uploads/2025/05/BCV601-MODULE_4.pdf\" target=\"_blank\" rel=\"noopener\">BIT Mangalore BCV601 lecture notes</a>):" },
            { k: "list", items: [
              "<strong>(a) Flight supported at the top and bottom risers by beams spanning parallel to the risers</strong> — effective span = centre-to-centre distance between those beams.",
              "<strong>(b) Flight spanning on to the edge of a landing slab that itself spans parallel to the risers</strong> (across the stair, between side walls or beams) — effective span = <strong>going + at each end either half the landing width or 1 m, whichever is smaller</strong>.",
              "<strong>(c) Landing slab spanning in the same direction as the flight</strong> (flight and landings act as one longitudinal slab) — effective span = centre-to-centre distance between the supporting beams or walls.",
            ]},
            { k: "p", t: "Where an open-well stair has spans partly crossing at right angles, Cl. 33.2 allows the load on the area common to the two spans to be shared one-half in each direction." },
            { k: "note", t: "<b>Correction (v35):</b> an earlier version attached the ‘going + half landing (≤ 1 m)’ rule to a flight spanning ‘between landing beams or walls at each end’. That rule is case (b) — a flight bearing on a landing that spans <em>across</em> the stair. A flight carried by beams at its top and bottom risers is case (a), and its span is simply the centre-to-centre distance of those beams." },
            { k: "h", t: "Loads, and the slope factor" },
            { k: "p", t: "Design is carried out per <strong>horizontal</strong> metre, because that is how the span is measured — but the waist itself is sloping and therefore longer than the horizontal projection. Its self weight must be increased accordingly:" },
            { k: "eq", expr: "waist weight per horizontal m² = t × 25 × √(R² + T²) / T", where: [
              ["t", "waist thickness, m"],
              ["25", "unit weight of reinforced concrete, kN/m³ (IS 875 Part 1)"],
            ]},
            { k: "p", t: "For the common 150/300 step that factor is √(150² + 300²)/300 = 1.118 — about 12% more waist weight than the flat thickness suggests. The steps themselves form triangles on top of the waist, and their weight averaged over the plan area is simply ½ × R × 25 per m²." },
            { k: "trap", t: "The slope factor applies to the <strong>waist only</strong>. The step weight, the finishes and the live load already act on the horizontal plan area and must not be multiplied by it again. On the landing there is no slope at all, so the landing load is the flat one." },
          ],
        },

        {
          n: "11.2",
          title: "A stair designed",
          hi: "सीढ़ी का डिज़ाइन",
          blocks: [
            { k: "eg",
              title: "Example 11.1 — Dog-legged stair flight",
              given: "10 risers of 150 mm and 9 treads of 300 mm, so the going is 2.7 m. Landings 1.2 m wide at each end, each spanning across the stair between side walls — so this is case (b) of Cl. 33.1. Live load 3 kN/m², floor finish 1 kN/m². M20 concrete, Fe 415 steel, cover 20 mm.",
              steps: [
                { t: "Effective span (Cl. 33.1 b)", w: "half of each landing = 0.6 m  (less than 1 m, so 0.6 governs)\nleff = 2.7 + 0.6 + 0.6 = 3.9 m" },
                { t: "Trial waist thickness", w: "l/d for a simply supported slab, with the usual modification factor, is about 26\nd ≈ 3900/26 = 150 mm  →  try a 200 mm waist\nd = 200 − 20 (cover) − 6 (half of a 12 mm bar) = 174 mm" },
                { t: "Slope factor", w: "√(150² + 300²)/300 = 335.4/300 = 1.118" },
                { t: "Loads per horizontal m² on the flight", w: "waist       0.200 × 25 × 1.118 = 5.59 kN/m²\nsteps       0.5 × 0.150 × 25   = 1.875\nfinish                          = 1.00\nlive                            = 3.00\ntotal w = 11.47 kN/m²\nwu = 1.5 × 11.47 = 17.20 kN/m²" },
                { t: "Design moment", w: "Taking the flight load over the whole span (conservative, since the landing is lighter):\nMu = 17.20 × 3.9²/8 = 32.70 kNm per metre width" },
                { t: "Steel", w: "Mu,lim = 0.138 × 20 × 1000 × 174² = 83.6 kNm  ≫  32.70  ✓\n7.4918 Ast² − 62,823 Ast + 32.70 × 10⁶ = 0\nAst = [62,823 − 54,469]/14.984 = 558 mm² per metre\nProvide 12 mm @ 200 mm c/c = 565 mm²  ✓" },
                { t: "Distribution steel", w: "0.12% × 1000 × 200 = 240 mm²/m\n8 mm @ 200 mm c/c = 251 mm²  ✓" },
                { t: "Deflection check", w: "pt = 100 × 565/(1000 × 174) = 0.325%\nfs = 0.58 × 415 × 558/565 = 237 N/mm²\nModification factor (Fig. 4) ≈ 1.46  →  permitted l/d = 20 × 1.5 = 30\nProvided l/d = 3900/174 = 22.4  <  30  ✓" },
              ],
              ans: "200 mm waist, main steel 12 mm @ 200 mm c/c running up the flight, distribution steel 8 mm @ 200 mm c/c across it.",
            },
            { k: "trap", t: "A 150 mm waist (d = 124 mm) satisfies the moment easily — Ast ≈ 731 mm²/m — but the higher steel ratio (pt ≈ 0.59%) drops the modification factor to about 1.17, so the permitted l/d is only ≈ 23 against a provided 3900/124 = 31.5. It fails deflection outright. In a stair, as in a slab, it is deflection that fixes the thickness. Start there." },
            { k: "note", t: "The reinforcement at the junction of a flight and a landing needs care. Where the bend is re-entrant, tension in the bar tends to straighten it and push the concrete off the inside of the corner. The bars are therefore detailed to run round the <em>outside</em> of the bend, or lapped so that the tension is never carried round a re-entrant corner by a single bar." },
          ],
        },

        {
          n: "11.3",
          title: "Retaining walls",
          hi: "रिटेनिंग वॉल",
          blocks: [
            { k: "p", t: "A retaining wall holds back a height of soil. Unlike everything else in this handbook, it usually fails as a <strong>rigid body</strong> — sliding, tipping or overloading the ground — long before its concrete is overstressed. So the stability checks come first and the reinforcement design comes second." },
            { k: "dia", id: "hb-rcc-retwall", cap: "The three stability checks, and where the resisting weight comes from." },
            { k: "def", term: "Active earth pressure", t: "The pressure the retained soil exerts when the wall moves very slightly away from it — which any real wall does. It increases linearly with depth, giving a triangular distribution: pa = Ka γ z, and a total thrust Pa = ½ Ka γ H² acting at H/3 above the base." },
            { k: "eq", expr: "Ka = (1 − sin φ) / (1 + sin φ)", where: [
              ["φ", "angle of internal friction of the retained soil"],
              ["γ", "unit weight of the retained soil, kN/m³"],
            ]},
            { k: "p", t: "This is Rankine's coefficient for a level backfill with no wall friction. For a typical granular fill with φ = 30°, Ka = 1/3 — a convenient number that hides how sensitive the result is: at φ = 25° it is 0.41, about 22% more thrust. The passive coefficient Kp = (1 + sin φ)/(1 − sin φ) = 1/Ka — 3.0 at φ = 30° — is what a shear key mobilises in front of it." },
            { k: "h", t: "The three checks" },
            { k: "list", items: [
              "<strong>Overturning</strong> about the toe — restoring moment from the weights against the overturning moment from the thrust.",
              "<strong>Sliding</strong> along the base — friction μΣW against the horizontal thrust. μ is typically 0.4 to 0.5 for soil on concrete.",
              "<strong>Bearing pressure</strong> under the base. The maximum must not exceed the SBC, and the minimum must not go negative — keep the resultant within the middle third.",
            ]},
            { k: "h", t: "How much safety — two ways of stating it" },
            { k: "cmp", t: "Stability criteria for a retaining wall", cols: ["IS 456 Cl. 20 (factored form)", "Classical FOS (practice)"], rows: [
              ["Overturning", "0.9 × restoring moment from dead load ≥ 1.2 × overturning moment from dead load + 1.4 × overturning moment from imposed load", "Mr / Mo ≥ 1.5 (EngineeringHulk) — many designers use 2.0"],
              ["Sliding", "factor ≥ 1.4, taking only 0.9 × the characteristic dead load as resisting", "μΣW / Pa ≥ 1.5"],
            ]},
            { k: "note", t: "Sources: the Cl. 20.1 wording (1.2 × dead-load overturning + 1.4 × imposed-load overturning; only 0.9 × dead load where dead load restores) is quoted by <a href=\"https://testbook.com/question-answer/the-stability-of-a-structure-as-a-whole-against-ov--615ed87a5995ff9aa070e9bf\" target=\"_blank\" rel=\"noopener\">Testbook (quoting Cl. 20.1)</a>; the sliding factor of 1.4 with 0.9 × dead load is used in <a href=\"https://gcekbpatna.ac.in/assets/documents/lecturenotes/1671874900_4b7c4a492b6b254c7625.pdf\" target=\"_blank\" rel=\"noopener\">GCE Katihar retaining-wall notes</a>; the plain 1.5 / 1.5 service factors are from <a href=\"https://engineeringhulk.com/civil/rcc-design/retaining-wall/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>. The two approaches are <strong>not numerically identical</strong> — Example 11.2 below checks the same wall both ways. Earth thrust is usually treated as the imposed-type load in the Cl. 20.1 check; state your assumption on the calculation." },
            { k: "h", t: "Trial proportions" },
            { k: "cmp", t: "Trial proportions of a cantilever retaining wall (H = total height)", cols: ["GCE Katihar notes", "EngineeringHulk"], rows: [
              ["Base width b", "0.4H – 0.6H", "0.5H – 0.7H (start at 0.6H)"],
              ["Toe projection", "0.3b – 0.4b", "not stated"],
              ["Base slab thickness", "H/10 – H/15, not less than 300 mm", "H/10 – H/12, not less than 300 mm"],
              ["Stem thickness at base", "8–10% of H, not less than 300 mm (≈150 mm at top)", "H/10 – H/12, not less than 200 mm"],
            ]},
            { k: "p", t: "These are starting points to be confirmed by the three checks, not code values; the two sources differ mainly on base width. If sliding governs, a <strong>shear key</strong> — a downstand under the base, usually below the stem and cast against undisturbed soil — adds passive resistance Pp = ½ Kp γ [(D + a)² − D²] for a key of depth a below a base at depth D (<a href=\"https://engineeringhulk.com/civil/rcc-design/retaining-wall/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a>)." },
            { k: "note", t: "The weight doing most of the resisting is the <strong>soil sitting on the heel</strong>, not the concrete. That is why a cantilever retaining wall has a long heel and a short toe, and why backfilling is a structural operation rather than a finishing one — a wall is not stable until its heel is loaded." },
          ],
        },

        {
          n: "11.4",
          title: "A retaining wall checked",
          hi: "रिटेनिंग वॉल की जाँच",
          blocks: [
            { k: "eg",
              title: "Example 11.2 — Stability of a cantilever retaining wall",
              given: "Overall height H = 4.0 m. Base 2.2 m wide and 0.4 m thick: toe 0.6 m, stem 0.3 m thick, heel 1.3 m. Backfill γ = 18 kN/m³, φ = 30°, level, no surcharge. Coefficient of friction at the base μ = 0.5. SBC = 150 kN/m². Concrete 25 kN/m³.",
              steps: [
                { t: "Active thrust", w: "Ka = (1 − sin30°)/(1 + sin30°) = 0.5/1.5 = 1/3\nPa = ½ × (1/3) × 18 × 4.0² = 48.0 kN per metre run\nacting at H/3 = 1.333 m above the base" },
                { t: "Overturning moment about the toe", w: "Mo = 48.0 × 1.333 = 64.0 kNm/m" },
                { t: "Resisting weights and their lever arms from the toe", w: "stem      0.3 × 3.6 × 25  = 27.00 kN   at 0.75 m\nbase      2.2 × 0.4 × 25  = 22.00 kN   at 1.10 m\nsoil on heel 1.3 × 3.6 × 18 = 84.24 kN   at 1.55 m\nΣW = 133.24 kN/m" },
                { t: "Check 1 — overturning", w: "Mr = 27.00×0.75 + 22.00×1.10 + 84.24×1.55\n   = 20.25 + 24.20 + 130.57 = 175.02 kNm/m\nFOS = 175.02/64.0 = 2.73  >  2  ✓" },
                { t: "Check 2 — sliding", w: "Resisting friction = μ ΣW = 0.5 × 133.24 = 66.62 kN\nFOS = 66.62/48.0 = 1.39  <  1.5  ✗ FAILS" },
                { t: "Check 3 — bearing pressure", w: "Position of the resultant from the toe:\nx̄ = (175.02 − 64.0)/133.24 = 0.833 m\ne = 2.2/2 − 0.833 = 0.267 m;  b/6 = 0.367 m  →  e < b/6  ✓ within the middle third\npmax = (133.24/2.2)(1 + 6×0.267/2.2) = 60.56 × 1.728 = 104.6 kN/m²  <  150  ✓\npmin = 60.56 × 0.272 = 16.5 kN/m²  >  0  ✓" },
                { t: "Check 4 — the same wall in the IS 456 Cl. 20 format", w: "Overturning (thrust taken as imposed-type load):\n0.9 × 175.02 = 157.5 kNm  ≥  1.4 × 64.0 = 89.6 kNm  ✓\n(equivalent to Mr/Mo = 2.73 ≥ 1.4/0.9 = 1.56)\nSliding: 0.9 × 66.62 / 48.0 = 1.25  <  1.4  ✗ FAILS" },
              ],
              ans: "Overturning and bearing are satisfactory; sliding fails — 1.39 against 1.5 in the classical form, 1.25 against 1.4 in the IS 456 Cl. 20 form. The remedies, in order of cost: add a shear key under the base (mobilising passive resistance in front of it), lengthen the heel so ΣW grows, or thicken the base. A shear key is almost always the cheapest.",
            },
            { k: "trap", t: "Sliding failing while overturning passes comfortably is the normal pattern, not an unlucky set of numbers. Overturning resistance grows with the <em>lever arm</em> of the weight, sliding resistance only with its <em>magnitude</em> — so widening the base helps overturning far more than it helps sliding. Check sliding early." },
            { k: "p", t: "Once stability is satisfied, the structural design follows familiar lines: the stem is a vertical cantilever carrying the triangular earth pressure, the heel a cantilever carrying the soil above it less the upward bearing pressure, and the toe a cantilever carrying the upward bearing pressure less its own weight. Each is a one-way slab strip designed by Chapter 3." },
            { k: "eg",
              title: "Example 11.3 — Stem of the wall in Example 11.2",
              given: "Stem 300 mm thick, height above the base h = 3.6 m. Ka = 1/3, γ = 18 kN/m³, level backfill. M20, Fe 415, 12 mm bars, clear cover 50 mm on the earth face. Load factor 1.5 on the earth pressure.",
              steps: [
                { t: "Moment and shear at the base of the stem", w: "M = Ka γ h³/6 = (1/3)(18)(3.6³)/6 = 46.66 kNm/m  →  Mu = 1.5 × 46.66 = 69.98 kNm/m\nV = ½ Ka γ h² = ½ (1/3)(18)(3.6²) = 38.88 kN/m  →  Vu = 58.32 kN/m" },
                { t: "Effective depth and limiting moment", w: "d = 300 − 50 − 6 = 244 mm\nMu,lim = 0.138 × 20 × 1000 × 244² = 164.3 kNm  >  69.98  ✓ singly reinforced" },
                { t: "Main steel on the earth face", w: "7.4918 Ast² − 88,097 Ast + 69.98 × 10⁶ = 0\nAst = 857 mm²/m\nProvide 12 mm @ 130 mm c/c = 870 mm²/m  ✓" },
                { t: "Shear", w: "τv = 58.32 × 10³/(1000 × 244) = 0.24 N/mm²\npt = 100 × 870/(1000 × 244) = 0.357%  →  τc ≈ 0.41 N/mm² (Table 19, M20)\nτv < τc  ✓ no shear reinforcement (checking at the base is conservative)" },
                { t: "Curtailment — moment falls as the cube of depth", w: "Alternate bars stopped leaves 12 @ 260 = 435 mm²/m\nMu of that steel = 0.87 × 415 × 435 × 244 × (1 − 435 × 415/(1000 × 244 × 20)) = 36.9 kNm\nDepth below the top where Mu = 36.9: 3.6 × (36.9/69.98)^(1/3) = 2.91 m, i.e. 0.69 m above the base\nExtend by d = 244 mm (> 12φ = 144): stop alternate bars ≈ 0.94 m → say 1.0 m above the base\nLength from the base 1000 mm  >  Ld = 564 mm  ✓" },
                { t: "Distribution steel", w: "0.12% × 1000 × 300 = 360 mm²/m  →  8 mm @ 130 mm c/c = 387 mm²/m (horizontal)" },
              ],
              ans: "12 mm @ 130 mm c/c vertical on the earth face, alternate bars stopped 1.0 m above the base; 8 mm @ 130 mm c/c horizontal; no shear reinforcement needed.",
            },
            { k: "note", t: "Cover on the earth face is set by exposure (IS 456 Table 16) and by practice for members cast against or in contact with soil; sources differ — <a href=\"https://engineeringhulk.com/civil/rcc-design/retaining-wall/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk</a> uses 40 mm on earth-exposed faces, <a href=\"https://gcekbpatna.ac.in/assets/documents/lecturenotes/1671874900_4b7c4a492b6b254c7625.pdf\" target=\"_blank\" rel=\"noopener\">GCE Katihar retaining-wall notes</a> uses 60 mm. 50 mm is used here; confirm the exposure class for your site. Because the moment varies as h³, half the steel is already redundant 0.69 m above the base — curtailing it is the main economy in a cantilever stem." },
          ],
        },

        {
          n: "11.5",
          title: "Deep beams",
          hi: "डीप बीम",
          blocks: [
            { k: "p", t: "Everything in Chapters 3 to 5 rests on the assumption that plane sections remain plane. That holds when a beam is slender. It stops holding when the beam is deep relative to its span, because shear deformation stops being negligible and the strain distribution is no longer linear — it becomes markedly non-linear, and the neutral axis does not sit where the flexural formula says." },
            { k: "p", t: "IS 456 Cl. 29 defines a beam as deep when the ratio of effective span to overall depth is less than 2.0 for a simply supported beam, or 2.5 for a continuous one (confirmed in the <a href=\"https://www.madeeasy.in/Uploads/examsolution/1491uf_01JPCERCC07-08-2026-SOLUTIONS.pdf\" target=\"_blank\" rel=\"noopener\">MADE EASY solution key</a>). The effective span is the centre-to-centre distance between supports or 1.15 times the clear span, whichever is smaller. Below those ratios the ordinary rules do not apply." },
            { k: "eq", expr: "Simply supported:  z = 0.2 (l + 2D)  for 1 ≤ l/D ≤ 2;   z = 0.6 l  for l/D < 1", where: [
              ["z", "lever arm used in Ast = Mu / (0.87 fy z)"],
              ["l, D", "effective span and overall depth"],
            ]},
            { k: "eq", expr: "Continuous:  z = 0.2 (l + 1.5D)  for 1 ≤ l/D ≤ 2.5;   z = 0.5 l  for l/D < 1", where: [
              ["z", "lever arm (Cl. 29.2)"],
            ]},
            { k: "p", t: "A built-in consistency check: at l/D = 1 the first formula gives 0.2 × 3l = 0.6l and the second 0.2 × 2.5l = 0.5l — exactly the values used below l/D = 1, so each pair joins without a jump. (Formulae from the <a href=\"https://www.indiabix.com/civil-engineering/structural-design-specifications/discussion-4922\" target=\"_blank\" rel=\"noopener\">IndiaBix discussion of Cl. 29.2</a> and the <a href=\"https://www.civilengineeringweb.com/2023/07/deep-beam-design-criteria.html\" target=\"_blank\" rel=\"noopener\">CivilEngineeringWeb summary of Cl. 29</a>.)" },
            { k: "list", items: [
              "The lever arm is much smaller than d − 0.42xu and is given directly by Cl. 29.2 as a function of l/D, rather than computed from a stress block.",
              "The positive (sagging) tension steel must <strong>extend without curtailment between supports</strong>, be embedded beyond the face of each support so that it has a development length of <strong>at least 0.8 Ld</strong> there, and be placed within a zone of depth <strong>0.25D − 0.05l</strong> adjacent to the tension face (Cl. 29.3.1, as summarised by <a href=\"https://www.civilengineeringweb.com/2023/07/deep-beam-design-criteria.html\" target=\"_blank\" rel=\"noopener\">CivilEngineeringWeb summary of Cl. 29</a>). There is no point of contraflexure to curtail against, and the tension is nearly constant along the span.",
              "The load is carried mainly by direct strut action from the load to the support, so web reinforcement on both faces is needed to control the cracking that runs along the strut (Cl. 29.3).",
            ]},
            { k: "eg",
              title: "Example 11.4 — Tension steel in a transfer girder",
              given: "Simply supported transfer girder, effective span l = 6.0 m, overall depth D = 4.0 m, factored moment Mu = 3000 kNm, Fe 415.",
              steps: [
                { t: "Is it deep?", w: "l/D = 6.0/4.0 = 1.5  <  2.0  →  deep beam (Cl. 29)" },
                { t: "Lever arm (Cl. 29.2, 1 ≤ l/D ≤ 2)", w: "z = 0.2 (l + 2D) = 0.2 (6.0 + 8.0) = 2.8 m" },
                { t: "Steel", w: "Ast = Mu/(0.87 fy z) = 3000 × 10⁶/(0.87 × 415 × 2800) = 2968 mm²" },
                { t: "Zone for the bars", w: "0.25D − 0.05l = 0.25 × 4000 − 0.05 × 6000 = 1000 − 300 = 700 mm above the soffit" },
                { t: "What the ordinary rule would have given", w: "taking z ≈ 0.9d with d ≈ 3.9 m: z ≈ 3.51 m  →  Ast ≈ 2367 mm²\nabout 20% too little steel" },
              ],
              ans: "About 2970 mm² (e.g. 10 bars of 20 mm = 3142 mm²) spread over the bottom 700 mm, run unbroken between supports and anchored for 0.8 Ld beyond each support face.",
            },
            { k: "note", t: "Transfer girders, pile caps, walls acting as deep beams over openings and the side walls of rectangular water tanks are all deep-beam problems. The modern approach for all of them is the strut-and-tie model: sketch the load path as a truss of concrete struts and steel ties, and provide steel for the ties." },
          ],
        },

        {
          n: "11.6",
          title: "Corbels and brackets",
          hi: "कॉर्बल और ब्रैकेट",
          blocks: [
            { k: "p", t: "A corbel is a short cantilever projecting from a column or wall, typically supporting a precast beam or a crane rail. IS 456 Cl. 28 defines it as one where the shear span does not exceed the effective depth — so short that, like a deep beam, it does not bend in the ordinary sense." },
            { k: "p", t: "It behaves as a simple truss: an inclined concrete strut running from the load down into the column, and a horizontal steel tie across the top holding the strut's outward thrust. Almost all of the reinforcement is that tie, placed as close to the top face as cover allows, and it must be anchored at both ends — welded to a transverse bar or looped, because a straight bar has nowhere near enough length in a corbel to develop." },
            { k: "list", items: [
              "<strong>Design for a horizontal force as well as the vertical one.</strong> Shrinkage, creep and thermal movement of the supported beam push or pull on the bearing; Eurocode-based practice designs for a horizontal force of at least 0.2 × the vertical load unless the bearing is specially detailed to release it.",
              "<strong>Anchor the tie beyond the bearing</strong> — U-hoops, loops or a welded cross bar at the front face, so the tie is fully developed at the outer node under the bearing plate.",
              "<strong>Provide closed horizontal links</strong> through the depth to control splitting along the strut; Eurocode-based practice asks for a total area of at least 0.4 × the main tie area in corbels deeper than about 300 mm.",
            ]},
            { k: "note", t: "The three rules above are the Eurocode 2 treatment as explained by <a href=\"https://structville.com/2020/07/structural-design-of-corbels.html\" target=\"_blank\" rel=\"noopener\">Structville</a> — general engineering practice, labelled as such, not a quotation of IS 456. IS 456 Cl. 28.2 gives its own design provisions for corbels; use the published clause for the Indian code values." },
            { k: "trap", t: "Corbels are frequently detailed with the main bars bent down into the face of the corbel, which looks tidy and leaves the tie unanchored at exactly the point of maximum force. The characteristic failure is a crack opening at the re-entrant corner and the whole corbel dropping off the column. The anchorage of the tie at the front face is required by every code treatment; it is not optional." },
          ],
        },

        {
          n: "11.7",
          title: "Liquid-retaining structures",
          hi: "द्रव-धारक संरचनाएँ",
          blocks: [
            { k: "p", t: "For a liquid-retaining structure the governing requirement is not strength but <strong>watertightness</strong> — which means keeping cracks small enough that the structure does not leak and its reinforcement does not corrode. Everything special about tank design follows from that." },
            { k: "list", items: [
              "<strong>Codes.</strong> IS 3370 covers concrete structures for the storage of liquids: Part 1 (general requirements) and Part 2 (reinforced concrete) were revised in 2009; Parts 3 (prestressed) and 4 (design tables) are older. IS 456 governs everything IS 3370 does not cover.",
              "<strong>Two permitted design routes.</strong> IS 3370 (Part 2):2009 allows <em>limit state design</em> with a check on the calculated surface crack width — 0.2 mm generally, 0.1 mm for the more severe exposures — <em>or</em> working stress design with low permissible steel stresses (130 N/mm² for deformed bars and 115 N/mm² for mild steel), which control crack width indirectly.",
              "<strong>Concrete.</strong> Minimum M30 for reinforced concrete (M20 for plain concrete), maximum w/c 0.45, cement content 320–400 kg/m³ — the upper limit to control shrinkage.",
              "<strong>Minimum reinforcement</strong> is now calculated on the <em>surface zones</em> of the section rather than its whole thickness, because shrinkage and temperature cracking is controlled by the steel near each face.",
              "<strong>Load cases.</strong> Members are designed for the tank both full and empty, since the two produce opposite moments, and a wall restrained at its base is checked for both.",
            ]},
            { k: "note", t: "Sources: design routes and crack-width limits from <a href=\"https://law.resource.org/pub/in/bis/S03/is.3370.2.2009.pdf\" target=\"_blank\" rel=\"noopener\">the standard as published on Public.Resource.Org</a>; the 130/115 N/mm² stresses, the M30 minimum and the surface-zone basis for minimum steel from an <a href=\"https://www.ijert.org/effects-on-intz-type-tank-with-code-revision-of-is3370-1965-to-2009\" target=\"_blank\" rel=\"noopener\">IJERT study comparing IS 3370:1965 and 2009</a>; M30/M20, w/c 0.45, 320–400 kg/m³ and a minimum nominal cover of 45 mm from <a href=\"https://testbook.com/question-answer/as-per-codal-provisions-of-is-3370-minimum-grade--6399a9eb19b214e641d3c119\" target=\"_blank\" rel=\"noopener\">Testbook</a>. <b>Conflict:</b> a secondary summary (<a href=\"https://infralens.in/code/IS-3370-Part-2-2009\" target=\"_blank\" rel=\"noopener\">Infralens</a>) gives cover as 40 mm on liquid faces, 30 mm on air faces and 50 mm for sewage — check the cover clause of IS 3370 (Part 2):2009 before using either figure." },
            { k: "note", t: "<b>Correction (v35):</b> an earlier version said tanks are ‘designed largely by the working stress method’ and that limit state design is ‘the wrong instrument’ for them. That described IS 3370:1965. Since the 2009 revision, limit state design with an explicit crack-width check is a permitted — and often more economical — route; the IJERT study above reports a large saving in wall steel for an Intze tank designed that way. Working stress remains permitted and is still common because it is simple and conservative." },
            { k: "note", t: "The same reasoning explains why IS 456's Annex B still exists. Working stress is not obsolete — it is a legitimate way of satisfying a serviceability requirement when crack control, not strength, is what governs." },
          ],
        },

        {
          n: "11.8",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "A stair is an inclined one-way slab: the waist spans, the steps are load, and the waist weight carries the √(R²+T²)/T factor.",
              "Stair effective span depends on the support case (Cl. 33.1): c/c of beams at the risers (a), going + half landing capped at 1 m each end when the landing spans across the stair (b), or c/c of supports when landing and flight span together (c).",
              "A retaining wall is checked for overturning, sliding and bearing before any steel is calculated — either as classical factors of safety or in the IS 456 Cl. 20 factored form — and sliding is usually the one that fails. The stem moment varies as h³, so half its steel can be curtailed low down.",
              "Deep beams (Cl. 29: l/D < 2 simply supported, < 2.5 continuous; z from Cl. 29.2; steel uncurtailed in the bottom 0.25D − 0.05l) and corbels (Cl. 28) break the plane-sections assumption and are handled by strut-and-tie thinking.",
              "Liquid-retaining structures are designed to IS 3370 (Part 2):2009 — by limit state with a crack-width check, or by working stress with low steel stresses — because crack width governs.",
            ]},
            { k: "p", t: "One chapter remains, and it is the one that decides whether everything in the previous eleven actually reaches the building. A design exists on paper; a structure is built from a drawing and a bar bending schedule." },
          ],
        },
      ],
    },

    /* =========================================================== CH 12 */
    {
      id: "rcc-12",
      n: 12,
      title: "Detailing and Bar Bending Schedule",
      hi: "डिटेलिंग और बार बेंडिंग शेड्यूल",
      blurb: "The step where calculations become a building — and where most real failures actually originate.",
      mins: 46,
      sections: [

        {
          n: "12.1",
          title: "Where designs actually fail",
          hi: "डिज़ाइन असल में कहाँ फेल होते हैं",
          blocks: [
            { k: "p", t: "Investigations of reinforced concrete failures rarely find an arithmetic error. They find reinforcement that was correctly calculated and then placed somewhere it could not work: bars stopped short of where the tension was, laps in the wrong position, cover that was never achieved because there were no spacers, stirrups closed with a lap in the cover rather than a hook in the core." },
            { k: "p", t: "There is a reason for that concentration. The calculation is checked — by the designer, by a senior, sometimes by an approving authority. The detail is drawn once, read by a bar bender who was not part of any of those conversations, and executed by someone working to a schedule of lengths. Every assumption the calculation made has to survive that journey, and it only survives if it was drawn." },
            { k: "def", term: "Detailing", t: "Deciding where every bar starts, stops, bends and laps, and communicating it so that it is built that way. It is the part of design that is about the load <em>path</em> rather than the load — about making sure the force has somewhere continuous to go at every point in the structure." },
          ],
        },

        {
          n: "12.2",
          title: "Cover, and why it is measured where it is",
          hi: "कवर और उसकी माप",
          blocks: [
            { k: "p", t: "Nominal cover (Cl. 26.4) is the distance from the concrete surface to the <strong>outside of the outermost bar</strong> — which in a beam means the stirrup, not the main bar. It has three separate jobs, and the governing value is whichever of them asks for most." },
            { k: "list", items: [
              "<strong>Durability</strong> — Cl. 26.4.2 and Table 16 fix it by exposure condition. This is normally the one that governs.",
              "<strong>Fire resistance</strong> — Cl. 26.4.3 and Table 16A fix it by the required fire rating, because steel loses strength quickly once it is hot.",
              "<strong>Bond</strong> — Cl. 26.4.1 requires the cover to be at least the bar diameter, so that the concrete around the bar can actually grip it.",
            ]},
            { k: "trap", t: "Cover that is drawn but not spaced is not cover. Cover blocks of the correct depth, at the correct frequency, are what puts the steel where the drawing says; without them the cage sits on the formwork and the bottom bars end up with nothing under them. The most common durability failure on Indian sites is not bad concrete — it is good concrete with the steel in the wrong place." },
            { k: "p", t: "Spacing rules (Cl. 26.3.2) are the other half of the same idea: the horizontal gap between bars must be at least the largest bar diameter or the maximum aggregate size plus 5 mm, so the concrete can actually get between them. A congested cage produces honeycombing exactly where the steel is densest — usually at a beam-column joint." },
          ],
        },

        {
          n: "12.3",
          title: "Continuity at joints",
          hi: "जोड़ों पर निरंतरता",
          blocks: [
            { k: "p", t: "The bending moment diagram tells you where tension is. Detailing is the business of making sure there is a bar there, anchored well enough to develop the stress it is being asked to carry." },
            { k: "dia", id: "hb-rcc-joint", cap: "A joint is where two members' reinforcement must become one continuous load path." },
            { k: "list", items: [
              "<strong>At an interior support</strong> of a continuous beam the moment is hogging, so the tension is at the <em>top</em>. Top bars must be continuous through the support, extending far enough either side to cover the whole hogging region.",
              "<strong>At supports</strong>, Cl. 26.2.3.3(a) requires at least <strong>one-third</strong> of the positive-moment steel in simple members, and <strong>one-fourth</strong> in continuous members, to extend along the same face into the support for a length of Ld/3 — the same fractions as <a href=\"https://help.idecad.com/ideCAD/flexural-reinforcement-brd\" target=\"_blank\" rel=\"noopener\">ACI 318 §9.7.3.8</a>. At a simple support the bars must also satisfy the 1.3 M1/V + L0 ≥ Ld check of Chapter 5.",
              "<strong>At a beam-column joint</strong>, beam top bars are taken through the joint and anchored with a standard bend down the far face of the column where the beam does not continue.",
              "<strong>Column laps</strong> — under lateral load a column's moment is greatest at its ends, next to the beams, and least near mid-height. Earthquake-resistant detailing therefore requires laps <strong>only in the middle half of the column height</strong>, with ties at no more than 150 mm along the lap (<a href=\"https://ddma.delhi.gov.in/sites/default/files/ddma/EQT/eqtip19.pdf\" target=\"_blank\" rel=\"noopener\">IIT Kanpur–BMTPC Earthquake Tip 19</a>; <a href=\"https://iitk.ac.in/nicee/econf/columnsplicing.htm\" target=\"_blank\" rel=\"noopener\">NICEE e-conference on column splicing</a>). Laps made just above floor level are a gravity-only, constructional convenience and should not be used where IS 13920 applies.",
            ]},
            { k: "note", t: "IS 13920, which governs ductile detailing for seismic design, tightens every one of these and adds requirements of its own — closely spaced stirrups over a defined length either side of every joint, 135° hooks on every stirrup, and continuity rules for column bars through the joint. Anything in a seismic zone is detailed to IS 13920, not to IS 456 alone." },
            { k: "note", t: "<b>Hook extension — check the edition.</b> <a href=\"https://ddma.delhi.gov.in/sites/default/files/ddma/EQT/eqtip19.pdf\" target=\"_blank\" rel=\"noopener\">IIT Kanpur–BMTPC Earthquake Tip 19</a>, written to IS 13920:1993, requires the tie to extend at least 10 bar diameters, and not less than 75 mm, beyond the 135° bend. Some summaries of IS 13920:2016 give a different extension (6d with a 65 mm minimum); the sources available here do not agree, so confirm the figure against the published 2016 standard before scheduling hooks. The bar-bending example below uses 10d." },
            { k: "note", t: "<b>Correction (v35):</b> an earlier version said column laps belong ‘just above floor level, where the moment is least, and never at mid-height where it is greatest’. That is reversed: in a frame, column moments peak at the ends. Chapter 5 carried the same error and has been corrected too." },
          ],
        },

        {
          n: "12.4",
          title: "The bar bending schedule",
          hi: "बार बेंडिंग शेड्यूल",
          blocks: [
            { k: "p", t: "A bar bending schedule is the drawing translated into instructions for a bar bender and a purchase order for a store: for every bar mark, its diameter, shape, cutting length, number, and weight. It is what actually gets executed, so an error in it is built." },
            { k: "def", term: "Cutting length", t: "The straight length of bar to cut before bending, so that after bending it fits the dimensions on the drawing. It is <strong>not</strong> the sum of those dimensions, because a bent bar's outside is longer than its centre line." },
            { k: "dia", id: "hb-rcc-bbs", cap: "Every bend earns a deduction; every hook adds a length." },
            { k: "p", t: "When a bar is bent, the dimensions on a drawing are measured to the outside of the bar, but the length of steel that is actually consumed follows its centre line. The outside travels further round the bend than the centre line does, so simply adding the drawn dimensions overstates the steel needed. The difference is the <em>bend deduction</em>, and Indian practice uses these values:" },
            { k: "list", items: [
              "45° bend — deduct 1d",
              "90° bend — deduct 2d",
              "135° bend (the hook on a stirrup) — deduct 3d",
              "Standard hook — add 9d to 10d of length, plus the deduction for its own bend",
              "Crank (bent-up bar) at 45° — add 0.42 × the crank height h, because the inclined leg h/sin 45° = 1.414h replaces a horizontal length h",
            ]},
            { k: "note", t: "These deductions are workshop convention rather than code values — they follow from the standard bend radii of Cl. 26.2.2.1 and SP:34, and different offices round them slightly differently. What matters is that an office uses one consistent set, and that the schedule states which." },
            { k: "eg",
              title: "Example 12.1 — Cutting length of a stirrup",
              given: "2-legged rectangular stirrup for a 300 × 450 beam. Stirrup diameter 8 mm, clear cover 25 mm. Three 90° bends and two 135° hooks.",
              steps: [
                { t: "Stirrup dimensions", w: "A = 300 − 2 × 25 = 250 mm\nB = 450 − 2 × 25 = 400 mm" },
                { t: "Build up the cutting length", w: "perimeter          2(A + B)   = 2(250 + 400) = 1300 mm\nadd two hooks      2 × 10d     = 2 × 80      = + 160 mm\nless 3 bends @ 90° 3 × 2d      = 3 × 16      = −  48 mm\nless 2 hooks @135° 2 × 3d      = 2 × 24      = −  48 mm" },
                { t: "Cutting length", w: "CL = 1300 + 160 − 48 − 48 = 1364 mm  ≈ 1.365 m" },
                { t: "Weight of one stirrup", w: "unit weight = d²/162 = 8²/162 = 0.395 kg/m\nweight = 1.364 × 0.395 = 0.539 kg" },
              ],
              ans: "Cutting length 1365 mm, 0.54 kg per stirrup. A 6 m beam with stirrups at 150 mm centres takes about 41 of them — roughly 22 kg of stirrup steel in one beam.",
            },
            { k: "eg",
              title: "Example 12.2 — Cutting length of a cranked slab bar",
              given: "Main bar 10 mm in a 150 mm slab, clear span 3000 mm, bearing on 230 mm walls at each end, end cover 25 mm, top and bottom cover 20 mm. Bar cranked up at both ends (two cranks, each with two 45° bends). No hooks.",
              steps: [
                { t: "Straight length", w: "clear span + both bearings − end covers\n= 3000 + 2 × 230 − 2 × 25 = 3410 mm" },
                { t: "Crank height", w: "h = 150 − 20 − 20 − 10 = 100 mm (centre of bottom bar to centre of top position)" },
                { t: "Extra length for two cranks", w: "2 × 0.42 h = 2 × 0.42 × 100 = + 84 mm" },
                { t: "Bend deductions", w: "4 bends at 45° × 1d = 4 × 10 = − 40 mm" },
                { t: "Cutting length and weight", w: "CL = 3410 + 84 − 40 = 3454 mm\nweight = 3.454 × 0.617 = 2.13 kg" },
              ],
              ans: "Cut each bar 3454 mm (≈ 3.45 m); 2.13 kg per bar. The 0.42h allowance is pure geometry — √2 − 1 = 0.414, rounded up.",
            },
          ],
        },

        {
          n: "12.5",
          title: "Where d²/162 comes from",
          hi: "d²/162 कहाँ से आता है",
          blocks: [
            { k: "p", t: "Every site in India uses this, and almost nobody derives it. It is one line." },
            { k: "eq", expr: "mass per metre = (π/4) d² × 10⁻⁶ m² × 7850 kg/m³  =  d² × 0.006165  =  d² / 162.2", where: [
              ["d", "bar diameter in mm"],
              ["7850", "density of steel, kg/m³"],
            ]},
            { k: "p", t: "So 162 is not a magic number — it is 4 × 10⁶ / (π × 7850), and it appears only because we insist on giving the diameter in millimetres and wanting the answer in kilograms per metre. Every standard size follows from it:" },
            { k: "cmp", t: "Mass per metre of reinforcing bars", cols: ["Exact, ρ = 7850 kg/m³", "Site rule (÷ 162)"], rows: [
              ["8 mm", "0.395 kg/m", "0.395 kg/m"],
              ["10 mm", "0.617 kg/m", "0.617 kg/m"],
              ["12 mm", "0.888 kg/m", "0.889 kg/m"],
              ["16 mm", "1.578 kg/m", "1.580 kg/m"],
              ["20 mm", "2.466 kg/m", "2.469 kg/m"],
              ["25 mm", "3.853 kg/m", "3.858 kg/m"],
              ["32 mm", "6.313 kg/m", "6.321 kg/m"],
            ]},
            { k: "p", t: "The exact column matches the nominal masses in IS 1786 and in <a href=\"https://amtec.uplb.edu.ph/wp-content/uploads/2019/07/316-1.pdf\" target=\"_blank\" rel=\"noopener\">a published bar-mass table</a>; d²/162 runs about 0.13% heavy because 162 rounds 162.2. For billing and tolerance checks use the nominal mass; for site estimates the difference is negligible." },
            { k: "note", t: "Because the mass goes as d², a 25 mm bar weighs nearly ten times a 8 mm bar per metre. That is worth remembering when a design is being tuned: substituting a smaller diameter at closer spacing keeps the area, improves crack control and shortens development lengths. The steel tonnage is unchanged, but more bars mean more cutting, bending, tying and congestion, and smaller diameters often carry a slightly higher price per tonne — so it is a trade-off, not a free improvement." },
          ],
        },

        {
          n: "12.6",
          title: "Errors that keep recurring",
          hi: "बार-बार होने वाली ग़लतियाँ",
          blocks: [
            { k: "list", items: [
              "<strong>Top bars in a cantilever placed at the bottom.</strong> The tension in a cantilever is at the top, always. This reverses the whole design and the member fails at the support on striking the props.",
              "<strong>Short-span bars placed above the long-span bars</strong> in a two-way slab, costing the short span its effective depth.",
              "<strong>Stirrups lapped in the cover</strong> instead of hooked into the core. The lap opens as soon as the cover spalls, and in a torsion or seismic member the stirrup unwinds.",
              "<strong>Laps all at one section.</strong> A lapped bar is the weakest point in its length; putting every lap at the same level makes a plane of weakness across the member. Stagger them.",
              "<strong>Cover blocks omitted or of the wrong depth.</strong> The commonest cause of premature corrosion in Indian construction.",
              "<strong>Bars curtailed at the theoretical cut-off point</strong>, with the Cl. 26.2.3.1 extension of d or 12φ forgotten.",
              "<strong>Development length not available at a corner</strong> — a 16 mm Fe 415 bar in M25 needs Ld ≈ 645 mm (752 mm in M20), it was drawn straight into a 300 mm column, and nobody noticed until the cage was made.",
            ]},
            { k: "trap", t: "Most of these are not ignorance on site. They are ambiguity on the drawing. A detail that can be built two ways will be built the quicker way, and the drawing is the only place the designer gets to decide which." },
          ],
        },

        {
          n: "12.7",
          title: "Closing the loop",
          hi: "पूरा चक्र",
          blocks: [
            { k: "p", t: "Twelve chapters back, this handbook began with the four things a design owes: safety, serviceability, durability and economy. It is worth reading the sequence backwards to see how each chapter served them." },
            { k: "list", items: [
              "<strong>Ch 1–2</strong> — the limit state framework, and why the same member is calculated twice, once for collapse and once for service.",
              "<strong>Ch 3–4</strong> — flexure: where 0.36 and 0.42 come from, and why xu,max buys ductility.",
              "<strong>Ch 5–6</strong> — shear, bond and torsion: the checks that stop a member failing without warning, and the grip that makes the steel usable at all.",
              "<strong>Ch 7–9</strong> — the members: slabs, columns, footings, and the load path down to the soil.",
              "<strong>Ch 10</strong> — serviceability, where a structure stops being a calculation and starts being somewhere people live.",
              "<strong>Ch 11–12</strong> — the elements that do not fit the pattern, and the drawing that makes any of it real.",
            ]},
            { k: "p", t: "One thing has been true throughout, and is worth stating plainly at the end: IS 456 tells you <em>what</em> must be satisfied and very rarely <em>why</em>. Every value in this handbook carries its clause, so you can check it against the published standard — and every explanation was written to supply the part the code leaves out. Use both. A designer who knows only the clause cannot tell when it does not apply; one who knows only the reasoning cannot demonstrate that the design complies." },
            { k: "note", t: "The values here are referenced for learning. Before using any of them in a design that will be built, confirm the clause against the current published edition of IS 456 and any amendment in force — and for anything in a seismic zone, read IS 1893 and IS 13920 alongside it." },
          ],
        },
      ],
    }

  );
})();
