/* Surveying class notes — Plane Table Surveying, notes p.179–195 — inserted into sv chapter 5 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 5; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- intro */
    {
      n: "",
      title: "Notes — Plane table survey: introduction, advantages and disadvantages",
      hi: "प्लेन टेबल सर्वे — परिचय, लाभ और हानियाँ",
      blocks: [
        { k: "h", t: "📘 Notes — p.179–180" },
        { k: "def", term: "Plane table", t: "An instrument used for surveying by <b>graphical method</b>, in which the <b>field work and plotting are done simultaneously</b>. (p.179)" },
        { k: "list", items: [
          "The main feature of the plane table is that the topographical features to be mapped are in <b>full view</b>, hence no chance of missing any important detail. (p.179)",
          "It is useful for <b>small to medium scale</b>, where great accuracy is not required. (p.179)",
          "It is also used for plotting the <b>topographical maps in the field</b>. (p.179)",
          "Before commencing the plane table survey, the <b>instrument stations are fixed</b> to cover the entire area to be surveyed. (p.179)",
          "A surveyor starts filling the details from any of the control points one by one. The finished maps are called <b>topographical maps</b>; the process of preparing topographic maps is called <b>“CARTOGRAPHY”</b>. (p.179)",
        ] },
        { k: "p", t: "Figure (p.179): a hexagon of control stations A (top), B, C (right side), D (bottom vertex, label cut off at page edge), E, F (left side), with a square plane-table symbol (marked with a star) set at the centre — the table covers the whole area from inside the framework. (p.179)" },
        { k: "h", t: "Advantages of plane table survey (p.180)" },
        { k: "list", items: [
          "1) The sighting and plotting are done simultaneously, so there is no risk of omitting (miss करना) any necessary detail. (p.180)",
          "2) The errors and mistakes can be checked by drawing the <b>check lines</b>. (p.180)",
          "3) Irregular objects can also be plotted; no great skill is required and no skilled labour is required. (p.180)",
          "4) It is less costly than theodolite survey. (p.180)",
          "5) ★ [imp] It is very advantageous in areas where <b>compass survey is not possible</b> (e.g. areas highly affected by magnetic field). (p.180)",
        ] },
        { k: "h", t: "Disadvantages of plane table survey (p.180)" },
        { k: "list", items: [
          "1) It is not suitable for work in <b>wet climate and dense forest</b>. (p.180)",
          "2) The <b>absence of measurements</b> causes inconvenience if the survey is to be reported on some different scale. (p.180)",
          "3) Plane table is <b>heavy and awkward to carry</b>. (p.180)",
          "4) It does <b>not give very accurate</b> results. (p.180)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Chain ya compass survey mein field book mein numbers likhte hain aur office mein plot karte hain. Plane table mein <b>map wahi field mein ban jaata hai</b> — isliye detail chhootne ka chance nahi (sab saamne dikh raha hai), lekin numbers ka record bhi nahi bachta. Isi wajah se scale badalna ho to dikkat hoti hai (disadvantage 2). Section 5.1 mein yahi trade-off aur detail se samjhaya hai." },
        { k: "p", t: "Advantage 5 ko yaad rakho: magnetic disturbance wale area mein compass fail ho jaata hai, par plane table orientation back-sighting se ho sakta hai, isliye wahan plane table kaam karta hai." },
        { k: "trap", t: "“Plane table is accurate because plotting is done on the spot” — galat. Notes clearly say it <b>does not give very accurate results</b> and is meant for small to medium scale work where great accuracy is not required. Its advantage is <b>no omission</b>, not high accuracy." },
        { k: "real", t: "Plane tabling is used to fill topographic detail (buildings, boundaries, streams) inside a framework of stations fixed beforehand — the notes' hexagon of stations around one table is exactly that idea." },
      ],
    },

    /* ---------------------------------------------------------- accessories */
    {
      n: "",
      title: "Notes — Accessories: board sizes, tripod, alidade, trough compass, spirit level, plumbing fork",
      hi: "प्लेन टेबल के सहायक उपकरण",
      blocks: [
        { k: "h", t: "📘 Notes — p.181–184" },
        { k: "def", term: "1) Plane table board", t: "The drawing board is carefully made of <b>well-seasoned wood</b>. The upper surface is kept smooth. The table, at the centre of the underside, is attached to a tripod with the help of a screw known as the <b>wing nut</b>. By means of the wing nut the table can be clamped in any direction or any position. (p.181)" },
        { k: "cmp", t: "Plane tables are available in the following different sizes (p.181)", cols: ["Dimension (mm × mm)"], rows: [
          ["B<sub>0</sub>", "1500 × 1000"],
          ["B<sub>1</sub>", "1000 × 700"],
          ["B<sub>2</sub>", "700 × 500"],
          ["B<sub>3</sub>", "500 × 350"],
        ] },
        { k: "def", term: "2) Tripod", t: "An <b>open-frame type light tripod</b> is generally used. Levelling of the board is achieved with the tripod legs, and horizontality of the board with the help of <b>two spirit levels fixed at right angles to each other</b> on the board. (p.181)" },
        { k: "def", term: "3) Alidade", t: "An alidade is a <b>straight-edge ruler having some sighting devices</b>; it is used for sighting objects and for drawing lines. (p.182)" },
        { k: "list", items: [
          "<b>Plain alidade</b> is a straight-edge ruler of about <b>450 mm</b> long made of metal or wood; one of the edges is graduated. (p.182)",
          "The alidade is provided with a <b>sight vane at each end</b>. The sight vanes have a hinge at the lower end so that they can be folded. (p.182)",
          "One of the sight vanes is provided with a <b>narrow slit</b> and is used as the <b>eye vane</b>; the <b>object vane</b> is open and carries a <b>hair or thin wire</b> at its centre. The two sight vanes provide a definite line of sight. The graduated edge of the ruler is called the <b>“Fiducial edge”</b>. (p.182 — marked in the margin as important)",
          "The line of sight of the alidade is in the <b>same plane as that of the fiducial edge</b> or in a plane parallel to it. (p.182)",
        ] },
        { k: "note", t: "Note (notes): Nowadays <b>telescopic alidades</b> are also used for sighting the object; by using a telescopic alidade, accuracy and range are increased. (p.182)" },
        { k: "p", t: "Figure (p.183): plain alidade in perspective — a long straight-edge ruler with a folding sight vane standing up at each end, each vane with a small hole/slit, labelled “sight vane” on both ends; a line between the vanes labelled “hair or wire”; the front edge graduated with tick marks, a dimension arrow “← 450 mm →” along it, and labelled “Fiducial edge”. (p.183)" },
        { k: "def", term: "4) Trough compass", t: "Generally it is <b>15 cm long</b> and is provided to plot the <b>magnetic meridian (N–S) direction</b>, to facilitate orientation of the plane table in the magnetic meridian. (p.183)" },
        { k: "p", t: "Figure (p.183): trough compass — a diamond-shaped magnetic needle in the middle with a short graduated arc at each end; each arc reads 10°, 5°, 0°, 5°, 10° from top to bottom (the needle swings only a few degrees either side of 0°). (p.183)" },
        { k: "def", term: "5) Spirit level / Level tube", t: "The essential condition of plane table survey is that the <b>board must be level</b>. The spirit level is placed on the board in <b>two positions at mutually perpendicular directions</b> and the bubble is centred in each position to level the table. (p.183)" },
        { k: "p", t: "Figure (p.183): a small rectangular block spirit level drawn in perspective, with two bubble tubes on it at right angles — one along the front edge, one along the side. (p.183)" },
        { k: "def", term: "6) Plumbing fork", t: "A plumbing bob [fork] is a <b>V-shape metal piece</b>; it is used for <b>centring the plane table over the station</b>. (p.183) Figure: a vertical string ending in a small plumb bob. (p.183)" },
        { k: "def", term: "7) Drawing sheet", t: "The drawing sheet used should be of the <b>best quality</b> to withstand [field use]. (p.184)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Board sizes yaad karne ka trick: har agla size pichhle ka lagbhag aadha hai — 1500 × 1000 → 1000 × 700 → 700 × 500 → 500 × 350. Pichhle size ki chhoti side agle ki lambi side ban jaati hai." },
        { k: "p", t: "Alidade ka <b>fiducial edge</b> hi wo edge hai jiske saath pencil chalaate ho. Line of sight usi plane mein (ya parallel plane mein) hai, isliye jo ray aap dekh rahe ho wahi ray paper par khinchti hai. Eye vane mein slit (aankh ke paas), object vane mein hair/wire (object ki taraf) — section 5.2 mein bhi yahi equipment list hai." },
        { k: "trap", t: "Do not mix up the vanes: the <b>eye vane has the narrow slit</b>, the <b>object vane is open with a hair/wire</b>. Also, the notes call the V-shaped centring piece a “plumbing bob” in the sentence but the heading is <b>Plumbing fork</b> — in exams the instrument for centring the plane table is the <b>plumbing fork (U-frame)</b>, with a plumb bob hanging from it." },
        { k: "real", t: "The trough compass (15 cm) only needs to show N–S, so its scale is a few degrees each side of zero — it is an orientation aid, not a bearing-measuring instrument like the prismatic compass." },
      ],
    },

    /* ---------------------------------------------------------- temporary adjustments + orientation */
    {
      n: "",
      title: "Notes — Temporary adjustments and methods of orientation",
      hi: "अस्थायी समायोजन और अभिविन्यास की विधियाँ",
      blocks: [
        { k: "h", t: "📘 Notes — p.184–186" },
        { k: "h", t: "Temporary adjustment of plane table" },
        { k: "def", term: "1) Centring", t: "The operation of bringing the <b>plotted station exactly over the ground station</b>. A <b>plumbing fork</b> is used for checking the centring. (p.184)" },
        { k: "note", t: "Note (notes): Exact centring is important for <b>large scale mapping only</b>; for small scale mapping an error in centring of about <b>30 cm is permissible</b>. (p.184)" },
        { k: "def", term: "2) Levelling", t: "The operation of bringing the plane table into a <b>horizontal plane</b>. Levelling is done with the help of the <b>spirit level</b>. (p.184)" },
        { k: "def", term: "3) Orientation", t: "The operation of keeping the plane table <b>parallel to the position it occupied at the first station</b>. In such a case all the lines plotted will be parallel to the corresponding lines on the ground. (p.184)" },
        { k: "list", items: [
          "If the position of the board is different at successive stations, the relative position of the plotted stations will not be the same as the relative position of the detail on the ground. (p.184)",
          "As a result, the plotted work of the previous station cannot be connected to that of the successive stations. (p.185)",
          "During orientation of the table, the table is rotated and the plotted position of the instrument station is also disturbed and shifts relative to the ground station. (p.185)",
        ] },
        { k: "h", t: "Methods of plane table orientation (p.185–186)" },
        { k: "def", term: "1) By trough compass", t: "A trough compass is placed on the <b>top right-side corner</b> of the plane table such that the magnetic needle points exactly towards the N–S direction. Draw a line along the edge of the compass; shift the set-up to the next station and place the trough compass along the N–S direction drawn. Rotate the plane table till the magnetic needle coincides with the N–S line previously drawn. (p.185)" },
        { k: "def", term: "2) By back sighting", t: "This is the <b>most accurate method</b> of orientation. The plane table is set on a new station, the alidade is placed against the line joining the new station with the preceding station, and the table is rotated until the line of sight bisects the previous station. (p.185)" },
        { k: "steps", items: [
          "Let the plane table be shifted from A to B, and the line <b>ab</b> has been plotted with the plane table at A. (p.186)",
          "Set the table on B; place the alidade along the plotted line <b>ba</b>. (p.186)",
          "Rotate the table until the line of sight <b>ba</b> bisects the station A; clamp the bolt. (p.186)",
          "Along the line of sight, the line truly represents the line BA along the ground. (p.186)",
        ] },
        { k: "p", t: "Figure (p.186): three plane-table boards at ground stations A (bottom left), B (middle top) and C (top right), joined by dashed lines A–B and B–C. Board at A shows plotted line a–b; board at B shows plotted a, b, c with lines a–b and b–c; board at C shows a, b, c with lines a–b and b–c — each board kept parallel to the first. (p.186)" },
        { k: "def", term: "3) Resection", t: "Listed as the third method of orientation; the notes add in Hindi “ये plane table में पढ़ेंगे” — it is taken up under methods of plane table surveying below. (p.186)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen kaam har station par: <b>level</b> (board horizontal), <b>centre</b> (paper ka point ground station ke upar), <b>orient</b> (board pehle station jaisa parallel). Orientation sabse zaroori hai — agar board ghooma hua hai to har ray utne hi angle se galat hogi, aur pichhle station ka kaam naye station se join hi nahi hoga." },
        { k: "p", t: "30 cm centring error kyun chalta hai small scale par? Kyunki chhote scale par 30 cm ground ka paper par ek pencil-dot se bhi chhota ho jaata hai. Section 5.2 ka note yahi scale wala logic deta hai." },
        { k: "trap", t: "Students often call trough-compass orientation the accurate one. The notes say <b>back sighting is the most accurate</b>; the compass method suffers wherever the needle is disturbed (local attraction) — and that is exactly the area where plane tabling is recommended over compass survey." },
        { k: "real", t: "On site, after back-sighting and clamping, the surveyor re-sights the previous station once more before drawing any new ray — a knock on the board while clamping is the usual cause of a bad station." },
      ],
    },

    /* ---------------------------------------------------------- four methods */
    {
      n: "",
      title: "Notes — Methods of plane table surveying: radiation, traversing, intersection, resection",
      hi: "प्लेन टेबल सर्वेक्षण की विधियाँ",
      blocks: [
        { k: "h", t: "📘 Notes — p.186–189" },
        { k: "p", t: "★ <b>Methods of plane table surveying</b> (marked “SSC main”, “imp”): 1) Radiation · 2) Traversing · 3) Intersection · 4) Resection. (p.186)" },
        { k: "h", t: "1) Radiation (p.187)" },
        { k: "list", items: [
          "The instrument is set up at a station and <b>rays are drawn to the various stations</b> which are to be plotted. The distances are cut to a suitable scale after actual measurement. (p.187)",
          "Suitable only when the <b>area to be surveyed is small</b> and all the required stations to be plotted are <b>visible and accessible</b> from the instrument station. (p.187)",
          "The scope of this method is increased when distances are measured with the help of a <b>tacheometer</b>. (p.187)",
        ] },
        { k: "p", t: "Figure (p.187): ground stations A, B, C, D, E form a closed pentagon (B at the top apex, A upper left, C upper right, E bottom left, D bottom right). The plane table is set inside the figure near its centre; on it the plotted points a, b, c, d, e form a small similar pentagon, with rays radiating from the instrument point to each of A, B, C, D, E. (p.187)" },
        { k: "h", t: "2) Traversing (p.187)" },
        { k: "list", items: [
          "Similar to <b>compass or theodolite traversing</b>; the table is set at each of the stations successively. (p.187)",
          "The <b>foresight</b> is taken to the next station and the required distance is cut to a suitable scale. (p.187)",
          "Most suited when a <b>narrow strip</b> of terrain is to be surveyed, e.g. road, railways etc. (p.187)",
        ] },
        { k: "h", t: "3) Intersection (p.188)" },
        { k: "list", items: [
          "Two stations are selected such that all the other stations to be plotted are visible from these. (p.188)",
          "The line joining these two stations is called the <b>base line</b>. Its length is measured <b>very accurately</b>. (p.188)",
          "Rays are drawn to the stations to be plotted from these two stations. (p.188)",
          "The <b>intersection of rays</b> from the two stations gives the location of the other station on the plane table. (p.188)",
          "This method is <b>most commonly used for plotting details</b>; it is preferred when the distance between stations is too large, the stations are <b>inaccessible</b>, or the ground is undulating. E.g. <b>broken boundaries</b> can be very conveniently plotted by this method. (p.188)",
        ] },
        { k: "p", t: "Figure (p.188): two plane-table boards at the ends of a “Base line”; each board shows the base line plotted as ab. A ray from a on the left board and a ray from the right board go up and meet at the ground station C at the top; on the right board the ray through c is shown. (p.188)" },
        { k: "h", t: "4) Resection (p.189)" },
        { k: "list", items: [
          "This method of orientation is employed when the plane table occupies a position <b>not yet plotted</b> on the drawing sheet. (p.189)",
          "<b>Resection</b> can be defined as the process of locating the instrument station occupied by the plane table by drawing rays from stations whose positions are <b>already plotted</b> on the drawing sheet. (p.189)",
          "The point representing the resection of two rays will be the station to be located, <b>provided the orientation is correct</b>. (p.189)",
        ] },
        { k: "p", t: "Figure (p.189): board at station A (bottom left) with plotted line a–b; an empty board at station B (bottom right); a board at the top (station C) showing plotted a, b and c forming a triangle a–b–c, with a dashed ray from the top board down to A and a line down to B. (p.189)" },
        { k: "cmp", t: "Four methods at a glance (from p.187–189)", cols: ["What is done", "Best suited for"], rows: [
          ["Radiation", "One set-up; rays drawn to points; distances measured and cut to scale", "Small area, all points visible and accessible"],
          ["Traversing", "Table set at each station in turn; foresight to next station; distance cut to scale", "Narrow strips — roads, railways"],
          ["Intersection", "Rays from both ends of an accurately measured base line; crossing gives the point", "Plotting details; inaccessible points, large distances, undulating ground, broken boundaries"],
          ["Resection", "Rays from already-plotted stations locate the table's own (unplotted) station", "Locating the instrument station; also orientation"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Radiation aur traversing mein <b>distance naapni padti hai</b>; intersection mein point tak distance naapni hi nahi padti — sirf base line accurately naapo aur do rays kaato. Isliye river ke paar wala ped ya chimney jaise inaccessible points intersection se plot hote hain. Resection ulta kaam karta hai: known points se apni khud ki position nikalna (section 5.3 mein bhi isi inversion ki baat hai)." },
        { k: "trap", t: "Radiation needs every point to be both <b>visible and accessible</b> from one station (distances are taped). Choosing radiation for inaccessible points is wrong — that is intersection's job. And resection gives the right point <b>only if the orientation is correct</b>." },
        { k: "real", t: "A road or railway strip survey goes by traversing; the trees, houses and boundary corners along it are then picked up by radiation (near, accessible) or intersection (far, across a nala)." },
      ],
    },

    /* ---------------------------------------------------------- back ray + two-point problem */
    {
      n: "",
      title: "Notes — Resection by back ray and the two-point problem",
      hi: "बैक रे द्वारा रिसेक्शन और द्वि-बिंदु समस्या",
      blocks: [
        { k: "h", t: "📘 Notes — p.189–193" },
        { k: "h", t: "Resection after orientation by back ray — procedure" },
        { k: "steps", items: [
          "Step 1 — Let a and b be the plotted positions of the two ground stations A and B; station C is to be plotted. (Refer to the figure above, p.189.) (p.189)",
          "Step 2 — Set up the table at station A with point a over station A. (p.190)",
          "Step 3 — Keeping the alidade along ab, bisect station B [orientation]. (p.190)",
          "Step 4 — Now, as the table is oriented, bisect station C and draw the ray ac. (p.190)",
          "Step 5 — Shift the table to station C, place the alidade along ca and rotate the table till it is oriented; clamp it. (p.190)",
          "Step 6 — With the alidade pivoted on b, sight station B and draw a <b>back ray bc</b>. (p.190)",
          "Step 7 — The point of intersection of ac and bc gives the position of station C on paper. (p.190)",
        ] },
        { k: "h", t: "Resection after orientation by two points / Two-point problem" },
        { k: "def", term: "Two-point problem", t: "Locating the position of a plane table station on the drawing sheet by observation of <b>two well-defined points</b> whose positions have already been plotted on the plan. Here it is used to plot a station C by sighting the stations A and B. (p.190)" },
        { k: "steps", items: [
          "Step 1 — Choose a suitable <b>auxiliary station D</b> near station C so that the angles ∠CAD and ∠CBD are neither too acute nor too obtuse. (p.191)",
          "Step 2 — Set up the plane table on station D; orient the table <b>approximately</b> using the compass or by eye judgement, such that line ab is approximately ∥ to AB. Clamp the plane table. (p.191)",
          "Step 3 — Pivot (स्थिर करना) the alidade on a and sight station A; draw a ray from a. Similarly pivot the alidade on b, sight station B and draw the ray through b, intersecting the ray through a at <b>d<sub>1</sub></b>. (p.191)",
          "Step 4 — Point d<sub>1</sub> gives the <b>approximate position</b> of station D, because the orientation of the table at D is approximate. Now transfer the point d<sub>1</sub> to the ground by the plumbing fork. (p.191)",
          "Step 5 — With the alidade pivoted at d<sub>1</sub>, sight station C and draw a ray d<sub>1</sub>c<sub>1</sub> to represent the distance DC. Mark the point c<sub>1</sub> by approximate estimation. (p.191)",
          "Step 6 — Now shift the plane table to station C and centre it such that point c<sub>1</sub> is above C. (p.191)",
          "Step 7 — Orient the plane table by <b>back-sighting on D</b>; thus the orientation at C is the same as that at D. Now pivot the alidade at point a, sight station A and draw a ray ac<sub>2</sub> to intersect d<sub>1</sub>c<sub>1</sub>. Hence c<sub>2</sub> represents the approximate position of station C, because the orientation is still approximate. (p.192)",
          "Step 8 — Pivot the alidade at c<sub>2</sub>, sight station B and draw a ray c<sub>2</sub>b<sub>1</sub> through c<sub>2</sub>. In general the ray c<sub>2</sub>b<sub>1</sub> will not pass through the correct position of B, because the orientation is approximate; point b<sub>1</sub> gives the approximate position of B. (p.192)",
          "Step 9 — As the length ab is the true representation of AB, the <b>error in orientation is equal to the angle b<sub>1</sub>ab</b> between the lines ab and ab<sub>1</sub>. (p.192)",
          "Step 10 — To eliminate this error of orientation, place the alidade along ab<sub>1</sub> [notes write “ad<sub>1</sub>” here; the figure and the end of the same step show the line ab<sub>1</sub>]; fix a ranging rod at point P (random point) at some distance from the plane table and in line with ab<sub>1</sub>. (p.192)",
          "Step 11 — Place the alidade along ab and turn the plane table until the point P is bisected. Clamp the table in this direction. Now the orientation of the table is correct and line ab is correctly ∥ to AB. (p.192)",
          "Step 12 — Now, to find the true position of c, pivot the alidade on a and sight A; similarly pivot the alidade on b and sight B. The intersection of ac and bc gives the position of c. (p.193)",
        ] },
        { k: "p", t: "Figure (p.193): ground stations A (top left) and B (top right) joined by a line A–B. Below, two plane-table sheets. <b>Left table (first setting at D):</b> plotted points a, b, d and c<sub>1</sub>; lines a–b, a–d, d–c<sub>1</sub>; a dashed line from d through b continues up to station B. <b>Right table (at C, corrected setting):</b> points a, b, b<sub>1</sub> (top right), c<sub>2</sub> (bottom right), d (bottom left), c<sub>1</sub> (on the bottom edge between d and c<sub>2</sub>); lines a–b, a–b<sub>1</sub>, a–d, d–c<sub>2</sub>, b<sub>1</sub>–c<sub>2</sub>; the line a–b<sub>1</sub> is extended off the table to the ranging point •P; a vertical line from b<sub>1</sub> goes up to B and a faint line from A down to c<sub>2</sub>. Note beside the right table with a curved arrow ↻: “Turn required up to when ab bisects point P”. (p.193)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Back-ray method mein aap pehle A par khade ho, isliye orientation pakki hai; C par jaakar ca par back-sight karke wahi orientation wapas laate ho, phir b se back ray kheenchte ho. Do rays (ac aur bc) cross karti hain to C mil jaata hai." },
        { k: "p", t: "Two-point problem mein dikkat ye hai ki sirf do known points se <b>position aur orientation dono</b> nahi nikalte. Isliye ek helper station D lete ho, approximate orientation se kaam chalaate ho, aur phir dekh lete ho ki b<sub>1</sub> aur b mein kitna angle hai — wahi angle b<sub>1</sub>ab orientation ki galti hai. Ranging rod P ko ab<sub>1</sub> line mein lagao, phir board ghumao jab tak ab line P ko bisect na kare: ab galti nikal gayi, ab parallel to AB. Section 5.4 mein auxiliary station wala yahi idea hai." },
        { k: "trap", t: "The error angle is <b>b<sub>1</sub>ab</b> — measured at <b>a</b>, between the true line ab and the approximate line ab<sub>1</sub>. A common slip is to measure it at c<sub>2</sub>, or to rotate the board so that ab<sub>1</sub> (instead of ab) points at P. The ranging rod is set on the line ab<sub>1</sub>; then the alidade is put on <b>ab</b> and the board turned until P is bisected." },
        { k: "real", t: "The auxiliary station D must give well-conditioned angles (∠CAD, ∠CBD neither too acute nor too obtuse) — at a flat-angle intersection a pencil-width error in a ray moves the point a long way." },
      ],
    },

    /* ---------------------------------------------------------- three-point problem */
    {
      n: "",
      title: "Notes — Three-point problem: Lehmann's (trial and error) method and the triangle of error",
      hi: "त्रि-बिंदु समस्या — लेहमन विधि और त्रुटि त्रिभुज",
      blocks: [
        { k: "h", t: "📘 Notes — p.193–195" },
        { k: "def", term: "Three-point problem", t: "Locating the position of a plane table on the drawing sheet by means of observation of <b>three well-defined points</b> whose positions have already been plotted on the plan. Let A, B, C be the three well-defined points and a, b, c their plotted positions; it is required to fix the ground station P on the plan as p. (p.193)" },
        { k: "list", items: [
          "The three-point problem can be solved by — (a) <b>Graphical</b> method · (b) <b>Trial and error</b> method (<b>Lehmann's</b> method) · (c) <b>Mechanical</b> method · (d) <b>Analytical</b> method · (e) <b>Geometrical construction</b> method. (p.194)",
        ] },
        { k: "h", t: "Trial and error method / Lehmann's method (p.194)" },
        { k: "steps", items: [
          "This method is commonly used in field measurements as it gives <b>very accurate results</b>. (p.194)",
          "The position of the plane table station is estimated by <b>eye judgement</b>; let it be p′. The alidade is kept against p′a [notes: “P′A”] and the table is oriented [by sighting A]. (p.194)",
          "Now pivot the alidade on point b, sight B and draw a back ray. Pivot the alidade on point c, sight C and draw a back ray. (p.194)",
          "If the orientation of the plane table is correct, the <b>3 rays will intersect at a point p</b>; otherwise a <b>triangle of error</b> will form. (p.194)",
        ] },
        { k: "p", t: "Figure (p.195): three ground stations A (left), B (middle), C (right) at the top. Plotted points a, b, c lie on the respective rays below them. Back rays drawn from A through a, from B through b and from C through c, extended downward, do not meet at one point but form a small triangle (shaded) near the bottom. Point p is marked just below/right of the triangle on the ray from A. An arrow from the triangle points to the label “Triangulation error” [i.e. the <b>triangle of error</b>]. (p.195)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen known points hain aur teen unknowns — station ke do coordinates aur board ka rotation. Orientation thodi bhi galat hai to teeno back rays ek point par nahi milti, ek chhota triangle bana deti hain — yahi <b>triangle of error</b> hai. Lehmann ke method mein board ko thoda ghumate ho aur dobara rays kheenchte ho, jab tak triangle ek point na ban jaaye. Triangle kis taraf shift karna hai iske Lehmann's rules section 5.4 mein diye hain." },
        { k: "trap", t: "The figure in the notes labels it “Triangulation error” — the correct term is <b>triangle of error</b>. Triangulation is a separate control-survey method; do not write “triangulation error” in an exam answer for the three-point problem." },
        { k: "note", t: "<b>General Engineering Knowledge:</b> in the standard texts, the graphical method is Bessel's method and the mechanical method is the tracing-paper method (both described in section 5.4). If the station lies on the circle through A, B and C, the problem has no unique solution (the “danger circle”)." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — Plane Table Surveying (p.179–195)",
      hi: "पुनरावृत्ति — प्लेन टेबल सर्वेक्षण",
      blocks: [
        { k: "h", t: "📘 Notes — key points p.179–195" },
        { k: "list", items: [
          "✅ Plane table = graphical method; field work and plotting simultaneous; small–medium scale, great accuracy not required. (p.179)",
          "✅ Process of preparing topographic maps = <b>Cartography</b>. (p.179)",
          "✅ Advantages: no omission, check lines, irregular objects easy, no skilled labour, cheaper than theodolite, ★ works where compass fails (magnetic areas). (p.180)",
          "✅ Disadvantages: not for wet climate / dense forest, no measurements (re-scaling hard), heavy and awkward, not very accurate. (p.180)",
          "✅ Board: well-seasoned wood, clamped by <b>wing nut</b>. Sizes B<sub>0</sub> 1500 × 1000, B<sub>1</sub> 1000 × 700, B<sub>2</sub> 700 × 500, B<sub>3</sub> 500 × 350 mm. (p.181)",
          "✅ Tripod: open-frame light type; two spirit levels at right angles. (p.181)",
          "✅ Plain alidade ≈ <b>450 mm</b>; eye vane = narrow slit, object vane = hair/wire; graduated edge = <b>fiducial edge</b>; line of sight in plane of (or parallel to) fiducial edge. Telescopic alidade → more accuracy and range. (p.182–183)",
          "✅ Trough compass ≈ <b>15 cm</b> long, plots magnetic meridian N–S for orientation. (p.183)",
          "✅ Spirit level in two mutually ⊥ positions; plumbing fork (V/U-shape) for centring. (p.183)",
          "✅ Temporary adjustments: <b>centring, levelling, orientation</b>. Small-scale centring error ≈ <b>30 cm</b> permissible. (p.184)",
          "✅ Orientation = board kept parallel to its position at the first station. (p.184)",
          "✅ Orientation methods: trough compass (top right corner), <b>back sighting (most accurate)</b>, resection. (p.185–186)",
          "✅ ★ Methods of surveying: radiation, traversing, intersection, resection. (p.186)",
          "✅ Radiation: small area, all points visible + accessible; tacheometer increases scope. (p.187)",
          "✅ Traversing: like compass/theodolite traverse; narrow strips — roads, railways. (p.187)",
          "✅ Intersection: accurately measured base line; most common for details; inaccessible points, large distances, undulating ground, broken boundaries. (p.188)",
          "✅ Resection: locate the occupied (unplotted) station from already-plotted stations; correct only if orientation is correct. (p.189)",
          "✅ Back-ray resection: orient on ab at A, ray ac; at C back-sight ca, back ray from b; ac × bc = c. (p.189–190)",
          "✅ Two-point problem: auxiliary station D; approximate orientation; error in orientation = ∠b<sub>1</sub>ab; ranging rod P on ab<sub>1</sub>, turn board till ab bisects P. (p.190–193)",
          "✅ Three-point problem methods: graphical, trial and error (Lehmann's), mechanical, analytical, geometrical construction. (p.193–194)",
          "✅ Lehmann's: estimate p′, orient on A, back rays from b and c; correct orientation → rays meet at p, else <b>triangle of error</b>. (p.194–195)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
