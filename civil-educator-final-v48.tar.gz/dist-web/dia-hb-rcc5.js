/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 9–10
   Footings · Serviceability
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 9.4 THE THREE CRITICAL SECTIONS */
  "hb-rcc-footchecks": {
    label: "The three critical sections in a footing",
    svg: `<svg viewBox="0 0 724 340" role="img" aria-label="An isolated footing in section and in plan, showing the three critical sections: bending taken at the face of the column, one way shear on a section a distance d from the face, and two way punching shear on a perimeter at d over two all round the column">
      ${hbmk("fc")}
      <text class="em" x="350" y="24" text-anchor="middle">THREE CHECKS, THREE DIFFERENT CRITICAL SECTIONS</text>

      <rect class="conc" x="70" y="118" width="360" height="62"/>
      <rect class="conc" x="216" y="46" width="68" height="72"/>
      <text class="lb" x="250" y="40" text-anchor="middle">column</text>
      ${[0,1,2,3,4,5,6,7,8,9].map(i=>`<line class="ac" x1="${86+i*36}" y1="206" x2="${86+i*36}" y2="184" marker-end="url(#fc-c)"/>`).join("")}
      <text class="ea" x="250" y="226" text-anchor="middle">net upward pressure from the soil</text>

      <line class="hi" x1="216" y1="110" x2="216" y2="192"/>
      <text class="lb" x="196" y="104" text-anchor="end">① bending</text>
      <text class="lb" x="196" y="122" text-anchor="end">at the column FACE</text>

      <line class="hi dash" x1="158" y1="110" x2="158" y2="192"/>
      <line class="ac" x1="216" y1="150" x2="158" y2="150" marker-end="url(#fc-c)"/>
      <text class="lb" x="150" y="204" text-anchor="end">② one-way shear</text>
      <text class="lb" x="150" y="222" text-anchor="end">at d from the face</text>

      <line class="thin" x1="70" y1="196" x2="70" y2="212"/>
      <line class="thin" x1="430" y1="196" x2="430" y2="212"/>
      <line class="steel" x1="86" y1="168" x2="414" y2="168"/>

      <line class="gl" x1="470" y1="36" x2="470" y2="326"/>

      <text class="em" x="588" y="60" text-anchor="middle">PLAN</text>
      <rect class="conc" x="496" y="80" width="186" height="186"/>
      <rect class="soft" x="552" y="136" width="74" height="74"/>
      <rect class="hi dash" x="530" y="114" width="118" height="118" fill="none"/>
      <text class="lb" x="589" y="176" text-anchor="middle">column</text>
      <line class="ac" x1="552" y1="252" x2="530" y2="252" marker-end="url(#fc-c)"/>
      <text class="ea" x="589" y="288" text-anchor="middle">③ punching perimeter at d/2 all round</text>
      <text class="lb" x="589" y="310" text-anchor="middle">the column tries to push a block</text>
      <text class="lb" x="589" y="328" text-anchor="middle">straight through the pad</text>
    </svg>`,
    caption: "Bending is checked at the face of the column, one-way shear on a full-width section a distance d away, and punching shear on a perimeter d/2 out all round. Three checks, three sections, and in a normal isolated footing it is punching that fixes the depth.",
  },

  /* ---------------------------------------- 9.8 LOAD TRANSFER */
  "hb-rcc-dowel": {
    label: "Transfer of load from column to footing",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A column bearing on a footing, showing the loaded area A2 spreading at two horizontal to one vertical into the larger supporting area A1, with dowel bars carrying any load the bearing stress cannot">
      ${hbmk("dw")}
      <text class="em" x="350" y="26" text-anchor="middle">THE LOAD HAS TO GET OUT OF THE COLUMN FIRST</text>
      <rect class="conc" x="120" y="150" width="440" height="100"/>
      <rect class="soft" x="288" y="60" width="104" height="90"/>
      <text class="lb" x="340" y="52" text-anchor="middle">column — area A2</text>
      <path class="thin dash" d="M288 150 L188 250"/>
      <path class="thin dash" d="M392 150 L492 250"/>
      <text class="lb" x="340" y="196" text-anchor="middle">the load spreads 2 : 1</text>
      <line class="ac" x1="188" y1="266" x2="492" y2="266" marker-end="url(#dw-c)" marker-start="url(#dw-c)"/>
      <text class="ea" x="340" y="288" text-anchor="middle">area A1 — the supporting area</text>
      <path class="steel" d="M310 60 L310 224 L340 224"/>
      <path class="steel" d="M370 60 L370 224 L340 224"/>
      <text class="lb" x="576" y="96">dowels carry</text>
      <text class="lb" x="576" y="114">whatever the</text>
      <text class="lb" x="576" y="132">bearing stress</text>
      <text class="lb" x="576" y="150">cannot</text>
      <text class="em" x="120" y="96">permissible bearing</text>
      <text class="em" x="120" y="118">= 0.45 fck √(A1/A2)</text>
      <text class="lb" x="120" y="138">with √(A1/A2) not more than 2</text>
    </svg>`,
    caption: "Concrete under a small loaded area is stronger than a cube test says, because the surrounding concrete confines it — that is the whole of the √(A1/A2) factor, capped at 2. Whatever the bearing stress cannot carry goes into dowels, and the dowels must be developed on both sides of the joint.",
  },

  /* ---------------------------------------- 10.2 DEFLECTION LIMITS */
  "hb-rcc-defl": {
    label: "How a beam's deflection grows with time",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A graph of deflection against time showing an immediate elastic deflection when the load is applied, then a slow increase from creep and shrinkage over months and years, with the two code limits of span over 250 total and span over 350 after partitions marked">
      ${hbmk("df")}
      <text class="em" x="350" y="26" text-anchor="middle">DEFLECTION IS NOT OVER WHEN THE LOAD IS APPLIED</text>
      <line class="s" x1="110" y1="60" x2="110" y2="240"/>
      <line class="s" x1="110" y1="240" x2="620" y2="240"/>
      <text class="lb" x="100" y="66" text-anchor="end">deflection</text>
      <text class="lb" x="618" y="262" text-anchor="end">time →</text>

      <path class="hi" d="M110 240 L150 168 C240 128 360 108 620 96"/>
      <line class="thin dash" x1="110" y1="168" x2="620" y2="168"/>
      <line class="ac" x1="130" y1="240" x2="130" y2="170" marker-end="url(#df-c)"/>
      <text class="ea" x="140" y="212">immediate</text>
      <text class="lb" x="140" y="230">(elastic)</text>
      <text class="ea" x="330" y="146">creep + shrinkage — months to years</text>

      <line class="ac" x1="596" y1="168" x2="596" y2="98" marker-end="url(#df-c)" marker-start="url(#df-c)"/>
      <text class="lb" x="586" y="136" text-anchor="end">this part arrives</text>
      <text class="lb" x="586" y="154" text-anchor="end">after the partitions are built</text>

      <line class="acf" x1="110" y1="88" x2="620" y2="88" stroke-dasharray="2 4"/>
      <text class="em" x="110" y="80">limit: span/250 on the TOTAL</text>
      <text class="em" x="350" y="286" text-anchor="middle">limit: span/350 or 20 mm on what arrives AFTER the partitions go up (Cl. 23.2)</text>
    </svg>`,
    caption: "A beam that passes on the day it is struck can still fail its user two years later. Creep multiplies the permanent-load deflection by two or three, and it is the part that arrives after the partitions and finishes are in place that cracks them.",
  },

  /* ---------------------------------------- 10.5 CRACK CONTROL */
  "hb-rcc-crack": {
    label: "Why many small bars beat a few large ones",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="Two beam sections with the same total area of steel. The one with a few large bars widely spaced develops few wide cracks; the one with many small bars closely spaced develops many fine cracks of acceptable width">
      ${hbmk("ck")}
      <text class="em" x="168" y="26" text-anchor="middle">SAME Ast — 3 LARGE BARS</text>
      <rect class="conc" x="70" y="50" width="196" height="150"/>
      <circle class="steel" cx="100" cy="176" r="13"/>
      <circle class="steel" cx="168" cy="176" r="13"/>
      <circle class="steel" cx="236" cy="176" r="13"/>
      <path class="hi" d="M120 200 L122 128"/>
      <path class="hi" d="M210 200 L206 134"/>
      <text class="lb" x="168" y="226" text-anchor="middle">few cracks, and each one wide</text>
      <text class="em" x="168" y="252" text-anchor="middle">each bar only controls</text>
      <text class="em" x="168" y="272" text-anchor="middle">the concrete close to it</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="272"/>

      <text class="em" x="524" y="26" text-anchor="middle">SAME Ast — 6 SMALL BARS</text>
      <rect class="conc" x="426" y="50" width="196" height="150"/>
      ${[0,1,2,3,4,5].map(i=>`<circle class="steel" cx="${450+i*25}" cy="176" r="9"/>`).join("")}
      ${[0,1,2,3,4].map(i=>`<path class="hi" d="M${462+i*25} 200 L${464+i*25} ${152-i%2*10}"/>`).join("")}
      <text class="lb" x="524" y="226" text-anchor="middle">many cracks, each one fine</text>
      <text class="em" x="524" y="252" text-anchor="middle">which is why Cl. 26.3.3 limits</text>
      <text class="em" x="524" y="272" text-anchor="middle">SPACING, not just area</text>
    </svg>`,
    caption: "Total crack opening is fixed by how much the steel has stretched — that is a strength matter. How that opening is divided up is a spacing matter, and it is the width of each individual crack that corrodes the steel and worries the client.",
  },

});
