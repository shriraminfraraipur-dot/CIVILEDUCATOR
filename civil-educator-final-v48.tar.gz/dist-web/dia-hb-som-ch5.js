/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 5.
   Conventions as in dia-hb-som-ch1.js. Deflections are shown
   greatly exaggerated (real beams deflect ~span/250 or less).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 5.1  ELASTIC CURVES + BCs */
  "hb-som-elastic": {
    label: "Elastic curves and boundary conditions — cantilever and simply supported beam",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="Top: a cantilever fixed at the left wall with a load W at the free right end. The straight dashed original axis and the curved deflected elastic line are shown; at the fixed end both deflection y and slope theta are zero, at the free end both are maximum. Bottom: a simply supported beam with a central load W. The elastic line sags; deflection is zero at both supports, the slope is greatest at the supports, and at mid-span the slope is zero where the deflection is maximum.">
      ${somMk("sm8")}
      <!-- cantilever -->
      <rect class="conc" x="40" y="30" width="16" height="90"/>
      <line class="dash" x1="56" y1="70" x2="440" y2="70"/>
      <path class="hi" d="M56 70 Q 300 72 440 118"/>
      <line class="ac" x1="440" y1="70" x2="440" y2="110" marker-end="url(#sm8-c)"/>
      <text class="ea" x="448" y="88">W</text>
      <text class="lb" x="64" y="56">y = 0, θ = 0</text>
      <text class="em" x="452" y="132">y_max, θ_max (free end)</text>
      <line class="thin" x1="380" y1="98" x2="460" y2="127"/>
      <text class="lb" x="210" y="56">Cantilever</text>

      <!-- simply supported -->
      <line class="dash" x1="60" y1="210" x2="440" y2="210"/>
      <path class="hi" d="M60 210 Q 250 290 440 210"/>
      <path class="s" d="M60 212 L50 230 L70 230 Z"/><path class="s" d="M440 212 L430 230 L450 230 Z"/>
      <line class="ac" x1="250" y1="168" x2="250" y2="206" marker-end="url(#sm8-c)"/>
      <text class="ea" x="258" y="184">W</text>
      <line class="thin" x1="60" y1="210" x2="120" y2="234"/><text class="lb" x="40" y="252">y = 0, θ max</text>
      <line class="thin" x1="210" y1="250" x2="290" y2="250"/><text class="em" x="250" y="270" text-anchor="middle">θ = 0, y = y_max</text>
      <text class="lb" x="400" y="252">y = 0, θ max</text>
      <text class="lb" x="210" y="160">Simply supported</text>
      <text class="lb" x="480" y="200">Sign used here:</text>
      <text class="lb" x="480" y="216">y downward shown,</text>
      <text class="lb" x="480" y="232">EI·d²y/dx² = M</text>
    </svg>`,
    caption: "Boundary conditions are what turn the integrated equation into numbers: a fixed end gives y = 0 AND θ = 0; a simple support gives only y = 0. (Deflections exaggerated.)",
  },

  /* ---------------------------------------- 5.2  MOMENT-AREA */
  "hb-som-momarea": {
    label: "Moment-area theorems on a cantilever",
    svg: `<svg viewBox="0 0 640 320" role="img" aria-label="Top: a cantilever A–B fixed at A with a load W at B, its elastic line and the tangent at A, which is horizontal. The vertical gap at B between the tangent at A and the elastic line is the tangential deviation t B over A, which here equals the tip deflection. The angle between the tangents at A and B is theta A B. Bottom: the M over EI diagram, a triangle of height W L over E I at A tapering to zero at B; its area gives theta A B and its first moment about B — area times x bar, with x bar equal to two thirds L measured from B — gives t B over A.">
      ${somMk("sm9")}
      <rect class="conc" x="50" y="30" width="16" height="90"/>
      <line class="dash" x1="66" y1="70" x2="470" y2="70"/>
      <path class="hi" d="M66 70 Q 330 72 470 128"/>
      <line class="ac" x1="470" y1="70" x2="470" y2="128" marker-start="url(#sm9-c)" marker-end="url(#sm9-c)"/>
      <text class="ea" x="478" y="104">t B/A = y_B</text>
      <line class="thin" x1="380" y1="100" x2="520" y2="150"/>
      <text class="lb" x="524" y="156">tangent at B</text>
      <text class="lb" x="74" y="62">tangent at A (horizontal)</text>
      <text x="60" y="140">A</text><text x="462" y="146">B</text>
      <!-- M/EI diagram -->
      <path class="soft-b" d="M66 200 L66 290 L470 290 Z"/>
      <line class="thin" x1="66" y1="290" x2="470" y2="290"/>
      <text class="em" x="72" y="196">WL/EI</text>
      <circle class="hif" cx="200.7" cy="260" r="4"/>
      <line class="dash" x1="200.7" y1="260" x2="200.7" y2="306"/>
      <line class="thin" x1="200.7" y1="306" x2="470" y2="306" marker-start="url(#sm9-a)" marker-end="url(#sm9-a)"/>
      <text class="lb" x="335" y="300" text-anchor="middle">x̄ = 2L/3 (from B)</text>
      <text x="500" y="230">θ_AB = Area</text>
      <text x="500" y="250">t_B/A = Area · x̄</text>
      <text class="lb" x="500" y="270">(area of M/EI)</text>
    </svg>`,
    caption: "Theorem 1: the change in slope between A and B = area of the M/EI diagram between them. Theorem 2: the deviation of B from the tangent at A = first moment of that area taken about B. For a cantilever the tangent at the fixed end is horizontal, so the deviation IS the deflection.",
  },

  /* ---------------------------------------- 5.4  EULER END CONDITIONS */
  "hb-som-euler": {
    label: "Buckled shapes and effective lengths for the four ideal end conditions",
    svg: `<svg viewBox="0 0 640 330" role="img" aria-label="Four columns of the same length L under axial load P, each drawn with its first buckled shape. Both ends hinged: a single half sine wave, effective length L. One end fixed, other free: a quarter wave, like half of a column twice as long, effective length 2L. One end fixed, other hinged: effective length L over root 2, about 0.7L, measured between the hinge and the point of contraflexure. Both ends fixed: the middle half between the two points of contraflexure buckles like a hinged column, effective length L over 2. Dots mark points of contraflexure.">
      ${somMk("sm10")}
      ${[[80,"Hinged–hinged","Le = L","M80 60 Q 120 160 80 260"],[230,"Fixed–free","Le = 2L","M230 260 Q 232 150 262 60"],[380,"Fixed–hinged","Le = L/√2 ≈ 0.7L","M380 260 C 380 200 420 150 380 60"],[530,"Fixed–fixed","Le = L/2","M530 260 C 530 210 565 190 565 160 C 565 130 530 110 530 60"]].map(([x,t,le,d])=>`
        <line class="dash" x1="${x}" y1="60" x2="${x}" y2="260"/>
        <path class="hi" d="${d}"/>
        <line class="ac" x1="${x}" y1="20" x2="${x}" y2="52" marker-end="url(#sm10-c)"/>
        <text class="em" x="${x}" y="292" text-anchor="middle">${t}</text>
        <text class="ea" x="${x}" y="310" text-anchor="middle">${le}</text>`).join("")}
      <!-- supports -->
      <path class="s" d="M80 262 L70 276 L90 276 Z"/><path class="s" d="M80 58 L70 44 L90 44 Z"/>
      <rect class="steel" x="214" y="262" width="32" height="8"/>
      <rect class="steel" x="364" y="262" width="32" height="8"/><path class="s" d="M380 58 L370 44 L390 44 Z"/>
      <rect class="steel" x="514" y="262" width="32" height="8"/><rect class="steel" x="514" y="50" width="32" height="8"/>
      <!-- contraflexure points -->
      <circle class="acf" cx="398" cy="140" r="0"/>
      <circle class="acf" cx="547" cy="210" r="4"/><circle class="acf" cx="547" cy="110" r="4"/>
      <text class="lb" x="320" y="16" text-anchor="middle">P (axial load on each)</text>
    </svg>`,
    caption: "Effective length = distance between points of zero moment (contraflexure) of the buckled shape — i.e. the length of an equivalent pin-ended column. These are the theoretical values; codes recommend larger ones for real, imperfect end restraint (§5.5).",
  },
});
