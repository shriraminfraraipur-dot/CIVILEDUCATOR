/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 7.
   Conventions as in dia-hb-som-ch1.js. The Lamé curves and the
   dam are drawn to scale for Worked examples 7.4 and 7.6.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 7.1  THIN CYLINDER FBDs */
  "hb-som-thincyl": {
    label: "Thin cylinder — the two cuts that give hoop and longitudinal stress",
    svg: `<svg viewBox="0 0 640 280" role="img" aria-label="Left: a thin cylinder cut along its length into two halves. Internal pressure p acts on the projected area d times L, pushing the halves apart; it is resisted by the hoop stress sigma h acting on the two cut wall strips, each of area t times L. Balancing gives sigma h equals p d over 2 t. Right: the cylinder cut across its length. Pressure acts on the end area pi d squared over 4 and is resisted by the longitudinal stress sigma l on the thin ring of area pi d t. Balancing gives sigma l equals p d over 4 t, half the hoop stress.">
      ${somMk("sm12")}
      <!-- longitudinal cut -->
      <path class="s" d="M60 150 A 90 90 0 0 1 240 150"/>
      <path class="s" d="M70 150 A 80 80 0 0 1 230 150"/>
      <line class="s" x1="60" y1="150" x2="70" y2="150"/><line class="s" x1="230" y1="150" x2="240" y2="150"/>
      ${[90,120,150,180,210].map(x=>`<line class="ac" x1="${x}" y1="150" x2="${x}" y2="${150-Math.sqrt(Math.max(0,80*80-(x-150)*(x-150)))+8}" marker-end="url(#sm12-c)"/>`).join("")}
      <line class="hi" x1="65" y1="152" x2="65" y2="196" marker-end="url(#sm12-m)"/>
      <line class="hi" x1="235" y1="152" x2="235" y2="196" marker-end="url(#sm12-m)"/>
      <text class="ea" x="150" y="140" text-anchor="middle">p on area d·L</text>
      <text class="em" x="40" y="214">σ_h</text><text class="em" x="240" y="214">σ_h</text>
      <text x="150" y="246" text-anchor="middle">p·d·L = 2·σ_h·t·L</text>
      <text class="em" x="150" y="266" text-anchor="middle">σ_h = pd / 2t</text>

      <!-- transverse cut -->
      <rect class="conc" x="380" y="70" width="12" height="150"/>
      <line class="s" x1="392" y1="70" x2="560" y2="70"/><line class="s" x1="392" y1="220" x2="560" y2="220"/>
      <line class="s" x1="392" y1="80" x2="560" y2="80"/><line class="s" x1="392" y1="210" x2="560" y2="210"/>
      ${[100,125,150,175,200].map(y=>`<line class="ac" x1="470" y1="${y-5}" x2="400" y2="${y-5}" marker-end="url(#sm12-c)"/>`).join("")}
      <line class="hi" x1="560" y1="75" x2="604" y2="75" marker-end="url(#sm12-m)"/>
      <line class="hi" x1="560" y1="215" x2="604" y2="215" marker-end="url(#sm12-m)"/>
      <text class="em" x="608" y="70">σ_l</text>
      <text class="ea" x="480" y="150">p on πd²/4</text>
      <text x="480" y="246" text-anchor="middle">p·πd²/4 = σ_l·π·d·t</text>
      <text class="em" x="480" y="266" text-anchor="middle">σ_l = pd / 4t</text>
    </svg>`,
    caption: "Same pressure, two free bodies. The longitudinal cut exposes wall area 2tL against a pressure force pdL; the transverse cut exposes πdt against only πd²p/4 — so the hoop stress is twice the longitudinal stress, and a pipe splits lengthwise first.",
  },

  /* ---------------------------------------- 7.2  LAMÉ DISTRIBUTION */
  "hb-som-lame": {
    label: "Lamé stresses across the wall of a thick cylinder (Worked example 7.1, to scale)",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="Graph across the wall thickness, from the bore at radius 100 millimetres on the left to the outer surface at 150 on the right. The hoop stress is tensile everywhere, 52 newtons per square millimetre at the bore falling along a curve to 32 at the outside. The radial stress is compressive, minus 20 at the bore (equal to the internal pressure) rising to zero at the outer surface. The thin-cylinder formula would give a single uniform value of 40, which under-estimates the bore stress.">
      <line class="s" x1="120" y1="200" x2="540" y2="200"/>
      <line class="s" x1="120" y1="30" x2="120" y2="280"/>
      <text class="lb" x="120" y="296" text-anchor="middle">r = a = 100 (bore)</text>
      <text class="lb" x="520" y="296" text-anchor="middle">r = b = 150</text>
      <text x="128" y="26">stress (N/mm²)</text>
      <path class="hi" d="M120.0 44.0 L160.0 54.0 L200.0 62.7 L240.0 70.3 L280.0 77.0 L320.0 82.9 L360.0 88.1 L400.0 92.7 L440.0 96.9 L480.0 100.6 L520.0 104.0"/>
      <path class="ac" d="M120.0 260.0 L160.0 250.0 L200.0 241.3 L240.0 233.7 L280.0 227.0 L320.0 221.1 L360.0 215.9 L400.0 211.3 L440.0 207.1 L480.0 203.4 L520.0 200.0"/>
      <line class="dash" x1="120" y1="80" x2="520" y2="80"/>
      <text class="lb" x="330" y="74">thin-cylinder estimate pd/2t = 40 (uniform)</text>
      <text class="em" x="128" y="40">σ_θ = 52</text><text class="em" x="526" y="108">32</text>
      <text class="ea" x="128" y="276">σ_r = −20 (= −p)</text><text class="ea" x="526" y="196">0</text>
      <text class="em" x="300" y="120">hoop σ_θ = A + B/r²</text>
      <text class="ea" x="300" y="250">radial σ_r = A − B/r²</text>
    </svg>`,
    caption: "Both stresses are steepest at the bore, which is why thick cylinders crack from the inside. Here the thin-wall formula (40) would under-estimate the true peak hoop stress (52) by about 23%.",
  },

  /* ---------------------------------------- 7.4  GRAVITY DAM */
  "hb-som-dam": {
    label: "Gravity dam of Worked example 7.5 — forces, middle third and base pressure (to scale)",
    svg: `<svg viewBox="0 0 640 400" role="img" aria-label="A trapezoidal gravity dam 12 metres high with a vertical upstream face, 2 metre top width and 9 metre base, holding water to the full height. Its weight W acts downward 3.12 metres from the heel; the water thrust P acts horizontally at one third of the height. The middle third of the base is marked between 3 and 6 metres from the heel. Without uplift the resultant cuts the base at 5.03 metres, inside the middle third. A triangular uplift diagram under the base pushes up; with full uplift the resultant moves to 6.17 metres, just outside the middle third. On the right, two base pressure diagrams: without uplift, compression of 106 kilonewtons per square metre at the heel rising to 223 at the toe; with full uplift, the heel goes slightly into tension, minus 12.">
      ${somMk("sm13")}
      <!-- water -->
      <path class="softa" d="M50 60 L150 60 L150 300 L50 300 Z"/>
      <text class="ea" x="56" y="54">water, H = 12 m</text>
      <!-- dam (20 px/m) -->
      <path class="conc" d="M150 300 L150 60 L190 60 L330 300 Z"/>
      <line class="s" x1="40" y1="300" x2="360" y2="300"/>
      <!-- forces -->
      <line class="ac" x1="70" y1="220" x2="146" y2="220" marker-end="url(#sm13-c)"/>
      <text class="ea" x="60" y="212">P = 706 kN</text><text class="lb" x="60" y="240">at H/3</text>
      <line class="hi" x1="212.4" y1="150" x2="212.4" y2="230" marker-end="url(#sm13-m)"/>
      <text class="em" x="218" y="170">W = 1478 kN</text>
      <!-- middle third -->
      <line class="thin" x1="210" y1="306" x2="270" y2="306" style="stroke-width:4"/>
      <text class="lb" x="240" y="294" text-anchor="middle">middle third</text>
      <circle class="hif" cx="250.6" cy="300" r="5"/>
      <circle class="acf" cx="273.3" cy="300" r="5"/>
      <text class="em" x="246" y="278" text-anchor="end">R (no uplift)</text>
      <text class="ea" x="282" y="278">R (uplift)</text>
      <!-- uplift -->
      <path class="softa" d="M150 300 L150 348 L330 300 Z" style="opacity:.3"/>
      ${[160,200,240,280].map(x=>`<line class="ac" x1="${x}" y1="${300+48*(330-x)/180}" x2="${x}" y2="304" marker-end="url(#sm13-c)"/>`).join("")}
      <text class="ea" x="150" y="364">uplift U = 530 kN</text>
      <text class="lb" x="150" y="384">heel</text><text class="lb" x="318" y="384">toe</text>

      <!-- base pressure diagrams: base 380..560, 0.25 px per kPa -->
      <text x="380" y="40">Base pressure, no uplift</text>
      <line class="s" x1="380" y1="90" x2="560" y2="90"/>
      <path class="soft-b" d="M380 90 L380 116.5 L560 145.6 L560 90 Z"/>
      <text class="lb" x="372" y="122" text-anchor="end">106</text><text class="em" x="566" y="150">223 kPa</text>
      <text x="380" y="210">With full uplift</text>
      <line class="s" x1="380" y1="260" x2="560" y2="260"/>
      <path class="soft-b" d="M389 260 L560 315.6 L560 260 Z"/>
      <path class="soft-b" d="M380 260 L380 257.1 L389 260 Z" style="fill:var(--accent)"/>
      <text class="ea" x="384" y="250">heel −12 (tension)</text><text class="em" x="566" y="320">223 kPa</text>
      <text class="lb" x="470" y="350" text-anchor="middle">heel ← base → toe</text>
    </svg>`,
    caption: "Worked example 7.5 to scale. Ignoring uplift the dam looks safe (resultant inside the middle third); with full uplift the resultant drifts past b/3 from the toe and the heel goes into tension — which is why drainage galleries and cut-off curtains are provided to cut uplift.",
  },
});
