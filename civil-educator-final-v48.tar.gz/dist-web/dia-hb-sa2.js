/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: Structural Analysis handbook, Ch. 2–3
   Trusses, and shear force / bending moment.
   Conventions as in dia-hb-sa1.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 2.2 TRUSS ANATOMY */
  "hb-sa-truss-anatomy": {
    label: "Parts of a truss",
    svg: `<svg viewBox="0 0 704 280" role="img" aria-label="A Pratt truss with top chord, bottom chord, verticals, diagonals, panel points and panel length all labelled, supported on a hinge and a roller">
      ${hbmk("ta")}
      <line class="s" x1="80" y1="200" x2="560" y2="200"/>
      <line class="s" x1="200" y1="100" x2="440" y2="100"/>
      <line class="s" x1="80" y1="200" x2="200" y2="100"/>
      <line class="s" x1="440" y1="100" x2="560" y2="200"/>
      <line class="s" x1="200" y1="100" x2="200" y2="200"/>
      <line class="s" x1="320" y1="100" x2="320" y2="200"/>
      <line class="s" x1="440" y1="100" x2="440" y2="200"/>
      <line class="s" x1="200" y1="100" x2="320" y2="200"/>
      <line class="s" x1="440" y1="100" x2="320" y2="200"/>

      <circle class="acf" cx="80" cy="200" r="5"/><circle class="acf" cx="200" cy="200" r="5"/>
      <circle class="acf" cx="320" cy="200" r="5"/><circle class="acf" cx="440" cy="200" r="5"/>
      <circle class="acf" cx="560" cy="200" r="5"/>
      <circle class="acf" cx="200" cy="100" r="5"/><circle class="acf" cx="320" cy="100" r="5"/>
      <circle class="acf" cx="440" cy="100" r="5"/>

      <path class="s" d="M80 200 L66 224 L94 224 Z"/>
      ${grd(58, 224, 44)}
      <circle class="s" cx="550" cy="212" r="10"/><circle class="s" cx="572" cy="212" r="10"/>
      ${grd(536, 224, 48)}

      <text class="em" x="320" y="90" text-anchor="middle">TOP CHORD — usually compression</text>
      <text class="em" x="320" y="222" text-anchor="middle">BOTTOM CHORD — usually tension</text>
      <line class="thin" x1="290" y1="150" x2="314" y2="150"/>
      <text class="lb" x="286" y="154" text-anchor="end">vertical</text>
      <line class="thin" x1="390" y1="160" x2="366" y2="152"/>
      <text class="lb" x="394" y="164">diagonal</text>
      <line class="thin" x1="200" y1="252" x2="320" y2="252" marker-start="url(#ta-a)" marker-end="url(#ta-a)"/>
      <text class="lb" x="260" y="268" text-anchor="middle">panel length</text>
      <text class="lb" x="80" y="256" text-anchor="middle">panel point</text>
      <line class="thin" x1="80" y1="246" x2="80" y2="210"/>
      <text class="lb" x="620" y="150">loads act</text>
      <text class="lb" x="620" y="166">only at</text>
      <text class="lb" x="620" y="182">panel points</text>
      <line class="ac" x1="320" y1="232" x2="320" y2="210" marker-end="url(#ta-c)"/>
    </svg>`,
    caption: "Every member is straight and pin-ended, and <strong>load arrives only at the panel points</strong>. Break either rule — hang a load from the middle of a member, or weld the joints so they carry moment — and the members stop being pure axial members.",
  },

  /* ---------------------------------------- 2.4 METHOD OF JOINTS */
  "hb-sa-joints": {
    label: "Free body of a single joint",
    svg: `<svg viewBox="0 0 704 300" role="img" aria-label="Left, a truss with one joint circled. Right, the free body of that joint showing the reaction, the two unknown member forces assumed as tension, and the two equilibrium equations">
      ${hbmk("jt")}
      <text class="lb" x="160" y="24" text-anchor="middle">PICK A JOINT WITH ONLY TWO UNKNOWNS</text>
      <line class="s" x1="60" y1="190" x2="300" y2="190"/>
      <line class="s" x1="60" y1="190" x2="180" y2="110"/>
      <line class="s" x1="180" y1="110" x2="300" y2="190"/>
      <line class="s" x1="180" y1="110" x2="180" y2="190"/>
      <path class="s" d="M60 190 L46 212 L74 212 Z"/>
      ${grd(38, 212, 44)}
      <circle class="hi" cx="60" cy="190" r="17"/>
      <text class="em" x="60" y="248" text-anchor="middle">joint A</text>

      <line class="gl" x1="352" y1="16" x2="352" y2="288"/>

      <text class="lb" x="516" y="24" text-anchor="middle">FREE BODY OF THAT JOINT</text>
      <circle class="acf" cx="500" cy="176" r="6"/>
      <line class="hi" x1="500" y1="240" x2="500" y2="188" marker-end="url(#jt-m)"/>
      <text class="em" x="512" y="226">VA</text>
      <line class="ac" x1="510" y1="176" x2="612" y2="176" marker-end="url(#jt-c)"/>
      <text class="ea" x="618" y="180">F₁</text>
      <line class="ac" x1="508" y1="169" x2="592" y2="113" marker-end="url(#jt-c)"/>
      <text class="ea" x="598" y="110">F₂</text>
      <path class="thin dash" d="M500 176 L592 176"/>
      <path class="thin" d="M544 176 A44 44 0 0 0 536 150"/>
      <text class="lb" x="556" y="164">θ</text>
      <text class="lb" x="516" y="270" text-anchor="middle">both unknowns drawn pulling AWAY from the joint</text>
      <text class="lb" x="516" y="288" text-anchor="middle">— so a minus sign in the answer simply means compression</text>
    </svg>`,
    caption: "Two equations, ΣFx = 0 and ΣFy = 0, so <strong>a joint can be solved only when it has at most two unknown members.</strong> Start where the reactions are known and work inwards; if no joint qualifies, you need a section cut instead.",
  },

  /* ---------------------------------------- 2.5 ZERO-FORCE MEMBERS */
  "hb-sa-zero": {
    label: "The three zero-force member cases",
    svg: `<svg viewBox="0 0 680 250" role="img" aria-label="Case one, two non-collinear members at an unloaded joint are both zero. Case two, three members with two collinear and no load means the odd member is zero. Case three, a load along one member makes the other zero.">
      ${hbmk("zf")}
      <text class="lb" x="110" y="26" text-anchor="middle">CASE 1</text>
      <line class="hi" x1="110" y1="120" x2="110" y2="190"/>
      <line class="hi" x1="110" y1="120" x2="180" y2="120"/>
      <circle class="acf" cx="110" cy="120" r="6"/>
      <text class="em" x="100" y="160" text-anchor="end">0</text>
      <text class="em" x="146" y="112" text-anchor="middle">0</text>
      <text class="lb" x="110" y="216" text-anchor="middle">two members,</text>
      <text class="lb" x="110" y="232" text-anchor="middle">no load → both zero</text>

      <line class="gl" x1="232" y1="16" x2="232" y2="240"/>

      <text class="lb" x="342" y="26" text-anchor="middle">CASE 2</text>
      <line class="s" x1="272" y1="120" x2="412" y2="120"/>
      <line class="hi" x1="342" y1="120" x2="342" y2="190"/>
      <circle class="acf" cx="342" cy="120" r="6"/>
      <text class="em" x="332" y="160" text-anchor="end">0</text>
      <text class="lb" x="342" y="216" text-anchor="middle">three members, two collinear,</text>
      <text class="lb" x="342" y="232" text-anchor="middle">no load → the odd one is zero</text>

      <line class="gl" x1="464" y1="16" x2="464" y2="240"/>

      <text class="lb" x="574" y="26" text-anchor="middle">CASE 3</text>
      <line class="s" x1="574" y1="120" x2="574" y2="190"/>
      <line class="hi" x1="574" y1="120" x2="644" y2="120"/>
      <circle class="acf" cx="574" cy="120" r="6"/>
      <line class="ac" x1="574" y1="66" x2="574" y2="112" marker-end="url(#zf-c)"/>
      <text class="ea" x="586" y="86">P</text>
      <text class="em" x="610" y="112" text-anchor="middle">0</text>
      <text class="lb" x="574" y="216" text-anchor="middle">load acts along one member</text>
      <text class="lb" x="574" y="232" text-anchor="middle">→ the other is zero</text>
    </svg>`,
    caption: "Spotting these first can remove a third of the arithmetic. They are <strong>not useless members</strong> — they brace the compression chord against buckling and carry force under other load cases. Zero here means zero for <em>this</em> loading only.",
  },

  /* ---------------------------------------- 2.6 METHOD OF SECTIONS */
  "hb-sa-sections": {
    label: "A section cut through three members",
    svg: `<svg viewBox="0 0 680 300" role="img" aria-label="A parallel chord truss cut by a vertical plane through the top chord, a diagonal and the bottom chord; the left portion is drawn as a free body with the three cut forces, and moment centres are marked">
      ${hbmk("sx")}
      <line class="s" x1="60" y1="200" x2="540" y2="200"/>
      <line class="s" x1="180" y1="120" x2="420" y2="120"/>
      <line class="s" x1="60" y1="200" x2="180" y2="120"/>
      <line class="s" x1="420" y1="120" x2="540" y2="200"/>
      <line class="s" x1="180" y1="120" x2="180" y2="200"/>
      <line class="s" x1="300" y1="120" x2="300" y2="200"/>
      <line class="s" x1="420" y1="120" x2="420" y2="200"/>
      <line class="s" x1="180" y1="120" x2="300" y2="200"/>
      <line class="s" x1="420" y1="120" x2="300" y2="200"/>
      <path class="s" d="M60 200 L46 222 L74 222 Z"/>
      ${grd(38, 222, 44)}
      <circle class="s" cx="530" cy="212" r="10"/><circle class="s" cx="552" cy="212" r="10"/>
      ${grd(516, 224, 48)}

      <path class="hi dash" d="M246 92 L246 236" style="stroke-dasharray:7 5"/>
      <text class="em" x="246" y="84" text-anchor="middle">CUT</text>

      <circle class="acf" cx="180" cy="120" r="6"/>
      <text class="ea" x="180" y="108" text-anchor="middle">G</text>
      <circle class="acf" cx="300" cy="200" r="6"/>
      <text class="ea" x="300" y="224" text-anchor="middle">E</text>

      <line class="ac" x1="246" y1="120" x2="196" y2="120" marker-end="url(#sx-c)"/>
      <text class="ea" x="214" y="112" text-anchor="middle">F(top)</text>
      <line class="ac" x1="246" y1="200" x2="196" y2="200" marker-end="url(#sx-c)"/>
      <text class="ea" x="214" y="220" text-anchor="middle">F(bot)</text>
      <line class="ac" x1="246" y1="164" x2="212" y2="141" marker-end="url(#sx-c)"/>
      <text class="ea" x="252" y="168">F(diag)</text>

      <line class="gl" x1="20" y1="252" x2="660" y2="252"/>
      <text class="em" x="340" y="276" text-anchor="middle">Take moments about E → only F(top) survives.   Take moments about G → only F(bot) survives.</text>
      <text class="lb" x="340" y="294" text-anchor="middle">Use ΣFy for the diagonal. Three unknowns, three equations, one answer each.</text>
    </svg>`,
    caption: "The whole trick is the <strong>choice of moment centre</strong>: pick the point where two of the three cut forces intersect and they both vanish, leaving one equation in one unknown. A far-off member that would need seven joints solved comes out in a single line.",
  },

  /* ---------------------------------------- 3.1 INTERNAL FORCES */
  "hb-sa-internal": {
    label: "Internal forces exposed by a cut",
    svg: `<svg viewBox="0 0 680 260" role="img" aria-label="A beam cut at a section, with the left portion drawn as a free body showing axial force, shear force and bending moment acting on the cut face, equal and opposite on the right portion">
      ${hbmk("in")}
      <line class="s" x1="60" y1="90" x2="620" y2="90"/>
      <path class="s" d="M60 90 L46 112 L74 112 Z"/>
      ${grd(38, 112, 44)}
      <circle class="s" cx="610" cy="102" r="10"/><circle class="s" cx="632" cy="102" r="10"/>
      ${grd(596, 114, 48)}
      <line class="ac" x1="300" y1="40" x2="300" y2="82" marker-end="url(#in-c)"/>
      <text class="ea" x="312" y="58">P</text>
      <path class="hi dash" d="M420 54 L420 128" style="stroke-dasharray:7 5"/>
      <text class="em" x="420" y="46" text-anchor="middle">section X–X</text>

      <line class="gl" x1="20" y1="150" x2="660" y2="150"/>

      <text class="lb" x="200" y="176" text-anchor="middle">LEFT FREE BODY</text>
      <rect class="conc" x="80" y="196" width="230" height="20"/>
      <line class="hi" x1="90" y1="248" x2="90" y2="222" marker-end="url(#in-m)"/>
      <line class="hi" x1="310" y1="196" x2="310" y2="244" marker-end="url(#in-m)"/>
      <text class="em" x="322" y="236">V</text>
      <line class="hi" x1="318" y1="206" x2="352" y2="206" marker-end="url(#in-m)"/>
      <text class="em" x="358" y="210">N</text>
      <path class="hi" d="M296 184 A26 26 0 0 1 320 178" marker-start="url(#in-m)"/>
      <text class="em" x="300" y="176" text-anchor="middle">M</text>

      <text class="lb" x="520" y="176" text-anchor="middle">RIGHT FREE BODY</text>
      <rect class="conc" x="430" y="196" width="180" height="20"/>
      <line class="hi" x1="430" y1="244" x2="430" y2="196" marker-end="url(#in-m)"/>
      <text class="em" x="406" y="236">V</text>
      <line class="hi" x1="422" y1="206" x2="392" y2="206" marker-end="url(#in-m)"/>
      <text class="em" x="378" y="210">N</text>
      <path class="hi" d="M444 178 A26 26 0 0 0 420 184" marker-start="url(#in-m)"/>
      <text class="em" x="444" y="176" text-anchor="middle">M</text>
      <text class="lb" x="340" y="258" text-anchor="middle">equal and opposite — they are the same pair of internal actions seen from two sides</text>
    </svg>`,
    caption: "There is nothing mysterious about an internal force. <strong>Cut the beam, and whatever the missing half was doing must be replaced by N, V and M on the cut face.</strong> Every SF and BM value in the subject comes from applying the three equilibrium equations to one of these free bodies.",
  },

  /* ---------------------------------------- 3.2 LOAD–SF–BM */
  "hb-sa-relations": {
    label: "The relationship between load, shear force and bending moment",
    svg: `<svg viewBox="0 0 680 400" role="img" aria-label="Three stacked diagrams for a simply supported beam under uniformly distributed load: the loading, the linear shear force diagram crossing zero at mid span, and the parabolic bending moment diagram peaking where the shear is zero">
      ${hbmk("rl")}
      <text class="lb" x="30" y="30">LOAD  w</text>
      <line class="s" x1="120" y1="60" x2="560" y2="60"/>
      <line class="thin" x1="120" y1="36" x2="560" y2="36"/>
      ${[0,1,2,3,4,5,6,7,8,9,10].map(i=>`<line class="ac" x1="${120+i*44}" y1="38" x2="${120+i*44}" y2="56" marker-end="url(#rl-c)"/>`).join("")}
      <path class="s" d="M120 60 L106 82 L134 82 Z"/>
      <circle class="s" cx="550" cy="72" r="10"/><circle class="s" cx="572" cy="72" r="10"/>

      <text class="lb" x="30" y="146">SHEAR  V</text>
      <line class="s" x1="120" y1="160" x2="560" y2="160"/>
      <path class="softa" d="M120 120 L340 160 L120 160 Z"/>
      <path class="softa" d="M340 160 L560 200 L560 160 Z"/>
      <path class="ac" d="M120 120 L560 200"/>
      <line class="thin dash" x1="340" y1="120" x2="340" y2="300"/>
      <text class="ea" x="140" y="114">+wL/2</text>
      <text class="ea" x="540" y="216" text-anchor="end">−wL/2</text>
      <circle class="acf" cx="340" cy="160" r="5"/>
      <text class="ea" x="352" y="152">V = 0</text>
      <text class="lb" x="596" y="150">slope of V</text>
      <text class="lb" x="596" y="166">= −w</text>

      <text class="lb" x="30" y="266">MOMENT  M</text>
      <line class="s" x1="120" y1="280" x2="560" y2="280"/>
      <path class="soft" d="M120 280 Q340 400 560 280 Z"/>
      <path class="hi" d="M120 280 Q340 400 560 280"/>
      <circle class="hif" cx="340" cy="340" r="5"/>
      <text class="em" x="340" y="364" text-anchor="middle">M(max) = wL²/8</text>
      <text class="lb" x="596" y="270">slope of M</text>
      <text class="lb" x="596" y="286">= V</text>
      <text class="lb" x="340" y="392" text-anchor="middle">maximum moment sits exactly where the shear crosses zero</text>
    </svg>`,
    caption: "Two derivatives tie the three diagrams together: <strong>dV/dx = −w and dM/dx = V.</strong> So load controls the slope of the shear diagram, shear controls the slope of the moment diagram, and the moment peaks wherever the shear passes through zero — which is how you find the maximum without calculus.",
  },

  /* ---------------------------------------- 3.4 STANDARD CASES */
  "hb-sa-standard": {
    label: "Standard shear force and bending moment diagrams",
    svg: `<svg viewBox="0 0 680 420" role="img" aria-label="Three standard cases side by side: simply supported beam with a uniformly distributed load, simply supported beam with a central point load, and a cantilever with a uniformly distributed load, each with its shear force and bending moment diagram and peak value">
      ${hbmk("st2")}
      <text class="lb" x="113" y="24" text-anchor="middle">SS + UDL</text>
      <line class="s" x1="34" y1="62" x2="192" y2="62"/>
      ${[0,1,2,3,4,5,6].map(i=>`<line class="ac" x1="${36+i*26}" y1="44" x2="${36+i*26}" y2="58" marker-end="url(#st2-c)"/>`).join("")}
      <path class="s" d="M34 62 L24 78 L44 78 Z"/><circle class="s" cx="186" cy="70" r="8"/>
      <line class="s" x1="34" y1="130" x2="192" y2="130"/>
      <path class="ac" d="M34 108 L192 152"/>
      <text class="lb" x="113" y="172" text-anchor="middle">V linear</text>
      <line class="s" x1="34" y1="250" x2="192" y2="250"/>
      <path class="soft" d="M34 250 Q113 330 192 250 Z"/>
      <path class="hi" d="M34 250 Q113 330 192 250"/>
      <text class="em" x="113" y="356" text-anchor="middle">wL²/8</text>
      <text class="lb" x="113" y="376" text-anchor="middle">parabolic</text>

      <line class="gl" x1="226" y1="16" x2="226" y2="400"/>

      <text class="lb" x="340" y="24" text-anchor="middle">SS + CENTRAL LOAD</text>
      <line class="s" x1="262" y1="62" x2="420" y2="62"/>
      <line class="ac" x1="341" y1="34" x2="341" y2="58" marker-end="url(#st2-c)"/>
      <text class="ea" x="352" y="44">W</text>
      <path class="s" d="M262 62 L252 78 L272 78 Z"/><circle class="s" cx="414" cy="70" r="8"/>
      <line class="s" x1="262" y1="130" x2="420" y2="130"/>
      <path class="ac" d="M262 108 L341 108 L341 152 L420 152"/>
      <text class="lb" x="340" y="172" text-anchor="middle">V constant, jumps at the load</text>
      <line class="s" x1="262" y1="250" x2="420" y2="250"/>
      <path class="soft" d="M262 250 L341 320 L420 250 Z"/>
      <path class="hi" d="M262 250 L341 320 L420 250"/>
      <text class="em" x="340" y="356" text-anchor="middle">WL/4</text>
      <text class="lb" x="340" y="376" text-anchor="middle">triangular — a kink under the load</text>

      <line class="gl" x1="454" y1="16" x2="454" y2="400"/>

      <text class="lb" x="566" y="24" text-anchor="middle">CANTILEVER + UDL</text>
      <line class="s" x1="490" y1="62" x2="646" y2="62"/>
      ${[0,1,2,3,4,5,6].map(i=>`<line class="ac" x1="${492+i*26}" y1="44" x2="${492+i*26}" y2="58" marker-end="url(#st2-c)"/>`).join("")}
      <line class="s" x1="490" y1="40" x2="490" y2="86"/>
      ${grd(468, 86, 24)}
      <line class="s" x1="490" y1="130" x2="646" y2="130"/>
      <path class="ac" d="M490 96 L646 130"/>
      <text class="lb" x="566" y="172" text-anchor="middle">V zero at the free end</text>
      <line class="s" x1="490" y1="250" x2="646" y2="250"/>
      <path class="soft" d="M490 250 Q568 250 646 250 L646 250 Q568 180 490 180 Z"/>
      <path class="hi" d="M490 180 Q568 180 646 250"/>
      <text class="em" x="566" y="356" text-anchor="middle">wL²/2 at the fixed end</text>
      <text class="lb" x="566" y="376" text-anchor="middle">hogging everywhere</text>

      <text class="lb" x="340" y="406" text-anchor="middle">Degree rises by one each time: UDL constant → V linear → M parabolic.</text>
    </svg>`,
    caption: "Worth knowing by heart, because they are the building blocks of everything else. Note the pattern: <strong>each diagram is one degree higher than the one above it.</strong> A point load makes a jump in V and a kink in M; a UDL makes V linear and M parabolic.",
  },

  /* ---------------------------------------- 3.5 OVERHANG */
  "hb-sa-overhang": {
    label: "Overhanging beam and the point of contraflexure",
    svg: `<svg viewBox="0 0 680 330" role="img" aria-label="An overhanging beam under uniform load, with its bending moment diagram sagging inside the span and hogging over the overhang, crossing zero at the point of contraflexure">
      ${hbmk("ov")}
      <line class="s" x1="70" y1="70" x2="610" y2="70"/>
      ${[0,1,2,3,4,5,6,7,8,9,10,11,12].map(i=>`<line class="ac" x1="${72+i*42}" y1="44" x2="${72+i*42}" y2="66" marker-end="url(#ov-c)"/>`).join("")}
      <path class="s" d="M70 70 L56 92 L84 92 Z"/>
      ${grd(48, 92, 44)}
      <circle class="s" cx="470" cy="82" r="10"/><circle class="s" cx="492" cy="82" r="10"/>
      ${grd(456, 94, 48)}
      <text class="lb" x="70" y="118" text-anchor="middle">A</text>
      <text class="lb" x="481" y="118" text-anchor="middle">B</text>
      <text class="lb" x="610" y="92" text-anchor="middle">C</text>
      <line class="thin" x1="70" y1="136" x2="481" y2="136" marker-start="url(#ov-a)" marker-end="url(#ov-a)"/>
      <text class="lb" x="275" y="152" text-anchor="middle">span 6 m</text>
      <line class="thin" x1="481" y1="136" x2="610" y2="136" marker-start="url(#ov-a)" marker-end="url(#ov-a)"/>
      <text class="lb" x="546" y="152" text-anchor="middle">overhang 2 m</text>

      <line class="s" x1="70" y1="230" x2="610" y2="230"/>
      <path class="softa" d="M70 230 Q250 300 435 230 Z"/>
      <path class="ac" d="M70 230 Q250 300 435 230"/>
      <path class="soft" d="M435 230 Q470 206 481 200 L481 230 Z"/>
      <path class="hi" d="M435 230 Q462 210 481 200 Q540 216 610 230"/>
      <circle class="acf" cx="435" cy="230" r="5"/>
      <line class="thin dash" x1="435" y1="200" x2="435" y2="252"/>
      <text class="ea" x="435" y="268" text-anchor="middle">point of contraflexure</text>
      <text class="ea" x="435" y="286" text-anchor="middle">x = 5.33 m from A</text>
      <text class="ea" x="250" y="316" text-anchor="middle">+35.6 kNm sagging</text>
      <text class="em" x="540" y="192" text-anchor="middle">−20 kNm hogging at B</text>
      <text class="lb" x="340" y="326" text-anchor="middle">Top steel must run past this point — not stop at the support</text>
    </svg>`,
    caption: "An overhang pulls hogging moment back into the span, and the moment crosses zero somewhere inside it. <strong>That crossing is where the tension face flips from bottom to top</strong>, which is exactly where the reinforcement has to change sides — and why the top steel has to continue past it.",
  },

});
