/* ============================================================
   CIVIL EDUCATOR — inline SVG diagrams for key topics
   Theme-aware: strokes use currentColor, meaning-carrying
   elements use the accent / marker tokens via CSS classes.
   Each entry: { svg, caption }
   ============================================================ */

window.DB = window.DB || {};

/* Arrow marker defs — id is prefixed per diagram so two figures never collide */
function mk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}
/* double-headed dimension line */
function dim(id, x1, y1, x2, y2) {
  return `<line class="thin" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-start="url(#${id}-a)" marker-end="url(#${id}-a)"/>`;
}

DB.diagrams = {

  /* ---------------------------------------------- NOMINAL COVER */
  "t-cover": {
    label: "Nominal cover in a beam section",
    svg: `<svg viewBox="0 0 470 300" role="img" aria-label="Beam cross section showing nominal cover measured from the concrete face to the outside of the stirrup, with effective depth d and overall depth D marked">
      ${mk("cv")}
      <rect class="conc" x="150" y="34" width="180" height="210"/>
      <path class="soft" fill-rule="evenodd" d="M150 34 H330 V244 H150 Z M176 60 H304 V218 H176 Z"/>
      <rect class="hi" x="176" y="60" width="128" height="158" rx="8"/>
      <circle class="steel" cx="196" cy="204" r="9"/>
      <circle class="steel" cx="240" cy="204" r="9"/>
      <circle class="steel" cx="284" cy="204" r="9"/>
      <circle class="steel" cx="196" cy="76" r="7"/>
      <circle class="steel" cx="284" cy="76" r="7"/>
      <line class="thin" x1="88" y1="47" x2="163" y2="47"/>
      <text class="em" x="84" y="51" text-anchor="end">cover c</text>
      <line class="thin" x1="88" y1="240" x2="190" y2="219"/>
      <text class="lb" x="84" y="244" text-anchor="end">stirrup</text>
      ${dim("cv", 352, 34, 352, 204)}
      <line class="thin" x1="346" y1="34" x2="358" y2="34"/>
      <line class="thin" x1="346" y1="204" x2="358" y2="204"/>
      <text x="362" y="123">d</text>
      ${dim("cv", 400, 34, 400, 244)}
      <line class="thin" x1="394" y1="244" x2="406" y2="244"/>
      <text x="410" y="143">D</text>
      ${dim("cv", 150, 274, 330, 274)}
      <text x="240" y="268" text-anchor="middle">b</text>
    </svg>`,
    caption: "Cover is measured from the concrete face to the <strong>outside of the stirrup</strong> — not to the main bar. Increasing cover for durability reduces the effective depth d, so the flexural design must be re-checked.",
  },

  /* ---------------------------------------------- DEVELOPMENT LENGTH */
  "t-ld": {
    label: "How development length works",
    svg: `<svg viewBox="0 0 480 210" role="img" aria-label="A reinforcing bar embedded in concrete, with bond stress acting along its surface over the development length, resisting the pull in the bar">
      ${mk("ld")}
      <rect class="conc" x="90" y="58" width="350" height="96"/>
      <line class="hi" x1="20" y1="106" x2="404" y2="106" stroke-width="7"/>
      <line class="ac" x1="86" y1="106" x2="24" y2="106" marker-end="url(#ld-c)"/>
      <text class="ea" x="54" y="92" text-anchor="middle">pull = σs</text>
      <line class="thin" x1="120" y1="88" x2="136" y2="88" marker-end="url(#ld-a)"/>
      <line class="thin" x1="172" y1="88" x2="188" y2="88" marker-end="url(#ld-a)"/>
      <line class="thin" x1="224" y1="88" x2="240" y2="88" marker-end="url(#ld-a)"/>
      <line class="thin" x1="276" y1="88" x2="292" y2="88" marker-end="url(#ld-a)"/>
      <line class="thin" x1="328" y1="88" x2="344" y2="88" marker-end="url(#ld-a)"/>
      <line class="thin" x1="120" y1="126" x2="136" y2="126" marker-end="url(#ld-a)"/>
      <line class="thin" x1="172" y1="126" x2="188" y2="126" marker-end="url(#ld-a)"/>
      <line class="thin" x1="224" y1="126" x2="240" y2="126" marker-end="url(#ld-a)"/>
      <line class="thin" x1="276" y1="126" x2="292" y2="126" marker-end="url(#ld-a)"/>
      <line class="thin" x1="328" y1="126" x2="344" y2="126" marker-end="url(#ld-a)"/>
      <text class="lb" x="265" y="44" text-anchor="middle">bond stress τbd acts along the bar surface</text>
      ${dim("ld", 90, 178, 404, 178)}
      <line class="thin" x1="90" y1="158" x2="90" y2="184"/>
      <line class="thin" x1="404" y1="158" x2="404" y2="184"/>
      <text class="em" x="247" y="200" text-anchor="middle">Ld = φ σs / (4 τbd)</text>
    </svg>`,
    caption: "The pull in the bar is resisted by bond spread over its whole embedded surface. Ld is the length at which the accumulated bond force equals the bar's design strength — shorten it and the bar simply slips out.",
  },

  /* ---------------------------------------------- LAP LENGTH */
  "t-lap": {
    label: "Lap splice between two bars",
    svg: `<svg viewBox="0 0 480 176" role="img" aria-label="Two reinforcing bars overlapping inside concrete, with the overlap marked as the lap length">
      ${mk("lp")}
      <rect class="conc" x="20" y="48" width="440" height="74"/>
      <rect class="soft" x="182" y="62" width="120" height="46"/>
      <line x1="20" y1="78" x2="302" y2="78" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
      <line class="hi" x1="182" y1="100" x2="460" y2="100" stroke-width="7"/>
      <text class="lb" x="70" y="68" text-anchor="middle">bar 1</text>
      <text class="lb" x="410" y="118" text-anchor="middle">bar 2</text>
      ${dim("lp", 182, 146, 302, 146)}
      <line class="thin" x1="182" y1="126" x2="182" y2="152"/>
      <line class="thin" x1="302" y1="126" x2="302" y2="152"/>
      <text class="em" x="242" y="168" text-anchor="middle">lap = greater of Ld and 30 φ</text>
    </svg>`,
    caption: "Force passes from one bar to the other through the concrete in the overlap zone, so the lap has to be at least as long as the development length. Laps are staggered and kept away from points of maximum stress.",
  },

  /* ---------------------------------------------- STRESS BLOCK */
  "t-mulim": {
    label: "Limit state stress block",
    svg: `<svg viewBox="0 0 620 268" role="img" aria-label="Section, strain diagram and stress block for a singly reinforced beam, showing the limiting neutral axis depth, the compressive force at 0.42 xu from the top and the tensile force in the steel">
      ${mk("sb")}
      <rect class="conc" x="30" y="45" width="80" height="180"/>
      <circle class="steel" cx="48" cy="205" r="6"/>
      <circle class="steel" cx="70" cy="205" r="6"/>
      <circle class="steel" cx="92" cy="205" r="6"/>
      <line class="dash" x1="22" y1="122" x2="118" y2="122"/>
      <text class="em" x="70" y="116" text-anchor="middle">N.A. at xu</text>
      <text class="lb" x="70" y="248" text-anchor="middle">section</text>

      <path class="softa" d="M200 45 H272 L200 122 Z"/>
      <line class="s" x1="200" y1="45" x2="200" y2="225"/>
      <polyline class="ac" points="272,45 200,122 154,205"/>
      <line class="dash" x1="150" y1="122" x2="286" y2="122"/>
      <text class="ea" x="276" y="40" text-anchor="middle">0.0035</text>
      <text class="lb" x="150" y="219" text-anchor="start">εst</text>
      <text class="lb" x="210" y="248" text-anchor="middle">strain</text>

      <rect class="soft" x="360" y="45" width="70" height="77"/>
      <line class="hi" x1="360" y1="45" x2="430" y2="45"/>
      <line class="hi" x1="430" y1="45" x2="430" y2="122"/>
      <line class="s" x1="360" y1="45" x2="360" y2="225"/>
      <line class="dash" x1="356" y1="122" x2="512" y2="122"/>
      <text class="em" x="436" y="60" text-anchor="start">0.36 fck</text>
      <line class="ac" x1="362" y1="77" x2="438" y2="77" marker-end="url(#sb-c)"/>
      <text class="ea" x="444" y="81" text-anchor="start">C</text>
      <line class="ac" x1="438" y1="205" x2="362" y2="205" marker-end="url(#sb-c)"/>
      <text class="ea" x="444" y="209" text-anchor="start">T</text>
      ${dim("sb", 512, 77, 512, 205)}
      <line class="thin" x1="506" y1="77" x2="518" y2="77"/>
      <line class="thin" x1="506" y1="205" x2="518" y2="205"/>
      <text x="524" y="146" text-anchor="start">d − 0.42 xu</text>
      <text class="lb" x="400" y="248" text-anchor="middle">stress block</text>

    </svg>`,
    caption: "Concrete strain at the top is fixed at 0.0035. The curved compressive stress distribution is replaced by an equivalent block of intensity 0.36 fck acting at 0.42 xu from the top — that is where every RCC formula's constants come from. Capping xu at xu,max forces the steel to yield first, giving a ductile failure.",
  },

  /* ---------------------------------------------- SHEAR */
  "t-shear": {
    label: "Diagonal shear crack and stirrups",
    svg: `<svg viewBox="0 0 480 224" role="img" aria-label="Beam elevation with a 45 degree diagonal crack near the support, crossed by vertical stirrups">
      ${mk("sh")}
      <rect class="conc" x="40" y="50" width="400" height="110"/>
      <polygon points="40,160 28,182 52,182" fill="none" stroke="currentColor" stroke-width="1.5"/>
      <polygon points="440,160 428,182 452,182" fill="none" stroke="currentColor" stroke-width="1.5"/>
      <line class="ac" x1="240" y1="14" x2="240" y2="46" marker-end="url(#sh-c)"/>
      <text class="ea" x="250" y="30" text-anchor="start">Vu</text>
      <polyline class="hi" points="110,160 128,132 120,118 150,88 142,74 174,58"/>
      <text class="em" x="196" y="88" text-anchor="start">diagonal crack ≈ 45°</text>
      <line class="ac" x1="95" y1="58" x2="95" y2="152"/>
      <line class="ac" x1="130" y1="58" x2="130" y2="152"/>
      <line class="ac" x1="165" y1="58" x2="165" y2="152"/>
      <line class="ac" x1="200" y1="58" x2="200" y2="152"/>
      ${dim("sh", 130, 196, 165, 196)}
      <text class="lb" x="240" y="214" text-anchor="middle">stirrup spacing sv ≤ 0.75 d and ≤ 300 mm</text>
    </svg>`,
    caption: "Shear shows up as an inclined crack near the support. Stirrups do nothing until that crack forms — their job is to cross it and carry the force across. That is why spacing matters more than bar size: a crack that fits between two stirrups is uncontrolled.",
  },

  /* ---------------------------------------------- COLUMN REINFORCEMENT */
  "t-colreinf": {
    label: "Column reinforcement and tie pitch",
    svg: `<svg viewBox="-24 0 504 262" role="img" aria-label="Column cross section with six longitudinal bars and a lateral tie, next to an elevation showing tie pitch">
      ${mk("cl")}
      <rect class="conc" x="30" y="46" width="140" height="140"/>
      <rect class="ac" x="54" y="70" width="92" height="92" rx="6"/>
      <circle class="steel" cx="68" cy="84" r="8"/>
      <circle class="steel" cx="100" cy="84" r="8"/>
      <circle class="steel" cx="132" cy="84" r="8"/>
      <circle class="steel" cx="68" cy="148" r="8"/>
      <circle class="steel" cx="100" cy="148" r="8"/>
      <circle class="steel" cx="132" cy="148" r="8"/>
      ${dim("cl", 68, 30, 100, 30)}
      <text class="lb" x="84" y="22" text-anchor="middle">≤ 300 mm</text>
      <text class="lb" x="100" y="206" text-anchor="middle">cover to bars ≥ 40 mm</text>
      <text class="lb" x="100" y="226" text-anchor="middle">section — min 4 bars (6 if circular)</text>

      <rect class="conc" x="286" y="28" width="86" height="196"/>
      <line x1="300" y1="28" x2="300" y2="224" stroke="currentColor" stroke-width="3"/>
      <line x1="358" y1="28" x2="358" y2="224" stroke="currentColor" stroke-width="3"/>
      <line class="ac" x1="292" y1="54" x2="366" y2="54"/>
      <line class="ac" x1="292" y1="88" x2="366" y2="88"/>
      <line class="ac" x1="292" y1="122" x2="366" y2="122"/>
      <line class="ac" x1="292" y1="156" x2="366" y2="156"/>
      <line class="ac" x1="292" y1="190" x2="366" y2="190"/>
      ${dim("cl", 396, 88, 396, 122)}
      <line class="thin" x1="390" y1="88" x2="402" y2="88"/>
      <line class="thin" x1="390" y1="122" x2="402" y2="122"/>
      <text class="em" x="408" y="110" text-anchor="start">pitch</text>
      <text class="lb" x="329" y="248" text-anchor="middle">elevation</text>
    </svg>`,
    caption: "Ties hold the longitudinal bars against outward buckling and confine the core. Pitch is limited to the least of the least lateral dimension, 16 times the smallest bar diameter, and 300 mm.",
  },

  /* ---------------------------------------------- CONFINING REINFORCEMENT */
  "t-confining": {
    label: "Special confining reinforcement zones",
    svg: `<svg viewBox="0 0 420 306" role="img" aria-label="Column between two floor beams with closely spaced hoops over the confining length at each end and wider spacing in the middle">
      ${mk("cf")}
      <rect class="conc" x="40" y="30" width="340" height="36"/>
      <rect class="conc" x="40" y="238" width="340" height="36"/>
      <rect class="conc" x="150" y="66" width="90" height="172"/>
      <line class="hi" x1="144" y1="74" x2="246" y2="74"/>
      <line class="hi" x1="144" y1="86" x2="246" y2="86"/>
      <line class="hi" x1="144" y1="98" x2="246" y2="98"/>
      <line class="hi" x1="144" y1="110" x2="246" y2="110"/>
      <line class="hi" x1="144" y1="122" x2="246" y2="122"/>
      <line class="thin" x1="144" y1="148" x2="246" y2="148"/>
      <line class="thin" x1="144" y1="172" x2="246" y2="172"/>
      <line class="hi" x1="144" y1="194" x2="246" y2="194"/>
      <line class="hi" x1="144" y1="206" x2="246" y2="206"/>
      <line class="hi" x1="144" y1="218" x2="246" y2="218"/>
      <line class="hi" x1="144" y1="230" x2="246" y2="230"/>
      ${dim("cf", 120, 66, 120, 128)}
      <line class="thin" x1="114" y1="66" x2="126" y2="66"/>
      <line class="thin" x1="114" y1="128" x2="126" y2="128"/>
      <text class="em" x="108" y="102" text-anchor="end">lo</text>
      <text class="em" x="262" y="100" text-anchor="start">hoops ≤ 100 mm</text>
      <text class="lb" x="262" y="164" text-anchor="start">normal spacing</text>
      <text class="lb" x="210" y="52" text-anchor="middle">beam</text>
      <text class="lb" x="210" y="260" text-anchor="middle">beam</text>
      <text class="lb" x="210" y="296" text-anchor="middle">lo = greatest of larger dimension, clear height / 6, 450 mm</text>
    </svg>`,
    caption: "During an earthquake the column ends are where plastic hinges want to form. Closely spaced hoops there hold the core concrete together after the cover spalls, so the column keeps carrying axial load while the frame sways.",
  },

  /* ---------------------------------------------- PLASTICITY CHART */
  "t-soilclass": {
    label: "Plasticity chart of IS 1498",
    svg: `<svg viewBox="-48 0 528 322" role="img" aria-label="Plasticity chart with liquid limit on the horizontal axis and plasticity index on the vertical axis, showing the A-line separating clays above from silts below, and the low, intermediate and high compressibility divisions at liquid limits of 35 and 50">
      ${mk("pc")}
      <line class="gl" x1="60" y1="231.7" x2="440" y2="231.7"/>
      <line class="gl" x1="60" y1="193.3" x2="440" y2="193.3"/>
      <line class="gl" x1="60" y1="155" x2="440" y2="155"/>
      <line class="gl" x1="60" y1="116.7" x2="440" y2="116.7"/>
      <line class="gl" x1="60" y1="78.3" x2="440" y2="78.3"/>
      <line class="dash" x1="193" y1="40" x2="193" y2="270"/>
      <line class="dash" x1="250" y1="40" x2="250" y2="270"/>
      <line class="s" x1="60" y1="270" x2="440" y2="270"/>
      <line class="s" x1="60" y1="270" x2="60" y2="40"/>
      <line class="hi" x1="136" y1="270" x2="440" y2="46"/>
      <text class="em" x="140" y="244" text-anchor="start">A-line</text>
      <text x="165" y="215" text-anchor="middle">CL</text>
      <text x="205" y="160" text-anchor="middle">CI</text>
      <text x="350" y="92" text-anchor="middle">CH</text>
      <text x="172" y="264" text-anchor="middle">ML</text>
      <text x="215" y="245" text-anchor="middle">MI</text>
      <text x="340" y="215" text-anchor="middle">MH</text>
      <circle class="acf" cx="231" cy="186" r="5"/>
      <text class="ea" x="222" y="180" text-anchor="end">wL 45, Ip 22</text>
      <text class="lb" x="60" y="286" text-anchor="middle">0</text>
      <text class="lb" x="136" y="286" text-anchor="middle">20</text>
      <text class="lb" x="193" y="286" text-anchor="middle">35</text>
      <text class="lb" x="250" y="286" text-anchor="middle">50</text>
      <text class="lb" x="440" y="286" text-anchor="middle">100</text>
      <text class="lb" x="50" y="274" text-anchor="end">0</text>
      <text class="lb" x="50" y="197" text-anchor="end">20</text>
      <text class="lb" x="50" y="120" text-anchor="end">40</text>
      <text class="lb" x="50" y="44" text-anchor="end">60</text>
      <text class="lb" x="250" y="308" text-anchor="middle">Liquid limit wL (%)</text>
      <text class="lb" x="20" y="155" text-anchor="middle" transform="rotate(-90 20 155)">Plasticity index Ip</text>
    </svg>`,
    caption: "The A-line, Ip = 0.73 (wL − 20), separates clays (above) from silts and organic soils (below); the vertical lines at wL = 35 and 50 split low, intermediate and high compressibility. Plot your two Atterberg limits and the group symbol falls out of the chart.",
  },

  /* ---------------------------------------------- PILE CAPACITY */
  "t-pile": {
    label: "Where a pile gets its capacity",
    svg: `<svg viewBox="0 0 400 306" role="img" aria-label="Pile in soil showing skin friction acting upward along the shaft and end bearing acting upward at the base, resisting the applied load">
      ${mk("pl")}
      <rect class="conc" x="20" y="62" width="360" height="212" opacity="0.5"/>
      <line class="s" x1="20" y1="62" x2="380" y2="62"/>
      <line class="thin" x1="30" y1="62" x2="22" y2="54"/>
      <line class="thin" x1="60" y1="62" x2="52" y2="54"/>
      <line class="thin" x1="90" y1="62" x2="82" y2="54"/>
      <line class="thin" x1="300" y1="62" x2="292" y2="54"/>
      <line class="thin" x1="330" y1="62" x2="322" y2="54"/>
      <line class="thin" x1="360" y1="62" x2="352" y2="54"/>
      <rect class="conc" x="176" y="42" width="48" height="212"/>
      <line class="ac" x1="200" y1="10" x2="200" y2="40" marker-end="url(#pl-c)"/>
      <text class="ea" x="210" y="26" text-anchor="start">Q</text>
      <line class="hi" x1="168" y1="112" x2="168" y2="92" marker-end="url(#pl-m)"/>
      <line class="hi" x1="168" y1="162" x2="168" y2="142" marker-end="url(#pl-m)"/>
      <line class="hi" x1="168" y1="212" x2="168" y2="192" marker-end="url(#pl-m)"/>
      <line class="hi" x1="232" y1="112" x2="232" y2="92" marker-end="url(#pl-m)"/>
      <line class="hi" x1="232" y1="162" x2="232" y2="142" marker-end="url(#pl-m)"/>
      <line class="hi" x1="232" y1="212" x2="232" y2="192" marker-end="url(#pl-m)"/>
      <text class="em" x="248" y="150" text-anchor="start">skin friction</text>
      <line class="ac" x1="186" y1="278" x2="186" y2="258" marker-end="url(#pl-c)"/>
      <line class="ac" x1="200" y1="278" x2="200" y2="258" marker-end="url(#pl-c)"/>
      <line class="ac" x1="214" y1="278" x2="214" y2="258" marker-end="url(#pl-c)"/>
      <text class="ea" x="240" y="278" text-anchor="start">end bearing</text>
      ${dim("pl", 120, 62, 120, 254)}
      <line class="thin" x1="114" y1="62" x2="126" y2="62"/>
      <line class="thin" x1="114" y1="254" x2="126" y2="254"/>
      <text x="108" y="162" text-anchor="end">L</text>
      <text class="lb" x="200" y="300" text-anchor="middle">Qu = end bearing + skin friction · safe load = Qu / 2.5</text>
    </svg>`,
    caption: "Capacity comes from two places at once: friction along the whole shaft and bearing at the base. In soft clays the shaft does most of the work; on rock the base does. Negative skin friction reverses those shaft arrows and becomes an extra load instead of a resistance.",
  },

  /* ---------------------------------------------- BASE SHEAR */
  "t-seismic": {
    label: "How base shear is distributed up a building",
    svg: `<svg viewBox="0 0 420 306" role="img" aria-label="Five storey building with lateral seismic forces at each floor, increasing with height, and the total base shear at the foundation">
      ${mk("bs")}
      <line class="s" x1="140" y1="40" x2="140" y2="250"/>
      <line class="s" x1="260" y1="40" x2="260" y2="250"/>
      <line class="s" x1="140" y1="40" x2="260" y2="40"/>
      <line class="s" x1="140" y1="82" x2="260" y2="82"/>
      <line class="s" x1="140" y1="124" x2="260" y2="124"/>
      <line class="s" x1="140" y1="166" x2="260" y2="166"/>
      <line class="s" x1="140" y1="208" x2="260" y2="208"/>
      <line class="s" x1="140" y1="250" x2="260" y2="250"/>
      <line class="s" x1="70" y1="250" x2="350" y2="250"/>
      <line class="thin" x1="90" y1="250" x2="82" y2="260"/>
      <line class="thin" x1="120" y1="250" x2="112" y2="260"/>
      <line class="thin" x1="290" y1="250" x2="282" y2="260"/>
      <line class="thin" x1="320" y1="250" x2="312" y2="260"/>
      <line class="hi" x1="268" y1="40" x2="358" y2="40" marker-end="url(#bs-m)"/>
      <line class="hi" x1="268" y1="82" x2="340" y2="82" marker-end="url(#bs-m)"/>
      <line class="hi" x1="268" y1="124" x2="322" y2="124" marker-end="url(#bs-m)"/>
      <line class="hi" x1="268" y1="166" x2="304" y2="166" marker-end="url(#bs-m)"/>
      <line class="hi" x1="268" y1="208" x2="286" y2="208" marker-end="url(#bs-m)"/>
      <text class="em" x="300" y="28" text-anchor="middle">Qi ∝ Wi hi²</text>
      <line class="ac" x1="140" y1="276" x2="248" y2="276" marker-end="url(#bs-c)"/>
      <text class="ea" x="256" y="280" text-anchor="start">VB = Ah W</text>
      ${dim("bs", 100, 40, 100, 250)}
      <line class="thin" x1="94" y1="40" x2="106" y2="40"/>
      <line class="thin" x1="94" y1="250" x2="106" y2="250"/>
      <text x="90" y="150" text-anchor="end">h</text>
      <text class="lb" x="210" y="300" text-anchor="middle">total base shear is shared out in proportion to Wi hi²</text>
    </svg>`,
    caption: "The whole building's seismic weight produces one base shear, VB = Ah W. That total is then distributed to the floors in proportion to Wi hi² — which is why upper floors attract far more force than their weight alone would suggest.",
  },

  /* ---------------------------------------------- LEVELLING */
  "t-levelling": {
    label: "Levelling by the height of instrument method",
    svg: `<svg viewBox="0 92 500 188" role="img" aria-label="A level set between a benchmark staff and a new point staff, with the line of collimation giving the height of instrument, a back sight and a fore sight">
      ${mk("lv")}
      <polyline class="s" points="20,205 120,205 200,214 300,200 400,208 480,208"/>
      <line class="s" x1="250" y1="150" x2="232" y2="205"/>
      <line class="s" x1="250" y1="150" x2="268" y2="205"/>
      <line class="s" x1="250" y1="150" x2="250" y2="205"/>
      <rect class="conc" x="232" y="136" width="36" height="14"/>
      <line class="dash" x1="112" y1="143" x2="400" y2="143"/>
      <text class="lb" x="256" y="128" text-anchor="middle">line of collimation</text>
      <rect class="conc" x="116" y="100" width="10" height="105"/>
      <line class="hi" x1="110" y1="143" x2="132" y2="143"/>
      <text class="em" x="106" y="140" text-anchor="end">BS 1.250</text>
      <polygon points="121,205 114,216 128,216" fill="currentColor"/>
      <text class="lb" x="121" y="232" text-anchor="middle">BM  RL 100.000</text>
      <rect class="conc" x="380" y="104" width="10" height="104"/>
      <line class="hi" x1="374" y1="143" x2="396" y2="143"/>
      <text class="em" x="402" y="140" text-anchor="start">FS 2.100</text>
      <text class="lb" x="385" y="232" text-anchor="middle">new point</text>
      <line class="dash" x1="20" y1="252" x2="480" y2="252"/>
      <text class="lb" x="24" y="248" text-anchor="start">datum</text>
      <text class="ea" x="250" y="270" text-anchor="middle">HI = 100.000 + 1.250 = 101.250    ·    RL = 101.250 − 2.100 = 99.150</text>
    </svg>`,
    caption: "The instrument's line of sight is one fixed level. Add the back sight to the known RL to find that level (the HI), then subtract every other staff reading from it. Higher ground gives a smaller reading — that is the whole method.",
  },

  /* ---------------------------------------------- BRICK BONDS */
  "t-brickwork": {
    label: "English bond compared with Flemish bond",
    svg: (function () {
      const H = 28, N = 4;
      /* headers (short faces) are shaded so the alternation is visible */
      function bricks(x0, y0, widths) {
        let x = x0, out = "";
        widths.forEach((w) => {
          const cls = w < 50 ? "soft-b" : "conc";
          out += `<rect class="${cls}" x="${x + 2}" y="${y0 + 2}" width="${w - 4}" height="${H - 4}" rx="2"/>`;
          x += w;
        });
        return out;
      }
      const S = 66.67, Hd = 33.33;
      let eng = "", fle = "";
      for (let i = 0; i < N; i++) {
        const y = 56 + i * H;
        eng += i % 2 === 0
          ? bricks(20, y, [S, S, S])
          : bricks(20, y, [Hd, Hd, Hd, Hd, Hd, Hd]);
        fle += i % 2 === 0
          ? bricks(260, y, [Hd, S, Hd, S])
          : bricks(260, y, [Hd, Hd, S, Hd, Hd]);
      }
      return `<svg viewBox="0 0 480 236" role="img" aria-label="Elevation of English bond, where whole courses of headers alternate with whole courses of stretchers, next to Flemish bond, where headers and stretchers alternate within every course">
        <text x="120" y="42" text-anchor="middle">English bond</text>
        <text x="360" y="42" text-anchor="middle">Flemish bond</text>
        ${eng}${fle}
        <text class="lb" x="120" y="192" text-anchor="middle">whole courses of headers and</text>
        <text class="lb" x="120" y="208" text-anchor="middle">stretchers alternate — stronger</text>
        <text class="lb" x="360" y="192" text-anchor="middle">headers and stretchers alternate</text>
        <text class="lb" x="360" y="208" text-anchor="middle">within each course — better looking</text>
      </svg>`;
    })(),
    caption: "Both bonds exist to stop vertical joints lining up from course to course. English bond carries load better and is the usual choice for structural walls; Flemish bond gives the neater face and is used where the brickwork is exposed.",
  },

  /* ---------------------------------------------- EFFECTIVE SPAN */
  "t-effspan": {
    label: "Effective span of a simply supported beam",
    svg: `<svg viewBox="0 0 480 214" role="img" aria-label="Beam on two wide supports, comparing the clear span plus effective depth with the centre to centre distance between supports">
      ${mk("es")}
      <rect class="conc" x="40" y="130" width="60" height="60"/>
      <rect class="conc" x="380" y="130" width="60" height="60"/>
      <rect class="conc" x="40" y="70" width="400" height="60"/>
      <line class="dash" x1="70" y1="50" x2="70" y2="196"/>
      <line class="dash" x1="410" y1="50" x2="410" y2="196"/>
      <line class="dash" x1="100" y1="50" x2="100" y2="130"/>
      <line class="dash" x1="380" y1="50" x2="380" y2="130"/>
      ${dim("es", 100, 40, 380, 40)}
      <text class="lb" x="240" y="32" text-anchor="middle">clear span</text>
      ${dim("es", 70, 206, 410, 206)}
      <text class="em" x="240" y="200" text-anchor="middle">centre to centre of supports</text>
      <text class="ea" x="240" y="106" text-anchor="middle">effective span = the smaller of the two</text>
    </svg>`,
    caption: "Two candidate lengths: clear span plus effective depth, and centre-to-centre of the supports. IS 456 takes the smaller. Use the wrong one and every bending moment in the design is wrong with it.",
  },
};
