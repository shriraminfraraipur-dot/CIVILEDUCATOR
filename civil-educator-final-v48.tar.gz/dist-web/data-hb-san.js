/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: STRUCTURAL ANALYSIS (COMPLETE NOTES)
   ------------------------------------------------------------
   Built from two sets of scanned class notes, read page by page
   and transcribed verbatim before anything was written here:

     T = "Theory of Structures" class notes      — 171 pages
     V = "Structural Analysis" class notes       — 269 pages
         (Vivek Gupta, MADE EASY)

   The two sets are merged topic-wise, not source by source. Every
   block carries its source and page (T p.63 / V p.118) so any value
   can be checked against the original sheet. Where the two sets
   disagree, both are shown with their citations — none is silently
   resolved. Where a worked example's own arithmetic slips, it is
   reproduced as written with a "Check:" note underneath.

   Chapters are pushed by data-hb-san2.js … data-hb-san8.js.
   ============================================================ */
window.DB = window.DB || {};
DB.handbooks = DB.handbooks || [];

DB.handbooks.push({
  id: "san",
  subject: "struct-analysis",
  name: "Structural Analysis — Complete Notes",
  hi: "संरचनात्मक विश्लेषण — सम्पूर्ण नोट्स",
  icon: "📐",
  blurb: "Do class notes (440 pages) topic-wise jode hue — determinacy se lekar matrix method aur structural dynamics tak, har value ke saath uska page number.",
  note: "Source codes: T = Theory of Structures notes (171 pp) · V = Structural Analysis notes, Vivek Gupta / MADE EASY (269 pp). Har block par source aur page likha hai. Jahan dono notes alag values dete hain, dono dikhayi gayi hain — koi chupke se nahi chuni gayi. Jahan notes ka apna hisaab galat hai, wahan original waisa ka waisa rakha hai aur neeche 'Check:' note lagaya hai.",
  chapters: []
});
