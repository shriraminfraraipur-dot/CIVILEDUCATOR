/* ============================================================
   CIVIL EDUCATOR — inline SVG diagrams, part 3
   Steel (IS 800) and ductile detailing (IS 13920).
   Uses the mk() / dim() helpers declared in diagrams.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------ SECTION CLASSIFICATION */
  "t-800-class": {
    label: "What the four section classes can do",
    svg: `<svg viewBox="0 0 500 248" role="img" aria-label="Moment against rotation for the four classes of cross section: class 1 reaches the plastic moment and holds it, class 2 reaches it briefly, class 3 only reaches the yield moment, class 4 buckles before yield">
      ${mk("cl")}
      <line class="gl" x1="60" y1="68" x2="318" y2="68" stroke-dasharray="5 4"/>
      <line class="gl" x1="60" y1="108" x2="318" y2="108" stroke-dasharray="5 4"/>
      <text class="lb" x="54" y="72" text-anchor="end">Mp</text>
      <text class="lb" x="54" y="112" text-anchor="end">My</text>

      <line class="thin" x1="60" y1="36" x2="60" y2="212"/>
      <line class="thin" x1="60" y1="212" x2="322" y2="212"/>
      <text class="lb" x="191" y="234" text-anchor="middle">rotation</text>

      <path class="ac" d="M60 195 C 88 120, 106 68, 146 68 L 318 68"/>
      <text class="ea" x="326" y="64">1 plastic</text>

      <path class="ac" d="M60 195 C 88 120, 106 68, 146 68 L 214 68 C 252 70, 282 98, 310 122"/>
      <text class="ea" x="326" y="126">2 compact</text>

      <path class="ac" d="M60 195 C 86 152, 102 108, 136 108 C 180 110, 240 150, 302 178"/>
      <text class="ea" x="326" y="180">3 semi-compact</text>

      <path class="ac" d="M60 195 C 84 174, 98 146, 126 146 C 164 152, 226 182, 300 202"/>
      <text class="ea" x="326" y="206">4 slender</text>

      <text class="em" x="326" y="34">ε = √(250 / fy)</text>
    </svg>`,
    caption: "Class decides the moment capacity before any strength formula runs: <strong>βb = 1 for Class 1 and 2, but Ze/Zp for Class 3</strong>, and a Class 4 section must be designed on a reduced effective area. Plastic analysis needs Class 1 throughout.",
  },

  /* ------------------------------------ SHEAR AREA */
  "t-800-shear": {
    label: "Shear area of a rolled I-section",
    svg: `<svg viewBox="0 0 500 228" role="img" aria-label="An I-section in cross section with the web shaded as the shear area, and the design shear strength expressions alongside">
      ${mk("sh")}
      <rect class="conc" x="130" y="40" width="120" height="14"/>
      <rect class="conc" x="130" y="176" width="120" height="14"/>
      <rect class="soft-b" x="182" y="54" width="16" height="122"/>
      <rect class="s" x="182" y="54" width="16" height="122"/>

      <line class="thin" x1="198" y1="115" x2="252" y2="100"/>
      <text class="em" x="256" y="96">tw</text>

      ${dim("sh", 288, 40, 288, 190)}
      <line class="thin" x1="282" y1="40" x2="294" y2="40"/>
      <line class="thin" x1="282" y1="190" x2="294" y2="190"/>
      <text x="298" y="119">h</text>

      <text class="em" x="340" y="82">Av = h · tw</text>
      <text x="340" y="112">Vn = Av fyw / √3</text>
      <text x="340" y="136">Vd = Vn / 1.10</text>
      <text class="lb" x="340" y="166">check shear buckling</text>
      <text class="lb" x="340" y="182">if d / tw &gt; 67 ε</text>
      <text class="lb" x="190" y="212" text-anchor="middle">shaded = shear area</text>
    </svg>`,
    caption: "For a <strong>hot-rolled</strong> I-section in major axis bending the shear area is the <em>overall depth</em> × web thickness; for a welded section it is the clear web depth × web thickness. The flanges are assumed to carry no shear.",
  },

  /* ------------------------------------ BEARING vs FRICTION GRIP */
  "t-800-hsfg": {
    label: "Bearing bolt and friction grip bolt compared",
    svg: `<svg viewBox="0 0 500 246" role="img" aria-label="Two lap joints: in the bearing bolt the shank carries the shear after the plates slip, in the friction grip bolt the clamping force makes friction between the plates carry the load">
      ${mk("hs")}
      <rect class="conc" x="60" y="48" width="170" height="18"/>
      <rect class="conc" x="130" y="66" width="170" height="18"/>
      <rect class="hi" x="178" y="36" width="14" height="42" rx="3"/>
      <line class="thin" x1="60" y1="57" x2="28" y2="57" marker-end="url(#hs-a)"/>
      <line class="thin" x1="300" y1="75" x2="332" y2="75" marker-end="url(#hs-a)"/>
      <text class="em" x="185" y="26" text-anchor="middle">shank in shear</text>
      <text class="ea" x="348" y="50">bearing bolt</text>
      <text class="lb" x="348" y="68">plates slip into</text>
      <text class="lb" x="348" y="84">bearing first</text>

      <rect class="conc" x="60" y="158" width="170" height="18"/>
      <rect class="conc" x="130" y="176" width="170" height="18"/>
      <rect class="hi" x="178" y="132" width="14" height="88" rx="3"/>
      <line class="hi" x1="150" y1="130" x2="150" y2="154" marker-end="url(#hs-m)"/>
      <line class="hi" x1="220" y1="222" x2="220" y2="198" marker-end="url(#hs-m)"/>
      <line class="ac" x1="150" y1="176" x2="120" y2="176" marker-end="url(#hs-c)"/>
      <line class="ac" x1="220" y1="176" x2="256" y2="176" marker-end="url(#hs-c)"/>
      <text class="em" x="112" y="126">clamping force F0 = 0.70 fub Anb</text>
      <text class="ea" x="348" y="160">friction grip</text>
      <text class="lb" x="348" y="178">friction at the</text>
      <text class="lb" x="348" y="194">faying surface</text>
      <text class="lb" x="348" y="210">carries it — no slip</text>
    </svg>`,
    caption: "A friction grip joint does not move at all under service load, which is why it is standard for <strong>bridge splices, crane gantries and any joint carrying reversal</strong>. Its whole capacity depends on the faying surface preparation and the tightening method.",
  },

  /* ------------------------------------ BEAM-COLUMN JOINT */
  "t-13920-joint": {
    label: "The beam-column joint region",
    svg: `<svg viewBox="0 0 500 252" role="img" aria-label="Elevation of a beam-column joint: beams framing in from both sides confine the joint, and the column hoops are carried through it">
      ${mk("jt")}
      <rect class="conc" x="60" y="98" width="140" height="62"/>
      <rect class="conc" x="280" y="98" width="140" height="62"/>
      <rect class="conc" x="200" y="26" width="80" height="72"/>
      <rect class="conc" x="200" y="160" width="80" height="66"/>
      <rect class="soft" x="200" y="98" width="80" height="62"/>
      <rect class="s" x="200" y="98" width="80" height="62"/>

      <rect class="hi" x="208" y="106" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="124" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="142" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="60" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="78" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="176" width="64" height="9" rx="3"/>
      <rect class="hi" x="208" y="194" width="64" height="9" rx="3"/>

      <line class="ac" x1="150" y1="110" x2="212" y2="110" marker-end="url(#jt-c)"/>
      <line class="ac" x1="330" y1="150" x2="268" y2="150" marker-end="url(#jt-c)"/>
      <text class="ea" x="110" y="92">1.25 fy</text>
      <text class="ea" x="392" y="142" text-anchor="end">1.25 fy</text>

      <line class="thin" x1="272" y1="156" x2="352" y2="196"/>
      <text class="em" x="358" y="200">joint region</text>
      <line class="thin" x1="272" y1="82" x2="360" y2="72"/>
      <text class="lb" x="366" y="60">column hoops</text>
      <text class="lb" x="366" y="76">continue through</text>
      <text class="lb" x="120" y="180" text-anchor="middle">beam</text>
      <text class="lb" x="240" y="244" text-anchor="middle">column</text>
    </svg>`,
    caption: "The joint shear comes from the beam bars at <strong>1.25 fy</strong> — an overstrength value, because that is the force the bars can actually deliver. Joint strength is 1.5 √fck when beams confine all four faces, 1.2 √fck for three, and 1.0 √fck otherwise.",
  },
});
