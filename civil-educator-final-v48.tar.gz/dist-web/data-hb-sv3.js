/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: SURVEYING
   Chapter 5 — Plane Table Surveying
   Chapter 6 — Levelling
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 5 */
    {
      id: "sv-5",
      n: 5,
      title: "Plane Table Surveying",
      hi: "प्लेन टेबल सर्वेक्षण",
      blurb: "The method with no field book at all — you draw the survey while standing in it.",
      mins: 34,
      sections: [

        {
          n: "5.1",
          title: "Drawing instead of writing",
          hi: "लिखने की जगह बनाना",
          blocks: [
            { k: "p", t: "Every other method in this handbook records numbers in the field and turns them into a plan in the office. Plane tabling skips the numbers: a drawing board is mounted on a tripod over the station, and the plan is drawn <em>on the spot</em>, with the ground in view." },
            { k: "list", items: [
              "<strong>Nothing is transcribed</strong>, so no booking or plotting errors are possible.",
              "<strong>Omissions are impossible to miss</strong> — the plan is in front of you, and a gap in it is visible while you can still walk over and fill it.",
              "<strong>Irregular detail is easy</strong> — a wandering stream or a broken hedge is sketched between fixed points rather than reduced to offsets.",
              "<strong>But</strong> it is slow in bad weather, useless in rain, awkward to carry, hard to work at a different scale later, and it produces no numerical record at all — so nothing can be recomputed.",
            ]},
            { k: "p", t: "That last limitation is why it has largely disappeared from engineering work and survives in reconnaissance, in geological and forest mapping, and in filling detail into a framework that was fixed by better means." },
          ],
        },

        {
          n: "5.2",
          title: "The equipment, and setting up",
          hi: "उपकरण और सेटअप",
          blocks: [
            { k: "list", items: [
              "<strong>The table and tripod</strong> — a drawing board that can be levelled and rotated about a vertical axis, and clamped.",
              "<strong>Alidade</strong> — a straightedge with sights. A plain alidade has simple vanes; a telescopic alidade has a telescope and vertical circle, and can measure distance and elevation tacheometrically (Chapter 9).",
              "<strong>Plumbing fork (U-frame)</strong> — to place the plotted point exactly over the ground station.",
              "<strong>Spirit level</strong> — to level the board.",
              "<strong>Trough compass</strong> — to orient the board on the magnetic meridian.",
              "<strong>Drawing sheet, pencils, and a waterproof cover.</strong>",
            ]},
            { k: "h", t: "The three things to get right at each station" },
            { k: "steps", items: [
              "<strong>Levelling</strong> — the board must be horizontal, or the rays are not true directions.",
              "<strong>Centring</strong> — the plotted point must be over the ground station, checked with the plumbing fork.",
              "<strong>Orientation</strong> — the board must be turned so that lines on the paper are parallel to the same lines on the ground. By back-sighting along a previously drawn ray is the accurate way; by trough compass is quicker and inherits everything Chapter 4 said about local attraction.",
            ]},
            { k: "trap", t: "Orientation is the one that decides whether the survey is any good, and it is the one most easily disturbed — a knock to the tripod, or clamping the board carelessly, and every ray from that station is wrong by the same angle. <strong>Re-check the orientation by back-sight before leaving each station</strong>, not after the plan has been drawn on." },
            { k: "note", t: "For small-scale work the centring error can often be ignored. The test is scale: at 1:1000, 1 m on the ground is 1 mm on the paper, so centring to within half a metre is meaningless. At 1:100 the same half-metre is 5 mm and matters a great deal." },
          ],
        },

        {
          n: "5.3",
          title: "The four methods",
          hi: "चार विधियाँ",
          blocks: [
            { k: "dia", id: "hb-sv-planetable", cap: "Radiation, intersection, traversing, resection — and the last one reverses the usual direction of the work." },
            { k: "def", term: "Radiation", t: "Set the table at one station, draw a ray to each point of detail, and measure the distance to each along the ray. Simple, but limited to points close enough to be reached by tape and visible from a single station." },
            { k: "def", term: "Intersection", t: "Occupy two stations whose positions are already plotted, and draw a ray to the same point from each. Where the rays cross is the point. <strong>No distance to the point is measured at all</strong>, which is what makes it the method for anything inaccessible — a chimney, an island, a spot across a river." },
            { k: "def", term: "Traversing", t: "Move from station to station round a framework, drawing the forward ray and measuring the distance before moving on. The plane table equivalent of any other traverse, with the same closing error at the end." },
            { k: "def", term: "Resection", t: "Draw rays to points whose positions are already plotted, and find where you are from them. The rays are drawn <em>backwards</em>, from the known points towards the table, and their intersection is the station." },
            { k: "p", t: "Resection is worth pausing on, because it inverts the logic of everything else. Instead of using a known position to find new points, it uses known points to find an unknown position — which is exactly what a GNSS receiver does in Chapter 12, and exactly why the same word, resection, is still used there." },
            { k: "eg",
              title: "Example 5.1 — Checking an intersection by calculation",
              given: "Stations A and B are 120.0 m apart and plotted at 1 : 1000. From A the ray to a chimney P makes 52° with AB; from B it makes 60° with BA.",
              steps: [
                { t: "Angle at P", w: "180° − 52° − 60° = 68°" },
                { t: "Sine rule", w: "AP = AB sin 60°/sin 68° = 120 × 0.8660/0.9272 = 112.1 m\nBP = AB sin 52°/sin 68° = 120 × 0.7880/0.9272 = 102.0 m" },
                { t: "On the sheet at 1 : 1000", w: "ap = 112.1 mm,  bp = 102.0 mm — measure these on the plotted intersection as a check" },
              ],
              ans: "AP ≈ 112.1 m, BP ≈ 102.0 m. An intersection angle of 68° is comfortably ‘well-conditioned’; below about 30° the same pencil-width error in a ray moves P several times as far along the other ray.",
            },
          ],
        },

        {
          n: "5.4",
          title: "The three-point problem",
          hi: "त्रि-बिंदु समस्या",
          blocks: [
            { k: "p", t: "The classic resection case: the table is at an unplotted station, three well-plotted points are visible, and the station is to be located. Because the board's orientation is also unknown, there are three unknowns — two coordinates and a rotation — and three rays, so it is exactly determined." },
            { k: "h", t: "The two-point problem first" },
            { k: "p", t: "With only <strong>two</strong> plotted points A and B visible from the new station P, the rays cannot fix both the position and the orientation. The standard remedy uses an auxiliary station C chosen so that its rays to A, B and P intersect well: set up at C, orient approximately, resect C from A and B and draw a ray towards P; move to P, orient by back-sighting C, and resect P from A and B. The plotted line ab and the line a′b′ obtained this way differ by the orientation error; turn the table through that angle and repeat. It is laborious — which is why the three-point problem, needing no auxiliary station, is preferred whenever a third point is visible." },
            { k: "h", t: "Solving the three-point problem" },
            { k: "list", items: [
              "<strong>Trial and error (Lehmann's method)</strong> — orient the board approximately and draw the three rays. They will not meet at a point but will form a small <em>triangle of error</em>. Lehmann's rules say where the true point lies relative to that triangle; re-orient and repeat, and the triangle shrinks rapidly. Two or three iterations usually suffice.",
              "<strong>Lehmann's rules</strong> (as set out in <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105107122/modules/module10/html/35-4.htm\" target=\"_blank\" rel=\"noopener\">NPTEL Surveying, Module 10</a>) — (1) if the station is inside the great triangle formed by the three ground points, its plotted position is inside the triangle of error, and (2) outside it if outside; (3) the plotted position is at distances from the three rays proportional to the distances of the station from the corresponding ground points; (4) it lies on the same side of all three rays — to the right of all three or to the left of all three, looking towards the points.",
              "<strong>Graphical (Bessel's method)</strong> — a construction using two of the points to orient the board correctly, after which the third ray passes through the station directly. Faster and needs no judgement.",
              "<strong>Mechanical (tracing paper method)</strong> — draw the three rays on tracing paper from any arbitrary point, then slide the tracing until each ray passes through its corresponding plotted point. That position is the station. Crude, quick and surprisingly effective.",
            ]},
            { k: "trap", t: "There is one arrangement in which the problem has <strong>no unique solution at all</strong>: when the station lies on the circle passing through the three known points, every orientation satisfies the three rays equally and the method fails completely. This is the <em>great circle</em> or <em>danger circle</em>, and the practical rule is to choose three points such that the station is well inside the triangle they form, or clearly outside their circle — never near its circumference." },
            { k: "note", t: "The same danger-circle condition reappears as poor geometry in every resection problem, including satellite positioning, where it is called dilution of precision. The mathematics differs; the lesson does not — <strong>when the known points are badly arranged, no amount of measurement precision saves the answer</strong>." },
          ],
        },

        {
          n: "5.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "The plan is drawn in the field, so there is nothing to transcribe and nothing to forget — but also nothing to recompute.",
              "Level, centre, orient — and orientation is the one that ruins a station.",
              "Radiation: rays plus measured distances. Intersection: rays from two stations, no distance.",
              "Traversing: like any traverse. Resection: known points locate you.",
              "The three-point problem fails on the danger circle through the three points.",
            ]},
            { k: "p", t: "Chapters 3 to 5 have all been about position in <em>plan</em>. Chapter 6 turns to the other coordinate — height — which needs a completely different instrument and has its own set of errors." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "sv-6",
      n: 6,
      title: "Levelling",
      hi: "लेवलिंग",
      blurb: "Heights, the two ways of reducing a level book, and the field habit that removes three errors at once.",
      mins: 60,
      sections: [

        {
          n: "6.1",
          title: "The vocabulary, and why it is precise",
          hi: "शब्दावली",
          blocks: [
            { k: "p", t: "Levelling determines the difference in height between points. The instrument provides a horizontal line of sight, a graduated staff is read against it, and differences of reading give differences of height. The ideas are simple; the terms are worth defining exactly, because several of them are routinely confused." },
            { k: "def", term: "Level surface", t: "A surface everywhere perpendicular to the direction of gravity — so it is <strong>curved</strong>, following the earth. Still water takes this shape." },
            { k: "def", term: "Horizontal line", t: "A straight line tangential to the level surface at the point of observation. It departs from the level surface with distance, which is the curvature correction of §6.5." },
            { k: "def", term: "Datum", t: "The surface to which all heights are referred. India's vertical datum was realised in 1909 on the average mean sea level of nine tide-gauge stations — Karachi, Karwar, Bombay, Beypore, Cochin, Nagapattinam, Madras, Visakhapatnam and False Point (<a href=\"https://www.fig.net/resources/proceedings/fig_proceedings/fig2018/papers/ts06e/TS06E_singh_9497.pdf\" target=\"_blank\" rel=\"noopener\">FIG 2018 paper on the Indian vertical datum</a>). Survey of India has been redefining it since 2006–07 on geopotential numbers and Helmert orthometric heights, because the old definition assumed a single sea level on both coasts (<a href=\"https://Surveyofindia.gov.in/documents/vertical-datum.pdf\" target=\"_blank\" rel=\"noopener\">Survey of India</a>)." },
            { k: "note", t: "<b>Correction (v35):</b> many textbooks, and an earlier version of this page, describe the Indian datum simply as ‘mean sea level at Karachi’. The 1909 datum was the average of nine ports, Karachi among them. Later levelling found the west coast about 35 cm lower than the east (FIG 2018) — one reason the datum is being modernised. Survey of India also reports that about 70% of old benchmarks are missing or disturbed: always check a BM against a second one before relying on it." },
            { k: "def", term: "Reduced level (RL)", t: "The height of a point above (or below) the datum." },
            { k: "def", term: "Benchmark (BM)", t: "A point of known RL. GTS benchmarks are established by the Survey of India; permanent, arbitrary and temporary benchmarks serve locally." },
            { k: "def", term: "Height of instrument (HI)", t: "Not the height of the telescope above the ground — it is the <strong>RL of the line of collimation</strong>. Easily the most misread term in surveying." },
          ],
        },

        {
          n: "6.2",
          title: "Backsight, intersight, foresight",
          hi: "बैकसाइट, इंटरसाइट, फोरसाइट",
          blocks: [
            { k: "dia", id: "hb-sv-levelling", cap: "One set-up, one height of instrument, and the names that depend only on order." },
            { k: "list", items: [
              "<strong>Backsight (BS)</strong> — the <em>first</em> reading taken after the instrument is set up, always on a point of known RL. It establishes the height of instrument.",
              "<strong>Foresight (FS)</strong> — the <em>last</em> reading before the instrument is moved. It transfers the levelling forward.",
              "<strong>Intersight (IS)</strong> — any reading between the two, on a point whose level is wanted but which is not used to move the instrument.",
              "<strong>Change point (CP)</strong> — a point carrying both an FS from the old set-up and a BS from the new one. It is how the line of levels walks across a site.",
            ]},
            { k: "trap", t: "A backsight is not a sight taken backwards and a foresight is not a long one. <strong>The names describe position in the sequence, nothing else.</strong> A backsight can point in any direction, and on a steep site it very often points forwards. Students lose marks on this before they reach any arithmetic." },
            { k: "note", t: "Levels are also taken as a <em>fly level</em> (simply carrying height from A to B, with no intermediate detail), a <em>profile level</em> along a route, or as <em>cross-sections</em> at right angles to it. Same instrument, same rules, different booking layout." },
          ],
        },

        {
          n: "6.3",
          title: "Reducing the level book",
          hi: "लेवल बुक की गणना",
          blocks: [
            { k: "p", t: "Two methods are in use, and they are not equivalent in what they check." },
            { k: "cmp", t: "Both give the same reduced levels. Only one of them checks the intersights.",
              cols: ["Height of instrument", "Rise and fall"],
              rows: [
                ["Method", "HI = RL + BS, then RL = HI − (IS or FS)", "Compare each reading with the one before it on the same set-up"],
                ["Arithmetic", "Short — one addition per set-up", "Longer — a rise or fall for every reading"],
                ["Check", "ΣBS − ΣFS = last RL − first RL", "ΣBS − ΣFS = ΣRise − ΣFall = last RL − first RL"],
                ["Are intersights checked?", "<strong>No</strong> — an error in an IS passes unnoticed", "<strong>Yes</strong> — every reading enters the check"],
                ["Best for", "Lines with many intersights: profiles, cross-sections, contouring", "Precise work, and any line where every point matters"],
              ] },
            { k: "p", t: "That fourth row is the whole difference. In the HI method an intersight is a dead end — it is computed from the HI and never used again, so a misread staff produces a wrong RL that nothing contradicts. In the rise-and-fall method every reading is compared with its neighbour, so every reading takes part in the arithmetic check." },
            { k: "eg",
              title: "Example 6.1 — The same level book, both ways",
              given: "Starting from a BM of RL 100.000 m, the readings in order were:\n1.585 (BS), 2.310, 1.020, 2.885 (FS/CP1), 1.940 (BS), 0.650, 1.245 (FS/CP2), 2.105 (BS), 1.925, 0.800 (FS)",
              steps: [
                { t: "Height of instrument method — first set-up", w: "HI₁ = 100.000 + 1.585 = 101.585\nRL(2.310) = 101.585 − 2.310 =  99.275\nRL(1.020) = 101.585 − 1.020 = 100.565\nRL(CP1)   = 101.585 − 2.885 =  98.700" },
                { t: "Second set-up", w: "HI₂ = 98.700 + 1.940 = 100.640\nRL(0.650) = 100.640 − 0.650 = 99.990\nRL(CP2)   = 100.640 − 1.245 = 99.395" },
                { t: "Third set-up", w: "HI₃ = 99.395 + 2.105 = 101.500\nRL(1.925) = 101.500 − 1.925 =  99.575\nRL(0.800) = 101.500 − 0.800 = 100.700" },
                { t: "Arithmetic check", w: "ΣBS = 1.585 + 1.940 + 2.105 = 5.630\nΣFS = 2.885 + 1.245 + 0.800 = 4.930\nΣBS − ΣFS = +0.700\nlast RL − first RL = 100.700 − 100.000 = +0.700   ✓" },
                { t: "Rise and fall method — compare consecutive readings", w: "1.585 → 2.310   fall 0.725\n2.310 → 1.020   rise 1.290\n1.020 → 2.885   fall 1.865\n(instrument moved — 1.940 is a new BS on the same point)\n1.940 → 0.650   rise 1.290\n0.650 → 1.245   fall 0.595\n(instrument moved)\n2.105 → 1.925   rise 0.180\n1.925 → 0.800   rise 1.125" },
                { t: "The fuller check", w: "ΣRise = 1.290 + 1.290 + 0.180 + 1.125 = 3.885\nΣFall = 0.725 + 1.865 + 0.595 = 3.185\nΣRise − ΣFall = +0.700\n= ΣBS − ΣFS = +0.700\n= last RL − first RL = +0.700   ✓✓" },
              ],
              ans: "Final RL 100.700 m. Both methods agree, and the rise-and-fall check is satisfied three ways rather than one — which is precisely why it is preferred when every reading matters.",
            },
            { k: "trap", t: "The arithmetic check verifies the <em>arithmetic</em>. It does not verify the fieldwork. A staff held on the wrong point, or held upside down, or an instrument that settled between readings, will pass the check perfectly. <strong>The field check is closing the circuit back onto a known benchmark</strong>, and nothing else substitutes for it." },
          ],
        },

        {
          n: "6.4",
          title: "The instrument, and keeping it honest",
          hi: "उपकरण और उसकी जाँच",
          blocks: [
            { k: "list", items: [
              "<strong>Dumpy level</strong> — telescope rigidly fixed to the vertical spindle. Simple and robust; levelled by footscrews for every sight.",
              "<strong>Tilting level</strong> — the telescope can be tilted slightly about a horizontal axis, so the bubble is centred immediately before each reading rather than once for the whole set-up. Faster and more accurate.",
              "<strong>Automatic (auto) level</strong> — a compensator, a suspended prism assembly, holds the line of sight horizontal by gravity once the instrument is roughly levelled. The standard site instrument today.",
              "<strong>Digital level</strong> — reads a bar-coded staff electronically, removing reading and booking blunders entirely.",
            ]},
            { k: "h", t: "Temporary and permanent adjustments" },
            { k: "p", t: "<strong>Temporary adjustments</strong> are made at every set-up: setting up and roughly levelling the tripod, accurate levelling by footscrews, elimination of parallax by focusing the eyepiece on the crosshairs and then the object on the crosshairs. Parallax is worth doing properly — if the image and the crosshairs are not in the same plane, moving your eye changes the reading." },
            { k: "p", t: "<strong>Permanent adjustments</strong> correct the instrument itself, and the fundamental one is that <em>the line of collimation must be parallel to the bubble tube axis</em>. When it is not, every sight is tilted by a fixed angle — a systematic error. The <strong>two-peg test</strong> detects it: level between two pegs and then from beside one of them, and compare the two computed differences (procedure as in <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105107122/modules/module4/html/29.htm\" target=\"_blank\" rel=\"noopener\">NPTEL Module 4</a>: pegs about 60–90 m apart, first set-up midway, second close to one peg)." },
            { k: "eg",
              title: "Example 6.2 — Two-peg test",
              given: "Pegs A and B are 80 m apart. Level set midway: staff on A reads 1.465, on B 1.075. Level then set close to A: staff on A reads 1.520, on B 1.110.",
              steps: [
                { t: "True difference (midway — equal sights cancel the error)", w: "h = 1.465 − 1.075 = 0.390 m, B higher" },
                { t: "Apparent difference from the second set-up", w: "h′ = 1.520 − 1.110 = 0.410 m" },
                { t: "What B should have read", w: "the reading on A (close to the level) is taken as error-free\ncorrect reading on B = 1.520 − 0.390 = 1.130\nobserved 1.110, so the line of sight is inclined DOWN by 0.020 m in 80 m" },
                { t: "Collimation error", w: "0.020/80 = 0.00025 rad = 0.00025 × 206265 = 51.6″\n= 25 mm per 100 m of sight" },
              ],
              ans: "Line of sight inclined downwards by about 52″ (25 mm per 100 m). Adjust until the staff on B reads 1.130 with the bubble central — or, until it is adjusted, balance every backsight and foresight so the error cancels.",
            },
            { k: "def", term: "Sensitivity of a bubble tube", t: "The angle the instrument must tilt to move the bubble by one division. Determined by the radius of curvature of the tube — a flatter tube is more sensitive — and expressed as α″ = (S × 206265)/(n × D), where S is the staff intercept, n the number of divisions the bubble moved and D the distance to the staff. A sensitive bubble is slow to centre but reads finer." },
            { k: "eg",
              title: "Example 6.3 — Sensitivity of a bubble tube",
              given: "With the staff 100 m away, the bubble is moved through 5 divisions and the staff reading changes by 0.025 m. One division is 2 mm long.",
              steps: [
                { t: "Angle per division", w: "α = S × 206265/(n D) = 0.025 × 206265/(5 × 100) = 10.3″" },
                { t: "Radius of the tube", w: "R = n l D/S = 5 × 0.002 × 100/0.025 = 40 m" },
              ],
              ans: "About 10″ per 2 mm division, equivalent to a tube radius of 40 m.",
            },
          ],
        },

        {
          n: "6.5",
          title: "Curvature, refraction, and one habit that beats both",
          hi: "वक्रता, अपवर्तन और संतुलित दृष्टि",
          blocks: [
            { k: "dia", id: "hb-sv-curvref", cap: "Two errors in opposite directions, one about seven times the other." },
            { k: "p", t: "A horizontal line of sight departs upwards from the curved level surface, so a distant staff is read <em>too high</em>. The atmosphere then bends the ray downwards, giving back about a seventh of it." },
            { k: "eq", expr: "curvature  C = 0.0785 d²      refraction  R = 0.0112 d²      combined  = 0.0673 d²", where: [
              ["d", "sight distance in kilometres; the answer is in metres"],
            ]},
            { k: "p", t: "The magnitudes are worth knowing. At 100 m the combined effect is 0.7 mm — negligible. At 500 m it is 17 mm, and at 1 km it is 67 mm, which is enormous for levelling. Refraction is also the less reliable of the two, since it varies with temperature gradient near the ground and is worst on a hot afternoon over bare earth." },
            { k: "eg",
              title: "Example 6.4 — How far can you see?",
              given: "An observer's eye is 1.5 m above the sea; a lighthouse lamp is 40 m above it. Use the combined correction 0.0673 d².",
              steps: [
                { t: "Invert the correction", w: "h = 0.0673 d²  →  d = √(h/0.0673) = 3.855 √h  (d in km, h in m)" },
                { t: "Each part of the sight line", w: "observer: 3.855 √1.5 = 4.72 km\nlamp:     3.855 √40  = 24.38 km" },
              ],
              ans: "The lamp is visible out to about 29.1 km. The same formula sizes the error on a single long levelling sight — and is why sights are kept short.",
            },
            { k: "h", t: "Equal sights" },
            { k: "dia", id: "an-sv-collim", cap: "Equal backsight and foresight distances make the same error appear in both readings, so it drops out of the difference." },
            { k: "p", t: "Keep the backsight and foresight distances equal and <strong>all three of curvature, refraction and collimation error cancel</strong>, because each affects both readings by the same amount and the level is computed from their difference. This one habit is worth more than any amount of instrument adjustment, and it costs nothing but pacing." },
            { k: "def", term: "Reciprocal levelling", t: "Where sights cannot be balanced — across a river or a valley — the level is set up close to each bank in turn and the difference computed from the mean of the two results. The errors, having opposite sign in the two set-ups, cancel in the mean. It is the same logic as face left and face right in Chapter 8." },
            { k: "eq", expr: "true difference H = ½ [(b₁ − a₁) + (b₂ − a₂)]      error in the far reading e = ½ [(b₁ − a₁) − (b₂ − a₂)]", where: [
              ["a₁, b₁", "staff readings on A and B with the level near A"],
              ["a₂, b₂", "readings on A and B with the level near B; H is the fall from A to B"],
            ]},
            { k: "eg",
              title: "Example 6.5 — Reciprocal levelling across a river",
              given: "A and B are on opposite banks, 400 m apart. Level near A: A reads 1.025, B reads 1.820. Level near B: A reads 0.660, B reads 1.405. RL of A = 150.000 m.",
              steps: [
                { t: "Apparent differences", w: "near A: 1.820 − 1.025 = 0.795\nnear B: 1.405 − 0.660 = 0.745" },
                { t: "True difference — the mean", w: "H = (0.795 + 0.745)/2 = 0.770 m fall from A to B\nRL of B = 150.000 − 0.770 = 149.230 m" },
                { t: "What cancelled", w: "e = (0.795 − 0.745)/2 = 0.025 m in the far-bank reading\ncurvature and refraction alone over 400 m = 0.0673 × 0.4² = 0.011 m\nthe remaining 0.014 m is collimation error — removed with the rest" },
              ],
              ans: "RL of B = 149.230 m. Both set-ups should be done as close together in time as possible, because refraction changes through the day and only a constant error cancels.",
            },
          ],
        },

        {
          n: "6.6",
          title: "Difficulties, and what to carry forward",
          hi: "कठिनाइयाँ और सार",
          blocks: [
            { k: "list", items: [
              "<strong>Steep ground</strong> — many short set-ups, or a staff held horizontally against a wall for the offset.",
              "<strong>An obstacle such as a wall</strong> — read the top of the wall as a foresight and again as a backsight from the far side.",
              "<strong>A ceiling or soffit</strong> — the staff is held inverted, and the reading is booked as <strong>negative</strong>. The arithmetic then works unchanged.",
              "<strong>A pond or river</strong> — reciprocal levelling.",
              "<strong>Long line</strong> — close the circuit back onto the starting benchmark, or onto another of known RL, and distribute the misclosure in proportion to the distance (or the number of set-ups) from the start.",
            ]},
            { k: "p", t: "How much misclosure is acceptable depends on the class of work and is written as a constant times √K, where K is the length of the circuit in kilometres. For precise levelling it is ±0.006√K m (<a href=\"https://prepp.in/question/the-permissible-error-e-for-the-precise-levelling-6616890f6c11d964bb99a6a1\" target=\"_blank\" rel=\"noopener\">Prepp</a>); third-order work is commonly held to ±12√K mm (worked in <a href=\"https://files.library.nung.edu.ua/chytalnya/4798/files/basic-html/page45.html\" target=\"_blank\" rel=\"noopener\">a surveying textbook page</a> as 12√2 = 17 mm for a 2 km circuit). Rougher classes use larger constants; the job specification, not a textbook, sets the figure." },
            { k: "eg",
              title: "Example 6.6 — Distributing a misclosure",
              given: "A levelling circuit of 2.0 km starts and ends on a BM of RL 100.000 m. The reduced level carried round to the BM comes out as 100.012 m. Change points CP1–CP3 are at 0.5, 1.0 and 1.5 km round the circuit. Third-order limit ±12√K mm.",
              steps: [
                { t: "Is it acceptable?", w: "misclosure = 100.012 − 100.000 = +12 mm\nlimit = 12√2 = ±17 mm  →  acceptable" },
                { t: "Correction in proportion to distance", w: "total correction = −12 mm over 2.0 km = −6 mm per km\nCP1 (0.5 km) −3 mm, CP2 (1.0 km) −6 mm, CP3 (1.5 km) −9 mm, closing BM −12 mm" },
              ],
              ans: "Accept the circuit and apply −3, −6, −9 and −12 mm cumulatively. Had the misclosure exceeded 17 mm, the right response is to re-level, not to distribute it.",
            },
            { k: "real", t: "Inverted staff readings turn up constantly in building work, because soffit levels, beam undersides and lintel levels all need them. The convention that saves you: <strong>book the reading with a minus sign and change nothing else</strong>. HI − (−2.150) = HI + 2.150, which is exactly right, because the point is above the line of sight." },
            { k: "list", items: [
              "Level surface is curved; a horizontal line is straight and tangential.",
              "HI is the RL of the line of collimation, not the height of the tripod.",
              "BS is first after a set-up, FS is last before moving. Position, not direction.",
              "HI method is quick; rise-and-fall checks every reading. Choose by how much the intersights matter.",
              "ΣBS − ΣFS = ΣRise − ΣFall = last RL − first RL.",
              "The arithmetic check does not check the fieldwork — closing on a benchmark does.",
              "Curvature 0.0785 d², refraction 0.0112 d², combined 0.0673 d², d in km.",
              "Balance your sights: curvature, refraction and collimation all cancel at once. Two-peg test finds collimation error; reciprocal levelling cancels it where sights cannot be balanced.",
              "Distance to the visible horizon d = 3.855√h km (h in m).",
              "Inverted staff readings are booked negative.",
            ]},
            { k: "p", t: "Chapter 7 takes levels over a whole area rather than along a line, and joins the points of equal height into the contours that a design is built on." },
          ],
        },
      ],
    }

  );
})();
