/* ============================================================
   HYDROLOGY · COMPLETE NOTES — Chapter 7
   Streamflow Measurement
   Sources consolidated here: S2 (p.50-63), S3 (p.19-30)
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-7",
    n: 7,
    title: "Streamflow Measurement",
    hi: "प्रवाह मापन",
    blurb: "Stream classification (perennial, intermittent, ephemeral, influent, effluent) se rating curve tak — stage measurement (staff, wire, float, bubble gauge), velocity measurement (current meter calibration, one/two/three-point methods), aur discharge ke saare direct/indirect methods: mid-section area-velocity, moving boat, dilution/chemical gauging aur slope-area, worked examples ke saath, har fact S2/S3 page-cited.",
    mins: 30,
    sections: [

      /* ---------------------------------------------------------- 7.1 */
      {
        n: "7.1",
        title: "Streams and their classification",
        hi: "धारा (स्ट्रीम) एवं उनका वर्गीकरण",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.50–51, S3 p.30" },
          { k: "def", term: "Stream", t: "A flow channel into which the surface runoff from a specified basin may drain. (S2 p.50)" },
          { k: "def", term: "Catchment boundary (ridge/divide)", t: "The raised line separating two adjoining basins. Precipitation falling exactly on this ridge can drain into either basin on either side of it. (S2 p.50)" },
          { k: "cmp", t: "Stream classification — the water-table picture (S2) combined with the hydrograph picture (S3)", cols: ["Water-table / seepage relation (S2 p.50–51)", "Hydrograph behaviour (S3 p.30)"], rows: [
            ["Perennial", "River bed is always below the GWT — groundwater constantly feeds the stream; flow exists all year.", "Water table is always above the bed; the hydrograph never touches the time-axis."],
            ["Effluent", "Bed lies below the GWT — upward seepage arrows show groundwater rising into the channel.", "Gets a groundwater contribution — water table is above the bed."],
            ["Influent", "Bed lies above the GWT — downward seepage arrows show the stream itself recharging the ground.", "Recharges the groundwater — water table is below the bed."],
            ["Intermittent", "Behaves as influent for part of the year and effluent for the rest, as the GWT rises and falls with the season.", "Water table is above the bed only in the wet season; flow may drop to zero in the dry season, so the hydrograph touches the x-axis during dry spells."],
            ["Ephemeral", "Carries water only in the rainy season — e.g. the tributaries of the river Kosi.", "No base flow at all — GWT is always below the bed; the hydrograph touches the x-axis frequently."],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Influent/effluent ka matlab sirf yeh hai ki paani bed ke through kis taraf jaa raha hai — <b>effluent</b> ko zameen se paani <b>milta</b> hai (bed, GWT ke neeche, upward seepage), <b>influent</b> apna paani zameen ko <b>de</b> deta hai (bed, GWT ke upar, downward seepage). Perennial/intermittent/ephemeral bas yeh batate hain ki yeh status season ke saath badalta hai ya nahi — perennial hamesha effluent-jaisa rehta hai, ephemeral sirf baarish mein paani paata hai, aur intermittent dono ke beech, season ke hisaab se switch karta hai." },
          { k: "trap", t: "Influent aur effluent ko ulta mat yaad karo — <b>in</b>fluent matlab paani <b>in</b>to the ground jaa raha hai (stream se zameen ko recharge), <b>ef</b>fluent matlab groundwater <b>ef</b>flux ho rahi hai stream mein (zameen se stream ko paani)." },
        ],
      },

      /* ---------------------------------------------------------- 7.2 */
      {
        n: "7.2",
        title: "Stage measurement — gauges and automatic recorders",
        hi: "जल-स्तर (स्टेज) मापन — गेज एवं स्वचालित रिकॉर्डर",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.51–52" },
          { k: "def", term: "Stage", t: "The water-surface elevation of a river measured above a datum. The datum may be mean sea level (MSL) or any assumed local level. The process of measuring stage is called <b>Gauging</b>. (S2 p.51)" },
          { k: "list", items: [
            "<b>Manual gauge</b> → Staff gauge.",
            "<b>Automatic gauge</b> → Wire gauge, Float gauge recorder, Bubble gauge recorder. (S2 p.51)",
          ] },
          { k: "def", term: "Staff Gauge", t: "Made of a wooden material chosen for its low coefficient of thermal expansion with respect to temperature and moisture, so the graduations stay accurate. It is rigidly fixed to a structure — abutment, pier, wing wall etc. — placed along the section of the river, and read directly. (S2 p.51)" },
          { k: "def", term: "Wire Gauge", t: "A wire is dropped from above a structure (e.g. a bridge) until it touches the water surface. The wire is wound on a pulley, so the length of wire paid out is directly proportional to the number of revolutions of the pulley. (S2 p.51)" },
          { k: "eq", expr: "L = n · 2πr", where: [["L", "length of wire paid out to touch the water"], ["r", "radius of the pulley"], ["n", "number of revolutions of the pulley"]] },
          { k: "def", term: "Float Gauge Recorder", t: "An automatic stage recorder. A float and a counterweight are connected by a wire running over a pulley, housed inside a stilling well (which protects the float from debris and wave action). The rise and fall of the float directly gives the water-surface elevation. (S2 p.52)" },
          { k: "def", term: "Bubble Gauge Recorder", t: "Compressed air or gas is bubbled out at a constant rate through a submerged outlet until it just escapes at the water surface. The pressure needed to push the bubble out equals the weight of the water column above the outlet. (S2 p.52)" },
          { k: "eq", expr: "P = ρgH", where: [["P", "applied (bubble) pressure"], ["ρ", "density of water"], ["g", "acceleration due to gravity"], ["H", "depth of water above the bubble outlet"]] },
          { k: "def", term: "Depth measurement", t: "Measured by (i) sounding rods, or (ii) a depth-echo recorder. (S2 p.52)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Staff gauge seedha-saadha, manually padhne wala scale hai — pier ya abutment par fix hota hai. Baaki teen (wire, float, bubble) sab continuous/automatic record ke liye hain: wire gauge pulley ki revolutions count karta hai, float gauge seedha float ki rise-fall track karta hai (stilling well debris se bachata hai), aur bubble gauge pressure se depth nikalta hai — teeno ka output end mein same hi cheez hai: water-surface elevation." },
          { k: "real", t: "Stilling well isliye zaroori hai float-gauge mein — bina usme, waves/debris float ko disturb karke galat reading de dete. Yeh same principle borewell/tank level automatic recorders mein bhi use hota hai." },
        ],
      },

      /* ---------------------------------------------------------- 7.3 */
      {
        n: "7.3",
        title: "Velocity measurement — floats and current meters",
        hi: "वेग मापन — फ्लोट एवं करंट मीटर",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.53–54, S3 p.19–22" },
          { k: "def", term: "Hydrometry", t: "The branch of discharge measurement that deals with stream-flow measurement is called Hydrometry. (S3 p.19)" },
          { k: "eq", expr: "Q = V/t,  V = A×L   ⇒   Q = AV   [units: m³/s]", where: [["V", "volume of water, = cross-section area A × length L travelled"], ["Q", "discharge = volume per unit time"]] },
          { k: "def", term: "Float method", t: "A float is placed on the river surface. If it travels a distance L (m) in a time t (sec), the surface velocity is Vs = L/t m/s. (S2 p.53)" },
          { k: "def", term: "Current meter", t: "A rotating element (cup or propeller) that spins due to its reaction with the stream's current. The number of revolutions per second (Ns, or N) is measured by an attached counter and converted to velocity through the meter's calibration equation. It is generally used to find the point velocity at any depth. (S2 p.53)" },
          { k: "eq", expr: "V = a·Ns + b   (equivalently V = aN + b)", where: [["V", "point velocity at the depth where the meter is held"], ["a, b", "current-meter constants, found by calibration"], ["Ns (or N)", "revolutions per second"]] },
          { k: "note", t: "Calibration: two known (velocity, revolution-rate) pairs are measured, V1 = a·N1 + b and V2 = a·N2 + b, and solved simultaneously for a and b; those constants are then substituted back into V = aN + b for every subsequent field reading of that meter. (S3 p.21)" },
          { k: "eg", title: "Finding a current meter's constants a, b by calibration (GATE)", given: "In 50 s, a cup registered 25 revolutions at a point where the velocity was 0.3 m/s, and 35 revolutions where the velocity was 0.45 m/s. If the same meter registers 50 revolutions in 60 s, find the velocity there.", steps: [
            { t: "Convert revolutions to rate (rev/s)", w: "N1 = 25/50 = 0.5 rev/s;  N2 = 35/50 = 0.7 rev/s" },
            { t: "Set up the two calibration equations", w: "0.3 = a(0.5) + b   ...(1)\n0.45 = a(0.7) + b   ...(2)" },
            { t: "Solve simultaneously", w: "(2) − (1): 0.15 = 0.2a  ⇒  a = 0.75\nback-substitute in (1): 0.3 = 0.75(0.5) + b  ⇒  b = 0.3 − 0.375 = −0.075" },
            { t: "Apply to the new reading", w: "Rate = 50/60 = 0.833 rev/s\nV = aN + b = 0.75(0.833) + (−0.075)" },
          ], ans: "V = 0.55 m/s (S3 p.28)" },
          { k: "def", term: "Current meter types — by axis (S2)", t: "<b>Vertical-axis CM</b> (e.g. Price meter) — axis is vertical; disadvantage: not suitable for inclined flow. <b>Horizontal-axis CM</b> — propeller type, suitable for flow inclined up to 15°, usable velocity range 0.15 m/s to 4 m/s. (S2 p.53)" },
          { k: "def", term: "Current meter types — by size (S3)", t: "<b>Price meter</b> — cup diameter 12.5 cm, used for larger rivers; constants a = 0.65, b = 0.03, so V = 0.65N + 0.03. <b>Pigmy meter</b> — cup diameter 5 cm, for small streams; constants a = 0.3, b = 0.003, so V = 0.3N + 0.003. (S3 p.20)" },
          { k: "note", t: "S2 classifies current meters by <b>axis orientation</b> (vertical-axis vs horizontal/propeller-axis); S3 classifies the same family by <b>cup size and application</b> (Price for large rivers, Pigmy for small streams). These are two different, non-conflicting ways of describing the instruments — both kept here. (S2 p.53; S3 p.20)" },
          { k: "def", term: "Velocity-depth profile (turbulent flow)", t: "Velocity increases from the bed up through the depth in a log-shaped profile. The maximum velocity Vmax is actually 10–15% higher than the surface velocity Vs, and occurs a little below the surface, typically in the 0.05y–0.15y band measured down from the free surface (this is the field rule used to locate Vmax under the surface). (S2 p.53–54)" },
          { k: "eq", expr: "V̄ (mean, general turbulent flow) = 0.85 Vs  to  0.95 Vs", where: [] },
          { k: "def", term: "One-point method", t: "For a shallow stream (depth ≤ 3 m per S3), the mean velocity is taken as the point velocity read at 0.6y depth from the free surface — this is the old point method or wading technique. Equivalently, S3 states it as the meter placed at 0.6×depth from the top, or 0.4×depth from the bottom. (S2 p.54; S3 p.21)" },
          { k: "eq", expr: "V̄ = V at 0.6y (from top) = V at 0.4y (from bottom) = aN + b", where: [] },
          { k: "def", term: "Two-point method", t: "For deep streams — the most accurate and most widely used method. The meter is held vertically at two depths along the same line of action: 0.2y from the top and 0.8y from the bottom, and the two point velocities are averaged. (S2 p.54; S3 p.21–22)" },
          { k: "eq", expr: "V̄ = (V0.2y + V0.8y) / 2", where: [] },
          { k: "def", term: "Three-point method", t: "Not a popular method. Averages point velocities at 0.2y, 0.6y and 0.8y. (S3 p.22)" },
          { k: "eq", expr: "V̄ = (V0.2y + V0.6y + V0.8y) / 3", where: [] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Current meter sirf ek calibrated rotating-cup sensor hai — har meter ka apna a, b hota hai jo do known readings se nikaalte ho. Kyunki stream mein velocity profile depth ke saath curve karta hai (bed par zero, thodi upar maximum, surface tak thoda kam), ek hi surface ya ek hi bed point lena misleading hoga. Isliye: shallow stream mein 0.6y par ek point kaafi maana jaata hai; deep stream mein 0.2y aur 0.8y ka average lena best hai kyunki yeh profile ke dono extremes ko balance kar deta hai." },
          { k: "trap", t: "Calibration problem solve karte waqt revolutions aur duration ki units match karna zaroori hai — 'N' hamesha rev/sec (ya jis unit mein a,b define hue the, usi mein) hona chahiye, seedha raw revolution count nahi (jaise GATE example mein 25 rev/50 sec ko 0.5 rev/sec banaya gaya, 25 nahi)." },
        ],
      },

      /* ---------------------------------------------------------- 7.4 */
      {
        n: "7.4",
        title: "Methods of discharge measurement — overview, gauging site, and the area-velocity (mid-section) method",
        hi: "प्रवाह मापन की विधियाँ — सिंहावलोकन एवं क्षेत्र-वेग (मिड-सेक्शन) विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.55–57, S3 p.19–20, S3 p.28" },
          { k: "list", items: [
            "<b>Direct methods:</b> (a) Area-velocity method (b) Moving boat method (c) Dilution method (d) Electromagnetic method (e) Ultrasonic method.",
            "<b>Indirect methods:</b> (a) Slope-area method (b) Hydraulic structures — notches, weirs, barrages, spillways etc.",
          ] },
          { k: "note", t: "S2 and S3 both group the methods the same way (area-velocity, dilution/chemical, ultrasonic and electromagnetic as direct; slope-area and hydraulic-structure methods as indirect — S2 p.55; S3 p.19–20). Neither source elaborates how the electromagnetic or ultrasonic methods actually work beyond naming them, so that detail is left out here rather than invented." },
          { k: "def", term: "Guidelines for selecting a gauging site", t: "The site should be stable; easily accessible throughout the year; free from backwater effect in the channel; and the stream should have a well-defined cross-section area that does not change across seasons. (S2 p.55)" },
          { k: "p", t: "<b>Area-velocity method</b> — generally used for a shallow stream. The river cross-section at the chosen gauging site is divided into a number of vertical sub-sections; depth and point velocity (by the one-point, 0.6y method, since the method targets shallow streams) are measured at each vertical. (S2 p.55)" },
          { k: "dia", id: "hb-hydro-midsection", cap: "The mid-section method: the cross-section is split into one sub-area per velocity vertical, each taken as width × local depth × local velocity." },
          { k: "eq", expr: "Effective width, 1st segment:  W̄1 = (W1 + W2/2)² / (2W1)", where: [] },
          { k: "eq", expr: "Effective width, interior segments (2 ≤ i ≤ n−2):  W̄i = (Wi + Wi+1) / 2", where: [] },
          { k: "eq", expr: "Effective width, last segment:  W̄(n−1) = (Wn + W(n−1)/2)² / (2 Wn)", where: [] },
          { k: "note", t: "The two end segments (next to the banks) use this squared-mean width expression, not the plain average used for the interior verticals. The two end formulas are mirror images: the squared term is always built on the <b>bank-side</b> width (W1 at the left bank, Wn at the right bank). The notes write the last-segment formula with W(n−1) in place of Wn — corrected here (v45); see the note below the worked example. (S2 p.55–56)" },
          { k: "eq", expr: "ai = W̄i · yi · vi        Total discharge, Q = a1 + a2 + ... + a(n−1) = Σ ai", where: [] },
          { k: "cmp", t: "Current-meter sounding data across the gauging section", cols: ["Bank", "V1 (1.2 m)", "V2 (2.4 m)", "V3 (4.2 m)", "V4 (6.0 m)", "Bank (6.6 m)"], rows: [
            ["Depth y (m)", "0", "1.29", "2.55", "1.41", "0.42", "0"],
            ["Revs at 0.6y / duration", "—", "58 in 100 s", "112 in 150 s", "90 in 100 s", "30 in 100 s", "—"],
            ["Ns (rev/s)", "0", "0.58", "0.75", "0.90", "0.30", "0"],
            ["V = 0.51 Ns + 0.03 (m/s)", "0", "0.326", "0.413", "0.489", "0.183", "0"],
          ] },
          { k: "eg", title: "Discharge by the mid-section method, from the sounding data above", given: "Verticals at distances 0, 1.2, 2.4, 4.2, 6.0, 6.6 m from the left bank, with depths and velocities as in the table above. Segment widths: W1 = 1.2 m, W2 = 2.4−1.2 = 1.2 m, W3 = 4.2−2.4 = 1.8 m, W4 = 6.0−4.2 = 1.8 m, W5 = 6.6−6.0 = 0.6 m.", steps: [
            { t: "Effective width of 1st segment (edge formula)", w: "W̄1 = (W1 + W2/2)² / (2W1) = (1.2 + 0.6)² / 2.4 = 1.8² / 2.4 = 1.35 m" },
            { t: "Effective width of 2nd segment (interior)", w: "W̄2 = (W2 + W3)/2 = (1.2 + 1.8)/2 = 1.5 m" },
            { t: "Effective width of 3rd segment (interior)", w: "W̄3 = (W3 + W4)/2 = (1.8 + 1.8)/2 = 1.8 m" },
            { t: "Effective width of 4th segment (edge formula, bank-side width W5)", w: "W̄4 = (W5 + W4/2)² / (2W5) = (0.6 + 0.9)² / 1.2 = 1.5² / 1.2 = 1.875 m  (the notes use (W4 + W5/2)²/(2W4) and print 1.225 m)" },
            { t: "Sub-area discharge at each vertical, ai = W̄i · yi · vi", w: "a1 = 1.35 × 1.29 × 0.326 = 0.567 m³/s\na2 = 1.5 × 2.55 × 0.413 = 1.579 m³/s\na3 = 1.8 × 1.41 × 0.489 = 1.241 m³/s\na4 = 1.875 × 0.42 × 0.183 = 0.144 m³/s" },
          ], ans: "Q = a1+a2+a3+a4 = 0.567+1.579+1.241+0.144 ≈ 3.53 m³/s (the notes print 3.4811 m³/s) (S2 p.57)" },
          { k: "note", t: "<b>Correction (v45):</b> The end-vertical effective width assumes the depth falls linearly to zero at the <b>nearest bank</b>, so the squared formula must be built on the bank-side width: W̄1 = (W1 + W2/2)²/(2W1) at the left bank and, by mirror symmetry, W̄(n−1) = (Wn + W(n−1)/2)²/(2Wn) at the right bank (the form given in Subramanya's <i>Engineering Hydrology</i>). The notes swapped the roles of W4 and W5 for the last vertical, giving 1.225 m instead of <b>1.875 m</b>; a4 becomes 0.144 m³/s and Q ≈ <b>3.53 m³/s</b> instead of 3.4811 m³/s. (S2 p.55–57)" },
          { k: "note", t: "Rule of thumb for how many verticals (segments) to take: the number of segments is usually about 1/15 to 1/20 of the total channel width. (S2 p.57)" },
          { k: "eg", title: "Discharge of a triangular stream — given top width (two-point method)", given: "A triangular stream, top width 2 m, depth 0.9 m. Point velocities on the centre line, at 18 cm and 72 cm depth, are 0.60 m/s and 0.40 m/s.", steps: [
            { t: "Identify the 0.2y and 0.8y points", w: "y = 0.9 m  ⇒  0.2y = 18 cm, 0.8y = 72 cm — exactly the two given readings, so this is the two-point method" },
            { t: "Mean velocity (two-point method)", w: "V̄ = (V0.2y + V0.8y)/2 = (0.60 + 0.40)/2 = 0.50 m/s" },
            { t: "Cross-section area of the triangle", w: "A = ½ × top width × depth = ½ × 2 × 0.9 = 0.9 m²" },
          ], ans: "Q = A·V̄ = 0.9 × 0.50 = 0.45 m³/s (S2 p.54)" },
          { k: "eg", title: "Same two readings, given the apex angle instead of the top width", given: "A triangular channel, depth of flow 90 cm, apex angle 60°. Velocities at 18 cm and 72 cm below the water surface — the same 0.2y/0.8y points — are 0.6 m/s and 0.4 m/s (the notes word this as \"18 cm from the bottom and 72 cm from the top\", which would be one and the same point).", steps: [
            { t: "Mean velocity", w: "V̄ = (0.6 + 0.4)/2 = 0.5 m/s" },
            { t: "Area from the half-angle", w: "Half the apex angle = 30°. For an apex-down triangular section of depth y, top half-width = y·tan30°, so A = y²·tan30° = 0.9² × tan30°" },
          ], ans: "Q = A·V̄ = (0.9 × 0.9 × tan30°) × 0.5 = 0.2338 m³/s (S3 p.28)" },
          { k: "note", t: "<b>Correction (v45):</b> The notes place the two readings at \"18 cm from the bottom and 72 cm from the top\" — in a 90-cm flow these are the same point (0.8y below the surface). For the two-point method the readings must be at 0.2y = 18 cm and 0.8y = 72 cm <b>below the water surface</b>, which is how the given now reads; the working and Q = 0.2338 m³/s are unchanged. (S3 p.28)" },
          { k: "note", t: "The last two worked examples use the same velocities and depth but different given data — one gives the top width directly (S2 p.54), the other gives the apex angle and derives the triangular area from it, A = y²tan30° for a 60° included angle (S3 p.28). Not a conflict, just two routes to the same kind of area kept side by side." },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Mid-section method ka core idea: har current-meter vertical ko ek 'apni' sub-area assign karo — us vertical ke left-right mein jitna width uske 'zimme' aata hai (W̄i), uska depth (yi), aur uski velocity (vi). Beech ke verticals ke liye width simple average hai (dono taraf ke adjacent spacing ka), lekin bank ke paas wale pehle/aakhri vertical ke liye bank tak extend karna padta hai — isiliye unka formula alag (squared) dikhta hai. Sab sub-areas (ai) jod do, Q mil jaata hai." },
          { k: "trap", t: "Mid-section formulas yaad karte waqt bhi confuse mat ho — W̄ formulas sirf <b>width</b> nikalte hain, depth/velocity alag se measured values hain. Final ai = W̄i × yi × vi teeno ka product hai, sirf width ka formula nahi." },
        ],
      },

      /* ---------------------------------------------------------- 7.5 */
      {
        n: "7.5",
        title: "Moving boat method",
        hi: "चलती नाव विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.57" },
          { k: "p", t: "For a big, wide river, taking fixed-vertical readings by the area-velocity method becomes impractical — the Moving Boat method is preferred instead. A boat is run across the river at a steady speed, continuously recording depth and the current-meter reading as it goes; a special propeller-type current meter is used for this. (S2 p.57)" },
          { k: "def", term: "Resultant velocity VR", t: "The boat's own velocity Vb (across the river) and the flow velocity VF (downstream) combine vectorially into a resultant VR, at angle θ to the flow direction, as read by the towed current meter. (S2 p.57)" },
          { k: "eq", expr: "Discharge through the ith section: ai = c/s area × velocity of flow = [(yi−1+yi)/2] × Wi × VF, with Wi = Vb·t and VF = VR sinθ", where: [] },
          { k: "eq", expr: "ai = [(yi−1 + yi)/2] · VR² · sinθ · cosθ · t        Q = Σ ai", where: [["yi−1, yi", "depths at the two soundings bounding the ith section"], ["θ", "angle of the resultant VR to the flow direction"], ["t", "time taken to cross that section"]] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Moving boat method mein boat khud ek 'moving vertical' ban jaati hai — static rukhna zaroori nahi, continuously chalte hue depth aur current-meter reading leke poore cross-section ko cover kar lete ho, jo bade river ke liye fixed-vertical method se bahut tez hai. VR ko Vb aur VF mein resolve karke, sirf flow-component (VR sinθ) hi actual discharge calculation mein use hota hai." },
        ],
      },

      /* ---------------------------------------------------------- 7.6 */
      {
        n: "7.6",
        title: "Dilution (chemical) gauging method",
        hi: "तनुकरण (रासायनिक) विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.58, S3 p.22–23, S3 p.29" },
          { k: "def", term: "Dilution method", t: "Also called the chemical method or constant-rate-injection method; mainly used for small, turbulent streams in hilly areas where a current meter cannot be held steady (S3 p.22). A known solution of a chemical tracer is injected into the flow (stream or pipe flow); downstream, the tracer's concentration decreases as it mixes into the increasing total discharge. Concentrations are found by titration — Sodium dichromate (Na2Cr2O7) is named as a good titrator. The method works purely on the law of mass conservation (continuity of the tracer mass), with no velocity measurement needed at all. (S2 p.58; S3 p.22)" },
          { k: "eq", expr: "Mass conservation:  Q0·C0 + Qs·Cs = Qmix·Cmix     ⇒     Q0 = Qs(Cmix − Cs) / (C0 − Cmix)", where: [
            ["Q0", "stream discharge to be found, m³/s"],
            ["C0", "background tracer concentration already in the stream — C0 = 0 for pure water"],
            ["Qs, Cs", "discharge and concentration of the injected tracer solution"],
            ["Qmix, Cmix", "discharge and concentration of the mixture, found by titration at the downstream sampling point"],
          ] },
          { k: "note", t: "S3 writes the same mass balance the other way round, Qm = (QR·CR + QT·CT)/Cm, using QR/CR for the tracer-reagent stream and QT/CT, Qm/Cm for the quantity being solved for. It is the same underlying equation (Q0C0+QsCs=QmixCmix); S2's form solves for the unknown stream discharge Q0, S3's form solves for the unknown mixed discharge Qm — both kept since they are useful for different unknowns. (S2 p.58; S3 p.23)" },
          { k: "def", term: "Mixing length L", t: "The length of channel needed for the tracer to mix completely across the section." },
          { k: "eq", expr: "L = 0.13 B² C (0.7C + 2√g) / (g·y)", where: [
            ["C", "Chezy's roughness coefficient (depends on the type of channel)"],
            ["B", "average width of the channel"],
            ["y", "average depth of the channel"],
            ["g", "acceleration due to gravity"],
          ] },
          { k: "eg", title: "Stream discharge by the dilution method", given: "Background concentration of the river C0 = 0; concentration of the injected tracer CT = 25 g/l; discharge of the tracer QT = 50 cc/s; concentration found downstream after mixing Cm = 10 ppm. Find the river discharge Qm.", steps: [
            { t: "Mass balance, with the river's own background term zero", w: "Qm = (QR·CR + QT·CT)/Cm = (0 + QT·CT)/Cm" },
            { t: "Substitute the given values (CT in mg/l = 25×10³ mg/l; working in cc and mg as in the original)", w: "Qm = (25×10³ × 50)/10 = 1.25×10⁵ cc/s, then convert cc/s → m³/s by dividing by 10⁶" },
          ], ans: "Qm = 0.125 m³/s (S3 p.29)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Dilution method tab use hota hai jab stream itna turbulent ya chhota ho ki current meter steady nahi reh sakta. Idea simple hai: ek known concentration ka tracer daalo, thoda aage jaake jo diluted concentration milegi usi se — bina kisi velocity ya area measurement ke — pura discharge nikal lo, sirf mass-conservation (jo gaya wahi aaya) ke base par." },
          { k: "real", t: "Field mein mixing length L critical hai — sample uthane se pehle tracer ko poori width/depth mein uniformly mix hone dena padta hai, warna Cmix ki reading галат (misleading) aayegi. (S2 p.58)" },
        ],
      },

      /* ---------------------------------------------------------- 7.7 */
      {
        n: "7.7",
        title: "Slope-area method",
        hi: "ढाल-क्षेत्र विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.59–62, S3 p.23–24" },
          { k: "p", t: "Used to estimate flood discharge AFTER the flood has passed, from the high-water marks it leaves behind at an upstream and a downstream section a known distance L apart (S2 p.59). S3 describes the same method simply as the one 'mainly used for finding the flood discharge of a river' (S3 p.23)." },
          { k: "def", term: "Energy balance between the two sections", t: "E1 = E2 + HF + He, i.e. Z1+y1+V1²/2g = Z2+y2+V2²/2g+HF+He, where Z = bed elevation, y = flow depth, HF = head loss due to friction, He = head loss due to eddy formation. (S2 p.59)" },
          { k: "eq", expr: "He = Ke(V1²/2g − V2²/2g)", where: [["Ke", "eddy-loss coefficient"]] },
          { k: "list", items: [
            "Ke = 0 for uniform flow.",
            "Ke = 0.1 for gradual contraction.",
            "Ke = 0.3 for gradual expansion.",
            "Ke = 0.6 for sudden expansion.",
            "Ke = 0.8 for sudden contraction. (S2 p.59)",
          ] },
          { k: "eq", expr: "h1+V1²/2g = h2+V2²/2g+HF+Ke·|V1²/2g−V2²/2g|   ⇒   HF = (h1−h2) + (V1²/2g−V2²/2g) − Ke·|V1²/2g−V2²/2g|   (eddy loss He = Ke·|Δ(V²/2g)| is always a loss)", where: [["h1, h2", "water-surface elevations above datum at the u/s and d/s sections"]] },
          { k: "def", term: "Conveyance K (Manning's formula)", t: "Q = AV = (A/n)R^(2/3)S^(1/2) = K√S, where R = hydraulic mean depth = Area / wetted perimeter. (S2 p.60; S3 p.23 states the same V = (1/n)R^(2/3)S^(1/2) with R = A/P.)" },
          { k: "note", t: "Manning's n: 0.02 to 0.03 for an earthen channel/structure, 0.023 for a concrete bed. (S3 p.23)" },
          { k: "def", term: "Very wide river simplification", t: "For a very wide river, the hydraulic mean depth is practically equal to the actual depth of flow: R ≈ y. (S3 p.24)" },
          { k: "eq", expr: "Composite conveyance of the reach: K = √(K1·K2)   (generalised, K = (K1·K2·...·Kn)^(1/n) — geometric mean)", where: [] },
          { k: "eq", expr: "S = (HF+He)/L; since HF ≫ He, S ≈ HF/L  ⇒  Q = K√(HF/L)", where: [["S", "slope of the total-energy line"]] },
          { k: "steps", items: [
            "Assume V1 = V2 for the first trial.",
            "Find HF = h1 − h2 using this assumption.",
            "Find K1, K2 from A, R, n at each section; take K = √(K1K2).",
            "Find Q = K√(HF/L).",
            "Find V1 = Q/A1 and V2 = Q/A2.",
            "Re-find HF using the full expression (including the velocity-head and eddy terms), then re-find Q = K√(HF/L).",
            "Repeat until Q stays (converges to) constant. (S2 p.61)",
          ] },
          { k: "eg", title: "Flood discharge by the slope-area method", given: "Two river sections 500 m apart. Upstream: water elevation 85.230 m, A1 = 91.746 m², R1 = 2.835 m. Downstream: water elevation 85.176 m, A2 = 84.354 m², R2 = 2.917 m. A1 > A2, a case of gradual contraction ⇒ Ke = 0.1; Manning's n = 0.022 throughout.", steps: [
            { t: "Conveyance at the u/s and d/s sections", w: "K1 = (A1/n)R1^(2/3) = (91.746/0.022)(2.835)^(2/3) = 8353.46\nK2 = (A2/n)R2^(2/3) = (84.354/0.022)(2.917)^(2/3) = 7827.816" },
            { t: "Composite conveyance", w: "K = √(K1K2) = √(8353.46 × 7827.816) = 8086.369" },
            { t: "Trial 1 — assume V1 = V2", w: "HF = h1 − h2 = 85.230 − 85.176 = 0.054 m" },
            { t: "Trial 1 — discharge", w: "Q = K√(HF/L) = 8086.369 × √(0.054/500) = 84.036 m³/s" },
            { t: "Trial 1 — back out V1, V2", w: "V1 = Q/A1 = 0.916 m/s;  V2 = Q/A2 = 0.996 m/s" },
            { t: "Trial 2 — refine HF with the velocity-head term and the eddy loss He = Ke·|V1²/2g − V2²/2g|", w: "V1²/2g − V2²/2g = (0.916² − 0.996²)/19.62 = −0.0078 m;  He = 0.1 × 0.0078 = 0.0008 m\nHF = 0.054 − 0.0078 − 0.0008 = 0.0454 m  (the notes keep the sign of the eddy term, turning the loss into a gain, and get 0.047 m)" },
            { t: "Trial 2 — refine Q, then V1, V2", w: "Q = 8086.369 × √(0.0454/500) = 77.05 m³/s;  V1 = 77.05/A1 = 0.840 m/s;  V2 = 77.05/A2 = 0.913 m/s" },
            { t: "Trials 3 to 5 — repeat until Q stops changing", w: "Trial 3: HF = 0.0468 m  ⇒  Q = 78.20 m³/s (V1 = 0.852, V2 = 0.927 m/s)\nTrial 4: HF = 0.0466 m  ⇒  Q = 78.02 m³/s (V1 = 0.850, V2 = 0.925 m/s)\nTrial 5: HF = 0.0466 m  ⇒  Q = 78.05 m³/s — converged" },
          ], ans: "Q ≈ 78.05 m³/s (the notes print 79.227 m³/s) (S2 p.62)" },
          { k: "note", t: "<b>Correction (v45):</b> The eddy loss He = Ke·|V1²/2g − V2²/2g| is always an energy <b>loss</b>, so it is subtracted as a positive magnitude whatever the sign of the velocity-head change. In this contracting reach V2 exceeds V1, so (V1²/2g − V2²/2g) is negative and the notes' signed term −Ke(V1²/2g − V2²/2g) adds about 0.0008 m back as a gain (HF = 0.047 instead of 0.0454 m in Trial 2). With the eddy loss taken correctly the iteration settles at HF ≈ 0.0466 m and <b>Q ≈ 78.05 m³/s</b>; the notes print 79.227 m³/s. Two further slips in the notes' working: Trial 2 writes √(0.046/500) although the Q it prints (78.400) corresponds to HF = 0.047, and Trial 3 rounds HF up to 0.048 — even with the notes' signed term the iteration actually converges at about 79.04 m³/s. (S2 p.62)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Slope-area method flood ke <b>baad</b> bhi discharge estimate karne deta hai — sirf high-water marks (u/s aur d/s water-surface elevation) chahiye, live gauging ki zaroorat nahi. Manning's formula se conveyance K nikalo, phir trial-and-error (V1=V2 se shuru karke) se HF aur Q ko converge karo jab tak consecutive iterations mein Q badalna band na ho jaaye." },
          { k: "real", t: "Flood-damage survey mein yeh sabse practical method hai kyunki flood ke time koi gauge/current-meter site par hota nahi — baad mein sirf high-water marks naap ke discharge nikaal lete hain. (S2 p.59)" },
        ],
      },

      /* ---------------------------------------------------------- 7.8 */
      {
        n: "7.8",
        title: "Rating curves — stage-discharge relationship",
        hi: "रेटिंग वक्र — जल स्तर-प्रवाह संबंध",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.63, S3 p.19" },
          { k: "def", term: "Rating curve", t: "The stage-discharge relationship of a river, plotted as discharge Q against (G−a). Once this curve exists, discharge can be read off directly from just the depth of flow — no further velocity or area measurement is needed. (S2 p.63; S3 p.19)" },
          { k: "eq", expr: "G = stage of the river at any time t;   a = stage corresponding to zero discharge", where: [] },
          { k: "def", term: "Log-scale form", t: "Plotted as ln Q against ln(G−a), the rating curve becomes a straight line through the origin. (S2 p.63)" },
          { k: "def", term: "Shifting control", t: "If the rating curve of a river itself changes with time (e.g. the bed scours or silts up), that control is called a shifting control — different years give different curves of increasing or decreasing steepness. (S2 p.63)" },
          { k: "def", term: "Permanent control", t: "If the stage-discharge relationship does NOT change with time, it is a permanent control — several years of data (e.g. 2015, 16, 17, 20, 21) all fall on the same single curve. (S2 p.63)" },
          { k: "def", term: "Loop rating curve", t: "During the passage of a flood, flow is unsteady, and the high-water marks left behind trace a loop rather than a single line: the rising limb and the falling limb of the flood follow different paths on the stage-discharge plot. As a result, the maximum discharge actually occurs BEFORE the maximum stage is reached — at a given stage, the rising-limb discharge QR exceeds the falling-limb discharge QF, while the falling-limb stage SF exceeds the rising-limb stage SR (QR &gt; QF, SF &gt; SR). (S2 p.63)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Rating curve bana lene ke baad roz-roz velocity measurement ki zaroorat nahi — sirf stage (depth) padho aur curve se Q seedha mil jaata hai. Lekin yeh seedha curve sirf <b>steady</b> flow mein kaam karta hai. Flood ke time flow unsteady hota hai, isliye rising limb par same stage par discharge zyada hota hai aur falling limb par kam — isi wajah se ek single line ke jagah loop ban jaata hai." },
          { k: "trap", t: "Flood discharge ko seedhe (non-loop) rating curve se mat padho — rising aur falling limb par same stage ke liye Q alag hoga, loop rating curve ka istemaal karo." },
        ],
      },

      /* ---------------------------------------------------------- 7.9 */
      {
        n: "7.9",
        title: "Percentage-error relations in discharge (weirs and slope-area)",
        hi: "प्रवाह में प्रतिशत त्रुटि संबंध (वियर एवं ढाल-क्षेत्र)",
        blocks: [
          { k: "h", t: "📘 Notes — S3 p.24–27" },
          { k: "eq", expr: "General % change:  (dQ/Q) × 100 = [(Q2 − Q1)/Q1] × 100", where: [["+ve result", "an increase in Q"], ["−ve result", "a decrease in Q"]] },
          { k: "eq", expr: "Slope-area discharge:  Q ∝ √S   ⇒   Q1/Q2 = √(S1/S2)", where: [] },
          { k: "eq", expr: "Rectangular weir/notch:  Q ∝ H^(3/2)   ⇒   (dQ/Q)×100 = (3/2)(dH/H)×100   — % error in Q = 1.5 × % error in head H", where: [] },
          { k: "eq", expr: "Triangular (V-notch) weir:  Q ∝ H^(5/2)   ⇒   (dQ/Q)×100 = (5/2)(dH/H)×100   — % error in Q = 2.5 × % error in head H", where: [] },
          { k: "eg", title: "% error in discharge through a V-notch", given: "% error in head measurement = 1%. Find the % error in discharge for a triangular (V-notch) weir.", steps: [
            { t: "Apply the V-notch error relation", w: "(dQ/Q)×100 = (5/2) × (dH/H × 100) = (5/2) × 1%" },
          ], ans: "%Q = 2.5% (S3 p.25)" },
          { k: "eg", title: "Discharge change with bed/energy slope", given: "Flow in a river is 100 cumec at a bed (energy) slope of 1 in 3000. Find the new discharge if the slope changes to 1 in 6000, all other dimensions unchanged.", steps: [
            { t: "Apply Q ∝ √S", w: "Q1/Q2 = √(S1/S2) = √[(1/3000)/(1/6000)]" },
            { t: "Solve for Q2", w: "Q2 = 100 × √(1/6000) / √(1/3000)" },
          ], ans: "Q2 = 70.71 cumec (S3 p.26)" },
          { k: "eg", title: "% change in discharge for a very wide channel — depth up 40%, slope down 30%", given: "Depth of flow increases by 40% and the energy slope decreases by 30%, for a very wide channel (R ≈ y, width B unchanged), using Manning's V = (1/n)y^(2/3)S^(1/2) and Q = AV = By·V. Find the % change in discharge.", steps: [
            { t: "Write Q in terms of y and S alone (very wide channel: R ≈ y, width B constant)", w: "Q = (B/n) · y^(5/3) · S^(1/2)  ∝  y^(5/3) · S^(1/2)" },
            { t: "New values", w: "y2 = y1 + 0.40y1 = 1.4 y1;    S2 = S1 − 0.30S1 = 0.7 S1" },
            { t: "Ratio form of the % change formula", w: "(dQ/Q)×100 = [y2^(5/3)S2^(1/2) − y1^(5/3)S1^(1/2)] / [y1^(5/3)S1^(1/2)] × 100 = [(1.4)^(5/3)(0.7)^(1/2) − 1] × 100" },
          ], ans: "(dQ/Q)×100 = 46.58% (S3 p.27)" },
          { k: "note", t: "<b>Correction (v45):</b> The notes write the very-wide-channel assumption as \"B = y, R = y\". Only <b>R ≈ y</b> is the wide-channel assumption; the width B is a fixed channel dimension. With B = y, Q would vary as y^(8/3), not y^(5/3). The working (Q ∝ y^(5/3)S^(1/2)) is right for constant B, and the result (1.4)^(5/3)(0.7)^(1/2) − 1 = 0.4659, i.e. about +46.6%, stands. (S3 p.27)" },
          { k: "note", t: "<b>Check:</b> the transcript labels this +46.58% result as a 'decrease in discharge' — but by its own earlier sign rule stated two pages before (a +ve % change means an INCREASE in Q, S3 p.24), a positive 46.58% should instead be read as a 46.58% <b>increase</b> in discharge: the 40% gain in depth (which enters as y^(5/3)) outweighs the 30% loss in slope (which enters only as S^(1/2)). The transcript itself flags this as a possible logic inconsistency at that point; the computed figure (46.58%) is kept exactly, but the correct reading — consistent with the source's own stated convention — is an increase, not a decrease. (S3 p.24, p.27)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh sab error-propagation relations seedhe power-law se nikalte hain: agar Q ∝ H^n, to chhote errors ke liye %error(Q) ≈ n × %error(H). Rectangular weir mein n = 3/2, V-notch mein n = 5/2 (isiliye V-notch zyada sensitive hai head-measurement error ke liye), aur slope-area mein S ka power sirf ½ hai, isliye slope ka error discharge par depth ya head ke comparison mein kam asar karta hai." },
        ],
      },

      /* ---------------------------------------------------------- 7.10 */
      {
        n: "7.10",
        title: "Quick revision — streamflow measurement",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Stream classification: perennial / effluent / influent / intermittent / ephemeral — by water-table relation (S2) and by hydrograph behaviour (S3).",
            "Stage = water-surface elevation above a datum; measured by staff gauge (manual), wire gauge, float gauge recorder, bubble gauge recorder (automatic).",
            "Current meter: V = aN + b, calibrated from two known readings; one-point (0.6y, shallow), two-point (0.2y & 0.8y, most accurate), three-point (0.2y, 0.6y, 0.8y) methods.",
            "Area-velocity (mid-section) method: cross-section split into sub-areas ai = W̄i·yi·vi; end segments use the squared-mean width formula, interior segments the plain average; Q = Σai.",
            "Moving boat method for wide rivers: ai = [(yi−1+yi)/2]·VR²·sinθ·cosθ·t.",
            "Dilution (chemical) method: Q0C0+QsCs=QmixCmix; mixing length L depends on Chezy's C, width B, depth y.",
            "Slope-area method: Q = K√(HF/L), K = √(K1K2) by Manning's formula, solved by iteration (assume V1=V2, refine HF, Q, V1, V2 until Q converges).",
            "Rating curve (Q vs G−a): shifting control (changes with time) vs permanent control (doesn't); loop rating curve during a flood, where QR &gt; QF for the same stage on rising vs falling limb.",
            "% error propagation: Q∝H^(3/2) for a rectangular weir, Q∝H^(5/2) for a V-notch, Q∝√S for slope-area.",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Basic discharge relation: Q = AV; current-meter calibration: V = aN + b (Price meter a=0.65,b=0.03; Pigmy meter a=0.3,b=0.003).",
            "Two-point method V̄=(V0.2y+V0.8y)/2 is the standard, most-accurate way to get mean velocity on a vertical.",
            "Mid-section method: Q = Σ(W̄i·yi·vi); dilution method: Q0 = Qs(Cmix−Cs)/(C0−Cmix); slope-area: Q = K√(HF/L).",
            "A loop rating curve exists because flood flow is unsteady — maximum discharge happens before maximum stage.",
          ] },
        ],
      },

    ],
  });
})();
