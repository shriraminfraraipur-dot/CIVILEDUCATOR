/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   Chapter 3 — Flexure: singly reinforced sections
   Chapter 4 — Doubly reinforced and flanged sections

   Every design value names its IS 456:2000 clause. The code's own
   text is never reproduced; the derivations, the arithmetic and
   the traps are written for this app.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "rcc"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "rcc-3",
      n: 3,
      title: "Flexure — Singly Reinforced Sections",
      hi: "बंकन — सिंगली रीइन्फोर्स्ड सेक्शन",
      blurb: "Where 0.36 and 0.42 come from, why xu,max exists at all, and the two calculations — analysis and design — that every beam question is one of.",
      mins: 45,
      sections: [

        {
          n: "3.1",
          title: "What a beam section actually does",
          hi: "बीम सेक्शन असल में करता क्या है",
          blocks: [
            { k: "p", t: "A simply supported beam under load sags. The top fibres shorten, the bottom fibres stretch, and somewhere between them is a layer that does neither — the neutral axis. Plain concrete would crack at the bottom almost at once, because its tensile strength is roughly a tenth of its compressive strength, and the crack would run straight up and split the beam." },
            { k: "p", t: "Reinforced concrete is the arrangement that accepts the crack instead of preventing it. Steel is placed where the tension is, the concrete below the neutral axis is allowed to crack and is then assumed to carry nothing at all, and what remains is a couple: concrete in compression above the neutral axis, steel in tension below it, separated by a lever arm. Every formula in this chapter is that couple written down." },
            { k: "def", term: "Effective depth (d)", t: "The distance from the extreme compression fibre to the <strong>centroid of the tension steel</strong> — not to the soffit and not to the nearest bar. With one layer of bars, d = D − clear cover − stirrup diameter − half the bar diameter. Capacity depends on d², so an error here is expensive." },
            { k: "dia", id: "hb-rcc-strain-stress", cap: "Section, strain and stress at the limit state of collapse in flexure. The strain diagram is straight because plane sections remain plane; the stress diagram is not, because concrete is not elastic." },
            { k: "h", t: "The five assumptions" },
            { k: "p", t: "IS 456 Cl. 38.1 lists the assumptions for flexural design at the limit state of collapse. They were stated at the end of Chapter 2; here is what each one is actually doing:" },
            { k: "list", items: [
              "<strong>Plane sections remain plane.</strong> This is what makes strain vary linearly with depth, and therefore what lets you find the strain at any level once you know the neutral axis depth. Everything else follows from it.",
              "<strong>Maximum concrete strain in bending is 0.0035.</strong> This is the definition of failure — the section is declared to have collapsed when the top fibre reaches it. It is a limit fixed by observation, not a calculation.",
              "<strong>The stress-strain curve for concrete is parabolic to a strain of 0.002, then constant at 0.446 fck.</strong> This is where the numbers 0.36 and 0.42 come from, as §3.3 shows.",
              "<strong>Tensile strength of concrete is ignored.</strong> Conservative, and close to the truth once the section has cracked.",
              "<strong>Steel follows the design stress-strain curve of Cl. 38.1(e)</strong>, reaching a design yield stress of 0.87 fy.",
            ]},
            { k: "p", t: "There is a sixth, stated separately in Cl. 38.1(f), which gets its own section later: the strain in the tension steel at failure must be at least 0.002 + 0.87 fy/Es. That one is not a modelling assumption at all. It is a design requirement, and §3.5 explains why it is the most important line in the chapter." },
          ],
        },

        {
          n: "3.2",
          title: "The stress block",
          hi: "स्ट्रेस ब्लॉक",
          blocks: [
            { k: "p", t: "Strain is linear through the depth, but stress is not, because concrete's stress-strain curve is not a straight line. Follow the top of the section down from the compression face when the extreme fibre has just reached 0.0035:" },
            { k: "steps", items: [
              "At the top fibre the strain is 0.0035 and the stress is 0.446 fck — the design value of concrete strength, being 0.67 fck (the flexural value) divided by the partial safety factor 1.5.",
              "The stress stays at 0.446 fck as you move down, as long as the strain is above 0.002, because the assumed curve is flat beyond that strain.",
              "At the level where strain equals 0.002 the flat part ends and the parabolic part begins.",
              "From there down to the neutral axis the stress falls parabolically to zero.",
            ]},
            { k: "p", t: "The result is a shape with a rectangular top and a parabolic bottom — the <em>parabolic-rectangular stress block</em>. The one thing to fix before going further is where the boundary sits, and that is set purely by the strain diagram. Strain is zero at the neutral axis and 0.0035 at the top, so the level with strain 0.002 is at 0.002/0.0035 = 4/7 of the way up from the neutral axis." },
            { k: "eq", expr: "depth of parabolic part = (4/7) xu   ·   depth of rectangular part = (3/7) xu", where: [
              ["xu", "depth of the neutral axis below the extreme compression fibre, mm"],
            ]},
            { k: "dia", id: "hb-rcc-block", cap: "The stress block split into its rectangular and parabolic parts, with the area and centroid of each. Adding them gives 0.36 fck b xu acting at 0.42 xu from the top." },
          ],
        },

        {
          n: "3.3",
          title: "Where 0.36 and 0.42 come from",
          hi: "0.36 और 0.42 कहाँ से आते हैं",
          blocks: [
            { k: "p", t: "These two constants appear in every RCC design in India and are almost always memorised without proof. They are two lines of arithmetic, and knowing where they come from is what lets you tell whether a formula you half-remember is right." },
            { k: "h", t: "The compressive force" },
            { k: "p", t: "Take a section of width b. The rectangular part is the top 3/7 of xu at a constant stress of 0.446 fck:" },
            { k: "eq", expr: "C1 = 0.446 fck × b × (3/7) xu = 0.191 fck b xu", where: [] },
            { k: "p", t: "The parabolic part is the lower 4/7 of xu. The area under a parabola with its vertex at one end is two-thirds of the enclosing rectangle:" },
            { k: "eq", expr: "C2 = (2/3) × 0.446 fck × b × (4/7) xu = 0.170 fck b xu", where: [] },
            { k: "eq", expr: "Cu = C1 + C2 = 0.361 fck b xu  ≈  0.36 fck b xu", where: [] },
            { k: "h", t: "The line of action" },
            { k: "p", t: "The centroid of the rectangular part is at half its own depth from the top: 0.5 × (3/7) xu = 0.214 xu. The centroid of a parabolic area lies at three-eighths of its depth from the flat end, so measured from the top of the section it is (3/7)xu + (3/8)(4/7)xu = 0.429 xu + 0.214 xu = 0.643 xu. Take moments about the top fibre:" },
            { k: "eq", expr: "ȳ = [0.191 × 0.214 + 0.170 × 0.643] / 0.361 = 0.416 xu  ≈  0.42 xu", where: [
              ["ȳ", "depth of the line of action of Cu below the extreme compression fibre"],
            ]},
            { k: "note", t: "So the lever arm is z = d − 0.42 xu, and the whole of flexural design is the couple Cu × z. IS 456 Annex G states these in the same form. If you remember nothing else from this section, remember that 0.36 is an <em>area</em> coefficient and 0.42 is a <em>centroid</em> coefficient — they answer different questions and never swap places." },
            { k: "trap", t: "0.446 fck is not 0.45 fck rounded for convenience, and the 0.67 inside it is not a typing error for 0.85. Concrete in a beam is weaker in flexure than the same concrete in a cube test, and 0.67 fck is the code's allowance for that. Dividing by γm = 1.5 gives 0.446. Using fck itself anywhere in a limit state calculation inflates the answer by about 55%." },
            { k: "note", t: "<b>Precision on that last figure (v34):</b> the size of the error depends on where the wrong value goes. Writing 0.67 fck instead of 0.446 fck (forgetting γm) overstates the concrete force by exactly 50%; writing fck instead of 0.446 fck overstates it by 124%. In an under-reinforced beam the moment changes much less than the force, because the steel still governs — which is precisely why the mistake can go unnoticed in a design check. Either way: <b>0.36 fck b xu already contains γm; never divide again.</b>" },
          ],
        },

        {
          n: "3.4",
          title: "Equilibrium: the two equations",
          hi: "संतुलन: दो समीकरण",
          blocks: [
            { k: "p", t: "With the compression force established, the rest is statics. There is no external axial force on a beam, so the total compression must equal the total tension. That single statement fixes the neutral axis depth." },
            { k: "eq", expr: "0.36 fck b xu = 0.87 fy Ast", where: [
              ["fck", "characteristic compressive strength of concrete, N/mm²"],
              ["fy", "characteristic yield strength of steel, N/mm²"],
              ["b", "width of the section, mm"],
              ["Ast", "area of tension steel, mm²"],
            ]},
            { k: "eq", expr: "xu = 0.87 fy Ast / (0.36 fck b)", where: [] },
            { k: "p", t: "Taking moments of that couple about either force gives the moment of resistance. Taking them about the tension steel is usual:" },
            { k: "eq", expr: "Mu = 0.36 fck b xu (d − 0.42 xu)", where: [] },
            { k: "p", t: "Or about the compression force, which is the more useful form once Ast is the unknown:" },
            { k: "eq", expr: "Mu = 0.87 fy Ast (d − 0.42 xu)", where: [] },
            { k: "note", t: "Both expressions give the same number for the same section — they are one couple viewed from two ends. Use the steel form when you are designing (because Ast is what you are after) and the concrete form when you are checking (because xu is already known)." },
            { k: "h", t: "Substituting to get a single equation" },
            { k: "p", t: "Put the expression for xu into the steel form of Mu and the whole design reduces to one quadratic in Ast:" },
            { k: "eq", expr: "Mu = 0.87 fy Ast d − 0.87 fy Ast × 0.42 × [0.87 fy Ast / (0.36 fck b)]", where: [] },
            { k: "eq", expr: "Mu = 0.87 fy Ast d [1 − Ast fy / (b d fck)]", where: [] },
            { k: "p", t: "The bracket collapses because 0.87 × 0.42 / 0.36 = 1.0148 ≈ 1. IS 456 Annex G.1.1 gives the expression in this form, and it is the one to use for design: everything except Ast is known, so it is a quadratic that solves in one step." },
          ],
        },

        {
          n: "3.5",
          title: "Under-reinforced, balanced, over-reinforced",
          hi: "अंडर-रीइन्फोर्स्ड, बैलेंस्ड, ओवर-रीइन्फोर्स्ड",
          blocks: [
            { k: "p", t: "Add more tension steel to a section and xu rises — the equilibrium equation says so directly. That changes which material reaches its limit first, and therefore changes how the beam fails. This is the single most important idea in reinforced concrete design, and it is the reason xu,max exists." },
            { k: "dia", id: "hb-rcc-failure", cap: "Under-reinforced failure gives warning; over-reinforced failure does not. The code permits only the first." },
            { k: "def", term: "Under-reinforced", t: "Steel reaches its yield strain before the concrete reaches 0.0035. The steel then stretches at nearly constant stress, cracks widen visibly, the neutral axis rises, deflection grows — and only after all that does the concrete crush. The failure is slow, loud and visible." },
            { k: "def", term: "Balanced", t: "Both happen at the same instant. A theoretical boundary, not a design target." },
            { k: "def", term: "Over-reinforced", t: "Concrete reaches 0.0035 while the steel is still elastic. The compression zone crushes suddenly, with small deflections and narrow cracks up to the moment of failure. No warning at all." },
            { k: "p", t: "An over-reinforced beam is not weak — it may well carry more load than an under-reinforced one of the same size. It is <strong>brittle</strong>, and brittleness is what design codes exist to prevent. A structure that groans, sags and cracks before it fails gives its occupants time to leave. One that does not, does not." },
            { k: "trap", t: "The steel does not fracture in an under-reinforced failure. It yields and keeps stretching, and the concrete still crushes in the end. The difference is everything that happens first. Saying \"the steel breaks\" in an exam is a guaranteed mark lost." },
            { k: "p", t: "IS 456 Cl. 38.1(f) makes ductility a requirement rather than a preference: the strain in the tension steel at failure must not be less than 0.002 + 0.87 fy/Es. Because strain is linear through the section, that is a statement about how deep the neutral axis is allowed to go — and the next section turns it into a number." },
          ],
        },

        {
          n: "3.6",
          title: "xu,max — the ductility limit as a number",
          hi: "xu,max — सीमित न्यूट्रल एक्सिस",
          blocks: [
            { k: "p", t: "Set the top fibre strain to 0.0035 and the steel strain to the Cl. 38.1(f) minimum, then use similar triangles on the strain diagram. If xu,max is the neutral axis depth at which both are reached at once:" },
            { k: "dia", id: "hb-rcc-xumax", cap: "Strain compatibility: fixing the top strain at 0.0035 and the steel strain at its required minimum fixes the deepest neutral axis the code will allow." },
            { k: "eq", expr: "xu,max / d = 0.0035 / (0.0035 + 0.002 + 0.87 fy/Es)", where: [
              ["Es", "modulus of elasticity of steel = 2 × 10⁵ N/mm² (IS 456 Cl. 5.6.3)"],
            ]},
            { k: "p", t: "For Fe 415: 0.87 × 415 / 200000 = 0.001805. Adding 0.002 gives 0.003805, and adding 0.0035 gives 0.007305. So xu,max/d = 0.0035/0.007305 = 0.479, which the code rounds to 0.48. The same arithmetic for the other grades:" },
            { k: "list", items: [
              "<strong>Fe 250</strong> — 0.87×250/2×10⁵ = 0.001088; xu,max/d = 0.0035/0.006588 = <strong>0.53</strong>",
              "<strong>Fe 415</strong> — 0.001805; xu,max/d = 0.0035/0.007305 = <strong>0.48</strong>",
              "<strong>Fe 500</strong> — 0.002175; xu,max/d = 0.0035/0.007675 = <strong>0.46</strong>",
            ]},
            { k: "p", t: "Stronger steel gives a <em>shallower</em> permitted neutral axis, which is the opposite of what intuition suggests. The reason is that higher-grade steel needs more strain to reach its design stress, and the only way to give the steel more strain while the concrete stays at 0.0035 is to raise the neutral axis." },
            { k: "h", t: "The limiting moment of resistance" },
            { k: "p", t: "Put xu = xu,max into the concrete form of Mu and the result depends only on the grades and the section:" },
            { k: "eq", expr: "Mu,lim = 0.36 fck b xu,max (d − 0.42 xu,max)", where: [] },
            { k: "p", t: "For Fe 415, with xu,max = 0.48 d: 0.36 × 0.48 × (1 − 0.42 × 0.48) = 0.1728 × 0.7984 = 0.138. So:" },
            { k: "list", items: [
              "<strong>Fe 250</strong> — Mu,lim = 0.148 fck b d²",
              "<strong>Fe 415</strong> — Mu,lim = 0.138 fck b d²",
              "<strong>Fe 500</strong> — Mu,lim = 0.133 fck b d²",
            ]},
            { k: "cmp", t: "Ru,lim = Mu,lim / bd² (N/mm²) and the balanced steel percentage", cols: ["M20", "M25"], rows: [
              ["Fe 415 — Ru,lim", "2.76", "3.45"],
              ["Fe 500 — Ru,lim", "2.66", "3.33"],
              ["Fe 415 — pt,lim (%)", "0.96", "1.19"],
            ] },
            { k: "note", t: "Ru,lim values as tabulated by <a href=\"https://engineeringhulk.com/civil/rcc-design/singly-reinforced-beam/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — singly reinforced beam</a>, and simply 0.138 × fck and 0.133 × fck. The limiting steel percentage follows from equilibrium at xu = xu,max: pt,lim = 100 × 0.36 fck (xu,max/d)/(0.87 fy) = 41.38 (fck/fy)(xu,max/d) — 0.96% for M20/Fe 415, matching EngineeringHulk's ≈ 0.96% (derived). A beam with more tension steel than pt,lim is over-reinforced, whatever its moment." },
            { k: "note", t: "Mu,lim is not the strength of the section. It is the largest moment the section is <em>permitted</em> to be designed for while failing in a ductile way. If the applied Mu exceeds it, the answer is never \"add more tension steel\" — that would push xu past xu,max and make the beam brittle. The answer is a deeper section, a higher grade, or compression steel, which is Chapter 4." },
            { k: "trap", t: "xu,max/d depends on <strong>fy alone</strong>. It has nothing to do with the grade of concrete. Mu,lim does depend on fck, because fck appears in the expression for the compressive force — but the 0.48 does not change when you move from M20 to M30." },
          ],
        },

        {
          n: "3.7",
          title: "Analysis: what is this section worth?",
          hi: "विश्लेषण: यह सेक्शन कितना उठाएगा",
          blocks: [
            { k: "p", t: "Analysis takes a section that already exists — dimensions, grades and steel all known — and asks what moment it can carry. There is no iteration and no choice; the arithmetic runs straight through." },
            { k: "steps", items: [
              "Compute d from the cover, stirrup and bar diameters, if it is not given.",
              "Assume the steel has yielded and find xu from 0.36 fck b xu = 0.87 fy Ast.",
              "Compute xu,max = (0.48 or 0.53 or 0.46) × d for the grade of steel present.",
              "Compare. If xu < xu,max the assumption was right — the section is under-reinforced and the steel has indeed yielded.",
              "Compute Mu = 0.87 fy Ast (d − 0.42 xu).",
            ]},
            { k: "p", t: "If step 4 fails — xu comes out greater than xu,max — the section is over-reinforced and step 2's assumption was false: the steel has not yielded, so 0.87 fy is not its stress. Such a section is not permitted by IS 456 for new design. In an analysis question, report Mu = Mu,lim as the usable capacity and state that the section is over-reinforced and would fail without warning." },
            { k: "eg",
              title: "Example 3.1 — Moment capacity of a given section",
              given: "b = 250 mm, d = 400 mm, M20 concrete, Fe 415 steel, tension steel 3 bars of 16 mm.",
              steps: [
                { t: "Area of tension steel", w: "Ast = 3 × (π/4) × 16² = 3 × 201.06 = 603.2 mm²" },
                { t: "Neutral axis depth, assuming the steel has yielded", w: "0.36 × 20 × 250 × xu = 0.87 × 415 × 603.2\n1800 xu = 217,782\nxu = 120.99 mm" },
                { t: "Limiting neutral axis depth (Fe 415)", w: "xu,max = 0.48 × 400 = 192 mm" },
                { t: "Check the failure mode", w: "xu = 121.0 mm  <  xu,max = 192 mm\nUnder-reinforced — the steel has yielded, so the assumption in step 2 holds." },
                { t: "Lever arm", w: "z = d − 0.42 xu = 400 − 0.42 × 120.99 = 400 − 50.8 = 349.2 mm" },
                { t: "Moment of resistance", w: "Mu = 0.87 fy Ast z = 217,782 × 349.2\n   = 76.05 × 10⁶ N·mm" },
              ],
              ans: "Mu = 76.0 kNm. The section is under-reinforced and will fail with warning.",
            },
            { k: "note", t: "Notice that 0.87 fy Ast was computed once in step 2 and reused in step 6. That product is the total tension force in newtons, and carrying it through rather than recomputing it saves a step and removes a place to make an arithmetic slip." },
          ],
        },

        {
          n: "3.8",
          title: "Design: what steel does this moment need?",
          hi: "डिज़ाइन: इस मोमेंट के लिए कितना स्टील",
          blocks: [
            { k: "p", t: "Design runs the other way: the moment is known from analysis, the section is usually fixed by architecture or by a span/depth rule, and Ast is the unknown. The first move is always the same — find out whether the section can be singly reinforced at all." },
            { k: "steps", items: [
              "Fix d from D, cover, stirrup and an assumed bar diameter.",
              "Compute Mu,lim = 0.138 fck b d² (Fe 415). If Mu ≤ Mu,lim, a singly reinforced section will do.",
              "Solve Mu = 0.87 fy Ast d [1 − Ast fy /(b d fck)] as a quadratic in Ast, taking the smaller root.",
              "Check xu < xu,max, and verify by recomputing Mu from the Ast found.",
              "Choose bars giving at least that area, and check Ast,min and Ast,max.",
            ]},
            { k: "p", t: "The quadratic always has two roots. The larger one corresponds to a neutral axis below xu,max — an over-reinforced solution that is mathematically valid and physically unacceptable. <strong>Always take the smaller root.</strong>" },
            { k: "eq", expr: "Ast = (0.5 fck / fy) [1 − √(1 − 4.6 Mu / (fck b d²))] b d", where: [
              ["origin", "the smaller root of the Annex G quadratic, written in closed form (derived: 4.6 = 4/0.87, the 0.87 being fy/γm with γm = 1.15)"],
              ["check", "Example 3.2: 4.6 × 150×10⁶/(25 × 300 × 452²) = 0.450 → Ast = 0.5 × 25/415 × (1 − 0.741) × 300 × 452 = 1056 mm² ✔ (quadratic gave 1055.5)"],
            ] },
            { k: "p", t: "The closed form is what calculators and spreadsheets use. It also shows the limit at a glance: when 4.6 Mu/(fck b d²) approaches the value corresponding to Mu,lim, the square root shrinks and the steel climbs steeply — the design is running out of depth." },
            { k: "eg",
              title: "Example 3.2 — Design of a singly reinforced beam",
              given: "b = 300 mm, overall depth D = 500 mm, M25 concrete, Fe 415 steel, factored moment Mu = 150 kNm. Mild exposure, 30 mm cover, 8 mm stirrups, assume 20 mm main bars.",
              steps: [
                { t: "Effective depth", w: "d = 500 − 30 − 8 − 20/2 = 500 − 48 = 452 mm" },
                { t: "Is a singly reinforced section enough?", w: "Mu,lim = 0.138 fck b d² = 0.138 × 25 × 300 × 452²\n       = 0.138 × 25 × 300 × 204,304\n       = 211.5 × 10⁶ N·mm = 211.5 kNm\nMu = 150 kNm  <  211.5 kNm — singly reinforced will do." },
                { t: "Set up the quadratic in Ast", w: "150 × 10⁶ = 0.87 × 415 × Ast × 452 × [1 − Ast × 415 /(300 × 452 × 25)]\n150 × 10⁶ = 163,195 Ast × [1 − Ast /8168.7]\n150 × 10⁶ = 163,195 Ast − 19.978 Ast²" },
                { t: "Solve, taking the smaller root", w: "19.978 Ast² − 163,195 Ast + 150 × 10⁶ = 0\nAst = [163,195 − √(163,195² − 4 × 19.978 × 150×10⁶)] / (2 × 19.978)\n    = [163,195 − √(2.6633×10¹⁰ − 1.1987×10¹⁰)] / 39.956\n    = [163,195 − 121,021] / 39.956\n    = 1055.5 mm²" },
                { t: "Check the neutral axis", w: "xu = 0.87 × 415 × 1055.5 /(0.36 × 25 × 300)\n   = 381,090 / 2700 = 141.1 mm\nxu/d = 141.1/452 = 0.312  <  0.48  ✓ under-reinforced" },
                { t: "Verify the moment", w: "z = 452 − 0.42 × 141.1 = 452 − 59.3 = 392.7 mm\nMu = 381,090 × 392.7 = 149.7 × 10⁶ N·mm ≈ 150 kNm  ✓" },
                { t: "Choose bars", w: "4 bars of 20 mm = 4 × 314.16 = 1256.6 mm²  >  1055.5  ✓\n(3 of 20 + 1 of 16 = 942.5 + 201.1 = 1143.6 mm² is a tighter fit and also works.)" },
                { t: "Minimum and maximum steel (Cl. 26.5.1.1)", w: "Ast,min = 0.85 b d / fy = 0.85 × 300 × 452 / 415 = 277.7 mm²  ✓\nAst,max = 0.04 b D = 0.04 × 300 × 500 = 6000 mm²  ✓" },
              ],
              ans: "Provide 4 bars of 20 mm (1257 mm²) as tension reinforcement. xu/d = 0.31, comfortably under-reinforced.",
            },
            { k: "trap", t: "d was computed with an <em>assumed</em> 20 mm bar and 20 mm bars were provided, so the assumption held. If the design had ended with 25 mm bars, d would really be 449.5 mm, not 452, and the calculation would need one more pass. Check at the end that the bar you assumed is the bar you provided." },
          ],
        },

        {
          n: "3.9",
          title: "Minimum and maximum steel, and why both exist",
          hi: "न्यूनतम और अधिकतम स्टील",
          blocks: [
            { k: "p", t: "Cl. 26.5.1.1 sets both bounds for beams, and they guard against two completely different failures." },
            { k: "eq", expr: "Ast,min / (b d) = 0.85 / fy", where: [
              ["fy", "characteristic yield strength, N/mm² — for Fe 415 this gives 0.205% of b d"],
            ]},
            { k: "p", t: "The minimum exists because of a failure mode the equilibrium equation cannot see. Before the section cracks, the concrete carries the tension. If the steel provided is so small that its yield force is less than the tension the uncracked concrete was carrying, then the instant the first crack forms the steel is overwhelmed and snaps. The beam fails at the cracking moment, without warning, at a load far below its calculated capacity. Ast,min guarantees that the cracked section is stronger than the uncracked one." },
            { k: "eq", expr: "Ast,max = 0.04 b D", where: [
              ["D", "overall depth, mm — note that this limit uses D, not d"],
            ]},
            { k: "p", t: "The maximum has nothing to do with strength. Four per cent of the gross area is about as much steel as can be placed with enough room between bars for the aggregate to pass and for the concrete to be compacted around it (Cl. 26.3.2 fixes the spacing rules). Beyond it you are designing a beam that cannot actually be cast." },
            { k: "note", t: "Slabs have their own minimum in Cl. 26.5.2.1, stated as a percentage of gross area rather than of b d: 0.15% for Fe 250 and 0.12% for high-strength deformed bars. That is a shrinkage and temperature provision as much as a flexural one, and Chapter 7 uses it." },
          ],
        },

        {
          n: "3.10",
          title: "Reading the answer",
          hi: "उत्तर को पढ़ना",
          blocks: [
            { k: "p", t: "A number out of a design is not the end of the work. Four quick reads tell you whether the section you have just designed is a sensible one:" },
            { k: "list", items: [
              "<strong>xu/d between about 0.15 and 0.40</strong> — a comfortable, economical beam. Below 0.1 the section is much deeper than it needs to be; approaching 0.48 it is working right at the ductility limit and any future increase in load has no margin.",
              "<strong>Steel percentage between about 0.4% and 1.5% of b d</strong> — typical for beams. Above 2% the bars start to crowd and a deeper section is usually cheaper than the extra steel.",
              "<strong>Mu/Mu,lim</strong> — how much of the permitted capacity you are using. Around 0.7 is comfortable.",
              "<strong>Span/depth</strong> — Cl. 23.2.1 gives basic ratios of 7 for cantilevers, 20 for simply supported and 26 for continuous spans. A section that passes flexure but breaks these will deflect too much, and Chapter 10 handles that check properly.",
            ]},
            { k: "p", t: "Flexure is only the first of the checks a beam has to pass. The same section still has to be checked for shear and for development length (Chapter 5), for torsion where the loading produces it (Chapter 6), and for deflection and cracking in service (Chapter 10). A section designed for moment alone is not a designed section." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "rcc-4",
      n: 4,
      title: "Doubly Reinforced and Flanged Sections",
      hi: "डबली रीइन्फोर्स्ड और फ्लैंज्ड सेक्शन",
      blurb: "What to do when Mu exceeds Mu,lim, and why a beam cast with its slab is far stronger than the rectangle on the drawing suggests.",
      mins: 42,
      sections: [

        {
          n: "4.1",
          title: "When the section is not deep enough",
          hi: "जब सेक्शन काफ़ी गहरा न हो",
          blocks: [
            { k: "p", t: "Chapter 3 ended at a wall: if Mu exceeds Mu,lim, adding tension steel is not an option, because it pushes xu past xu,max and turns a ductile beam into a brittle one. There are three ways past that wall, and only one of them is the subject of this chapter." },
            { k: "list", items: [
              "<strong>Increase d.</strong> Always the cheapest if the space exists — capacity goes as d², so a 10% deeper beam is about 21% stronger for almost no extra steel.",
              "<strong>Increase fck.</strong> Mu,lim is proportional to fck, so M30 in place of M25 buys 20%. Modest, and it affects the whole pour.",
              "<strong>Add compression steel.</strong> The only option when the depth is fixed by a false ceiling, a door head, a floor-to-floor height, or by a beam that must match its neighbours.",
            ]},
            { k: "p", t: "Depth is fixed far more often than a textbook suggests, which is why doubly reinforced beams are common in practice rather than exceptional." },
          ],
        },

        {
          n: "4.2",
          title: "The two-part idea",
          hi: "दो हिस्सों वाला विचार",
          blocks: [
            { k: "p", t: "A doubly reinforced section is not analysed as a new kind of section. It is split into two sections that are each already understood, and their moments are added." },
            { k: "dia", id: "hb-rcc-doubly", cap: "The doubly reinforced section as the sum of a balanced singly reinforced section and a pure steel couple." },
            { k: "list", items: [
              "<strong>Part 1</strong> — a singly reinforced section working at exactly its limit: concrete in compression, steel Ast1 in tension, moment Mu,lim, neutral axis at xu,max.",
              "<strong>Part 2</strong> — a pure steel couple: compression steel Asc at the top, an equal and opposite extra tension steel Ast2 at the bottom, carrying the balance Mu2 = Mu − Mu,lim over a lever arm of (d − d′).",
            ]},
            { k: "p", t: "Part 1 is the most the concrete is allowed to do. Part 2 is everything above that, and the concrete takes no part in it at all — which is why the lever arm for Part 2 is the distance between the two layers of steel and nothing else." },
            { k: "eq", expr: "Mu = Mu,lim + Mu2   ·   Ast = Ast1 + Ast2", where: [
              ["d′", "distance from the extreme compression fibre to the centroid of the compression steel, mm"],
            ]},
            { k: "note", t: "The split is a bookkeeping device, not a physical description — the real section has one neutral axis and one set of strains. But because both parts obey equilibrium separately and their sum obeys it too, the answer is exact for the assumed stress block." },
          ],
        },

        {
          n: "4.3",
          title: "The stress in the compression steel",
          hi: "कम्प्रेशन स्टील का तनाव",
          blocks: [
            { k: "p", t: "This is where doubly reinforced design actually differs from singly, and where most errors are made. The compression steel sits at d′ from the top, not at the top fibre, so its strain is not 0.0035. Read it off the strain diagram at xu = xu,max:" },
            { k: "eq", expr: "εsc = 0.0035 (xu,max − d′) / xu,max", where: [
              ["εsc", "strain in the compression steel"],
            ]},
            { k: "p", t: "That strain then has to be converted to a stress using the <strong>design stress-strain curve</strong> of IS 456 Cl. 38.1(e), not by multiplying by Es. For Fe 250 (mild steel) the curve is bilinear and the conversion is trivial: elastic at Es until 0.87 fy, then flat. For Fe 415 and Fe 500 — cold-worked bars — the curve leaves the straight line at 0.8 fy and approaches 0.87 fy gradually, so between those two points the stress has to be interpolated. IS 456 Table A of Fig. 23 gives the salient points; for Fe 415 they are:" },
            { k: "list", items: [
              "strain 0.00144 → stress 288.8 N/mm² (0.80 × 0.87 fy)",
              "strain 0.00163 → stress 306.9 N/mm² (0.85)",
              "strain 0.00192 → stress 324.9 N/mm² (0.90)",
              "strain 0.00241 → stress 343.0 N/mm² (0.95)",
              "strain 0.00276 → stress 352.0 N/mm² (0.975)",
              "strain 0.00380 → stress 361.1 N/mm² (1.00 × 0.87 fy)",
            ]},
            { k: "trap", t: "fsc almost never equals 0.87 fy for Fe 415 or Fe 500. Reaching 0.87 fy would need a strain of 0.0038, and εsc at xu,max with a normal d′ comes out around 0.0025–0.0030. Assuming fsc = 0.87 fy overestimates the compression steel's contribution and leaves the section short — typically by 2 to 4 per cent, which is small but is on the unsafe side." },
            { k: "h", t: "The hole the compression steel occupies" },
            { k: "p", t: "The compression steel sits inside the concrete compression zone and displaces concrete that was already counted as carrying 0.446 fck. The net force the compression steel adds is therefore the difference:" },
            { k: "eq", expr: "Cs = (fsc − 0.446 fck) Asc", where: [
              ["fsc", "design stress in the compression steel at its actual strain, N/mm²"],
            ]},
            { k: "p", t: "For M25 the deduction is 0.446 × 25 = 11.15 N/mm² — around 3% of fsc. Small, routinely dropped in rough work, and carried through properly here." },
          ],
        },

        {
          n: "4.4",
          title: "Designing a doubly reinforced section",
          hi: "डबली रीइन्फोर्स्ड डिज़ाइन",
          blocks: [
            { k: "steps", items: [
              "Compute Mu,lim for the section. If Mu ≤ Mu,lim, stop — it is a singly reinforced problem.",
              "Mu2 = Mu − Mu,lim.",
              "Compute εsc from xu,max and d′, then read fsc off the design curve.",
              "Asc = Mu2 / [(fsc − 0.446 fck)(d − d′)].",
              "Ast1 = Mu,lim / [0.87 fy (d − 0.42 xu,max)].",
              "Ast2 = Asc (fsc − 0.446 fck) / (0.87 fy) — from horizontal equilibrium of the steel couple.",
              "Ast = Ast1 + Ast2, then choose bars for both faces and check the limits.",
            ]},
            { k: "eg",
              title: "Example 4.1 — Doubly reinforced beam",
              given: "b = 300 mm, D = 550 mm, d = 500 mm, d′ = 50 mm, M25 concrete, Fe 415 steel, factored moment Mu = 320 kNm.",
              steps: [
                { t: "Limiting moment", w: "Mu,lim = 0.138 × 25 × 300 × 500² = 0.138 × 25 × 300 × 250,000\n       = 258.75 × 10⁶ N·mm = 258.75 kNm\nMu = 320 > 258.75 — doubly reinforced is required." },
                { t: "Moment to be carried by the steel couple", w: "Mu2 = 320 − 258.75 = 61.25 kNm" },
                { t: "Strain in the compression steel", w: "xu,max = 0.48 × 500 = 240 mm\nεsc = 0.0035 × (240 − 50)/240 = 0.0035 × 190/240 = 0.002771" },
                { t: "Stress in the compression steel, by interpolation", w: "0.002771 lies just above 0.00276 (352.0), between it and 0.00380 (361.05)\nfsc = 352.0 + (361.05 − 352.0) × (0.002771 − 0.00276)/(0.00380 − 0.00276)\n    = 352.0 + 9.05 × 0.000011/0.00104 = 352.0 + 0.10\n    ≈ 352.1 N/mm²   (still short of 0.87 fy = 361.05)" },
                { t: "Compression steel", w: "Asc = 61.25 × 10⁶ / [(352.1 − 0.446×25)(500 − 50)]\n    = 61.25 × 10⁶ / [(352.1 − 11.15) × 450]\n    = 61.25 × 10⁶ / (340.95 × 450)\n    = 61.25 × 10⁶ / 153,428 = 399.2 mm²" },
                { t: "Tension steel, part 1", w: "z1 = d − 0.42 xu,max = 500 − 0.42 × 240 = 500 − 100.8 = 399.2 mm\nAst1 = 258.75 × 10⁶ /(0.87 × 415 × 399.2) = 258.75×10⁶ / 144,131\n     = 1795.2 mm²" },
                { t: "Tension steel, part 2", w: "Ast2 = Asc (fsc − 0.446 fck)/(0.87 fy) = 399.2 × 340.95 / 361.05\n     = 136,107 / 361.05 = 377.0 mm²" },
                { t: "Total tension steel", w: "Ast = 1795.2 + 377.0 = 2172.2 mm²" },
                { t: "Choose bars", w: "Compression: 2 bars of 16 mm = 402.1 mm²  >  399.2  ✓\nTension: 7 bars of 20 mm = 2199.1 mm²  >  2172.2  ✓\nAst,max = 0.04 × 300 × 550 = 6600 mm²  ✓" },
              ],
              ans: "Asc = 2 bars of 16 mm (402 mm²) at the top, Ast = 7 bars of 20 mm (2199 mm²) at the bottom. Seven 20 mm bars will need two layers in a 300 mm web, which raises the centroid — d must be rechecked and the design repeated if it has dropped materially.",
            },
            { k: "trap", t: "The closing remark in that example is the real lesson. Doubly reinforced beams are used when depth is short, so the tension steel is always heavy and rarely fits in one layer. Two layers move the centroid down from the soffit and reduce d — and reducing d is exactly what you were trying to avoid. Check bar arrangement before accepting the answer." },
            { k: "note", t: "<b>Correction (v34):</b> the earlier version of Example 4.1 interpolated between 0.00241 and 0.00276 although εsc = 0.002771 is already <i>past</i> 0.00276 — an extrapolation that gave fsc = 352.3. The correct bracket is 0.00276–0.00380, giving 352.1 N/mm². Asc changes from 399.0 to 399.2 mm² and the bars chosen are unchanged — but always check which pair of points actually brackets the strain. (Salient points re-derived: strain = stress/Es + the inelastic strain of IS 456 Fig. 23, e.g. 0.975 × 361.05/2×10⁵ + 0.001 = 0.00276.)" },
            { k: "note", t: "Compression bars must be held against buckling outwards. Cl. 26.5.3.2(c) requires stirrups at a spacing not more than 16 times the diameter of the smallest longitudinal bar in compression, and this applies to beams with compression steel, not only to columns." },
          ],
        },

        {
          n: "4.5",
          title: "Flanged sections: why a T-beam exists",
          hi: "फ्लैंज्ड सेक्शन: टी-बीम क्यों",
          blocks: [
            { k: "p", t: "A floor beam is not cast on its own. The slab and the beam are poured together and harden into one piece, so when the beam bends, part of the slab bends with it and contributes compression. Drawing the beam as an isolated rectangle throws that contribution away." },
            { k: "p", t: "In a mid-span sagging region the compression is at the top, where the slab is, so the section behaves as a T (or an L at the edge of a floor) with a wide compression flange and a narrow tension web. At a support in a continuous beam the moment reverses, the compression goes to the bottom, and the same physical member behaves as a plain rectangular section of width bw — the flange is in tension there and is ignored." },
            { k: "dia", id: "hb-rcc-tbeam", cap: "Effective flange width, and the two cases: neutral axis inside the flange, and neutral axis in the web." },
            { k: "h", t: "Effective width of flange" },
            { k: "p", t: "Not all of the slab helps equally. Compressive stress is highest directly over the web and falls off with distance — shear lag. Rather than model that, IS 456 Cl. 23.1.2 replaces the real varying stress with a uniform stress acting over an <em>effective width</em> bf that carries the same total force:" },
            { k: "eq", expr: "T-beam:  bf = L0/6 + bw + 6 Df", where: [
              ["L0", "distance between points of zero moment; for a simply supported beam it may be taken as the effective span (Cl. 23.1.2)"],
              ["bw", "breadth of the web, mm"],
              ["Df", "thickness of the flange — that is, the slab, mm"],
            ]},
            { k: "eq", expr: "L-beam:  bf = L0/12 + bw + 3 Df", where: [] },
            { k: "p", t: "In both cases bf must not be taken greater than the actual width available — the centre-to-centre distance to the next beam for a T, and half that plus the web for an L. Two adjacent beams cannot both claim the same strip of slab." },
            { k: "note", t: "<b>Isolated T- and L-beams</b> (a flange that is not part of a continuous slab — e.g. a precast T or a beam with a narrow kerb slab) get a separate, smaller expression in Cl. 23.1.2(c). Secondary sources quote that expression in different forms (one gives bw + L0/5 capped at bw + 4Df), so it is not reproduced here — read the clause itself before using it. Floor beams cast with the slab use the two formulas above (both confirmed by <a href=\"https://engineeringhulk.com/civil/rcc-design/t-beam-l-beam/\" target=\"_blank\" rel=\"noopener\">EngineeringHulk — T-beam &amp; L-beam</a>)." },
            { k: "note", t: "For a continuous beam L0 is the distance between points of contraflexure, which is roughly 0.7 times the effective span, so the flange is narrower than a simply supported beam of the same span would get." },
          ],
        },

        {
          n: "4.6",
          title: "The two cases, and which one you are in",
          hi: "दो स्थितियाँ",
          blocks: [
            { k: "p", t: "Everything about T-beam analysis turns on one question: does the neutral axis fall inside the flange, or below it in the web? The test is direct — work out the moment the section could carry if the whole flange were in compression and the neutral axis sat exactly at its underside:" },
            { k: "eq", expr: "Mu (at xu = Df) = 0.36 fck bf Df (d − 0.42 Df)", where: [] },
            { k: "list", items: [
              "<strong>If the applied Mu is smaller</strong>, the neutral axis is inside the flange. The compression zone is then a plain rectangle of width bf, and the section is designed exactly as a singly reinforced rectangular beam of that width. Nothing new is needed.",
              "<strong>If the applied Mu is larger</strong>, the neutral axis lies in the web. The compression zone is a T — the full flange plus a strip of web — and IS 456 Annex G.2.2 handles it, with the flange contribution capped at a depth yf when xu is large compared with Df.",
            ]},
            { k: "p", t: "In real floor construction the flange is wide — often six to eight times the web — so the first case is overwhelmingly the common one. A 2000 mm wide flange gives an enormous compression area, and a very shallow neutral axis is enough to balance any realistic amount of tension steel." },
            { k: "eg",
              title: "Example 4.2 — T-beam design",
              given: "Simply supported T-beam. Slab thickness Df = 120 mm, web bw = 300 mm, d = 500 mm, effective span 6000 mm, beams spaced 3000 mm centre to centre, M25 concrete, Fe 415 steel, factored moment Mu = 400 kNm.",
              steps: [
                { t: "Effective width of flange (Cl. 23.1.2)", w: "bf = L0/6 + bw + 6 Df = 6000/6 + 300 + 6 × 120\n   = 1000 + 300 + 720 = 2020 mm\nSpacing limit = 3000 mm  >  2020 mm  ✓ so bf = 2020 mm" },
                { t: "Which case? Moment at xu = Df", w: "Mu(xu=Df) = 0.36 × 25 × 2020 × 120 × (500 − 0.42 × 120)\n          = 0.36 × 25 × 2020 × 120 × 449.6\n          = 2,181,600 × 449.6\n          = 980.8 × 10⁶ N·mm = 980.8 kNm\nMu = 400 kNm  <  980.8 kNm — the neutral axis is inside the flange." },
                { t: "Design as a rectangular section of width 2020 mm", w: "400 × 10⁶ = 0.87 × 415 × Ast × 500 × [1 − Ast × 415/(2020 × 500 × 25)]\n400 × 10⁶ = 180,525 Ast × [1 − Ast/60,843]\n400 × 10⁶ = 180,525 Ast − 2.967 Ast²" },
                { t: "Solve, smaller root", w: "2.967 Ast² − 180,525 Ast + 400 × 10⁶ = 0\nAst = [180,525 − √(3.2589×10¹⁰ − 4.7472×10⁹)] / (2 × 2.967)\n    = [180,525 − √(2.7842×10¹⁰)] / 5.934\n    = [180,525 − 166,860] / 5.934\n    = 2302.9 mm²" },
                { t: "Check the neutral axis", w: "xu = 0.87 × 415 × 2302.9 /(0.36 × 25 × 2020)\n   = 831,462 / 18,180 = 45.7 mm\n45.7 mm  <  Df = 120 mm  ✓ the flange assumption holds\nxu/d = 0.091  <  0.48  ✓ under-reinforced" },
                { t: "Verify the moment", w: "z = 500 − 0.42 × 45.7 = 500 − 19.2 = 480.8 mm\nMu = 831,462 × 480.8 = 399.8 × 10⁶ N·mm ≈ 400 kNm  ✓" },
                { t: "Choose bars", w: "5 bars of 25 mm = 5 × 490.87 = 2454.4 mm²  >  2302.9  ✓\nIn a 300 mm web, five 25 mm bars need two layers — recheck d." },
              ],
              ans: "Ast = 2303 mm²; provide 5 bars of 25 mm (2454 mm²). xu = 46 mm, well inside the 120 mm flange.",
            },
            { k: "trap", t: "xu/d came out at 0.09, which in a rectangular beam would say the section is badly oversized. In a T-beam it says nothing of the sort — the flange is so wide that a shallow compression zone is all that is needed. Judge a T-beam by the tension steel percentage on bw d, not by xu/d." },
          ],
        },

        {
          n: "4.7",
          title: "Neutral axis in the web",
          hi: "न्यूट्रल एक्सिस वेब में",
          blocks: [
            { k: "p", t: "This is the less common case — a narrow flange, a thin slab, or a heavily loaded beam. The compression zone is now made of two pieces and their contributions are added:" },
            { k: "list", items: [
              "The <strong>web</strong> portion, width bw, full depth xu, carrying 0.36 fck bw xu at 0.42 xu from the top.",
              "The <strong>overhanging flange</strong>, width (bf − bw), carrying 0.446 fck (bf − bw) yf at yf/2 from the top.",
            ]},
            { k: "eq", expr: "Mu = 0.36 fck bw xu (d − 0.42 xu) + 0.446 fck (bf − bw) yf (d − yf/2)", where: [
              ["yf", "the depth of flange assumed to be at the full stress 0.446 fck"],
            ]},
            { k: "p", t: "The subtlety is yf. If the flange is thin relative to xu, the whole of it is at or near the full stress and yf = Df. But if the flange is deep compared with the neutral axis, the lower part of the flange sits in the parabolic region of the stress block at reduced stress, and taking the whole flange at 0.446 fck would overstate the compression. Cl. G-2.2 handles this with a switch:" },
            { k: "eq", expr: "If Df/d ≤ 0.2 :  yf = Df      If Df/d > 0.2 :  yf = 0.15 xu + 0.65 Df  (but not more than Df)", where: [] },
            { k: "note", t: "The 0.2 threshold is a practical dividing line, not a physical one. For most floors, a 120–150 mm slab with a 450–600 mm deep beam gives Df/d well under 0.2, so yf = Df and the reduction never applies. It matters for shallow, wide members." },
            { k: "p", t: "The limiting case follows the same rule as before: put xu = xu,max into the expression and you have Mu,lim for the flanged section. If the applied moment exceeds even that, the section needs compression steel — a doubly reinforced T-beam, which is the two-part idea of §4.2 applied to the flanged section of this one." },
          ],
        },

        {
          n: "4.8",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Mu ≤ Mu,lim → singly reinforced. Mu > Mu,lim with depth fixed → add compression steel and split the moment in two.",
              "fsc must be read from the design stress-strain curve at the actual εsc, and it will not be 0.87 fy for Fe 415 or Fe 500.",
              "Subtract 0.446 fck from fsc for the concrete the compression bars displace.",
              "A beam cast with a slab is a T-beam in sagging regions and a rectangle of width bw in hogging regions — the same member, two different sections.",
              "Test whether the neutral axis is inside the flange before doing anything else; if it is, the problem is an ordinary rectangular design of width bf.",
              "Every flexural design still owes checks for shear, bond, deflection and cracking before it is finished.",
            ]},
            { k: "p", t: "Chapter 5 takes the section that has just been designed and asks what happens near the supports, where the moment is small and the shear is large — and why the bars that were just calculated will pull straight out of the concrete unless they are given enough length to develop their strength." },
          ],
        },
      ],
    }

  );
})();
