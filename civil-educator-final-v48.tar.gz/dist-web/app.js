/* ============================================================
   CIVIL EDUCATOR — application engine
   Router · search index · views · exam · library · admin · AI
   ============================================================ */
(function () {
  "use strict";

  /* ------------------------------------------------------------ helpers */
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

  const STATUS = {
    current: { dot: "🟢", label: "Current", cls: "ok" },
    check: { dot: "🟡", label: "Check latest edition", cls: "warn" },
    withdrawn: { dot: "🔴", label: "Withdrawn / superseded", cls: "bad" },
  };

  /* ------------------------------------------------------------ storage */
  const KEY = "ccl.state.v1";
  const defaults = () => ({
    lang: "en",
    profile: { level: null, name: "" },
    saved: { code: [], topic: [], table: [], formula: [], mcq: [], calc: [] },
    recents: [],
    stats: { viewedCodes: [], viewedTopicsByCat: {}, answeredByCat: {}, bestQuiz: {}, calcRuns: 0, dailyDone: [], answered: 0, correct: 0, topicsRead: [] },
    views: {},
    notes: {},
    reports: [],
    project: { name: "My project", items: [] },
    theme: "",
    navOpen: [],
    navClosed: [],
    onboarded: false,
    admin: { codes: [], topics: [], tables: [], formulas: [], mcqs: [], categories: [], edits: {}, pin: "civil2024", unlocked: false },
  });
  let S = defaults();
  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) S = Object.assign(defaults(), JSON.parse(raw));
      S.saved = Object.assign(defaults().saved, S.saved || {});
      S.stats = Object.assign(defaults().stats, S.stats || {});
      S.admin = Object.assign(defaults().admin, S.admin || {});
    } catch (e) { S = defaults(); }
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { }
    if (window.AUTH) AUTH.onSave();
  }

  /* ------------------------------------------------ merged data accessors */
  let CODES = [], TOPICS = [], TABLES = [], FORMULAS = [], MCQS = [], CATS = [];
  function rebuild() {
    const applyEdits = (arr) => arr.map((x) => (S.admin.edits[x.id] ? Object.assign({}, x, S.admin.edits[x.id]) : x));
    CATS = DB.categories.concat(S.admin.categories || []);
    CODES = applyEdits(DB.codes.concat(S.admin.codes || []));
    TOPICS = applyEdits(DB.topics.concat(S.admin.topics || []));
    TABLES = applyEdits(DB.tables.concat(S.admin.tables || []));
    FORMULAS = applyEdits(DB.formulas.concat(S.admin.formulas || []));
    MCQS = DB.mcqs.concat(S.admin.mcqs || []);
    buildIndex();
  }
  const codeById = (id) => CODES.find((c) => c.id === id);
  const topicById = (id) => TOPICS.find((t) => t.id === id);
  const tableById = (id) => TABLES.find((t) => t.id === id);
  const formulaById = (id) => FORMULAS.find((f) => f.id === id);
  const catById = (id) => CATS.find((c) => c.id === id);
  const codeLabel = (c) => c.number + (c.year && c.year !== "—" && c.year !== "various" ? ":" + c.year : "");

  /* ------------------------------------------------------- search engine */
  const SYN = {
    rcc: "reinforced concrete cement", ld: "development length", cover: "nominal cover",
    bbs: "bar bending schedule reinforcement", sbc: "safe bearing capacity", ndt: "non destructive testing",
    tmt: "high strength deformed bar steel reinforcement hysd", psc: "prestressed concrete",
    msa: "million standard axles traffic", cbr: "california bearing ratio subgrade",
    spt: "standard penetration test", opc: "ordinary portland cement",
    seismic: "earthquake", quake: "earthquake seismic", steel: "structural steel reinforcement",
    footing: "foundation shallow", pile: "pile foundation deep foundation",
    stirrup: "shear reinforcement link", slump: "workability",
    "mix design": "mix proportioning", ductile: "ductile detailing seismic",
    brick: "masonry brickwork", plaster: "plastering mortar",
    survey: "surveying levelling traverse", bar: "reinforcement steel",
    wind: "wind load", quantity: "estimation measurement",
  };
  let INDEX = [];
  /* Keep this regex in ASCII escapes (the Devanagari block).
     A literal Devanagari range here breaks the whole app if the server ever
     serves this file without charset=utf-8: the bytes decode as latin-1 and
     the range becomes invalid, throwing before anything renders. */
  function norm(s) { return String(s || "").toLowerCase().replace(/[^a-z0-9\u0900-\u097F ]+/g, " ").replace(/\s+/g, " ").trim(); }
  function buildIndex() {
    INDEX = [];
    CODES.forEach((c) => {
      const g = (DB.guides || {})[c.id];
      const gtext = g ? [g.what, g.use, (g.inside || []).join(" "),
        (g.key || []).map((k) => k.join(" ")).join(" "), (g.watch || []).join(" ")].join(" ") : "";
      INDEX.push({
        type: "code", id: c.id, title: codeLabel(c), sub: c.title, cat: c.cat,
        hay: norm([c.number, c.number.replace(/IS\s*/i, ""), c.title, c.summary,
          (c.keywords || []).join(" "), (c.contents || []).join(" "), c.docType, gtext].join(" ")),
        boost: (c.popular ? 6 : 0) + (g ? 4 : 0),
      });
    });
    TOPICS.forEach((t) => {
      const c = codeById(t.code);
      const h = (DB.hindi || {})[t.id];
      const htext = h ? [h.what, h.why, h.eg, h.tip].join(" ") : "";
      INDEX.push({
        type: "topic", id: t.id, title: t.title, sub: (c ? codeLabel(c) + " · " : "") + t.ref, cat: c ? c.cat : "",
        hay: norm([t.title, t.hi, t.ref, t.what, t.why, t.example, t.tip, htext,
          (t.keywords || []).join(" "), c ? c.number : ""].join(" ")),
        boost: t.importance === "high" ? 4 : 1,
      });
    });
    TABLES.forEach((t) => INDEX.push({
      type: "table", id: t.id, title: t.title, sub: t.ref, cat: t.code ? (codeById(t.code) || {}).cat : "",
      hay: norm([t.title, t.ref, t.note, (t.cols || []).join(" "), (t.rows || []).map((r) => r.join(" ")).join(" ")].join(" ")), boost: 2,
    }));
    FORMULAS.forEach((f) => INDEX.push({
      type: "formula", id: f.id, title: f.title, sub: f.ref,
      hay: norm([f.title, f.expr, f.ref, f.example, (f.vars || []).map((v) => v.join(" ")).join(" ")].join(" ")), boost: 2,
    }));
    CALC.list.forEach((c) => INDEX.push({
      type: "calc", id: c.id, title: c.name, sub: "Calculator · " + c.ref,
      hay: norm([c.name, c.ref, c.formula, (c.inputs || []).map((i) => i.label).join(" ")].join(" ")), boost: 1,
    }));
    Object.keys(DB.clauses || {}).forEach((cid) => {
      const c = codeById(cid); if (!c) return;
      (DB.clauses[cid] || []).forEach((sec) => (sec.items || []).forEach((it) => {
        INDEX.push({
          type: "clause", id: cid + "::" + it.n, title: "Cl. " + it.n + " — " + it.t,
          sub: codeLabel(c) + " · " + sec.sec, cat: c.cat, topic: it.topic, tbl: it.tbl, code: cid,
          hay: norm([it.n, it.t, c.number, sec.sec, "clause"].join(" ")), boost: it.topic ? 5 : 2,
        });
      }));
    });
    (DB.materials || []).forEach((m) => INDEX.push({
      type: "materials", id: m.id, title: m.name, sub: "Material · " + m.blurb,
      hay: norm([m.name, m.hi, m.blurb, m.intro,
        (m.types || []).map((x) => x.n + " " + x.u + " " + x.w).join(" "),
        (m.tests || []).map((x) => x.n + " " + x.w).join(" "),
        (m.field || []).map((x) => x.t + " " + x.w).join(" "),
        (m.problems || []).map((x) => x.t + " " + x.w).join(" "),
        (m.props && m.props.rows || []).map((r) => r.join(" ")).join(" ")].join(" ")),
      boost: 16,
    }));
    (DB.examples || []).forEach((x) => INDEX.push({
      type: "example", id: x.id, title: x.title, sub: "Solved example · " + x.cat,
      hay: norm([x.title, x.given, x.cat, x.answer, (x.steps || []).map((s) => s.t + " " + s.w + " " + s.r).join(" ")].join(" ")), boost: 3,
    }));
    MCQS.forEach((q) => INDEX.push({
      type: "mcq", id: q.id, title: q.q, sub: q.ref,
      hay: norm([q.q, q.exp, q.ref, (q.opts || []).join(" ")].join(" ")), boost: 0,
    }));
  }
  function expand(q) {
    let t = norm(q);
    Object.keys(SYN).forEach((k) => { if (t.includes(k)) t += " " + SYN[k]; });
    const isNum = /^\d{2,5}$/.test(q.trim());
    if (isNum) t += " is " + q.trim();
    return t;
  }
  function searchAll(q, limit) {
    const raw = norm(q);
    if (!raw) return [];
    const full = expand(q);
    const words = Array.from(new Set(full.split(" "))).filter((w) => w.length > 1);
    const scored = [];
    INDEX.forEach((e) => {
      let sc = 0;
      if (e.hay.includes(raw)) sc += 24;
      if (norm(e.title).startsWith(raw)) sc += 20;
      if (norm(e.title).includes(raw)) sc += 12;
      words.forEach((w) => {
        if (!e.hay.includes(w)) return;
        sc += 3;
        if (norm(e.title).includes(w)) sc += 5;
        if (new RegExp("(^| )" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "( |$)").test(e.hay)) sc += 2;
      });
      if (sc > 0) scored.push({ e, sc: sc + e.boost + (e.type === "code" ? 4 : e.type === "topic" ? 3 : 0) });
    });
    scored.sort((a, b) => b.sc - a.sc);
    return scored.slice(0, limit || 60).map((x) => x.e);
  }

  /* ---------------------------------------------------------------- i18n */
  const STR = {
    en: {
      home: "Home", codes: "All Codes", search: "Search", calc: "Calculators", profile: "Profile",
      exam: "Exam Mode", library: "My Library", tables: "Tables & Values", formulas: "Formulas",
      admin: "Admin", ai: "Ask Civil AI", about: "About & Sources",
      searchPh: "Search IS Code, clause, topic or keyword…",
      hero1: "Civil Engineering Library",
      hero2: "Find IS Codes, clauses, formulas, standards and study resources — all in one place.",
      explore: "Browse by category", popular: "Popular codes", study: "Study Today",
      continue: "Continue Learning", save: "Save", saved: "Saved", view: "View Code",
      what: "What is it?", why: "Why is it important?", ref: "Code reference", eg: "Example", tip: "Remember",
      related: "Related Codes", contents: "Contents", source: "Official source", info: "Information",
      recommended: "Recommended for you", progress: "Learning progress",
      subjects: "Subjects", handbooks: "Handbooks",
    },
    hi: {
      home: "होम", codes: "सभी कोड", search: "खोजें", calc: "कैलकुलेटर", profile: "प्रोफ़ाइल",
      exam: "परीक्षा मोड", library: "मेरी लाइब्रेरी", tables: "टेबल एवं मान", formulas: "सूत्र",
      admin: "एडमिन", ai: "सिविल AI से पूछें", about: "स्रोत एवं जानकारी",
      searchPh: "IS कोड, क्लॉज़, विषय या कीवर्ड खोजें…",
      hero1: "सिविल इंजीनियरिंग लाइब्रेरी",
      hero2: "IS कोड, क्लॉज़, सूत्र, मानक और अध्ययन सामग्री — सब एक जगह।",
      explore: "श्रेणी से खोजें", popular: "लोकप्रिय कोड", study: "आज का अध्ययन",
      continue: "जहाँ छोड़ा था", save: "सेव", saved: "सेव किया", view: "कोड देखें",
      what: "यह क्या है?", why: "यह क्यों ज़रूरी है?", ref: "कोड संदर्भ", eg: "उदाहरण", tip: "याद रखें",
      related: "संबंधित कोड", contents: "विषय-सूची", source: "आधिकारिक स्रोत", info: "जानकारी",
      recommended: "आपके लिए सुझाव", progress: "अध्ययन प्रगति",
      subjects: "विषय", handbooks: "हैंडबुक",
    },
  };
  const t = (k) => (STR[S.lang] && STR[S.lang][k]) || STR.en[k] || k;

  /* ------------------------------------------------------- Hindi bodies
     Topic bodies are written twice: English in the data-topics files, and
     Hindi in data-hindi.js keyed by topic id. Hindi is being filled in
     batch by batch, so a topic may have a Hindi title and an English body.
     body() falls back to English silently; hiNotice() says so once, at the
     top of the page, rather than leaving the reader to wonder. */
  const EN_KEY = { what: "what", why: "why", eg: "example", tip: "tip" };
  function hiBody(tp) {
    return S.lang === "hi" ? (DB.hindi || {})[tp.id] : null;
  }
  function body(tp, k) {
    const h = hiBody(tp);
    return (h && h[k]) || tp[EN_KEY[k]];
  }
  function hiNotice(tp) {
    if (S.lang !== "hi" || hiBody(tp)) return "";
    return `<div class="callout-note">इस विषय की व्याख्या अभी अंग्रेज़ी में ही उपलब्ध है — हिन्दी रूपांतर बैच दर बैच जोड़ा जा रहा है। संदर्भ, सूत्र और टेबल दोनों भाषाओं में एक ही हैं।</div>`;
  }
  function hiCount() {
    const ids = Object.keys(DB.hindi || {});
    return DB.topics.filter((tp) => ids.indexOf(tp.id) !== -1).length;
  }

  /* ------------------------------------------------------------ tracking */
  function track(type, id, title, sub) {
    S.recents = S.recents.filter((r) => !(r.type === type && r.id === id));
    S.recents.unshift({ type, id, title, sub, at: Date.now() });
    S.recents = S.recents.slice(0, 20);
    S.views[type + ":" + id] = (S.views[type + ":" + id] || 0) + 1;
    if (type === "code" && !S.stats.viewedCodes.includes(id)) S.stats.viewedCodes.push(id);
    if (type === "topic") {
      if (!S.stats.topicsRead.includes(id)) S.stats.topicsRead.push(id);
      const tp = topicById(id), c = tp && codeById(tp.code);
      if (c) S.stats.viewedTopicsByCat[c.cat] = (S.stats.viewedTopicsByCat[c.cat] || 0) + 1;
    }
    save();
  }
  const isSaved = (type, id) => (S.saved[type] || []).includes(id);
  function toggleSave(type, id) {
    S.saved[type] = S.saved[type] || [];
    const i = S.saved[type].indexOf(id);
    if (i >= 0) S.saved[type].splice(i, 1); else S.saved[type].push(id);
    S.stats.savedCount = Object.keys(S.saved).reduce((a, k) => a + S.saved[k].length, 0);
    save();
  }
  function progressPct() {
    const total = TOPICS.length + MCQS.length;
    const done = (S.stats.topicsRead || []).length + (S.stats.answered || 0);
    return Math.min(100, Math.round((done / Math.max(1, total)) * 100));
  }
  function earnedBadges() {
    const st = Object.assign({}, S.stats, { savedCount: S.stats.savedCount || 0 });
    return DB.badges.map((b) => ({ b, got: (() => { try { return !!b.test(st); } catch (e) { return false; } })() }));
  }

  /* ------------------------------------------------------------ fragments */
  function statusPill(st) {
    const s = STATUS[st] || STATUS.check;
    return `<span class="pill ${s.cls}"><span aria-hidden="true">${s.dot}</span>${s.label}</span>`;
  }
  function saveBtn(type, id) {
    const on = isSaved(type, id);
    return `<button class="btn ghost sm star${on ? " on" : ""}" data-act="save" data-type="${type}" data-id="${esc(id)}" aria-pressed="${on}">${on ? "★ " + t("saved") : "☆ " + t("save")}</button>`;
  }
  function codeCard(c) {
    const cat = catById(c.cat);
    return `<article class="card code-card stat-${c.status}">
      <div class="cc-head">
        <a class="cc-no mono" href="#/code/${c.id}">${esc(codeLabel(c))}</a>
        <span class="doctype">${esc(c.docType)}</span>
      </div>
      <a class="cc-title" href="#/code/${c.id}">${esc(c.title)}</a>
      <div class="cc-meta">${cat ? `<a class="tag" href="#/cat/${cat.id}">${cat.icon} ${esc(cat.name)}</a>` : ""}${statusPill(c.status)}${(DB.guides || {})[c.id] ? `<span class="tag guide-tag">📘 Guide</span>` : ""}</div>
      <div class="cc-actions">
        <a class="btn sm" href="#/code/${c.id}">${t("view")}</a>
        ${saveBtn("code", c.id)}
      </div>
    </article>`;
  }
  /* Most refs already open with the code label ("IS 456:2000, Cl. 6.1"),
     so prefixing the label again printed "IS 456:2000 → IS 456:2000, Cl. 6.1"
     on every row. Show the prefix only when the ref does not carry it. */
  function refLine(c, ref) {
    const r = String(ref || "");
    if (!c) return esc(r);
    const label = codeLabel(c);
    if (r.indexOf(label) === 0 || r.indexOf(c.number) === 0) return esc(r);
    return esc(label) + " \u2192 " + esc(r);
  }
  function topicRow(tp) {
    const c = codeById(tp.code);
    return `<a class="row" href="#/topic/${tp.id}">
      <div class="row-main">
        <div class="row-title">${esc(S.lang === "hi" && tp.hi ? tp.hi : tp.title)}${tp.importance === "high" ? '<span class="imp" title="High importance">●</span>' : ""}${(DB.diagrams || {})[tp.id] ? '<span class="has-dia" title="Includes a diagram">📐</span>' : ""}${S.lang === "hi" && !(DB.hindi || {})[tp.id] ? '<span class="hi-dot" title="व्याख्या अंग्रेज़ी में">EN</span>' : ""}</div>
        <div class="row-sub mono">${refLine(c, tp.ref)}</div>
      </div><span class="chev">→</span></a>`;
  }
  function tableBlock(tb) {
    return `<div class="tbl-wrap">
      <table class="data"><thead><tr>${tb.cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead>
      <tbody>${tb.rows.map((r) => `<tr>${r.map((cell, i) => `<td${i === 0 ? ' class="first"' : ""}>${esc(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>
    </div>`;
  }
  function srcLine(ref) { return `<p class="src"><span class="src-k">Source</span> ${esc(ref)}</p>`; }
  /* Categories carry a Hindi name; use it wherever the name is shown so the
     sidebar, the home grid and the landing pages all agree. */
  const catName = (c) => (S.lang === "hi" && c.hi ? c.hi : c.name);

  function sectionHead(title, extra) {
    return `<div class="sec-head"><h2>${esc(title)}</h2>${extra || ""}</div>`;
  }
  function emptyState(msg, cta) {
    return `<div class="empty"><p>${esc(msg)}</p>${cta || ""}</div>`;
  }

  /* ================================================================ VIEWS */
  const V = {};

  V.home = function () {
    const pop = CODES.filter((c) => c.popular);
    const recs = S.profile.level ? DB.recommendations[S.profile.level] : null;
    const daily = dailySet();
    const recents = S.recents.slice(0, 5);
    return `
    <section class="hero">
      <p class="eyebrow mono">IS Codes • Standards • Clauses • Formulas • Study</p>
      <h1>${t("hero1")}</h1>
      <p class="lede">${t("hero2")}</p>
      ${searchBox()}
      <div class="chips">
        ${["IS 456", "Nominal cover", "Development length", "IS 800", "Pile foundation", "Soil classification", "Brick strength"]
        .map((x) => `<button class="chip" data-act="q" data-q="${esc(x)}">${esc(x)}</button>`).join("")}
      </div>
    </section>

    ${recents.length ? `<section>${sectionHead(t("continue"))}
      <div class="rows">${recents.map((r) => `<a class="row" href="#/${r.type}/${r.id}">
        <div class="row-main"><div class="row-title">${esc(r.title)}</div><div class="row-sub mono">${esc(r.sub || "")}</div></div><span class="chev">→</span></a>`).join("")}</div>
    </section>` : ""}

    ${/* Subject first. A student arrives thinking "Concrete Technology,
          unit 3", not "IS 456" — so the first thing under the search box
          is their subject list, and the code categories stay further down
          for when they already know the code they want. */""}
    <section>${sectionHead((S.lang === "hi" ? "🎓 विषय से पढ़ें" : "🎓 Study by subject"),
      `<a class="more" href="#/subjects">${S.lang === "hi" ? "सभी विषय" : "All subjects"} →</a>`)}
      <div class="grid subs">${(DB.subjects || []).map((sub) => {
        const st = subjectStats(sub);
        return `<a class="card sub-tile" href="#/subject/${sub.id}">
          <span class="sub-ico" aria-hidden="true">${sub.icon}</span>
          <span class="sub-name">${esc(S.lang === "hi" && sub.hi ? sub.hi : sub.name)}</span>
          <span class="sub-sem mono">${esc(sub.sem)}</span>
          <span class="cat-count mono">${st.covered}/${st.units} units · ${st.mcqs} MCQ</span></a>`;
      }).join("")}</div>
    </section>

    <section>${sectionHead("🎓 Study & practice", `<a class="more" href="#/exam">Exam mode →</a>`)}
      <div class="grid three">
        <a class="card study" href="#/exam/daily">
          <span class="study-n mono">5</span><span class="study-l">Today's MCQs</span>
          <span class="study-s">${S.stats.dailyDone.includes(todayKey()) ? "Completed today ✓" : "Five questions, mixed codes"}</span></a>
        <a class="card study" href="#/exam/revision/${daily.rev.id}">
          <span class="study-n mono">${daily.rev.points.length}</span><span class="study-l">Quick revision</span>
          <span class="study-s">${esc(daily.rev.title.replace(/^\d+\s+Important Points from\s*/, ""))}</span></a>
        <a class="card study" href="#/examples">
          <span class="study-n mono">${(DB.examples || []).length}</span><span class="study-l">Solved examples</span>
          <span class="study-s">Full design problems, step by step, clause by clause</span></a>
        <a class="card study" href="#/formulas">
          <span class="study-n mono">${FORMULAS.length}</span><span class="study-l">Formulas</span>
          <span class="study-s">With variables, source clause and a worked example</span></a>
        <a class="card study" href="#/paths">
          <span class="study-n mono">${(DB.paths || []).length}</span><span class="study-l">Study paths</span>
          <span class="study-s">The library ordered for GATE, SSC JE, AE or diploma</span></a>
        <a class="card study" href="#/checklists">
          <span class="study-n mono">${(DB.checklists || []).length}</span><span class="study-l">Site checklists</span>
          <span class="study-s">What to check before the concrete arrives</span></a>
      </div>
    </section>

    <section>${sectionHead(t("explore"), `<a class="more" href="#/codes">All ${CODES.length} codes →</a>`)}
      <div class="grid cats">
        ${CATS.map((c) => `<a class="card cat-card" href="#/cat/${c.id}">
          <span class="cat-ico" aria-hidden="true">${c.icon}</span>
          <span class="cat-name">${esc(catName(c))}</span>
          <span class="cat-blurb">${esc(c.blurb || "")}</span>
          <span class="cat-count mono">${CODES.filter((x) => x.cat === c.id).length} entries</span>
        </a>`).join("")}
      </div>
    </section>

    <section>${sectionHead("🔥 " + t("popular"))}
      <div class="grid codes">${pop.map(codeCard).join("")}</div>
    </section>

    ${/* The same five groups the Materials page and the sidebar use, so the
          three places never disagree about how materials are organised. */""}
    <section>${sectionHead("🧱 Materials", `<a class="more" href="#/materials">All ${(DB.materials || []).length} guides →</a>`)}
      <div class="grid three">${(DB.matCategories || []).map((cat) => {
        const n = (DB.materials || []).filter((m) => (DB.matCatOf || {})[m.id] === cat.id).length;
        return `<a class="card cat-card" href="#/matcat/${cat.id}">
          <span class="cat-ico" aria-hidden="true">${cat.icon}</span>
          <span class="cat-name">${esc(catName(cat))}</span>
          <span class="cat-blurb">${esc(cat.blurb)}</span>
          <span class="cat-count mono">${n} guide${n === 1 ? "" : "s"}</span></a>`;
      }).join("")}</div>
    </section>

    ${recs ? `<section>${sectionHead(t("recommended") + " — " + recs.label)}
      <div class="grid codes">${recs.codes.map((id) => codeById(id)).filter(Boolean).map(codeCard).join("")}</div>
      <div class="rows mt">${recs.topics.map((id) => topicById(id)).filter(Boolean).map(topicRow).join("")}</div>
    </section>`
        : `<section class="card prompt"><h2>Personalise this library</h2>
      <p>Tell us what you are studying and the home screen will recommend the codes and topics that matter to you.</p>
      <a class="btn" href="#/profile">Choose your course →</a></section>`}

    <section class="notice">
      <p><strong>Educational reference.</strong> ${esc(DB.meta.disclaimer)}</p>
      <a class="more" href="#/about">Sources and how this library is built →</a>
    </section>`;
  };

  function searchBox(val) {
    return `<div class="search-wrap">
      <form class="searchbar" data-act="searchform" role="search">
        <span class="s-ico" aria-hidden="true">🔍</span>
        <input id="q" type="search" autocomplete="off" placeholder="${esc(t("searchPh"))}" value="${esc(val || "")}"
          aria-label="Search the code library" aria-autocomplete="list" aria-controls="live">
        <button class="btn" type="submit">${t("search")}</button>
      </form>
      <div id="live" class="live" hidden></div>
    </div>`;
  }

  /* Instant results as the student types — clause numbers resolve directly. */
  const TYPE_ICON = { code: "📚", topic: "📄", table: "📊", formula: "∑", calc: "🧮", mcq: "❓", example: "✏️", clause: "§", materials: "🧱" };
  function hrefFor(e) {
    if (e.type === "mcq") return "#/exam";
    if (e.type === "clause") return e.topic ? "#/topic/" + e.topic : e.tbl ? "#/table/" + e.tbl : "#/clauses/" + e.code;
    return "#/" + e.type + "/" + e.id;
  }
  function liveSearch(q) {
    const box = $("#live");
    if (!box) return;
    const raw = q.trim();
    if (raw.length < 2) { box.hidden = true; box.innerHTML = ""; return; }
    let hits = searchAll(raw, 8);
    /* a clause number like 26.4.2 should land on the topic that carries it */
    if (/^\d+(\.\d+)+$/.test(raw)) {
      const cl = TOPICS.filter((tp) => (tp.ref || "").replace(/\s/g, "").includes(raw));
      hits = cl.map((tp) => INDEX.find((e) => e.type === "topic" && e.id === tp.id)).filter(Boolean).concat(hits);
    }
    hits = hits.filter((h, i, a) => a.findIndex((x) => x.type === h.type && x.id === h.id) === i).slice(0, 8);
    if (!hits.length) { box.hidden = true; box.innerHTML = ""; return; }
    box.innerHTML = hits.map((e) => `<a class="live-row" href="${hrefFor(e)}" data-act="closelive">
        <span class="live-ico" aria-hidden="true">${TYPE_ICON[e.type] || "•"}</span>
        <span class="live-main"><span class="live-t">${esc(e.title)}</span><span class="live-s mono">${esc(e.sub || "")}</span></span>
      </a>`).join("") + `<button class="live-all" data-act="q" data-q="${esc(raw)}">See all results for “${esc(raw)}” →</button>`;
    box.hidden = false;
  }

  V.codes = function (params) {
    const q = params.q || "";
    const cat = params.cat || "";
    const yr = params.yr || "";
    const sort = params.sort || "num";
    let list = CODES.slice();
    if (cat) list = list.filter((c) => c.cat === cat);
    if (yr) list = list.filter((c) => String(c.year).includes(yr));
    if (q) { const ids = searchAll(q, 300).filter((e) => e.type === "code").map((e) => e.id); list = list.filter((c) => ids.includes(c.id)); }
    if (sort === "az") list.sort((a, b) => a.title.localeCompare(b.title));
    else if (sort === "year") list.sort((a, b) => String(b.year).localeCompare(String(a.year)));
    else if (sort === "views") list.sort((a, b) => (S.views["code:" + b.id] || 0) - (S.views["code:" + a.id] || 0));
    else list.sort((a, b) => a.number.localeCompare(b.number, undefined, { numeric: true }));

    const years = Array.from(new Set(CODES.map((c) => String(c.year).match(/\d{4}/) ? String(c.year).match(/\d{4}/)[0] : null).filter(Boolean))).sort().reverse();
    const fav = (S.saved.code || []).map(codeById).filter(Boolean);
    const recent = S.recents.filter((r) => r.type === "code").slice(0, 6).map((r) => codeById(r.id)).filter(Boolean);

    return `<header class="page-head"><h1>${t("codes")}</h1><p class="lede">${CODES.length} codes, guidelines and specifications indexed across ${CATS.length} categories.</p></header>
    ${searchBox(q)}
    <div class="filters" data-act="filters">
      <label>Category
        <select id="f-cat">${['<option value="">All categories</option>'].concat(CATS.map((c) => `<option value="${c.id}"${c.id === cat ? " selected" : ""}>${c.icon} ${esc(c.name)}</option>`)).join("")}</select></label>
      <label>Year
        <select id="f-yr">${['<option value="">Any year</option>'].concat(years.map((y) => `<option value="${y}"${y === yr ? " selected" : ""}>${y}</option>`)).join("")}</select></label>
      <label>Sort
        <select id="f-sort">
          <option value="num"${sort === "num" ? " selected" : ""}>Code number</option>
          <option value="az"${sort === "az" ? " selected" : ""}>Title A–Z</option>
          <option value="year"${sort === "year" ? " selected" : ""}>Newest edition</option>
          <option value="views"${sort === "views" ? " selected" : ""}>Most viewed</option>
        </select></label>
      <button class="btn ghost sm" data-act="clearfilters">Clear</button>
    </div>
    ${fav.length ? `<section>${sectionHead("★ Favourites")}<div class="grid codes">${fav.map(codeCard).join("")}</div></section>` : ""}
    ${recent.length ? `<section>${sectionHead("Recently viewed")}<div class="grid codes">${recent.map(codeCard).join("")}</div></section>` : ""}
    <section>${sectionHead(list.length + " result" + (list.length === 1 ? "" : "s"))}
      ${list.length ? `<div class="grid codes">${list.map(codeCard).join("")}</div>` : emptyState("No code matches those filters. Try clearing the category or year filter.")}
    </section>`;
  };

  V.cat = function (params) {
    const c = catById(params.id);
    if (!c) return notFound();
    const list = CODES.filter((x) => x.cat === c.id);
    const tps = TOPICS.filter((tp) => { const cd = codeById(tp.code); return cd && cd.cat === c.id; });
    return `<header class="page-head">
      <p class="eyebrow mono">Category</p>
      <h1>${c.icon} ${esc(S.lang === "hi" && c.hi ? c.hi : c.name)}</h1>
      <p class="lede">${esc(c.blurb || c.desc || "")}</p></header>
    <section>${sectionHead(list.length + " codes")}<div class="grid codes">${list.map(codeCard).join("")}</div></section>
    ${tps.length ? `<section>${sectionHead(tps.length + " topics in this category")}<div class="rows">${tps.map(topicRow).join("")}</div></section>` : ""}`;
  };

  V.code = function (params) {
    const c = codeById(params.id);
    if (!c) return notFound();
    track("code", c.id, codeLabel(c), c.title);
    const cat = catById(c.cat);
    const tps = TOPICS.filter((x) => x.code === c.id);
    const tbs = TABLES.filter((x) => x.code === c.id);
    const qs = MCQS.filter((x) => x.code === c.id);
    const rel = (c.related || []).map(codeById).filter(Boolean);
    return `<nav class="crumbs mono"><a href="#/codes">All codes</a> → ${cat ? `<a href="#/cat/${cat.id}">${esc(cat.name)}</a> → ` : ""}<span>${esc(c.number)}</span></nav>
    <header class="code-head stat-${c.status}">
      <div class="ch-top">
        <h1 class="mono">${esc(codeLabel(c))}</h1>
        <div class="ch-actions">${saveBtn("code", c.id)}${sourceBtns(c)}</div>
      </div>
      <p class="ch-title">${esc(c.title)}</p>
      <div class="ch-meta">${statusPill(c.status)}<span class="doctype">${esc(c.docType)}</span>${cat ? `<a class="tag" href="#/cat/${cat.id}">${cat.icon} ${esc(cat.name)}</a>` : ""}</div>
    </header>

    <section class="card">
      <h2>${t("info")}</h2>
      <dl class="info">
        <dt>Code number</dt><dd class="mono">${esc(c.number)}</dd>
        <dt>Title</dt><dd>${esc(c.title)}</dd>
        <dt>Edition / year</dt><dd>${esc(c.edition || c.year)}</dd>
        <dt>Category</dt><dd>${cat ? esc(cat.name) : "—"}</dd>
        <dt>Document type</dt><dd>${esc(c.docType)}${c.docType === "IRC" || c.docType === "MoRTH" ? " <span class=\"warnnote\">— not an Indian Standard</span>" : ""}</dd>
        <dt>Status</dt><dd>${statusPill(c.status)}</dd>
        <dt>Official page</dt><dd>${c.documentUrl
        ? `<a class="link" href="${esc(c.documentUrl)}" target="_blank" rel="noopener">Opens this standard directly ↗</a>`
        : `<span class="fine">Direct link not recorded yet — the button above opens the portal and copies the code number for you.</span>`}</dd>
      </dl>
      <p class="summary">${esc(c.summary)}</p>
      ${srcLine("Official reference: " + c.src)}
    </section>

    ${guideBlock(c)}

    ${c.contents && c.contents.length ? `<section class="card">
      <h2>📑 ${t("contents")}</h2>
      <ol class="contents">${c.contents.map((x) => `<li>${esc(x)}</li>`).join("")}</ol>
      <p class="fine">Index of what the standard covers — prepared for navigation, not a reproduction of the code text.</p>
    </section>` : ""}

    ${(function () {
      const mats = (DB.materials || []).filter((m) => (m.codes || []).includes(c.id));
      return mats.length ? `<section>${sectionHead("Materials covered by this code")}
        <div class="grid three">${mats.map((m) => `<a class="card cat-card" href="#/materials/${m.id}">
          <span class="cat-ico" aria-hidden="true">${m.icon}</span><span class="cat-name">${esc(m.name)}</span>
          <span class="cat-blurb">${esc(m.blurb)}</span></a>`).join("")}</div></section>` : "";
    })()}
    ${(DB.clauses || {})[c.id] ? (function () {
      const st = clauseStats(c.id);
      return `<section class="card cta-card clause-cta"><div><h2>§ Clause map</h2>
        <p>${st.total} ${st.unit} indexed by number and heading — ${st.mapped} of them explained here. Search a clause number like <code class="mono">26.4.2</code> from anywhere in the app.</p></div>
        <a class="btn" href="#/clauses/${c.id}">Open clause map →</a></section>`;
    })() : ""}
    ${tps.length ? `<section>${sectionHead("Topics explained (" + tps.length + ")")}<div class="rows">${tps.map(topicRow).join("")}</div></section>` : ""}
    ${tbs.length ? `<section>${sectionHead("Tables & values (" + tbs.length + ")")}<div class="rows">${tbs.map((tb) => `<a class="row" href="#/table/${tb.id}"><div class="row-main"><div class="row-title">${esc(tb.title)}</div><div class="row-sub mono">${esc(tb.ref)}</div></div><span class="chev">→</span></a>`).join("")}</div></section>` : ""}
    ${(function () {
      const exs = (DB.examples || []).filter((e) => e.code === c.id);
      return exs.length ? `<section>${sectionHead("✏️ Solved examples (" + exs.length + ")")}
        <div class="rows">${exs.map((e) => `<a class="row" href="#/examples/${e.id}">
          <div class="row-main"><div class="row-title">${esc(e.title)}</div>
          <div class="row-sub mono">${esc(e.cat)} · ${esc(e.level)} · ${e.steps.length} steps</div></div>
          <span class="chev">→</span></a>`).join("")}</div></section>` : "";
    })()}
    ${qs.length ? `<section class="card cta-card"><div><h2>Practice this code</h2><p>${qs.length} questions with explanations and clause references.</p></div><a class="btn" href="#/exam/quiz/${c.id}">Start ${esc(c.number)} quiz →</a></section>` : ""}
    ${rel.length ? `<section>${sectionHead("🔗 " + t("related"))}<div class="grid codes">${rel.map(codeCard).join("")}</div></section>` : ""}`;
  };

  V.topic = function (params) {
    const tp = topicById(params.id);
    if (!tp) return notFound();
    const c = codeById(tp.code);
    track("topic", tp.id, tp.title, c ? codeLabel(c) + " · " + tp.ref : tp.ref);
    const tb = tp.table ? tableById(tp.table) : null;
    const fm = tp.formula ? formulaById(tp.formula) : null;
    const rel = (tp.related || []).map(topicById).filter(Boolean);
    return `<nav class="crumbs mono">${c ? `<a href="#/code/${c.id}">${esc(codeLabel(c))}</a> → ` : ""}<span>${esc(tp.title)}</span></nav>
    <header class="page-head topic-head">
      <div class="th-top"><h1>${esc(S.lang === "hi" && tp.hi ? tp.hi : tp.title)}</h1>${saveBtn("topic", tp.id)}</div>
      ${tp.hi ? `<p class="hi-title">${esc(S.lang === "hi" ? tp.title : tp.hi)}</p>` : ""}
      <p class="ref-badge mono">${esc(tp.ref)}</p>
    </header>

    ${hiNotice(tp)}
    <section class="card q-what"><h2>${t("what")}</h2><p>${esc(body(tp, "what"))}</p></section>
    ${diagramBlock(tp.id)}
    <section class="card q-why"><h2>${t("why")}</h2><p>${esc(body(tp, "why"))}</p></section>
    <section class="card q-eg"><h2>${t("eg")}</h2><p>${esc(body(tp, "eg"))}</p></section>
    <section class="card q-tip"><h2>💡 ${t("tip")}</h2><p>${esc(body(tp, "tip"))}</p></section>

    ${fm ? `<section class="card formula-card">
      <h2>Formula</h2>
      <p class="formula mono">${esc(fm.expr)}</p>
      <dl class="vars">${(fm.vars || []).map((v) => `<dt class="mono">${esc(v[0])}</dt><dd>${esc(v[1])}</dd>`).join("")}</dl>
      <p class="eg"><strong>Worked example.</strong> ${esc(fm.example)}</p>
      ${srcLine(fm.ref)}
      <div class="row-actions">${saveBtn("formula", fm.id)}${relatedCalcLink(fm.id)}</div>
    </section>` : ""}

    ${tb ? `<section class="card">
      <h2>${esc(tb.title)}</h2>
      ${tableBlock(tb)}
      ${tb.note ? `<p class="fine">${esc(tb.note)}</p>` : ""}
      ${srcLine(tb.ref)}
      <div class="row-actions">${saveBtn("table", tb.id)}<a class="btn ghost sm" href="#/table/${tb.id}">Open table →</a></div>
    </section>` : ""}

    <section class="card src-card">
      <h2>${t("ref")}</h2>
      <p class="mono big-ref">${esc(tp.ref)}</p>
      ${c ? `<p>From <a href="#/code/${c.id}">${esc(codeLabel(c))} — ${esc(c.title)}</a> ${statusPill(c.status)}</p>
      <a class="btn ghost sm" href="${esc(c.src)}" target="_blank" rel="noopener">${t("source")} ↗</a>` : ""}
      <p class="fine">Always confirm the clause against the latest officially published edition before using it for design.</p>
      <div class="row-actions">${shareBtn(tp.title + " — " + tp.ref)}${reportBtn("topic", tp.id, tp.title)}</div>
    </section>

    ${notesBlock(tp.id)}
    ${rel.length ? `<section>${sectionHead("Related topics")}<div class="rows">${rel.map(topicRow).join("")}</div></section>` : ""}`;
  };

  /* Official-source buttons.
     If a per-code deep link has been recorded, open the standard directly.
     Otherwise open the portal and put the code number on the clipboard so the
     student only has to paste it into the portal's search box. */
  function sourceBtns(c) {
    if (c.documentUrl) {
      return `<a class="btn sm" href="${esc(c.documentUrl)}" target="_blank" rel="noopener">Open this standard ↗</a>`;
    }
    return `<a class="btn sm ghost" href="${esc(c.src)}" target="_blank" rel="noopener">${t("source")} ↗</a>
      <button class="btn sm ghost" data-act="copycode" data-n="${esc(c.number)}">Copy “${esc(c.number)}”</button>`;
  }

  function guideBlock(c) {
    const g = (DB.guides || {})[c.id];
    if (!g) return "";
    return `<section class="card guide-card">
      <h2>📘 Code guide</h2>
      <p class="guide-what">${esc(g.what)}</p>
      ${g.use ? `<p class="guide-use"><strong>When you open it.</strong> ${esc(g.use)}</p>` : ""}
      ${g.dia && (DB.diagrams || {})[g.dia] ? `<figure class="dia guide-dia">${DB.diagrams[g.dia].svg}
        <figcaption>${DB.diagrams[g.dia].caption}</figcaption></figure>` : ""}
      ${(g.inside || []).length ? `<h3 class="guide-h">What is inside</h3>
        <ul class="bullets">${g.inside.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
      ${(g.key || []).length ? `<h3 class="guide-h">Key values &amp; ideas</h3>
        <dl class="kv">${g.key.map((k) => `<dt>${esc(k[0])}</dt><dd>${esc(k[1])}</dd>`).join("")}</dl>` : ""}
      ${(g.watch || []).length ? `<h3 class="guide-h">⚠️ Watch out</h3>
        <ul class="bullets warn-b">${g.watch.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}
      <p class="fine">${esc(DB.guideNote || "")}</p>
      <div class="row-actions">${shareBtn(codeLabel(c) + " — code guide")}${reportBtn("guide", c.id, codeLabel(c))}</div>
    </section>`;
  }
  function shareBtn(title) {
    return `<button class="btn ghost sm" data-act="share" data-t="${esc(title)}">↗ Share</button>`;
  }
  function reportBtn(kind, id, label) {
    return `<button class="btn ghost sm" data-act="report" data-kind="${kind}" data-id="${esc(id)}" data-label="${esc(label)}">⚑ Report an error</button>`;
  }
  function notesBlock(id) {
    const val = S.notes[id] || "";
    return `<section class="card note-card">
      <h2>📝 My note</h2>
      <p class="fine">Saved on this device only. Use it for your own working, a lecturer's remark, or a page number from your textbook.</p>
      <textarea class="note-in" data-act="note" data-id="${esc(id)}" rows="3" placeholder="Write a note for this topic…">${esc(val)}</textarea>
      <p class="note-state fine" id="note-state">${val ? "Saved" : ""}</p>
    </section>`;
  }

  function diagramBlock(id) {
    const d = (DB.diagrams || {})[id];
    if (!d) return "";
    return `<section class="card dia-card">
      <h2>📐 ${esc(d.label)}</h2>
      <figure class="dia hb-dia${d.anim ? " is-anim" : ""}">${d.svg}<figcaption>${d.caption}</figcaption></figure>
    </section>`;
  }

  function relatedCalcLink(fid) {
    const map = { "f-ld": "dev-length", "f-mulim": "mu-lim", "f-tauc": "tauc-calc", "f-steelwt": "steel-weight", "f-concrete": "concrete-qty", "f-simpson": "area-offsets", "f-level": "level-hi", "f-traverse": "traverse" };
    return map[fid] ? `<a class="btn ghost sm" href="#/calc/${map[fid]}">Open calculator →</a>` : "";
  }

  V.tables = function () {
    return `<header class="page-head"><h1>${t("tables")}</h1>
      <p class="lede">The values students look up most often, each carrying the clause or table it comes from. Nothing here is invented — every figure names its source.</p></header>
      <div class="rows">${TABLES.map((tb) => `<a class="row" href="#/table/${tb.id}">
        <div class="row-main"><div class="row-title">${esc(tb.title)}</div><div class="row-sub mono">${esc(tb.ref)}</div></div><span class="chev">→</span></a>`).join("")}</div>`;
  };

  V.table = function (params) {
    const tb = tableById(params.id);
    if (!tb) return notFound();
    track("table", tb.id, tb.title, tb.ref);
    const c = tb.code ? codeById(tb.code) : null;
    return `<nav class="crumbs mono"><a href="#/tables">Tables & values</a> → <span>${esc(tb.title)}</span></nav>
    <header class="page-head"><div class="th-top"><h1>${esc(tb.title)}</h1>${saveBtn("table", tb.id)}</div>
    <p class="ref-badge mono">${esc(tb.ref)}</p></header>
    <section class="card">${tableBlock(tb)}${tb.note ? `<p class="fine">${esc(tb.note)}</p>` : ""}${srcLine(tb.ref)}
    ${c ? `<a class="btn ghost sm" href="#/code/${c.id}">Open ${esc(codeLabel(c))} →</a>` : ""}</section>`;
  };

  V.formulas = function () {
    return `<header class="page-head"><div class="th-top"><h1>${t("formulas")}</h1>
      <button class="btn sm" data-act="sheet">⬇ Download revision sheet</button></div>
      <p class="lede">Each formula with its variables, the clause it comes from, and a worked example in real numbers.</p></header>
      ${FORMULAS.map((f) => `<section class="card formula-card">
        <div class="th-top"><h2>${esc(f.title)}</h2>${saveBtn("formula", f.id)}</div>
        <p class="formula mono">${esc(f.expr)}</p>
        <dl class="vars">${(f.vars || []).map((v) => `<dt class="mono">${esc(v[0])}</dt><dd>${esc(v[1])}</dd>`).join("")}</dl>
        <p class="eg"><strong>Example.</strong> ${esc(f.example)}</p>
        ${srcLine(f.ref)}
        <div class="row-actions">${f.topic ? `<a class="btn ghost sm" href="#/topic/${f.topic}">Read the topic →</a>` : ""}${relatedCalcLink(f.id)}</div>
      </section>`).join("")}`;
  };

  V.search = function (params) {
    const q = params.q || "";
    const res = q ? searchAll(q, 80) : [];
    const groups = { materials: [], clause: [], code: [], topic: [], table: [], formula: [], calc: [], example: [], mcq: [] };
    res.forEach((r) => groups[r.type] && groups[r.type].push(r));
    const names = { materials: "Materials", clause: "Clauses", code: "Codes", topic: "Topics & clauses", table: "Tables & values", formula: "Formulas", calc: "Calculators", mcq: "Practice questions", example: "Solved examples" };
    const body = !q
      ? emptyState("Type a code number, a clause topic, or a keyword — try “nominal cover”, “Ld”, “456”, or “pile”.")
      : res.length === 0
        ? emptyState("Nothing matched “" + q + "”. Try a code number (456), a topic (development length) or a keyword (pile, plaster, CBR).")
        : Object.keys(groups).filter((k) => groups[k].length)
            .sort((a, b) => res.indexOf(groups[a][0]) - res.indexOf(groups[b][0]))
            .map((k) => `<section>
            ${sectionHead(names[k] + " (" + groups[k].length + ")")}
            <div class="rows">${groups[k].map((e) => `<a class="row" href="${hrefFor(e)}">
              <div class="row-main"><div class="row-title">${esc(e.title)}</div><div class="row-sub mono">${esc(e.sub || "")}</div></div><span class="chev">→</span></a>`).join("")}</div>
          </section>`).join("");
    return `<header class="page-head"><h1>${t("search")}</h1>${q ? `<p class="lede">${res.length} result${res.length === 1 ? "" : "s"} for <strong>${esc(q)}</strong></p>` : ""}</header>
      ${searchBox(q)}
      <div class="chips">${["IS 456", "nominal cover", "Ld", "456", "pile", "CBR", "slump", "lap length", "base shear"].map((x) => `<button class="chip" data-act="q" data-q="${esc(x)}">${esc(x)}</button>`).join("")}</div>
      ${body}`;
  };

  /* ------------------------------------------------------------ calculators */
  function calcMeta(id) { return (window.CALCMETA || {})[id] || {}; }
  function calcTile(c) {
    const m = calcMeta(c.id);
    const cat = CALC.cats.find((x) => x.id === c.cat);
    return `<a class="calc-tile" href="#/calc/${c.id}" data-cat="${c.cat}"
        data-hay="${esc(norm([c.name, m.desc, m.kw, c.formula, cat ? cat.name : ""].join(" ")))}">
      <span class="ct-ico" aria-hidden="true">${m.icon || "🧮"}</span>
      <span class="ct-body">
        <span class="ct-name">${esc(c.name)}</span>
        <span class="ct-desc">${esc(m.desc || String(c.formula).slice(0, 70))}</span>
      </span>
      <span class="ct-go" aria-hidden="true">→</span>
    </a>`;
  }
  V.calc = function (params) {
    if (params.id) return calcView(params.id);
    calcCat = "all";
    const recents = (S.recents || []).filter((r) => r.kind === "calc")
      .map((r) => CALC.list.find((c) => c.id === r.id)).filter(Boolean).slice(0, 4);
    const pop = (window.CALCPOPULAR || []).map((id) => CALC.list.find((c) => c.id === id)).filter(Boolean);
    return `<header class="page-head calc-head">
      <h1>🧮 ${t("calc")}</h1>
      <p class="lede">${CALC.list.length} tools. Each one shows the formula it follows, the working step by step, and the clause it comes from — so you can check it, not just trust it.</p>
    </header>

    <div class="calc-filter">
      <div class="searchbar"><span class="s-ico" aria-hidden="true">🔍</span>
        <input id="calcq" type="search" placeholder="Find a calculator — try “stirrup”, “ld”, “bricks”, “acre”…" autocomplete="off">
      </div>
      <div class="chips cat-chips">
        <button class="chip on" data-act="calcfilter" data-cat="all">All ${CALC.list.length}</button>
        ${CALC.cats.map((cat) => `<button class="chip" data-act="calcfilter" data-cat="${cat.id}">${cat.icon} ${esc(cat.name)}</button>`).join("")}
      </div>
    </div>

    ${recents.length ? `<section class="calc-sec" data-strip="recent">${sectionHead("↩︎ Recently used")}
      <div class="calc-grid">${recents.map(calcTile).join("")}</div></section>` : ""}

    ${pop.length ? `<section class="calc-sec" data-strip="popular">${sectionHead("⭐ Most used")}
      <div class="calc-grid">${pop.map(calcTile).join("")}</div></section>` : ""}

    <div id="calc-results"></div>

    ${CALC.cats.map((cat) => `<section class="calc-sec" data-catsec="${cat.id}">
      ${sectionHead(cat.icon + " " + cat.name, `<span class="more">${esc(cat.desc)}</span>`)}
      <div class="calc-grid">${CALC.list.filter((c) => c.cat === cat.id).map(calcTile).join("")}</div>
    </section>`).join("")}

    <p class="calc-empty" id="calc-none" hidden>Nothing matched. Try a different word — or browse a category above.</p>`;
  };

  function calcView(id) {
    const c = CALC.list.find((x) => x.id === id);
    if (!c) return notFound();
    track("calc", c.id, c.name, "Calculator");
    const f = (i) => {
      const v = calcState[c.id] && calcState[c.id][i.k] !== undefined ? calcState[c.id][i.k] : i.def;
      if (i.type === "select") return `<select id="ci-${i.k}" data-k="${i.k}">${i.opts.map((o) => `<option${String(o) === String(v) ? " selected" : ""}>${esc(o)}</option>`).join("")}</select>`;
      if (i.type === "textarea") return `<textarea id="ci-${i.k}" data-k="${i.k}" rows="5">${esc(v)}</textarea>`;
      if (i.type === "text") return `<input id="ci-${i.k}" data-k="${i.k}" type="text" value="${esc(v)}">`;
      return `<input id="ci-${i.k}" data-k="${i.k}" type="number" step="${i.step || "any"}" value="${esc(v)}">`;
    };
    const m = calcMeta(c.id);
    const cat = CALC.cats.find((x) => x.id === c.cat);
    const rel = CALC.list.filter((x) => x.cat === c.cat && x.id !== c.id).slice(0, 3);
    /* Open with a worked answer already on screen, using the default values. */
    if (!calcState[c.id] && c.inputs.every((i) => i.def !== undefined && i.def !== "")) {
      const seed = {};
      c.inputs.forEach((i) => { seed[i.k] = i.def; });
      try { c.run(seed); calcState[c.id] = seed; } catch (err) { /* leave the placeholder */ }
    }
    return `<nav class="crumbs mono"><a href="#/calc">Calculators</a> → <span>${esc(c.name)}</span></nav>
    <header class="page-head calc-hero">
      <div class="ch-ico" aria-hidden="true">${m.icon || "🧮"}</div>
      <div class="ch-txt">
        <h1>${esc(c.name)}</h1>
        ${m.desc ? `<p class="lede">${esc(m.desc)}</p>` : ""}
        ${cat ? `<span class="tag">${cat.icon} ${esc(cat.name)}</span>` : ""}
      </div>
      ${saveBtn("calc", c.id)}
    </header>

    <section class="card calc-panel">
      <form class="calc-form" data-act="calcform" data-id="${c.id}">
        <div class="grid inputs">${c.inputs.map((i) => `<label class="field"><span class="flabel">${esc(i.label)}${i.unit ? ` <em class="unit mono">${esc(i.unit)}</em>` : ""}</span>${f(i)}</label>`).join("")}</div>
        <div class="row-actions">
          <button class="btn" type="submit">Calculate</button>
          <button class="btn ghost" type="button" data-act="calcreset" data-id="${c.id}">Reset</button>
          <span class="live-hint fine">Results update as you type</span>
        </div>
      </form>
    </section>

    <div id="calc-out">${calcState[c.id] ? renderCalcOut(c) : `<section class="card calc-placeholder">
      <span class="cp-ico" aria-hidden="true">${m.icon || "🧮"}</span>
      <p>Enter your values above — the answer, the working and the clause appear here.</p></section>`}</div>

    <details class="card calc-ref">
      <summary><span class="cr-k mono">Formula &amp; source</span></summary>
      <p class="formula mono">${esc(c.formula)}</p>
      ${srcLine(c.ref)}
    </details>

    ${rel.length ? `<section>${sectionHead("More " + (cat ? cat.name : "") + " tools")}
      <div class="calc-grid">${rel.map(calcTile).join("")}</div></section>` : ""}`;
  }
  let calcState = {};
  function renderCalcOut(c) {
    let out;
    try { out = c.run(calcState[c.id]); } catch (e) {
      return `<section class="card calc-err"><p><strong>Could not compute with those inputs.</strong> Check that every field has a valid number.</p></section>`;
    }
    const res = (out.results || []);
    const hero = res.find((r) => r.big) || res[res.length - 1];
    const rest = res.filter((r) => r !== hero);
    return `<section class="card calc-answer">
      ${hero ? `<div class="hero-res">
        <span class="hr-l">${esc(hero.label)}</span>
        <span class="hr-v mono">${esc(hero.value)}<em>${esc(hero.unit || "")}</em></span>
      </div>` : ""}
      ${rest.length ? `<div class="results">${rest.map((r) => `<div class="res">
        <span class="res-l">${esc(r.label)}</span><span class="res-v mono">${esc(r.value)} <em>${esc(r.unit || "")}</em></span></div>`).join("")}</div>` : ""}
      ${out.table ? tableBlock(out.table) : ""}
      ${out.note ? `<p class="fine">${esc(out.note)}</p>` : ""}
      <div class="row-actions">
        <button class="btn sm" data-act="addproj" data-id="${c.id}">+ Add to project</button>
        ${shareBtn(c.name)}
        <a class="btn ghost sm" href="#/project">Open project →</a>
      </div>
    </section>
    ${(out.steps || []).filter(Boolean).length ? `<details class="card calc-work" open>
      <summary><span class="cr-k mono">How this was calculated</span></summary>
      <ol class="steps">${out.steps.filter(Boolean).map((s) => `<li class="mono">${esc(s)}</li>`).join("")}</ol>
      ${srcLine(c.ref)}
    </details>` : ""}`;
  }

  /* ------------------------------------------------------------- exam mode */
  function todayKey() { const d = new Date(); return d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate(); }
  function seededPick(arr, n, seed) {
    const a = arr.slice(); let s = seed;
    const rnd = () => { s = (s * 1103515245 + 12345) % 2147483648; return s / 2147483648; };
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; }
    return a.slice(0, n);
  }
  function dailySet() {
    const d = new Date(), seed = d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
    return { qs: seededPick(MCQS, 5, seed), rev: DB.revision[seed % DB.revision.length] };
  }
  function shuffled(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[a[i], a[j]] = [a[j], a[i]]; }
    return a;
  }
  function catQuestions(catId) {
    const ids = CODES.filter((c) => c.cat === catId).map((c) => c.id);
    return MCQS.filter((q) => ids.includes(q.code));
  }
  /* A mock test spreads its questions across subjects instead of over-sampling IS 456. */
  function mockSet(n) {
    const per = {}, out = [];
    DB.categories.forEach((cat) => { per[cat.id] = shuffled(catQuestions(cat.id)); });
    const cats = DB.categories.map((c) => c.id).filter((c) => per[c].length);
    let i = 0;
    while (out.length < n && cats.some((c) => per[c].length)) {
      const c = cats[i % cats.length]; i++;
      if (per[c].length) out.push(per[c].pop());
    }
    return shuffled(out);
  }

  V.exam = function (params) {
    if (params.sub === "quiz") return quizView(params.id);
    if (params.sub === "daily") return quizView("daily");
    if (params.sub === "revision") return revisionView(params.id);
    const byCode = {};
    MCQS.forEach((q) => { byCode[q.code] = (byCode[q.code] || 0) + 1; });
    const badges = earnedBadges();
    const acc = S.stats.answered ? Math.round((100 * S.stats.correct) / S.stats.answered) : 0;
    return `<header class="page-head"><h1>🎓 ${t("exam")}</h1>
      <p class="lede">${MCQS.length} questions, each with the correct answer, an explanation and the clause it comes from.</p></header>

      <section class="card stats-card">
        <div class="stat"><span class="stat-n mono">${S.stats.answered}</span><span class="stat-l">Answered</span></div>
        <div class="stat"><span class="stat-n mono">${acc}%</span><span class="stat-l">Accuracy</span></div>
        <div class="stat"><span class="stat-n mono">${progressPct()}%</span><span class="stat-l">${t("progress")}</span></div>
        <div class="stat"><span class="stat-n mono">${badges.filter((b) => b.got).length}/${badges.length}</span><span class="stat-l">Badges</span></div>
        <div class="bar"><span style="width:${progressPct()}%"></span></div>
      </section>

      <section class="card cta-card"><div><h2>Daily challenge</h2><p>Five questions, the same five for everyone today. ${S.stats.dailyDone.includes(todayKey()) ? "You have completed today's set." : ""}</p></div>
        <a class="btn" href="#/exam/daily">${S.stats.dailyDone.includes(todayKey()) ? "Attempt again" : "Start today's 5"} →</a></section>

      <section class="card cta-card"><div><h2>Mock test</h2>
        <p>Twenty-five questions spread across every subject, in random order — closer to how a real paper is set than a single-code quiz.${S.stats.bestQuiz["mock"] ? " Your best so far: " + S.stats.bestQuiz["mock"] + "%." : ""}</p></div>
        <a class="btn" href="#/exam/quiz/mock">Start mock test →</a></section>

      <section>${sectionHead("Practice by subject")}
        <div class="grid three">${DB.categories.map((cat) => {
      const n = catQuestions(cat.id).length; if (!n) return "";
      const best = S.stats.bestQuiz["cat-" + cat.id];
      return `<a class="card quiz-card" href="#/exam/quiz/cat-${cat.id}">
          <span class="qz-no">${cat.icon} ${esc(cat.name)}</span>
          <span class="qz-m mono">${n} question${n === 1 ? "" : "s"}${best ? " · best " + best + "%" : ""}</span></a>`;
    }).join("")}</div></section>

      <section>${sectionHead("Quiz by code")}
        <div class="grid three">${Object.keys(byCode).sort((a, b) => byCode[b] - byCode[a]).map((cid) => {
      const c = codeById(cid); if (!c) return "";
      const best = S.stats.bestQuiz[cid];
      return `<a class="card quiz-card" href="#/exam/quiz/${cid}">
            <span class="qz-no mono">${esc(c.number)}</span><span class="qz-t">${esc(c.title)}</span>
            <span class="qz-m mono">${byCode[cid]} questions${best ? " · best " + best + "%" : ""}</span></a>`;
    }).join("")}</div></section>

      <section>${sectionHead("Quick revision")}
        <div class="rows">${DB.revision.map((r) => `<a class="row" href="#/exam/revision/${r.id}">
          <div class="row-main"><div class="row-title">${esc(r.title)}</div><div class="row-sub mono">${r.points.length} points</div></div><span class="chev">→</span></a>`).join("")}</div></section>

      <section>${sectionHead("Badges")}
        <div class="grid badges">${badges.map(({ b, got }) => `<div class="card badge${got ? " got" : ""}">
          <span class="bd-i" aria-hidden="true">${b.icon}</span><span class="bd-n">${esc(b.name)}</span>
          <span class="bd-d">${esc(b.desc)}</span><span class="bd-s mono">${got ? "Earned" : "Locked"}</span></div>`).join("")}</div></section>`;
  };

  let quiz = null;
  function quizView(id) {
    if (!quiz || quiz.key !== id) {
      let qs, title;
      if (id === "daily") { qs = dailySet().qs; title = "Daily challenge — " + new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long" }); }
      else if (id === "mock") { qs = mockSet(25); title = "Mock test — 25 mixed questions"; }
      else if (id.indexOf("unit-") === 0) {
        const m = id.match(/^unit-(.+)-(\d+)$/);
        const sub = m && subjectById(m[1]);
        const u = sub && unitOf(sub, m[2]);
        if (!u) return notFound();
        qs = shuffled(unitMcqs(u)).slice(0, 25);
        title = unitName(u) + " — " + (S.lang === "hi" ? "प्रैक्टिस" : "practice set");
      }
      else if (id.indexOf("sub-") === 0) {
        const sub = subjectById(id.slice(4)); if (!sub) return notFound();
        qs = shuffled(subjectMcqs(sub)).slice(0, 25);
        title = (S.lang === "hi" && sub.hi ? sub.hi : sub.name) + " \u2014 practice set";
      }
      else if (id.indexOf("cat-") === 0) {
        const cat = catById(id.slice(4)); if (!cat) return notFound();
        qs = shuffled(catQuestions(cat.id)).slice(0, 25);
        title = cat.name + " — practice set";
      } else { const c = codeById(id); if (!c) return notFound(); qs = MCQS.filter((q) => q.code === id); title = codeLabel(c) + " quiz"; }
      if (!qs.length) return emptyState("No questions for this code yet.");
      quiz = { key: id, title, qs, i: 0, picked: null, score: 0, done: false };
    }
    if (quiz.done) {
      const pct = Math.round((100 * quiz.score) / quiz.qs.length);
      if (quiz.key !== "daily") S.stats.bestQuiz[quiz.key] = Math.max(S.stats.bestQuiz[quiz.key] || 0, pct);
      else if (!S.stats.dailyDone.includes(todayKey())) S.stats.dailyDone.push(todayKey());
      save();
      return `<header class="page-head"><h1>${esc(quiz.title)}</h1></header>
      <section class="card result-card center">
        <p class="score mono">${quiz.score}<span>/${quiz.qs.length}</span></p>
        <p class="score-pct mono">${pct}%</p>
        <p>${pct >= 80 ? "Strong. You know where these clauses live." : pct >= 50 ? "Solid start — review the explanations you missed." : "Read the topic pages for this code, then try again."}</p>
        <div class="row-actions center">
          <button class="btn" data-act="quizrestart">Try again</button>
          <a class="btn ghost" href="#/exam">Back to exam mode</a></div>
      </section>
      <section>${sectionHead("Review")}
        ${quiz.qs.map((q, i) => `<div class="card review-q">
          <p class="rq mono">Q${i + 1}</p><p class="rq-t">${esc(q.q)}</p>
          <p class="rq-a">✔ ${esc(q.opts[q.ans])}</p>
          <p class="rq-e">${esc(q.exp)}</p>${srcLine(q.ref)}</div>`).join("")}</section>`;
    }
    const q = quiz.qs[quiz.i];
    const picked = quiz.picked;
    return `<header class="page-head"><div class="th-top"><h1>${esc(quiz.title)}</h1><span class="mono qprog">${quiz.i + 1} / ${quiz.qs.length}</span></div>
      <div class="bar"><span style="width:${((quiz.i) / quiz.qs.length) * 100}%"></span></div></header>
      <section class="card quiz">
        <p class="q-text">${esc(q.q)}</p>
        <div class="opts">${q.opts.map((o, i) => {
      let cls = "";
      if (picked !== null) { if (i === q.ans) cls = " correct"; else if (i === picked) cls = " wrong"; }
      return `<button class="opt${cls}" data-act="answer" data-i="${i}"${picked !== null ? " disabled" : ""}>
            <span class="opt-k mono">${"ABCD"[i]}</span><span>${esc(o)}</span></button>`;
    }).join("")}</div>
        ${picked !== null ? `<div class="explain ${picked === q.ans ? "ok" : "bad"}">
          <p class="ex-h">${picked === q.ans ? "✔ Correct" : "✘ Correct answer: " + "ABCD"[q.ans] + ". " + esc(q.opts[q.ans])}</p>
          <p>${esc(q.exp)}</p>${srcLine(q.ref)}
          <div class="row-actions">${saveBtn("mcq", q.id)}${q.topic ? `<a class="btn ghost sm" href="#/topic/${q.topic}">Read the topic →</a>` : ""}
          <button class="btn" data-act="qnext">${quiz.i === quiz.qs.length - 1 ? "See result" : "Next question"} →</button></div>
        </div>` : ""}
      </section>`;
  }

  function revisionView(id) {
    const r = DB.revision.find((x) => x.id === id);
    if (!r) return notFound();
    const c = codeById(r.code);
    return `<nav class="crumbs mono"><a href="#/exam">Exam mode</a> → <span>Quick revision</span></nav>
      <header class="page-head"><h1>${esc(r.title)}</h1>${c ? `<p class="ref-badge mono">${esc(codeLabel(c))} — ${esc(c.title)}</p>` : ""}</header>
      <section class="card"><ol class="rev">${r.points.map((p) => `<li>${esc(p)}</li>`).join("")}</ol>
      <p class="fine">Compiled as a revision aid. Confirm each value against the published standard before using it in design.</p></section>
      ${c ? `<div class="row-actions"><a class="btn" href="#/exam/quiz/${c.id}">Take the ${esc(c.number)} quiz →</a><a class="btn ghost" href="#/code/${c.id}">Open the code page</a></div>` : ""}`;
  }

  /* ---------------------------------------------------------- my library */
  V.library = function () {
    const sec = (type, title, render) => {
      const ids = S.saved[type] || [];
      if (!ids.length) return `<section>${sectionHead(title + " (0)")}${emptyState("Nothing saved yet. Use the ☆ button on any " + type + " page.")}</section>`;
      return `<section>${sectionHead(title + " (" + ids.length + ")")}${render(ids)}</section>`;
    };
    return `<header class="page-head"><div class="th-top"><h1>⭐ ${t("library")}</h1>
      <button class="btn ghost sm" data-act="export">Export my library</button></div>
      <p class="lede">Saved on this device. Nothing is uploaded anywhere.</p></header>
      ${sec("code", "Saved codes", (ids) => `<div class="grid codes">${ids.map(codeById).filter(Boolean).map(codeCard).join("")}</div>`)}
      ${sec("topic", "Saved topics", (ids) => `<div class="rows">${ids.map(topicById).filter(Boolean).map(topicRow).join("")}</div>`)}
      ${sec("table", "Saved tables", (ids) => `<div class="rows">${ids.map(tableById).filter(Boolean).map((tb) => `<a class="row" href="#/table/${tb.id}"><div class="row-main"><div class="row-title">${esc(tb.title)}</div><div class="row-sub mono">${esc(tb.ref)}</div></div><span class="chev">→</span></a>`).join("")}</div>`)}
      ${sec("formula", "Saved formulas", (ids) => `<div class="rows">${ids.map(formulaById).filter(Boolean).map((f) => `<a class="row" href="#/formulas"><div class="row-main"><div class="row-title">${esc(f.title)}</div><div class="row-sub mono">${esc(f.expr)}</div></div><span class="chev">→</span></a>`).join("")}</div>`)}
      ${sec("calc", "Saved calculators", (ids) => `<div class="rows">${ids.map((i) => CALC.list.find((c) => c.id === i)).filter(Boolean).map((c) => `<a class="row" href="#/calc/${c.id}"><div class="row-main"><div class="row-title">${esc(c.name)}</div><div class="row-sub mono">${esc(c.ref)}</div></div><span class="chev">→</span></a>`).join("")}</div>`)}
      ${sec("subject", "Saved subjects", (ids) => `<div class="rows">${ids.map((i) => (DB.subjects || []).find((x) => x.id === i)).filter(Boolean).map((sb) => `<a class="row" href="#/subject/${sb.id}"><div class="row-main"><div class="row-title">${sb.icon} ${esc(S.lang === "hi" && sb.hi ? sb.hi : sb.name)}</div><div class="row-sub mono">${esc(sb.sem)}</div></div><span class="chev">\u2192</span></a>`).join("")}</div>`)}
      ${sec("mcq", "Saved questions", (ids) => `<div class="rows">${ids.map((i) => MCQS.find((q) => q.id === i)).filter(Boolean).map((q) => `<div class="row static"><div class="row-main"><div class="row-title">${esc(q.q)}</div><div class="row-sub mono">✔ ${esc(q.opts[q.ans])} · ${esc(q.ref)}</div></div></div>`).join("")}</div>`)}
      <section>${sectionHead("Recently viewed")}
        ${S.recents.length ? `<div class="rows">${S.recents.map((r) => `<a class="row" href="#/${r.type}/${r.id}"><div class="row-main"><div class="row-title">${esc(r.title)}</div><div class="row-sub mono">${esc(r.sub || "")}</div></div><span class="chev">→</span></a>`).join("")}</div>` : emptyState("Nothing viewed yet.")}
      </section>`;
  };

  /* ------------------------------------------------------------- profile */
  V.profile = function () {
    const badges = earnedBadges();
    return `<header class="page-head"><h1>${t("profile")}</h1>
      <p class="lede">Your settings and progress, stored on this device only.</p></header>
      <section class="card">
        <h2>What are you studying?</h2>
        <div class="grid three levels">${Object.keys(DB.recommendations).map((k) => `<button class="card level${S.profile.level === k ? " on" : ""}" data-act="level" data-k="${k}">
          <span class="lv-n">${esc(DB.recommendations[k].label)}</span>
          <span class="lv-s mono">${DB.recommendations[k].codes.length} codes recommended</span></button>`).join("")}</div>
      </section>
      <section class="card">
        <h2>Language · भाषा</h2>
        <p>Code numbers, clause references and formulas always stay in their original form.</p>
        <div class="row-actions">
          <button class="btn${S.lang === "en" ? "" : " ghost"}" data-act="lang" data-l="en">English</button>
          <button class="btn${S.lang === "hi" ? "" : " ghost"}" data-act="lang" data-l="hi">हिन्दी</button>
        </div>
        <p class="fine">${hiCount() >= DB.topics.length
          ? `सभी ${DB.topics.length} विषयों की पूरी व्याख्या हिन्दी में उपलब्ध है — यह क्या है, क्यों ज़रूरी है, उदाहरण और याद रखने की बात। तकनीकी शब्द जान-बूझकर अंग्रेज़ी में रखे गए हैं, क्योंकि परीक्षा, drawing और site पर वही चलते हैं।`
          : `हिन्दी व्याख्या अभी ${hiCount()} / ${DB.topics.length} विषयों के लिए लिखी जा चुकी है। बाक़ी विषय हिन्दी में खोलने पर अंग्रेज़ी व्याख्या दिखेगी — वह भी सही और पूरी है।`}</p>
      </section>
      <section class="card stats-card">
        <div class="stat"><span class="stat-n mono">${(S.stats.topicsRead || []).length}</span><span class="stat-l">Topics read</span></div>
        <div class="stat"><span class="stat-n mono">${S.stats.viewedCodes.length}</span><span class="stat-l">Codes opened</span></div>
        <div class="stat"><span class="stat-n mono">${S.stats.answered}</span><span class="stat-l">Questions answered</span></div>
        <div class="stat"><span class="stat-n mono">${S.stats.calcRuns || 0}</span><span class="stat-l">Calculations run</span></div>
        <div class="bar"><span style="width:${progressPct()}%"></span></div>
        <p class="fine">${t("progress")}: ${progressPct()}% of the topics and questions in this library.</p>
      </section>
      <section>${sectionHead("Badges")}<div class="grid badges">${badges.map(({ b, got }) => `<div class="card badge${got ? " got" : ""}">
        <span class="bd-i" aria-hidden="true">${b.icon}</span><span class="bd-n">${esc(b.name)}</span>
        <span class="bd-d">${esc(b.desc)}</span><span class="bd-s mono">${got ? "Earned" : "Locked"}</span></div>`).join("")}</div></section>
      <section class="card">
        <h2>Data</h2>
        <div class="row-actions">
          <button class="btn ghost sm" data-act="export">Export my data</button>
          <button class="btn ghost sm" data-act="reset">Reset everything</button>
          <a class="btn ghost sm" href="#/admin">Admin panel →</a>
        </div>
      </section>`;
  };

  /* ---------------------------------------------------------------- AI */
  let aiNS = null, aiTried = false;
  async function getAI() {
    if (aiTried) return aiNS;
    aiTried = true;
    try { aiNS = window.claude && window.claude.use ? await window.claude.use("sample") : null; } catch (e) { aiNS = null; }
    return aiNS;
  }
  V.ai = function () {
    return `<header class="page-head"><h1>🤖 ${t("ai")}</h1>
      <p class="lede">Ask a question in plain words. The answer is built from this library's own entries and always names the code and clause it came from.</p></header>
      <section class="card">
        <form class="ai-form" data-act="aiform">
          <label class="field"><span class="flabel">Your question</span>
            <textarea id="ai-q" rows="3" placeholder="What is development length? · Which IS Code covers pile foundations? · Difference between Fe 415 and Fe 500?"></textarea></label>
          <div class="row-actions"><button class="btn" type="submit">Ask</button>
            <button class="btn ghost" type="button" data-act="aiclear">Clear</button></div>
        </form>
        <div class="chips">${["What is development length?", "Which code covers pile foundations?", "Explain nominal cover simply", "Difference between Fe 415 and Fe 500"].map((x) => `<button class="chip" data-act="aiq" data-q="${esc(x)}">${esc(x)}</button>`).join("")}</div>
      </section>
      <div id="ai-out"></div>
      <section class="card fine-card">
        <h2>How this works</h2>
        <p>Your question is matched against the codes, clauses, topics, tables, formulas, materials and calculators in this library. The best match is then opened out into an answer — the explanation, the example and the clause reference exactly as they are written here.</p>
        <p>Where this app is opened inside Claude, a language model is also given those same entries as its only source, with instructions never to invent a clause number. Everywhere else — the website and the installed app — the answer is assembled directly from the entries, with no model involved. That version works offline and cannot fabricate anything, but it will not rephrase the question for you.</p>
        <p class="fine">Answers are a study aid, not an engineering opinion. Verify every clause against the published standard.</p>
      </section>`;
  };

  /* ------------------------------------------------------------------
     Offline answer engine. Builds the answer out of the library entry
     itself — no model, no network, and no possibility of an invented
     clause number. Used wherever the AI runtime is not available, which
     includes the self-hosted site and the installed app.
     ------------------------------------------------------------------ */
  /* Question words carry no meaning for retrieval and only dilute the match. */
  const AI_STOP = ["what", "which", "how", "why", "when", "who", "is", "are", "was", "the", "a", "an",
    "of", "for", "in", "on", "to", "do", "does", "did", "can", "should", "explain", "tell", "me",
    "about", "please", "give", "my", "i", "it", "that", "this"];
  function aiQuery(q) {
    const words = norm(q).split(" ").filter((w) => w && AI_STOP.indexOf(w) === -1);
    return words.length ? words.join(" ") : q;
  }
  /* Pick the entry that actually answers a question: an explanation beats a
     bare code record, and a practice question is never the answer. */
  function aiPick(hits) {
    const best = ["topic", "materials", "table", "formula"];
    return hits.slice(0, 6).find((h) => best.indexOf(h.type) !== -1)
      || hits.find((h) => h.type !== "mcq")
      || hits[0];
  }

  function localAnswer(q, hits) {
    const linkRows = (list) => `<div class="rows">${list.map((e) => `<a class="row" href="${hrefFor(e)}">
      <div class="row-main"><div class="row-title">${esc(e.title)}</div><div class="row-sub mono">${esc(e.sub || "")}</div></div>
      <span class="chev">→</span></a>`).join("")}</div>`;

    if (!hits.length) {
      return `<section class="card ai-ans"><h2>Nothing in the library matches that yet</h2>
        <p>Try a code number (<code class="mono">456</code>), a term (<em>development length</em>, <em>nominal cover</em>, <em>CBR</em>)
        or a material (<em>cement</em>, <em>bitumen</em>). If the subject really is missing, it has not been written yet —
        this library never guesses an answer it does not hold.</p>
        <div class="row-actions"><a class="btn ghost sm" href="#/codes">Browse all codes →</a></div></section>`;
    }

    const top = aiPick(hits);
    const others = hits.filter((h) => h !== top && h.type !== "mcq").slice(0, 6);
    let body = "", head = top.title, ref = "", href = hrefFor(top);

    if (top.type === "topic") {
      const tp = topicById(top.id), c = codeById(tp.code);
      head = tp.title; ref = tp.ref;
      body = `<p class="ai-lead">${esc(tp.what)}</p>
        <h3 class="ai-h">Why it matters</h3><p>${esc(tp.why)}</p>
        <h3 class="ai-h">Example</h3><p>${esc(tp.example)}</p>
        <h3 class="ai-h">Remember</h3><p>${esc(tp.tip)}</p>
        ${c ? `<p class="fine">From ${esc(codeLabel(c))} — ${esc(c.title)}</p>` : ""}`;
    } else if (top.type === "table") {
      const tb = tableById(top.id);
      head = tb.title; ref = tb.ref;
      body = `${tb.note ? `<p class="ai-lead">${esc(tb.note)}</p>` : ""}${tableBlock(tb)}`;
    } else if (top.type === "formula") {
      const f = formulaById(top.id);
      head = f.title; ref = f.ref;
      body = `<p class="formula mono">${esc(f.expr)}</p>
        <dl class="vars">${(f.vars || []).map((v) => `<dt class="mono">${esc(v[0])}</dt><dd>${esc(v[1])}</dd>`).join("")}</dl>
        <p class="eg"><strong>Worked example.</strong> ${esc(f.example)}</p>`;
    } else if (top.type === "materials") {
      const m = (DB.materials || []).find((x) => x.id === top.id);
      head = m.name; ref = "Material guide";
      body = `<p class="ai-lead">${esc(m.blurb)}</p><p>${esc(String(m.intro).slice(0, 700))}</p>`;
    } else if (top.type === "code") {
      const c = codeById(top.id), g = (DB.guides || {})[top.id];
      head = codeLabel(c) + " — " + c.title; ref = c.edition || c.year;
      body = `<p class="ai-lead">${esc(g ? g.what : c.summary)}</p>
        ${g && g.use ? `<h3 class="ai-h">When you open it</h3><p>${esc(g.use)}</p>` : ""}
        ${g && (g.key || []).length ? `<h3 class="ai-h">Key values</h3>
          <dl class="kv">${g.key.map((k) => `<dt>${esc(k[0])}</dt><dd>${esc(k[1])}</dd>`).join("")}</dl>` : ""}`;
    } else if (top.type === "clause") {
      const cid = String(top.id).split("::")[0], c = codeById(cid);
      head = top.title; ref = c ? codeLabel(c) : "";
      body = `<p class="ai-lead">That clause is indexed in this library. Open it to see the heading, the explanation where one is written, and the code it belongs to.</p>`;
    } else if (top.type === "calc") {
      head = top.title; ref = top.sub || "";
      body = `<p class="ai-lead">There is a calculator for this. It shows the formula, your inputs, the working step by step and the clause it follows.</p>`;
    } else {
      body = `<p class="ai-lead">The closest entry in the library is below.</p>`;
    }

    return `<section class="card ai-ans">
      <p class="ai-kicker mono">Answered from the library</p>
      <h2>${esc(head)}</h2>
      ${ref ? `<p class="ref-badge mono">${esc(ref)}</p>` : ""}
      ${body}
      <div class="row-actions">
        <a class="btn sm" href="${href}">Open the full entry →</a>
        ${shareBtn(head)}
      </div>
      <p class="fine">Built from this library's own entries — nothing here is generated, so no clause number can be invented. Verify against the published standard before using it in design.</p>
    </section>
    ${others.length ? `<section class="card"><h2>Other entries that match</h2>
      ${linkRows(others)}</section>` : ""}`;
  }

  async function askAI(q) {
    const out = $("#ai-out");
    if (!out) return;
    const ns = await getAI();
    const hits = searchAll(aiQuery(q), 12);
    const ctx = hits.map((h) => {
      if (h.type === "topic") { const tp = topicById(h.id), c = codeById(tp.code); return `TOPIC: ${tp.title}\nCODE: ${c ? codeLabel(c) : ""}\nREFERENCE: ${tp.ref}\nWHAT: ${tp.what}\nWHY: ${tp.why}\nEXAMPLE: ${tp.example}\nTIP: ${tp.tip}`; }
      if (h.type === "code") { const c = codeById(h.id); return `CODE: ${codeLabel(c)} — ${c.title}\nSTATUS: ${c.status}\nSUMMARY: ${c.summary}\nCONTENTS: ${(c.contents || []).join("; ")}\nSOURCE: ${c.src}`; }
      if (h.type === "table") { const tb = tableById(h.id); return `TABLE: ${tb.title}\nREFERENCE: ${tb.ref}\nDATA: ${tb.cols.join(" | ")}\n${tb.rows.map((r) => r.join(" | ")).join("\n")}`; }
      if (h.type === "formula") { const f = formulaById(h.id); return `FORMULA: ${f.title}\nEXPRESSION: ${f.expr}\nREFERENCE: ${f.ref}\nEXAMPLE: ${f.example}`; }
      return "";
    }).filter(Boolean).join("\n\n---\n\n");

    if (!ns) { out.innerHTML = localAnswer(q, hits); return; }
    out.innerHTML = `<section class="card ai-ans"><h2>Answer</h2><div id="ai-text" class="ai-text">Thinking…</div></section>`;
    const target = $("#ai-text");
    const prompt = [
      "You are a civil engineering reference assistant for Indian students, inside an app called Civil Educator.",
      "Answer ONLY from the library entries given below. Never invent or guess a clause number, table number or numeric value.",
      "If the entries do not contain the answer, say clearly that it is not in the library yet and name the code the student should check.",
      "Structure every answer exactly as: Answer (2-3 sentences) / Explanation (short paragraph) / Relevant code / Clause or table reference / Source.",
      "Keep the language simple enough for a first-year diploma student. Do not use markdown headers larger than bold text.",
      "",
      "LIBRARY ENTRIES:",
      ctx || "(no matching entries)",
      "",
      "STUDENT QUESTION: " + q,
    ].join("\n");
    try {
      await ns(prompt, { modelTier: "default", onText: ({ text }) => { target.textContent = text; } });
      const links = hits.filter((e) => e.type !== "mcq").slice(0, 5).map((e) => `<a class="row" href="${hrefFor(e)}">
        <div class="row-main"><div class="row-title">${esc(e.title)}</div><div class="row-sub mono">${esc(e.sub || "")}</div></div><span class="chev">→</span></a>`).join("");
      out.insertAdjacentHTML("beforeend", `<section class="card"><h2>Entries used</h2><div class="rows">${links}</div>
        <p class="fine">Verify every clause against the latest published standard before using it for design.</p></section>`);
    } catch (e) {
      target.textContent = "The assistant could not answer just now (" + (e && e.code ? e.code : "unavailable") + "). The library entries below still cover your question.";
    }
  }

  /* -------------------------------------------------------------- admin */
  V.admin = function () {
    if (!S.admin.unlocked) {
      return `<header class="page-head"><h1>🔐 ${t("admin")}</h1>
        <p class="lede">Content management for whoever maintains this library.</p></header>
        <section class="card">
          <form data-act="pinform" class="pin-form">
            <label class="field"><span class="flabel">Admin PIN</span><input id="pin" type="password" autocomplete="off" placeholder="Enter PIN"></label>
            <button class="btn" type="submit">Unlock</button>
          </form>
          <p class="fine">Default PIN for this demo build: <code class="mono">civil2024</code>. Change it after unlocking. This gate protects the editor on this device — it is not a server-side login.</p>
        </section>`;
    }
    const counts = { codes: CODES.length, topics: TOPICS.length, tables: TABLES.length, formulas: FORMULAS.length, mcqs: MCQS.length, categories: CATS.length };
    const withLinks = CODES.filter((c) => c.documentUrl);
    const missing = CODES.filter((c) => !c.documentUrl);
    const custom = (S.admin.codes || []).length + (S.admin.topics || []).length + (S.admin.mcqs || []).length + (S.admin.tables || []).length;
    const topViews = Object.keys(S.views).sort((a, b) => S.views[b] - S.views[a]).slice(0, 8);
    return `<header class="page-head"><div class="th-top"><h1>🔐 ${t("admin")}</h1>
      <button class="btn ghost sm" data-act="lock">Lock</button></div></header>

      <section class="card stats-card">
        ${Object.keys(counts).map((k) => `<div class="stat"><span class="stat-n mono">${counts[k]}</span><span class="stat-l">${k}</span></div>`).join("")}
        <div class="stat"><span class="stat-n mono">${custom}</span><span class="stat-l">added here</span></div>
      </section>

      <section class="card">
        <h2>Add a code</h2>
        <form data-act="addcode" class="grid inputs">
          <label class="field"><span class="flabel">Code number</span><input id="a-num" placeholder="IS 1893 (Part 6)" required></label>
          <label class="field"><span class="flabel">Year / edition</span><input id="a-year" placeholder="2022"></label>
          <label class="field wide"><span class="flabel">Title</span><input id="a-title" placeholder="Full title of the standard" required></label>
          <label class="field"><span class="flabel">Category</span><select id="a-cat">${CATS.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("")}</select></label>
          <label class="field"><span class="flabel">Document type</span><select id="a-dt"><option>IS</option><option>SP</option><option>IRC</option><option>MoRTH</option><option>NBC</option><option>Reference</option></select></label>
          <label class="field"><span class="flabel">Status</span><select id="a-st"><option value="current">🟢 Current</option><option value="check" selected>🟡 Check latest edition</option><option value="withdrawn">🔴 Withdrawn / superseded</option></select></label>
          <label class="field"><span class="flabel">Official source URL</span><input id="a-src" placeholder="https://www.services.bis.gov.in/"></label>
          <label class="field wide"><span class="flabel">Summary</span><textarea id="a-sum" rows="3" placeholder="What this standard covers"></textarea></label>
          <label class="field wide"><span class="flabel">Keywords (comma separated)</span><input id="a-kw" placeholder="seismic, part 6, ..."></label>
          <label class="field wide"><span class="flabel">Contents (one per line)</span><textarea id="a-con" rows="3"></textarea></label>
          <label class="field wide"><span class="flabel">Related code IDs (comma separated)</span><input id="a-rel" placeholder="is456, is800"></label>
          <div class="row-actions wide"><button class="btn" type="submit">Add code</button></div>
        </form>
      </section>

      <section class="card">
        <h2>Add a topic (clause explanation)</h2>
        <form data-act="addtopic" class="grid inputs">
          <label class="field"><span class="flabel">Belongs to code</span><select id="t-code">${CODES.map((c) => `<option value="${c.id}">${esc(codeLabel(c))}</option>`).join("")}</select></label>
          <label class="field"><span class="flabel">Importance</span><select id="t-imp"><option value="high">High</option><option value="med" selected>Medium</option></select></label>
          <label class="field wide"><span class="flabel">Topic title</span><input id="t-title" required></label>
          <label class="field wide"><span class="flabel">Clause / table reference</span><input id="t-ref" placeholder="IS 456:2000, Cl. 26.4 and Table 16" required></label>
          <label class="field wide"><span class="flabel">What is it?</span><textarea id="t-what" rows="3" required></textarea></label>
          <label class="field wide"><span class="flabel">Why is it important?</span><textarea id="t-why" rows="2"></textarea></label>
          <label class="field wide"><span class="flabel">Example</span><textarea id="t-eg" rows="2"></textarea></label>
          <label class="field wide"><span class="flabel">Exam tip</span><textarea id="t-tip" rows="2"></textarea></label>
          <label class="field wide"><span class="flabel">Keywords (comma separated)</span><input id="t-kw"></label>
          <div class="row-actions wide"><button class="btn" type="submit">Add topic</button></div>
        </form>
      </section>

      <section class="card">
        <h2>Add a question</h2>
        <form data-act="addmcq" class="grid inputs">
          <label class="field"><span class="flabel">Code</span><select id="m-code">${CODES.map((c) => `<option value="${c.id}">${esc(codeLabel(c))}</option>`).join("")}</select></label>
          <label class="field"><span class="flabel">Correct option</span><select id="m-ans"><option value="0">A</option><option value="1">B</option><option value="2">C</option><option value="3">D</option></select></label>
          <label class="field wide"><span class="flabel">Question</span><textarea id="m-q" rows="2" required></textarea></label>
          <label class="field"><span class="flabel">Option A</span><input id="m-a" required></label>
          <label class="field"><span class="flabel">Option B</span><input id="m-b" required></label>
          <label class="field"><span class="flabel">Option C</span><input id="m-c" required></label>
          <label class="field"><span class="flabel">Option D</span><input id="m-d" required></label>
          <label class="field wide"><span class="flabel">Explanation</span><textarea id="m-e" rows="2"></textarea></label>
          <label class="field wide"><span class="flabel">Source reference</span><input id="m-r" placeholder="IS 456:2000, Cl. ..." required></label>
          <div class="row-actions wide"><button class="btn" type="submit">Add question</button></div>
        </form>
      </section>

      <section class="card">
        <h2>Add a category</h2>
        <form data-act="addcat" class="grid inputs">
          <label class="field"><span class="flabel">Name</span><input id="c-name" required></label>
          <label class="field"><span class="flabel">Icon (emoji)</span><input id="c-icon" value="📘"></label>
          <label class="field wide"><span class="flabel">Description</span><input id="c-desc"></label>
          <div class="row-actions wide"><button class="btn" type="submit">Add category</button></div>
        </form>
      </section>

      <section class="card">
        <h2>Update status or edition of an existing code</h2>
        <form data-act="editcode" class="grid inputs">
          <label class="field"><span class="flabel">Code</span><select id="e-code">${CODES.map((c) => `<option value="${c.id}">${esc(codeLabel(c))}</option>`).join("")}</select></label>
          <label class="field"><span class="flabel">New status</span><select id="e-st"><option value="">— leave unchanged —</option><option value="current">🟢 Current</option><option value="check">🟡 Check latest edition</option><option value="withdrawn">🔴 Withdrawn / superseded</option></select></label>
          <label class="field"><span class="flabel">New year</span><input id="e-year" placeholder="leave blank to keep"></label>
          <label class="field wide"><span class="flabel">New edition note</span><input id="e-ed" placeholder="leave blank to keep"></label>
          <label class="field wide"><span class="flabel">Licensed document URL (where rights exist)</span><input id="e-doc" placeholder="https://…"></label>
          <div class="row-actions wide"><button class="btn" type="submit">Apply update</button></div>
        </form>
        <p class="fine">Only upload or link documents you are licensed to distribute. This library is designed to hold metadata, indexes and original explanations — not copies of copyrighted standards.</p>
      </section>

      <section class="card">
        <h2>Direct links to standards</h2>
        <p>${withLinks.length} of ${CODES.length} codes have a direct link recorded. The rest fall back to the portal with the code number copied for the student.</p>
        <p class="fine">Open the official portal, search the code, copy the address bar URL, and paste one line per code below. Format: <code class="mono">code-id | URL</code></p>
        <form data-act="bulklinks">
          <label class="field"><span class="flabel">Paste links</span><textarea id="bl" rows="6" placeholder="is456 | https://standards.bis.gov.in/website/standard-details?encryptedId=...&#10;is800 | https://standards.bis.gov.in/website/standard-details?encryptedId=..."></textarea></label>
          <div class="row-actions"><button class="btn" type="submit">Save links</button>
            <button class="btn ghost sm" type="button" data-act="copyids">Copy the list of code ids still missing a link</button></div>
        </form>
        ${missing.length ? `<div class="tbl-wrap"><table class="data"><thead><tr><th>Code id</th><th>Code</th><th>Title</th></tr></thead><tbody>
          ${missing.slice(0, 12).map((c) => `<tr><td class="first mono">${esc(c.id)}</td><td class="mono">${esc(c.number)}</td><td>${esc(c.title.slice(0, 60))}</td></tr>`).join("")}
        </tbody></table></div>${missing.length > 12 ? `<p class="fine">…and ${missing.length - 12} more.</p>` : ""}` : ""}
      </section>

      <section class="card">
        <h2>Analytics (this device)</h2>
        ${topViews.length ? `<div class="rows">${topViews.map((k) => `<div class="row static"><div class="row-main"><div class="row-title">${esc(k)}</div><div class="row-sub mono">${S.views[k]} views</div></div></div>`).join("")}</div>` : emptyState("No usage recorded yet.")}
        <p class="fine">Usage is counted locally in the browser. A server-backed build would aggregate this across users.</p>
      </section>

      <section class="card">
        <h2>Data and access</h2>
        <form data-act="setpin" class="row-actions">
          <input id="newpin" placeholder="New admin PIN" autocomplete="off">
          <button class="btn ghost sm" type="submit">Change PIN</button>
        </form>
        <div class="row-actions">
          <button class="btn ghost sm" data-act="exportdb">Export content JSON</button>
          <button class="btn ghost sm" data-act="importdb">Import content JSON</button>
          <button class="btn ghost sm" data-act="wipeadmin">Delete content added here</button>
        </div>
        <p class="fine">Exported JSON carries the same shape as the built-in database (codes, categories, topics, tables, formulas, mcqs), so it can seed a server database later without rework.</p>
      </section>`;
  };

  /* --------------------------------------------- MATERIALS */
  V.materials = function (params) {
    if (params.id) {
      const m = (DB.materials || []).find((x) => x.id === params.id);
      if (!m) return notFound();
      track("materials", m.id, m.name, "Material");
      const sec = (title, body) => `<section class="card"><h2>${title}</h2>${body}</section>`;
      return `<nav class="crumbs mono"><a href="#/materials">Materials</a> → <span>${esc(m.name)}</span></nav>
      <header class="page-head mat-head"><div class="th-top"><h1>${m.icon} ${esc(m.name)}</h1>${saveBtn("material", m.id)}</div>
        ${m.hi ? `<p class="hi-title">${esc(m.hi)}</p>` : ""}
        <p class="lede">${esc(m.intro)}</p></header>

      ${sec("Types and where each is used", `<div class="tbl-wrap"><table class="data">
        <thead><tr><th>Type</th><th>Used for</th><th>What to know</th></tr></thead>
        <tbody>${m.types.map((x) => `<tr><td class="first">${esc(x.n)}</td><td>${esc(x.u)}</td><td>${esc(x.w)}</td></tr>`).join("")}</tbody>
      </table></div>`)}

      ${sec("Key values", `${tableBlock({ cols: m.props.cols, rows: m.props.rows })}
        ${m.props.note ? `<p class="fine">${esc(m.props.note)}</p>` : ""}${srcLine(m.props.ref)}`)}

      ${m.chem ? sec(esc(m.chem.title), `<dl class="vars">${m.chem.items.map((i) => `<dt>${esc(i.n)}</dt><dd>${esc(i.w)}</dd>`).join("")}</dl>${srcLine(m.chem.ref)}`) : ""}

      ${sec("Tests — what each one actually tells you", `<div class="tbl-wrap"><table class="data">
        <thead><tr><th>Test</th><th>What it measures</th><th>Reference</th></tr></thead>
        <tbody>${m.tests.map((x) => `<tr><td class="first">${esc(x.n)}</td><td>${esc(x.w)}</td><td class="mono">${esc(x.r)}</td></tr>`).join("")}</tbody>
      </table></div>`)}

      <section class="card q-tip"><h2>🔎 Checks you can do on site without a lab</h2>
        <div class="chk">${m.field.map((f) => `<div class="chk-row static"><span class="chk-b">
          <span class="chk-t">${esc(f.t)}</span><span class="chk-r">${esc(f.w)}</span></span></div>`).join("")}</div></section>

      ${sec("Storage and handling", `<ul class="bullets">${m.storage.map((s) => `<li>${esc(s)}</li>`).join("")}</ul>`)}

      <section class="card q-why"><h2>⚠ What goes wrong, and why</h2>
        <dl class="vars">${m.problems.map((p) => `<dt>${esc(p.t)}</dt><dd>${esc(p.w)}</dd>`).join("")}</dl></section>

      ${sec("Numbers for estimating", `<div class="results">${m.estimating.map((e) => `<div class="res">
        <span class="res-l">${esc(e.t)}</span><span class="res-v mono">${esc(e.v)}</span></div>`).join("")}</div>`)}

      ${m.topics && m.topics.length ? `<section>${sectionHead("Go deeper")}
        <div class="rows">${m.topics.map((id) => topicById(id)).filter(Boolean).map(topicRow).join("")}</div></section>` : ""}

      ${m.calcs && m.calcs.length ? `<section>${sectionHead("Calculate it")}
        <div class="grid three">${m.calcs.map((id) => CALC.list.find((c) => c.id === id)).filter(Boolean).map((c) => `<a class="card calc-card" href="#/calc/${c.id}">
          <span class="calc-name">${esc(c.name)}</span><span class="calc-f mono">${esc(String(c.formula).slice(0, 70))}…</span></a>`).join("")}</div></section>` : ""}

      ${m.codes && m.codes.length ? `<section>${sectionHead("Codes that govern this material")}
        <div class="grid codes">${m.codes.map((id) => codeById(id)).filter(Boolean).map(codeCard).join("")}</div></section>` : ""}

      <div class="row-actions">${shareBtn(m.name + " — Civil Educator")}${reportBtn("material", m.id, m.name)}</div>`;
    }
    /* Landing page, grouped. One wall of 22 cards was impossible to scan;
       five named groups of three to seven is not. */
    const cats = DB.matCategories || [];
    const of = DB.matCatOf || {};
    const all = DB.materials || [];
    const inCat = (id) => all.filter((m) => of[m.id] === id);
    return `<header class="page-head"><h1>🧱 Materials</h1>
      <p class="lede">Everything about a material in one place — types, the values that matter, every test with what it actually measures, checks you can do on site without a lab, what goes wrong, and the numbers you need for estimating.</p></header>
      ${cats.map((cat) => {
        const list = inCat(cat.id);
        if (!list.length) return "";
        return `<section>${sectionHead(cat.icon + " " + catName(cat), `<span class="more">${esc(cat.blurb)}</span>`)}
          <div class="grid three">${list.map(matCard).join("")}</div></section>`;
      }).join("")}
      <section class="card notice"><p><strong>Why this section exists.</strong> A standard states requirements; it does not teach a material. These pages explain what the requirements mean, how each is checked, and what goes wrong when they are ignored — so you can work from here rather than hunting through several codes at once.</p></section>`;
  };

  function matCard(m) {
    return `<a class="card cat-card" href="#/materials/${m.id}">
      <span class="cat-ico" aria-hidden="true">${m.icon}</span>
      <span class="cat-name">${esc(m.name)}</span>
      <span class="cat-blurb">${esc(m.blurb)}</span>
      <span class="cat-count mono">${m.tests.length} tests · ${m.field.length} field checks</span></a>`;
  }

  /* #/matcat/<id> — one material group on its own page, so the sidebar can
     link straight into it the same way the code categories do. */
  V.matcat = function (params) {
    const cat = (DB.matCategories || []).find((c) => c.id === params.id);
    if (!cat) return notFound();
    const list = (DB.materials || []).filter((m) => (DB.matCatOf || {})[m.id] === cat.id);
    return `<nav class="crumbs mono"><a href="#/materials">Materials</a> → <span>${esc(catName(cat))}</span></nav>
      <header class="page-head"><h1>${cat.icon} ${esc(catName(cat))}</h1>
        <p class="lede">${esc(cat.blurb)}. ${list.length} guide${list.length === 1 ? "" : "s"}.</p></header>
      <div class="grid three">${list.map(matCard).join("")}</div>
      <section><a class="btn ghost" href="#/materials">← All materials</a></section>`;
  };

  /* =============================================== SUBJECT MODE
     The library is filed by IS code. A student's semester is filed by
     subject and unit. data-subjects.js is the map between the two; these
     two views are the only places that read it.

     Nothing here invents content — every id is looked up in the arrays
     that already exist, and an id that does not resolve is dropped
     silently rather than rendered as a dead link. Units we have nothing
     for are still shown, marked "not covered yet", because a student who
     finds that out on the night before the exam trusts the app less than
     one who was told upfront.                                          */

  const SUBJECTS = () => DB.subjects || [];
  const subjectById = (id) => SUBJECTS().find((s) => s.id === id);

  /* Every topic a subject touches, deduped and in unit order. */
  function subjectTopics(sub) {
    const seen = {}, out = [];
    sub.units.forEach((u) => (u.topics || []).forEach((id) => {
      if (seen[id]) return; seen[id] = 1;
      const tp = topicById(id); if (tp) out.push(tp);
    }));
    return out;
  }
  /* Questions are matched on topic, not on code. Matching on code would
     drag all of IS 456 into Geotechnical Engineering just because footings
     live in IS 456 — the subject quiz has to mean the subject. */
  function subjectMcqs(sub) {
    const ids = {};
    subjectTopics(sub).forEach((tp) => { ids[tp.id] = 1; });
    return MCQS.filter((q) => ids[q.topic]);
  }
  const RES = {
    topics: { icon: "\u{1F4C4}", href: (id) => "#/topic/" + id, get: (id) => topicById(id), name: (x) => (S.lang === "hi" && x.hi ? x.hi : x.title) },
    mats: { icon: "\u{1F9F1}", href: (id) => "#/materials/" + id, get: (id) => (DB.materials || []).find((m) => m.id === id), name: (x) => x.name },
    calcs: { icon: "\u{1F9EE}", href: (id) => "#/calc/" + id, get: (id) => CALC.list.find((c) => c.id === id), name: (x) => x.name },
    ex: { icon: "✏️", href: (id) => "#/examples/" + id, get: (id) => (DB.examples || []).find((e) => e.id === id), name: (x) => x.title },
    tables: { icon: "\u{1F4CA}", href: (id) => "#/table/" + id, get: (id) => tableById(id), name: (x) => x.title },
    formulas: { icon: "∑", href: (id) => "#/formulas", get: (id) => FORMULAS.find((f) => f.id === id), name: (x) => x.title },
    checks: { icon: "✓", href: (id) => "#/checklists/" + id, get: (id) => (DB.checklists || []).find((c) => c.id === id), name: (x) => x.title },
    cmps: { icon: "⚖️", href: (id) => "#/compare/" + id, get: (id) => (DB.compares || []).find((c) => c.id === id), name: (x) => x.title },
  };
  const RES_ORDER = ["mats", "calcs", "ex", "tables", "formulas", "checks", "cmps"];

  /* How much of a unit actually exists, counted the same way everywhere. */
  function unitCount(u) {
    let n = 0;
    Object.keys(RES).forEach((k) => (u[k] || []).forEach((id) => { if (RES[k].get(id)) n++; }));
    if (unitChapter(u)) n++;
    return n;
  }
  /* The handbook chapter a unit belongs to, if its subject has a handbook. */
  function unitChapter(u, sub) {
    if (!u.ch) return null;
    const hb = (DB.handbooks || []).find((h) => h.subject === (sub ? sub.id : (u.__sub || "")));
    const any = hb || (DB.handbooks || []).find((h) => h.chapters.some((c) => c.n === u.ch));
    return any ? { hb: any, ch: any.chapters.find((c) => c.n === u.ch) } : null;
  }
  function subjectStats(sub) {
    const st = { units: sub.units.length, covered: 0, items: 0 };
    sub.units.forEach((u) => { const n = unitCount(u); st.items += n; if (n) st.covered++; });
    st.topics = subjectTopics(sub).length;
    st.mcqs = subjectMcqs(sub).length;
    return st;
  }

  function resChips(u) {
    const out = [];
    RES_ORDER.forEach((k) => (u[k] || []).forEach((id) => {
      const r = RES[k], x = r.get(id);
      if (!x) return;
      out.push(`<a class="res" href="${r.href(id)}"><span class="res-i" aria-hidden="true">${r.icon}</span>${esc(r.name(x))}</a>`);
    }));
    return out.length ? `<div class="res-chips">${out.join("")}</div>` : "";
  }

  V.subjects = function () {
    const hi = S.lang === "hi";
    return `<header class="page-head"><h1>\u{1F393} ${esc(hi ? "विषय" : "Subjects")}</h1>
      <p class="lede">${hi
        ? "अपना विषय चुनिए — यूनिट के हिसाब से विषय, सामग्री, कैलकुलेटर और हल किए उदाहरण एक जगह।"
        : "The same library, arranged the way your semester is. Pick a subject and every unit shows the topics, materials, calculators and solved examples that belong to it."}</p></header>

      <div class="grid three">${SUBJECTS().map((sub) => {
        const st = subjectStats(sub);
        return `<a class="card sub-card" href="#/subject/${sub.id}">
          <span class="sub-ico" aria-hidden="true">${sub.icon}</span>
          <span class="sub-name">${esc(hi && sub.hi ? sub.hi : sub.name)}</span>
          <span class="sub-sem mono">${esc(sub.sem)}</span>
          <span class="cat-blurb">${esc(sub.blurb)}</span>
          <span class="sub-bar"><span style="width:${Math.round((100 * st.covered) / st.units)}%"></span></span>
          <span class="cat-count mono">${st.covered}/${st.units} units · ${st.items} items · ${st.mcqs} MCQ</span></a>`;
      }).join("")}</div>

      <section class="card notice-card"><h2>${esc(hi ? "जो अभी नहीं है" : "Not in this app yet")}</h2>
        <p>${hi
          ? "ये विषय अभी इस लाइब्रेरी में नहीं हैं, क्योंकि ये IS कोड से नहीं, डेरिवेशन से बनते हैं।"
          : "These are taught from derivations rather than from standards, so a code library has little to offer on them. Saying so here is better than letting you find out the night before the exam."}</p>
        <div class="chips">${(DB.subjectsMissing || []).map((m) => `<span class="chip static">${esc(m)}</span>`).join("")}</div>
      </section>`;
  };

  /* A unit is the page a student actually studies from, so it has to carry
     something the code pages do not. Three things do that here: the at-a-
     glance sheet (every topic's "Remember" line on one screen, which is what
     you read the night before), the numbers and formulas rendered inline so
     nothing has to be opened, and a quiz scoped to this unit alone.
     Without those, Subject Mode is only a second menu onto the same pages. */

  function unitOf(sub, n) {
    const i = parseInt(n, 10) - 1;
    return i >= 0 && i < sub.units.length ? sub.units[i] : null;
  }
  function unitTopics(u) { return (u.topics || []).map(topicById).filter(Boolean); }
  function unitRead(u) {
    const read = S.stats.topicsRead || [];
    return unitTopics(u).filter((tp) => read.includes(tp.id)).length;
  }
  function unitMcqs(u) {
    const ids = {};
    unitTopics(u).forEach((tp) => { ids[tp.id] = 1; });
    return MCQS.filter((q) => ids[q.topic]);
  }
  const unitName = (u) => (S.lang === "hi" && u.hi ? u.hi : u.t);
  /* Tips are written in both languages; fall back rather than show nothing. */
  function tipOf(tp) {
    const h = S.lang === "hi" ? (DB.hindi || {})[tp.id] : null;
    return (h && h.tip) || tp.tip || "";
  }

  V.subject = function (params) {
    const sub = subjectById(params.id);
    if (!sub) return notFound();
    const hi = S.lang === "hi";
    const name = hi && sub.hi ? sub.hi : sub.name;
    track("subject", sub.id, name, hi ? "विषय" : "Subject");
    const st = subjectStats(sub);
    const thin = st.covered < st.units;
    const readAll = sub.units.reduce((a, u) => a + unitRead(u), 0);

    return `<nav class="crumbs mono"><a href="#/subjects">${esc(hi ? "विषय" : "Subjects")}</a> → <span>${esc(name)}</span></nav>
      <header class="page-head"><div class="th-top"><h1>${sub.icon} ${esc(name)}</h1>${saveBtn("subject", sub.id)}</div>
        <p class="ref-badge mono">${esc(sub.sem)}${sub.also ? " · " + esc(sub.also) : ""}</p>
        <p class="lede">${esc(sub.blurb)}</p></header>

      <section class="card stats-card">
        <div class="stat"><span class="stat-n mono">${st.covered}/${st.units}</span><span class="stat-l">${esc(hi ? "यूनिट" : "Units covered")}</span></div>
        <div class="stat"><span class="stat-n mono">${readAll}/${st.topics}</span><span class="stat-l">${esc(hi ? "पढ़े गए" : "Topics read")}</span></div>
        <div class="stat"><span class="stat-n mono">${st.items}</span><span class="stat-l">${esc(hi ? "सामग्री" : "Resources")}</span></div>
        <div class="stat"><span class="stat-n mono">${st.mcqs}</span><span class="stat-l">MCQ</span></div>
        <div class="bar"><span style="width:${st.topics ? Math.round((100 * readAll) / st.topics) : 0}%"></span></div>
      </section>

      ${st.mcqs ? `<section class="card cta-card"><div><h2>${esc(hi ? "पूरे विषय की प्रैक्टिस" : "Practice the whole subject")}</h2>
        <p>${hi
          ? st.mcqs + " प्रश्न, सिर्फ़ इसी विषय के टॉपिक से" + (S.stats.bestQuiz["sub-" + sub.id] ? "। अब तक सबसे अच्छा: " + S.stats.bestQuiz["sub-" + sub.id] + "%" : "") + "।"
          : st.mcqs + " question" + (st.mcqs === 1 ? "" : "s") + " drawn only from this subject's topics" + (S.stats.bestQuiz["sub-" + sub.id] ? ". Your best so far: " + S.stats.bestQuiz["sub-" + sub.id] + "%" : "") + "."}</p></div>
        <a class="btn" href="#/exam/quiz/sub-${sub.id}">${esc(hi ? "शुरू करें" : "Start")} →</a></section>` : ""}

      ${(DB.handbooks || []).filter((h) => h.subject === sub.id).map((hb) => `<section class="card cta-card">
        <div><h2>${esc(hi ? "पूरी हैंडबुक पढ़ें" : "Read the full handbook")}</h2>
        <p>${esc(hi
          ? hb.chapters.length + " अध्याय, शुरू से आख़िर तक पढ़ने के लिए — derivation, diagram और हल किए गए उदाहरण के साथ।"
          : hb.chapters.length + " chapter" + (hb.chapters.length === 1 ? "" : "s") + " written to be read in order — derivations, diagrams and worked examples, no shortcuts.")}</p></div>
        <a class="btn" href="#/handbook/${hb.id}">${esc(hi ? "खोलें" : "Open")} →</a></section>`).join("")}

      <section>${sectionHead(hi ? "यूनिट" : "Units")}
        <div class="rows">${sub.units.map((u, i) => {
          const n = unitCount(u);
          const tps = unitTopics(u).length;
          const done = unitRead(u);
          const q = unitMcqs(u).length;
          const bits = [];
          if (tps) bits.push(tps + (hi ? " टॉपिक" : " topic" + (tps === 1 ? "" : "s")));
          if (q) bits.push(q + " MCQ");
          return `<a class="row unit-row" href="#/unit/${sub.id}/${i + 1}">
            <span class="ui-n mono">${i + 1}</span>
            <div class="row-main">
              <div class="row-title">${esc(unitName(u))}</div>
              <div class="row-sub mono">${n ? esc(bits.join(" · ")) : esc(hi ? "अभी सामग्री नहीं" : "nothing written yet")}</div>
            </div>
            ${tps ? `<span class="u-done mono${done === tps ? " all" : ""}">${done}/${tps}</span>` : ""}
            <span class="chev">→</span></a>`;
        }).join("")}</div></section>

      ${thin ? `<section class="notice"><p><strong>${esc(hi ? "ईमानदार बात।" : "Honest note.")}</strong> ${esc(hi
        ? "यह ऐप IS कोड से बनी है, इसलिए डेरिवेशन वाले यूनिट खाली हैं। इसे किताब की जगह नहीं, साथ में रखें।"
        : "This library is built from IS codes, so units that are pure theory or derivation are empty. Use it alongside your textbook, not instead of it.")}</p>
        <a class="more" href="#/subjects">All subjects →</a></section>` : ""}`;
  };

  V.unit = function (params) {
    const sub = subjectById(params.id);
    if (!sub) return notFound();
    const n = parseInt(params.u, 10);
    const u = unitOf(sub, params.u);
    if (!u) return notFound();
    const hi = S.lang === "hi";
    const subName = hi && sub.hi ? sub.hi : sub.name;
    const title = unitName(u);
    track("unit", sub.id + "/" + n, title, subName);

    const tps = unitTopics(u);
    const done = unitRead(u);
    const tbs = (u.tables || []).map(tableById).filter(Boolean);
    const fms = (u.formulas || []).map((id) => FORMULAS.find((f) => f.id === id)).filter(Boolean);
    const exs = (u.ex || []).map((id) => (DB.examples || []).find((e) => e.id === id)).filter(Boolean);
    const cls = (u.calcs || []).map((id) => CALC.list.find((c) => c.id === id)).filter(Boolean);
    const mts = (u.mats || []).map((id) => (DB.materials || []).find((m) => m.id === id)).filter(Boolean);
    const cks = (u.checks || []).map((id) => (DB.checklists || []).find((c) => c.id === id)).filter(Boolean);
    const cps = (u.cmps || []).map((id) => (DB.compares || []).find((c) => c.id === id)).filter(Boolean);
    const qs = unitMcqs(u);
    const empty = !unitCount(u);

    const prev = n > 1 ? n - 1 : 0;
    const next = n < sub.units.length ? n + 1 : 0;
    const pager = `<div class="unit-pager">
      ${prev ? `<a class="btn ghost sm" href="#/unit/${sub.id}/${prev}">← ${esc(hi ? "पिछला" : "Unit " + prev)}</a>` : `<span></span>`}
      <a class="btn ghost sm" href="#/subject/${sub.id}">${esc(hi ? "सभी यूनिट" : "All units")}</a>
      ${next ? `<a class="btn ghost sm" href="#/unit/${sub.id}/${next}">${esc(hi ? "अगला" : "Unit " + next)} →</a>` : `<span></span>`}</div>`;

    return `<nav class="crumbs mono"><a href="#/subjects">${esc(hi ? "विषय" : "Subjects")}</a> →
      <a href="#/subject/${sub.id}">${esc(subName)}</a> → <span>${esc(hi ? "यूनिट " + n : "Unit " + n)}</span></nav>
      <header class="page-head"><div class="th-top"><h1>${esc(title)}</h1></div>
        <p class="ref-badge mono">${sub.icon} ${esc(subName)} · ${esc(hi ? "यूनिट " + n + " / " + sub.units.length : "Unit " + n + " of " + sub.units.length)}</p>
        ${tps.length ? `<div class="u-prog"><div class="bar"><span style="width:${Math.round((100 * done) / tps.length)}%"></span></div>
          <p class="fine">${esc(hi ? done + " / " + tps.length + " टॉपिक पढ़ लिए" : done + " of " + tps.length + " topics read")}</p></div>` : ""}</header>

      ${(function () {
        const c = unitChapter(u, sub);
        if (!c || !c.ch) return "";
        return `<section class="card cta-card hb-cta"><div>
          <h2>${esc(hi ? "अध्याय " + c.ch.n + " — पूरा पढ़ें" : "Chapter " + c.ch.n + " — read it in full")}</h2>
          <p>${esc(hi && c.ch.hi ? c.ch.hi : c.ch.title)} · ${c.ch.sections.length} ${esc(hi ? "अनुभाग" : "sections")}${c.ch.mins ? " · " + c.ch.mins + " min" : ""}${hbRead(c.hb.id, c.ch.n) ? (hi ? " · पढ़ लिया ✓" : " · read ✓") : ""}</p></div>
          <a class="btn" href="#/read/${c.hb.id}/${c.ch.n}">${esc(hi ? "खोलें" : "Open")} →</a></section>`;
      })()}

      ${empty ? `<div class="card unit-empty"><p>${esc(hi
          ? "इस यूनिट पर अभी सामग्री नहीं है। अपनी किताब या नोट्स देखें — हम खाली पन्ना भरने के लिए कुछ गढ़ना नहीं चाहते।"
          : "Nothing written for this unit yet. Use your textbook or notes for it — we would rather say so than pad the page.")}</p></div>${pager}` : ""}

      ${tps.length ? `<section>${sectionHead(hi ? "एक नज़र में" : "At a glance",
        `<span class="sec-note">${esc(hi ? "परीक्षा से पहले यही पढ़ें" : "read this the night before")}</span>`)}
        <div class="glance">${tps.map((tp) => `<article class="card gl">
          <h3><a href="#/topic/${tp.id}">${esc(S.lang === "hi" && tp.hi ? tp.hi : tp.title)}</a>${tp.importance === "high" ? '<span class="imp" title="High importance">●</span>' : ""}</h3>
          <p class="gl-tip">${esc(tipOf(tp))}</p>
          <p class="src"><span class="src-k">${esc(hi ? "संदर्भ" : "Source")}</span> ${esc(tp.ref)}</p>
        </article>`).join("")}</div></section>` : ""}

      ${tbs.length ? `<section>${sectionHead(hi ? "याद रखने लायक मान" : "The values you need")}
        ${tbs.map((tb) => `<div class="card tbl-card"><h3><a href="#/table/${tb.id}">${esc(tb.title)}</a></h3>
          ${tableBlock(tb)}<p class="src"><span class="src-k">${esc(hi ? "संदर्भ" : "Source")}</span> ${esc(tb.ref)}</p></div>`).join("")}</section>` : ""}

      ${fms.length ? `<section>${sectionHead(hi ? "सूत्र" : "Formulas")}
        <div class="rows">${fms.map((f) => `<a class="row" href="#/formulas">
          <div class="row-main"><div class="row-title mono fx">${esc(f.expr)}</div>
          <div class="row-sub">${esc(f.title)} · <span class="mono">${esc(f.ref)}</span></div></div><span class="chev">→</span></a>`).join("")}</div></section>` : ""}

      ${qs.length ? `<section class="card cta-card"><div><h2>${esc(hi ? "इसी यूनिट की प्रैक्टिस" : "Practice just this unit")}</h2>
        <p>${hi ? qs.length + " प्रश्न, सिर्फ़ इसी यूनिट से" + (S.stats.bestQuiz["unit-" + sub.id + "-" + n] ? "। अब तक सबसे अच्छा: " + S.stats.bestQuiz["unit-" + sub.id + "-" + n] + "%" : "") + "।"
          : qs.length + " question" + (qs.length === 1 ? "" : "s") + " from this unit only" + (S.stats.bestQuiz["unit-" + sub.id + "-" + n] ? ". Your best so far: " + S.stats.bestQuiz["unit-" + sub.id + "-" + n] + "%" : "") + "."}</p></div>
        <a class="btn" href="#/exam/quiz/unit-${sub.id}-${n}">${esc(hi ? "शुरू करें" : "Start")} →</a></section>` : ""}

      ${exs.length ? `<section>${sectionHead(hi ? "हल किए गए सवाल" : "Solved numericals")}
        <div class="rows">${exs.map((x) => `<a class="row" href="#/examples/${x.id}">
          <div class="row-main"><div class="row-title">${esc(x.title)}</div>
          <div class="row-sub mono">${x.steps.length} ${esc(hi ? "चरण" : "steps")} · ${esc(x.level)}</div></div><span class="chev">→</span></a>`).join("")}</div></section>` : ""}

      ${cls.length ? `<section>${sectionHead(hi ? "कैलकुलेटर" : "Calculators")}
        <div class="res-chips">${cls.map((c) => `<a class="res" href="#/calc/${c.id}"><span class="res-i" aria-hidden="true">🧮</span>${esc(c.name)}</a>`).join("")}</div></section>` : ""}

      ${(mts.length || cks.length || cps.length) ? `<section>${sectionHead(hi ? "साथ में देखें" : "Also for this unit")}
        <div class="res-chips">
          ${mts.map((m) => `<a class="res" href="#/materials/${m.id}"><span class="res-i" aria-hidden="true">🧱</span>${esc(m.name)}</a>`).join("")}
          ${cks.map((c) => `<a class="res" href="#/checklists/${c.id}"><span class="res-i" aria-hidden="true">✓</span>${esc(c.title)}</a>`).join("")}
          ${cps.map((c) => `<a class="res" href="#/compare/${c.id}"><span class="res-i" aria-hidden="true">⚖️</span>${esc(c.title)}</a>`).join("")}
        </div></section>` : ""}

      ${tps.length ? `<section>${sectionHead(hi ? "पूरी व्याख्या पढ़ें" : "Read the full explanation")}
        <div class="rows">${tps.map(topicRow).join("")}</div></section>` : ""}

      ${empty ? "" : pager}`;
  };

  /* ================================================ HANDBOOK READER
     Topic pages answer a question and end. A handbook is read straight
     through, so this view is built for continuous reading: the chapter
     is one long page, blocks in the order they were written, with a
     section list at the top for finding your way back.

     Section jumps scroll the page rather than writing "#1.6" into the
     hash. This app is a hash router — a bare "#..." anchor would be
     read as a view name and render Not found. That bug shipped once
     already; _hashes.js now sweeps every view for it.                */

  const HANDBOOKS = () => DB.handbooks || [];
  const hbById = (id) => HANDBOOKS().find((h) => h.id === id);
  function chapterOf(hb, n) {
    const i = parseInt(n, 10);
    return hb.chapters.find((c) => c.n === i) || null;
  }
  function hbReadKey(hbId, chN) { return "hb:" + hbId + ":" + chN; }
  function hbRead(hbId, chN) { return !!(S.views || {})[hbReadKey(hbId, chN)]; }

  /* One block of a chapter. Anything unknown is skipped rather than
     rendered as an empty box, so a half-written chapter still reads. */
  function hbBlock(b) {
    const hi = S.lang === "hi";
    switch (b.k) {
      case "p": return `<p class="hb-p">${b.t}</p>`;
      case "h": return `<h3 class="hb-h">${esc(b.t)}</h3>`;
      case "def": return `<div class="hb-def"><span class="hb-def-t">${esc(b.term)}</span><p>${b.t}</p></div>`;
      case "note": return `<div class="hb-note"><span class="hb-k">${esc(hi ? "ध्यान दें" : "Note")}</span><p>${b.t}</p></div>`;
      case "trap": return `<div class="hb-trap"><span class="hb-k">${esc(hi ? "यहीं ग़लती होती है" : "Where it goes wrong")}</span><p>${b.t}</p></div>`;
      /* Side-by-side comparison. b.cols = column headings (2 or 3),
         b.rows = [[rowLabel, cellA, cellB, ...], ...]. Renders as a real
         table on a wide screen and as stacked cards on a phone, because a
         3-column table at 360px is unreadable and this app is mobile-first. */
      case "cmp": {
        const cols = b.cols || [];
        const rows = b.rows || [];
        return `<div class="hb-cmp">${b.t ? `<p class="hb-cmp-t">${esc(b.t)}</p>` : ""}
          <table class="hb-cmp-tb"><thead><tr><th></th>${cols.map((c, i) =>
            `<th class="${i === 0 ? "c-a" : "c-b"}">${esc(c)}</th>`).join("")}</tr></thead>
          <tbody>${rows.map((r) => `<tr><th scope="row">${r[0]}</th>${
            r.slice(1).map((c, i) => `<td class="${i === 0 ? "c-a" : "c-b"}">${c}</td>`).join("")}</tr>`).join("")}</tbody></table>
          <div class="hb-cmp-rows">${rows.map((r) => `<div class="hb-cmp-row">
            <p class="r-lbl">${r[0]}</p>
            <div class="r-vals" style="--n:${cols.length}">${cols.map((c, i) => `<div class="${i === 0 ? "c-a" : "c-b"}">
              <b>${esc(c)}</b><p>${r[i + 1] || "—"}</p></div>`).join("")}</div></div>`).join("")}</div></div>`;
      }
      /* Where you actually meet this on a site. Kept deliberately concrete —
         a named building element, not a restatement of the theory. */
      case "real": return `<div class="hb-real"><span class="hb-k">${
        esc(hi ? "असल में कहाँ दिखेगा" : "Where you'll meet this")}</span><p>${b.t}</p></div>`;
      case "list": return `<ul class="hb-list">${(b.items || []).map((x) => `<li>${x}</li>`).join("")}</ul>`;
      case "steps": return `<ol class="hb-steps">${(b.items || []).map((x) => `<li>${x}</li>`).join("")}</ol>`;
      case "eq": return `<div class="hb-eq"><p class="hb-expr mono">${esc(b.expr)}</p>${
        (b.where || []).length ? `<dl class="hb-where">${b.where.map(([k, v]) => `<dt class="mono">${esc(k)}</dt><dd>${esc(v)}</dd>`).join("")}</dl>` : ""}</div>`;
      case "dia": {
        const d = (DB.diagrams || {})[b.id];
        if (!d) return "";
        return `<figure class="dia hb-dia${d.anim ? " is-anim" : ""}">${d.svg}<figcaption>${b.cap || d.caption || ""}</figcaption></figure>`;
      }
      case "tbl": {
        const tb = tableById(b.id);
        if (!tb) return "";
        return `<div class="card hb-tbl"><h4><a href="#/table/${tb.id}">${esc(tb.title)}</a></h4>${tableBlock(tb)}
          ${tb.note ? `<p class="fine">${esc(tb.note)}</p>` : ""}
          <p class="src"><span class="src-k">${esc(hi ? "संदर्भ" : "Source")}</span> ${esc(tb.ref)}</p></div>`;
      }
      case "eg": return `<section class="card hb-eg">
        <h4>${esc(b.title)}</h4>
        <p class="hb-given"><span class="hb-k">${esc(hi ? "दिया है" : "Given")}</span> ${esc(b.given)}</p>
        <ol class="hb-egsteps">${(b.steps || []).map((st) => `<li>
          <p class="hb-egt">${esc(st.t)}</p><pre class="ex-work">${esc(st.w)}</pre></li>`).join("")}</ol>
        <p class="hb-ans"><span class="hb-k">${esc(hi ? "उत्तर" : "Answer")}</span> ${esc(b.ans)}</p></section>`;
      default: return "";
    }
  }

  /* ============================================================
     COURSE MAP — semester → subject → topic
     A broad B.Tech Civil master structure for the handbook, not
     any one university's syllabus. Every subject shows honestly
     whether a handbook covers it, whether it is only covered
     inside another handbook, whether the class notes are here but
     the handbook is not written yet, or whether it is still only
     planned. A planned subject links to nothing, on purpose.
     ============================================================ */
  const SEMS = () => DB.semesters || [];
  const allCourseSubs = () =>
    SEMS().reduce((a, sm) => a.concat((sm.subjects || []).map((x) => Object.assign({ sem: sm.n }, x))), [])
      .concat((DB.courseExtra || []).map((x) => Object.assign({ sem: 0 }, x)));
  const csubById = (id) => allCourseSubs().filter((x) => x.id === id)[0];
  const ST = {
    ready: ["\u{1F4D7}", "Handbook ready", "हैंडबुक तैयार"],
    partial: ["\u{1F4D9}", "Partly covered", "आंशिक रूप से"],
    notes: ["\u{1F4E5}", "Notes uploaded", "नोट्स आ चुके हैं"],
    planned: ["⚪", "Planned", "प्रस्तावित"]
  };
  const stOf = (x) => (x.hb && x.status === "ready" ? "ready" : x.status || (x.hb ? "partial" : "planned"));
  const stPill = (x) => { const v = ST[stOf(x)]; return `<span class="chip static">${v[0]} ${esc(S.lang === "hi" ? v[2] : v[1])}</span>`; };
  const hbOf = (x) => (x.hb ? (DB.handbooks || []).filter((h) => h.id === x.hb)[0] : null);

  V.courses = function () {
    const hi = S.lang === "hi";
    const subs = allCourseSubs();
    const n = (k) => subs.filter((x) => stOf(x) === k).length;
    return `<header class="page-head"><h1>\u{1F393} ${esc(hi ? "बी.टेक सिविल — पूरा कोर्स" : "B.Tech Civil — Master Course")}</h1>
      <p class="lede">${hi
        ? "आठ सेमेस्टर, हर सेमेस्टर के पेपर, और हर पेपर के टॉपिक। यह किसी एक यूनिवर्सिटी का सिलेबस नहीं है।"
        : "Eight semesters, the papers in each, and the topics in each paper. This is a broad academic and practical master structure for the handbook — not any one university's syllabus, so where yours differs, read the topic list rather than the semester number."}</p></header>

      <section class="card"><h2>${esc(hi ? "अभी कहाँ तक बना है" : "Where the handbook stands today")}</h2>
        <div class="chips">
          <span class="chip static">\u{1F4D7} ${n("ready")} ${esc(hi ? "पेपर पूरे" : "papers with a handbook")}</span>
          <span class="chip static">\u{1F4D9} ${n("partial")} ${esc(hi ? "आंशिक" : "partly covered")}</span>
          <span class="chip static">\u{1F4E5} ${n("notes")} ${esc(hi ? "नोट्स आ चुके" : "notes uploaded, not built")}</span>
          <span class="chip static">⚪ ${n("planned")} ${esc(hi ? "प्रस्तावित" : "planned")}</span>
        </div>
        <p class="fine">${esc(hi
          ? "जो लिखा नहीं गया, उसे यहाँ साफ़-साफ़ बताया गया है।"
          : "A paper that has not been written is marked as such here rather than linked to something thin. That is deliberate.")}</p>
      </section>

      <div class="grid three">${SEMS().map((sm) => {
        const r = (sm.subjects || []).filter((x) => stOf(x) === "ready").length;
        return `<a class="card sub-card" href="#/sem/${sm.n}">
          <span class="sub-ico" aria-hidden="true">${sm.n}</span>
          <span class="sub-name">${esc(hi && sm.hi ? sm.hi : sm.name)}</span>
          <span class="sub-sem mono">Semester ${sm.n}</span>
          <span class="cat-blurb">${esc(sm.blurb)}</span>
          <span class="sub-bar"><span style="width:${Math.round((100 * r) / (sm.subjects || []).length)}%"></span></span>
          <span class="cat-count mono">${(sm.subjects || []).length} papers · ${r} with a handbook</span></a>`;
      }).join("")}</div>

      <section class="card"><h2>${esc(hi ? "हर टॉपिक का रास्ता" : "How every topic is meant to read")}</h2>
        <p>${esc(hi
          ? "सिर्फ सेमेस्टर नोट्स नहीं — सेमेस्टर से साइट तक।"
          : "Not semester notes — the chain runs from the semester all the way to the site.")}</p>
        <ol class="steps">${(DB.courseFlow || []).map((f) => `<li><b>${esc(f[0])}</b> — ${esc(f[1])}</li>`).join("")}</ol>
      </section>

      ${(DB.courseExtra || []).length ? `<section class="card"><h2>${esc(hi ? "सेमेस्टर के बाहर" : "Outside the semester grid")}</h2>
        <div class="rows">${(DB.courseExtra || []).map((x) => `<a class="row" href="#/csub/${x.id}"><div class="row-main"><div class="row-title">${esc(x.name)}</div><div class="row-sub">${esc(x.summary || "")}</div></div><span class="chev">→</span></a>`).join("")}</div>
      </section>` : ""}`;
  };

  V.sem = function (params) {
    const sm = SEMS().filter((x) => String(x.n) === String(params.id))[0];
    if (!sm) return notFound();
    const hi = S.lang === "hi";
    return `<nav class="crumb"><a href="#/courses">${esc(hi ? "पूरा कोर्स" : "Master course")}</a> <span>›</span> Semester ${sm.n}</nav>
      <header class="page-head"><h1>${sm.n}. ${esc(hi && sm.hi ? sm.hi : sm.name)}</h1>
      <p class="lede">${esc(sm.blurb)}</p></header>
      <div class="rows">${(sm.subjects || []).map((x) => `<a class="row" href="#/csub/${x.id}">
        <div class="row-main">
          <div class="row-title">${esc(hi && x.hi ? x.hi : x.name)}</div>
          <div class="row-sub">${esc(x.summary || "")}</div>
          <div class="chips">${stPill(x)}<span class="chip static">${(x.topics || []).length} topics</span></div>
        </div><span class="chev">→</span></a>`).join("")}</div>`;
  };

  V.csub = function (params) {
    const x = csubById(params.id);
    if (!x) return notFound();
    const hi = S.lang === "hi";
    const hb = hbOf(x);
    const sm = SEMS().filter((s) => s.n === x.sem)[0];
    const st = stOf(x);
    return `<nav class="crumb"><a href="#/courses">${esc(hi ? "पूरा कोर्स" : "Master course")}</a>${sm ? ` <span>›</span> <a href="#/sem/${sm.n}">Semester ${sm.n}</a>` : ""}</nav>
      <header class="page-head"><h1>${esc(hi && x.hi ? x.hi : x.name)}</h1>
      <p class="lede">${esc(x.summary || "")}</p>
      <div class="chips">${stPill(x)}<span class="chip static">${(x.topics || []).length} topics</span></div></header>

      ${hb ? `<section class="card"><h2>${esc(hi ? "इस एप में पढ़ें" : "Read it in this app")}</h2>
        <a class="row" href="#/handbook/${hb.id}"><div class="row-main"><div class="row-title">${hb.icon} ${esc(hb.name)}</div><div class="row-sub mono">${hb.chapters.length} chapters</div></div><span class="chev">→</span></a>
        ${x.note ? `<p class="fine">${esc(x.note)}</p>` : ""}
      </section>` : st === "notes" ? `<section class="card notice-card"><h2>${esc(hi ? "नोट्स आ चुके हैं, हैंडबुक बननी बाकी" : "Notes are in, handbook not built yet")}</h2>
        <p>${esc(hi ? "इस पेपर के क्लास नोट्स अपलोड हो चुके हैं।" : "The class notes for this paper are uploaded. The handbook is next in the queue, and until it exists this page does not pretend otherwise.")}</p>
        ${x.src ? `<div class="chips"><span class="chip static">${esc(x.src)}</span></div>` : ""}
      </section>` : `<section class="card notice-card"><h2>${esc(hi ? "अभी नहीं लिखा गया" : "Not written yet")}</h2>
        <p>${esc(hi ? "इस पेपर का स्ट्रक्चर यहाँ है, लेकिन सामग्री अभी नहीं।" : "The structure is here so you can see where it fits, but no content has been written for it. Listing a topic is not the same as covering it.")}</p>
      </section>`}

      <section class="card"><h2>${esc(hi ? "टॉपिक" : "Topics")}</h2>
        <div class="chips">${(x.topics || []).map((tp) => `<span class="chip static">${esc(tp)}</span>`).join("")}</div>
      </section>

      ${x.flow === "material" ? `<section class="card"><h2>${esc(hi ? "हर मटेरियल का क्रम" : "The order every material follows")}</h2>
        <ol class="steps">${(DB.materialFlow || []).map((f) => `<li>${esc(f)}</li>`).join("")}</ol></section>` : ""}

      <section class="card"><h2>${esc(hi ? "टॉपिक कैसे पढ़ा जाए" : "How a topic reads")}</h2>
        <ol class="steps">${(DB.courseFlow || []).slice(3).map((f) => `<li><b>${esc(f[0])}</b> — ${esc(f[1])}</li>`).join("")}</ol></section>`;
  };

  V.handbooks = function () {
    const hi = S.lang === "hi";
    if (!HANDBOOKS().length) return emptyState(hi ? "अभी कोई हैंडबुक नहीं है।" : "No handbook yet.");
    return `<header class="page-head"><h1>📖 ${esc(hi ? "हैंडबुक" : "Handbooks")}</h1>
      <p class="lede">${esc(hi
        ? "पढ़ने के लिए लिखी गई किताब — शुरू से आख़िर तक, हर method की derivation और हल किए गए उदाहरण के साथ। Reference card की तरह नहीं।"
        : "Written to be read start to finish, with every method derived and every example worked — not as reference cards you dip into.")}</p></header>
      <div class="grid three">${HANDBOOKS().map((hb) => {
        const done = hb.chapters.filter((c) => hbRead(hb.id, c.n)).length;
        return `<a class="card sub-card" href="#/handbook/${hb.id}">
          <span class="sub-ico" aria-hidden="true">${hb.icon}</span>
          <span class="sub-name">${esc(hi && hb.hi ? hb.hi : hb.name)}</span>
          <span class="cat-blurb">${esc(hb.blurb)}</span>
          <span class="sub-bar"><span style="width:${Math.round((100 * done) / hb.chapters.length)}%"></span></span>
          <span class="cat-count mono">${done}/${hb.chapters.length} ${esc(hi ? "अध्याय" : "chapters")}</span></a>`;
      }).join("")}</div>`;
  };

  V.handbook = function (params) {
    const hb = hbById(params.id);
    if (!hb) return notFound();
    const hi = S.lang === "hi";
    const name = hi && hb.hi ? hb.hi : hb.name;
    track("handbook", hb.id, name, hi ? "हैंडबुक" : "Handbook");
    const done = hb.chapters.filter((c) => hbRead(hb.id, c.n)).length;
    const sub = (DB.subjects || []).find((x) => x.id === hb.subject);

    return `<nav class="crumbs mono">${sub ? `<a href="#/subject/${sub.id}">${esc(hi && sub.hi ? sub.hi : sub.name)}</a> → ` : ""}<span>${esc(hi ? "हैंडबुक" : "Handbook")}</span></nav>
      <header class="page-head"><h1>${hb.icon} ${esc(name)}</h1>
        <p class="lede">${esc(hb.blurb)}</p></header>

      <section class="card stats-card">
        <div class="stat"><span class="stat-n mono">${hb.chapters.length}</span><span class="stat-l">${esc(hi ? "अध्याय" : "Chapters")}</span></div>
        <div class="stat"><span class="stat-n mono">${done}</span><span class="stat-l">${esc(hi ? "पढ़ लिए" : "Read")}</span></div>
        <div class="stat"><span class="stat-n mono">${hb.chapters.reduce((a, c) => a + c.sections.length, 0)}</span><span class="stat-l">${esc(hi ? "अनुभाग" : "Sections")}</span></div>
        <div class="bar"><span style="width:${Math.round((100 * done) / hb.chapters.length)}%"></span></div>
      </section>

      <section>${sectionHead(hi ? "विषय-सूची" : "Contents")}
        <div class="rows">${hb.chapters.map((c) => `<a class="row unit-row" href="#/read/${hb.id}/${c.n}">
          <span class="ui-n mono">${c.n}</span>
          <div class="row-main"><div class="row-title">${esc(hi && c.hi ? c.hi : c.title)}</div>
            <div class="row-sub mono">${c.sections.length} ${esc(hi ? "अनुभाग" : "sections")}${c.mins ? " · " + c.mins + " min" : ""}</div></div>
          ${hbRead(hb.id, c.n) ? `<span class="u-done mono all">✓</span>` : ""}<span class="chev">→</span></a>`).join("")}</div></section>

      ${hb.note ? `<section class="notice"><p>${esc(hb.note)}</p></section>` : ""}`;
  };

  V.read = function (params) {
    const hb = hbById(params.id);
    if (!hb) return notFound();
    const ch = chapterOf(hb, params.c);
    if (!ch) return notFound();
    const hi = S.lang === "hi";
    const hbName = hi && hb.hi ? hb.hi : hb.name;
    const title = hi && ch.hi ? ch.hi : ch.title;
    track("read", hb.id + "/" + ch.n, title, hbName);
    /* Opening a chapter marks it read — this is a book, not a quiz. */
    S.views[hbReadKey(hb.id, ch.n)] = (S.views[hbReadKey(hb.id, ch.n)] || 0) + 1;
    save();

    const idx = hb.chapters.findIndex((c) => c.n === ch.n);
    const prev = idx > 0 ? hb.chapters[idx - 1] : null;
    const next = idx < hb.chapters.length - 1 ? hb.chapters[idx + 1] : null;
    const pager = `<div class="unit-pager">
      ${prev ? `<a class="btn ghost sm" href="#/read/${hb.id}/${prev.n}">← ${esc(hi ? "अध्याय " + prev.n : "Chapter " + prev.n)}</a>` : "<span></span>"}
      <a class="btn ghost sm" href="#/handbook/${hb.id}">${esc(hi ? "विषय-सूची" : "Contents")}</a>
      ${next ? `<a class="btn sm" href="#/read/${hb.id}/${next.n}">${esc(hi ? "अध्याय " + next.n : "Chapter " + next.n)} →</a>` : "<span></span>"}</div>`;

    return `<nav class="crumbs mono"><a href="#/handbook/${hb.id}">${esc(hbName)}</a> → <span>${esc(hi ? "अध्याय " + ch.n : "Chapter " + ch.n)}</span></nav>
      <header class="page-head hb-head">
        <p class="hb-chno mono">${esc(hi ? "अध्याय" : "Chapter")} ${ch.n}</p>
        <h1>${esc(title)}</h1>
        ${ch.blurb ? `<p class="lede">${esc(ch.blurb)}</p>` : ""}
        ${ch.mins ? `<p class="fine">${ch.mins} ${esc(hi ? "मिनट का पाठ" : "minute read")} · ${ch.sections.length} ${esc(hi ? "अनुभाग" : "sections")}</p>` : ""}</header>

      ${hi ? `<div class="callout-note">इस हैंडबुक के अध्याय और अनुभाग के शीर्षक हिन्दी में हैं, पर पूरा पाठ अभी अंग्रेज़ी में ही है — हिन्दी रूपांतर अध्याय दर अध्याय जोड़ा जा रहा है। सूत्र, आँकड़े और चित्र दोनों भाषाओं में एक ही हैं। इसी विषय के topic पन्ने (Subjects → ${esc(hi && (DB.subjects || []).find((x) => x.id === hb.subject) ? ((DB.subjects || []).find((x) => x.id === hb.subject).hi || "") : "")}) पूरी तरह हिन्दी में उपलब्ध हैं।</div>` : ""}

      <nav class="hb-toc" aria-label="${esc(hi ? "इस अध्याय के अनुभाग" : "Sections in this chapter")}">
        ${ch.sections.map((sec, i) => `<button class="hb-tocb" data-act="hbjump" data-i="${i}">
          <span class="mono">${esc(sec.n)}</span> ${esc(hi && sec.hi ? sec.hi : sec.title)}</button>`).join("")}
      </nav>

      ${ch.sections.map((sec, i) => `<section class="hb-sec" id="hbs${i}">
        <h2 class="hb-st"><span class="mono hb-sn">${esc(sec.n)}</span> ${esc(hi && sec.hi ? sec.hi : sec.title)}</h2>
        ${(sec.blocks || []).map(hbBlock).join("")}
      </section>`).join("")}

      <section class="notice"><p><strong>${esc(hi ? "याद रहे।" : "Remember.")}</strong> ${esc(hb.note || "")}</p></section>
      ${pager}`;
  };

  /* --------------------------------------------- CLAUSE BROWSER */
  function clauseStats(cid) {
    const secs = (DB.clauses || {})[cid] || [];
    let total = 0, mapped = 0;
    let parts = 0;
    secs.forEach((s) => s.items.forEach((it) => { total++; if (it.topic || it.mat) mapped++; if (/^Part /.test(it.n)) parts++; }));
    return { total, mapped, secs, unit: parts > total / 2 ? "parts" : "clauses" };
  }
  function clauseRow(cid, it) {
    const tp = it.topic ? topicById(it.topic) : null;
    const tb = it.tbl ? tableById(it.tbl) : null;
    const mt = it.mat ? (DB.materials || []).find((m) => m.id === it.mat) : null;
    const href = tp ? "#/topic/" + tp.id : mt ? "#/materials/" + mt.id : tb ? "#/table/" + tb.id : null;
    const note = tp ? `<span class="cl-s">Explained in this app</span>`
      : mt ? `<span class="cl-s">Material guide: ${esc(mt.name)}</span>`
      : `<span class="cl-s idx">Explanation not written yet</span>`;
    const inner = `<span class="cl-n mono">${esc(it.n)}</span>
      <span class="cl-main"><span class="cl-t">${esc(it.t)}</span>
        ${note}</span>
      ${it.v ? `<span class="cl-v" title="Clause numbering still to be confirmed against the published standard">verify</span>` : ""}
      ${href ? `<span class="chev">→</span>` : ""}`;
    return href
      ? `<a class="row cl-row" href="${href}">${inner}</a>`
      : `<div class="row cl-row static">${inner}</div>`;
  }
  V.clauses = function (params) {
    const c = codeById(params.id);
    if (!c || !(DB.clauses || {})[c.id]) return notFound();
    track("clauses", c.id, codeLabel(c) + " — clause map", "Clause index");
    const st = clauseStats(c.id);
    return `<nav class="crumbs mono"><a href="#/code/${c.id}">${esc(codeLabel(c))}</a> → <span>Clause map</span></nav>
    <header class="page-head"><h1>${esc(codeLabel(c))} — clause map</h1>
      <p class="lede">${esc(c.title)}</p>
      <div class="bar"><span style="width:${(st.mapped / st.total) * 100}%"></span></div>
      <p class="fine mono">${st.mapped} of ${st.total} indexed ${st.unit} have an explanation in this app</p></header>
    <div class="callout-note">${esc(DB.clauseNote)}</div>
    ${(DB.clauseDraft || []).includes(c.id) ? `<div class="callout-note draft-note">
      <strong>Draft index.</strong> This map was compiled from the standard's published contents listing and has
      not yet been checked page by page. The headings are right; a clause number may have moved in a later revision.
      Confirm the number against your copy before quoting it.
    </div>` : ""}
    ${st.secs.map((s) => `<section>${sectionHead(s.sec, `<span class="more">${s.items.length} entries</span>`)}
      <div class="rows">${s.items.map((it) => clauseRow(c.id, it)).join("")}</div></section>`).join("")}
    <section class="card">
      <h2>Found a clause we have not explained?</h2>
      <p>The index tells you where the provision lives; the explanation is written by us, one clause at a time. If a clause you need is marked “index only”, tell us and it moves up the list.</p>
      <div class="row-actions">${reportBtn("clause", c.id, codeLabel(c) + " clause map")}<a class="btn ghost sm" href="#/policy">How this content is written →</a></div>
    </section>`;
  };

  /* --------------------------------------------- CONTENT POLICY */
  V.policy = function () {
    return `<header class="page-head"><h1>How this content is written</h1>
      <p class="lede">The rules every entry in this library follows. They exist so the app stays useful to students and stays on the right side of copyright.</p></header>

    <section class="card q-what"><h2>The one test</h2>
      <p>Before publishing any entry, ask: <strong>would a student still need the actual standard after reading this?</strong></p>
      <p>If yes, it is a textbook entry and it is fine. If no, it has replaced the standard — and that is both a copyright problem and, for a student, a dangerous one.</p></section>

    <section class="card"><h2>What this library may contain</h2>
      <ul class="bullets">
        <li>Clause numbers and headings, as an index for navigation</li>
        <li>Explanations written from scratch for this app, in our own words</li>
        <li>The specific values a student needs, with the clause named next to them</li>
        <li>Formulas, which are mathematical facts</li>
        <li>Worked examples, diagrams, calculators and questions we create ourselves</li>
        <li>Links to the official source for the standard itself</li>
      </ul></section>

    <section class="card q-tip"><h2>⚑ What it must never contain</h2>
      <ul class="bullets">
        <li>Scanned or copied PDFs of any standard</li>
        <li>The text of a clause reproduced word for word — not even one sentence, unless it is a short quotation in quotation marks with the clause named</li>
        <li>A clause-by-clause paraphrase of a whole code in the code's own order — that is an adaptation of the work, not a new one</li>
        <li>Every table of a standard reproduced in full; include the values students actually use, not the complete compilation</li>
        <li>A clause number, table number or value that has not been checked against the published standard</li>
      </ul></section>

    <section class="card"><h2>Writing rules for contributors</h2>
      <ol class="rev">
        <li><strong>Organise by topic, not by clause order.</strong> A topic page teaches an idea and names the clauses it comes from. A page that walks the code in sequence is a copy with different words.</li>
        <li><strong>Teach, do not transcribe.</strong> Every entry must answer why the provision exists and what goes wrong without it. If an entry only restates the requirement, it is not finished.</li>
        <li><strong>Name the source on every entry.</strong> No clause reference, no publish.</li>
        <li><strong>Verify before you publish.</strong> Open the standard, check the clause number, the table number and the value. Mark the entry with the date you checked it.</li>
        <li><strong>Add something of our own.</strong> A worked example, a diagram, a site consequence, an exam tip. That addition is what makes the entry ours.</li>
        <li><strong>When unsure, say so.</strong> Marking an entry “verify” is always better than a confident wrong number.</li>
      </ol></section>

    <section class="card notice"><p><strong>Not legal advice.</strong> These are the working rules this project follows. Before commercial distribution, have them reviewed by a lawyer who works in intellectual property.</p></section>`;
  };

  /* --------------------------------------------- SOLVED EXAMPLES */
  V.examples = function (params) {
    if (params.id) {
      const x = (DB.examples || []).find((e) => e.id === params.id);
      if (!x) return notFound();
      track("example", x.id, x.title, "Solved example");
      const c = codeById(x.code);
      return `<nav class="crumbs mono"><a href="#/examples">Solved examples</a> → <span>${esc(x.title)}</span></nav>
      <header class="page-head"><div class="th-top"><h1>${esc(x.title)}</h1>${saveBtn("example", x.id)}</div>
      ${c ? `<p class="ref-badge mono">${esc(codeLabel(c))} · ${esc(x.cat)}</p>` : ""}</header>
      <section class="card q-eg"><h2>Given</h2><p>${esc(x.given)}</p></section>
      <ol class="ex-steps">${x.steps.map((s, i) => `<li class="card ex-step">
        <p class="ex-n mono">Step ${i + 1}</p>
        <h3>${esc(s.t)}</h3>
        <pre class="ex-work">${esc(s.w)}</pre>
        ${s.r && s.r !== "—" ? `<p class="src"><span class="src-k">Clause</span> ${esc(s.r)}</p>` : ""}
      </li>`).join("")}</ol>
      <section class="card result-card"><p class="step-k mono">Answer</p><p class="ex-ans">${esc(x.answer)}</p></section>
      <section class="card q-tip"><h2>💡 Where students slip</h2><p>${esc(x.watch)}</p></section>
      <div class="row-actions">
        ${x.calc ? `<a class="btn" href="#/calc/${x.calc}">Try it in the calculator →</a>` : ""}
        ${c ? `<a class="btn ghost" href="#/code/${c.id}">Open ${esc(c.number)}</a>` : ""}
        ${shareBtn(x.title)}
      </div>`;
    }
    const byCat = {};
    (DB.examples || []).forEach((x) => { (byCat[x.cat] = byCat[x.cat] || []).push(x); });
    return `<header class="page-head"><h1>✏️ Solved examples</h1>
      <p class="lede">Complete design problems worked step by step, with the clause named at every step. This is the part students actually have to reproduce in an exam.</p></header>
      ${Object.keys(byCat).map((k) => `<section>${sectionHead(k + " (" + byCat[k].length + ")")}
        <div class="rows">${byCat[k].map((x) => `<a class="row" href="#/examples/${x.id}">
          <div class="row-main"><div class="row-title">${esc(x.title)}</div><div class="row-sub mono">${esc(x.steps.length)} steps · ${esc((codeById(x.code) || {}).number || "")}</div></div><span class="chev">→</span></a>`).join("")}</div>
      </section>`).join("")}`;
  };

  /* --------------------------------------------- SITE CHECKLISTS */
  V.checklists = function (params) {
    if (params.id) {
      const cl = (DB.checklists || []).find((x) => x.id === params.id);
      if (!cl) return notFound();
      track("checklists", cl.id, cl.title, "Site checklist");
      const done = S.notes["chk:" + cl.id] ? JSON.parse(S.notes["chk:" + cl.id]) : {};
      const n = cl.items.filter((_, i) => done[i]).length;
      return `<nav class="crumbs mono"><a href="#/checklists">Site checklists</a> → <span>${esc(cl.title)}</span></nav>
      <header class="page-head"><h1>${cl.icon} ${esc(cl.title)}</h1><p class="lede">${esc(cl.intro)}</p>
        <div class="bar"><span style="width:${(n / cl.items.length) * 100}%"></span></div>
        <p class="fine mono">${n} / ${cl.items.length} checked</p></header>
      <section class="card"><div class="chk">${cl.items.map((it, i) => `<label class="chk-row${done[i] ? " done" : ""}">
        <input type="checkbox" data-act="chk" data-cl="${cl.id}" data-i="${i}"${done[i] ? " checked" : ""}>
        <span class="chk-b"><span class="chk-t">${esc(it.t)}</span>${it.r && it.r !== "—" ? `<span class="chk-r mono">${esc(it.r)}</span>` : ""}</span>
      </label>`).join("")}</div>
      <div class="row-actions"><button class="btn ghost sm" data-act="chkreset" data-cl="${cl.id}">Reset</button>${shareBtn(cl.title)}</div></section>`;
    }
    return `<header class="page-head"><h1>✅ Site checklists</h1>
      <p class="lede">What to check before the concrete arrives, while it is being placed, and while the steel is still visible. Each point names the clause behind it.</p></header>
      <div class="grid three">${(DB.checklists || []).map((cl) => `<a class="card cat-card" href="#/checklists/${cl.id}">
        <span class="cat-ico" aria-hidden="true">${cl.icon}</span><span class="cat-name">${esc(cl.title)}</span>
        <span class="cat-blurb">${esc(cl.intro.slice(0, 90))}…</span>
        <span class="cat-count mono">${cl.items.length} checks</span></a>`).join("")}</div>`;
  };

  /* --------------------------------------------- EXAM PATHS */
  V.paths = function (params) {
    if (params.id) {
      const p = (DB.paths || []).find((x) => x.id === params.id);
      if (!p) return notFound();
      track("paths", p.id, p.name, "Study path");
      const all = p.groups.reduce((a, g) => a + g.topics.length, 0);
      const read = p.groups.reduce((a, g) => a + g.topics.filter((id) => (S.stats.topicsRead || []).includes(id)).length, 0);
      return `<nav class="crumbs mono"><a href="#/paths">Study paths</a> → <span>${esc(p.name)}</span></nav>
      <header class="page-head"><h1>${p.icon} ${esc(p.name)}</h1><p class="lede">${esc(p.blurb)}</p>
        <div class="bar"><span style="width:${(read / all) * 100}%"></span></div>
        <p class="fine mono">${read} / ${all} topics read</p></header>
      ${p.groups.map((g) => `<section>${sectionHead(g.g)}
        <div class="rows">${g.topics.map((id) => topicById(id)).filter(Boolean).map((tp) => {
        const r = (S.stats.topicsRead || []).includes(tp.id);
        return `<a class="row${r ? " read" : ""}" href="#/topic/${tp.id}">
            <span class="tick">${r ? "✓" : "○"}</span>
            <div class="row-main"><div class="row-title">${esc(tp.title)}</div><div class="row-sub mono">${esc(tp.ref)}</div></div><span class="chev">→</span></a>`;
      }).join("")}</div></section>`).join("")}`;
    }
    return `<header class="page-head"><h1>🎯 Study paths</h1>
      <p class="lede">The same library, ordered for the exam you are actually writing. Topics tick off as you read them.</p></header>
      <div class="grid three">${(DB.paths || []).map((p) => {
      const all = p.groups.reduce((a, g) => a + g.topics.length, 0);
      const read = p.groups.reduce((a, g) => a + g.topics.filter((id) => (S.stats.topicsRead || []).includes(id)).length, 0);
      return `<a class="card cat-card" href="#/paths/${p.id}">
          <span class="cat-ico" aria-hidden="true">${p.icon}</span><span class="cat-name">${esc(p.name)}</span>
          <span class="cat-blurb">${esc(p.blurb.slice(0, 95))}…</span>
          <span class="cat-count mono">${read} / ${all} topics read</span></a>`;
    }).join("")}</div>`;
  };

  /* --------------------------------------------- COMPARISONS */
  V.compare = function (params) {
    if (params.id) {
      const c = (DB.compares || []).find((x) => x.id === params.id);
      if (!c) return notFound();
      track("compare", c.id, c.title, "Comparison");
      return `<nav class="crumbs mono"><a href="#/compare">Comparisons</a> → <span>${esc(c.title)}</span></nav>
      <header class="page-head"><div class="th-top"><h1>${esc(c.title)}</h1>${saveBtn("compare", c.id)}</div>
      <p class="ref-badge mono">${esc(c.ref)}</p></header>
      <section class="card">${tableBlock({ cols: c.cols, rows: c.rows })}
      <p class="fine">${esc(c.note)}</p>${srcLine(c.ref)}
      <div class="row-actions">${shareBtn(c.title)}</div></section>`;
    }
    return `<header class="page-head"><h1>⇄ Comparisons</h1>
      <p class="lede">The difference questions students ask most, answered side by side.</p></header>
      <div class="rows">${(DB.compares || []).map((c) => `<a class="row" href="#/compare/${c.id}">
        <div class="row-main"><div class="row-title">${esc(c.title)}</div><div class="row-sub mono">${esc(c.ref)}</div></div><span class="chev">→</span></a>`).join("")}</div>`;
  };

  /* --------------------------------------------- MY PROJECT */
  V.project = function () {
    const items = S.project.items || [];
    const totals = {};
    items.forEach((it) => {
      (it.results || []).forEach((r) => {
        const key = r.label + "|" + (r.unit || "");
        const num = parseFloat(String(r.value).replace(/,/g, ""));
        if (!isFinite(num)) return;
        totals[key] = (totals[key] || 0) + num * (it.qty || 1);
      });
    });
    const keep = Object.keys(totals).filter((k) => /m³|kg|bags|nos|m²|tonne/i.test(k));
    return `<header class="page-head"><div class="th-top"><h1>📦 ${esc(S.project.name)}</h1>
      <div class="ch-actions"><button class="btn ghost sm" data-act="projname">Rename</button>
      <button class="btn ghost sm" data-act="projexport">Export</button>
      <button class="btn ghost sm" data-act="projclear">Clear</button></div></div>
      <p class="lede">Add results from any calculator and this page adds them up — one material list for the whole job.</p></header>

      ${items.length ? `<section>${sectionHead("Totals")}
        <section class="card result-card"><div class="results">
          ${keep.length ? keep.map((k) => {
      const [label, unit] = k.split("|");
      return `<div class="res"><span class="res-l">${esc(label)}</span><span class="res-v mono">${CALC.fmt(totals[k], 3)} <em>${esc(unit)}</em></span></div>`;
    }).join("") : `<div class="res"><span class="res-l">No quantity totals yet</span><span class="res-v mono">—</span></div>`}
        </div><p class="fine">Only quantity results (volumes, weights, bags, counts) are added up. Check units before ordering material.</p></section>
      </section>

      <section>${sectionHead("Items (" + items.length + ")")}
        <div class="rows">${items.map((it, i) => `<div class="row static">
          <div class="row-main"><div class="row-title">${esc(it.name)}${it.qty > 1 ? ` <span class="mono">× ${it.qty}</span>` : ""}</div>
          <div class="row-sub mono">${esc((it.results || []).slice(0, 3).map((r) => r.label + ": " + r.value + " " + (r.unit || "")).join(" · "))}</div></div>
          <button class="btn ghost sm" data-act="projdel" data-i="${i}">Remove</button></div>`).join("")}</div>
      </section>` : emptyState("Nothing added yet. Open any calculator, run it, and press “Add to project”.", `<a class="btn" href="#/calc">Open calculators →</a>`)}`;
  };

  V.about = function () {
    return `<header class="page-head"><h1>${t("about")}</h1></header>
      <section class="card notice"><p><strong>Educational reference.</strong> ${esc(DB.meta.disclaimer)}</p></section>
      <section class="card">
        <h2>What this library contains</h2>
        <ul class="bullets">
          <li>Code metadata — number, title, edition, category, status and official source.</li>
          <li>An index of what each standard covers, for navigation.</li>
          <li>Original, student-facing explanations of key clauses, written for this app.</li>
          <li>Clause and table references so you can find the provision in the published standard.</li>
          <li>Formulas with their variables and worked examples, each naming its clause.</li>
          <li>Calculators that show the formula and every step of the calculation.</li>
          <li>Practice questions with explanations and references.</li>
        </ul>
        <h2>What it does not contain</h2>
        <p>No scanned or copied IS Code PDFs, and no reproduction of code text. Where you need the standard itself, use the official source button on each code page.</p>
      </section>
      <section class="card">
        <h2>Official sources</h2>
        <div class="rows">
          <a class="row" href="${esc(DB.meta.bisPortal)}" target="_blank" rel="noopener"><div class="row-main"><div class="row-title">Bureau of Indian Standards (BIS)</div><div class="row-sub mono">Indian Standards — IS and SP publications</div></div><span class="chev">↗</span></a>
          <a class="row" href="${esc(DB.meta.irc)}" target="_blank" rel="noopener"><div class="row-main"><div class="row-title">Indian Roads Congress (IRC)</div><div class="row-sub mono">IRC codes and guidelines — not Indian Standards</div></div><span class="chev">↗</span></a>
          <a class="row" href="${esc(DB.meta.morth)}" target="_blank" rel="noopener"><div class="row-main"><div class="row-title">Ministry of Road Transport & Highways</div><div class="row-sub mono">Specifications for Road and Bridge Works</div></div><span class="chev">↗</span></a>
        </div>
      </section>
      <section class="card">
        <h2>Status marks</h2>
        <div class="rows">
          <div class="row static"><div class="row-main"><div class="row-title">${statusPill("current")}</div><div class="row-sub">Believed to be the current edition at the time this entry was written.</div></div></div>
          <div class="row static"><div class="row-main"><div class="row-title">${statusPill("check")}</div><div class="row-sub">Older or reaffirmed edition — confirm the latest revision and amendments before use.</div></div></div>
          <div class="row static"><div class="row-main"><div class="row-title">${statusPill("withdrawn")}</div><div class="row-sub">Superseded or merged into another standard; kept because it is still quoted in older drawings.</div></div></div>
        </div>
        <p class="fine">No code is assumed current without verification. Content version ${esc(DB.meta.version)}, last reviewed ${esc(DB.meta.updated)}.</p>
      </section>`;
  };

  V.account = function () {
    return window.AUTH ? AUTH.view() : notFound();
  };

  function notFound() {
    return `<section class="card"><h1>Not found</h1><p>That entry does not exist in the library.</p>
      <div class="row-actions"><a class="btn" href="#/">Go home</a><a class="btn ghost" href="#/codes">Browse all codes</a></div></section>`;
  }

  /* ------------------------------------------------------------- router */
  function parseHash() {
    const h = location.hash.replace(/^#\/?/, "");
    const [path, qs] = h.split("?");
    const seg = path.split("/").filter(Boolean);
    const params = {};
    if (qs) qs.split("&").forEach((p) => { const [k, v] = p.split("="); params[k] = decodeURIComponent(v || ""); });
    return { seg, params };
  }
  function render() {
    const { seg, params } = parseHash();
    const view = seg[0] || "home";
    let html;
    const p = Object.assign({}, params);
    if (view === "exam") { p.sub = seg[1]; p.id = seg[2]; }
    else if (view === "unit") { p.id = seg[1]; p.u = seg[2]; }
    else if (view === "read") { p.id = seg[1]; p.c = seg[2]; }
    else if (view === "search") { p.q = p.q || decodeURIComponent(seg[1] || ""); }
    else { p.id = seg[1]; }
    const fn = V[view];
    html = fn ? fn(p) : notFound();
    const main = $("#view");
    main.innerHTML = html;
    document.title = titleFor(view, p) + " · Civil Educator";
    buildNav();
    markNav(view, seg);
    window.scrollTo(0, 0);
    if (view === "codes") { const s = $("#f-cat"); if (s) { } }
  }
  function titleFor(v, p) {
    if (v === "code" && codeById(p.id)) return codeLabel(codeById(p.id));
    if (v === "topic" && topicById(p.id)) return topicById(p.id).title;
    if (v === "calc" && p.id) { const c = CALC.list.find((x) => x.id === p.id); if (c) return c.name; }
    if (v === "materials" && p.id) { const m = (DB.materials || []).find((x) => x.id === p.id); if (m) return m.name; }
    if (v === "examples" && p.id) { const x = (DB.examples || []).find((e) => e.id === p.id); if (x) return x.title; }
    if (v === "subject" && p.id) { const sb = (DB.subjects || []).find((x) => x.id === p.id); if (sb) return sb.name; }
    if (v === "handbook" && p.id) { const h = (DB.handbooks || []).find((x) => x.id === p.id); if (h) return h.name; }
    if (v === "read" && p.id) { const h = (DB.handbooks || []).find((x) => x.id === p.id); const c = h && h.chapters.find((x) => String(x.n) === String(p.c)); if (c) return c.title; }
    if (v === "unit" && p.id) { const sb = (DB.subjects || []).find((x) => x.id === p.id); const un = sb && sb.units[parseInt(p.u, 10) - 1]; if (un) return un.t; }
    return { home: "Home", codes: "All Codes", search: "Search", calc: "Calculators", exam: "Exam Mode", library: "My Library", tables: "Tables & Values", formulas: "Formulas", profile: "Profile", admin: "Admin", ai: "Ask Civil AI", about: "About", examples: "Solved Examples", subjects: "Subjects", handbooks: "Handbooks", clauses: "Clause Map", materials: "Materials", policy: "Content Policy", checklists: "Site Checklists", paths: "Study Paths", compare: "Comparisons", project: "My Project" }[v] || "Civil Educator";
  }
  /* Nav keys are now "cat:rcc" and "matcat:binders" as well as plain view
     names, so the exact category highlights rather than every category. */
  function navKey(view, seg) {
    if (view === "cat" && seg[1]) return "cat:" + seg[1];
    if (view === "matcat" && seg[1]) return "matcat:" + seg[1];
    if (view === "materials" && seg[1]) return "materials";
    if (view === "subject" || view === "unit") return "subjects";
    if (view === "handbook" || view === "read") return "handbooks";
    return view;
  }
  function markNav(view, seg) {
    const key = navKey(view, seg || []);
    $$("[data-nav]").forEach((a) => a.classList.toggle("on", a.dataset.nav === key));
  }
  function go(h) { location.hash = h; }

  /* --------------------------------------------------------- interaction */
  document.addEventListener("click", function (e) {
    const el = e.target.closest("[data-act]");
    if (!el) return;
    const act = el.dataset.act;
    if (act === "hbjump") {
      /* Scroll inside the chapter. Writing "#hbs3" into location.hash would
         make the router treat "hbs3" as a view and render Not found. */
      e.preventDefault();
      const sec = document.getElementById("hbs" + el.dataset.i);
      if (sec) sec.scrollIntoView({ behavior: "smooth", block: "start" });
    } else if (act === "save") {
      e.preventDefault();
      toggleSave(el.dataset.type, el.dataset.id);
      render();
    } else if (act === "q" || act === "aiq") {
      e.preventDefault();
      if (act === "q") go("/search?q=" + encodeURIComponent(el.dataset.q));
      else { const ta = $("#ai-q"); if (ta) { ta.value = el.dataset.q; askAI(el.dataset.q); } }
    } else if (act === "copycode") {
      e.preventDefault();
      const n = el.dataset.n;
      const done = () => { const o = el.textContent; el.textContent = "Copied ✓"; setTimeout(() => { el.textContent = o; }, 1600); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(n).then(done, () => alert(n));
      else alert(n);
    } else if (act === "clearfilters") {
      e.preventDefault(); go("/codes");
    } else if (act === "answer") {
      const i = +el.dataset.i;
      if (quiz && quiz.picked === null) {
        quiz.picked = i;
        const q = quiz.qs[quiz.i];
        S.stats.answered++;
        const c = codeById(q.code);
        if (c) S.stats.answeredByCat[c.cat] = (S.stats.answeredByCat[c.cat] || 0) + 1;
        if (i === q.ans) { quiz.score++; S.stats.correct++; }
        save(); render();
      }
    } else if (act === "qnext") {
      if (quiz) { if (quiz.i === quiz.qs.length - 1) quiz.done = true; else { quiz.i++; quiz.picked = null; } render(); }
    } else if (act === "quizrestart") {
      if (quiz) { quiz = Object.assign({}, quiz, { i: 0, picked: null, score: 0, done: false }); render(); }
    } else if (act === "level") {
      S.profile.level = el.dataset.k; save(); render();
    } else if (act === "lang") {
      S.lang = el.dataset.l; save(); buildNav(); render();
    } else if (act === "export") {
      download("civil-educator-my-data.json", JSON.stringify({ saved: S.saved, recents: S.recents, stats: S.stats, profile: S.profile }, null, 2));
    } else if (act === "exportdb") {
      download("civil-educator-content.json", JSON.stringify({ categories: CATS, codes: CODES, topics: TOPICS, tables: TABLES, formulas: FORMULAS, mcqs: MCQS }, null, 2));
    } else if (act === "copyids") {
      const txt = CODES.filter((c) => !c.documentUrl).map((c) => c.id + " | " + c.number).join("\n");
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(() => alert("Copied " + CODES.filter((c) => !c.documentUrl).length + " code ids."), () => { });
    } else if (act === "importdb") {
      importDB();
    } else if (act === "reset") {
      if (confirm("Reset all saved items, progress and settings on this device?")) { S = defaults(); save(); rebuild(); render(); }
    } else if (act === "wipeadmin") {
      if (confirm("Delete all content added through the admin panel?")) {
        S.admin = Object.assign(S.admin, { codes: [], topics: [], tables: [], formulas: [], mcqs: [], categories: [], edits: {} });
        save(); rebuild(); render();
      }
    } else if (act === "lock") {
      S.admin.unlocked = false; save(); render();
    } else if (act === "calcfilter") {
      calcCat = el.dataset.cat;
      $$("[data-act=calcfilter]").forEach((b) => b.classList.toggle("on", b === el));
      applyCalcFilter();
    } else if (act === "calcreset") {
      delete calcState[el.dataset.id]; render();
    } else if (act === "aiclear") {
      const o = $("#ai-out"); if (o) o.innerHTML = ""; const ta = $("#ai-q"); if (ta) ta.value = "";
    } else if (act === "share") {
      e.preventDefault();
      const title = el.dataset.t;
      const url = location.href;
      const text = title + " — Civil Educator\n" + url;
      if (navigator.share) { navigator.share({ title, text: title, url }).catch(() => { }); }
      else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => { const o = el.textContent; el.textContent = "Link copied ✓"; setTimeout(() => { el.textContent = o; }, 1600); }, () => { });
    } else if (act === "report") {
      e.preventDefault();
      const what = prompt("What is wrong on this page? (clause number, value, spelling — be specific)");
      if (!what) return;
      S.reports.push({ kind: el.dataset.kind, id: el.dataset.id, label: el.dataset.label, what, at: Date.now() });
      save();
      const line = `[${el.dataset.kind}] ${el.dataset.label} (${el.dataset.id}): ${what}`;
      if (navigator.clipboard) navigator.clipboard.writeText(line).catch(() => { });
      alert("Thank you — noted on this device and copied to your clipboard.\n\nPaste it into a message to the app maintainer so it can be corrected.");
    } else if (act === "addproj") {
      e.preventDefault();
      const c = CALC.list.find((x) => x.id === el.dataset.id);
      if (!c || !calcState[c.id]) return;
      let out; try { out = c.run(calcState[c.id]); } catch (err) { return; }
      const name = prompt("Name this item (e.g. “Ground floor beams B1–B4”)", c.name);
      if (name === null) return;
      const qty = parseInt(prompt("How many of these? (multiplier)", "1"), 10) || 1;
      S.project.items.push({ calcId: c.id, name: name || c.name, qty, results: out.results, at: Date.now() });
      save();
      alert("Added to " + S.project.name + ".");
    } else if (act === "projdel") {
      S.project.items.splice(+el.dataset.i, 1); save(); render();
    } else if (act === "projclear") {
      if (confirm("Remove every item from this project?")) { S.project.items = []; save(); render(); }
    } else if (act === "projname") {
      const nm = prompt("Project name", S.project.name);
      if (nm) { S.project.name = nm; save(); render(); }
    } else if (act === "projexport") {
      download(slug(S.project.name) + ".json", JSON.stringify(S.project, null, 2));
    } else if (act === "chk") {
      const key = "chk:" + el.dataset.cl;
      const cur = S.notes[key] ? JSON.parse(S.notes[key]) : {};
      if (el.checked) cur[el.dataset.i] = 1; else delete cur[el.dataset.i];
      S.notes[key] = JSON.stringify(cur); save(); render();
    } else if (act === "chkreset") {
      delete S.notes["chk:" + el.dataset.cl]; save(); render();
    } else if (act === "theme") {
      const order = ["", "light", "dark"];
      S.theme = order[(order.indexOf(S.theme) + 1) % 3];
      applyTheme(); save(); buildNav(); render();
    } else if (act === "sheet") {
      e.preventDefault();
      downloadFormulaSheet();
    } else if (act === "onbnext") {
      onbStep++; renderOnboarding();
    } else if (act === "onblevel") {
      S.profile.level = el.dataset.k; save(); onbStep++; renderOnboarding();
    } else if (act === "onbdone") {
      S.onboarded = true; save(); $("#onb").remove(); render();
    } else if (act === "closelive") {
      const b = $("#live"); if (b) { b.hidden = true; b.innerHTML = ""; }
    } else if (act === "menu") {
      document.body.classList.toggle("nav-open");
    } else if (act === "navgroup") {
      e.preventDefault();
      const id = el.dataset.g;
      const open = navOpenSet();
      const i = open.indexOf(id);
      if (i === -1) open.push(id); else open.splice(i, 1);
      // A group the current page lives in opens itself, so closing it has to
      // be recorded as an explicit choice rather than silently springing back.
      S.navClosed = (S.navClosed || []).filter((x) => x !== id);
      if (i !== -1) S.navClosed.push(id);
      save();
      buildNav();
      const { seg: sg } = parseHash();
      markNav(sg[0] || "home", sg);
    } else if (act === "closenav") {
      document.body.classList.remove("nav-open");
    } else if (window.AUTH && AUTH.act(el, act, e)) {
      e.preventDefault();
    }
  });

  document.addEventListener("input", function (e) {
    if (window.AUTH && e.target && e.target.id) AUTH.input(e.target);
  });

  document.addEventListener("submit", function (e) {
    const el = e.target.closest("[data-act]");
    if (!el) return;
    const act = el.dataset.act;
    e.preventDefault();
    if (window.AUTH && AUTH.submit(el, act)) {
      return;
    }
    if (act === "searchform") {
      const q = $("#q", el).value.trim();
      if (q) go("/search?q=" + encodeURIComponent(q));
    } else if (act === "calcform") {
      const id = el.dataset.id;
      const c = CALC.list.find((x) => x.id === id);
      const v = {};
      $$("[data-k]", el).forEach((i) => { v[i.dataset.k] = i.value; });
      calcState[id] = v;
      S.stats.calcRuns = (S.stats.calcRuns || 0) + 1; save();
      $("#calc-out").innerHTML = renderCalcOut(c);
    } else if (act === "aiform") {
      const q = $("#ai-q").value.trim();
      if (q) askAI(q);
    } else if (act === "pinform") {
      if ($("#pin").value === S.admin.pin) { S.admin.unlocked = true; save(); render(); }
      else { alert("That PIN is not correct."); }
    } else if (act === "setpin") {
      const p = $("#newpin").value.trim();
      if (p.length >= 4) { S.admin.pin = p; save(); alert("PIN updated on this device."); }
      else alert("Use at least four characters.");
    } else if (act === "addcode") {
      const num = $("#a-num").value.trim();
      const id = slug(num) + "-" + Math.random().toString(36).slice(2, 6);
      S.admin.codes.push({
        id, docType: $("#a-dt").value, number: num, year: $("#a-year").value.trim() || "—",
        cat: $("#a-cat").value, status: $("#a-st").value, title: $("#a-title").value.trim(),
        edition: $("#a-year").value.trim(), summary: $("#a-sum").value.trim(),
        keywords: $("#a-kw").value.split(",").map((s) => s.trim()).filter(Boolean),
        contents: $("#a-con").value.split("\n").map((s) => s.trim()).filter(Boolean),
        related: $("#a-rel").value.split(",").map((s) => s.trim()).filter(Boolean),
        src: $("#a-src").value.trim() || DB.meta.bisPortal, createdAt: Date.now(),
      });
      save(); rebuild(); go("/code/" + id);
    } else if (act === "addtopic") {
      const id = "t-" + slug($("#t-title").value).slice(0, 24) + "-" + Math.random().toString(36).slice(2, 5);
      S.admin.topics.push({
        id, code: $("#t-code").value, title: $("#t-title").value.trim(), ref: $("#t-ref").value.trim(),
        importance: $("#t-imp").value, what: $("#t-what").value.trim(), why: $("#t-why").value.trim(),
        example: $("#t-eg").value.trim(), tip: $("#t-tip").value.trim(),
        keywords: $("#t-kw").value.split(",").map((s) => s.trim()).filter(Boolean), createdAt: Date.now(),
      });
      save(); rebuild(); go("/topic/" + id);
    } else if (act === "addmcq") {
      const id = "q-" + Math.random().toString(36).slice(2, 8);
      S.admin.mcqs.push({
        id, code: $("#m-code").value, q: $("#m-q").value.trim(),
        opts: [$("#m-a").value, $("#m-b").value, $("#m-c").value, $("#m-d").value].map((s) => s.trim()),
        ans: +$("#m-ans").value, exp: $("#m-e").value.trim(), ref: $("#m-r").value.trim(), level: "med", createdAt: Date.now(),
      });
      save(); rebuild(); alert("Question added."); render();
    } else if (act === "addcat") {
      const name = $("#c-name").value.trim();
      S.admin.categories.push({ id: slug(name), name, icon: $("#c-icon").value.trim() || "📘", blurb: $("#c-desc").value.trim() });
      save(); rebuild(); render();
    } else if (act === "bulklinks") {
      const lines = $("#bl").value.split(/\n+/).map((l) => l.trim()).filter(Boolean);
      let ok = 0, bad = [];
      lines.forEach((l) => {
        const m = l.split(/\s*[|,\t]\s*/);
        if (m.length < 2) { bad.push(l); return; }
        const id = m[0].trim(), url = m.slice(1).join("|").trim();
        if (!codeById(id)) { bad.push(m[0]); return; }
        if (!/^https?:\/\//i.test(url)) { bad.push(m[0]); return; }
        S.admin.edits[id] = Object.assign({}, S.admin.edits[id] || {}, { documentUrl: url });
        ok++;
      });
      save(); rebuild();
      alert(ok + " link" + (ok === 1 ? "" : "s") + " saved." + (bad.length ? "\n\nNot recognised: " + bad.join(", ") : ""));
      render();
    } else if (act === "editcode") {
      const id = $("#e-code").value;
      const patch = Object.assign({}, S.admin.edits[id] || {});
      if ($("#e-st").value) patch.status = $("#e-st").value;
      if ($("#e-year").value.trim()) patch.year = $("#e-year").value.trim();
      if ($("#e-ed").value.trim()) patch.edition = $("#e-ed").value.trim();
      if ($("#e-doc").value.trim()) patch.documentUrl = $("#e-doc").value.trim();
      S.admin.edits[id] = patch;
      save(); rebuild(); alert("Updated."); render();
    }
  });

  /* ---- calculator list: live filter by text and by category ---- */
  let calcCat = "all";
  function applyCalcFilter() {
    const box = $("#calcq");
    if (!box) return;
    const q = norm(box.value.trim());
    const filtering = q.length > 0 || calcCat !== "all";
    let shown = 0;
    $$(".calc-tile").forEach((t) => {
      const okCat = calcCat === "all" || t.dataset.cat === calcCat;
      const okQ = !q || (t.dataset.hay || "").indexOf(q) !== -1;
      const on = okCat && okQ;
      t.hidden = !on;
      if (on) shown++;
    });
    /* hide the Recent / Most-used strips while a filter is active, and any empty section */
    $$("[data-strip]").forEach((s) => {
      s.hidden = filtering;
      if (filtering) $$(".calc-tile", s).forEach((t) => { t.hidden = true; });
    });
    $$("[data-catsec]").forEach((s) => {
      s.hidden = !$$(".calc-tile:not([hidden])", s).length;
    });
    const none = $("#calc-none");
    if (none) none.hidden = shown > 0;
  }
  /* ---- calculator page: recompute as the user types ---- */
  let calcTimer = null;
  function liveCalc(form) {
    const id = form.dataset.id;
    const c = CALC.list.find((x) => x.id === id);
    if (!c) return;
    const v = {};
    $$("[data-k]", form).forEach((i) => { v[i.dataset.k] = i.value; });
    if (Object.keys(v).some((k) => String(v[k]).trim() === "")) return;
    calcState[id] = v;
    const out = $("#calc-out");
    if (out) out.innerHTML = renderCalcOut(c);
  }

  let noteTimer = null;
  document.addEventListener("input", function (e) {
    const el = e.target;
    if (el.id === "q") { liveSearch(el.value); return; }
    if (el.id === "calcq") { applyCalcFilter(); return; }
    const form = el.closest && el.closest("[data-act=calcform]");
    if (form) {
      clearTimeout(calcTimer);
      calcTimer = setTimeout(() => liveCalc(form), 220);
      return;
    }
    if (el.matches("[data-act=note]")) {
      clearTimeout(noteTimer);
      const id = el.dataset.id, val = el.value;
      noteTimer = setTimeout(() => {
        if (val.trim()) S.notes[id] = val; else delete S.notes[id];
        save();
        const s = $("#note-state"); if (s) { s.textContent = "Saved"; setTimeout(() => { if (s) s.textContent = ""; }, 1500); }
      }, 500);
    }
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") { const b = $("#live"); if (b) { b.hidden = true; b.innerHTML = ""; } }
  });

  document.addEventListener("change", function (e) {
    const cf = e.target.closest && e.target.closest("[data-act=calcform]");
    if (cf) { clearTimeout(calcTimer); liveCalc(cf); return; }
    if (!e.target.closest(".filters")) return;
    const cat = $("#f-cat").value, yr = $("#f-yr").value, sort = $("#f-sort").value;
    const q = new URLSearchParams();
    if (cat) q.set("cat", cat);
    if (yr) q.set("yr", yr);
    if (sort) q.set("sort", sort);
    go("/codes?" + q.toString());
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "/" && !/input|textarea|select/i.test(document.activeElement.tagName)) {
      e.preventDefault();
      const q = $("#q");
      if (q) q.focus(); else go("/search");
    }
  });

  async function download(name, text) {
    try {
      const d = window.claude && window.claude.use ? await window.claude.use("downloads") : null;
      if (d) { await d.save({ filename: name, data: text }); return; }
    } catch (e) { }
    try {
      const w = window.open("", "_blank");
      if (w) { w.document.write("<pre>" + esc(text) + "</pre>"); w.document.close(); return; }
    } catch (e) { }
    alert("Export is not available in this view. Copy the data from the admin panel instead.");
  }
  function applyTheme() {
    const r = document.documentElement;
    if (S.theme === "light" || S.theme === "dark") r.setAttribute("data-theme", S.theme);
    else r.removeAttribute("data-theme");
  }
  function themeLabel() {
    return S.theme === "light" ? "☀️ Light" : S.theme === "dark" ? "🌙 Dark" : "🖥 System";
  }

  function downloadFormulaSheet() {
    const lines = ["CIVIL EDUCATOR — FORMULA SHEET", "Generated " + new Date().toLocaleDateString("en-IN"), "", DB.meta.disclaimer, "", "=".repeat(60), ""];
    FORMULAS.forEach((f) => {
      lines.push(f.title.toUpperCase());
      lines.push("  " + f.expr);
      (f.vars || []).forEach((v) => lines.push("    " + v[0] + " = " + v[1]));
      lines.push("  Example: " + f.example);
      lines.push("  Source: " + f.ref);
      lines.push("");
    });
    lines.push("=".repeat(60), "", "KEY VALUES", "");
    TABLES.forEach((tb) => {
      lines.push(tb.title + "  [" + tb.ref + "]");
      lines.push("  " + tb.cols.join(" | "));
      tb.rows.forEach((r) => lines.push("  " + r.join(" | ")));
      lines.push("");
    });
    download("civil-formula-sheet.txt", lines.join("\n"));
  }

  /* ------------------------------------------------------- onboarding */
  let onbStep = 0;
  function renderOnboarding() {
    const host = $("#onb");
    if (!host) return;
    const slides = [
      { icon: "🔍", h: "Search the way you think", p: "Type a code number, a clause number like 26.4.2, or plain words like “nominal cover”. Results appear as you type." },
      { icon: "📐", h: "Understand, don't just look up", p: "Every important clause has a plain explanation, a diagram, a worked example and the exact reference you can quote." },
      { icon: "🧮", h: "Calculators that show the working", p: "Formula, your inputs, every step, then the result — with the clause it follows. Nothing is a black box." },
    ];
    if (onbStep < slides.length) {
      const s = slides[onbStep];
      host.innerHTML = `<div class="onb-card">
        <span class="onb-ico" aria-hidden="true">${s.icon}</span>
        <h2>${esc(s.h)}</h2><p>${esc(s.p)}</p>
        <div class="onb-dots">${slides.map((_, i) => `<span class="${i === onbStep ? "on" : ""}"></span>`).join("")}</div>
        <div class="row-actions center">
          <button class="btn" data-act="onbnext">Next</button>
          <button class="btn ghost" data-act="onbdone">Skip</button>
        </div></div>`;
    } else {
      host.innerHTML = `<div class="onb-card">
        <span class="onb-ico" aria-hidden="true">🎓</span>
        <h2>What are you studying?</h2><p>We will put the right codes and topics on your home screen. You can change this later in Profile.</p>
        <div class="onb-levels">${Object.keys(DB.recommendations).map((k) => `<button class="btn ghost" data-act="onblevel" data-k="${k}">${esc(DB.recommendations[k].label)}</button>`).join("")}</div>
        <div class="row-actions center"><button class="btn ghost" data-act="onbdone">Skip for now</button></div></div>`;
    }
  }
  function maybeOnboard() {
    if (S.onboarded) return;
    const d = document.createElement("div");
    d.id = "onb"; d.className = "onb";
    document.body.appendChild(d);
    renderOnboarding();
  }

  function importDB() {
    const txt = prompt("Paste content JSON exported from this app:");
    if (!txt) return;
    try {
      const j = JSON.parse(txt);
      ["codes", "topics", "tables", "formulas", "mcqs", "categories"].forEach((k) => {
        if (Array.isArray(j[k])) {
          const known = new Set((DB[k === "categories" ? "categories" : k] || []).map((x) => x.id));
          S.admin[k] = j[k].filter((x) => x && x.id && !known.has(x.id));
        }
      });
      save(); rebuild(); alert("Content imported."); render();
    } catch (e) { alert("That does not look like valid JSON."); }
  }

  /* ----------------------------------------------------------------- nav */
  /* The sidebar used to be twenty-one flat links, eight of which were code
     categories already listed inside "All codes". Six groups instead: a
     student sees six words, opens the one they want, and the group holding
     the page they are on opens itself. Which groups are open is remembered,
     so the menu settles into the shape each person uses. */
  const NAVGROUPS = [
    {
      id: "codes", icon: "📚", label: () => (S.lang === "hi" ? "IS कोड" : "IS Codes"),
      count: () => CODES.length,
      items: () => [["codes", S.lang === "hi" ? "सभी कोड" : "All codes", "codes", CODES.length]].concat(
        CATS.map((c) => ["cat/" + c.id, catName(c), "cat:" + c.id,
          CODES.filter((x) => x.cat === c.id).length])
          .filter((r) => r[3] > 0)
      ),
    },
    {
      id: "materials", icon: "🧱", label: () => (S.lang === "hi" ? "सामग्री" : "Materials"),
      count: () => (DB.materials || []).length,
      items: () => [["materials", S.lang === "hi" ? "सभी सामग्री" : "All materials", "materials", (DB.materials || []).length]].concat(
        (DB.matCategories || []).map((c) => ["matcat/" + c.id, catName(c), "matcat:" + c.id,
          (DB.materials || []).filter((m) => (DB.matCatOf || {})[m.id] === c.id).length])
      ),
    },
    {
      id: "course", icon: "🗓", label: () => (S.lang === "hi" ? "कोर्स" : "Course"),
      count: () => (DB.semesters || []).length,
      items: () => [["courses", S.lang === "hi" ? "पूरा कोर्स" : "Master course", "courses", (DB.semesters || []).reduce((a, s) => a + (s.subjects || []).length, 0)]].concat(
        (DB.semesters || []).map((sm) => ["sem/" + sm.n, "Sem " + sm.n + " \u00b7 " + sm.name, "sem:" + sm.n, (sm.subjects || []).length])
      ),
    },
    {
      id: "study", icon: "🎓", label: () => (S.lang === "hi" ? "अध्ययन" : "Study"),
      items: () => [
        ["subjects", t("subjects"), "subjects", (DB.subjects || []).length],
        ["handbooks", t("handbooks"), "handbooks", (DB.handbooks || []).length],
        ["exam", t("exam"), "exam", MCQS.length],
        ["examples", "Solved examples", "examples", (DB.examples || []).length],
        ["paths", "Study paths", "paths", 0],
        ["compare", "Comparisons", "compare", 0],
        ["ai", "Quick answers", "ai", 0],
      ],
    },
    {
      id: "tools", icon: "🧮", label: () => (S.lang === "hi" ? "औज़ार" : "Tools"),
      items: () => [
        ["calc", "Calculators", "calc", CALC.list.length],
        ["tables", t("tables"), "tables", TABLES.length],
        ["formulas", t("formulas"), "formulas", FORMULAS.length],
        ["checklists", "Site checklists", "checklists", 0],
        ["project", "My project", "project", 0],
      ],
    },
  ];

  /* Which view belongs to which group, so the right one springs open. */
  function groupForView(view, params) {
    if (view === "codes" || view === "cat" || view === "code" || view === "clauses" || view === "topic") return "codes";
    if (view === "materials" || view === "matcat") return "materials";
    if (["courses", "sem", "csub"].includes(view)) return "course";
    if (["exam", "examples", "paths", "compare", "ai", "example", "subjects", "subject", "unit", "handbook", "read"].includes(view)) return "study";
    if (["calc", "tables", "table", "formulas", "formula", "checklists", "project"].includes(view)) return "tools";
    return "";
  }

  function navOpenSet() {
    if (!Array.isArray(S.navOpen)) S.navOpen = [];
    return S.navOpen;
  }

  function buildNav() {
    const { seg } = parseHash();
    const view = seg[0] || "home";
    const activeGroup = groupForView(view, seg);
    const open = navOpenSet();
    const closed = S.navClosed || [];
    const isOpen = (id) => !closed.includes(id) && (open.includes(id) || id === activeGroup);

    const link = (href, label, nav, count) =>
      `<a href="#/${href}" data-nav="${esc(nav)}" data-act="closenav">
         <span class="nav-l">${esc(label)}</span>
         ${count ? `<span class="nav-n mono">${count}</span>` : ""}</a>`;

    const group = (g) => {
      const items = g.items();
      const on = isOpen(g.id);
      return `<div class="nav-group${on ? " open" : ""}">
        <button class="nav-head" data-act="navgroup" data-g="${g.id}" aria-expanded="${on}">
          <span aria-hidden="true">${g.icon}</span>
          <span class="nav-l">${esc(g.label())}</span>
          ${g.count ? `<span class="nav-n mono">${g.count()}</span>` : ""}
          <span class="nav-caret" aria-hidden="true">▾</span>
        </button>
        <div class="nav-sub">${items.map(([h, l, n, c]) => link(h, l, n, c)).join("")}</div>
      </div>`;
    };

    $("#sidenav").innerHTML = `<a class="brand" href="#/" data-act="closenav">
        <span class="mark" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M3 20h18M6 20V9l6-5 6 5v11M10 20v-5h4v5"/></svg></span>
        <span class="brand-t"><strong>CIVIL</strong><em>EDUCATOR</em></span></a>
      <nav>
        <a href="#/" data-nav="home" data-act="closenav" class="nav-top"><span aria-hidden="true">🏠</span><span class="nav-l">${esc(t("home"))}</span></a>
        ${NAVGROUPS.map(group).join("")}
        <a href="#/library" data-nav="library" data-act="closenav" class="nav-top"><span aria-hidden="true">⭐</span><span class="nav-l">${esc(t("library"))}</span>${savedCount() ? `<span class="nav-n mono">${savedCount()}</span>` : ""}</a>
      </nav>
      <div class="side-foot">
        <button class="theme-btn" data-act="theme">${themeLabel()}</button>
        ${window.AUTH ? AUTH.navItem() : ""}
        <a href="#/profile" data-nav="profile" data-act="closenav"><span aria-hidden="true">👤</span><span class="nav-l">${esc(t("profile"))}</span></a>
        <a href="#/about" data-nav="about" data-act="closenav"><span aria-hidden="true">ℹ️</span><span class="nav-l">${esc(t("about"))}</span></a>
        <a href="#/policy" data-nav="policy" data-act="closenav"><span aria-hidden="true">⚖️</span><span class="nav-l">Content policy</span></a>
        <p class="fine">Educational reference. Verify against the published standard.</p>
      </div>`;

    $("#bottomnav").innerHTML = [
      ["", "🏠", t("home"), "home"],
      ["codes", "📚", S.lang === "hi" ? "कोड" : "Codes", "codes"],
      ["search", "🔍", t("search"), "search"],
      ["calc", "🧮", t("calc"), "calc"],
      ["exam", "🎓", S.lang === "hi" ? "परीक्षा" : "Exam", "exam"],
    ].map(([h, i, l, n]) => `<a href="#/${h}" data-nav="${n}"><span aria-hidden="true">${i}</span>${esc(l)}</a>`).join("");
  }

  function savedCount() {
    const sv = S.saved || {};
    return Object.keys(sv).reduce((n, k) => n + (Array.isArray(sv[k]) ? sv[k].length : 0), 0);
  }

  /* ---------------------------------------------------------------- boot */
  load();
  rebuild();
  applyTheme();
  buildNav();
  window.addEventListener("hashchange", render);
  render();
  maybeOnboard();

  if (window.AUTH) {
    AUTH.init({
      esc: esc,
      getState: () => S,
      setState: (next) => { S = Object.assign(S, next); save(); rebuild(); },
      render: render,
      buildNav: buildNav,
    });
  }

  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => { });
    });
  }
})();
