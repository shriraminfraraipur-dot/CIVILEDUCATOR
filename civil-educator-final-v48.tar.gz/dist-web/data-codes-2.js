/* ============================================================
   CIVIL EDUCATOR — additional codes for the material hub
   Appends to DB.categories and DB.codes.
   Most entries are marked "check" — confirm the current
   revision on the BIS portal before quoting them in design.
   ============================================================ */

window.DB = window.DB || {};
DB.categories = DB.categories || [];
DB.codes = DB.codes || [];

DB.categories.push({
  id: "finishes", name: "Finishes & Services", hi: "फिनिश एवं सेवाएँ", icon: "🎨",
  blurb: "Paints, tiles, glass, gypsum, waterproofing, aluminium, pipes",
});

const BIS2 = DB.meta.bisPortal;
const add = (o) => DB.codes.push(Object.assign({ docType: "IS", status: "check", src: BIS2 }, o));

/* ---------------------------------------------------- LIME */
add({
  id: "is712", number: "IS 712", year: "1984", cat: "masonry",
  title: "Building Limes — Specification",
  edition: "Third Revision, 1984 (reaffirmed) — confirm current revision",
  summary: "Classifies building limes into classes A to F by their hydraulicity and intended use, and gives the chemical and physical requirements for each.",
  keywords: ["lime", "fat lime", "hydraulic lime", "quick lime", "class a lime", "712", "slaking"],
  contents: ["Classification of building limes (Classes A to F)", "Chemical requirements", "Physical requirements", "Packing, marking and storage", "Sampling and criteria for conformity"],
  related: ["is6932", "is2250", "is1635"],
});
add({
  id: "is6932", number: "IS 6932 (Parts 1–11)", year: "1973", cat: "testing",
  title: "Methods of Tests for Building Limes",
  edition: "Published in parts — confirm the part applicable to your test",
  summary: "The test method series for building limes — fineness, residue, soundness, workability, volume yield, setting time, compressive and transverse strength.",
  keywords: ["lime test", "6932", "slaking test", "volume yield", "lime fineness"],
  contents: ["Part 1 Determination of insoluble residue, LOI and other constituents", "Part 2 Determination of carbon dioxide content", "Part 3 Determination of residue on slaking of quick lime", "Part 4 Determination of fineness of hydrated lime", "Part 5 Determination of volume yield of quick lime", "Part 6 Determination of available lime", "Part 7 Determination of compressive and transverse strength", "Part 8 Determination of workability", "Part 9 Determination of soundness"],
  related: ["is712", "is2250"],
});
add({
  id: "is1635", number: "IS 1635", year: "1992", cat: "masonry",
  title: "Field Slaking of Building Lime and Preparation of Putty — Code of Practice",
  edition: "Second Revision, 1992 (reaffirmed)",
  summary: "How lime is slaked on site and made into putty, including precautions for the heat generated during slaking.",
  keywords: ["slaking", "lime putty", "1635", "field slaking"],
  contents: ["Materials and equipment", "Method of slaking", "Preparation and storage of lime putty", "Precautions during slaking"],
  related: ["is712", "is2250"],
});

/* ---------------------------------------------------- POZZOLANA */
add({
  id: "is3812-1", number: "IS 3812 (Part 1)", year: "2013", cat: "rcc",
  title: "Pulverized Fuel Ash — Specification: For Use as Pozzolana in Cement, Cement Mortar and Concrete",
  edition: "Third Revision, 2013 — confirm current revision",
  summary: "Requirements for fly ash used as a pozzolana — fineness, lime reactivity, loss on ignition and chemical limits, for siliceous and calcareous ash.",
  keywords: ["fly ash", "3812", "pozzolana", "pfa", "lime reactivity", "class f", "ppc"],
  contents: ["Classification — siliceous and calcareous pulverized fuel ash", "Chemical requirements", "Physical requirements — fineness, lime reactivity, soundness", "Sampling and criteria for conformity"],
  related: ["is1344", "is269", "is456", "is10262"],
});
add({
  id: "is1344", number: "IS 1344", year: "1981", cat: "rcc",
  title: "Calcined Clay Pozzolana — Specification",
  edition: "Second Revision, 1981 (reaffirmed)",
  summary: "Requirements for calcined clay pozzolana used with lime or cement, including lime reactivity and fineness.",
  keywords: ["pozzolana", "calcined clay", "1344", "surkhi"],
  contents: ["Chemical requirements", "Physical requirements", "Lime reactivity", "Sampling and conformity"],
  related: ["is3812-1", "is712"],
});
add({
  id: "is2645", number: "IS 2645", year: "2003", cat: "rcc",
  title: "Integral Waterproofing Compounds for Cement Mortar and Concrete — Specification",
  edition: "Second Revision, 2003 (reaffirmed)",
  summary: "Requirements for integral waterproofing compounds added to the mix — permeability, setting time and strength effects.",
  keywords: ["waterproofing compound", "integral", "2645", "permeability"],
  contents: ["Types of compounds", "Requirements — permeability, setting time, compressive strength", "Test methods", "Packing and marking"],
  related: ["is3067", "is456", "is9103"],
});

/* ---------------------------------------------------- TIMBER */
add({
  id: "is883", number: "IS 883", year: "2016", cat: "masonry",
  title: "Design of Structural Timber in Building — Code of Practice",
  edition: "Fifth Revision, 2016 — confirm current revision",
  summary: "Structural design with timber — strength groups, permissible stresses, modification factors, joints and fasteners.",
  keywords: ["timber", "wood", "883", "structural timber", "group a b c", "permissible stress"],
  contents: ["Classification of timber by strength group", "Permissible stresses and modification factors", "Design of beams, columns and joints", "Fastenings and connections", "Workmanship"],
  related: ["is287", "is1141", "is401", "is399"],
});
add({
  id: "is287", number: "IS 287", year: "1993", cat: "masonry",
  title: "Recommendations for Maximum Permissible Moisture Content of Timber Used for Different Purposes in Different Zones",
  edition: "Third Revision, 1993 (reaffirmed)",
  summary: "Permissible moisture content of timber by climatic zone and end use — the single figure that decides whether joinery will warp after installation.",
  keywords: ["moisture content", "timber", "287", "zone", "seasoning"],
  contents: ["Climatic zones of India", "Permissible moisture content by end use", "Zone-wise recommendations"],
  related: ["is883", "is1141"],
});
add({
  id: "is1141", number: "IS 1141", year: "1993", cat: "masonry",
  title: "Seasoning of Timber — Code of Practice",
  edition: "Second Revision, 1993 (reaffirmed)",
  summary: "Air seasoning and kiln seasoning of timber, stacking arrangements, seasoning defects and their prevention.",
  keywords: ["seasoning", "timber", "1141", "kiln", "air seasoning"],
  contents: ["Purpose of seasoning", "Air seasoning — stacking and site", "Kiln seasoning schedules", "Seasoning defects", "Handling after seasoning"],
  related: ["is883", "is287", "is401"],
});
add({
  id: "is401", number: "IS 401", year: "2001", cat: "masonry",
  title: "Preservation of Timber — Code of Practice",
  edition: "Fifth Revision, 2001 (reaffirmed)",
  summary: "Preservatives and treatment methods for timber — pressure and non-pressure processes, retention requirements and handling of treated timber.",
  keywords: ["timber preservation", "401", "creosote", "ascu", "pressure treatment"],
  contents: ["Types of preservatives", "Non-pressure processes", "Pressure processes", "Retention and penetration requirements", "Handling and precautions"],
  related: ["is883", "is1141"],
});

/* ---------------------------------------------------- STONE */
add({
  id: "is1121-1", number: "IS 1121 (Part 1)", year: "2013", cat: "testing",
  title: "Methods of Test for Determination of Strength Properties of Natural Building Stones — Compressive Strength",
  edition: "Second Revision, 2013 — companion parts cover transverse, tensile and shear strength",
  summary: "Test method for the compressive strength of building stone, the property that decides whether a stone is fit for masonry.",
  keywords: ["stone test", "1121", "crushing strength stone", "building stone"],
  contents: ["Part 1 Compressive strength", "Part 2 Transverse strength", "Part 3 Tensile strength", "Part 4 Shear strength"],
  related: ["is1124", "is1122", "is1597-1"],
});
add({
  id: "is1124", number: "IS 1124", year: "1974", cat: "testing",
  title: "Method of Test for Determination of Water Absorption, Apparent Specific Gravity and Porosity of Natural Building Stones",
  edition: "First Revision, 1974 (reaffirmed)",
  summary: "Water absorption and porosity of building stone — the durability indicators that matter more than crushing strength for exposed work.",
  keywords: ["stone water absorption", "1124", "porosity", "specific gravity stone"],
  contents: ["Apparatus and specimens", "Water absorption procedure", "Apparent specific gravity", "Porosity calculation"],
  related: ["is1121-1", "is1122", "is1597-1"],
});
add({
  id: "is1122", number: "IS 1122", year: "1974", cat: "testing",
  title: "Method of Test for Determination of True Specific Gravity of Natural Building Stones",
  edition: "First Revision, 1974 (reaffirmed)",
  summary: "True specific gravity of building stone, used with the apparent value to compute porosity.",
  keywords: ["specific gravity", "stone", "1122"],
  contents: ["Apparatus", "Preparation of sample", "Procedure and calculation"],
  related: ["is1124", "is1121-1"],
});

/* ---------------------------------------------------- BITUMEN */
add({
  id: "is1205", number: "IS 1205", year: "1978", cat: "testing",
  title: "Methods for Testing Tar and Bituminous Materials — Determination of Softening Point",
  edition: "Second Revision, 1978 (reaffirmed) — confirm current revision",
  summary: "The ring and ball test for softening point, which indicates how a binder will behave at high pavement temperature.",
  keywords: ["softening point", "ring and ball", "1205", "bitumen test"],
  contents: ["Apparatus — ring and ball", "Procedure", "Reporting the softening point"],
  related: ["is73", "is1203", "is1208", "is1206"],
});
add({
  id: "is1208", number: "IS 1208", year: "1978", cat: "testing",
  title: "Methods for Testing Tar and Bituminous Materials — Determination of Ductility",
  edition: "Second Revision, 1978 (reaffirmed)",
  summary: "Ductility test — how far a briquette of binder stretches before breaking, an indicator of its ability to accommodate movement without cracking.",
  keywords: ["ductility", "1208", "bitumen test", "briquette"],
  contents: ["Apparatus and mould", "Test temperature and rate of pull", "Reporting"],
  related: ["is73", "is1203", "is1205"],
});
add({
  id: "is1206", number: "IS 1206 (Parts 1–3)", year: "1978", cat: "testing",
  title: "Methods for Testing Tar and Bituminous Materials — Determination of Viscosity",
  edition: "Published in parts; Part 2 covers absolute viscosity at 60 °C, the basis of the VG grading system",
  summary: "Viscosity test methods. Absolute viscosity at 60 °C is what the VG-10 to VG-40 grade designations refer to.",
  keywords: ["viscosity", "1206", "vg grade", "bitumen"],
  contents: ["Part 1 Industrial viscosity", "Part 2 Absolute viscosity", "Part 3 Kinematic viscosity"],
  related: ["is73", "is1203"],
});
add({
  id: "is8887", number: "IS 8887", year: "2018", cat: "highway",
  title: "Bitumen Emulsion for Roads — Specification",
  edition: "Third Revision, 2018 — confirm current revision",
  summary: "Cationic bitumen emulsions for road work — rapid setting, medium setting and slow setting grades used for tack coat, prime coat and surface dressing.",
  keywords: ["bitumen emulsion", "8887", "rs1", "ms", "ss", "tack coat", "prime coat"],
  contents: ["Types and grades of emulsion", "Requirements for each grade", "Test methods", "Storage and handling"],
  related: ["is73", "morth", "irc37"],
});
add({
  id: "is15462", number: "IS 15462", year: "2019", cat: "highway",
  title: "Polymer Modified Bitumen — Specification",
  edition: "First Revision, 2019 — confirm current revision",
  summary: "Requirements for polymer modified (PMB) and crumb rubber modified (CRMB) binders used on high-traffic and high-temperature pavements.",
  keywords: ["pmb", "crmb", "modified bitumen", "15462", "polymer"],
  contents: ["Types of modified binder", "Physical requirements by grade", "Test methods", "Storage and site handling"],
  related: ["is73", "is8887", "irc37", "morth"],
});

/* ---------------------------------------------------- PAINTS */
add({
  id: "is2395-1", number: "IS 2395 (Part 1)", year: "1994", cat: "finishes",
  title: "Painting of Concrete, Masonry and Plaster Surfaces — Code of Practice: Operations and Workmanship",
  edition: "Second Revision, 1994 (reaffirmed)",
  summary: "Surface preparation, priming, number of coats, workmanship and defects for painting masonry, plaster and concrete surfaces.",
  keywords: ["painting", "2395", "primer", "coats", "surface preparation", "paint defects"],
  contents: ["Preparation of surface", "Priming", "Application of finishing coats", "Workmanship and precautions", "Common defects"],
  related: ["is427", "is15489", "is1661"],
});
add({
  id: "is427", number: "IS 427", year: "1965", cat: "finishes",
  title: "Distemper, Dry, Colour as Required — Specification",
  edition: "First Revision, 1965 (reaffirmed)",
  summary: "Requirements for dry distemper — the low cost internal finish still widely used on plastered walls.",
  keywords: ["distemper", "427", "dry distemper", "internal paint"],
  contents: ["Composition and requirements", "Consistency and covering capacity", "Packing and marking"],
  related: ["is428", "is2395-1"],
});
add({
  id: "is428", number: "IS 428", year: "2000", cat: "finishes",
  title: "Distemper, Oil Emulsion, Colour as Required — Specification",
  edition: "Fourth Revision, 2000 (reaffirmed)",
  summary: "Requirements for oil-bound washable distemper, a step above dry distemper in durability and cleanability.",
  keywords: ["oil bound distemper", "obd", "428", "washable distemper"],
  contents: ["Composition", "Requirements — drying time, finish, washability", "Packing and marking"],
  related: ["is427", "is15489", "is2395-1"],
});
add({
  id: "is15489", number: "IS 15489", year: "2004", cat: "finishes",
  title: "Plastic Emulsion Paint — Specification",
  edition: "2004 (reaffirmed) — confirm current revision",
  summary: "Requirements for interior and exterior acrylic emulsion paints — the standard modern wall finish.",
  keywords: ["emulsion paint", "acrylic", "15489", "plastic emulsion"],
  contents: ["Types — interior and exterior", "Requirements — finish, drying time, scrub resistance", "Test methods", "Packing and marking"],
  related: ["is2395-1", "is428"],
});

/* ---------------------------------------------------- GLASS */
add({
  id: "is2835", number: "IS 2835", year: "1987", cat: "finishes",
  title: "Flat Transparent Sheet Glass — Specification",
  edition: "Third Revision, 1987 (reaffirmed) — float glass is covered by IS 14900",
  summary: "Requirements for flat transparent sheet glass — thickness, dimensions, tolerances and permissible defects.",
  keywords: ["sheet glass", "2835", "glazing", "glass thickness"],
  contents: ["Classification and thickness", "Dimensional tolerances", "Quality and permissible defects", "Packing and marking"],
  related: ["is14900", "is1948"],
});
add({
  id: "is14900", number: "IS 14900", year: "2018", cat: "finishes",
  title: "Transparent Float Glass — Specification",
  edition: "First Revision, 2018 — confirm current revision",
  summary: "Requirements for transparent float glass, the base product for toughened, laminated and insulated glazing.",
  keywords: ["float glass", "14900", "toughened", "laminated", "glazing"],
  contents: ["Nominal thickness and tolerance", "Optical and visual quality", "Dimensional requirements", "Sampling and conformity"],
  related: ["is2835", "is1948"],
});

/* ---------------------------------------------------- TILES */
add({
  id: "is1237", number: "IS 1237", year: "2012", cat: "finishes",
  title: "Cement Concrete Flooring Tiles — Specification",
  edition: "Second Revision, 2012 — confirm current revision",
  summary: "Requirements for cement concrete and terrazzo flooring tiles — dimensions, wet transverse strength, water absorption and abrasion resistance.",
  keywords: ["flooring tile", "1237", "terrazzo", "mosaic tile", "cement tile"],
  contents: ["Types and dimensions", "Wet transverse strength", "Water absorption", "Resistance to wear (abrasion)", "Sampling and conformity"],
  related: ["is15622", "is13630", "is1200-11"],
});
add({
  id: "is15622", number: "IS 15622", year: "2017", cat: "finishes",
  title: "Pressed Ceramic Tiles — Specification",
  edition: "Second Revision, 2017 — confirm current revision",
  summary: "Classification of pressed ceramic tiles by water absorption group, with dimensional, mechanical and surface quality requirements.",
  keywords: ["ceramic tile", "vitrified tile", "15622", "water absorption group", "tile"],
  contents: ["Classification by water absorption group", "Dimensions and surface quality", "Mechanical properties — breaking strength, modulus of rupture", "Chemical and stain resistance", "Marking"],
  related: ["is13630", "is1237"],
});
add({
  id: "is13630", number: "IS 13630 (Parts 1–16)", year: "2006", cat: "testing",
  title: "Ceramic Tiles — Methods of Test, Sampling and Basis for Acceptance",
  edition: "Published in parts, each covering one property",
  summary: "Test methods for ceramic tiles — water absorption, breaking strength, abrasion resistance, thermal shock, stain and chemical resistance.",
  keywords: ["tile test", "13630", "water absorption tile", "abrasion", "pei"],
  contents: ["Water absorption, apparent porosity and density", "Modulus of rupture and breaking strength", "Resistance to deep and surface abrasion", "Thermal shock and crazing resistance", "Chemical and stain resistance"],
  related: ["is15622", "is1237"],
});

/* ---------------------------------------------------- PIPES */
add({
  id: "is4985", number: "IS 4985", year: "2021", cat: "water",
  title: "Unplasticized PVC Pipes for Potable Water Supplies — Specification",
  edition: "Confirm current revision",
  summary: "UPVC pipe requirements by pressure class and nominal outside diameter, with dimensional, hydrostatic and impact requirements.",
  keywords: ["upvc", "pvc pipe", "4985", "pressure class", "water supply pipe"],
  contents: ["Classification by pressure rating", "Dimensions and tolerances", "Hydrostatic and impact requirements", "Marking", "Sampling and conformity"],
  related: ["is15778", "is4984", "is1239-1", "is2065"],
});
add({
  id: "is15778", number: "IS 15778", year: "2007", cat: "water",
  title: "Chlorinated Polyvinyl Chloride (CPVC) Pipes for Potable Hot and Cold Water Distribution — Specification",
  edition: "2007 (reaffirmed) — confirm current revision",
  summary: "CPVC pipe requirements for hot and cold water plumbing, by SDR class, with temperature and pressure ratings.",
  keywords: ["cpvc", "15778", "hot water pipe", "sdr 11", "plumbing"],
  contents: ["Material and classification", "Dimensions by SDR class", "Pressure and temperature ratings", "Test requirements", "Marking"],
  related: ["is4985", "is2065", "is1239-1"],
});
add({
  id: "is4984", number: "IS 4984", year: "2016", cat: "water",
  title: "Polyethylene Pipes for Water Supply — Specification",
  edition: "Fifth Revision, 2016 — confirm current revision",
  summary: "HDPE pipe requirements by material grade (PE 63, PE 80, PE 100) and pressure rating, for buried water mains.",
  keywords: ["hdpe", "polyethylene pipe", "4984", "pe100", "water main"],
  contents: ["Material grades", "Dimensions and pressure ratings", "Physical and mechanical requirements", "Jointing", "Marking"],
  related: ["is4985", "is15778"],
});
add({
  id: "is1239-1", number: "IS 1239 (Part 1)", year: "2004", cat: "water",
  title: "Steel Tubes, Tubulars and Other Wrought Steel Fittings — Specification: Steel Tubes",
  edition: "Sixth Revision, 2004 (with amendments)",
  summary: "Galvanized and black steel tubes in light, medium and heavy classes, used for water supply, fire lines and structural tubing.",
  keywords: ["gi pipe", "steel tube", "1239", "medium class", "heavy class"],
  contents: ["Classification — light, medium and heavy", "Dimensions and mass", "Mechanical and hydraulic tests", "Galvanizing requirements", "Marking"],
  related: ["is4985", "is15778", "is2065"],
});

/* ---------------------------------------------------- GYPSUM */
add({
  id: "is2547-1", number: "IS 2547 (Part 1)", year: "1976", cat: "finishes",
  title: "Gypsum Building Plaster — Specification: Excluding Premixed Lightweight Plaster",
  edition: "First Revision, 1976 (reaffirmed)",
  summary: "Requirements for gypsum building plaster — fineness, setting time, soundness and strength.",
  keywords: ["gypsum plaster", "pop", "2547", "plaster of paris", "punning"],
  contents: ["Types of gypsum plaster", "Physical requirements — fineness, setting time, strength", "Test methods", "Packing and storage"],
  related: ["is2095-1", "is1661"],
});
add({
  id: "is2095-1", number: "IS 2095 (Part 1)", year: "2011", cat: "finishes",
  title: "Gypsum Plaster Boards — Specification: Plain Gypsum Plaster Boards",
  edition: "Third Revision, 2011 — confirm current revision",
  summary: "Requirements for gypsum plaster boards used in false ceilings and drywall partitions.",
  keywords: ["gypsum board", "drywall", "false ceiling", "2095", "plasterboard"],
  contents: ["Types and dimensions", "Physical requirements — transverse strength, moisture", "Surface finish", "Packing and handling"],
  related: ["is2547-1"],
});

/* ---------------------------------------------------- WATERPROOFING */
add({
  id: "is3067", number: "IS 3067", year: "1988", cat: "finishes",
  title: "General Design Details and Preparatory Work for Damp-Proofing and Waterproofing of Buildings — Code of Practice",
  edition: "First Revision, 1988 (reaffirmed)",
  summary: "Design principles and preparatory work for damp proofing and waterproofing — slopes, junctions, upturns, drainage and detailing at penetrations.",
  keywords: ["waterproofing", "damp proofing", "3067", "dpc", "terrace", "slope"],
  contents: ["Principles of waterproofing", "Preparatory work and surface preparation", "Design details at junctions and penetrations", "Drainage and slopes", "Protection of the waterproofing layer"],
  related: ["is1322", "is2645", "is1346"],
});
add({
  id: "is1322", number: "IS 1322", year: "1993", cat: "finishes",
  title: "Bitumen Felts for Waterproofing and Damp-proofing — Specification",
  edition: "Fifth Revision, 1993 (reaffirmed)",
  summary: "Requirements for bitumen felt used in built-up waterproofing treatment and damp proof courses.",
  keywords: ["bitumen felt", "1322", "waterproofing felt", "dpc"],
  contents: ["Types and grades of felt", "Requirements — mass, breaking strength, pliability", "Test methods", "Packing and marking"],
  related: ["is3067", "is1346"],
});
add({
  id: "is1346", number: "IS 1346", year: "1991", cat: "finishes",
  title: "Waterproofing of Roofs with Bitumen Felts — Code of Practice",
  edition: "Third Revision, 1991 (reaffirmed)",
  summary: "Application of built-up bitumen felt waterproofing on roofs — surface preparation, number of layers, laying and protection.",
  keywords: ["roof waterproofing", "1346", "bitumen felt roof", "built up treatment"],
  contents: ["Preparation of roof surface", "Grades of treatment", "Laying of felt layers", "Treatment at junctions and outlets", "Protective finish"],
  related: ["is3067", "is1322"],
});

/* ---------------------------------------------------- ALUMINIUM */
add({
  id: "is733", number: "IS 733", year: "1983", cat: "finishes",
  title: "Wrought Aluminium and Aluminium Alloy Bars, Rods and Sections (For General Engineering Purposes) — Specification",
  edition: "Third Revision, 1983 (reaffirmed)",
  summary: "Aluminium alloy designations, tempers and mechanical properties for extruded bars, rods and sections used in windows, doors and partitions.",
  keywords: ["aluminium", "733", "alloy", "extrusion", "window section"],
  contents: ["Alloy designations and tempers", "Chemical composition", "Mechanical properties", "Dimensional tolerances", "Sampling and testing"],
  related: ["is1948", "is14900"],
});
add({
  id: "is1948", number: "IS 1948", year: "1961", cat: "finishes",
  title: "Aluminium Doors, Windows and Ventilators — Specification",
  edition: "1961 (reaffirmed) — confirm current revision and related standards",
  summary: "Requirements for aluminium doors, windows and ventilators — sections, fabrication, glazing and fixing.",
  keywords: ["aluminium window", "1948", "ventilator", "glazing", "anodising"],
  contents: ["Materials and sections", "Fabrication and assembly", "Glazing", "Fixing and hardware", "Finish and protection"],
  related: ["is733", "is14900", "is2835"],
});

/* ---------------------------------------------------- MEASUREMENT */
add({
  id: "is1200-11", number: "IS 1200 (Part 11)", year: "1977", cat: "estimation",
  title: "Methods of Measurement of Building and Civil Engineering Works — Paving, Floor Finishes, Dado and Skirting",
  edition: "Third Revision, 1977 (reaffirmed) — confirm the part numbering against the current series",
  summary: "Measurement rules for flooring, paving, dado and skirting — units, deductions and classification.",
  keywords: ["flooring measurement", "1200 part 11", "dado", "skirting", "paving"],
  contents: ["Classification of floor finishes", "Rules of measurement", "Deductions", "Units of measurement"],
  related: ["is1237", "is15622", "is1200-12"],
});
