/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: GEOTECHNICAL ENGINEERING
   Chapter 3 — Permeability
   Chapter 4 — Seepage and Flow Nets
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "ge"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 3 */
    {
      id: "ge-3",
      n: 3,
      title: "Permeability",
      hi: "पारगम्यता",
      blurb: "How fast water moves through soil — the property that decides whether a clay is one material or two.",
      mins: 34,
      sections: [

        {
          n: "3.1",
          title: "Darcy's law",
          hi: "डार्सी का नियम",
          blocks: [
            { k: "p", t: "Water flows through soil along the connected voids between grains. Darcy found in 1856 that for the slow, laminar flow that occurs in almost all soils, the velocity is simply proportional to the hydraulic gradient." },
            { k: "eq", expr: "v = k i        q = k i A", where: [
              ["v", "discharge velocity, m/s"],
              ["i", "hydraulic gradient = head loss / length over which it is lost, dimensionless"],
              ["k", "coefficient of permeability, m/s — the whole subject of this chapter"],
              ["A", "total cross-sectional area, including the solids"],
            ]},
            { k: "trap", t: "v is a fiction, and a useful one. It is the flow divided by the <strong>total</strong> area, including the grains that water cannot pass through. The real velocity in the pores — the seepage velocity — is larger: vs = v/n, where n is the porosity. Use v for computing quantities of flow, and vs when asking how long a contaminant takes to travel." },
            { k: "def", term: "Hydraulic gradient", t: "The loss of <em>total head</em> per unit length of flow path. Total head is elevation head plus pressure head; velocity head is negligible at seepage velocities and is always dropped. Water flows from high total head to low total head — never simply downhill, and never simply from high pressure to low." },
            { k: "p", t: "That definition is worth pausing on, because it is the source of most confusion in Chapter 4. Water can and does flow <em>upward</em> through soil, against gravity, whenever the total head below is greater than the total head above — which is exactly what happens at the downstream toe of a dam." },
          ],
        },

        {
          n: "3.2",
          title: "What k depends on",
          hi: "k किस पर निर्भर है",
          blocks: [
            { k: "p", t: "The range of k across ordinary soils is astonishing — about ten orders of magnitude, from clean gravel to intact clay. No other engineering property in this app varies by anything like that much, and it is the reason sands and clays need entirely different treatments." },
            { k: "cmp", t: "Typical values. The point is not the numbers but the gap between them.",
              cols: ["k (m/s), order of magnitude"],
              rows: [
                ["Clean gravel", "10⁻¹ and above"],
                ["Clean sand, sand–gravel mixtures", "10⁻² to 10⁻⁵"],
                ["Fine sand, silty sand", "10⁻⁵ to 10⁻⁷"],
                ["Silt, clayey silt", "10⁻⁷ to 10⁻⁹"],
                ["Intact clay", "below 10⁻⁹"],
              ] },
            { k: "list", items: [
              "<strong>Grain size</strong> — the dominant factor. k varies roughly as the square of the effective size, so halving D10 quarters the permeability. Allen Hazen's old rule k (cm/s) ≈ 100 D10², with <strong>D10 in centimetres</strong>, is still a useful sanity check for clean, fairly uniform sands (D10 about 0.1–3 mm, Cu ≤ 5).",
              "<strong>Void ratio</strong> — more voids, more flow. k increases with e, though not linearly.",
              "<strong>Grading</strong> — a well graded soil has its voids blocked by fines and is <em>less</em> permeable than a uniform soil of the same average size.",
              "<strong>Structure and stratification</strong> — a layered deposit passes water along its layers far more readily than across them. §3.4 quantifies this.",
              "<strong>Properties of the fluid</strong> — k as normally quoted includes the viscosity of water, so it changes with temperature. Values are conventionally corrected to 27 °C in Indian practice: k₂₇ = k_T × (η_T/η₂₇), as in the <a href=\"https://archive.nptel.ac.in/content/storage2/courses/105103097/web/exp-6-final/s2.htm\" target=\"_blank\" rel=\"noopener\">NPTEL laboratory module</a>.",
              "<strong>Degree of saturation</strong> — trapped air blocks pores, so a partly saturated soil is less permeable than the same soil saturated.",
            ]},
            { k: "eg",
              title: "Example 3.1 — Hazen as a sanity check",
              given: "A clean, uniform sand has D10 = 0.15 mm.",
              steps: [
                { t: "Convert D10 to cm", w: "0.15 mm = 0.015 cm" },
                { t: "Hazen", w: "k ≈ 100 × 0.015² = 0.0225 cm/s = 2.3 × 10⁻⁴ m/s" },
              ],
              ans: "About 2 × 10⁻⁴ m/s — clean sand, as the table expects. Using D10 in millimetres instead gives 2.25 cm/s, the permeability of gravel: the unit error is a factor of 100." },
            { k: "note", t: "<b>Correction (v39):</b> an earlier version wrote Hazen's rule with D10 in millimetres. <a href=\"https://www.aqtesolv.com/aquifer-tests/aquifer_properties.htm\" target=\"_blank\" rel=\"noopener\">AQTESOLV</a> states K = C D10² with K in cm/s, D10 in cm and C typically 100 (published values span 1–1000), valid for about 0.1 ≤ D10 ≤ 3 mm and Cu ≤ 5; <a href=\"https://www.dot.state.mn.us/mnroad/nrra/structure-teams/geotechnical/files/permeability-base-task-2-lit-review-final-2020-08-24.pdf\" target=\"_blank\" rel=\"noopener\">a MnDOT literature review</a> gives the same relationship in SI form with D10 in mm and a constant of order 10⁻³ m/s per mm² — the two are consistent." },
          ],
        },

        {
          n: "3.3",
          title: "Measuring it",
          hi: "मापन",
          blocks: [
            { k: "dia", id: "hb-ge-perm", cap: "Constant head for soils that flow freely; falling head for those that do not." },
            { k: "eq", expr: "constant head:   k = Q L / (A h t)", where: [
              ["Q", "volume of water collected in time t"],
              ["L", "length of the sample"],
              ["h", "the constant head difference"],
            ]},
            { k: "eq", expr: "falling head:   k = 2.303 (a L)/(A t) × log₁₀(h₁/h₂)", where: [
              ["a", "cross-sectional area of the standpipe — deliberately small"],
              ["h₁, h₂", "head at the start and end of the timed interval"],
            ]},
            { k: "p", t: "The choice is decided by k itself. A sand passes enough water in a minute to measure comfortably at constant head. A clay would take days to yield a measurable volume, so instead a thin standpipe is watched: the small area <em>a</em> converts a tiny flow into a large, easily timed drop in level." },
            { k: "eg",
              title: "Example 3.2 — Falling head test",
              given: "A falling head permeameter with a sample 150 mm long and 78.54 cm² in area, and a standpipe of 0.785 cm² cross-section. The head fell from 600 mm to 300 mm in 15 minutes.",
              steps: [
                { t: "Put everything in consistent units", w: "a = 0.785 cm²,  A = 78.54 cm²,  L = 15.0 cm\nt = 15 × 60 = 900 s\nh₁ = 60.0 cm,  h₂ = 30.0 cm" },
                { t: "Apply the formula", w: "k = 2.303 × (0.785 × 15.0)/(78.54 × 900) × log₁₀(60/30)\n  = 2.303 × 11.775/70,686 × log₁₀(2)\n  = 2.303 × 1.6659 × 10⁻⁴ × 0.30103" },
                { t: "Evaluate", w: "k = 1.155 × 10⁻⁴ cm/s\n  = 1.155 × 10⁻⁶ m/s" },
                { t: "What kind of soil is that?", w: "10⁻⁶ m/s sits between fine sand and silt — consistent with a silty fine sand or a coarse silt." },
              ],
              ans: "k = 1.16 × 10⁻⁶ m/s. The last step matters: a permeability that does not match the soil you think you tested means either the test or the description is wrong, and it is worth finding out which before the value goes into a design.",
            },
            { k: "list", items: [
              "<strong>Field pumping tests</strong> give a k averaged over a large volume of real ground, including the fissures and sand lenses a 100 mm laboratory sample will never contain. For a major dewatering design they are worth far more than any laboratory value.",
              "<strong>Indirect methods</strong> — k can also be back-calculated from a consolidation test, using k = cv mv γw. Useful, and much less reliable than measuring it.",
            ]},
            { k: "trap", t: "Laboratory permeability is one of the least trustworthy numbers in geotechnics, and it is nearly always <em>too low</em>. A sample cannot contain the sand seam or the root hole that actually carries most of the flow in the field, and a value an order of magnitude out is routine. Design dewatering on field tests, not on a permeameter." },
          ],
        },

        {
          n: "3.4",
          title: "Layered soils",
          hi: "स्तरित मिट्टी",
          blocks: [
            { k: "p", t: "Natural deposits are layered, and a layered soil has two quite different permeabilities depending on which way the water goes." },
            { k: "eq", expr: "parallel to the layers:   kh = Σ(kᵢ zᵢ) / Σzᵢ", where: [] },
            { k: "eq", expr: "perpendicular to them:    kv = Σzᵢ / Σ(zᵢ / kᵢ)", where: [] },
            { k: "p", t: "Those are a weighted arithmetic mean and a weighted harmonic mean respectively, and the reason for the difference is physical rather than mathematical. Flowing <em>along</em> the layers, water uses the most permeable layer as a motorway and the total flow is dominated by it. Flowing <em>across</em> them, every layer must be crossed in series, so the least permeable one is a bottleneck and controls everything." },
            { k: "eg",
              title: "Example 3.3 — How lopsided the two can be",
              given: "Three horizontal layers: 2.0 m of sand at k = 5 × 10⁻⁴ m/s, 3.0 m of clay at k = 2 × 10⁻⁶ m/s, and 1.5 m of silt at k = 1 × 10⁻⁵ m/s.",
              steps: [
                { t: "Horizontal — arithmetic mean, weighted by thickness", w: "kh = [2.0(5×10⁻⁴) + 3.0(2×10⁻⁶) + 1.5(1×10⁻⁵)]/6.5\n   = [1.0×10⁻³ + 6.0×10⁻⁶ + 1.5×10⁻⁵]/6.5\n   = 1.021×10⁻³/6.5 = 1.571 × 10⁻⁴ m/s" },
                { t: "Vertical — harmonic mean", w: "Σ(z/k) = 2.0/(5×10⁻⁴) + 3.0/(2×10⁻⁶) + 1.5/(1×10⁻⁵)\n       = 4000 + 1,500,000 + 150,000 = 1,654,000\nkv = 6.5/1,654,000 = 3.930 × 10⁻⁶ m/s" },
                { t: "The ratio", w: "kh/kv = 1.571×10⁻⁴ / 3.930×10⁻⁶ = 40" },
              ],
              ans: "kh is 40 times kv. Look at the vertical calculation: the clay layer contributes 1,500,000 of the 1,654,000 total — 91% of the resistance from 46% of the thickness. The sand is almost irrelevant vertically and dominant horizontally.",
            },
            { k: "real", t: "This is why an excavation in layered ground floods from the sides rather than the base, and why a single clay layer can perch a water table above the main one. It is also why a cut-off wall must be taken <em>through</em> the permeable layer and into the impermeable one — stopping short leaves the motorway open." },
          ],
        },

        {
          n: "3.5",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "v = ki, q = kiA. v is a fictitious velocity over the whole area; seepage velocity is v/n.",
              "Water flows from high TOTAL head to low total head — which can be upward.",
              "k spans ten orders of magnitude from gravel to clay.",
              "Constant head for permeable soils, falling head for impermeable ones.",
              "Laboratory k is nearly always too low; field pumping tests for anything important.",
              "kh is a weighted arithmetic mean, kv a weighted harmonic mean — and the least permeable layer controls vertical flow.",
            ]},
            { k: "p", t: "Chapter 4 takes this one permeability and asks what happens when water flows through a whole structure — under a dam, into an excavation — where the flow is two-dimensional and the gradient varies from point to point." },
          ],
        },
      ],
    },

    /* ============================================================ CH 4 */
    {
      id: "ge-4",
      n: 4,
      title: "Seepage and Flow Nets",
      hi: "रिसाव और प्रवाह जाल",
      blurb: "Two-dimensional flow, drawn rather than solved — and the gradient that makes sand behave like a liquid.",
      mins: 38,
      sections: [

        {
          n: "4.1",
          title: "Two-dimensional flow",
          hi: "द्वि-आयामी प्रवाह",
          blocks: [
            { k: "p", t: "Chapter 3 dealt with flow along a single path with a single gradient. Under a dam, behind a sheet pile or into an excavation, water moves in two dimensions and the gradient differs from point to point. The governing equation, for steady flow through a saturated, homogeneous, isotropic soil, is Laplace's:" },
            { k: "eq", expr: "∂²h/∂x²  +  ∂²h/∂z²  =  0", where: [
              ["h", "total head"],
            ]},
            { k: "p", t: "That equation has been solved analytically for a handful of idealised geometries and numerically for everything else. But it also has a <em>graphical</em> solution that requires no mathematics at all — and understanding the graphical one is the fastest route to understanding what the numerical one is doing." },
            { k: "def", term: "Flow line", t: "The path a particle of water takes through the soil." },
            { k: "def", term: "Equipotential line", t: "A line joining all points of equal total head. Water has no reason to flow along one, so flow lines cross them at right angles — and that orthogonality is what makes a flow net drawable." },
          ],
        },

        {
          n: "4.2",
          title: "The flow net",
          hi: "फ्लो नेट",
          blocks: [
            { k: "dia", id: "hb-ge-flownet", cap: "Flow lines and equipotentials crossing at right angles, forming approximate squares." },
            { k: "p", t: "A flow net is a family of flow lines and a family of equipotentials, drawn by trial until they cross at right angles everywhere and the figures between them are approximately <strong>square</strong>. The squareness is not decoration — it is the condition that makes each figure pass the same quantity of water under the same head drop, which is what lets you simply count them." },
            { k: "eq", expr: "q = k H (Nf / Nd)     per unit length perpendicular to the section", where: [
              ["H", "total head loss across the whole net"],
              ["Nf", "number of flow channels — the spaces between flow lines, not the lines"],
              ["Nd", "number of equipotential drops — the spaces between equipotentials"],
            ]},
            { k: "trap", t: "Count the <strong>spaces</strong>, not the lines. Five flow lines bound four channels, so Nf = 4, not 5. Getting this wrong changes the answer by 25% and it is the single most common error in flow net work." },
            { k: "list", items: [
              "The <strong>upstream and downstream ground surfaces</strong> are equipotentials — the water above them is at rest and at constant head.",
              "The <strong>base of the structure and the impermeable boundary</strong> are flow lines — nothing crosses them.",
              "The head drop per figure is <strong>H/Nd</strong>, equal everywhere in the net.",
              "At any point, the pore water pressure follows from the total head there minus the elevation head.",
            ]},
            { k: "eg",
              title: "Example 4.1 — Seepage under a sheet pile",
              given: "A sheet pile wall retains 6.0 m of head. A flow net drawn for the section has 5 flow channels and 12 equipotential drops. The soil has k = 3 × 10⁻⁵ m/s.",
              steps: [
                { t: "Seepage quantity", w: "q = k H (Nf/Nd) = 3×10⁻⁵ × 6.0 × (5/12)\n  = 3×10⁻⁵ × 6.0 × 0.4167\n  = 7.50 × 10⁻⁵ m³/s per metre run" },
                { t: "In units anyone can picture", w: "= 7.50 × 10⁻⁵ × 86,400 = 6.48 m³ per day per metre of wall\nFor a 40 m long excavation with two sides: about 518 m³/day" },
                { t: "Head loss per figure", w: "H/Nd = 6.0/12 = 0.50 m per drop" },
              ],
              ans: "6.48 m³ per day per metre — which for the whole excavation is 518 m³/day, and that number is the pump specification. This is the calculation that decides whether a dewatering scheme is a few pumps or a major undertaking.",
            },
            { k: "eg",
              title: "Example 4.2 — Pore pressure at a point, from the same net",
              given: "In the flow net of Example 4.1, point P lies on the 8th equipotential from the upstream side, 7.0 m below the downstream water level (taken as datum).",
              steps: [
                { t: "Total head at P", w: "upstream total head = 6.0 m; after 8 drops of 0.5 m: h = 6.0 − 8 × 0.5 = 2.0 m" },
                { t: "Pressure head", w: "elevation head z = −7.0 m  →  pressure head = h − z = 2.0 − (−7.0) = 9.0 m" },
                { t: "Pore pressure", w: "u = 9.0 × 9.81 = 88.3 kPa  (hydrostatic alone would be 7.0 × 9.81 = 68.7 kPa)" },
              ],
              ans: "u = 88.3 kPa — 19.6 kPa more than the static water table suggests, because P is still upstream of most of the head loss. This is the number that goes into uplift and effective-stress checks." },
          ],
        },

        {
          n: "4.3",
          title: "The quick condition",
          hi: "क्विक कंडीशन",
          blocks: [
            { k: "p", t: "The seepage quantity is usually the less important of a flow net's two answers. The more important one is what the upward gradient does to the soil at the downstream exit." },
            { k: "p", t: "Where water flows <strong>upward</strong>, it exerts a drag on the grains — a seepage force. As the gradient increases, that force eventually equals the submerged weight of the soil, at which point the grains are no longer pressed against each other. The effective stress becomes zero, and a soil with no effective stress has <em>no shear strength at all</em>." },
            { k: "eq", expr: "critical hydraulic gradient   icr = γ′/γw = (G − 1)/(1 + e)", where: [] },
            { k: "p", t: "For a typical sand with G = 2.65 and e = 0.85, icr = 1.65/1.85 = 0.89. Values close to 1.0 are usual, which is why the quick condition is often quoted as \"a gradient of about unity\" — but it is worth computing rather than assuming, because a loose sand with a high void ratio reaches it sooner." },
            { k: "def", term: "Quicksand", t: "Not a type of soil — a <em>condition</em>. Any cohesionless soil subjected to an upward gradient equal to icr becomes quick. The famous property of swallowing things is real but exaggerated: the mixture is denser than a person, so you float in it rather than sink." },
            { k: "list", items: [
              "<strong>Piping</strong> — once a quick condition starts at the exit, grains are carried away, forming a channel that works backwards towards the water source. The channel shortens the flow path, which raises the gradient, which erodes faster. It is self-accelerating and it has destroyed dams.",
              "<strong>Boiling / heave</strong> — the base of an excavation lifting bodily under upward seepage.",
              "<strong>Factor of safety</strong> — normally taken as icr/iexit, and values of 4 to 5 are usual for a dam, because the consequence is catastrophic and the exit gradient is the least reliable output of a flow net.",
            ]},
            { k: "eg",
              title: "Example 4.3 — Safety against piping at the exit",
              given: "In the same net, the last square at the downstream exit is 0.80 m long in the direction of flow. The sand has G = 2.65 and e = 0.70.",
              steps: [
                { t: "Exit gradient", w: "i_exit = (H/Nd)/l = 0.50/0.80 = 0.625" },
                { t: "Critical gradient", w: "icr = (G − 1)/(1 + e) = 1.65/1.70 = 0.971" },
                { t: "Factor of safety", w: "FS = 0.971/0.625 = 1.55" },
              ],
              ans: "FS ≈ 1.6 — far below the 4–5 normally wanted. Drive the sheet pile deeper (more drops, smaller exit gradient), add a loaded filter at the exit, or lower the head with relief wells." },
            { k: "real", t: "The engineering answers all attack the gradient rather than the soil. A <strong>filter</strong> — a graded layer that lets water out but holds grains in — is the classic remedy, and it is why every earth dam has a filter at its downstream toe. A <strong>cut-off wall</strong> or a longer flow path reduces the gradient itself; <strong>relief wells</strong> let the pressure out before it can lift anything." },
          ],
        },

        {
          n: "4.4",
          title: "Uplift, and what to carry forward",
          hi: "उत्थान और सार",
          blocks: [
            { k: "p", t: "The other thing a flow net gives you is the pore pressure on the <em>base of the structure</em>. Water seeping beneath a dam or a hydraulic structure is under pressure, and that pressure acts upward on the underside — reducing the effective weight holding the structure down." },
            { k: "p", t: "It is computed directly from the net: count the drops to the point in question, subtract from the upstream head, convert to pressure. Integrated across the base it becomes the <strong>uplift force</strong>, and it enters the overturning and sliding checks of any hydraulic structure exactly as the earth pressure of Chapter 10 does for a retaining wall." },
            { k: "trap", t: "Uplift is invisible and it does not appear in the loading schedule unless someone puts it there. A gravity dam checked for overturning without uplift can look comfortably safe and be nowhere near it — the force acts upward over a very large area and it can exceed the weight of a substantial part of the structure." },
            { k: "list", items: [
              "Laplace's equation governs; a flow net solves it graphically.",
              "Flow lines and equipotentials cross at right angles, forming approximate squares.",
              "q = k H (Nf/Nd), counting SPACES not lines.",
              "Head loss per drop = H/Nd, equal throughout the net.",
              "icr = (G − 1)/(1 + e), usually close to 1.0. At that gradient σ′ = 0 and the soil has no strength.",
              "Piping is self-accelerating; filters, cut-offs and relief wells are the remedies.",
              "Uplift on the base of a structure comes from the same net and must be in the load case.",
            ]},
            { k: "p", t: "Chapter 4 has been quietly using an idea it never defined: that the grains carry one part of the stress and the water carries another. Chapter 5 states it properly, and it is the most important chapter in this handbook." },
          ],
        },
      ],
    }

  );
})();
