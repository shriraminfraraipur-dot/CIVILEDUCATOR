/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS for Strength of Materials, Chapter 6.
   Conventions as in dia-hb-som-ch1.js.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 6.1  CORE / KERN */
  "hb-som-kern": {
    label: "Core (kern) of rectangular and circular sections, and stress under an eccentric load",
    svg: `<svg viewBox="0 0 640 360" role="img" aria-label="Left: a rectangle b wide and d deep with a shaded rhombus at its centre whose half-diagonals are b over 6 horizontally and d over 6 vertically — the core. Below it a circle of diameter d with a shaded central circle of diameter d over 4 — its core. Right: three stress diagrams across the depth of the rectangle for a compressive load at eccentricity e. When e is less than d over 6 the stress is compressive everywhere, larger on the load side. When e equals d over 6 the stress just reaches zero at the far edge — a triangle. When e is greater than d over 6, tension appears at the far edge.">
      <!-- rectangle + kern -->
      <rect class="conc" x="40" y="30" width="150" height="210"/>
      <path class="soft-b" d="M115 100 L140 135 L115 170 L90 135 Z"/>
      <line class="dash" x1="40" y1="135" x2="190" y2="135"/><line class="dash" x1="115" y1="30" x2="115" y2="240"/>
      <text class="em" x="146" y="128">b/6</text><text class="em" x="120" y="96">d/6</text>
      <text class="lb" x="115" y="256" text-anchor="middle">b</text><text class="lb" x="28" y="139">d</text>
      <!-- circle + kern -->
      <circle class="conc" cx="115" cy="305" r="45" style="opacity:1"/>
      <circle class="soft-b" cx="115" cy="305" r="11.25"/>
      <text class="em" x="170" y="300">core ⌀ d/4</text>
      <text class="lb" x="170" y="316">(e ≤ d/8)</text>

      <!-- stress diagrams: baseline width 120, depth 210 (y 30..240) -->
      ${[[270,"e < d/6",60,10],[390,"e = d/6",70,0],[510,"e > d/6",80,-20]].map(([x,t,a,b])=>`
        <line class="s" x1="${x}" y1="30" x2="${x}" y2="240"/>
        <path class="soft-b" d="${b>=0?`M${x} 30 L${x+a} 30 L${x+b} 240 L${x} 240 Z`:`M${x} 30 L${x+a} 30 L${x} ${30+210*a/(a-b)} Z`}"/>
        ${b<0?`<path class="soft-b" d="M${x} 240 L${x+b} 240 L${x} ${30+210*a/(a-b)} Z" style="fill:var(--accent)"/>`:""}
        <line class="hi" x1="${x+a}" y1="30" x2="${x+b}" y2="240"/>
        <text class="em" x="${x+30}" y="268" text-anchor="middle">${t}</text>`).join("")}
      <text class="lb" x="270" y="20">load side ↑ (compression)</text>
      <text class="ea" x="500" y="292">tension at far edge</text>
      <text class="lb" x="270" y="300">σ = P/A · (1 ± 6e/d)</text>
    </svg>`,
    caption: "Keep the load inside the shaded core and the whole section stays in compression — essential for masonry, plain concrete footings and dams, which cannot take tension. For a rectangle the core is the 'middle third' (b/6 or d/6 each side of centre).",
  },

  /* ---------------------------------------- 6.2  TORSION SHEAR STRESS */
  "hb-som-torsion": {
    label: "Shear stress in a twisted shaft — linear with radius; solid vs hollow",
    svg: `<svg viewBox="0 0 640 300" role="img" aria-label="Left: a shaft fixed at one end with a torque T applied at the other; a straight line drawn along its surface twists into a helix through angle gamma, and the end section rotates through the angle of twist theta. Right: two cross-sections. In the solid section the shear stress grows linearly from zero at the centre to tau max at the surface. In the hollow section the stress grows linearly from a non-zero value at the inner radius to tau max at the outer surface; the lightly stressed core has been removed, which is why hollow shafts are lighter for the same strength.">
      ${somMk("sm11")}
      <rect class="conc" x="20" y="60" width="14" height="120"/>
      <rect class="conc" x="34" y="95" width="220" height="50" rx="4"/>
      <line class="dash" x1="34" y1="120" x2="280" y2="120"/>
      <line class="thin" x1="34" y1="96" x2="254" y2="96"/>
      <path class="hi" d="M34 96 Q 150 104 254 132"/>
      <text class="em" x="150" y="90">γ (helix)</text>
      <path class="ac" d="M266 92 A 30 30 0 1 1 266 148" marker-end="url(#sm11-c)"/>
      <text class="ea" x="296" y="124">T</text>
      <text class="lb" x="140" y="170" text-anchor="middle">θ = TL/GJ at the free end</text>

      <!-- solid section -->
      <circle class="conc" cx="410" cy="120" r="60"/>
      <line class="thin" x1="410" y1="120" x2="470" y2="120"/>
      <path class="soft-b" d="M410 120 L470 120 L470 70 Z"/>
      <line class="hi" x1="410" y1="120" x2="470" y2="70"/>
      <text class="em" x="474" y="68">τ_max</text>
      <text class="lb" x="410" y="204" text-anchor="middle">Solid: τ ∝ r</text>

      <!-- hollow section -->
      <circle class="conc" cx="560" cy="120" r="60"/>
      <circle class="s" cx="560" cy="120" r="36" style="fill:var(--surface,#fff)"/>
      <path class="soft-b" d="M596 120 L620 120 L620 70 L596 90 Z"/>
      <line class="hi" x1="596" y1="90" x2="620" y2="70"/>
      <text class="lb" x="560" y="204" text-anchor="middle">Hollow: core removed</text>
      <text class="lb" x="485" y="250" text-anchor="middle">Material near the surface does the work.</text>
    </svg>`,
    caption: "Plane circular sections stay plane and radii stay straight, so shear strain — and stress — grows linearly from the axis. The material near the centre does little work; removing it (hollow shaft) saves weight for almost the same torque capacity.",
  },
});
