/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: BUILDING SERVICES & SAFETY · Ch 6–8
   Fire load & resistance · Detection & suppression · Waterproofing
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "bs");
  if (!hb) { console.error("[bs3] handbook bs not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 6 */
    {
      id: "bs-6",
      n: 6,
      title: "Fire Load and Fire Resistance",
      hi: "अग्नि भार और अग्नि प्रतिरोध",
      blurb: "How much fire a building can produce, how long its walls hold it back, and how compartmentation boxes a fire in to buy time.",
      mins: 20,
      sections: [
        {
          n: "6.1",
          title: "Fire load and resistance rating",
          hi: "अग्नि भार और रेटिंग",
          blocks: [
            { k: "p", t: "Once people are escaping (Chapter 5), the second job is to slow the fire down so they have time. That means knowing how big a fire the building can produce, and how long its structure can resist it." },
            { k: "dia", id: "hb-bs-fire", cap: "The fire triangle, fire load, resistance rating and compartmentation." },
            { k: "def", term: "Fire load", t: "The amount of combustible material (the building's contents and any combustible structure) per unit floor area, usually expressed in terms of the equivalent weight of wood or its heat energy per m². A higher fire load means a hotter, longer-lasting fire — a paper warehouse has a far higher fire load than an empty hall, and needs correspondingly more protection." },
            { k: "def", term: "Fire-resistance rating", t: "How long an element — a wall, floor, beam, door — can hold back a standard fire before it fails to carry load, or lets flame or excessive heat through. It is rated in hours (½, 1, 2, 4 h). The rating required depends on the building's use, height and fire load: taller, more crowded, more combustible buildings demand higher ratings." },
            { k: "trap", t: "Fire resistance is not fireproofing — nothing is fireproof. A 2-hour wall does not stop the fire; it holds it back for two hours, which is time bought for escape and firefighting. Confusing 'fire-rated' with 'fireproof' leads people to expect a rated element to survive indefinitely, when its whole design basis is a limited, defined period. The number is hours, and hours run out." },
          ],
        },
        {
          n: "6.2",
          title: "Compartmentation — boxing the fire in",
          hi: "कम्पार्टमेंटेशन",
          blocks: [
            { k: "p", t: "The most powerful use of fire-resistant construction is compartmentation: dividing a building into fire-tight boxes with rated walls and floors, so a fire starting in one compartment is held there and cannot spread through the whole building while people escape." },
            { k: "def", term: "Compartmentation", t: "Dividing a building into compartments bounded by fire-resistant walls and floors of a rated resistance, with any openings (doors, service penetrations) protected to the same rating. A fire is then confined to its compartment for the rated period — it cannot race through corridors and shafts to trap people or overwhelm the structure." },
            { k: "trap", t: "Compartmentation is only as good as its weakest penetration. A perfectly rated wall is useless if a cable tray, a duct or a pipe passes through it via an unsealed hole — the fire and smoke simply go through the gap. Fire-stopping every service penetration to the wall's rating is therefore essential and endlessly neglected, because the holes are made later by other trades who never see the fire strategy. <strong>A fire wall with an open hole in it is not a fire wall.</strong>" },
            { k: "real", t: "Smoke, not flame, kills most fire victims, and compartmentation and its sealed openings are as much about containing smoke as fire. Staircases are kept smoke-free (often pressurised) precisely because they are the escape route, and a smoke-logged stair is a death trap even far from the flames. <strong>Every rated door held shut, every penetration sealed, is keeping smoke out of the path people need.</strong>" },
          ],
        },
      ],
    },

    /* ============================================================ CH 7 */
    {
      id: "bs-7",
      n: 7,
      title: "Fire Detection and Suppression",
      hi: "अग्नि पहचान और शमन",
      blurb: "The active systems — detectors that raise the alarm early, and the water systems (sprinklers, hydrants) that fight the fire — and why early warning matters most.",
      mins: 18,
      sections: [
        {
          n: "7.1",
          title: "Detection — the earlier the better",
          hi: "पहचान",
          blocks: [
            { k: "p", t: "Everything in fire safety is a race against time, and the clock starts when the fire is noticed. Detection systems win time at the most valuable moment — the very start — by raising the alarm while the fire is still small and everyone can still leave calmly." },
            { k: "cmp", t: "How fires are detected",
              cols: ["Senses"],
              rows: [
                ["Smoke detector", "smoke particles — earliest warning, for escape routes & sleeping areas"],
                ["Heat detector", "a temperature rise — for dusty/steamy areas where smoke detectors false-alarm"],
                ["Manual call point", "a person breaking the glass — human detection"],
                ["Alarm & PA", "warns everyone and directs the evacuation"],
              ] },
            { k: "note", t: "Smoke detection matters most in exactly the places people are most vulnerable: escape routes (which must stay usable) and sleeping accommodation (where occupants are unconscious of the fire). A few minutes' earlier warning is the difference between a calm walk out and a panic — which is why smoke detectors, not heat detectors, guard the routes and the bedrooms, despite costing more and false-alarming more." },
          ],
        },
        {
          n: "7.2",
          title: "Suppression — water where the fire is",
          hi: "शमन",
          blocks: [
            { k: "p", t: "Suppression systems fight the fire itself, and the workhorse is water, delivered automatically by sprinklers or by firefighters through hydrants and hose reels fed from the building's fire water storage." },
            { k: "list", items: [
              "<strong>Sprinklers</strong> — heads that open individually when the heat above them bursts a glass bulb, showering water only on the fire below. They act automatically, immediately, and only where needed — often controlling a fire before the brigade arrives.",
              "<strong>Wet risers / hydrants</strong> — pipes kept charged with water, with landing valves on each floor for firefighters to connect hoses to, so they need not run hose up from the street.",
              "<strong>Hose reels</strong> — for first-aid firefighting by occupants on a small fire.",
              "<strong>Fire water tank & pumps</strong> — a dedicated reserve of water and pumps that guarantee pressure and flow when the fire systems are called on.",
            ] },
            { k: "trap", t: "A common misconception is that a fire sets off every sprinkler in the building, drenching everything. It does not: each sprinkler head opens independently, only when the heat directly beneath it bursts its own bulb, so usually just one or two heads over the actual fire operate. The image of a whole floor showering at once is from films, not engineering. <strong>Sprinklers are surgical, not indiscriminate</strong> — which is why the water damage they cause is far less than the fire they prevent." },
            { k: "real", t: "The fire water tank and its dedicated pumps are the reason the whole active system can be trusted: they hold a reserve that ordinary use can never draw down, and pumps (often with a diesel backup) that will run when mains power has failed in the fire. <strong>An automatic system is only as reliable as its water and power on the worst day</strong> — which is why the fire reserve and standby pumps are protected and tested, not shared with the daily supply." },
          ],
        },
      ],
    },

    /* ============================================================ CH 8 */
    {
      id: "bs-8",
      n: 8,
      title: "Waterproofing and Damp Proofing",
      hi: "वाटरप्रूफिंग और डैम्प प्रूफिंग",
      blurb: "Keeping water out of a building — the difference between damp proofing and waterproofing, where each is used, and why it is the cheapest durability money there is.",
      mins: 18,
      sections: [
        {
          n: "8.1",
          title: "Two different jobs — damp, and water",
          hi: "दो अलग काम",
          blocks: [
            { k: "p", t: "Keeping water out of a building splits into two related but distinct jobs. Damp proofing resists moisture — water in the form of dampness and vapour, moving slowly by capillary action. Waterproofing resists liquid water under pressure — a roof under rain, a basement below the water table, a water tank. They use different measures and it matters which the situation needs." },
            { k: "cmp", t: "Damp proofing vs waterproofing",
              cols: ["Damp proofing", "Waterproofing"],
              rows: [
                ["Resists", "moisture, dampness, vapour", "liquid water under pressure"],
                ["Where", "walls (DPC), floors on ground", "roofs, basements, wet areas, tanks"],
                ["Example", "the DPC at plinth level", "roof membrane, basement tanking"],
                ["Fails as", "rising damp, blistered plaster", "active leaks, ponding, seepage"],
              ] },
            { k: "note", t: "The damp-proof course (DPC) from the Building Construction handbook is the classic damp-proofing measure — a barrier at plinth level stopping ground moisture rising into the walls. Waterproofing is a bigger job: a continuous membrane or coating that must stay perfect over a whole roof or basement, because liquid water under pressure finds any gap. The wetter and more pressured the situation, the more it is waterproofing, not damp proofing." },
          ],
        },
        {
          n: "8.2",
          title: "The cheapest durability money there is",
          hi: "सबसे सस्ता टिकाऊपन",
          blocks: [
            { k: "p", t: "Water is the root of most building decay — rising damp, leaking roofs, saturated walls, and, worst of all, water reaching the reinforcement in concrete and corroding it. So money spent keeping water out is the most cost-effective durability spend on the whole building, and the first place to look when a building ages badly." },
            { k: "list", items: [
              "<strong>Roofs</strong> — the biggest water-exposed surface; a membrane or coating with adequate slope to drain, no ponding.",
              "<strong>Basements</strong> — below the water table, so under constant pressure; tanked with a continuous membrane, the hardest waterproofing job.",
              "<strong>Wet areas</strong> — bathrooms, kitchens, terraces; waterproofed and drained so leaks do not reach the structure below.",
              "<strong>Water-retaining structures</strong> — tanks and reservoirs, waterproofed to hold water in as well as keep it out.",
            ] },
            { k: "real", t: "Trace almost any complaint about an ageing building — stained ceilings, damp walls, cracked and spalling concrete with rusting bars showing — and it comes back to water that got in and was not kept out. Fixing it after the fact means opening up finished work; doing it right at construction is a fraction of the cost. <strong>Waterproofing is the durability investment that repays itself many times over</strong>, and skimping it is the false economy that most reliably shortens a building's life." },
          ],
        },
      ],
    },

  );
})();
