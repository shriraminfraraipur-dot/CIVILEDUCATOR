/* ============================================================
   CIVIL EDUCATOR — Calculator engine and definitions
   Each calculator: id, cat, name, ref, formula, inputs, run()
   run(v) returns { results:[{label,value,unit}], steps:[string] }
   ============================================================ */

window.CALC = (function () {
  const n = (x) => (isFinite(x) ? x : 0);
  const r = (x, d = 2) => {
    if (!isFinite(x)) return "—";
    const f = Math.pow(10, d);
    return (Math.round(x * f) / f).toLocaleString("en-IN", { maximumFractionDigits: d });
  };
  const CEMENT_BAG_M3 = 0.0347; // 50 kg at 1440 kg/m³
  const MIXES = {
    "M5 (1:5:10)": [1, 5, 10], "M7.5 (1:4:8)": [1, 4, 8], "M10 (1:3:6)": [1, 3, 6],
    "M15 (1:2:4)": [1, 2, 4], "M20 (1:1.5:3)": [1, 1.5, 3], "1:1:2 (rich)": [1, 1, 2],
  };
  const MORTAR = { "1:3": [1, 3], "1:4": [1, 4], "1:5": [1, 5], "1:6": [1, 6], "1:8": [1, 8] };
  const TAUBD = { 20: 1.2, 25: 1.4, 30: 1.5, 35: 1.7, 40: 1.9 };
  const TAUCMAX = { 20: 2.8, 25: 3.1, 30: 3.5, 35: 3.7, 40: 4.0 };
  const XUMAX = { 250: 0.53, 415: 0.48, 500: 0.46 };

  function taubd(fck, deformed, compression) {
    const keys = [20, 25, 30, 35, 40];
    let k = 40;
    for (const key of keys) { if (fck <= key) { k = key; break; } }
    let t = TAUBD[k];
    if (deformed) t *= 1.6;
    if (compression) t *= 1.25;
    return t;
  }
  function taucmax(fck) {
    const keys = [20, 25, 30, 35, 40];
    let k = 40;
    for (const key of keys) { if (fck <= key) { k = key; break; } }
    return TAUCMAX[k];
  }
  /* IS 456:2000 — expression given with Table 19 */
  function tauc(fck, pt) {
    if (pt <= 0) pt = 0.15;
    let beta = (0.8 * fck) / (6.89 * pt);
    if (beta < 1) beta = 1;
    return (0.85 * Math.sqrt(0.8 * fck) * (Math.sqrt(1 + 5 * beta) - 1)) / (6 * beta);
  }

  /* ---------------- unit conversion helper ---------------- */
  function converter(id, name, units, defFrom, defTo, ref) {
    return {
      id, cat: "conv", name, ref: ref || "SI definitions",
      formula: "value in base unit = input × factor of source unit; output = base ÷ factor of target unit",
      inputs: [
        { k: "v", label: "Value", type: "number", def: 1 },
        { k: "from", label: "From", type: "select", opts: Object.keys(units), def: defFrom },
        { k: "to", label: "To", type: "select", opts: Object.keys(units), def: defTo },
      ],
      run(v) {
        const base = n(+v.v) * units[v.from];
        const out = base / units[v.to];
        const rows = Object.keys(units).map((u) => ({ label: u, value: r(base / units[u], 6), unit: "" }));
        return {
          results: [{ label: `${v.v} ${v.from}`, value: r(out, 6), unit: v.to, big: true }],
          steps: [`${v.v} ${v.from} × ${units[v.from]} = ${r(base, 6)} (base unit)`, `${r(base, 6)} ÷ ${units[v.to]} = ${r(out, 6)} ${v.to}`],
          table: { cols: ["Unit", "Value"], rows: rows.map((x) => [x.label, x.value]) },
        };
      },
    };
  }

  const list = [
    /* =========================== RCC =========================== */
    {
      id: "concrete-qty", cat: "rcc", name: "Concrete Quantity & Materials",
      ref: "Nominal mixes from IS 456:2000 Table 9; dry volume factor 1.54 is accepted site practice",
      formula: "Dry volume = 1.54 × wet volume · Cement = dry volume × (1 / total parts) · Bags = cement volume ÷ 0.0347",
      inputs: [
        { k: "L", label: "Length", unit: "m", type: "number", def: 5 },
        { k: "B", label: "Width", unit: "m", type: "number", def: 3 },
        { k: "D", label: "Thickness / depth", unit: "m", type: "number", def: 0.15 },
        { k: "mix", label: "Nominal mix", type: "select", opts: Object.keys(MIXES), def: "M20 (1:1.5:3)" },
        { k: "wc", label: "Water-cement ratio", type: "number", def: 0.5, step: 0.01 },
      ],
      run(v) {
        const vol = n(+v.L) * n(+v.B) * n(+v.D);
        const dry = vol * 1.54;
        const p = MIXES[v.mix], tot = p[0] + p[1] + p[2];
        const cem = (dry * p[0]) / tot, sand = (dry * p[1]) / tot, agg = (dry * p[2]) / tot;
        const bags = cem / CEMENT_BAG_M3, kg = bags * 50, water = kg * n(+v.wc);
        return {
          results: [
            { label: "Wet concrete volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "Dry volume (×1.54)", value: r(dry, 3), unit: "m³" },
            { label: "Cement", value: r(bags, 2), unit: "bags (" + r(kg, 0) + " kg)" },
            { label: "Sand (fine aggregate)", value: r(sand, 3), unit: "m³ (" + r(sand * 35.3147, 2) + " cft)" },
            { label: "Coarse aggregate", value: r(agg, 3), unit: "m³ (" + r(agg * 35.3147, 2) + " cft)" },
            { label: "Water (approx.)", value: r(water, 0), unit: "litres" },
          ],
          steps: [
            `Wet volume = ${v.L} × ${v.B} × ${v.D} = ${r(vol, 3)} m³`,
            `Dry volume = 1.54 × ${r(vol, 3)} = ${r(dry, 3)} m³`,
            `Mix ${v.mix} → total parts = ${tot}`,
            `Cement = ${r(dry, 3)} × ${p[0]}/${tot} = ${r(cem, 3)} m³ = ${r(cem, 3)} ÷ 0.0347 = ${r(bags, 2)} bags`,
            `Sand = ${r(dry, 3)} × ${p[1]}/${tot} = ${r(sand, 3)} m³ · Aggregate = ${r(dry, 3)} × ${p[2]}/${tot} = ${r(agg, 3)} m³`,
            `Water = ${r(kg, 0)} kg cement × ${v.wc} = ${r(water, 0)} litres`,
          ],
          note: "Nominal mixes are permitted only up to M20 (IS 456 Cl. 9.1.1). Above M20 use a design mix as per IS 10262.",
        };
      },
    },
    {
      id: "steel-weight", cat: "rcc", name: "Steel Weight (bars)",
      ref: "Derived from steel density 7850 kg/m³; nominal masses specified in IS 1786",
      formula: "w = d² / 162 kg per metre (d in mm) · Total = w × length × number of bars",
      inputs: [
        { k: "d", label: "Bar diameter", unit: "mm", type: "select", opts: ["6", "8", "10", "12", "16", "20", "25", "32", "36", "40"], def: "12" },
        { k: "L", label: "Length of one bar", unit: "m", type: "number", def: 12 },
        { k: "nos", label: "Number of bars", type: "number", def: 10 },
      ],
      run(v) {
        const d = +v.d, w = (d * d) / 162, tot = w * n(+v.L) * n(+v.nos);
        return {
          results: [
            { label: "Unit weight", value: r(w, 3), unit: "kg/m" },
            { label: "Weight of one bar", value: r(w * n(+v.L), 2), unit: "kg" },
            { label: "Total weight", value: r(tot, 2), unit: "kg (" + r(tot / 1000, 3) + " tonne)", big: true },
          ],
          steps: [`w = ${d}² / 162 = ${r(w, 4)} kg/m`, `Total = ${r(w, 4)} × ${v.L} m × ${v.nos} bars = ${r(tot, 2)} kg`],
        };
      },
    },
    {
      id: "dev-length", cat: "rcc", name: "Development Length (Ld)",
      ref: "IS 456:2000, Cl. 26.2.1 and Cl. 26.2.1.1",
      formula: "Ld = φ σs / (4 τbd) · σs = 0.87 fy · τbd × 1.6 for deformed bars, × 1.25 further for compression",
      inputs: [
        { k: "d", label: "Bar diameter φ", unit: "mm", type: "select", opts: ["6", "8", "10", "12", "16", "20", "25", "32", "36", "40"], def: "16" },
        { k: "fy", label: "Steel grade fy", unit: "N/mm²", type: "select", opts: ["250", "415", "500", "550"], def: "500" },
        { k: "fck", label: "Concrete grade fck", unit: "N/mm²", type: "select", opts: ["20", "25", "30", "35", "40"], def: "25" },
        { k: "bar", label: "Bar type", type: "select", opts: ["Deformed (HYSD / TMT)", "Plain (mild steel)"], def: "Deformed (HYSD / TMT)" },
        { k: "cond", label: "Condition", type: "select", opts: ["Tension", "Compression"], def: "Tension" },
      ],
      run(v) {
        const d = +v.d, fy = +v.fy, fck = +v.fck;
        const deformed = v.bar.startsWith("Deformed") && fy > 250;
        const comp = v.cond === "Compression";
        const t = taubd(fck, deformed, comp);
        const sigma = 0.87 * fy;
        const mult = sigma / (4 * t);
        const Ld = mult * d;
        return {
          results: [
            { label: "Design bond stress τbd", value: r(t, 3), unit: "N/mm²" },
            { label: "Ld as a multiple of φ", value: r(mult, 1), unit: "φ" },
            { label: "Development length Ld", value: r(Ld, 0), unit: "mm", big: true },
          ],
          steps: [
            `σs = 0.87 × ${fy} = ${r(sigma, 1)} N/mm²`,
            `τbd (plain, tension) for M${fck} = ${TAUBD[Math.min(40, [20, 25, 30, 35, 40].find((k) => fck <= k) || 40)]} N/mm²` +
              (deformed ? " → × 1.6 for deformed bars" : "") + (comp ? " → × 1.25 for compression" : "") + ` = ${r(t, 3)} N/mm²`,
            `Ld = ${d} × ${r(sigma, 1)} / (4 × ${r(t, 3)}) = ${r(Ld, 0)} mm ≈ ${r(mult, 1)} φ`,
          ],
          note: "σs is taken as 0.87 fy, i.e. the bar developing its full design strength. Where the bar is stressed to less than that, σs may be reduced proportionately.",
        };
      },
    },
    {
      id: "lap-length", cat: "rcc", name: "Lap Length",
      ref: "IS 456:2000, Cl. 26.2.5.1",
      formula: "Flexural tension: greater of Ld and 30 φ · Direct tension: greater of 2 Ld and 30 φ · Compression: greater of Ld(compression) and 24 φ",
      inputs: [
        { k: "d", label: "Bar diameter φ", unit: "mm", type: "select", opts: ["8", "10", "12", "16", "20", "25", "32"], def: "16" },
        { k: "fy", label: "Steel grade fy", unit: "N/mm²", type: "select", opts: ["250", "415", "500"], def: "500" },
        { k: "fck", label: "Concrete grade fck", unit: "N/mm²", type: "select", opts: ["20", "25", "30", "35", "40"], def: "25" },
        { k: "type", label: "Type of lap", type: "select", opts: ["Flexural tension", "Direct tension", "Compression"], def: "Flexural tension" },
      ],
      run(v) {
        const d = +v.d, fy = +v.fy, fck = +v.fck;
        const deformed = fy > 250;
        const comp = v.type === "Compression";
        const t = taubd(fck, deformed, comp);
        const Ld = (0.87 * fy * d) / (4 * t);
        let req, basis;
        if (v.type === "Flexural tension") { req = Math.max(Ld, 30 * d); basis = `greater of Ld = ${r(Ld, 0)} mm and 30 φ = ${30 * d} mm`; }
        else if (v.type === "Direct tension") { req = Math.max(2 * Ld, 30 * d); basis = `greater of 2 Ld = ${r(2 * Ld, 0)} mm and 30 φ = ${30 * d} mm`; }
        else { req = Math.max(Ld, 24 * d); basis = `greater of Ld(compression) = ${r(Ld, 0)} mm and 24 φ = ${24 * d} mm`; }
        return {
          results: [
            { label: "Development length Ld", value: r(Ld, 0), unit: "mm (" + r(Ld / d, 1) + " φ)" },
            { label: "Lap length required", value: r(req, 0), unit: "mm (" + r(req / d, 1) + " φ)", big: true },
          ],
          steps: [`τbd = ${r(t, 3)} N/mm²`, `Ld = ${d} × 0.87 × ${fy} / (4 × ${r(t, 3)}) = ${r(Ld, 0)} mm`, `${v.type}: ${basis} → ${r(req, 0)} mm`],
          note: "Laps should be staggered and kept away from sections of maximum stress (Cl. 26.2.5.1).",
        };
      },
    },
    {
      id: "bar-spacing", cat: "rcc", name: "Bar Spacing / Area of Steel per Metre",
      ref: "Spacing limits from IS 456:2000 Cl. 26.3.3(b)",
      formula: "Ast per metre = (1000 / spacing) × area of one bar · area = π d² / 4",
      inputs: [
        { k: "mode", label: "Find", type: "select", opts: ["Ast from spacing", "Spacing from required Ast"], def: "Ast from spacing" },
        { k: "d", label: "Bar diameter", unit: "mm", type: "select", opts: ["6", "8", "10", "12", "16", "20", "25"], def: "10" },
        { k: "s", label: "Spacing (for mode 1)", unit: "mm", type: "number", def: 150 },
        { k: "ast", label: "Required Ast (for mode 2)", unit: "mm²/m", type: "number", def: 400 },
        { k: "D", label: "Slab thickness (for spacing check)", unit: "mm", type: "number", def: 150 },
      ],
      run(v) {
        const d = +v.d, a = (Math.PI * d * d) / 4;
        const dEff = Math.max(10, n(+v.D) - 25);
        const maxMain = Math.min(3 * dEff, 300);
        let out, steps;
        if (v.mode === "Ast from spacing") {
          const s = n(+v.s), ast = (1000 / s) * a;
          out = [{ label: "Area of one bar", value: r(a, 1), unit: "mm²" }, { label: "Ast provided", value: r(ast, 0), unit: "mm² per metre", big: true }];
          steps = [`Area of one ${d} mm bar = π × ${d}²/4 = ${r(a, 1)} mm²`, `Ast = (1000 / ${s}) × ${r(a, 1)} = ${r(ast, 0)} mm²/m`];
        } else {
          const need = n(+v.ast), s = (1000 * a) / need;
          const sUse = Math.floor(s / 5) * 5;
          out = [{ label: "Area of one bar", value: r(a, 1), unit: "mm²" }, { label: "Spacing required", value: r(s, 0), unit: "mm" }, { label: "Adopt spacing", value: r(sUse, 0), unit: "mm c/c", big: true }];
          steps = [`Spacing = 1000 × ${r(a, 1)} / ${need} = ${r(s, 0)} mm`, `Round down to a practical value: ${sUse} mm c/c`];
        }
        return {
          results: out,
          steps: steps.concat([`Maximum spacing for main bars = lesser of 3d and 300 mm ≈ ${r(maxMain, 0)} mm (with assumed d = ${r(dEff, 0)} mm)`]),
          note: "Main bars: spacing ≤ 3d or 300 mm, whichever is smaller. Distribution bars: ≤ 5d or 450 mm (IS 456 Cl. 26.3.3).",
        };
      },
    },
    {
      id: "mu-lim", cat: "rcc", name: "Limiting Moment of Resistance",
      ref: "IS 456:2000, Cl. 38.1 and Annex G",
      formula: "xu,max/d = 0.53 / 0.48 / 0.46 (Fe 250 / 415 / 500) · Mu,lim = 0.36 fck b xu,max (d − 0.42 xu,max)",
      inputs: [
        { k: "fck", label: "Concrete grade fck", unit: "N/mm²", type: "select", opts: ["20", "25", "30", "35", "40"], def: "25" },
        { k: "fy", label: "Steel grade fy", unit: "N/mm²", type: "select", opts: ["250", "415", "500"], def: "415" },
        { k: "b", label: "Width b", unit: "mm", type: "number", def: 300 },
        { k: "d", label: "Effective depth d", unit: "mm", type: "number", def: 450 },
      ],
      run(v) {
        const fck = +v.fck, fy = +v.fy, b = n(+v.b), d = n(+v.d);
        const k = XUMAX[fy], xu = k * d;
        const Mu = 0.36 * fck * b * xu * (d - 0.42 * xu);
        const coef = Mu / (fck * b * d * d);
        const ast = Mu / (0.87 * fy * (d - 0.42 * xu));
        return {
          results: [
            { label: "xu,max / d", value: k, unit: "" },
            { label: "xu,max", value: r(xu, 1), unit: "mm" },
            { label: "Mu,lim", value: r(Mu / 1e6, 2), unit: "kN·m", big: true },
            { label: "Coefficient (Mu,lim / fck b d²)", value: r(coef, 3), unit: "" },
            { label: "Ast at the limiting condition", value: r(ast, 0), unit: "mm²" },
          ],
          steps: [
            `xu,max = ${k} × ${d} = ${r(xu, 1)} mm`,
            `Mu,lim = 0.36 × ${fck} × ${b} × ${r(xu, 1)} × (${d} − 0.42 × ${r(xu, 1)}) = ${r(Mu / 1e6, 2)} kN·m`,
            `Check: coefficient = ${r(coef, 3)} (code values 0.148 / 0.138 / 0.133 for Fe 250 / 415 / 500)`,
          ],
          note: "If the factored moment exceeds Mu,lim the section must be doubly reinforced or made deeper.",
        };
      },
    },
    {
      id: "ast-singly", cat: "rcc", name: "Area of Steel — Singly Reinforced Beam",
      ref: "IS 456:2000, Annex G.1.1",
      formula: "Mu = 0.87 fy Ast (d − fy Ast / (fck b)) — solved for Ast",
      inputs: [
        { k: "Mu", label: "Factored moment Mu", unit: "kN·m", type: "number", def: 150 },
        { k: "fck", label: "Concrete grade fck", unit: "N/mm²", type: "select", opts: ["20", "25", "30", "35", "40"], def: "25" },
        { k: "fy", label: "Steel grade fy", unit: "N/mm²", type: "select", opts: ["250", "415", "500"], def: "415" },
        { k: "b", label: "Width b", unit: "mm", type: "number", def: 300 },
        { k: "d", label: "Effective depth d", unit: "mm", type: "number", def: 450 },
      ],
      run(v) {
        const Mu = n(+v.Mu) * 1e6, fck = +v.fck, fy = +v.fy, b = n(+v.b), d = n(+v.d);
        const k = XUMAX[fy], xu = k * d;
        const Mulim = 0.36 * fck * b * xu * (d - 0.42 * xu);
        const A = (0.87 * fy * fy) / (fck * b);
        const B = -0.87 * fy * d;
        const C = Mu;
        const disc = B * B - 4 * A * C;
        const steps = [`Mu,lim = ${r(Mulim / 1e6, 2)} kN·m`];
        let results;
        if (Mu > Mulim) {
          results = [{ label: "Section status", value: "Mu exceeds Mu,lim", unit: "— doubly reinforced section or larger depth required", big: true },
          { label: "Mu,lim", value: r(Mulim / 1e6, 2), unit: "kN·m" }];
          steps.push(`Applied Mu = ${r(Mu / 1e6, 2)} kN·m > Mu,lim → singly reinforced solution is not valid.`);
        } else if (disc < 0) {
          results = [{ label: "Section status", value: "No real solution — increase the section", unit: "", big: true }];
        } else {
          const ast = (-B - Math.sqrt(disc)) / (2 * A);
          const pt = (100 * ast) / (b * d);
          const astMin = (0.85 / fy) * b * d;
          results = [
            { label: "Ast required", value: r(ast, 0), unit: "mm²", big: true },
            { label: "pt = 100 Ast / bd", value: r(pt, 3), unit: "%" },
            { label: "Minimum Ast (0.85/fy × bd)", value: r(astMin, 0), unit: "mm²" },
            { label: "Governing Ast", value: r(Math.max(ast, astMin), 0), unit: "mm²" },
          ];
          steps.push(`Solving 0.87 fy Ast (d − fy Ast/(fck b)) = Mu gives Ast = ${r(ast, 0)} mm²`);
          steps.push(`Minimum steel = 0.85/${fy} × ${b} × ${d} = ${r(astMin, 0)} mm² (Cl. 26.5.1.1)`);
          [12, 16, 20, 25].forEach(() => { });
          const bars = [12, 16, 20, 25].map((dia) => {
            const a1 = (Math.PI * dia * dia) / 4;
            return `${Math.ceil(Math.max(ast, astMin) / a1)} nos – ${dia} mm`;
          });
          steps.push("Bar options: " + bars.join("  ·  "));
        }
        return { results, steps, note: "Check the maximum limit of 0.04 b D and the detailing rules of Cl. 26.5.1 before finalising." };
      },
    },
    {
      id: "tauc-calc", cat: "rcc", name: "Shear Check — τv, τc and τc,max",
      ref: "IS 456:2000, Cl. 40, the expression given with Table 19, and Table 20",
      formula: "τv = Vu/(b d) · τc = 0.85 √(0.8 fck)(√(1+5β) − 1)/(6β) with β = 0.8 fck/(6.89 pt) ≥ 1",
      inputs: [
        { k: "Vu", label: "Factored shear Vu", unit: "kN", type: "number", def: 150 },
        { k: "b", label: "Width b", unit: "mm", type: "number", def: 300 },
        { k: "d", label: "Effective depth d", unit: "mm", type: "number", def: 450 },
        { k: "fck", label: "Concrete grade fck", unit: "N/mm²", type: "select", opts: ["20", "25", "30", "35", "40"], def: "25" },
        { k: "ast", label: "Tension steel Ast provided", unit: "mm²", type: "number", def: 1000 },
        { k: "fy", label: "Stirrup steel fy", unit: "N/mm²", type: "select", opts: ["250", "415", "500"], def: "415" },
      ],
      run(v) {
        const Vu = n(+v.Vu) * 1000, b = n(+v.b), d = n(+v.d), fck = +v.fck, fy = +v.fy;
        const pt = (100 * n(+v.ast)) / (b * d);
        const tv = Vu / (b * d), tc = tauc(fck, pt), tmax = taucmax(fck);
        let verdict, extra = [];
        if (tv > tmax) verdict = "τv exceeds τc,max — redesign the section";
        else if (tv <= tc) verdict = "τv ≤ τc — provide minimum shear reinforcement only";
        else verdict = "τc < τv ≤ τc,max — design shear reinforcement";
        const Vus = Math.max(0, Vu - tc * b * d);
        const asv = 100; // 8 mm 2-legged
        const sv = Vus > 0 ? (0.87 * fy * asv * d) / Vus : 0;
        const svMin = (0.87 * fy * asv) / (0.4 * b);
        const svMax = Math.min(0.75 * d, 300);
        if (Vus > 0) extra.push(`Vus = ${r(Vu / 1000, 1)} − ${r((tc * b * d) / 1000, 1)} = ${r(Vus / 1000, 1)} kN`);
        return {
          results: [
            { label: "pt = 100 Ast / bd", value: r(pt, 3), unit: "%" },
            { label: "Nominal shear stress τv", value: r(tv, 3), unit: "N/mm²", big: true },
            { label: "Design shear strength τc", value: r(tc, 3), unit: "N/mm²" },
            { label: "Maximum shear stress τc,max", value: r(tmax, 2), unit: "N/mm²" },
            { label: "Verdict", value: verdict, unit: "" },
            { label: "Spacing for 8 mm 2-legged stirrups", value: Vus > 0 ? r(Math.min(sv, svMin, svMax), 0) : r(Math.min(svMin, svMax), 0), unit: "mm c/c (governing)" },
          ],
          steps: [
            `τv = ${r(Vu / 1000, 1)} × 1000 / (${b} × ${d}) = ${r(tv, 3)} N/mm²`,
            `β = 0.8 × ${fck} / (6.89 × ${r(pt, 3)}) → τc = ${r(tc, 3)} N/mm²`,
          ].concat(extra, [
            `Design spacing = 0.87 fy Asv d / Vus = ${Vus > 0 ? r(sv, 0) + " mm" : "not required"}`,
            `Minimum shear reinforcement spacing = 0.87 × ${fy} × ${asv} / (0.4 × ${b}) = ${r(svMin, 0)} mm`,
            `Maximum spacing = lesser of 0.75d = ${r(0.75 * d, 0)} mm and 300 mm → ${r(svMax, 0)} mm`,
          ]),
          note: "Asv is taken as 100 mm² (two legs of 8 mm). Change the bar size in your own calculation if you use a different stirrup.",
        };
      },
    },
    {
      id: "span-depth", cat: "rcc", name: "Span / Effective Depth Check",
      ref: "IS 456:2000, Cl. 23.2.1",
      formula: "Basic L/d = 7 (cantilever), 20 (simply supported), 26 (continuous), × modification factors",
      inputs: [
        { k: "type", label: "Support condition", type: "select", opts: ["Cantilever (7)", "Simply supported (20)", "Continuous (26)"], def: "Simply supported (20)" },
        { k: "span", label: "Effective span", unit: "mm", type: "number", def: 4000 },
        { k: "mf", label: "Modification factor (tension steel, Fig. 4)", type: "number", def: 1.4, step: 0.05 },
        { k: "mc", label: "Modification factor (compression steel, Fig. 5)", type: "number", def: 1.0, step: 0.05 },
      ],
      run(v) {
        const base = v.type.startsWith("Cantilever") ? 7 : v.type.startsWith("Simply") ? 20 : 26;
        const span = n(+v.span), mf = n(+v.mf), mc = n(+v.mc);
        const allow = base * mf * mc;
        const dreq = span / allow;
        const longSpan = span > 10000 && base !== 7;
        const adj = longSpan ? (10000 / span) : 1;
        return {
          results: [
            { label: "Basic L/d", value: base, unit: "" },
            { label: "Permissible L/d", value: r(allow * adj, 2), unit: "" },
            { label: "Effective depth required", value: r(span / (allow * adj), 0), unit: "mm", big: true },
            { label: "Suggested overall depth (cover 25 + φ/2)", value: r(span / (allow * adj) + 30, 0), unit: "mm" },
          ],
          steps: [
            `Basic value for ${v.type} = ${base}`,
            `Permissible L/d = ${base} × ${mf} × ${mc}${longSpan ? ` × (10/${span / 1000})` : ""} = ${r(allow * adj, 2)}`,
            `d required = ${span} / ${r(allow * adj, 2)} = ${r(dreq / (longSpan ? 1 / adj : 1), 0)} mm`,
          ],
          note: "For spans over 10 m the basic values are multiplied by 10/span in metres, except for cantilevers, where a deflection calculation is required instead.",
        };
      },
    },
    {
      id: "slab-qty", cat: "rcc", name: "Slab Quantity (concrete + steel estimate)",
      ref: "Concrete measurement as per IS 1200 (Part 2); steel estimate is a preliminary figure only",
      formula: "Volume = L × B × t · Steel estimate = volume × assumed kg/m³",
      inputs: [
        { k: "L", label: "Length", unit: "m", type: "number", def: 6 },
        { k: "B", label: "Width", unit: "m", type: "number", def: 4 },
        { k: "t", label: "Thickness", unit: "mm", type: "number", def: 150 },
        { k: "kg", label: "Steel allowance", unit: "kg/m³", type: "number", def: 80 },
      ],
      run(v) {
        const vol = n(+v.L) * n(+v.B) * (n(+v.t) / 1000);
        const steel = vol * n(+v.kg);
        return {
          results: [
            { label: "Concrete volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "Concrete volume", value: r(vol * 35.3147, 2), unit: "cft" },
            { label: "Steel (preliminary estimate)", value: r(steel, 1), unit: "kg" },
            { label: "Formwork area (soffit)", value: r(n(+v.L) * n(+v.B), 2), unit: "m²" },
          ],
          steps: [`Volume = ${v.L} × ${v.B} × ${v.t}/1000 = ${r(vol, 3)} m³`, `Steel ≈ ${r(vol, 3)} × ${v.kg} = ${r(steel, 1)} kg`],
          note: "Typical preliminary steel allowances: slabs 70–100 kg/m³, beams 120–180, columns 150–250, footings 60–90. Use the bar bending schedule for the real figure.",
        };
      },
    },
    {
      id: "beam-qty", cat: "rcc", name: "Beam Quantity",
      ref: "Measurement as per IS 1200 (Part 2); formwork as per IS 1200 (Part 5)",
      formula: "Volume = b × D × L × number · Formwork = (2D + b) × L × number",
      inputs: [
        { k: "b", label: "Width b", unit: "mm", type: "number", def: 300 },
        { k: "D", label: "Overall depth D", unit: "mm", type: "number", def: 450 },
        { k: "L", label: "Length", unit: "m", type: "number", def: 5 },
        { k: "nos", label: "Number of beams", type: "number", def: 4 },
        { k: "kg", label: "Steel allowance", unit: "kg/m³", type: "number", def: 150 },
      ],
      run(v) {
        const b = n(+v.b) / 1000, D = n(+v.D) / 1000, L = n(+v.L), nos = n(+v.nos);
        const vol = b * D * L * nos, fw = (2 * D + b) * L * nos;
        return {
          results: [
            { label: "Concrete volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "Formwork area", value: r(fw, 2), unit: "m²" },
            { label: "Steel (preliminary estimate)", value: r(vol * n(+v.kg), 1), unit: "kg" },
          ],
          steps: [`Volume = ${b} × ${D} × ${L} × ${nos} = ${r(vol, 3)} m³`, `Formwork (2 sides + soffit) = (2 × ${D} + ${b}) × ${L} × ${nos} = ${r(fw, 2)} m²`],
        };
      },
    },
    {
      id: "column-qty", cat: "rcc", name: "Column Quantity",
      ref: "Measurement as per IS 1200 (Part 2); reinforcement limits IS 456 Cl. 26.5.3.1",
      formula: "Volume = b × D × h × number · Ast range = 0.8% to 6% of gross area",
      inputs: [
        { k: "b", label: "Width b", unit: "mm", type: "number", def: 300 },
        { k: "D", label: "Depth D", unit: "mm", type: "number", def: 450 },
        { k: "h", label: "Height", unit: "m", type: "number", def: 3 },
        { k: "nos", label: "Number of columns", type: "number", def: 8 },
      ],
      run(v) {
        const b = n(+v.b), D = n(+v.D), h = n(+v.h), nos = n(+v.nos);
        const vol = (b / 1000) * (D / 1000) * h * nos;
        const ag = b * D;
        return {
          results: [
            { label: "Concrete volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "Formwork area", value: r(2 * ((b + D) / 1000) * h * nos, 2), unit: "m²" },
            { label: "Gross area of one column", value: r(ag, 0), unit: "mm²" },
            { label: "Minimum longitudinal steel (0.8%)", value: r(0.008 * ag, 0), unit: "mm²" },
            { label: "Maximum longitudinal steel (6%)", value: r(0.06 * ag, 0), unit: "mm²" },
          ],
          steps: [
            `Volume = ${b / 1000} × ${D / 1000} × ${h} × ${nos} = ${r(vol, 3)} m³`,
            `Ag = ${b} × ${D} = ${r(ag, 0)} mm²; steel between ${r(0.008 * ag, 0)} and ${r(0.06 * ag, 0)} mm² (Cl. 26.5.3.1)`,
            `Tie pitch ≤ least of ${Math.min(b, D)} mm (least dimension), 16 φ, and 300 mm (Cl. 26.5.3.2)`,
          ],
        };
      },
    },
    {
      id: "footing-qty", cat: "rcc", name: "Footing Quantity",
      ref: "Measurement as per IS 1200 (Part 2); minimum cover 50 mm as per IS 456 Cl. 26.4.2.2",
      formula: "Rectangular: L × B × D · Sloped: L B d1 + (h/3)(A1 + A2 + √(A1 A2))",
      inputs: [
        { k: "type", label: "Footing type", type: "select", opts: ["Rectangular (uniform depth)", "Sloped / trapezoidal"], def: "Rectangular (uniform depth)" },
        { k: "L", label: "Length L", unit: "m", type: "number", def: 2 },
        { k: "B", label: "Width B", unit: "m", type: "number", def: 2 },
        { k: "d1", label: "Depth at edge / uniform depth", unit: "m", type: "number", def: 0.3 },
        { k: "cL", label: "Top length (sloped only)", unit: "m", type: "number", def: 0.6 },
        { k: "cB", label: "Top width (sloped only)", unit: "m", type: "number", def: 0.6 },
        { k: "h", label: "Sloped portion height", unit: "m", type: "number", def: 0.25 },
        { k: "nos", label: "Number of footings", type: "number", def: 1 },
      ],
      run(v) {
        const L = n(+v.L), B = n(+v.B), d1 = n(+v.d1), nos = n(+v.nos);
        let vol, steps;
        if (v.type.startsWith("Rect")) {
          vol = L * B * d1 * nos;
          steps = [`Volume = ${L} × ${B} × ${d1} × ${nos} = ${r(vol, 3)} m³`];
        } else {
          const A1 = L * B, A2 = n(+v.cL) * n(+v.cB), h = n(+v.h);
          const frustum = (h / 3) * (A1 + A2 + Math.sqrt(A1 * A2));
          vol = (L * B * d1 + frustum) * nos;
          steps = [
            `Bottom prism = ${L} × ${B} × ${d1} = ${r(L * B * d1, 3)} m³`,
            `Frustum = (${h}/3)(${r(A1, 3)} + ${r(A2, 3)} + √(${r(A1, 3)} × ${r(A2, 3)})) = ${r(frustum, 3)} m³`,
            `Total × ${nos} footings = ${r(vol, 3)} m³`,
          ];
        }
        return {
          results: [
            { label: "Concrete volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "PCC bed (75 mm, 100 mm projection each side)", value: r((L + 0.2) * (B + 0.2) * 0.075 * nos, 3), unit: "m³" },
            { label: "Excavation (200 mm working space, depth d1)", value: r((L + 0.4) * (B + 0.4) * d1 * nos, 3), unit: "m³" },
          ],
          steps,
          note: "Footings require a minimum nominal cover of 50 mm (IS 456 Cl. 26.4.2.2). Excavation is measured on authorised dimensions (IS 1200 Part 1), not on the working space actually dug.",
        };
      },
    },

    /* ====================== CONSTRUCTION ====================== */
    {
      id: "brickwork", cat: "build", name: "Brickwork Quantity",
      ref: "Brick dimensions from IS 1077:1992; measurement as per IS 1200 (Part 3)",
      formula: "Bricks = wall volume ÷ volume of one brick with mortar · Mortar = wall volume − volume of bricks",
      inputs: [
        { k: "L", label: "Wall length", unit: "m", type: "number", def: 10 },
        { k: "H", label: "Wall height", unit: "m", type: "number", def: 3 },
        { k: "t", label: "Wall thickness", type: "select", opts: ["115 mm (half brick)", "230 mm (one brick)", "345 mm (one and a half)"], def: "230 mm (one brick)" },
        { k: "brick", label: "Brick size", type: "select", opts: ["Modular 190×90×90", "Traditional 230×110×70"], def: "Modular 190×90×90" },
        { k: "mix", label: "Mortar mix", type: "select", opts: Object.keys(MORTAR), def: "1:6" },
        { k: "open", label: "Deduction for openings", unit: "m²", type: "number", def: 0 },
      ],
      run(v) {
        const t = parseFloat(v.t) / 1000;
        const area = Math.max(0, n(+v.L) * n(+v.H) - n(+v.open));
        const vol = area * t;
        const bd = v.brick.startsWith("Modular") ? [0.19, 0.09, 0.09] : [0.23, 0.11, 0.07];
        const withMortar = (bd[0] + 0.01) * (bd[1] + 0.01) * (bd[2] + 0.01);
        const nBricks = vol / withMortar;
        const brickVol = nBricks * bd[0] * bd[1] * bd[2];
        const mortarWet = vol - brickVol;
        const mortarDry = mortarWet * 1.33;
        const p = MORTAR[v.mix], tot = p[0] + p[1];
        const cem = (mortarDry * p[0]) / tot, sand = (mortarDry * p[1]) / tot;
        return {
          results: [
            { label: "Brickwork volume", value: r(vol, 3), unit: "m³" },
            { label: "Number of bricks", value: r(Math.ceil(nBricks * 1.05), 0), unit: "nos (incl. 5% wastage)", big: true },
            { label: "Wet mortar", value: r(mortarWet, 3), unit: "m³" },
            { label: "Cement", value: r(cem / CEMENT_BAG_M3, 2), unit: "bags (" + r((cem / CEMENT_BAG_M3) * 50, 0) + " kg)" },
            { label: "Sand", value: r(sand, 3), unit: "m³ (" + r(sand * 35.3147, 2) + " cft)" },
          ],
          steps: [
            `Net wall area = ${r(area, 2)} m²; volume = ${r(area, 2)} × ${t} = ${r(vol, 3)} m³`,
            `One brick with 10 mm joint occupies ${r(withMortar, 5)} m³ → ${r(nBricks, 0)} bricks`,
            `Mortar (wet) = ${r(vol, 3)} − ${r(brickVol, 3)} = ${r(mortarWet, 3)} m³; dry = × 1.33 = ${r(mortarDry, 3)} m³`,
            `Mix ${v.mix}: cement = ${r(cem, 3)} m³ = ${r(cem / CEMENT_BAG_M3, 2)} bags; sand = ${r(sand, 3)} m³`,
          ],
          note: "A modular brick with a 10 mm joint gives 500 bricks per m³ of brickwork — the standard site check on this result.",
        };
      },
    },
    {
      id: "plaster", cat: "build", name: "Plaster Quantity",
      ref: "Plastering practice as per IS 1661:1972; measurement as per IS 1200 (Part 12)",
      formula: "Wet mortar = area × thickness · Dry = wet × 1.27 · Cement and sand split by mix ratio",
      inputs: [
        { k: "A", label: "Plaster area", unit: "m²", type: "number", def: 100 },
        { k: "t", label: "Thickness", unit: "mm", type: "select", opts: ["6", "12", "15", "20"], def: "12" },
        { k: "mix", label: "Mortar mix", type: "select", opts: Object.keys(MORTAR), def: "1:6" },
        { k: "waste", label: "Wastage allowance", unit: "%", type: "number", def: 15 },
      ],
      run(v) {
        const A = n(+v.A), t = +v.t / 1000;
        const wet = A * t, dry = wet * 1.27 * (1 + n(+v.waste) / 100);
        const p = MORTAR[v.mix], tot = p[0] + p[1];
        const cem = (dry * p[0]) / tot, sand = (dry * p[1]) / tot;
        return {
          results: [
            { label: "Wet mortar volume", value: r(wet, 3), unit: "m³" },
            { label: "Dry mortar volume", value: r(dry, 3), unit: "m³" },
            { label: "Cement", value: r(cem / CEMENT_BAG_M3, 2), unit: "bags (" + r((cem / CEMENT_BAG_M3) * 50, 0) + " kg)", big: true },
            { label: "Sand", value: r(sand, 3), unit: "m³ (" + r(sand * 35.3147, 2) + " cft)" },
          ],
          steps: [
            `Wet volume = ${A} × ${t} = ${r(wet, 3)} m³`,
            `Dry volume = ${r(wet, 3)} × 1.27 × (1 + ${v.waste}%) = ${r(dry, 3)} m³`,
            `Mix ${v.mix}: cement ${r(cem, 3)} m³ = ${r(cem / CEMENT_BAG_M3, 2)} bags; sand ${r(sand, 3)} m³`,
          ],
          note: "Internal plaster is usually 12 mm in one coat; external 15–20 mm in two coats. Cure plaster for at least 7 days.",
        };
      },
    },
    {
      id: "excavation", cat: "build", name: "Excavation Quantity",
      ref: "Measurement as per IS 1200 (Part 1):1992",
      formula: "Volume = L × B × D × number · Bulked (loose) volume = volume × bulking factor",
      inputs: [
        { k: "L", label: "Length", unit: "m", type: "number", def: 2.4 },
        { k: "B", label: "Width", unit: "m", type: "number", def: 2.4 },
        { k: "D", label: "Depth", unit: "m", type: "number", def: 1.5 },
        { k: "nos", label: "Number of pits / trenches", type: "number", def: 8 },
        { k: "bulk", label: "Bulking on excavation", unit: "%", type: "number", def: 25 },
      ],
      run(v) {
        const vol = n(+v.L) * n(+v.B) * n(+v.D) * n(+v.nos);
        const loose = vol * (1 + n(+v.bulk) / 100);
        return {
          results: [
            { label: "Excavation (in situ measure)", value: r(vol, 3), unit: "m³", big: true },
            { label: "Loose / bulked volume for disposal", value: r(loose, 3), unit: "m³" },
            { label: "Tipper loads (6 m³ each)", value: r(Math.ceil(loose / 6), 0), unit: "trips" },
          ],
          steps: [`Volume = ${v.L} × ${v.B} × ${v.D} × ${v.nos} = ${r(vol, 3)} m³`, `Loose volume = ${r(vol, 3)} × ${1 + n(+v.bulk) / 100} = ${r(loose, 3)} m³`],
          note: "Earthwork is measured on authorised dimensions, not on the pit actually dug — working space is a contractor's cost (IS 1200 Part 1).",
        };
      },
    },
    {
      id: "backfill", cat: "build", name: "Backfilling Quantity",
      ref: "Measurement as per IS 1200 (Part 1):1992",
      formula: "Backfill = excavation volume − volume of structure below ground level",
      inputs: [
        { k: "exc", label: "Total excavation volume", unit: "m³", type: "number", def: 60 },
        { k: "pcc", label: "PCC volume below ground", unit: "m³", type: "number", def: 4 },
        { k: "fdn", label: "Footing + pedestal volume below ground", unit: "m³", type: "number", def: 12 },
        { k: "shrink", label: "Shrinkage on compaction", unit: "%", type: "number", def: 10 },
      ],
      run(v) {
        const back = Math.max(0, n(+v.exc) - n(+v.pcc) - n(+v.fdn));
        const loose = back * (1 + n(+v.shrink) / 100);
        return {
          results: [
            { label: "Backfill (compacted, in place)", value: r(back, 3), unit: "m³", big: true },
            { label: "Loose soil required", value: r(loose, 3), unit: "m³" },
            { label: "Surplus for disposal (if all excavated soil is reused)", value: r(Math.max(0, n(+v.exc) - back), 3), unit: "m³" },
          ],
          steps: [`Backfill = ${v.exc} − ${v.pcc} − ${v.fdn} = ${r(back, 3)} m³`, `Allowing ${v.shrink}% shrinkage, loose soil required = ${r(loose, 3)} m³`],
          note: "Backfill is normally placed in 150–200 mm layers, watered and compacted; the specification will state the required density.",
        };
      },
    },
    {
      id: "earthwork", cat: "build", name: "Earthwork Volume between Sections",
      ref: "Standard practice; measurement as per IS 1200 (Part 1)",
      formula: "Trapezoidal: V = L (A1 + A2)/2 · Prismoidal: V = (L/6)(A1 + 4Am + A2)",
      inputs: [
        { k: "A1", label: "Cross-section area at first station", unit: "m²", type: "number", def: 12 },
        { k: "Am", label: "Area at mid-station", unit: "m²", type: "number", def: 15 },
        { k: "A2", label: "Area at second station", unit: "m²", type: "number", def: 19 },
        { k: "L", label: "Distance between the two stations", unit: "m", type: "number", def: 30 },
      ],
      run(v) {
        const A1 = n(+v.A1), Am = n(+v.Am), A2 = n(+v.A2), L = n(+v.L);
        const trap = (L * (A1 + A2)) / 2;
        const pris = (L / 6) * (A1 + 4 * Am + A2);
        return {
          results: [
            { label: "Trapezoidal (end area) volume", value: r(trap, 2), unit: "m³" },
            { label: "Prismoidal volume", value: r(pris, 2), unit: "m³", big: true },
            { label: "Prismoidal correction", value: r(trap - pris, 2), unit: "m³" },
          ],
          steps: [`Trapezoidal: V = ${L}(${A1} + ${A2})/2 = ${r(trap, 2)} m³`, `Prismoidal: V = (${L}/6)(${A1} + 4×${Am} + ${A2}) = ${r(pris, 2)} m³`],
          note: "The prismoidal formula is more accurate where the section changes non-linearly; contracts state which method governs the bill.",
        };
      },
    },
    {
      id: "pcc", cat: "build", name: "PCC / Lean Concrete",
      ref: "Nominal mixes from IS 456:2000 Table 9",
      formula: "Same as concrete quantity, with a lean nominal mix",
      inputs: [
        { k: "A", label: "Area", unit: "m²", type: "number", def: 40 },
        { k: "t", label: "Thickness", unit: "mm", type: "number", def: 75 },
        { k: "mix", label: "Mix", type: "select", opts: Object.keys(MIXES), def: "M10 (1:3:6)" },
      ],
      run(v) {
        const vol = n(+v.A) * (n(+v.t) / 1000), dry = vol * 1.54;
        const p = MIXES[v.mix], tot = p[0] + p[1] + p[2];
        const cem = (dry * p[0]) / tot, sand = (dry * p[1]) / tot, agg = (dry * p[2]) / tot;
        return {
          results: [
            { label: "PCC volume", value: r(vol, 3), unit: "m³", big: true },
            { label: "Cement", value: r(cem / CEMENT_BAG_M3, 2), unit: "bags" },
            { label: "Sand", value: r(sand, 3), unit: "m³" },
            { label: "Coarse aggregate", value: r(agg, 3), unit: "m³" },
          ],
          steps: [`Volume = ${v.A} × ${v.t}/1000 = ${r(vol, 3)} m³`, `Dry volume = 1.54 × ${r(vol, 3)} = ${r(dry, 3)} m³`, `Mix ${v.mix} → cement ${r(cem / CEMENT_BAG_M3, 2)} bags, sand ${r(sand, 3)} m³, aggregate ${r(agg, 3)} m³`],
        };
      },
    },

    /* ======================== SURVEYING ======================== */
    {
      id: "area-offsets", cat: "survey", name: "Area from Offsets (Trapezoidal / Simpson)",
      ref: "Standard surveying practice",
      formula: "Trapezoidal: A = d[(O1 + On)/2 + O2 + … + On−1] · Simpson: A = (d/3)[(O1 + On) + 4Σodd-position + 2Σeven-position]",
      inputs: [
        { k: "ord", label: "Ordinates (comma separated, in metres)", type: "text", def: "2.0, 3.5, 4.2, 3.8, 2.5" },
        { k: "d", label: "Common interval", unit: "m", type: "number", def: 10 },
        { k: "m", label: "Method", type: "select", opts: ["Simpson's rule", "Trapezoidal rule", "Both"], def: "Both" },
      ],
      run(v) {
        const o = String(v.ord).split(/[, ]+/).map(parseFloat).filter((x) => isFinite(x));
        const d = n(+v.d);
        let trap = 0;
        if (o.length > 1) { trap = d * ((o[0] + o[o.length - 1]) / 2 + o.slice(1, -1).reduce((a, b) => a + b, 0)); }
        let simp = null, warn = "";
        if (o.length >= 3 && o.length % 2 === 1) {
          let odd = 0, even = 0;
          for (let i = 1; i < o.length - 1; i++) { if (i % 2 === 1) odd += o[i]; else even += o[i]; }
          simp = (d / 3) * (o[0] + o[o.length - 1] + 4 * odd + 2 * even);
        } else { warn = "Simpson's rule needs an odd number of ordinates (an even number of intervals)."; }
        const res = [{ label: "Number of ordinates", value: o.length, unit: "" }];
        if (simp !== null && v.m !== "Trapezoidal rule") res.push({ label: "Area — Simpson's rule", value: r(simp, 2), unit: "m²", big: true });
        if (v.m !== "Simpson's rule") res.push({ label: "Area — trapezoidal rule", value: r(trap, 2), unit: "m²", big: simp === null });
        return {
          results: res,
          steps: [`Ordinates: ${o.join(", ")} at ${d} m interval`,
          simp !== null ? `Simpson: (${d}/3)[(${o[0]} + ${o[o.length - 1]}) + 4Σ + 2Σ] = ${r(simp, 2)} m²` : warn,
          `Trapezoidal: ${d}[(${o[0]} + ${o[o.length - 1]})/2 + Σ intermediate] = ${r(trap, 2)} m²`],
          note: warn || "Simpson's rule is generally more accurate for a curved boundary.",
        };
      },
    },
    {
      id: "area-coords", cat: "survey", name: "Area from Coordinates (Shoelace)",
      ref: "Standard surveying practice",
      formula: "A = ½ |Σ (xi · yi+1 − xi+1 · yi)|",
      inputs: [{ k: "pts", label: "Coordinates, one point per line as E,N", type: "textarea", def: "0,0\n30,0\n30,20\n10,25\n0,15" }],
      run(v) {
        const pts = String(v.pts).split(/\n+/).map((l) => l.split(/[, \t]+/).map(parseFloat)).filter((p) => p.length >= 2 && isFinite(p[0]) && isFinite(p[1]));
        let s = 0, per = 0;
        for (let i = 0; i < pts.length; i++) {
          const a = pts[i], b = pts[(i + 1) % pts.length];
          s += a[0] * b[1] - b[0] * a[1];
          per += Math.hypot(b[0] - a[0], b[1] - a[1]);
        }
        const area = Math.abs(s) / 2;
        return {
          results: [
            { label: "Number of points", value: pts.length, unit: "" },
            { label: "Area", value: r(area, 2), unit: "m²", big: true },
            { label: "Area", value: r(area / 10000, 4), unit: "hectare (" + r(area * 10.7639, 0) + " ft²)" },
            { label: "Perimeter", value: r(per, 2), unit: "m" },
          ],
          steps: [`Σ(xi·yi+1 − xi+1·yi) = ${r(s, 3)}`, `Area = |${r(s, 3)}| / 2 = ${r(area, 2)} m²`],
          note: "Points must be entered in order around the boundary (clockwise or anticlockwise), and the polygon must not cross itself.",
        };
      },
    },
    {
      id: "distance-bearing", cat: "survey", name: "Distance and Bearing between Two Points",
      ref: "Standard surveying practice",
      formula: "Distance = √(ΔE² + ΔN²) · Whole circle bearing = atan2(ΔE, ΔN), adjusted to 0–360°",
      inputs: [
        { k: "e1", label: "Easting of point A", unit: "m", type: "number", def: 1000 },
        { k: "n1", label: "Northing of point A", unit: "m", type: "number", def: 1000 },
        { k: "e2", label: "Easting of point B", unit: "m", type: "number", def: 1120 },
        { k: "n2", label: "Northing of point B", unit: "m", type: "number", def: 1085 },
      ],
      run(v) {
        const dE = n(+v.e2) - n(+v.e1), dN = n(+v.n2) - n(+v.n1);
        const dist = Math.hypot(dE, dN);
        let brg = (Math.atan2(dE, dN) * 180) / Math.PI;
        if (brg < 0) brg += 360;
        const deg = Math.floor(brg), mins = (brg - deg) * 60, mm = Math.floor(mins), ss = (mins - mm) * 60;
        return {
          results: [
            { label: "ΔE (departure)", value: r(dE, 3), unit: "m" },
            { label: "ΔN (latitude)", value: r(dN, 3), unit: "m" },
            { label: "Distance", value: r(dist, 3), unit: "m", big: true },
            { label: "Whole circle bearing", value: r(brg, 4), unit: "° (" + deg + "° " + mm + "' " + r(ss, 1) + "\")" },
          ],
          steps: [`ΔE = ${r(dE, 3)}, ΔN = ${r(dN, 3)}`, `Distance = √(ΔE² + ΔN²) = ${r(dist, 3)} m`, `WCB = atan2(ΔE, ΔN) = ${r(brg, 4)}°`],
        };
      },
    },
    {
      id: "level-hi", cat: "survey", name: "Levelling — Reduced Level (HI method)",
      ref: "Standard surveying practice",
      formula: "HI = RL(known) + BS · RL(new) = HI − IS or FS",
      inputs: [
        { k: "rl", label: "RL of the known point (benchmark)", unit: "m", type: "number", def: 100, step: 0.001 },
        { k: "bs", label: "Back sight on the known point", unit: "m", type: "number", def: 1.25, step: 0.001 },
        { k: "sights", label: "Readings at new points (comma separated)", type: "text", def: "1.850, 2.100, 0.950" },
      ],
      run(v) {
        const hi = n(+v.rl) + n(+v.bs);
        const s = String(v.sights).split(/[, ]+/).map(parseFloat).filter(isFinite);
        const rows = s.map((x, i) => [`Point ${i + 1}`, x.toFixed(3), (hi - x).toFixed(3)]);
        return {
          results: [
            { label: "Height of instrument (HI)", value: hi.toFixed(3), unit: "m", big: true },
            { label: "Lowest RL", value: (hi - Math.max(...s)).toFixed(3), unit: "m" },
            { label: "Highest RL", value: (hi - Math.min(...s)).toFixed(3), unit: "m" },
          ],
          steps: [`HI = ${v.rl} + ${v.bs} = ${hi.toFixed(3)} m`, `RL of each point = HI − staff reading`],
          table: { cols: ["Point", "Staff reading (m)", "Reduced level (m)"], rows },
          note: "Arithmetic check for the HI method: ΣBS − ΣFS = last RL − first RL.",
        };
      },
    },
    {
      id: "slope", cat: "survey", name: "Slope, Gradient and Angle",
      ref: "Standard surveying practice; road gradients as per IRC geometric design standards",
      formula: "Slope % = 100 × rise/run · Gradient = 1 in (run/rise) · Angle = atan(rise/run)",
      inputs: [
        { k: "rise", label: "Rise (vertical)", unit: "m", type: "number", def: 1.5 },
        { k: "run", label: "Run (horizontal)", unit: "m", type: "number", def: 30 },
      ],
      run(v) {
        const rise = n(+v.rise), run = n(+v.run);
        const pct = (100 * rise) / run, ang = (Math.atan(rise / run) * 180) / Math.PI;
        return {
          results: [
            { label: "Slope", value: r(pct, 3), unit: "%", big: true },
            { label: "Gradient", value: "1 in " + r(run / rise, 2), unit: "" },
            { label: "Angle", value: r(ang, 4), unit: "degrees" },
            { label: "Slope length", value: r(Math.hypot(rise, run), 3), unit: "m" },
          ],
          steps: [`Slope = 100 × ${rise}/${run} = ${r(pct, 3)}%`, `Gradient = 1 in ${r(run / rise, 2)}`, `Angle = atan(${rise}/${run}) = ${r(ang, 4)}°`],
        };
      },
    },
    {
      id: "traverse", cat: "survey", name: "Latitude and Departure",
      ref: "Standard surveying practice",
      formula: "Latitude = L cos θ · Departure = L sin θ (θ = whole circle bearing)",
      inputs: [{ k: "lines", label: "Lines, one per line as length,bearing", type: "textarea", def: "120, 60\n95, 145\n150, 250\n110, 330" }],
      run(v) {
        const lines = String(v.lines).split(/\n+/).map((l) => l.split(/[, \t]+/).map(parseFloat)).filter((p) => p.length >= 2 && isFinite(p[0]) && isFinite(p[1]));
        let sL = 0, sD = 0, per = 0;
        const rows = lines.map((p, i) => {
          const lat = p[0] * Math.cos((p[1] * Math.PI) / 180);
          const dep = p[0] * Math.sin((p[1] * Math.PI) / 180);
          sL += lat; sD += dep; per += p[0];
          return [`Line ${i + 1}`, r(p[0], 3), r(p[1], 2) + "°", r(lat, 3), r(dep, 3)];
        });
        const err = Math.hypot(sL, sD);
        return {
          results: [
            { label: "Σ Latitude", value: r(sL, 3), unit: "m" },
            { label: "Σ Departure", value: r(sD, 3), unit: "m" },
            { label: "Closing error", value: r(err, 4), unit: "m", big: true },
            { label: "Relative accuracy", value: err > 0 ? "1 in " + r(per / err, 0) : "exact", unit: "" },
          ],
          steps: [`Perimeter = ${r(per, 3)} m`, `Closing error = √(ΣL² + ΣD²) = ${r(err, 4)} m`, `Distribute by Bowditch's rule in proportion to line length.`],
          table: { cols: ["Line", "Length (m)", "Bearing", "Latitude (m)", "Departure (m)"], rows },
        };
      },
    },

    /* ===================== BAR BENDING SCHEDULE ===================== */
    {
      id: "bbs-stirrup", cat: "bbs", name: "Stirrup Cutting Length",
      ref: "Bend and hook allowances follow standard practice based on IS 2502 and SP 34; cover as per IS 456 Cl. 26.4",
      formula: "L = 2(a + b) + 2 × hook − (3 × 90° bend deduction) − (2 × 135° bend deduction), where a and b are the stirrup dimensions after deducting cover and bar diameter",
      inputs: [
        { k: "B", label: "Member width", unit: "mm", type: "number", def: 300 },
        { k: "D", label: "Member depth", unit: "mm", type: "number", def: 500 },
        { k: "c", label: "Clear cover", unit: "mm", type: "number", def: 25 },
        { k: "d", label: "Stirrup diameter", unit: "mm", type: "select", opts: ["6", "8", "10", "12"], def: "8" },
        { k: "hk", label: "Hook length (× d)", type: "number", def: 9 },
        { k: "b90", label: "90° bend deduction (× d)", type: "number", def: 2 },
        { k: "b135", label: "135° bend deduction (× d)", type: "number", def: 3 },
      ],
      run(v) {
        const d = +v.d, c = n(+v.c);
        const a = n(+v.B) - 2 * c - d;
        const b = n(+v.D) - 2 * c - d;
        const hook = n(+v.hk) * d;
        const ded = 3 * n(+v.b90) * d + 2 * n(+v.b135) * d;
        const L = 2 * (a + b) + 2 * hook - ded;
        const w = (d * d) / 162;
        return {
          results: [
            { label: "Stirrup width a", value: r(a, 0), unit: "mm" },
            { label: "Stirrup depth b", value: r(b, 0), unit: "mm" },
            { label: "Cutting length", value: r(L, 0), unit: "mm", big: true },
            { label: "Weight of one stirrup", value: r((L / 1000) * w, 3), unit: "kg" },
          ],
          steps: [
            `a = ${v.B} − 2 × ${c} − ${d} = ${r(a, 0)} mm`,
            `b = ${v.D} − 2 × ${c} − ${d} = ${r(b, 0)} mm`,
            `Perimeter = 2(${r(a, 0)} + ${r(b, 0)}) = ${r(2 * (a + b), 0)} mm`,
            `Hooks = 2 × ${v.hk} × ${d} = ${r(2 * hook, 0)} mm`,
            `Bend deductions = 3 × ${v.b90}d + 2 × ${v.b135}d = ${r(ded, 0)} mm`,
            `Cutting length = ${r(2 * (a + b), 0)} + ${r(2 * hook, 0)} − ${r(ded, 0)} = ${r(L, 0)} mm`,
          ],
          note: "Hook and bend allowances differ between design offices. The defaults here are the values most commonly taught and used; change them to match your office or contract and the calculation follows.",
        };
      },
    },
    {
      id: "bbs-bar", cat: "bbs", name: "Bar Cutting Length (straight, L-bar, cranked)",
      ref: "Bend deductions follow standard practice based on IS 2502 and SP 34",
      formula: "L = sum of all straight segments + crank allowance (0.42 × rise per crank) − (2d per 90° bend)",
      inputs: [
        { k: "len", label: "Clear length between supports", unit: "mm", type: "number", def: 5000 },
        { k: "c", label: "Cover at each end", unit: "mm", type: "number", def: 25 },
        { k: "d", label: "Bar diameter", unit: "mm", type: "select", opts: ["8", "10", "12", "16", "20", "25", "32"], def: "16" },
        { k: "leg", label: "Bend leg at each end (0 for straight)", unit: "mm", type: "number", def: 0 },
        { k: "legs", label: "Number of 90° bends", type: "number", def: 0 },
        { k: "cranks", label: "Number of cranks (bent-up bars)", type: "number", def: 0 },
        { k: "rise", label: "Crank rise (member depth − 2 cover − 2 bar dia)", unit: "mm", type: "number", def: 0 },
        { k: "nos", label: "Number of such bars", type: "number", def: 2 },
      ],
      run(v) {
        const d = +v.d, c = n(+v.c);
        const base = n(+v.len) - 2 * c;
        const legs = n(+v.legs) * n(+v.leg);
        const crank = n(+v.cranks) * 0.42 * n(+v.rise);
        const ded = n(+v.legs) * 2 * d;
        const L = base + legs + crank - ded;
        const w = (d * d) / 162;
        const tot = (L / 1000) * w * n(+v.nos);
        return {
          results: [
            { label: "Length inside cover", value: r(base, 0), unit: "mm" },
            { label: "Crank allowance", value: r(crank, 0), unit: "mm" },
            { label: "Cutting length of one bar", value: r(L, 0), unit: "mm", big: true },
            { label: "Weight of one bar", value: r((L / 1000) * w, 3), unit: "kg" },
            { label: "Total weight", value: r(tot, 2), unit: "kg for " + v.nos + " bars" },
          ],
          steps: [
            `Length inside cover = ${v.len} − 2 × ${c} = ${r(base, 0)} mm`,
            n(+v.legs) ? `Bend legs = ${v.legs} × ${v.leg} = ${r(legs, 0)} mm; deduction = ${v.legs} × 2 × ${d} = ${r(ded, 0)} mm` : "No 90° bends",
            n(+v.cranks) ? `Crank allowance = ${v.cranks} × 0.42 × ${v.rise} = ${r(crank, 0)} mm` : "No cranks",
            `Cutting length = ${r(base, 0)} + ${r(legs, 0)} + ${r(crank, 0)} − ${r(ded, 0)} = ${r(L, 0)} mm`,
            `Unit weight = ${d}²/162 = ${r(w, 3)} kg/m`,
          ],
          note: "The 0.42 factor is the extra length of a 45° crank for a given vertical rise — it is a geometric result, not a code clause. Development length into the support must be added separately where the drawing requires it.",
        };
      },
    },
    {
      id: "bbs-beam", cat: "bbs", name: "Beam Bar Bending Schedule",
      ref: "Detailing limits from IS 456:2000 Cl. 26; bend and hook allowances follow standard practice based on IS 2502 and SP 34",
      formula: "Schedule each bar mark: cutting length × number × unit weight (d²/162), then total",
      inputs: [
        { k: "len", label: "Beam clear length", unit: "mm", type: "number", def: 5000 },
        { k: "B", label: "Beam width", unit: "mm", type: "number", def: 300 },
        { k: "D", label: "Beam depth", unit: "mm", type: "number", def: 500 },
        { k: "c", label: "Clear cover", unit: "mm", type: "number", def: 25 },
        { k: "nb", label: "Bottom bars — number", type: "number", def: 4 },
        { k: "db", label: "Bottom bars — diameter", unit: "mm", type: "select", opts: ["12", "16", "20", "25"], def: "16" },
        { k: "nt", label: "Top bars — number", type: "number", def: 2 },
        { k: "dt", label: "Top bars — diameter", unit: "mm", type: "select", opts: ["10", "12", "16", "20", "25"], def: "12" },
        { k: "ds", label: "Stirrup diameter", unit: "mm", type: "select", opts: ["6", "8", "10"], def: "8" },
        { k: "sv", label: "Stirrup spacing", unit: "mm", type: "number", def: 150 },
        { k: "anch", label: "Anchorage into each support", unit: "mm", type: "number", def: 450 },
      ],
      run(v) {
        const c = n(+v.c), L = n(+v.len);
        const db = +v.db, dt = +v.dt, ds = +v.ds;
        const wOf = (d) => (d * d) / 162;
        const mainLen = L - 2 * c + 2 * n(+v.anch);
        const a = n(+v.B) - 2 * c - ds;
        const b = n(+v.D) - 2 * c - ds;
        const stLen = 2 * (a + b) + 2 * 9 * ds - (3 * 2 * ds + 2 * 3 * ds);
        const nSt = Math.floor(L / n(+v.sv)) + 1;
        const rows = [], marks = [
          ["B1", "Bottom — straight", db, mainLen, n(+v.nb)],
          ["T1", "Top — straight", dt, mainLen, n(+v.nt)],
          ["S1", "Stirrup — 2 legged", ds, stLen, nSt],
        ];
        let total = 0;
        marks.forEach((m) => {
          const [mark, shape, dia, cut, nos] = m;
          const wt = (cut / 1000) * wOf(dia) * nos;
          total += wt;
          rows.push([mark, shape, dia + " mm", r(cut, 0), nos, r(wt, 2)]);
        });
        const byDia = {};
        marks.forEach((m) => { byDia[m[2]] = (byDia[m[2]] || 0) + (m[3] / 1000) * wOf(m[2]) * m[4]; });
        return {
          results: [
            { label: "Stirrups required", value: nSt, unit: "nos at " + v.sv + " mm c/c" },
            { label: "Stirrup cutting length", value: r(stLen, 0), unit: "mm" },
            { label: "Main bar cutting length", value: r(mainLen, 0), unit: "mm (including anchorage)" },
            { label: "Total steel for this beam", value: r(total, 2), unit: "kg", big: true },
          ],
          steps: [
            `Main bar = ${L} − 2 × ${c} + 2 × ${v.anch} = ${r(mainLen, 0)} mm`,
            `Stirrup: a = ${r(a, 0)} mm, b = ${r(b, 0)} mm → cutting length ${r(stLen, 0)} mm`,
            `Number of stirrups = (${L} / ${v.sv}) + 1 = ${nSt}`,
            "Diameter-wise total: " + Object.keys(byDia).map((k) => `${k} mm — ${r(byDia[k], 2)} kg`).join("  ·  "),
          ],
          table: { cols: ["Mark", "Shape", "Dia", "Cutting length (mm)", "Nos", "Weight (kg)"], rows },
          note: "A working schedule for estimating. Anchorage, curtailment, extra support bars and the closer stirrup spacing required near supports (IS 456 Cl. 26.5.1.5, IS 13920 Cl. 6.3.5) must come from the structural drawing.",
        };
      },
    },
    {
      id: "bbs-slab", cat: "bbs", name: "Slab Steel Schedule",
      ref: "Spacing limits from IS 456:2000 Cl. 26.3.3; minimum steel Cl. 26.5.2.1",
      formula: "Number of bars = (length ÷ spacing) + 1 in each direction; weight = cutting length × nos × d²/162",
      inputs: [
        { k: "Lx", label: "Slab length (shorter span direction)", unit: "mm", type: "number", def: 4000 },
        { k: "Ly", label: "Slab width", unit: "mm", type: "number", def: 6000 },
        { k: "c", label: "Clear cover", unit: "mm", type: "number", def: 20 },
        { k: "dm", label: "Main bar diameter", unit: "mm", type: "select", opts: ["8", "10", "12", "16"], def: "10" },
        { k: "sm", label: "Main bar spacing", unit: "mm", type: "number", def: 150 },
        { k: "dd", label: "Distribution bar diameter", unit: "mm", type: "select", opts: ["6", "8", "10"], def: "8" },
        { k: "sd", label: "Distribution bar spacing", unit: "mm", type: "number", def: 200 },
      ],
      run(v) {
        const c = n(+v.c), Lx = n(+v.Lx), Ly = n(+v.Ly);
        const dm = +v.dm, dd = +v.dd;
        const wOf = (d) => (d * d) / 162;
        const cutMain = Lx - 2 * c;
        const cutDist = Ly - 2 * c;
        const nMain = Math.floor(Ly / n(+v.sm)) + 1;
        const nDist = Math.floor(Lx / n(+v.sd)) + 1;
        const wMain = (cutMain / 1000) * wOf(dm) * nMain;
        const wDist = (cutDist / 1000) * wOf(dd) * nDist;
        const astMain = (1000 / n(+v.sm)) * (Math.PI * dm * dm) / 4;
        const astDist = (1000 / n(+v.sd)) * (Math.PI * dd * dd) / 4;
        return {
          results: [
            { label: "Main bars", value: nMain, unit: "nos × " + r(cutMain, 0) + " mm" },
            { label: "Distribution bars", value: nDist, unit: "nos × " + r(cutDist, 0) + " mm" },
            { label: "Ast provided — main", value: r(astMain, 0), unit: "mm²/m" },
            { label: "Ast provided — distribution", value: r(astDist, 0), unit: "mm²/m" },
            { label: "Total steel", value: r(wMain + wDist, 2), unit: "kg", big: true },
          ],
          steps: [
            `Main: (${Ly} / ${v.sm}) + 1 = ${nMain} bars, each ${r(cutMain, 0)} mm → ${r(wMain, 2)} kg`,
            `Distribution: (${Lx} / ${v.sd}) + 1 = ${nDist} bars, each ${r(cutDist, 0)} mm → ${r(wDist, 2)} kg`,
            `Main spacing limit = lesser of 3d and 300 mm; distribution = lesser of 5d and 450 mm`,
          ],
          table: {
            cols: ["Bar", "Dia", "Cutting length (mm)", "Nos", "Weight (kg)"],
            rows: [
              ["Main", dm + " mm", r(cutMain, 0), nMain, r(wMain, 2)],
              ["Distribution", dd + " mm", r(cutDist, 0), nDist, r(wDist, 2)],
            ],
          },
          note: "Bends, chairs and laps are not included. For a continuous slab, top steel over supports must be scheduled separately.",
        };
      },
    },

    /* ======================= CONVERSIONS ======================= */
    converter("conv-length", "Length", { mm: 0.001, cm: 0.01, m: 1, km: 1000, inch: 0.0254, foot: 0.3048, yard: 0.9144, mile: 1609.344 }, "m", "foot"),
    converter("conv-area", "Area", { "mm²": 1e-6, "cm²": 1e-4, "m²": 1, "ft²": 0.09290304, "yd²": 0.83612736, "acre": 4046.8564224, "hectare": 10000, "km²": 1e6 }, "m²", "ft²"),
    converter("conv-volume", "Volume", { "m³ (cum)": 1, "ft³ (cft)": 0.028316846592, litre: 0.001, "cm³": 1e-6, "yd³": 0.764554857984, "gallon (US)": 0.003785411784 }, "m³ (cum)", "ft³ (cft)"),
    converter("conv-mass", "Mass", { kg: 1, gram: 0.001, tonne: 1000, quintal: 100, pound: 0.45359237, "cement bag (50 kg)": 50 }, "tonne", "kg"),
    converter("conv-force", "Force", { N: 1, kN: 1000, MN: 1e6, "kgf": 9.80665, "tonne-force": 9806.65, lbf: 4.4482216 }, "kN", "kgf"),
    converter("conv-stress", "Stress / Pressure", { "N/mm² (MPa)": 1e6, "kN/m² (kPa)": 1000, "N/m² (Pa)": 1, "kg/cm²": 98066.5, "t/m²": 9806.65, psi: 6894.757, "GPa": 1e9 }, "N/mm² (MPa)", "kg/cm²"),
  ];

  const cats = [
    { id: "rcc", name: "RCC", icon: "🏗", desc: "Concrete, steel, development length, moment capacity, shear" },
    { id: "build", name: "Construction", icon: "🧱", desc: "Brickwork, plaster, excavation, PCC, earthwork" },
    { id: "bbs", name: "Bar Bending Schedule", icon: "🔩", desc: "Cutting lengths, stirrups, beam and slab schedules" },
    { id: "survey", name: "Surveying", icon: "📐", desc: "Area, distance, levels, slope, traverse" },
    { id: "conv", name: "Conversion", icon: "🔄", desc: "Length, area, volume, mass, force, stress" },
  ];

  return { list, cats, tauc, taucmax, taubd, fmt: r };
})();
