/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF RCC STRUCTURES
   Chapter 9 — Footings and Foundations
   Chapter 10 — Serviceability: Deflection and Cracking

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "rcc"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 9 */
    {
      id: "rcc-9",
      n: 9,
      title: "Footings and Foundations",
      hi: "फुटिंग और नींव",
      blurb: "Where the load finally leaves the structure, why service and factored loads are both needed in the same design, and the three checks that fix a footing's depth.",
      mins: 42,
      sections: [

        {
          n: "9.1",
          title: "The one material we do not choose",
          hi: "एक सामग्री जो हम नहीं चुनते",
          blocks: [
            { k: "p", t: "Every chapter so far has worked with materials we specify, test and reject if they fail — concrete of a stated grade, steel of a stated yield. A foundation transfers load into soil, and soil is what happens to be there. It is not mixed to a design, it varies across the site and with depth and with the season, and it is sampled at a handful of boreholes rather than one cube in every batch." },
            { k: "p", t: "That single fact shapes the whole of foundation design. Where concrete design carries a partial safety factor of 1.5 on the material, geotechnical practice carries a factor of two to three on the bearing capacity — and it is applied before the structural engineer sees the number." },
            { k: "def", term: "Safe bearing capacity (SBC)", t: "The pressure the soil can carry with an adequate margin against shear failure, and without settling more than the structure can tolerate. It reaches the structural engineer as a single figure in kN/m² from the soil investigation report, already containing its own factor of safety — which is why it is compared against <strong>service</strong> loads, never factored ones." },
            { k: "trap", t: "This is the error that runs through the whole chapter and it is worth stating before anything else: the <strong>plan size</strong> of a footing is fixed using <strong>service (unfactored)</strong> loads against the SBC, and the <strong>depth and reinforcement</strong> are then designed using <strong>factored</strong> loads. Using factored loads to size the base gives a footing 50% too large; using service loads to design the steel gives one that is unsafe." },
          ],
        },

        {
          n: "9.2",
          title: "Choosing a type",
          hi: "प्रकार का चुनाव",
          blocks: [
            { k: "list", items: [
              "<strong>Isolated (pad) footing</strong> — one column, one pad. The default wherever the soil is decent and the columns are far enough apart.",
              "<strong>Combined footing</strong> — two or more columns on one pad. Used when the pads would otherwise overlap, or when a column sits on a property line and cannot have a symmetric footing of its own.",
              "<strong>Strip footing</strong> — a continuous footing under a wall, or under a line of closely spaced columns.",
              "<strong>Raft (mat)</strong> — one slab under the whole building. Used when the footings would cover more than about half the plan area anyway, or when the soil is weak and differential settlement must be evened out.",
              "<strong>Pile foundation</strong> — where competent soil is deep, the load is carried down to it by friction along the pile shaft, by end bearing at its toe, or by both.",
            ]},
            { k: "p", t: "The choice is rarely purely structural. Depth to good soil, the water table, the presence of neighbouring buildings, the property line and the cost of excavation usually decide it before the calculation begins." },
          ],
        },

        {
          n: "9.3",
          title: "Sizing the base",
          hi: "बेस का आकार",
          blocks: [
            { k: "p", t: "The base area follows from a single inequality: the pressure under the footing must not exceed the SBC under service load." },
            { k: "eq", expr: "A  =  (P + self weight of footing and soil above it) / SBC", where: [
              ["P", "service axial load from the column, kN"],
              ["A", "required plan area, m²"],
            ]},
            { k: "p", t: "The self weight is not known until the footing has been sized, so it is estimated first — 10% of the column load is the usual allowance for an ordinary pad footing, more for a deep one with a lot of backfill above it. The estimate is checked at the end." },
            { k: "def", term: "Net upward pressure", t: "Once the footing is in place, the weight of the footing and of the soil sitting on it is carried by the ground directly beneath it and produces no bending in the pad at all. The pressure used for the <em>structural</em> design is therefore the net value — the column load divided by the base area, without the self weight. Including it would overstate the moment." },
            { k: "p", t: "Where the column also transfers a moment, the pressure distribution is trapezoidal rather than uniform, and the requirement becomes two: the maximum pressure must not exceed the SBC, and the minimum should not go negative, because soil cannot pull. Keeping the resultant within the middle third of the base guarantees the second." },
            { k: "eq", expr: "pmax, pmin  =  P/A  ±  M / Z", where: [
              ["Z", "section modulus of the base area in the plane of the moment, m³"],
            ]},
          ],
        },

        {
          n: "9.4",
          title: "The three checks",
          hi: "तीन जाँचें",
          blocks: [
            { k: "p", t: "With the plan size settled from service loads, the rest of the design uses the factored net upward pressure, and IS 456 Cl. 34 fixes three checks — each at a different critical section." },
            { k: "dia", id: "hb-rcc-footchecks", cap: "Bending at the column face, one-way shear at d from the face, punching shear on a perimeter d/2 out." },
            { k: "steps", items: [
              "<strong>Bending</strong> (Cl. 34.2.3) — the projection of the pad beyond the column is a cantilever carrying the upward pressure. The critical section is at the <em>face</em> of a concrete column (at the halfway point of the projection for a masonry wall).",
              "<strong>One-way shear</strong> (Cl. 34.2.4) — a vertical section across the full width of the footing, at a distance <strong>d</strong> from the face of the column. The resistance is the ordinary τc of Chapter 5.",
              "<strong>Two-way (punching) shear</strong> (Cl. 31.6) — a perimeter at <strong>d/2</strong> from the column face all round. The column is trying to push a block straight through the pad.",
            ]},
            { k: "eq", expr: "Punching:  τv = Vu / (b0 d)  ≤  ks × 0.25 √fck", where: [
              ["b0", "length of the critical perimeter at d/2 from the column face, mm"],
              ["Vu", "factored load minus the upward pressure inside that perimeter, N"],
              ["ks", "0.5 + βc, not more than 1.0, where βc is the ratio of the short side of the column to the long side (Cl. 31.6.3)"],
            ]},
            { k: "p", t: "For a square column βc = 1, so ks = 1.5 which is then capped at 1.0 and the permitted stress is simply 0.25 √fck. For an elongated column βc is small and ks reduces the permitted stress, because a long thin column punches less efficiently around its short ends." },
            { k: "note", t: "In an ordinary isolated footing it is nearly always <strong>punching shear that fixes the depth</strong>. The flexural requirement is met by a much thinner pad, and the steel then comes out at the minimum. That is why footings look so much thicker than their bending moment seems to justify." },
          ],
        },

        {
          n: "9.5",
          title: "An isolated footing worked through",
          hi: "एकल फुटिंग — हल सहित",
          blocks: [
            { k: "eg",
              title: "Example 9.1 — Isolated square footing",
              given: "400 × 400 mm column carrying a service axial load of 1000 kN. Safe bearing capacity 200 kN/m². M25 concrete, Fe 415 steel, cover 50 mm, 16 mm bars.",
              steps: [
                { t: "Plan area — SERVICE load against SBC", w: "Allow 10% for the weight of the footing and the soil on it\nA = 1.1 × 1000/200 = 5.5 m²\nside = √5.5 = 2.35 m  →  provide 2.4 m × 2.4 m = 5.76 m²" },
                { t: "Factored net upward pressure", w: "Pu = 1.5 × 1000 = 1500 kN\nqu = 1500/5.76 = 260.4 kN/m²  (net — self weight excluded)" },
                { t: "Bending at the column face (Cl. 34.2.3)", w: "projection = (2400 − 400)/2 = 1000 mm = 1.0 m\nMu = qu × projection²/2 = 260.4 × 1.0²/2 = 130.2 kNm per metre width" },
                { t: "Trial depth", w: "For flexure alone: d = √(130.2×10⁶/(0.138 × 25 × 1000)) = 194 mm\nBut shear will govern — try D = 600 mm\nd = 600 − 50 (cover) − 8 (half of a 16 mm bar) = 542 mm" },
                { t: "Steel for bending", w: "5.9934 Ast² − 195,689 Ast + 130.2 × 10⁶ = 0\nAst = [195,689 − 187,544]/11.987 = 680 mm² per metre\nMinimum steel: 0.12% × 1000 × 600 = 720 mm²/m  →  GOVERNS\nProvide 16 mm @ 270 mm c/c both ways = 745 mm²/m  ✓" },
                { t: "One-way shear (Cl. 34.2.4)", w: "Critical section at d from the column face:\ndistance from the edge = 1000 − 542 = 458 mm\nVu = 260.4 × 0.458 × 2.4 = 286.2 kN\nτv = 286,200/(2400 × 542) = 0.220 N/mm²\npt = 100 × 745/(1000 × 542) = 0.137%\nτc (M25, Table 19 expression) = 0.28 N/mm²\n0.220  <  0.28  ✓" },
                { t: "Punching shear (Cl. 31.6)", w: "Critical perimeter at d/2 = 271 mm from each face:\nside = 400 + 542 = 942 mm;  b0 = 4 × 942 = 3768 mm\nVu = 260.4 × (5.76 − 0.942²) = 260.4 × 4.873 = 1268.9 kN\nτv = 1,268,900/(3768 × 542) = 0.621 N/mm²\nPermitted = ks × 0.25√fck, with βc = 1 → ks = 1.0\n          = 0.25 × √25 = 1.25 N/mm²\n0.621  <  1.25  ✓ comfortable" },
                { t: "Development length (Cl. 26.2.1)", w: "Ld for 16 mm Fe 415 in M25 = 40.3 × 16 = 645 mm\nAvailable from the critical section to the edge = 1000 − 50 = 950 mm  ✓" },
              ],
              ans: "2.4 m × 2.4 m × 600 mm deep pad, with 16 mm bars at 270 mm centres both ways at the bottom. Both shear checks pass with margin, and the steel is at the minimum — which is the normal shape of an isolated footing design.",
            },
            { k: "trap", t: "Both directions of a square footing need their own mesh, and the two layers sit at different effective depths — the upper layer has roughly one bar diameter less. For a square footing under an axial load the difference is usually absorbed by the minimum-steel requirement, but for a rectangular footing the shorter direction should be checked with its own, smaller d." },
          ],
        },

        {
          n: "9.6",
          title: "Getting the load out of the column",
          hi: "कॉलम से लोड फुटिंग में",
          blocks: [
            { k: "p", t: "There is a check that is skipped more often than it should be: the load has to pass through the joint between the column and the footing, and at that surface a small heavily loaded area bears on a large lightly loaded one. Cl. 34.4 governs it." },
            { k: "dia", id: "hb-rcc-dowel", cap: "The loaded area spreads into the supporting area, and the bearing stress is allowed to rise accordingly." },
            { k: "eq", expr: "permissible bearing stress = 0.45 fck √(A1/A2),   with √(A1/A2) ≤ 2", where: [
              ["A2", "the loaded area — the column section, mm²"],
              ["A1", "the supporting area, taken as the largest frustum with 2 horizontal to 1 vertical sides, mm²"],
            ]},
            { k: "p", t: "The √(A1/A2) factor is a real effect and not a code allowance: concrete loaded over a small patch is confined by the concrete around it, and confined concrete is stronger. The cap of 2 is there because the confinement stops improving once the surrounding area is large enough." },
            { k: "p", t: "Where the bearing stress exceeds the permissible value, the excess must be carried by reinforcement crossing the joint — <strong>dowels</strong>. Cl. 34.4.3 requires dowel area of at least 0.5% of the column section, with a minimum of four bars, and the dowels must be developed for their full stress on both sides of the joint: into the footing and into the column above." },
            { k: "note", t: "Dowels are provided in practice whether or not the bearing check demands them, because the column's own bars stop at the kicker and something has to continue the load path. They are the reason a footing is cast with a cage of starter bars sticking up out of it." },
          ],
        },

        {
          n: "9.7",
          title: "Combined footings, and what changes",
          hi: "संयुक्त फुटिंग",
          blocks: [
            { k: "p", t: "When two columns are close enough that their pads would overlap, or when one sits on a property line and cannot be centred, they share one footing. The structural behaviour changes completely." },
            { k: "list", items: [
              "The pad now spans <strong>between</strong> the columns, so it bends the other way in that region — the top of the footing is in tension, and steel is needed at the top as well as at the bottom.",
              "The plan shape is chosen so that the <strong>centroid of the base coincides with the resultant of the column loads</strong>. Only then is the pressure uniform. A rectangular footing works when the loads are equal; otherwise a trapezoidal one, or a strap connecting two separate pads, is used.",
              "The pad is analysed as an inverted beam carrying the upward soil pressure, supported on the columns — draw its shear force and bending moment diagrams like any beam.",
            ]},
            { k: "p", t: "A property-line column is the classic case: its footing cannot extend outwards, so a symmetric pad would be loaded off-centre and would tilt. Combining it with the next interior column, or connecting the two with a strap beam, brings the resultant back over the centroid." },
          ],
        },

        {
          n: "9.8",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Size the base with SERVICE loads against the SBC; design depth and steel with FACTORED loads.",
              "Use the NET upward pressure for the structural design.",
              "Bending at the column face; one-way shear at d; punching at d/2 all round.",
              "Punching almost always fixes the depth of an isolated footing; the flexural steel usually comes out at the minimum.",
              "Punching resistance = ks × 0.25√fck, with ks = 0.5 + βc ≤ 1.0.",
              "Check the bearing stress at the column-footing joint, and provide dowels developed both sides.",
              "Minimum steel in a footing is by the slab rule (0.12% of gross area for HYSD bars), and the edge thickness of a footing on soil is at least 150 mm.",
            ]},
            { k: "p", t: "That completes the strength design of a whole load path — slab to beam to column to footing to soil. Chapter 10 goes back over the same members and asks a different question: not whether they will stand, but whether anyone will be willing to live in them." },
          ],
        },
      ],
    },

    /* ============================================================ CH 10 */
    {
      id: "rcc-10",
      n: 10,
      title: "Serviceability: Deflection and Cracking",
      hi: "सेवाक्षमता: विक्षेपण और दरार",
      blurb: "The checks that decide whether a structure is usable rather than whether it stands — and the ones that generate nearly all the complaints.",
      mins: 40,
      sections: [

        {
          n: "10.1",
          title: "A different question, and different loads",
          hi: "अलग सवाल, अलग भार",
          blocks: [
            { k: "p", t: "The limit state of collapse asks whether the structure will fall down. The limit state of serviceability asks whether it will do its job — whether floors are flat enough, cracks fine enough, and vibrations small enough for people to accept. Structures rarely collapse. They frequently annoy." },
            { k: "p", t: "Because the question is different, the loads are different. Cl. 36.4.1 sets the partial safety factor on loads to <strong>1.0</strong> for serviceability checks: the interest is in what happens under the load the structure actually carries day to day, not under a rare extreme. A deflection check carried out with factored loads is not conservative — it is simply the wrong calculation." },
            { k: "trap", t: "Serviceability also uses different material properties. Under service load the concrete is in its elastic range and the steel is well below yield, so the analysis uses the modular ratio and elastic section properties, not the parabolic-rectangular stress block. Mixing the two — factored loads with an elastic section, or a stress-block calculation for deflection — is the most common confusion in this chapter." },
          ],
        },

        {
          n: "10.2",
          title: "Deflection limits",
          hi: "विक्षेपण की सीमाएँ",
          blocks: [
            { k: "p", t: "Cl. 23.2 sets two limits, and they are not alternatives — both must be satisfied." },
            { k: "list", items: [
              "<strong>span / 250</strong> on the final deflection due to all loads, measured below the level of the supports. This is about appearance and about drainage: a floor that sags visibly looks unsafe even when it is not, and a roof that ponds water collects load where it is already deflecting.",
              "<strong>span / 350 or 20 mm, whichever is less</strong>, on the deflection that occurs <em>after</em> the partitions and finishes are constructed. This is about damage: brittle partitions, glazing and tiling crack when the floor beneath them moves.",
            ]},
            { k: "dia", id: "hb-rcc-defl", cap: "The immediate deflection is only part of the story; creep and shrinkage add to it for years." },
            { k: "p", t: "The second limit is the harder one, and it is why the timing of construction matters to a structural calculation. The immediate deflection under the beam's own weight happens before the partitions exist, so it does not count against that limit. Everything after that — the finishes, the live load, and all the creep and shrinkage — does." },
          ],
        },

        {
          n: "10.3",
          title: "The span/depth method",
          hi: "स्पैन/गहराई विधि",
          blocks: [
            { k: "p", t: "For ordinary members Cl. 23.2.1 lets you avoid computing the deflection at all, by capping the span to effective depth ratio instead. Chapter 7 used it to size a slab; here is what is actually behind it." },
            { k: "p", t: "Deflection is proportional to l⁴/(E I) and the moment to l², so for a given load intensity the deflection-to-span ratio depends mainly on l/d. Fixing l/d therefore fixes the deflection in a rough but reliable way, provided the reinforcement and the section shape are in the usual ranges — which is exactly what the modification factors correct for." },
            { k: "list", items: [
              "Basic ratios: 7 (cantilever), 20 (simply supported), 26 (continuous).",
              "<strong>Tension steel factor</strong> (Fig. 4) — a function of pt and the service stress fs = 0.58 fy (Ast required / Ast provided). More steel than required lowers fs and raises the factor.",
              "<strong>Compression steel factor</strong> (Fig. 5) — compression steel restrains creep, so it genuinely reduces long-term deflection.",
              "<strong>Flanged section factor</strong> (Fig. 6) — a function of bw/bf, correcting for the fact that a T-beam's gross stiffness does not grow in proportion to its flange.",
              "For spans over 10 m, multiply the whole ratio by 10/span.",
            ]},
            { k: "note", t: "The method is a check on a whole member, not on a section. If it is satisfied, no deflection calculation is required. If it fails — or if the member is unusual, heavily loaded, or carries brittle finishes — then the actual deflection must be computed by Annex C, which is the next section." },
          ],
        },

        {
          n: "10.4",
          title: "Computing the deflection properly",
          hi: "वास्तविक विक्षेपण की गणना",
          blocks: [
            { k: "p", t: "Annex C gives the full calculation, and it has three parts that are added: the immediate elastic deflection, the additional deflection from creep, and the deflection from shrinkage." },
            { k: "h", t: "Part 1 — immediate deflection and the effective moment of inertia" },
            { k: "p", t: "A reinforced beam is uncracked near its supports where the moment is small and cracked at mid-span where it is large, so neither the gross moment of inertia nor the fully cracked value is right. Annex C-2.1 interpolates between them:" },
            { k: "eq", expr: "Ieff = Ir / [1.2 − (Mr/M)(z/d)(1 − x/d)(bw/b)],   with Ir ≤ Ieff ≤ Igr", where: [
              ["Ir", "moment of inertia of the cracked transformed section, mm⁴"],
              ["Igr", "moment of inertia of the gross section, ignoring the steel, mm⁴"],
              ["Mr", "cracking moment = fcr Igr / yt, where fcr = 0.7 √fck (Cl. 6.2.2)"],
              ["M", "maximum service moment on the member"],
              ["x", "depth of the neutral axis of the cracked transformed section"],
              ["z", "lever arm of the cracked section = d − x/3"],
            ]},
            { k: "p", t: "The deflection then follows from ordinary elastic theory — 5wl⁴/384 EI for a simply supported uniformly loaded beam — using Ec = 5000 √fck (Cl. 6.2.3.1) and Ieff." },
            { k: "h", t: "Part 2 — creep" },
            { k: "p", t: "Concrete under sustained load goes on shortening for years. Annex C-3 handles it by repeating the permanent-load deflection with an effective modulus:" },
            { k: "eq", expr: "Ece = Ec / (1 + θ)", where: [
              ["θ", "creep coefficient: 2.2 at 7 days of loading, 1.6 at 28 days, 1.1 at one year (Cl. 6.2.5.1)"],
            ]},
            { k: "p", t: "The creep deflection is the difference between the permanent-load deflection computed with Ece and the same deflection computed with Ec. Note that lowering the modulus raises the modular ratio, which deepens the neutral axis and increases Ir — so the two effects partly offset, and the increase is less than (1 + θ) would suggest." },
            { k: "h", t: "Part 3 — shrinkage" },
            { k: "p", t: "Concrete shrinks as it dries, and reinforcement, which does not shrink, restrains it. In a singly reinforced beam the steel is all at the bottom, so the bottom shrinks less than the top and the member curves downwards — deflection with no load at all." },
            { k: "eq", expr: "acs = k3 ψcs l²,    ψcs = k4 εcs / D", where: [
              ["k3", "0.5 for a cantilever, 0.125 for a simply supported member, 0.086 for one end continuous, 0.063 for both ends continuous"],
              ["εcs", "ultimate shrinkage strain, 0.0003 in the absence of test data (Cl. 6.2.4.1)"],
              ["k4", "0.72 (pt − pc)/√pt ≤ 1.0 for 0.25 ≤ (pt − pc) < 1.0, and 0.65(pt − pc)/√pt ≤ 1.0 for (pt − pc) ≥ 1.0"],
            ]},
            { k: "note", t: "k4 depends on (pt − pc), the <em>difference</em> between tension and compression steel. A symmetrically reinforced section has no shrinkage curvature at all, because both faces are restrained equally. This is a second, independent reason to put steel in the compression face of a long-span beam." },
          ],
        },

        {
          n: "10.5",
          title: "A deflection calculation from end to end",
          hi: "पूरी विक्षेपण गणना",
          blocks: [
            { k: "eg",
              title: "Example 10.1 — Long-term deflection of a beam",
              given: "Simply supported beam, span 6.0 m, b = 300 mm, D = 500 mm, d = 450 mm, M25, Fe 415, Ast = 1250 mm². Service load 20 kN/m in total, of which 12 kN/m is permanent. Loaded at 28 days.",
              steps: [
                { t: "Section properties and the cracking moment", w: "Ec = 5000 √25 = 25,000 N/mm²\nIgr = 300 × 500³/12 = 3.125 × 10⁹ mm⁴\nfcr = 0.7 √25 = 3.5 N/mm²\nMr = 3.5 × 3.125×10⁹/250 = 43.75 kNm" },
                { t: "Is the beam cracked?", w: "M (service, total) = 20 × 6²/8 = 90 kNm  >  Mr = 43.75 kNm\n→ cracked, so Ieff applies" },
                { t: "Cracked transformed section", w: "m = Es/Ec = 200,000/25,000 = 8\n300 x²/2 = 8 × 1250 × (450 − x)\n150 x² + 10,000 x − 4.5×10⁶ = 0  →  x = 143.0 mm\nIr = 300 × 143.0³/3 + 10,000 × (450 − 143.0)²\n   = 2.928×10⁸ + 9.422×10⁸ = 1.235 × 10⁹ mm⁴" },
                { t: "Effective moment of inertia under total load", w: "z = 450 − 143.0/3 = 402.3 mm\ndenominator = 1.2 − (43.75/90)(402.3/450)(1 − 143.0/450)\n            = 1.2 − 0.486 × 0.894 × 0.682 = 0.9036\nIeff = 1.235×10⁹/0.9036 = 1.367 × 10⁹ mm⁴   (between Ir and Igr  ✓)" },
                { t: "Immediate deflection under total load", w: "δ = 5wl⁴/(384 Ec Ieff)\n  = 5 × 20 × 6000⁴/(384 × 25,000 × 1.367×10⁹)\n  = 9.88 mm" },
                { t: "Immediate deflection under permanent load alone", w: "M (permanent) = 12 × 6²/8 = 54 kNm\nIeff = 1.235×10⁹/[1.2 − (43.75/54)(0.894)(0.682)] = 1.749 × 10⁹\nδ = 5 × 12 × 6000⁴/(384 × 25,000 × 1.749×10⁹) = 4.63 mm" },
                { t: "The same, with the creep-reduced modulus", w: "θ = 1.6 at 28 days  →  Ece = 25,000/2.6 = 9615 N/mm²\nm = 200,000/9615 = 20.8  →  x = 205.8 mm, Ir = 2.422×10⁹\nIeff = 2.422×10⁹/0.8273 = 2.928 × 10⁹ mm⁴  (< Igr  ✓)\nδ = 5 × 12 × 6000⁴/(384 × 9615 × 2.928×10⁹) = 7.19 mm" },
                { t: "Creep deflection", w: "= 7.19 − 4.63 = 2.56 mm" },
                { t: "Shrinkage deflection", w: "pt = 100 × 1250/(300 × 450) = 0.926%,  pc = 0\nk4 = 0.72 × 0.926/√0.926 = 0.693\nψcs = 0.693 × 0.0003/500 = 4.157 × 10⁻⁷ per mm\nacs = 0.125 × 4.157×10⁻⁷ × 6000² = 1.87 mm" },
                { t: "Total, and the two limits", w: "Total = 9.88 (immediate) + 2.56 (creep) + 1.87 (shrinkage) = 14.31 mm\nLimit 1: span/250 = 6000/250 = 24 mm      14.31 < 24  ✓\nAfter partitions = 14.31 − 4.63 = 9.68 mm\nLimit 2: span/350 = 17.1 mm, or 20 mm → 17.1 mm      9.68 < 17.1  ✓" },
              ],
              ans: "Total long-term deflection 14.3 mm against a limit of 24 mm; 9.7 mm arrives after the partitions, against a limit of 17.1 mm. The beam is satisfactory.",
            },
            { k: "trap", t: "Creep and shrinkage together added 4.4 mm to an immediate 9.9 mm — nearly half as much again. A calculation that stops at the elastic deflection is not a deflection check, and it is the part it leaves out that cracks the partitions." },
          ],
        },

        {
          n: "10.6",
          title: "Cracking",
          hi: "दरार",
          blocks: [
            { k: "p", t: "Reinforced concrete cracks. That is not a defect — the whole theory of Chapter 3 assumed that the concrete below the neutral axis had cracked and carried nothing. Steel only carries tension by stretching, and concrete bonded to stretching steel must crack. The design question is never whether there are cracks, but how <strong>wide</strong> each one is." },
            { k: "p", t: "Width matters because of corrosion. A wide crack lets water, oxygen and chlorides reach the bar, the bar rusts, rust occupies more volume than steel, and the expansion spalls the cover — after which the corrosion accelerates. Cl. 35.3.2 sets the acceptable surface width:" },
            { k: "list", items: [
              "<strong>0.3 mm</strong> for members where cracking is not harmful to appearance or durability — the general case.",
              "<strong>0.2 mm</strong> where cracking is harmful because the member is exposed to the weather, continuously exposed to moisture, or <strong>in contact with soil or ground water</strong>.",
              "<strong>0.1 mm</strong> for particularly aggressive environments — the severe category and worse of Table 3.",
            ]},
            { k: "note", t: "<b>Correction (v34):</b> an earlier version placed members in contact with soil or water in the 0.1 mm category. Cl. 35.3.2 puts contact with soil or ground water in the <b>0.2 mm</b> category; 0.1 mm is reserved for particularly aggressive (severe and worse) environments — as stated in <a href=\"https://www.sarthaks.com/2545521/using-design-method-members-cracking-tensile-harmful-because-continuously-exposed-ground\" target=\"_blank\" rel=\"noopener\">Sarthaks' worked answer on Cl. 35.3.2</a>. Liquid-retaining structures follow IS 3370 (0.2 mm, or 0.1 mm for severe exposure) — see Chapter 1.2." },
            { k: "dia", id: "hb-rcc-crack", cap: "The same area of steel, arranged two ways. What changes is the width of each crack, not the total." },
            { k: "p", t: "The key idea is in that figure. The total opening across the tension zone is fixed by how far the steel has stretched, which is a strength matter and already settled. How that opening is <em>divided</em> — into a few wide cracks or many fine ones — depends on how closely the bars are spaced, because each bar only controls the concrete near it." },
            { k: "p", t: "This is why Cl. 26.3.3 limits bar spacing and why Cl. 26.5.1.3 requires side-face reinforcement in beams deeper than 750 mm. Neither rule adds strength. Both exist to stop the concrete midway between the bars from cracking on its own account, unrestrained by anything." },
            { k: "note", t: "Annex F gives a formula for computing the design surface crack width from the strain at the level considered, the distance to the nearest bar and the cover. In practice, satisfying the detailing rules is accepted as satisfying the crack-width requirement for ordinary members, and the formula is used for liquid-retaining structures, for water-retaining work under IS 3370, and where a client specifies a tighter limit." },
          ],
        },

        {
          n: "10.7",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Serviceability uses SERVICE loads (γf = 1.0) and elastic section properties.",
              "Deflection limits: span/250 total, and span/350 or 20 mm after partitions (Cl. 23.2).",
              "The span/depth rule of Cl. 23.2.1 is a legitimate substitute for computing deflection in ordinary members.",
              "Annex C: immediate deflection from Ieff, plus creep via Ece = Ec/(1+θ), plus shrinkage curvature.",
              "Creep and shrinkage typically add 40–60% to the immediate deflection.",
              "Crack widths: 0.3 / 0.2 / 0.1 mm by exposure (Cl. 35.3.2), controlled in practice by bar spacing rather than by calculation.",
              "Compression steel helps twice over: it restrains creep and it cancels shrinkage curvature.",
            ]},
            { k: "p", t: "Chapters 3 to 10 have covered the members that make up nearly every reinforced concrete building. Chapter 11 takes the elements that do not fit that list — stairs, retaining walls, deep beams, corbels — and shows how each one is handled by bending the same rules to a different geometry." },
          ],
        },
      ],
    }

  );
})();
