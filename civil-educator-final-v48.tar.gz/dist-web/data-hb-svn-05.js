/* Surveying class notes — Compass surveying: traverse, meridians, bearings, included angles, declination, dip, notes p.2–29 — inserted into sv chapter 4 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 4; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- traverse */
    {
      n: "", title: "Class notes — Traverse and its types", hi: "ट्रैवर्स और उसके प्रकार",
      blocks: [
        { k: "h", t: "📘 Notes — p.2–3  (Angular measurement — Compass survey)" },
        { k: "def", term: "Traverse", t: "A traverse is a <b>series of connecting lines</b>. (p.2)" },
        { k: "p", t: "Figure (p.2): a pentagon-shaped closed traverse with vertices A (left), B (top), C (right), D (bottom right), E (bottom left). Labels: \"A, B, C, D, E → end points\"; \"AB, BC, CD, DE, EA are survey lines\". (p.2)" },
        { k: "list", items: [
          "The point where the survey lines meet is called <b>end point</b> or <b>traverse point</b> or <b>traverse station</b>. (p.2)",
          "In a compass traverse the <b>length</b> of a survey line is measured with the help of a <b>chain or tape</b>. (p.2)",
          "Where two survey lines meet, the <b>horizontal angle</b> is also measured. (p.2)",
          "Depending upon the instrument used for the measurement of angles, a traverse may be: <b>compass traverse</b>, <b>plane table traverse</b>, <b>theodolite traverse</b>, <b>stadia traverse (tacheometric traverse)</b>. (p.2)",
        ] },
        { k: "p", t: "<b>Types of traverse:</b> → Closed traverse · → Open traverse (p.2)" },
        { k: "def", term: "(i) Closed traverse", t: "A closed traverse starts from a point (station) of <b>known location</b> and ends either at the <b>same</b> location (station) or at a station of <b>known location</b>. (p.3)" },
        { k: "p", t: "Figure (p.3): left — a closed hexagonal traverse A, B (top), C, D, E (bottom), F that returns to A. Right — a zig-zag traverse A → B (down) → C (up) → D (down-right) with the caption \"location of A &amp; D are known\" (a closed traverse ending on a second known point). (p.3)" },
        { k: "def", term: "(ii) Open traverse", t: "Starts from a point of <b>known location</b> and ends at a point whose location is <b>not known</b>.<br>⇒ Open traverses are used for <b>canal, railway, road</b> etc. (p.3)" },
        { k: "def", term: "Compass traverse", t: "In compass survey a <b>magnetic compass</b> is used for the measurement of <b>horizontal angles</b>, and a <b>chain or tape</b> is used for the measurement of <b>horizontal distance</b>. (p.3)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Traverse ka matlab hai lines ki ek chain — har line ki length (chain/tape se) aur har line ki direction (compass se). Closed traverse apne aap ko check kar sakta hai, kyunki woh kisi known point par khatam hota hai; open traverse (canal, road, railway jaisi lambi patli strip) ke end par koi check nahi milta, isliye usme galti chupi reh sakti hai." },
        { k: "trap", t: "Closed traverse ka matlab sirf 'polygon jo wapas start par aaye' nahi hai. Notes ke hisaab se agar traverse ek known point se shuru hokar <b>doosre known point</b> par khatam ho (A aur D dono known), woh bhi <b>closed</b> traverse hai. Open tabhi hai jab end point ki location known na ho." },
        { k: "real", t: "Road ya canal alignment ka preliminary survey aksar open traverse hota hai — ek known bench/station se shuru karke alignment ke saath aage badhte jaate hain." },
      ],
    },

    /* ---------------------------------------------------------- meridians */
    {
      n: "", title: "Class notes — Measurement of angles and meridians", hi: "कोणों का मापन और याम्योत्तर",
      blocks: [
        { k: "h", t: "📘 Notes — p.3–6" },
        { k: "p", t: "<b>Measurement of angles</b> → The direction of a survey line can be defined in two ways: (p.3–4)" },
        { k: "list", items: [
          "<b>1) Relative to each other</b> — e.g. the angles θ₁, θ₂, θ₃, θ₄, θ₅ between adjacent lines. (p.4)",
          "<b>2) With reference to a fixed reference line (meridian)</b> — e.g. the angles α₁ … α₅. (p.4)",
        ] },
        { k: "p", t: "Figure (p.4): closed pentagon traverse A (left), B (top), C (right), D (bottom right), E (bottom left). Interior angles θ₁ at A, θ₂ at B, θ₃ at C, θ₄ at D, θ₅ at E (black arcs). At every station a short vertical (north) reference line is drawn, and red arcs α₁ at A, α₂ at B, α₃ at C, α₄ at D, α₅ at E are measured clockwise from this vertical line to the survey line. (p.4)" },
        { k: "def", term: "Meridian", t: "A meridian is a <b>fixed or reference line</b> with respect to which the angle of any line is measured. (p.4)" },
        { k: "p", t: "<b>Types of meridian:</b> 1) True meridian · 2) Magnetic meridian · 3) Grid meridian · 4) Arbitrary meridian (p.4)" },
        { k: "def", term: "1) True meridian", t: "True meridian at a point on the earth's surface is the line joining the <b>North and South poles</b> of the earth through that point.<br>⇒ True meridian represents the <b>true North and true South</b> direction at the place.<br>→ True meridian at a place is determined by taking <b>astronomical observations of sun and stars</b>.<br>→ True meridian at a place <b>does not change with time</b>. (p.4–5)" },
        { k: "def", term: "2) Magnetic meridian", t: "Magnetic meridian at a point is the direction indicated by a <b>freely suspended magnetic needle</b> or magnetic bar, provided the needle is not affected by any magnetic field other than the earth's magnetic field.<br>⇒ Magnetic meridian at a point <b>does not remain fixed</b> with time. It changes with the passage of time. (p.5)" },
        { k: "p", t: "Figure (p.5): a circle with a vertical diameter from T.N (top, arrow) to T.S (bottom, arrow) — labelled \"True meridian\" — and a horizontal diameter. A faint inclined line through the centre, slightly east of north at the top and west of south at the bottom, is labelled \"Magnetic meridian\". The angle between the T.N line and this inclined line is marked δ with the label \"Magnetic declination\". (p.5)" },
        { k: "def", term: "3) Grid meridian", t: "For the survey of a country, the <b>true meridian passing through the central place</b> is taken as the reference meridian for the whole country; this is called the grid meridian. (p.6)" },
        { k: "def", term: "4) Arbitrary meridian", t: "A meridian taken in any <b>arbitrary direction</b>. It is generally taken for a <b>small traverse</b> which does not have some important significance. (p.6)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Angle ko do tarah se bata sakte hain: ya to ek line ko doosri line se naapo (θ — included angles), ya har line ko ek <b>fixed</b> reference line se naapo (α — bearings). Fixed reference line hi meridian hai. Section 4.1 mein teen meridians aaye the; notes chautha bhi dete hain — <b>grid meridian</b>, jo poore desh ke liye ek hi central true meridian hota hai, taaki desh bhar ke maps ek hi north se bane." },
        { k: "p", t: "True meridian kabhi nahi badalta (geographic poles fixed hain), magnetic meridian badalta rehta hai (magnetic poles khisakte rehte hain). Isi difference se aage declination ka poora topic nikalta hai." },
        { k: "trap", t: "True meridian <b>compass se nahi</b> milta — woh sun aur stars ke astronomical observations se milta hai. Compass hamesha magnetic meridian deta hai. MCQ mein 'true meridian is determined by…' ka answer astronomical observation hai." },
      ],
    },

    /* ---------------------------------------------------------- bearings */
    {
      n: "", title: "Class notes — Bearings: types and designation (WCB, QB, RB)", hi: "दिशाकोण: प्रकार और पद्धतियाँ",
      blocks: [
        { k: "h", t: "📘 Notes — p.6–10" },
        { k: "def", term: "Bearing", t: "Bearing is the <b>horizontal angle</b> between two successive survey lines, or between one survey line and the reference line (meridian). (p.6)" },
        { k: "p", t: "<b>Types of bearing:</b> 1) True bearing · 2) Magnetic bearing · 3) Grid bearing · 4) Arbitrary bearing (p.6)" },
        { k: "def", term: "1) True bearing", t: "True bearing of a line is the horizontal angle of the survey line measured with reference to the <b>true meridian</b>.<br>True bearing <b>does not change</b> with passage of time. (p.6)" },
        { k: "def", term: "2) Magnetic bearing", t: "Magnetic bearing of a line is the horizontal angle measured with reference to the <b>magnetic meridian</b>.<br>As the magnetic meridian does not remain fixed with passage of time, the magnetic bearing also <b>changes</b> with passage of time. (p.7)" },
        { k: "note", t: "<b>Note (notes):</b> For all important survey works, <b>true bearing is preferred over magnetic bearing</b> because it remains constant with time. True bearing of a line is found by taking <b>astronomical observation</b>, and magnetic bearing is found by <b>magnetic compass</b>. (p.7)" },
        { k: "h", t: "Designation of bearing" },
        { k: "cmp", cols: ["Range"], rows: [
          ["1) Whole circle bearing system (WCB)", "0° – 360°"],
          ["2) Quadrantal bearing system (QB)", "0° – 90°"],
          ["3) Reduced bearing system (RB)", "0° – 90°"],
        ] },
        { k: "def", term: "1) Whole circle bearing (WCB)", t: "The bearing of any line is measured in the <b>clockwise direction from the North end</b>.<br>WCB is also called <b>azimuth</b>, and its value varies 0° – 360°.<br>WCB is given by the <b>prismatic compass</b> ↳ least value (least count) = <b>30 min</b>. (p.7–8)" },
        { k: "p", t: "Figure (p.8): vertical N–S and horizontal W–E lines crossing at O. Four lines from the centre: OA (NE quadrant), OB (SE), OC (SW), OD (NW). Clockwise arcs all start from N: θ₁ from N to A; θ₂ from N to B; θ₃ from N to C; θ₄ from N all the way round to D. (p.8)" },
        { k: "def", term: "2) Quadrantal bearing (QB)", t: "It is the <b>acute angle</b> which a line makes with the reference meridian.<br>It is measured from the <b>North or South end</b> of the reference meridian, whichever is nearer; therefore the angle is <b>always less than 90°</b>.<br>It is given by the <b>surveyor's compass</b>. (p.8)" },
        { k: "p", t: "Figure (p.8): axes N (up), S (down), E (right), W (left); lines OA (NE), OB (SE), OC (SW), OD (NW). θ₁ from N clockwise to A — \"Nθ₁E\"; θ₂ from S anticlockwise to B — \"Sθ₂E\"; θ₃ from S clockwise to C — \"Sθ₃W\"; θ₄ from N anticlockwise to D — \"Nθ₄W\". In red: on the N axis \"N0°\"; on the E axis \"N90°E | S90°E\"; on the W axis \"N90°W | S90°W\". (p.8)" },
        { k: "p", t: "Figure (p.9) — <b>Interchange of QB into WCB</b>: lines OA (NE), OB (SE), OC (SW), OD (NW) with quadrantal angles θ₁ (N to OA), θ₂ (S to OB), θ₃ (S to OC), θ₄ (N to OD). Red labels: WCB of OA = θ₁; WCB of OB = 180° − θ₂; WCB of OC = 180° + θ₃; WCB of OD = 360° − θ₄. (p.9)" },
        { k: "p", t: "Figure (p.9) — <b>Interchange of WCB into QB</b>: same four lines with clockwise WCB arcs θ₁, θ₂, θ₃, θ₄ from N. Red labels: OA = Nθ₁E; OB = S(180° − θ₂)E; OC = S(θ₃ − 180°)W; OD = N(360° − θ₄)W. (p.9)" },
        { k: "def", term: "3) Reduced bearing (RB)", t: "When the WCB of a line exceeds 90°, it must be reduced to the corresponding angle which is <b>less than 90°</b>; this angle is called the reduced bearing.<br>Sometimes reduced bearings are used in the same manner (as quadrantal bearings). (p.10)" },
        { k: "cmp", t: "Conversion table (p.10)", cols: ["WCB", "QB", "RB"], rows: [
          ["Case 1", "0° – 90°", "N (WCB) E", "WCB"],
          ["Case 2", "90° – 180°", "S (180° − WCB) E", "180° − WCB"],
          ["Case 3", "180° – 270°", "S (WCB − 180°) W", "WCB − 180°"],
          ["Case 4", "270° – 360°", "N (360° − WCB) W", "360° − WCB"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "WCB ek hi rule hai — North se clockwise, poora 360°. QB/RB mein angle hamesha <b>N ya S se</b> shuru hota hai (jo paas ho) aur <b>E ya W ki taraf</b> jaata hai, isliye kabhi 90° se zyada nahi hota. Conversion ke liye table ratne ki zaroorat nahi — line ka sketch banao, dekho kaunse quadrant mein hai, aur nearest N/S end se angle nikaalo (jaise section 4.1 mein bhi kaha gaya)." },
        { k: "trap", t: "QB ko kabhi E ya W se mat naapo. 'E 30° N' galat designation hai — sahi likhna hai N 60° E. Pehla letter hamesha N ya S hota hai, aakhri letter E ya W." },
        { k: "real", t: "Prismatic compass (WCB, least count 30′) hand-held reconnaissance mein chalta hai; surveyor's compass (QB) tripod par. Field book mein jis compass se reading li, usi system mein bearing likho, aur calculation se pehle sab ek hi system (usually WCB) mein convert kar lo." },
      ],
    },

    /* ---------------------------------------------------------- conversions */
    {
      n: "", title: "Class notes — Converting QB and WCB (numericals)", hi: "दिशाकोण रूपांतरण — प्रश्न",
      blocks: [
        { k: "h", t: "📘 Notes — p.10–11" },
        { k: "eg",
          title: "Notes example — Convert QB to WCB",
          given: "Convert the following QB to WCB: (i) N 30° E  (ii) S 38°46′ E  (iii) S 46°18′ W  (iv) N 18°36′ W",
          steps: [
            { t: "(i) N 30° E — NE quadrant", w: "WCB = 30°" },
            { t: "(ii) S 38°46′ E — SE quadrant", w: "WCB = 180° − 38°46′ = 141°14′" },
            { t: "(iii) S 46°18′ W — SW quadrant", w: "WCB = 180° + 46°18′ = 226°18′" },
            { t: "(iv) N 18°36′ W — NW quadrant", w: "WCB = 360° − 18°36′ = 341°24′" },
          ],
          ans: "(i) 30°  (ii) 141°14′  (iii) 226°18′  (iv) 341°24′  (p.10)",
        },
        { k: "eg",
          title: "Notes example — Convert WCB to QB",
          given: "Convert WCB into QB: (i) 48°13′  (ii) 138°12′  (iii) 203°18′  (iv) 300°33′",
          steps: [
            { t: "(i) 48°13′ — between 0° and 90°", w: "QB = N 48°13′ E" },
            { t: "(ii) 138°12′ — between 90° and 180°", w: "QB = S (180° − 138°12′) E = S 41°48′ E" },
            { t: "(iii) 203°18′ — between 180° and 270°", w: "QB = S (203°18′ − 180°) W, written in the notes as S 23°58′ W" },
            { t: "(iv) 300°33′ — between 270° and 360°", w: "QB = N (360° − 300°33′) W = N 59°27′ W" },
          ],
          ans: "(i) N 48°13′ E  (ii) S 41°48′ E  (iii) S 23°58′ W (as written)  (iv) N 59°27′ W  (p.11)",
        },
        { k: "note", t: "<b>Check:</b> for (iii), 203°18′ − 180° = <b>23°18′</b>, so the QB is <b>S 23°18′ W</b>, not S 23°58′ W as written in the notes (the minutes figure is a slip; confirmed on the page image). The other three answers are correct. (p.11)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har conversion mein sirf do sawaal: (1) line kaunse quadrant mein hai? (2) nearest N/S end se angle kitna hai? Minutes ka hisaab dhyaan se karo — 180° − 38°46′ ke liye 180° ko 179°60′ likh lo, phir 179°60′ − 38°46′ = 141°14′." },
        { k: "trap", t: "Minutes subtract karte waqt degree se 'borrow' karna bhoolna sabse common galti hai. Aur ulta bhi — WCB − 180° karte waqt minutes waise ke waise rehte hain (203°18′ → 23°18′); unhe badalne ki koi wajah nahi." },
      ],
    },

    /* ---------------------------------------------------------- FB / BB */
    {
      n: "", title: "Class notes — Fore bearing and back bearing", hi: "अग्र दिशाकोण और पश्च दिशाकोण",
      blocks: [
        { k: "h", t: "📘 Notes — p.11–12" },
        { k: "def", term: "Fore bearing (FB)", t: "It is the bearing of a line measured in the <b>direction of progress</b> of survey work. (p.11)" },
        { k: "def", term: "Back bearing (BB)", t: "It is the bearing of a line measured in the <b>opposite direction</b> of progress of work. (p.11)" },
        { k: "p", t: "Figure (p.11): line from A (left, lower) to B (right, higher). At A a north line and a short horizontal line; angle α₁ measured clockwise from north at A to line AB. At B a north line and horizontal line; angle α₂ (reflex) measured clockwise from north at B round to line BA. (p.11)" },
        { k: "p", t: "For AB → FB = α₁, BB = α₂ &nbsp;⟹&nbsp; <b>α₂ = 180° + α₁</b>, i.e. <b>BB = FB + 180°</b><br>For BA → FB = α₂, BB = α₁ &nbsp;⟹&nbsp; <b>α₁ = α₂ − 180°</b>, i.e. <b>BB = FB − 180°</b> (p.11–12)" },
        { k: "eq", expr: "BB = FB ± 180°", where: [
          ["+", "use when FB < 180°"],
          ["−", "use when FB > 180°"],
        ] },
        { k: "eq", expr: "FB of AB = BB of BA", where: [] },
        { k: "h", t: "In case of QB (p.12)" },
        { k: "p", t: "Figure (p.12): a line going down to the right from the first station to the second. At the first station the angle α₁ is measured from the south end of the meridian towards the line — label <b>FB = Sα₁E</b>. At the second station the same angle α₁ is measured from the north end of the meridian to the line pointing back — label <b>BB = Nα₁W</b>. (p.12)" },
        { k: "eg",
          title: "Notes example — Back bearing of a line given in QB",
          given: "FB = S 45° E. Find the back bearing.",
          steps: [
            { t: "Convert FB to WCB (SE quadrant)", w: "WCB = 180° − 45° = 135°" },
            { t: "FB = 135° < 180°, so add 180°", w: "BB = FB + 180°\nBB = 315°" },
            { t: "Convert back to QB (NW quadrant)", w: "315° = N 45° W  (sketch: 45° from north end to the line going up-left; clockwise arc from north = 315°)" },
          ],
          ans: "BB = 315° = N 45° W  (p.12)",
        },
        { k: "note", t: "<b>Note (notes):</b> If the FB of a line is given in QBS, the BB of the same line is obtained by replacing <b>North → South, South → North, East → West and West → East</b> (the angle stays the same). (p.12)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek hi line ko dono siron se dekho to direction bilkul ulti hoti hai — isliye 180° ka farak. ± ka rule sirf itna ensure karta hai ki answer 0°–360° ke andar rahe: FB chhota (&lt; 180°) ho to 180° jodo, bada (&gt; 180°) ho to 180° ghatao. QB mein to aur bhi aasaan — angle wahi, sirf N↔S aur E↔W swap." },
        { k: "trap", t: "QB mein back bearing nikalte waqt angle ko 180° se mat chhedo. S 45° E ka BB 'S 225° E' ya 'N 135° W' nahi hai — seedha <b>N 45° W</b>. Aur sirf ek letter swap karna (jaise S 45° W) bhi galat hai — dono letters badalte hain." },
        { k: "real", t: "Field mein har line ka FB aur BB dono lene ka asli fayda: agar unka farak exactly 180° nahi hai, to kisi station par local attraction hai (section 4.4 dekho)." },
      ],
    },

    /* ---------------------------------------------------------- included angles */
    {
      n: "", title: "Class notes — Included angles from bearings", hi: "अंतर्गत कोण (Included angle)",
      blocks: [
        { k: "h", t: "📘 Notes — p.13–15  (★ marked \"vimp\")" },
        { k: "def", term: "Included angle", t: "It is the <b>horizontal angle between two successive survey lines</b> in the direction of progress of survey, and is <b>always measured in the clockwise direction</b>. (p.13)" },
        { k: "p", t: "Figure (p.13), left: a quadrilateral A (left), B (top), C (right), D (bottom) with a <b>clockwise</b> arrow inside; red arcs at every corner drawn <b>outside</b> the figure (exterior angles). Caption: <b>Σ = (2n + 4) × 90°</b>.<br>Figure (p.13), right: a quadrilateral A (left), D (top), C (right), B (bottom) with an <b>anticlockwise</b> arrow inside; red arcs drawn <b>inside</b> the figure (interior angles). Caption: <b>Σ = (2n − 4) × 90°</b>. (p.13)" },
        { k: "note", t: "<b>Note (notes):</b> If the traverse runs in the <b>clockwise direction (↻)</b>, the included angle will be <b>exterior</b>; if the traverse runs in the <b>anticlockwise direction (↺)</b>, the included angle will be <b>interior</b>. (p.13)" },
        { k: "eq", expr: "∠ included = FB of next line − BB of previous line", where: [] },
        { k: "eq", expr: "Clockwise traverse (exterior angles): Σ = (2n + 4) × 90°;  Anticlockwise traverse (interior angles): Σ = (2n − 4) × 90°", where: [["n", "number of sides (stations) of the closed traverse"]] },
        { k: "p", t: "Figure (p.13): traverse A–B–C, line rising from A to B (apex) and descending to C; a meridian at each of A, B and C; the arc at B marks the included angle: <b>∠B = FB of BC − BB of AB</b>. (p.13)" },
        { k: "eg",
          title: "Notes example — Angle ABC from two WCBs",
          given: "The WCB of lines AB and BC are 30°15′ and 120°30′. Calculate angle ABC.",
          steps: [
            { t: "Sketch (p.14)", w: "A with meridian; AB rises to the apex B with bearing 30°15′ at A; at B the bearing 120°30′ is marked clockwise from the meridian to BC; BC descends to C." },
            { t: "Included angle rule", w: "∠B = FB of BC − BB of AB" },
            { t: "Substitute (add 360° to keep it positive)", w: "= 120°30′ − (30°15′ + 180°) + 360°\n= 270°15′" },
          ],
          ans: "∠ABC = 270°15′  (p.14)",
        },
        { k: "eg",
          title: "Notes example — Included angles of a closed compass traverse ABCD",
          given: "Determine the values of included angles in a closed compass traverse. FB: AB = 40°, BC = 70°, CD = 210°, DA = 280°.",
          steps: [
            { t: "Method 1 — from the sketch (p.14)", w: "A at left, B up-middle, C top-right, D bottom-right below C; meridian at each station; traverse runs clockwise so the angles are exterior (red arcs).\n∠A = 80° + 180° + 40° = 300°\n∠B = 50° + 90° + 70° = 210°\n∠C = 20° + 90° + 210° = 320°\nAt D: 360° − 280° = 80°;  ∠D = 280° − 30° = 250°" },
            { t: "Method 2 (alternatively, p.15) — ∠A", w: "∠A = FB of AB − BB of DA\n= 40° − (280° − 180°) + 360°\n= 300°" },
            { t: "∠B", w: "∠B = FB of BC − BB of AB\n= 70° − (40° + 180°) + 360°\n∠B = 210°" },
            { t: "∠C", w: "∠C = FB of CD − BB of BC\n= 210° − (70° + 180°) + 360°\n= 320°" },
            { t: "∠D", w: "∠D = FB of DA − BB of CD\n= 280° − (210° − 180°) = 250°" },
            { t: "Check the sum (n = 4)", w: "Σ = (2n + 4) × 90° = (2 × 4 + 4) × 90° = 1080°\n∠A + ∠B + ∠C + ∠D = 1080°" },
          ],
          ans: "∠A = 300°, ∠B = 210°, ∠C = 320°, ∠D = 250°; sum = 1080° = (2n + 4) × 90°  (p.14–15)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Station B par khade ho jao. Peeche wali line (BA) ki direction = BB of AB; aage wali line (BC) ki direction = FB of BC. Dono hi North se clockwise naapi gayi hain, to unka farak hi B par clockwise angle hai — yahi formula hai. Negative aaye to 360° jodo, 360° se zyada aaye to 360° ghatao." },
        { k: "p", t: "Clockwise chalne wale traverse mein 'clockwise angle' bahar ki taraf padta hai (exterior), isliye sum (2n + 4) × 90° — n = 4 ke liye 1080°. Anticlockwise traverse mein woh andar padta hai (interior), sum (2n − 4) × 90° — n = 4 ke liye 360°. Example 4.3 (section 4.4) mein bhi isi tarah angle-sum check lagaya gaya hai." },
        { k: "trap", t: "Formula ulta mat lagao: <b>FB of next − BB of previous</b>, na ki 'FB of previous − FB of next'. Aur 270°15′ jaisa answer dekh kar ghabrao mat — included angle notes ki definition se clockwise naapa jaata hai, isliye 180° se bada bhi ho sakta hai." },
      ],
    },

    /* ---------------------------------------------------------- bearings from angles */
    {
      n: "", title: "Class notes — Bearings from included angles (closed and open traverse)", hi: "अंतर्गत कोणों से दिशाकोण",
      blocks: [
        { k: "h", t: "📘 Notes — p.15–18" },
        { k: "eq", expr: "FB of next line = ∠ included + BB of previous line  (subtract 360° if the result exceeds 360°)", where: [] },
        { k: "eg",
          title: "Notes example — Bearings of all lines from included angles",
          given: "Following included angles were observed: ∠ABC = 89°45′, ∠BCD = 125°22′, ∠CDE = 135°34′. Calculate bearings of all lines if bearing of AB = 150°30′.",
          steps: [
            { t: "∠B", w: "∠B = FB of BC − BB of AB\n89°45′ = FB of BC − (150°30′ + 180°)\nFB of BC = 89°45′ + (150°30′ + 180°) − 360°\nFB of BC = 60°15′" },
            { t: "∠C", w: "∠C = FB of CD − BB of BC\n125°22′ = FB of CD − (60°15′ + 180°)\nFB of CD = 125°22′ + (60°15′ + 180°) − 360°\nFB of CD = 5°37′" },
            { t: "∠D", w: "∠D = FB of DE − BB of CD\n135°34′ = FB of DE − 185°37′\nFB of DE = 135° + 185°37′ = 321°11′  (as written)" },
          ],
          ans: "FB of AB = 150°30′, BC = 60°15′, CD = 5°37′, DE = 321°11′  (p.15–16)",
        },
        { k: "note", t: "<b>Check:</b> all three bearings are correct. In the last line the notes write \"135° + 185°37′\", which would give 320°37′; the 321°11′ answer comes from the full angle, 135°34′ + 185°37′ = 321°11′. (p.16)" },
        { k: "p", t: "<b>Q (notes, p.16):</b> Following bearings were observed; compute included angles for closed traverse ABCDA.<br>AB = 140°30′ · BC = 80°30′ · CD = 340° · DE = 290°30′ · EA = 230°30′<br><i>The notes give the question only — no solution is written.</i> (p.16)" },
        { k: "note", t: "<b>Check (worked here, not in the notes):</b> the table has five lines, so the traverse is really ABCDEA (n = 5). Using ∠ = FB of next line − BB of previous line:<br>∠A = 140°30′ − (230°30′ − 180°) = 90°00′<br>∠B = 80°30′ − (140°30′ + 180°) + 360° = 120°00′<br>∠C = 340° − (80°30′ + 180°) = 79°30′<br>∠D = 290°30′ − (340° − 180°) = 130°30′<br>∠E = 230°30′ − (290°30′ − 180°) = 120°00′<br>Sum = 540° = (2 × 5 − 4) × 90°, so these are interior angles (the traverse runs anticlockwise)." },
        { k: "eg",
          title: "Notes example — Open traverse: bearing of the last line",
          given: "The following angles are observed in clockwise direction in an open traverse: ∠ABC = 124°15′, ∠BCD = 156°30′, ∠CDE = 102°, ∠DEF = 95°15′, ∠EFG = 215°45′. The magnetic bearing of line AB = 241°30′. What would be the bearing of FG?",
          steps: [
            { t: "∠B", w: "∠B = FB of BC − BB of AB\n124°15′ = FB of BC − (241°30′ − 180°)\nFB of BC = 124°15′ + (241°30′ − 180°)\nFB of BC = 185°45′" },
            { t: "∠C", w: "∠C = FB of CD − BB of BC\n156°30′ = FB of CD − 5°45′\nFB of CD = 162°15′" },
            { t: "∠D", w: "∠D = FB of DE − BB of CD\n102° = FB of DE − (162°15′ + 180°)\nFB of DE = 84°15′" },
            { t: "∠E", w: "∠E = FB of EF − BB of DE\n95°15′ = FB of EF − (84°15′ + 180°)\nFB of EF = 359°30′" },
            { t: "∠F", w: "∠F = FB of FG − BB of EF\n215°45′ = FB of FG − 179°30′\nFB of FG = 35°15′" },
          ],
          ans: "Bearing of FG = 35°15′  (p.17–18)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Yeh pichhle topic ka ulta hai. Pehli line ka bearing pata hai; har station par included angle pata hai. To aage wali line ka FB = angle + peeche wali line ka BB. Phir naye line ka BB nikaalo (± 180°) aur agle station par wahi step repeat karo — ek chain ki tarah poore traverse mein bearing 'carry forward' hota hai." },
        { k: "trap", t: "Har step ke baad answer ko 0°–360° mein laana mat bhoolo. Jaise ∠D wale step mein 102° + 342°15′ = 444°15′ aata hai; 360° ghatao to 84°15′. Isi tarah BB nikalte waqt ± 180° ka sahi sign lagao — 241°30′ ka BB 61°30′ hai (180° ghatana), 421°30′ nahi." },
        { k: "real", t: "Open traverse mein (jaise road alignment) end par koi check nahi hota, isliye har step ka arithmetic doosri baar check karna zaroori hai — ek galti aage ki saari lines mein chali jaati hai." },
      ],
    },

    /* ---------------------------------------------------------- declination */
    {
      n: "", title: "Class notes — Magnetic declination, isogonic and agonic lines", hi: "चुम्बकीय दिक्पात, समदिक्पाती और शून्य-दिक्पाती रेखाएँ",
      blocks: [
        { k: "h", t: "📘 Notes — p.19–23  (Magnetic declination — चुम्बकीय दिक्पात)" },
        { k: "list", items: [
          "Generally the magnetic meridian and true meridian <b>do not coincide</b> with each other. (p.19)",
          "The horizontal angle between TM and MM at the time of observation is called <b>magnetic declination</b> or simply <b>declination</b>. (p.19)",
        ] },
        { k: "p", t: "Figure (p.19): a circle with the vertical diameter TN (top) – TS (bottom) in blue (true meridian), and a red line MN (upper right) – MS (lower left) through the centre, inclined to the right of TN (magnetic meridian). The angle δ between TN and MN near the top is labelled \"Magnetic declination\". (p.19)" },
        { k: "def", term: "Eastward (+ve) declination", t: "If the M.M lies on the <b>east</b> side of the TM, it is called eastward declination or <b>+ve declination</b>. (p.20)" },
        { k: "def", term: "Westward (−ve) declination", t: "If the magnetic meridian lies on the <b>west</b> side of the true meridian, it is called westward declination or <b>−ve declination</b>. (p.20)" },
        { k: "p", t: "Figure (p.20), eastward case: axes TN, TS, W, E; the red magnetic meridian is inclined to the east of TN; a survey line lies in the NE quadrant. δ between TN and MN; θ₁ between MN and the line (magnetic bearing); θ₂ from TN to the line (true bearing).<br>θ₂ = θ₁ + δ &nbsp;→&nbsp; TB = MB + declination &nbsp;→&nbsp; <b>TB &gt; MB</b> ✓ (p.20)" },
        { k: "p", t: "Figure (p.20), westward case: the red magnetic meridian MN is in the NW quadrant (continuing to MS in the SE); the survey line is in the NE quadrant. θ₁ from MN to the line; δ between MN and TN; θ₂ from TN to the line.<br>θ₂ = θ₁ − δ &nbsp;→&nbsp; TB = MB − δ &nbsp;→&nbsp; <b>MB &gt; TB</b> ✓ (p.20)" },
        { k: "eq", expr: "TB = MB ± δ", where: [
          ["+", "eastward declination"],
          ["−", "westward declination"],
        ] },
        { k: "h", t: "Note (p.21)" },
        { k: "list", items: [
          "1) Magnetic declination in the field is determined by establishing the <b>true bearing and magnetic bearing</b> (of the same line). (p.21)",
          "2) Magnetic declination changes from <b>time to time</b> and <b>place to place</b>. (p.21)",
          "3) Variation of magnetic declination is shown by <b>isogonic lines</b>. (p.21)",
        ] },
        { k: "def", term: "Isogonic lines", t: "A line passing through the points of <b>equal declination</b> on the earth's surface at a particular instant of time. (p.21)" },
        { k: "def", term: "Agonic line", t: "A special type of isogonic line on which the declination of all points is <b>zero</b>. Points on an agonic line have <b>equal magnetic bearing and true bearing</b> — i.e. at points lying on the agonic line the magnetic meridian <b>coincides</b> with the true meridian. (p.22)" },
        { k: "eg",
          title: "Notes example 1 — True bearing from magnetic bearing",
          given: "The magnetic bearing of a line is 124°35′. Find its TB if magnetic declination is 10°10′ West.",
          steps: [
            { t: "West declination → subtract", w: "TB = MB − δ = 124°35′ − 10°10′ = 114°25′" },
          ],
          ans: "TB = 114°25′  (p.22)",
        },
        { k: "eg",
          title: "Notes example 2 — Present magnetic bearing from an old record",
          given: "The MB of a line in Jaipur was found to be N60°30′E in year 1990 when declination was 5°10′ west. Find its present MB when declination is 4°25′ East.",
          steps: [
            { t: "True bearing (1990, west declination)", w: "TB = MB ± δ\n= 60°30′ − 5°10′ = 55°20′" },
            { t: "Present MB (east declination)", w: "TB = MB ± δ\n55°20′ = MB + 4°25′\nMB = 50°55′" },
          ],
          ans: "Present MB = 50°55′ (i.e. N 50°55′ E)  (p.22–23)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Formula yaad karne ka trick: <b>true bearing hamesha true north se naapa jaata hai</b>. Agar magnetic north, true north ke east mein hai (+ve), to compass ka angle chhota padta hai, isliye TB = MB + δ. West mein hai (−ve) to compass ka angle bada padta hai, TB = MB − δ. Sketch banao — sign khud dikh jayega." },
        { k: "p", t: "Purane record wale sawaal (example 2) ka raasta hamesha ek hi: pehle purane MB aur purane δ se <b>TB</b> nikaalo (TB kabhi nahi badalta), phir naye δ se naya MB. Section 4.3 ka Example 4.2 bhi isi logic par hai." },
        { k: "trap", t: "QB mein diya MB (jaise N60°30′E) seedha ± δ karne se pehle socho ki line kaunse quadrant mein hai. NE quadrant mein QB = WCB hai, isliye yahan seedha chal gaya; SW/NW quadrant mein pehle WCB mein convert karo (agla section dekho)." },
        { k: "real", t: "Survey of India ke maps par declination diagram aur isogonic lines di hoti hain — purane revenue maps ke magnetic bearings ko aaj ke compass se dobara lagane se pehle unhe isi tarah correct kiya jaata hai." },
      ],
    },

    /* ---------------------------------------------------------- variations */
    {
      n: "", title: "Class notes — Variations of magnetic declination", hi: "चुम्बकीय दिक्पात में विचरण",
      blocks: [
        { k: "h", t: "📘 Notes — p.23–25" },
        { k: "cmp", t: "Variation of magnetic declination (p.23)", cols: ["Hindi"], rows: [
          ["1) Secular variation", "चिरकालिक विचरण"],
          ["2) Annual variation", "वार्षिक विचरण"],
          ["3) Diurnal variation", "दैनिक विचरण"],
          ["4) Irregular variation", "आकस्मिक विचरण"],
        ] },
        { k: "def", term: "1) Secular variation", t: "It is a <b>long-time</b> variation.<br>Eg — over a period of approx <b>150 yr</b> there is a gradual shift in the earth's magnetic field in one direction; thereafter the declination shifts in the opposite direction for about the same period; hence the cycle is complete in about <b>300 yrs</b>.<br>The variation follows approximately a <b>sine curve</b>.<br>Still there is <b>no reliable method</b> for the prediction of secular variation. Annual rate of secular variation is generally <b>5–10 min</b>. (p.23–24)" },
        { k: "def", term: "2) Annual variation", t: "Variation in magnetic declination over the period of <b>1 yr</b>. It is caused by the <b>revolution of the earth around the sun</b>. Generally it varies between <b>1–2 min</b>. (p.24)" },
        { k: "def", term: "3) Diurnal variation", t: "Variation in declination over a period of <b>1 day</b>. It is caused by the <b>rotation of the earth about its axis</b>. It is observed that —<br>a) It is <b>greater at poles</b> and lesser at equator.<br>b) It is <b>more in summer</b> than winter.<br>c) It is <b>more in day</b> than night.<br>d) It changes from year to year. (p.24)" },
        { k: "def", term: "4) Irregular variation", t: "It occurs due to <b>earthquakes, volcanic eruptions, magnetic storms</b>, depending upon the magnitude of disturbance. It may be of the order of <b>2°</b> also. (p.25)" },
        { k: "note", t: "Section 4.3 quotes other textbook figures for these variations (secular cycle ~250–300 years, annual ~1′, irregular a degree or more). The notes give a ~300-year cycle, annual 1–2 min, a secular rate of 5–10 min per year and irregular up to ~2°. Use the notes' values for this course's exams. (p.23–25)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Charon variations ko time-scale se yaad karo: <b>secular</b> — sadiyon wala (lagbhag 300 saal ka cycle, sine curve jaisa); <b>annual</b> — saal bhar (earth sun ke chakkar lagati hai); <b>diurnal</b> — din bhar (earth apni axis par ghoomti hai); <b>irregular</b> — achanak (earthquake, volcano, magnetic storm). Pehle teen periodic hain, chautha bilkul unpredictable." },
        { k: "trap", t: "Annual variation ka cause <b>revolution</b> (sun ke around) hai aur diurnal ka <b>rotation</b> (apni axis par) — MCQ mein dono ko interchange karke poocha jaata hai. Diurnal variation poles par zyada, equator par kam; summer aur din mein zyada." },
        { k: "real", t: "Diurnal variation din mein zyada hoti hai, isliye precise compass work ek hi time-window mein karna better hai; magnetic storm (irregular variation) ke din compass work rok dena chahiye." },
      ],
    },

    /* ---------------------------------------------------------- declination numericals */
    {
      n: "", title: "Class notes — Declination numericals", hi: "दिक्पात — संख्यात्मक प्रश्न",
      blocks: [
        { k: "h", t: "📘 Notes — p.25–27" },
        { k: "eg",
          title: "Notes example — Magnetic bearing after 108 years of annual change",
          given: "If a line AB had magnetic bearing 44°30′ in 1910 when the declination was 4°30′ West, determine MB of same line in 2018 if the annual declination change is observed as 6 min East.",
          steps: [
            { t: "Data", w: "1910 → MB = 44°30′\nδ = 4°30′ W\nannual declination change = 6′ (East)" },
            { t: "Total eastward change up to 2018 (108 years)", w: "= (6 × 108) / 60\n= 10°48′" },
            { t: "Net eastward declination in 2018", w: "= 10°48′ − 4°30′\n= 6°18′ (East)" },
            { t: "True bearing (1910)", w: "TB = 44°30′ − 4°30′ = 40′  (as written; read 40°)" },
            { t: "MB in 2018", w: "TB = MB + δ\n40° = MB + 6°18′\nMB = 33°42′" },
          ],
          ans: "MB in 2018 = 33°42′  (p.25)",
        },
        { k: "note", t: "<b>Check:</b> the answer is correct. One unit slip in the working: 44°30′ − 4°30′ = <b>40°</b>, not 40′ as written; the next line correctly uses 40°. (p.25)" },
        { k: "eg",
          title: "Notes example — TB of a line given in QB, east and west declination",
          given: "The MB of a line AB is S 38°30′ W. Determine TB if magnetic declination is (i) 4°30′ W (ii) 3°30′ E.",
          steps: [
            { t: "Convert MB to WCB (SW quadrant)", w: "S 38°30′ W = 180° + 38°30′ = 218°30′  (sketch: clockwise arc from north to the SW arm = 218°30′; angle from south = 38°30′)" },
            { t: "(i) 4°30′ W → subtract", w: "TB = MB − 4°30′\n= 218°30′ − 4°30′\nTB = 214°\nQB = 214° − 180° = S 34° W" },
            { t: "(ii) 3°30′ E → add", w: "TB = 218°30′ + 4°30′  (as written)\n= 222°\nS 42° W" },
            { t: "Method 2 — directly in QB (sketches)", w: "(i) West declination: magnetic meridian swings 4°30′ from the south axis on the other side; 38°30′ − 4°30′ → S 34° W\n(ii) East declination: 38°30′ + 03°30′ → S 42° W" },
          ],
          ans: "(i) TB = 214° = S 34° W   (ii) TB = 222° = S 42° W  (p.26)",
        },
        { k: "note", t: "<b>Check:</b> in (ii) the notes write \"218°30′ + 4°30′ = 222°\". With the given declination of 3°30′ E, the working should be 218°30′ + 3°30′ = <b>222°</b> (S 42° W), so the answer is right and the \"4°30′\" is a slip (218°30′ + 4°30′ would be 223°). Method 2 on the same page correctly uses 38°30′ + 3°30′; its sketch still labels the small angle 4°30′. (p.26)" },
        { k: "eg",
          title: "Notes example — Declination from a lamp post, then TB of a line",
          given: "The true bearing of a lamp post P as observed from station A was 355°30′; the magnetic bearing of the same post was found to be 3°30′. With the same compass the magnetic bearing of a line AB was found to be 130°. Determine TB of line AB.",
          steps: [
            { t: "Data", w: "TB = 355°30′\nMB = 3°30′" },
            { t: "Declination (sketch: TB of P is 4°30′ west of north, MB is 3°30′ east of the magnetic north)", w: "δ = 4°30′ + 3°30′ = 8° W  (352° struck out in the notes → 8° W)" },
            { t: "TB of AB", w: "MB of AB = 130°\nTB = 130° − 8° = 122°" },
          ],
          ans: "TB of AB = 122°  (p.27)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Quadrant wale MB ke saath sabse safe raasta: pehle WCB banao (S 38°30′ W = 218°30′), phir ± δ karo, phir wapas QB mein le aao. Method 2 wahi kaam seedha sketch par karta hai — West declination SW line ko south ke paas le aata hai (angle ghatta hai), East declination door le jaata hai (angle badhta hai)." },
        { k: "p", t: "Lamp post wale sawaal mein declination diya nahi gaya — usse ek hi object ke TB aur MB se nikaala gaya hai (p.21 ka note: 'declination is determined by establishing TB and MB'). 355°30′ aur 3°30′ ke beech north line cross hoti hai, isliye seedha subtract karne par 352° aata hai — sahi farak 4°30′ + 3°30′ = 8° hai." },
        { k: "trap", t: "Do bearings ke beech North (0°/360°) cross ho raha ho to seedha subtract mat karo. 355°30′ − 3°30′ = 352° declination nahi hai; sketch banao ya 3°30′ ko 363°30′ likho: TB − MB = 355°30′ − 363°30′ = −8° → 8° W." },
      ],
    },

    /* ---------------------------------------------------------- sun & dip */
    {
      n: "", title: "Class notes — Position of the sun at noon, and dip", hi: "दोपहर में सूर्य की स्थिति और नमन (डिप)",
      blocks: [
        { k: "h", t: "📘 Notes — p.28–29" },
        { k: "h", t: "Position of sun (p.28)" },
        { k: "p", t: "Figure (p.28): a cross of two lines; top end labelled 12AM, bottom end 12PM, left end 6PM, right end 6AM. (p.28)" },
        { k: "list", items: [
          "At noon (12 बजे दोपहर) the sun is exactly over the <b>geographical meridian (true meridian)</b> of the place. (p.28)",
          "→ The true bearing of the line joining the sun and the place is <b>360° or 0°</b> if the sun is to the <b>north</b> of the place. (p.28)",
          "→ And it is <b>180°</b> if the sun is to the <b>south</b> of the place. (p.28)",
        ] },
        { k: "eg",
          title: "Notes example — Declination from the sun's bearing at noon",
          given: "a) If MB of sun at noon is 185°, determine magnetic declination. b) What would be the declination if MB of sun at noon is 355°?",
          steps: [
            { t: "a) Sun to the south at noon", w: "TB = 180°, MB = 185°\nδ = TB − MB = −5°\n↳ 5° W" },
            { t: "b) Sun to the north at noon", w: "TB = 360°, MB = 355°\nδ = +5°\n↳ 5° E" },
          ],
          ans: "a) 5° W   b) 5° E  (p.28)",
        },
        { k: "h", t: "Magnetic field of earth (p.29)" },
        { k: "p", t: "Figure (p.29), left: a circle (the earth) with a vertical diameter from T.N (top) to T.S (bottom) and an inclined red line from M.S (lower left) to M.N (upper right); a red curved field line loops from M.S around the outside of the right side of the circle up to M.N, with arrows. Right: a bar magnet with S at top and N at bottom; a closed field-line loop from N round the right side up to S with an upward arrow; labelled \"dip\". (p.29)" },
        { k: "list", items: [
          "The earth acts as a <b>powerful magnet</b> with its magnetic lines of force running from the <b>south to the north</b> end. (p.29)",
          "A magnetic needle, when freely suspended at its centre of gravity, is influenced by the earth's magnetic field and tries to attain the <b>North–South direction</b>. (p.29)",
        ] },
        { k: "def", term: "Dip", t: "The <b>vertical angle</b> made by the magnetic needle with the earth's surface is called dip.<br>At <b>poles dip = 90°</b> and at <b>equator dip = 0°</b>; between pole and equator, dip = 0° – 90°. (p.29)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Dopahar 12 baje sooraj theek true meridian par hota hai — yeh true north nikaalne ka sabse simple astronomical tareeka hai. India (northern hemisphere, tropic ke upar wale hisse) mein dopahar ka sooraj zyaadatar south mein dikhta hai, to uska TB = 180°. Compass jo MB padhe, TB − MB se declination mil jaata hai; sign se E/W." },
        { k: "p", t: "Declination <b>horizontal</b> plane ka angle hai (TM aur MM ke beech); dip <b>vertical</b> plane ka angle hai (needle aur horizontal ke beech). Field lines poles par seedhi neeche jaati hain (dip 90°) aur equator par horizontal hoti hain (dip 0°) — section 4.3 ka note batata hai ki needle par counterweight isi ko balance karne ke liye hota hai." },
        { k: "trap", t: "Declination aur dip ko mix mat karo: declination = horizontal angle between true and magnetic meridian; dip = vertical angle of the needle with the horizontal. Dip poles par 90°, equator par 0° — ulta yaad mat karna." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "", title: "Notes revision — Compass surveying: traverse, bearings, declination (p.2–29)", hi: "पुनरावृत्ति — कम्पास सर्वेक्षण (p.2–29)",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "✅ Traverse = series of connecting lines; closed (ends at the start or another known station) / open (end location unknown — canal, railway, road). (p.2–3)",
          "✅ Traverse types by instrument: compass, plane table, theodolite, stadia (tacheometric). Compass traverse: angles by magnetic compass, distances by chain/tape. (p.2–3)",
          "✅ Meridians: true (astronomical, fixed), magnetic (needle, changes with time), grid (true meridian through the central place of a country), arbitrary (small traverses). (p.4–6)",
          "✅ Bearing = horizontal angle with the meridian; true bearing preferred for important work as it does not change. (p.6–7)",
          "✅ WCB: clockwise from North, 0°–360°, azimuth, prismatic compass, least count 30′. QB: acute angle from N or S end, &lt; 90°, surveyor's compass. RB: WCB reduced to &lt; 90°. (p.7–10)",
          "✅ WCB → QB: 0–90° N(WCB)E · 90–180° S(180° − WCB)E · 180–270° S(WCB − 180°)W · 270–360° N(360° − WCB)W. (p.10)",
          "✅ BB = FB ± 180° (+ if FB &lt; 180°, − if FB &gt; 180°); FB of AB = BB of BA; in QB swap N↔S and E↔W, keep the angle. (p.11–12)",
          "✅ Included angle = FB of next line − BB of previous line, always clockwise. (p.13)",
          "✅ Clockwise traverse → exterior angles, Σ = (2n + 4) × 90°; anticlockwise → interior angles, Σ = (2n − 4) × 90°. (p.13)",
          "✅ Numericals: ∠ABC = 270°15′ (p.14); ABCD angles 300°, 210°, 320°, 250°, sum 1080° (p.14–15); bearings 60°15′, 5°37′, 321°11′ (p.16); open traverse FG = 35°15′ (p.18).",
          "✅ Declination = horizontal angle between TM and MM; East = +ve (TB &gt; MB), West = −ve (MB &gt; TB); <b>TB = MB ± δ</b>. (p.19–20)",
          "✅ Declination changes with time and place; determined in the field from TB and MB of the same line. (p.21)",
          "✅ Isogonic line: points of equal declination; agonic line: zero declination, MM coincides with TM. (p.21–22)",
          "✅ Secular (~150 yr each way, ~300 yr cycle, sine curve, 5–10 min/yr, no reliable prediction); annual (1–2 min, revolution of earth); diurnal (rotation; more at poles, in summer, by day; changes year to year); irregular (earthquake, volcano, magnetic storm, up to ~2°). (p.23–25)",
          "✅ Declination numericals: 114°25′ (p.22); 50°55′ (p.23); 33°42′ (p.25); S 34° W and S 42° W (p.26); 122° (p.27).",
          "✅ Sun at noon is on the true meridian: TB = 0°/360° if sun is north, 180° if south; MB 185° → 5° W, MB 355° → 5° E. (p.28)",
          "✅ Earth's lines of force run south → north; dip = vertical angle of needle with the earth's surface: 90° at poles, 0° at equator. (p.29)",
          "✅ Notes slips to remember: 203°18′ → S 23°18′ W (notes S 23°58′ W, p.11); p.26 (ii) uses 3°30′, not 4°30′ (answer 222° is right).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
