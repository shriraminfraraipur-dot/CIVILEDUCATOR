/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: Structural Analysis, Chapters 10–12
   Matrix methods · Plastic analysis · Structural dynamics
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "sa"; });
  if (!hb) return;

  hb.chapters.push(

    /* =========================================================== CH 10 */
    {
      id: "sa-10",
      n: 10,
      title: "Matrix Methods",
      hi: "मैट्रिक्स विधियाँ",
      blurb: "The same two families of method, written as matrices — which is what makes them programmable, and what every analysis package you will ever use is actually doing.",
      mins: 30,
      sections: [
        {
          n: "10.1", title: "Why matrices", hi: "मैट्रिक्स क्यों",
          blocks: [
            { k: "p", t: "Nothing new happens in this chapter. The force method of Chapter 6 and the displacement methods of Chapters 7 and 8 are already complete; matrices are a way of writing them that a computer can follow and a person can scale." },
            { k: "p", t: "The reason it matters is that hand methods stop somewhere around a two-storey frame (§7.6). Real buildings are larger, and the equations do not become harder — only more numerous. A matrix formulation turns \"more numerous\" into a mechanical, repeatable assembly step, and that is the whole gain." },
            { k: "list", items: [
              "<strong>Flexibility (force) method</strong> in matrix form: unknowns are redundant forces, and the matrix is the flexibility matrix of §6.6.",
              "<strong>Stiffness (displacement) method</strong> in matrix form: unknowns are joint displacements. This is the one used universally in software.",
            ]},
            { k: "note", t: "The stiffness method won because it can be assembled without any choices. A flexibility formulation needs somebody to pick the redundants (§6.3), and there is no automatic rule for choosing well. Stiffness needs no choice at all — number the degrees of freedom and assemble." },
          ],
        },
        {
          n: "10.2", title: "The member stiffness matrix", hi: "सदस्य कठोरता मैट्रिक्स",
          blocks: [
            { k: "def", term: "Stiffness coefficient k(i,j)", t: "The force required at degree of freedom i when degree of freedom j is given unit displacement and every other degree of freedom is held at zero." },
            { k: "dia", id: "hb-sa-stiff-col" },
            { k: "p", t: "Read that definition and the matrix builds itself. Give the near end unit rotation with everything else held: the moment needed there is 4EI/L, the moment that appears at the far end is 2EI/L, and the shears needed to hold the member in that shape are 6EI/L² at each end. Those four numbers are one column." },
            { k: "eq", expr: "Rotational part of a beam member:    k = [ 4EI/L   2EI/L ;   2EI/L   4EI/L ]", where: [] },
            { k: "p", t: "Those are the same 4EI/L and 2EI/L that appeared in the slope-deflection equation of §7.1 and as the stiffness and carry-over of §8.2. Three chapters, one pair of numbers — the matrix is simply the tidiest place to keep them." },
            { k: "note", t: "The full plane-frame member matrix is 6 × 6, because each end has an axial displacement, a transverse displacement and a rotation. The axial terms are AE/L and the rest are the bending terms above. Nothing in the idea changes; the bookkeeping grows." },
          ],
        },
        {
          n: "10.3", title: "Assembling the global matrix", hi: "ग्लोबल मैट्रिक्स बनाना",
          blocks: [
            { k: "steps", items: [
              "Number every degree of freedom in the structure.",
              "Write each member's stiffness matrix in the global axis directions.",
              "Add each member's coefficients into the rows and columns of the degrees of freedom it connects.",
              "Where two members share a joint, their coefficients <strong>add</strong> — both resist that joint's movement.",
            ]},
            { k: "dia", id: "hb-sa-matrix-dof" },
            { k: "eq", expr: "[K] {D} = {F}", where: [
              ["[K]", "Global stiffness matrix"],
              ["{D}", "Vector of unknown joint displacements"],
              ["{F}", "Vector of joint loads, including the equivalent joint loads from member loads"],
            ]},
            { k: "p", t: "Loads applied along a member rather than at a joint are handled exactly as in Chapter 7 — convert them to fixed end moments, apply the reversed values as equivalent joint loads, solve, and add the fixed end moments back at the end. Nothing about that is a matrix idea; it is the slope-deflection FEM term wearing different clothes." },
          ],
        },
        {
          n: "10.4", title: "Boundary conditions and solving", hi: "सीमा शर्तें और हल",
          blocks: [
            { k: "p", t: "As assembled, [K] is singular — the structure is still floating, so it has rigid body movements and no unique solution. Applying the supports fixes that: strike out the rows and columns of every restrained degree of freedom, and what remains is invertible." },
            { k: "steps", items: [
              "Assemble [K] for the whole structure, supports included.",
              "Delete the rows and columns of the restrained degrees of freedom.",
              "Solve the reduced system for the free displacements.",
              "Back-substitute into each member's own matrix to get its end forces.",
              "Recover the support reactions from the deleted rows.",
            ]},
            { k: "trap", t: "If the reduced matrix still refuses to invert, the structure is a mechanism — §1.10 all over again, discovered numerically instead of by sketch. That is exactly the error a package reports as \"structure unstable\" or \"zero pivot at node n\", and the fix is a missing restraint or a missing brace, never a numerical setting." },
          ],
        },
        {
          n: "10.5", title: "Worked example — the same beam a fourth time", hi: "हल किया उदाहरण — वही बीम, चौथी बार",
          blocks: [
            { k: "eg", title: "Example 10.1 — continuous beam by the stiffness method", given: "Continuous beam ABC, spans AB = BC = 6 m, UDL 20 kN/m, A and C simply supported, B continuous, EI constant. Take the three joint rotations as the degrees of freedom.", steps: [
              { t: "Degrees of freedom and member matrices", w: "Vertical movement is prevented at all three supports, so the only unknowns are the rotations θA, θB, θC.\n\nFor each 6 m member, with a = EI/6:\n  4EI/L = 4EI/6 = 4a      2EI/L = 2a" },
              { t: "Fixed end moments as equivalent joint loads", w: "FEM = wL²/12 = 60 kNm on each span.\n  member AB:  {−60, +60}\n  member BC:  {−60, +60}\n\nThe joint load vector is the NEGATIVE of the sum of fixed end moments at each joint:\n  at A:  −(−60) = +60\n  at B:  −(+60 − 60) = 0\n  at C:  −(+60) = −60" },
              { t: "Assemble and write the equations", w: "Joint A:   4a θA + 2a θB              = +60\nJoint B:   2a θA + 8a θB + 2a θC       =  0\nJoint C:            2a θB + 4a θC      = −60\n\n(The 8a at joint B is 4a from member AB plus 4a from member BC — the two members share that degree of freedom, so their coefficients add.)" },
              { t: "Solve", w: "From the first equation:  θA = (60 − 2a θB) / 4a\nFrom the third:           θC = (−60 − 2a θB) / 4a\n\nSubstitute both into the second:\n  (60 − 2aθB)/2 + 8aθB + (−60 − 2aθB)/2 = 0\n  30 − aθB + 8aθB − 30 − aθB = 0\n  6a θB = 0\n  θB = 0\n\nThen  a θA = 15   and  a θC = −15,\ni.e.  θA = 90/EI  and  θC = −90/EI." },
              { t: "Back-substitute for the member end moments", w: "M(BA) = 2a θA + 4a θB + FEM(BA)\n      = 2(15) + 0 + 60\n      = 30 + 60\n      = +90 kNm" },
              { t: "Four methods, one answer", w: "Force method (6.1):          90 kNm\nSlope-deflection (7.1):      90 kNm\nMoment distribution (8.1):   90 kNm\nStiffness matrix (this):     90 kNm  ✓" },
            ], ans: "M at B = 90 kNm hogging — the same beam solved four different ways, agreeing every time" },
            { k: "note", t: "That agreement is the point of doing it four times. These are not four theories competing; they are four routes through one theory, and any of them can check the others. When a package gives you a number you did not expect, one of these — usually moment distribution — is how you find out whether to believe it." },
          ],
        },
        {
          n: "10.6", title: "What software is actually doing", hi: "सॉफ़्टवेयर असल में क्या करता है",
          blocks: [
            { k: "p", t: "Every general analysis package follows §10.3 and §10.4, for every member, simultaneously. Understanding that changes how you read its output." },
            { k: "list", items: [
              "<strong>\"Structure unstable\"</strong> — a mechanism. Check restraints and bracing, not the software.",
              "<strong>Absurdly large displacements</strong> — usually a member whose properties were entered in the wrong units, or a joint left unconnected.",
              "<strong>Moments that do not balance at a joint</strong> — check whether a release was applied by accident. A modelled hinge carries no moment.",
              "<strong>Results that look nothing like a hand estimate</strong> — do the hand estimate anyway. A continuous beam by moment distribution takes ten minutes and has settled many arguments.",
            ]},
            { k: "p", t: "The habit worth forming is to predict before you run. Sketch the deflected shape (§1.13), estimate the support moment from a standard coefficient, then compare. Software is very good at solving the model you gave it, and completely uninterested in whether that was the model you meant." },
          ],
        },
      ],
    },

    /* =========================================================== CH 11 */
    {
      id: "sa-11",
      n: 11,
      title: "Plastic Analysis",
      hi: "प्लास्टिक विश्लेषण",
      blurb: "What happens after first yield: the plastic moment, the shape factor, collapse mechanisms, and why a steel structure carries considerably more than elastic design admits.",
      mins: 28,
      sections: [
        {
          n: "11.1", title: "Why elastic design leaves strength on the table", hi: "इलास्टिक डिज़ाइन क्या छोड़ देता है",
          blocks: [
            { k: "p", t: "Elastic design stops at the moment the most stressed fibre in the most stressed section reaches yield. At that instant the rest of that section is still elastic, and every other section in the structure is still well below yield. The structure is nowhere near collapse." },
            { k: "p", t: "Plastic analysis asks the other question: what load actually causes collapse? For ductile materials — structural steel above all — the answer can be substantially higher, and designing to it is both more economical and more honest about how the structure will really fail." },
            { k: "note", t: "This depends entirely on ductility. Steel yields and keeps deforming at roughly constant stress, which is what makes a plastic hinge possible. Plain concrete does not — it crushes. Reinforced concrete can behave plastically if it is detailed so the steel yields before the concrete crushes, and making sure of that is exactly what the under-reinforced requirement of IS 456 and the ductile detailing of IS 13920 are for." },
          ],
        },
        {
          n: "11.2", title: "Plastic moment and shape factor", hi: "प्लास्टिक आघूर्ण और आकार गुणांक",
          blocks: [
            { k: "dia", id: "hb-sa-plastic-stress" },
            { k: "p", t: "As the moment grows past first yield, the yielded zone spreads inward from both faces while an elastic core shrinks in the middle. When the core vanishes, the whole section is at yield — two rectangular stress blocks, one in tension and one in compression. That is the plastic moment, and the section can rotate freely at constant moment from then on." },
            { k: "eq", expr: "Me = fy × Ze        Mp = fy × Zp        Shape factor  S = Zp / Ze = Mp / Me", where: [
              ["Ze", "Elastic section modulus, I / y(max)"],
              ["Zp", "Plastic section modulus — first moment of the two equal areas about the equal-area axis"],
              ["fy", "Yield stress"],
            ]},
            { k: "eg", title: "Example 11.1 — shape factor of a rectangle", given: "A rectangular section, breadth b, depth d, of a material with yield stress fy.", steps: [
              { t: "Elastic modulus", w: "I = b d³ / 12,  y(max) = d/2\n\nZe = I / y(max) = (b d³ / 12) / (d/2) = b d² / 6" },
              { t: "Plastic modulus", w: "The equal-area axis is the mid-depth. Each half has area bd/2, and its centroid is d/4 from that axis.\n\nZp = 2 × (bd/2) × (d/4) = b d² / 4" },
              { t: "Shape factor", w: "S = Zp / Ze = (b d²/4) / (b d²/6) = 6/4 = 1.5" },
            ], ans: "S = 1.5 — a rectangular section carries 50% more moment at full plasticity than at first yield" },
            { k: "list", items: [
              "Rectangle — <strong>1.5</strong>",
              "Solid circle — <strong>1.70</strong> (16/3π)",
              "I-section about the strong axis — <strong>1.12 to 1.15</strong>",
              "Diamond — <strong>2.0</strong>",
            ]},
            { k: "p", t: "The I-section's low shape factor is not a weakness — it is the sign of an efficient section. Most of its material is already in the flanges at near-maximum stress when it first yields, so there is little idle material left for plasticity to recruit. A rectangle has a great deal of idle material near the neutral axis, which is why its shape factor is high and its efficiency low." },
          ],
        },
        {
          n: "11.3", title: "The plastic hinge", hi: "प्लास्टिक हिंज",
          blocks: [
            { k: "def", term: "Plastic hinge", t: "A section that has reached its plastic moment and can now rotate at essentially constant moment — behaving like a real hinge that resists a fixed moment Mp." },
            { k: "p", t: "It is not a real hinge and not a point. Yielding spreads over a finite length of the member, and the idealisation as a point is an approximation that works well for analysis. What matters is the consequence: once a hinge forms, that section stops attracting any further moment and the extra load has to redistribute elsewhere." },
            { k: "p", t: "That redistribution is why an indeterminate structure survives well past first yield. A hinge at the first section to yield turns the structure into one that is indeterminate to one degree less — not into a collapsing one. Hinges form one after another, and collapse comes only when enough have formed to make a mechanism." },
            { k: "eq", expr: "Number of hinges for a complete collapse mechanism = Ds + 1", where: [["Ds", "Degree of static indeterminacy of the original structure"]] },
          ],
        },
        {
          n: "11.4", title: "Collapse mechanisms and the work equation", hi: "संकुचन तंत्र और कार्य समीकरण",
          blocks: [
            { k: "dia", id: "hb-sa-mechanism" },
            { k: "steps", items: [
              "Find Ds and therefore the number of hinges needed: Ds + 1.",
              "Identify where hinges can form — at fixed supports, under point loads, at joints, and where the moment is maximum within a span.",
              "Choose a mechanism and give it a virtual rotation θ.",
              "Equate external work (loads × their displacements) to internal work (Σ Mp × hinge rotation).",
              "Solve for the collapse load, then repeat for every possible mechanism and <strong>take the lowest</strong>.",
            ]},
            { k: "eg", title: "Example 11.2 — collapse load of a fixed beam under UDL", given: "A beam of span L, fixed at both ends, carrying a uniformly distributed load w. The section has plastic moment Mp. Find the collapse load.", steps: [
              { t: "How many hinges", w: "A fixed beam has Ds = 2, so collapse needs Ds + 1 = 3 hinges.\nThey form at the two fixed ends and at mid-span, where the moments are largest." },
              { t: "Give the mechanism a virtual rotation", w: "Let each end hinge rotate by θ.\nThe mid-span hinge then rotates by 2θ (the two halves rotate towards each other).\nThe mid-span deflection is δ = (L/2) θ." },
              { t: "Internal work", w: "W(int) = Mp θ  +  Mp (2θ)  +  Mp θ\n       = 4 Mp θ" },
              { t: "External work", w: "The load is uniform and the deflected shape is triangular, so the average deflection is δ/2.\n\nW(ext) = w L × (δ/2)\n       = w L × (L θ / 4)\n       = w L² θ / 4" },
              { t: "Equate and solve", w: "4 Mp θ = w L² θ / 4\n\nθ cancels — it always does, which is why the virtual rotation can be anything.\n\n  Mp = w L² / 16\n  w(collapse) = 16 Mp / L²" },
              { t: "Compare with elastic design", w: "Elastically, the largest moment in a fixed beam is at the supports:\n  M = wL²/12\n\nFirst yield when wL²/12 = Mp  →  w = 12 Mp / L²\n\nReserve = 16/12 = 1.33\n\nThe beam carries a third more load after first yield than elastic design credits it with." },
            ], ans: "w(collapse) = 16 Mp / L², against 12 Mp / L² at first yield — a reserve of 33%" },
            { k: "note", t: "For a propped cantilever under a UDL the corresponding result is w(collapse) = 11.66 Mp / L², with the span hinge at 0.414L from the propped end rather than at mid-span. The hinge position is itself an unknown there, which is why the coefficient is not a round number." },
          ],
        },
        {
          n: "11.5", title: "The three theorems", hi: "तीन प्रमेयें",
          blocks: [
            { k: "list", items: [
              "<strong>Static (lower bound) theorem.</strong> Any load for which a bending moment distribution can be found that satisfies equilibrium and nowhere exceeds Mp is less than or equal to the true collapse load. Guessing here is <em>safe</em>.",
              "<strong>Kinematic (upper bound) theorem.</strong> The load computed from any assumed mechanism is greater than or equal to the true collapse load. Guessing here is <em>unsafe</em>.",
              "<strong>Uniqueness theorem.</strong> When a distribution satisfies equilibrium, the yield condition and the mechanism condition all at once, that load is the true collapse load.",
            ]},
            { k: "trap", t: "This is why §11.4 says to take the <strong>lowest</strong> of all the mechanisms you try. The work equation is an upper-bound calculation: every mechanism you have not thought of could give a lower answer, and the true collapse load is the lowest of them all. Finding one mechanism is not finishing the problem." },
            { k: "p", t: "In practice you check the mechanism you believe governs, and then verify it with the static theorem — draw the bending moment diagram that corresponds to it and confirm that Mp is nowhere exceeded. If it is, the mechanism was wrong and a different one governs." },
          ],
        },
        {
          n: "11.6", title: "Load factor and where codes use this", hi: "लोड फैक्टर और कोड में उपयोग",
          blocks: [
            { k: "eq", expr: "Load factor λ = collapse load / working load", where: [] },
            { k: "p", t: "Plastic design sets the section so that λ is at least the required value — which is what a limit state code does when it factors the loads. IS 800:2007 is a limit state code, and its plastic design provisions rest directly on this chapter." },
            { k: "list", items: [
              "<strong>Section classification</strong> — IS 800 Section 3 sorts sections into plastic, compact, semi-compact and slender. Only a plastic section can actually form a hinge and rotate enough to redistribute; a slender one buckles locally first and never reaches Mp.",
              "<strong>Moment redistribution in concrete</strong> — IS 456 Cl. 22.7 permits limited redistribution in continuous beams for the same underlying reason, with strict limits because concrete's ductility has to be earned by detailing.",
            ]},
            { k: "trap", t: "Plastic analysis assumes the structure is ductile enough to reach the mechanism. If local buckling, lateral-torsional buckling or brittle fracture intervenes first, the collapse load calculated here will never be reached. <strong>The ductility is a requirement of the method, not a bonus</strong> — which is exactly why section classification comes before plastic design, not after." },
          ],
        },
      ],
    },

    /* =========================================================== CH 12 */
    {
      id: "sa-12",
      n: 12,
      title: "Structural Dynamics — Single Degree of Freedom",
      hi: "संरचनात्मक गतिकी — एकल स्वतंत्रता कोटि",
      blurb: "What changes when the load varies with time: natural period, damping, resonance, and the link from all three to the seismic coefficient IS 1893 asks for.",
      mins: 28,
      sections: [
        {
          n: "12.1", title: "What changes when the load moves", hi: "जब भार समय के साथ बदले",
          blocks: [
            { k: "p", t: "Everything so far has been static: the load is applied slowly, the structure deflects, and nothing accelerates. A dynamic load is one applied fast enough that the mass has to be accelerated, and then the inertia force m·ü joins the equilibrium equation as a real force." },
            { k: "list", items: [
              "<strong>Earthquake</strong> — the ground moves and the building's mass resists following it. The dominant dynamic problem in Indian practice.",
              "<strong>Wind</strong> — gusts, and vortex shedding on slender structures like chimneys.",
              "<strong>Machinery</strong> — rotating equipment on a foundation block, at a known and constant frequency.",
              "<strong>Blast and impact</strong> — very short duration, very large magnitude.",
            ]},
            { k: "p", t: "The decisive quantity is the ratio of the loading's frequency to the structure's own. That is why a structure's <strong>natural period</strong> becomes the property that matters most, and why it is the axis of every design spectrum." },
          ],
        },
        {
          n: "12.2", title: "The single degree of freedom model", hi: "एकल स्वतंत्रता कोटि मॉडल",
          blocks: [
            { k: "dia", id: "hb-sa-sdof" },
            { k: "p", t: "One mass, one spring, one dashpot. It looks too crude to be useful and it is not: a water tank on a staging, a single-storey building with a heavy roof, or a machine block on soil all behave very close to this. Even a multi-storey building is analysed as a set of SDOF systems, one per mode." },
            { k: "eq", expr: "m ü + c u̇ + k u = p(t)", where: [
              ["m", "Mass"],
              ["c", "Viscous damping coefficient"],
              ["k", "Lateral stiffness of the supporting structure"],
              ["u", "Displacement; u̇ and ü its velocity and acceleration"],
              ["p(t)", "Applied force, varying with time"],
            ]},
            { k: "p", t: "Three forces resist the applied one: inertia from the mass, damping from whatever dissipates energy, and the elastic restoring force from the stiffness. For an earthquake there is no p(t) at all — the base moves instead, and the effective force is −m·üg, the mass times the ground acceleration. That is the whole reason seismic force is proportional to mass, and why lightening a building lightens its earthquake demand." },
          ],
        },
        {
          n: "12.3", title: "Free vibration — period and frequency", hi: "मुक्त कंपन — आवर्तकाल और आवृत्ति",
          blocks: [
            { k: "p", t: "Push the mass and let go. With no damping it oscillates for ever at one particular frequency, which depends only on the mass and the stiffness — never on how hard you pushed." },
            { k: "eq", expr: "ω = √(k/m)        T = 2π/ω = 2π√(m/k)        f = 1/T", where: [
              ["ω", "Circular natural frequency, rad/s"],
              ["T", "Natural period, seconds — the time for one complete cycle"],
              ["f", "Natural frequency, Hz"],
            ]},
            { k: "eg", title: "Example 12.1 — natural period of a water tank on a staging", given: "An elevated water tank whose full mass, including contained water, is 50 000 kg. The staging has a lateral stiffness of 2000 kN/m. Find the natural period.", steps: [
              { t: "Work in consistent units", w: "m = 50 000 kg\nk = 2000 kN/m = 2 × 10⁶ N/m" },
              { t: "Circular frequency", w: "ω = √(k/m)\n  = √(2 × 10⁶ / 5 × 10⁴)\n  = √40\n  = 6.32 rad/s" },
              { t: "Period and frequency", w: "T = 2π / ω = 6.283 / 6.32 = 0.99 s\nf = 1/T = 1.01 Hz" },
              { t: "What this number is for", w: "T ≈ 1 second is the value you take to the design spectrum of IS 1893 to read the spectral acceleration. It is the single most important dynamic property of the structure." },
            ], ans: "ω = 6.32 rad/s · T = 0.99 s · f = 1.01 Hz" },
            { k: "note", t: "The tank has two design cases, not one: full and empty. Emptying it reduces m and therefore shortens T, which moves the structure to a different point on the spectrum — sometimes to a worse one. Checking only the full tank is a standard omission." },
          ],
        },
        {
          n: "12.4", title: "Damping", hi: "अवमंदन",
          blocks: [
            { k: "p", t: "Real structures do not oscillate for ever. Energy leaks away through internal friction in the material, friction at connections, cracking, and into the soil. All of that is bundled into one viscous coefficient c — not because the physics is viscous, but because a viscous model is linear and fits the observed decay well enough." },
            { k: "eq", expr: "ζ = c / (2√(km))        ω(d) = ω √(1 − ζ²)        δ = ln(u₁/u₂) ≈ 2πζ", where: [
              ["ζ", "Damping ratio, as a fraction of critical"],
              ["ω(d)", "Damped natural frequency"],
              ["δ", "Logarithmic decrement — how damping is measured from a real decay trace"],
            ]},
            { k: "list", items: [
              "Welded steel — about <strong>2%</strong>",
              "Bolted steel — about <strong>5%</strong>",
              "Reinforced concrete — about <strong>5%</strong>, which is the value IS 1893 assumes",
              "Masonry — higher still",
            ]},
            { k: "p", t: "For values this small, ω(d) is barely different from ω — at ζ = 0.05 the difference is about one part in eight hundred. So damping can be ignored when computing the period, and cannot be ignored anywhere near resonance. That contrast is the subject of the next section." },
          ],
        },
        {
          n: "12.5", title: "Forced vibration and resonance", hi: "प्रणोदित कंपन और अनुनाद",
          blocks: [
            { k: "p", t: "Drive the system with a force that oscillates at frequency ω(f) and it responds at that frequency, with an amplitude that depends on how close ω(f) is to the natural frequency." },
            { k: "eq", expr: "DMF = 1 / √[ (1 − β²)² + (2ζβ)² ]        β = ω(force) / ω(natural)", where: [
              ["DMF", "Dynamic magnification factor — the ratio of dynamic amplitude to the static deflection under the same peak force"],
            ]},
            { k: "dia", id: "hb-sa-dmf" },
            { k: "list", items: [
              "<strong>β ≪ 1</strong> (slow load) — DMF ≈ 1. The structure follows the load quasi-statically.",
              "<strong>β ≈ 1</strong> — resonance. DMF = 1/(2ζ), so at 5% damping the response is <strong>ten times</strong> the static value.",
              "<strong>β ≫ 1</strong> (very fast load) — DMF → 0. The mass cannot keep up and barely moves.",
            ]},
            { k: "p", t: "For machine foundations this is a design rule, not a curiosity: keep the operating frequency well away from the natural frequency of the block, and pass through resonance quickly during start-up and shut-down. The usual target is β below about 0.7 or above about 1.4." },
            { k: "trap", t: "Stiffening a structure to fix a vibration problem raises ω, which can move β from above 1 to nearer 1 and make things <strong>worse</strong>. Work out which side of resonance you are on before changing anything — this is one of the few places in structural engineering where more stiffness is the wrong answer." },
          ],
        },
        {
          n: "12.6", title: "From here to IS 1893", hi: "यहाँ से IS 1893 तक",
          blocks: [
            { k: "p", t: "An earthquake is not a single-frequency force, so the DMF curve above cannot be used directly. What is done instead is to compute, for one ground motion, the peak response of a whole family of SDOF systems with different periods, and plot that peak against period. That plot is a response spectrum. Smooth and envelope many such spectra and you have a design spectrum." },
            { k: "p", t: "IS 1893 (Part 1) gives exactly that, as Sa/g against T for three soil types, and the design horizontal seismic coefficient follows from it:" },
            { k: "eq", expr: "Ah = (Z/2) × (I/R) × (Sa/g)", where: [
              ["Z", "Zone factor — the expected ground motion for the region"],
              ["I", "Importance factor"],
              ["R", "Response reduction factor — credit for ductility"],
              ["Sa/g", "Read from the spectrum at the structure's period T"],
            ]},
            { k: "p", t: "Every term in that expression traces back to this chapter. T comes from §12.3. The spectrum shape is the DMF idea generalised. The 5% damping assumption is §12.4. And R is an acknowledgement that the structure will go beyond elastic — which is Chapter 11." },
            { k: "note", t: "The empirical period formulas in IS 1893 — the ones in terms of building height — exist because computing T properly needs a model that does not exist yet at the stage the design force is first needed. They are a starting point, and a dynamic analysis later refines them. This app's topic pages carry those clause references; the physics behind them is here." },
          ],
        },
        {
          n: "12.7", title: "Multi-degree systems, in one paragraph", hi: "बहु-स्वतंत्रता प्रणालियाँ, संक्षेप में",
          blocks: [
            { k: "p", t: "A multi-storey building has one degree of freedom per floor, and therefore that many natural periods and mode shapes. The useful result is that the response can be decomposed into those modes, each of which behaves exactly like the SDOF system of this chapter, and then recombined. So nothing here is superseded by the larger problem — it is the building block of it." },
            { k: "p", t: "In practice the first mode dominates for regular buildings, which is why the simple static method of IS 1893 works for them at all, and why the code requires a dynamic analysis precisely when it does not — tall buildings, irregular buildings, and important ones." },
            { k: "note", t: "This is where this handbook stops. Multi-degree dynamics, non-linear analysis and finite elements all continue from here, and all of them assume everything in Chapters 1 to 12 without re-explaining it." },
          ],
        },
      ],
    }

  );
})();
