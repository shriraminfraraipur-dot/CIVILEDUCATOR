/* ============================================================
   CIVIL EDUCATOR — B.Tech CIVIL ENGINEERING MASTER COURSE MAP
   ------------------------------------------------------------
   Eight semesters, the subjects in each, and the topics in each
   subject. This is a broad academic + practical master structure
   for the handbook — it is NOT any one university's syllabus, and
   it does not claim to be. Where a university differs, the topic
   list is what matters, not the semester number.

   Every subject carries an honest status:
     ready   - a handbook in this app covers it
     partial - covered inside another handbook, not on its own
     notes   - source class notes are uploaded, handbook not built
     planned - nothing written yet
   Nothing here invents content. A subject marked planned links to
   nothing, on purpose.
   ============================================================ */
window.DB = window.DB || {};

DB.courseFlow = [
  ["Semester", "Aap kis saal mein hain"],
  ["Subject", "Us semester ka paper"],
  ["Chapter", "Paper ka unit"],
  ["Topic", "Ek padhne layak cheez"],
  ["Concept", "Ye hota kya hai, aur kyun"],
  ["Formula / Theory", "Jis se number nikalta hai"],
  ["Diagram", "Jo shabdon se nahi samajh aata"],
  ["Worked Example", "Poora hisaab, step by step"],
  ["Test / Design", "Lab test ya design procedure"],
  ["Site Application", "Site par ye dikhta kaise hai"],
  ["Engineer's Note", "Jo sirf anubhav se pata chalta hai"],
  ["Viva / MCQ", "Jo poocha jata hai"],
  ["Quick Revision", "Aakhri raat ka ek page"]
];

DB.materialFlow = ["Introduction", "Types", "Raw Materials", "Manufacturing", "Properties",
  "Grades", "Standards", "Tests", "Apparatus", "Testing Procedure", "Applications",
  "Storage", "Defects", "Site Inspection"];

DB.semesters = [
  {
    n: 1, name: "Engineering Foundation", hi: "इंजीनियरिंग की नींव",
    blurb: "Maths, physics, chemistry, electrical, drawing aur programming — civil ka koi paper abhi nahi, par inke bina aage kuch samajh nahi aayega.",
    subjects: [
      { id: "s1-maths1", name: "Engineering Mathematics", hi: "इंजीनियरिंग गणित",
        summary: "Civil engineering calculations ke mathematical fundamentals.",
        status: "planned",
        topics: ["Differential Calculus", "Integral Calculus", "Differential Equations", "Matrices & Determinants", "Vector Calculus", "Complex Numbers", "Numerical Methods", "Probability & Statistics"] },
      { id: "s1-physics", name: "Engineering Physics", hi: "इंजीनियरिंग भौतिकी",
        summary: "Mechanics se modern physics tak — aur inka engineering mein use.",
        status: "planned",
        topics: ["Mechanics", "Properties of Matter", "Heat & Thermodynamics", "Waves & Oscillations", "Optics", "Electricity & Magnetism", "Modern Physics", "Engineering Applications"] },
      { id: "s1-chem", name: "Engineering Chemistry", hi: "इंजीनियरिंग रसायन",
        summary: "Water chemistry, corrosion aur cement chemistry — civil ke liye sabse kaam ke hisse.",
        status: "partial", hb: "bmn",
        note: "Cement chemistry aur corrosion ka civil wala hissa Building Materials handbook (Bogue's compounds, Metals and Corrosion) mein hai.",
        topics: ["Atomic Structure", "Chemical Bonding", "Water Chemistry", "Corrosion", "Cement Chemistry", "Fuels", "Polymers", "Construction-related chemical materials"] },
      { id: "s1-bee", name: "Basic Electrical Engineering", hi: "मूल विद्युत अभियांत्रिकी",
        summary: "DC/AC circuits, machines aur electrical safety.",
        status: "planned",
        topics: ["DC Circuits", "AC Circuits", "Electrical Machines", "Transformers", "Electrical Measurements", "Power Systems", "Electrical Safety"] },
      { id: "s1-graphics", name: "Engineering Graphics / Drawing", hi: "इंजीनियरिंग ड्राइंग",
        summary: "Projection, section aur building drawing ki buniyaad.",
        status: "notes", src: "ENGINEERING DRAWING Notes.pdf",
        topics: ["Drawing Instruments", "Geometrical Construction", "Orthographic Projection", "Isometric Projection", "Sections", "Development of Surfaces", "Building Drawing Basics"] },
      { id: "s1-prog", name: "Programming / Computer Fundamentals", hi: "प्रोग्रामिंग की बुनियाद",
        summary: "Algorithm se engineering problem solving tak.",
        status: "planned",
        topics: ["Programming Basics", "Algorithms", "Data Structures Basics", "Engineering Problem Solving", "Computer Applications"] }
    ]
  },
  {
    n: 2, name: "Basic Engineering + Civil Introduction", hi: "मूल अभियांत्रिकी + सिविल परिचय",
    blurb: "Engineering Mechanics aur Basic Civil — yahin se civil ka asli course shuru hota hai.",
    subjects: [
      { id: "s2-maths2", name: "Engineering Mathematics-II", hi: "इंजीनियरिंग गणित-II",
        summary: "Laplace, Fourier aur numerical techniques.",
        status: "planned",
        topics: ["Advanced Calculus", "Differential Equations", "Laplace Transform", "Fourier Series", "Probability / Statistics", "Numerical Techniques"] },
      { id: "s2-mech", name: "Engineering Mechanics", hi: "इंजीनियरिंग यांत्रिकी",
        summary: "Force, equilibrium, centroid aur MOI — Strength of Materials ki seedhi neev.",
        status: "partial", hb: "sa",
        note: "Free body diagram, equilibrium aur support reactions Structural Analysis handbook ke chapter 1 mein hain.",
        topics: ["Force Systems", "Free Body Diagram", "Equilibrium", "Friction", "Centroid", "Moment of Inertia", "Kinematics", "Kinetics", "Work & Energy"] },
      { id: "s2-bce", name: "Basic Civil Engineering", hi: "मूल सिविल अभियांत्रिकी",
        summary: "Civil Engineering ke saare domains ka introduction — ek nazar mein poora course.",
        status: "partial", hb: "bc",
        topics: ["Building Components", "Building Materials", "Surveying Introduction", "Transportation", "Water Resources", "Environmental Engineering", "Structural Engineering", "Geotechnical Engineering", "Construction Management", "Estimation Basics"] },
      { id: "s2-workshop", name: "Workshop / Manufacturing Practice", hi: "वर्कशॉप अभ्यास",
        summary: "Welding, carpentry, plumbing aur fabrication — haath ka kaam.",
        status: "planned",
        topics: ["Basic Tools", "Welding", "Carpentry", "Metal Work", "Plumbing", "Fabrication", "Safety"] },
      { id: "s2-cad", name: "Engineering Graphics / CAD", hi: "कैड ड्राफ्टिंग",
        summary: "AutoCAD mein plan, section aur elevation banana.",
        status: "notes", src: "ENGINEERING DRAWING Notes.pdf",
        topics: ["AutoCAD Basics", "2D Drafting", "Building Plans", "Sections & Elevations", "Dimensioning", "Layer Management"] }
    ]
  },
  {
    n: 3, name: "Core Civil Fundamentals", hi: "सिविल की मूल बुनियाद",
    blurb: "SOM, Fluid Mechanics, Surveying, Building Materials aur Building Construction — civil ki chaar deewarein.",
    subjects: [
      { id: "s3-som", name: "Strength of Materials", hi: "पदार्थ सामर्थ्य",
        summary: "Load ke neeche material aur structural member ka behaviour.",
        status: "ready", hb: "som",
        topics: ["Stress & Strain", "Elasticity", "Hooke's Law", "Poisson's Ratio", "Shear Stress", "Principal Stress", "Mohr's Circle", "Bending", "Shear Force & Bending Moment", "Torsion", "Deflection", "Columns", "Buckling"] },
      { id: "s3-fm", name: "Fluid Mechanics", hi: "तरल यांत्रिकी",
        summary: "Hydrostatics se boundary layer tak.",
        status: "ready", hb: "fm",
        topics: ["Fluid Properties", "Pressure", "Hydrostatics", "Buoyancy", "Fluid Kinematics", "Continuity Equation", "Bernoulli Equation", "Momentum Equation", "Pipe Flow", "Boundary Layer", "Dimensional Analysis", "Open Channel Introduction"] },
      { id: "s3-survey", name: "Surveying", hi: "सर्वेक्षण",
        summary: "Chain se GNSS tak — har method ka principle aur har correction ka reason.",
        status: "ready", hb: "sv",
        topics: ["Principles of Surveying", "Chain Surveying", "Compass Surveying", "Levelling", "Theodolite", "Traversing", "Contouring", "Tacheometry", "Total Station", "Survey Errors", "Field Procedures"] },
      { id: "s3-bm", name: "Building Materials", hi: "भवन सामग्री",
        summary: "Har material ka poora chakra — introduction se site inspection tak.",
        status: "ready", hb: "bmn",
        flow: "material",
        topics: ["Cement", "Bricks", "Aggregates", "Concrete", "Mortar", "Timber", "Stones", "Lime", "Glass", "Paints", "Tiles", "Bitumen", "Blocks", "Admixtures", "Construction Chemicals", "Waterproofing Materials", "Steel"] },
      { id: "s3-bcon", name: "Building Construction", hi: "भवन निर्माण",
        summary: "Foundation se finishing tak, construction sequence ke saath.",
        status: "ready", hb: "bc",
        topics: ["Foundations", "Masonry", "Doors & Windows", "Floors", "Roofs", "Stairs", "Damp Proofing", "Waterproofing", "Plastering", "Finishing", "Building Services", "Construction Sequence"] }
    ]
  },
  {
    n: 4, name: "Structural + Construction Core", hi: "संरचना एवं निर्माण कोर",
    blurb: "Structural Analysis, Concrete Technology, Geotech-I, Hydrology aur Engineering Geology.",
    subjects: [
      { id: "s4-sa", name: "Structural Analysis", hi: "संरचनात्मक विश्लेषण",
        summary: "Determinate se indeterminate tak — har method derive kiya hua.",
        status: "ready", hb: "sa",
        topics: ["Determinate Structures", "Beams", "Trusses", "Frames", "Influence Lines", "Deflection", "Energy Methods", "Indeterminate Structures", "Moment Distribution", "Structural Behavior"] },
      { id: "s4-ct", name: "Concrete Technology", hi: "कंक्रीट प्रौद्योगिकी",
        summary: "Ingredient se cube test tak, aur special concrete.",
        status: "ready", hb: "ct",
        topics: ["Ingredients of Concrete", "Cement", "Aggregates", "Water", "Admixtures", "Workability", "Mix Proportioning", "Water-Cement Ratio", "Strength", "Durability", "Concrete Production", "Transportation", "Placing", "Compaction", "Curing", "Concrete Testing", "Special Concrete"] },
      { id: "s4-geo1", name: "Geotechnical Engineering-I", hi: "भू-तकनीकी अभियांत्रिकी-I",
        summary: "Soil formation se shear strength tak.",
        status: "ready", hb: "ge",
        topics: ["Soil Formation", "Soil Types", "Phase Relationships", "Index Properties", "Soil Classification", "Permeability", "Seepage", "Effective Stress", "Compaction", "Consolidation", "Shear Strength"] },
      { id: "s4-hydro", name: "Hydrology", hi: "जल विज्ञान",
        summary: "Hydrologic cycle se lekar precipitation, evaporation, infiltration, runoff, hydrographs aur flood frequency tak.",
        status: "ready", hb: "hydro",
        topics: ["Hydrologic Cycle", "Precipitation", "Rainfall Measurement", "Rainfall Analysis", "Evaporation", "Infiltration", "Runoff", "Streamflow Measurement", "Hydrographs", "Unit Hydrograph", "Floods", "Flood Frequency", "Flood Routing", "Droughts"] },
      { id: "s4-geol", name: "Engineering Geology", hi: "इंजीनियरिंग भूविज्ञान",
        summary: "Mineral aur rock se dam, tunnel aur foundation ke geological investigation tak.",
        status: "planned",
        topics: ["Minerals", "Rocks", "Rock Classification", "Geological Structures", "Weathering", "Geological Maps", "Groundwater", "Engineering Properties of Rocks", "Geological Investigations", "Dams", "Tunnels", "Foundations"] }
    ]
  },
  {
    n: 5, name: "Design + Infrastructure", hi: "डिज़ाइन एवं अवसंरचना",
    blurb: "RCC Design, Geotech-II, Highway, Water Supply aur Estimation — pehla poora design semester.",
    subjects: [
      { id: "s5-rcc", name: "RCC Design", hi: "आर.सी.सी. डिज़ाइन",
        summary: "IS 456:2000 ka poora design course — philosophy se detailing tak.",
        status: "ready", hb: "rcc",
        topics: ["Design Philosophy", "Limit State Method", "Loads", "Flexural Members", "Singly Reinforced Beams", "Doubly Reinforced Beams", "T-Beams", "Shear", "Bond", "Development Length", "Slabs", "One-Way Slabs", "Two-Way Slabs", "Staircases", "Columns", "Footings", "Detailing", "Ductile Detailing", "IS 456 and related standards"] },
      { id: "s5-geo2", name: "Geotechnical Engineering-II", hi: "भू-तकनीकी अभियांत्रिकी-II",
        summary: "Earth pressure, bearing capacity, piles aur slope stability.",
        status: "ready", hb: "ge",
        note: "Geotechnical handbook ke chapters 10-12 is paper ko cover karte hain.",
        topics: ["Earth Pressure", "Retaining Walls", "Bearing Capacity", "Foundations", "Shallow Foundations", "Deep Foundations", "Piles", "Pile Capacity", "Settlement", "Slope Stability", "Soil Stabilization"] },
      { id: "s5-tr1", name: "Transportation Engineering-I (Highway)", hi: "परिवहन अभियांत्रिकी-I",
        summary: "Alignment aur geometric design se pavement construction tak.",
        status: "ready", hb: "tr",
        topics: ["Highway Classification", "Road Planning", "Alignment", "Surveys", "Geometric Design", "Sight Distance", "Superelevation", "Pavement Materials", "Flexible Pavements", "Rigid Pavements", "Pavement Construction", "Drainage", "Maintenance"] },
      { id: "s5-env1", name: "Environmental Engineering-I (Water Supply)", hi: "पर्यावरण अभियांत्रिकी-I",
        summary: "Source se distribution tak — demand, treatment aur storage.",
        status: "partial", hb: "bs",
        note: "Water demand, storage aur treatment Building Services handbook ke chapters 2 aur 4 mein hai; intake structures aur distribution abhi nahi.",
        topics: ["Water Sources", "Water Quality", "Water Demand", "Intake Structures", "Water Treatment", "Coagulation", "Sedimentation", "Filtration", "Disinfection", "Water Distribution", "Storage"] },
      { id: "s5-est", name: "Estimation & Costing", hi: "प्राक्कलन एवं लागत",
        summary: "Quantity take-off, rate analysis aur tender documents.",
        status: "ready", hb: "es",
        topics: ["Quantity Take-off", "BOQ", "Rate Analysis", "Material Quantities", "Labour Quantities", "Earthwork", "Concrete", "Brickwork", "Plaster", "Flooring", "Steel", "Measurement", "Abstract Estimate", "Detailed Estimate", "Tender Documents"] }
    ]
  },
  {
    n: 6, name: "Advanced Civil Engineering", hi: "उन्नत सिविल अभियांत्रिकी",
    blurb: "Steel, Irrigation, Wastewater, Railway/Airport/Traffic aur Foundation engineering.",
    subjects: [
      { id: "s6-steel", name: "Steel Structures", hi: "इस्पात संरचनाएँ",
        summary: "IS 800 ka poora design course — connection se industrial structure tak.",
        status: "ready", hb: "stn",
        topics: ["Structural Steel", "Design Philosophy", "Loads", "Connections", "Bolted Connections", "Welded Connections", "Tension Members", "Compression Members", "Columns", "Beams", "Plate Girders", "Roof Trusses", "Industrial Structures", "Detailing", "IS 800"] },
      { id: "s6-irr", name: "Irrigation Engineering", hi: "सिंचाई अभियांत्रिकी",
        summary: "Duty-delta se canal design, cross drainage, dams aur spillways tak.",
        status: "ready", hb: "irr",
        topics: ["Irrigation Fundamentals", "Soil-Water-Plant Relationship", "Crop Water Requirement", "Duty", "Delta", "Base Period", "Irrigation Efficiencies", "Canal Classification", "Canal Alignment", "Canal Losses", "Canal Design", "Kennedy Theory", "Lacey Theory", "Canal Lining", "Cross Drainage Works", "Waterlogging", "Drainage", "Wells", "Dams", "Spillways", "Weirs & Barrages"] },
      { id: "s6-env2", name: "Environmental Engineering-II (Wastewater & Solid Waste)", hi: "पर्यावरण अभियांत्रिकी-II",
        summary: "Sewerage aur treatment, phir solid waste ka poora chakra.",
        status: "partial", hb: "bs",
        note: "Building drainage aur wastewater treatment Building Services handbook ke chapters 3-4 mein hai; sewer design aur solid waste abhi nahi.",
        topics: ["Sewerage Systems", "Sewer Design", "Sewer Appurtenances", "Wastewater Characteristics", "Primary Treatment", "Secondary Treatment", "Biological Treatment", "Sludge Treatment", "Industrial Wastewater", "Solid Waste: Collection", "Transportation", "Processing", "Recycling", "Composting", "Disposal", "Landfills"] },
      { id: "s6-tr2", name: "Transportation Engineering-II", hi: "परिवहन अभियांत्रिकी-II",
        summary: "Railway, airport, traffic engineering aur pavement management.",
        status: "notes", src: "Railway Airport Tunnel.pdf · Transportation Engineering.pdf",
        note: "Transportation handbook ka chapter 8 railways, airports aur docks ko chhota sa cover karta hai.",
        topics: ["Railway Engineering", "Airport Engineering", "Traffic Engineering", "Traffic Studies", "Road Safety", "Intelligent Transportation Systems", "Pavement Management"] },
      { id: "s6-found", name: "Foundation / Advanced Construction", hi: "नींव एवं उन्नत निर्माण",
        summary: "Site investigation, dewatering, shoring, piling aur ground improvement.",
        status: "partial", hb: "ge",
        note: "Piles, deep foundations aur site investigation Geotechnical handbook ke chapter 12 mein hain.",
        topics: ["Foundation Selection", "Site Investigation", "Excavation", "Dewatering", "Shoring", "Piling", "Ground Improvement", "Construction Equipment", "Temporary Works"] }
    ]
  },
  {
    n: 7, name: "Professional Civil Engineering", hi: "व्यावसायिक सिविल अभियांत्रिकी",
    blurb: "Prestressed concrete, construction management, contracts, quantity surveying aur professional practice.",
    subjects: [
      { id: "s7-psc", name: "Prestressed Concrete", hi: "पूर्वप्रतिबलित कंक्रीट",
        summary: "Pre-tensioning, post-tensioning, losses aur anchorage.",
        status: "planned",
        topics: ["Concept of Prestressing", "Materials", "Prestressing Systems", "Pre-tensioning", "Post-tensioning", "Losses", "Analysis", "Design", "Anchorage", "Applications"] },
      { id: "s7-cm", name: "Construction Management", hi: "निर्माण प्रबंधन",
        summary: "Planning, CPM/PERT, resources, cost, quality, safety aur risk.",
        status: "notes", src: "CPM Handwritten Notes.pdf",
        topics: ["Construction Planning", "Scheduling", "CPM", "PERT", "Resource Management", "Labour Management", "Material Management", "Equipment Management", "Cost Control", "Quality Control", "Safety Management", "Risk Management"] },
      { id: "s7-contract", name: "Contracts & Tendering", hi: "अनुबंध एवं निविदा",
        summary: "Tender se arbitration tak — contract ka poora jeevan.",
        status: "partial", hb: "es",
        note: "Rate analysis, tendering aur valuation Estimation handbook ke chapter 8 mein hai; contract types, claims aur arbitration abhi nahi.",
        topics: ["Tender Documents", "BOQ", "Specifications", "Bidding", "E-Tendering", "Contract Types", "Work Orders", "Payment", "Measurement", "Variation", "Claims", "Arbitration", "Contract Administration"] },
      { id: "s7-qs", name: "Quantity Surveying / Valuation", hi: "मात्रा सर्वेक्षण एवं मूल्यांकन",
        summary: "Measurement, billing, RA bills aur property valuation.",
        status: "partial", hb: "es",
        topics: ["Measurement", "Quantity Take-off", "Rate Analysis", "BOQ", "Billing", "Running Account Bills", "Final Bills", "Valuation", "Depreciation", "Property Valuation"] },
      { id: "s7-prof", name: "Professional Practice", hi: "व्यावसायिक अभ्यास",
        summary: "Ethics, site documentation, QA/QC aur coordination.",
        status: "partial", hb: "qc",
        note: "QA/QC, site inspection aur acceptance Material Testing & QC handbook ke chapters 1 aur 8 mein hain.",
        topics: ["Engineering Ethics", "Site Documentation", "Drawings", "Specifications", "QA/QC", "Site Inspection", "Client Management", "Contractor Management", "Consultant Coordination", "Safety", "Professional Responsibility"] }
    ]
  },
  {
    n: 8, name: "Advanced + Industry + Project", hi: "उन्नत + उद्योग + परियोजना",
    blurb: "Seismic design, advanced construction, BIM, sustainability aur major project.",
    subjects: [
      { id: "s8-adv", name: "Advanced Structural Engineering", hi: "उन्नत संरचना अभियांत्रिकी",
        summary: "Advanced RCC/steel, dynamics, rehabilitation aur health monitoring.",
        status: "partial", hb: "sa",
        note: "Structural dynamics (SDOF) Structural Analysis handbook ke chapter 19 mein hai; rehabilitation aur SHM abhi nahi.",
        topics: ["Advanced RCC", "Advanced Steel", "Seismic Design", "Structural Dynamics", "Earthquake Engineering", "Structural Rehabilitation", "Retrofitting", "Structural Health Monitoring"] },
      { id: "s8-eq", name: "Earthquake Engineering", hi: "भूकंप अभियांत्रिकी",
        summary: "IS 1893 aur IS 13920 ka poora flow — base shear se ductile detailing tak.",
        status: "ready", hb: "eq",
        topics: ["Earthquake Fundamentals", "Seismic Zones", "Structural Response", "Seismic Loads", "Ductility", "Earthquake-resistant Construction", "IS 1893", "IS 13920", "Detailing", "Retrofitting"] },
      { id: "s8-adct", name: "Advanced Construction Technology", hi: "उन्नत निर्माण तकनीक",
        summary: "High-rise, precast, formwork systems aur construction automation.",
        status: "planned",
        topics: ["High-Rise Construction", "Precast Construction", "Modular Construction", "Prefabrication", "Formwork Systems", "Slip Form", "Tunnel Form", "Construction Automation", "3D Printing", "Robotics", "Drones", "Modern Construction Methods"] },
      { id: "s8-bim", name: "BIM / Digital Civil Engineering", hi: "बी.आई.एम. एवं डिजिटल सिविल",
        summary: "3D se 5D BIM, digital twins, GIS aur drone survey.",
        status: "planned",
        topics: ["BIM Fundamentals", "Revit", "3D Modelling", "Clash Detection", "Quantity Extraction", "4D BIM", "5D BIM", "Digital Twins", "GIS", "Drone Survey", "Digital Construction Management"] },
      { id: "s8-green", name: "Sustainability & Green Construction", hi: "स्थिरता एवं हरित निर्माण",
        summary: "Green buildings, energy aur water conservation, LCA.",
        status: "planned",
        topics: ["Sustainable Materials", "Green Buildings", "Energy Efficiency", "Water Conservation", "Rainwater Harvesting", "Waste Reduction", "Recycling", "Carbon Reduction", "Life Cycle Assessment", "Sustainable Construction"] },
      { id: "s8-proj", name: "Major Project / Industrial Training", hi: "मुख्य परियोजना",
        summary: "Problem se final report tak — project ka poora process.",
        status: "planned",
        topics: ["Problem Identification", "Literature Review", "Methodology", "Design / Analysis", "Site Investigation", "Execution", "Testing", "Data Analysis", "Cost Analysis", "Documentation", "Presentation", "Final Report"] }
    ]
  }
];

/* Papers that sit outside the semester grid but have a handbook here. */
DB.courseExtra = [
  { id: "x-qc", name: "Material Testing & Quality Control", hb: "qc",
    summary: "Lab file, viva aur site QC — har test ka kyun, kitna aur kis code se." },
  { id: "x-tunnel", name: "Tunnel Engineering", status: "ready", hb: "tunnel",
    summary: "Tunnelling methods, supports aur ventilation." },
  { id: "x-bridge", name: "Bridge Engineering", status: "ready", hb: "bridge",
    summary: "Bridge components, loading aur superstructure types." }
];
