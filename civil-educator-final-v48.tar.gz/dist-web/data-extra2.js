/* ============================================================
   CIVIL EDUCATOR — Solved examples, part 2
   Thirty worked numericals with every step shown and the
   clause each step follows. Written for this app.
   ============================================================ */

window.DB = window.DB || {};
DB.examples = DB.examples || [];

DB.examples.push(

  /* ====================================================== RCC DESIGN */
  {
    id: "ex-beam-doubly", code: "is456", cat: "RCC design", level: "Advanced",
    title: "Doubly reinforced beam — compression steel",
    given: "Beam 300 mm wide, effective depth d = 450 mm, d′ = 50 mm, factored moment Mu = 250 kN·m, M25 concrete, Fe 500 steel.",
    steps: [
      { t: "Limiting moment of resistance", w: "For Fe 500, Mu,lim = 0.133 fck b d²\n= 0.133 × 25 × 300 × 450²\n= 0.133 × 25 × 300 × 202 500\n= 202.0 kN·m", r: "IS 456 Cl. 38.1, Annex G" },
      { t: "Is compression steel needed?", w: "Mu = 250 kN·m > Mu,lim = 202.0 kN·m\nExcess Mu2 = 250 − 202.0 = 48.0 kN·m must be carried by a compression–tension steel couple.", r: "IS 456 Annex G-1.2" },
      { t: "Stress in compression steel", w: "d′/d = 50/450 = 0.111\nFor Fe 500 at this ratio, fsc ≈ 412 N/mm² (read from the strain-compatibility table; it is NOT 0.87 fy because the steel does not reach full yield strain at that depth).", r: "IS 456 Cl. 38.1, Annex G-1.2" },
      { t: "Area of compression steel", w: "Asc = Mu2 / [(fsc − 0.446 fck)(d − d′)]\n= 48 × 10⁶ / [(412 − 11.15) × (450 − 50)]\n= 48 × 10⁶ / (400.85 × 400)\n= 299 mm²", r: "IS 456 Annex G-1.2" },
      { t: "Tension steel for the limiting moment", w: "xu,max = 0.46 d = 0.46 × 450 = 207 mm\nLever arm = d − 0.42 xu,max = 450 − 86.9 = 363.1 mm\nAst1 = Mu,lim / (0.87 fy × lever arm) = 202 × 10⁶ / (435 × 363.1) = 1 279 mm²", r: "IS 456 Cl. 38.1" },
      { t: "Tension steel balancing the compression steel", w: "Ast2 = Asc × fsc / (0.87 fy) = 299 × 412 / 435 = 283 mm²\nTotal Ast = 1 279 + 283 = 1 562 mm²", r: "IS 456 Annex G-1.2" },
      { t: "Provide bars", w: "Tension: 4 – 20 mm (1 257) + 2 – 16 mm (402) = 1 659 mm² > 1 562 ✓\nCompression: 2 – 16 mm = 402 mm² > 299 ✓\nCheck max steel: 0.04 b D = 0.04 × 300 × 500 = 6 000 mm² ≫ 1 659 ✓", r: "IS 456 Cl. 26.5.1.1" },
    ],
    answer: "Tension steel 4 – 20 mm + 2 – 16 mm (1 659 mm²); compression steel 2 – 16 mm (402 mm²).",
    watch: "fsc is not 0.87 fy. The compression steel sits close to the neutral axis, so its strain — and therefore its stress — is limited by the concrete strain. Using 0.87 fy here understates the compression steel required.",
    calc: "ast-singly",
  },

  {
    id: "ex-slab-twoway", code: "is456", cat: "RCC design", level: "Advanced",
    title: "Two-way restrained slab — moments and steel",
    given: "Interior panel 4 m × 5 m, all four edges continuous. Live load 3 kN/m², floor finish 1 kN/m², M25, Fe 500. Overall depth 150 mm, effective depth 125 mm.",
    steps: [
      { t: "One-way or two-way?", w: "ly/lx = 5/4 = 1.25 ≤ 2 → design as a two-way slab using the Annex D coefficients.", r: "IS 456 Cl. 24, Annex D" },
      { t: "Loads", w: "Self weight = 0.15 × 25 = 3.75 kN/m²\nFinish = 1.00\nLive load = 3.00\nTotal service load = 7.75 kN/m²\nFactored wu = 1.5 × 7.75 = 11.63 kN/m²", r: "IS 875 (Parts 1 & 2); IS 456 Table 18" },
      { t: "Moment coefficients", w: "Interior panel, ly/lx = 1.25, from Table 26:\nαx (negative, continuous edge) = 0.053\nαx (positive, mid-span)        = 0.040\nαy (negative)                  = 0.047\nαy (positive)                  = 0.035", r: "IS 456 Table 26" },
      { t: "Moments — note lx² in BOTH directions", w: "Mx(−) = 0.053 × 11.63 × 4² = 9.86 kN·m\nMx(+) = 0.040 × 11.63 × 16 = 7.44 kN·m\nMy(−) = 0.047 × 11.63 × 16 = 8.75 kN·m\nMy(+) = 0.035 × 11.63 × 16 = 6.51 kN·m", r: "IS 456 Annex D-1.1" },
      { t: "Steel for the largest moment", w: "Mx(−) = 9.86 kN·m, b = 1000 mm, d = 125 mm\n9.86 × 10⁶ = 435 Ast (125 − 0.02 Ast)\n8.7 Ast² − 54 375 Ast + 9.86 × 10⁶ = 0\nAst = 187 mm² per metre", r: "IS 456 Annex G-1.1" },
      { t: "Check minimum steel", w: "As,min = 0.12% of gross area = 0.0012 × 1000 × 150 = 180 mm²/m\n187 > 180, so the calculated steel governs — but only just.", r: "IS 456 Cl. 26.5.2.1" },
      { t: "Provide and check spacing", w: "8 mm @ 200 mm c/c = 50.3 × 1000/200 = 251 mm²/m ✓\nMax spacing for main steel = 3d = 375 mm or 300 mm, whichever less → 300 mm. 200 < 300 ✓", r: "IS 456 Cl. 26.3.3(b)" },
    ],
    answer: "Provide 8 mm @ 200 c/c both ways, with extra top steel at continuous edges for the negative moments; corner torsion steel is not required in an interior panel.",
    watch: "The moment in the LONG direction still uses lx² — the shorter span squared. Writing αy w ly² is the single commonest error in two-way slab problems and inflates the long-span moment badly.",
    calc: "span-depth",
  },

  {
    id: "ex-tbeam", code: "is456", cat: "RCC design", level: "Advanced",
    title: "T-beam — effective flange width and steel",
    given: "Simply supported T-beam, effective span 6 m, web width bw = 250 mm, slab thickness Df = 120 mm, beams at 3 m centres, effective depth d = 500 mm, Mu = 250 kN·m, M25, Fe 500.",
    steps: [
      { t: "Effective flange width", w: "bf = lo/6 + bw + 6 Df\n= 6000/6 + 250 + 6 × 120\n= 1000 + 250 + 720 = 1 970 mm\nCheck against the actual c/c spacing of 3 000 mm → 1 970 mm governs.", r: "IS 456 Cl. 23.1.2" },
      { t: "Assume the neutral axis lies in the flange", w: "Treat the section as rectangular of width bf = 1 970 mm:\n250 × 10⁶ = 435 Ast (500 − 500 Ast/(25 × 1970))\n= 435 Ast (500 − 0.01015 Ast)", r: "IS 456 Annex G-2.1" },
      { t: "Solve for Ast", w: "4.415 Ast² − 217 500 Ast + 250 × 10⁶ = 0\nAst = 1 178 mm²", r: "IS 456 Annex G-2.1" },
      { t: "Verify the assumption", w: "xu = 0.87 fy Ast / (0.36 fck bf)\n= 435 × 1 178 / (0.36 × 25 × 1 970)\n= 512 430 / 17 730 = 28.9 mm\n28.9 mm < Df = 120 mm ✓ — the neutral axis really is in the flange.", r: "IS 456 Annex G-2.2" },
      { t: "Provide bars", w: "4 – 20 mm = 1 257 mm² > 1 178 ✓\nAs,min = 0.85/fy × bw d = 0.85/500 × 250 × 500 = 213 mm² ✓", r: "IS 456 Cl. 26.5.1.1" },
    ],
    answer: "Effective flange width 1 970 mm; provide 4 – 20 mm tension bars (1 257 mm²). The neutral axis falls inside the flange, so the section behaves as a wide rectangle.",
    watch: "Always verify the assumption at the end. If xu had come out greater than Df the section would have to be re-analysed with the flange and web contributing separately — and the answer would change.",
    calc: "ast-singly",
  },

  {
    id: "ex-torsion", code: "is456", cat: "RCC design", level: "Advanced",
    title: "Spandrel beam — design for torsion",
    given: "Beam 300 mm × 500 mm, effective depth 450 mm, Mu = 90 kN·m, Vu = 80 kN, Tu = 20 kN·m, M25, Fe 500.",
    steps: [
      { t: "Equivalent shear", w: "Ve = Vu + 1.6 Tu / b\n= 80 + 1.6 × 20 / 0.3\n= 80 + 106.7 = 186.7 kN\nThe torsion more than doubles the shear the section must be checked for.", r: "IS 456 Cl. 41.3.1" },
      { t: "Equivalent shear stress", w: "τve = Ve / (b d) = 186 700 / (300 × 450) = 1.38 N/mm²\nτc,max for M25 = 3.1 N/mm² → 1.38 < 3.1 ✓ the section size is acceptable.", r: "IS 456 Cl. 41.3.1, Table 20" },
      { t: "Equivalent bending moment", w: "Mt = Tu (1 + D/b) / 1.7\n= 20 (1 + 500/300) / 1.7\n= 20 × 2.667 / 1.7 = 31.4 kN·m\nMe1 = Mu + Mt = 90 + 31.4 = 121.4 kN·m", r: "IS 456 Cl. 41.4.2" },
      { t: "Longitudinal steel for Me1", w: "121.4 × 10⁶ = 435 Ast (450 − 0.0667 Ast)\n29 Ast² − 195 750 Ast + 121.4 × 10⁶ = 0\nAst = 691 mm² → provide 4 – 16 mm = 804 mm² ✓", r: "IS 456 Annex G-1.1" },
      { t: "Concrete shear capacity", w: "pt = 100 × 804 / (300 × 450) = 0.60 %\nFrom Table 19 for M25 at pt = 0.60, τc ≈ 0.52 N/mm²\nτve − τc = 1.38 − 0.52 = 0.86 N/mm² must be carried by transverse steel.", r: "IS 456 Table 19" },
      { t: "Transverse reinforcement", w: "Provide CLOSED stirrups around the outer corners — open stirrups carry no torsion at all.\nSince D = 500 mm > 450 mm, side face reinforcement is also required on both faces of the web.", r: "IS 456 Cl. 41.4.3 and Cl. 26.5.1.3" },
    ],
    answer: "Design for Ve = 186.7 kN and Me1 = 121.4 kN·m: 4 – 16 mm bottom bars, closed stirrups throughout, plus side face reinforcement because the depth exceeds 450 mm.",
    watch: "Distinguish equilibrium torsion from compatibility torsion. An edge beam carrying a cantilever slab needs its full torsional capacity to stand up; torsion that arises only because the frame is monolithic largely relieves itself by cracking.",
    calc: "tauc-calc",
  },

  {
    id: "ex-slender-col", code: "is456", cat: "RCC design", level: "Advanced",
    title: "Slender column — additional moment",
    given: "Column 300 mm × 450 mm, unsupported length 6 m, braced frame with both ends restrained against rotation, factored axial load Pu = 1 000 kN, M25, Fe 500.",
    steps: [
      { t: "Effective length", w: "Braced, both ends held in position and restrained against rotation:\nlex = ley = 0.65 × 6 000 = 3 900 mm", r: "IS 456 Cl. 25.2, Table 28" },
      { t: "Short or slender?", w: "lex/D = 3 900 / 450 = 8.67  → short about the major axis\nley/b = 3 900 / 300 = 13.0  → SLENDER about the minor axis\nBoth must be under 12; one exceeds it, so the column is slender.", r: "IS 456 Cl. 25.1.2" },
      { t: "Minimum eccentricity about the minor axis", w: "e min = l/500 + b/30 = 6 000/500 + 300/30 = 12 + 10 = 22 mm\n22 mm > 20 mm floor, so 22 mm governs.\nMu,min = 1 000 × 0.022 = 22.0 kN·m", r: "IS 456 Cl. 25.4" },
      { t: "Additional moment from slenderness", w: "May = Pu × b × (ley/b)² / 2000\n= 1 000 × 300 × 13.0² / 2000\n= 1 000 × 300 × 169 / 2000 = 25 350 kN·mm = 25.35 kN·m", r: "IS 456 Cl. 39.7.1" },
      { t: "Design moment", w: "Take the larger of the minimum-eccentricity moment and the additional moment, added to any moment from the frame analysis:\nMuy = 25.35 kN·m about the minor axis (governs over 22.0)\nThe column is now designed for combined axial load and moment from an interaction chart.", r: "IS 456 Cl. 39.7" },
    ],
    answer: "The column is slender about its minor axis. Design it for Pu = 1 000 kN with an additional moment of 25.35 kN·m about that axis, using an interaction diagram rather than the simple axial formula.",
    watch: "Check both axes separately. A rectangular column is usually short one way and slender the other, and it is always the weak direction that governs — the additional moment grows with the SQUARE of the slenderness.",
    calc: "column-qty",
  },

  {
    id: "ex-stair", code: "is456", cat: "RCC design", level: "Core",
    title: "Dog-leg staircase — span, load and steel",
    given: "Going 2.7 m (tread 270 mm, riser 150 mm), landings 1.2 m at both ends, waist slab 150 mm, floor finish 1 kN/m², live load 3 kN/m², M25, Fe 500, cover 20 mm, 12 mm bars.",
    steps: [
      { t: "Effective span", w: "Add, at each end, half the landing width or 1 m, whichever is SMALLER:\nhalf of 1.2 m = 0.6 m < 1.0 m → add 0.6 m each end\nEffective span = 2.7 + 0.6 + 0.6 = 3.9 m", r: "IS 456 Cl. 33.1" },
      { t: "Waist slab weight on plan", w: "Inclined length per unit going = √(150² + 270²)/270 = 308.9/270 = 1.144\nWaist load on plan = 0.15 × 25 × 1.144 = 4.29 kN/m²", r: "IS 456 Cl. 33.3" },
      { t: "Steps, finishes and live load", w: "Steps (triangular, as an equivalent UDL) = ½ × 0.15 × 25 = 1.875 kN/m²\nFinishes = 1.00 kN/m²\nLive load = 3.00 kN/m²\nTotal = 4.29 + 1.875 + 1.00 + 3.00 = 10.17 kN/m²\nwu = 1.5 × 10.17 = 15.25 kN/m² (= 15.25 kN/m per metre width)", r: "IS 875 (Part 2); IS 456 Table 18" },
      { t: "Design moment", w: "Mu = wu l² / 8 = 15.25 × 3.9² / 8 = 15.25 × 15.21 / 8 = 29.0 kN·m per metre width", r: "—" },
      { t: "Effective depth and steel", w: "d = 150 − 20 − 12/2 = 124 mm\n29 × 10⁶ = 435 Ast (124 − 0.02 Ast)\n8.7 Ast² − 53 940 Ast + 29 × 10⁶ = 0\nAst = 595 mm² per metre", r: "IS 456 Annex G-1.1" },
      { t: "Provide bars", w: "12 mm @ 180 mm c/c = 113 × 1000/180 = 628 mm²/m > 595 ✓\nDistribution steel: 0.12% × 1000 × 150 = 180 mm²/m → 8 mm @ 250 c/c (201 mm²/m) ✓", r: "IS 456 Cl. 26.5.2.1" },
    ],
    answer: "Effective span 3.9 m; provide 12 mm @ 180 c/c main bars along the flight with 8 mm @ 250 c/c distribution steel.",
    watch: "The self weight of the steps is forgotten more often than anything else on a staircase. The waist slab alone is about 4.3 kN/m²; the steps add nearly another 2 kN/m² — a 40% under-estimate if you skip them.",
    calc: "slab-qty",
  },

  {
    id: "ex-devlength", code: "is456", cat: "RCC design", level: "Core",
    title: "Development length in tension and compression",
    given: "16 mm Fe 500 deformed bar in M25 concrete.",
    steps: [
      { t: "Design bond stress", w: "For M25, τbd = 1.4 N/mm² (plain bars)\nDeformed bars in tension: increase by 60% → τbd = 1.4 × 1.6 = 2.24 N/mm²", r: "IS 456 Cl. 26.2.1.1" },
      { t: "Development length in tension", w: "Ld = φ σs / (4 τbd)\n= 16 × 0.87 × 500 / (4 × 2.24)\n= 16 × 435 / 8.96\n= 16 × 48.55 = 777 mm ≈ 48.5 φ", r: "IS 456 Cl. 26.2.1" },
      { t: "Development length in compression", w: "In compression τbd is increased by a further 25%:\nτbd = 2.24 × 1.25 = 2.80 N/mm²\nLd = 16 × 435 / (4 × 2.80) = 16 × 38.84 = 621 mm ≈ 39 φ", r: "IS 456 Cl. 26.2.1.1" },
      { t: "Compare with Fe 415", w: "For Fe 415 in M25: Ld = 16 × 361 / 8.96 = 16 × 40.3 = 645 mm ≈ 40 φ\nThe stronger bar needs a LONGER anchorage, because σs in the numerator is higher.", r: "IS 456 Cl. 26.2.1" },
    ],
    answer: "Tension Ld = 777 mm (say 780 mm, 48.5 φ); compression Ld = 621 mm (say 625 mm, 39 φ).",
    watch: "Ld is proportional to the bar STRESS, so going from Fe 415 to Fe 500 lengthens the anchorage by about 20%. A detail that just fitted in Fe 415 may not fit in Fe 500 — check the beam width at the support.",
    calc: "dev-length",
  },

  {
    id: "ex-lap", code: "is456", cat: "RCC design", level: "Core",
    title: "Lap length for a column and a beam bar",
    given: "16 mm Fe 500 bars in M25 concrete. Ld in tension = 777 mm, Ld in compression = 621 mm (from the development length example).",
    steps: [
      { t: "Lap in flexural tension", w: "Lap length = Ld or 30 φ, whichever is greater\n30 φ = 30 × 16 = 480 mm\nLd = 777 mm governs → provide 780 mm", r: "IS 456 Cl. 26.2.5.1" },
      { t: "Lap in direct tension", w: "Lap length = 2 Ld or 30 φ, whichever is greater\n2 Ld = 1 554 mm → provide 1 560 mm\nThe straight length of the lap must not be less than 15 φ or 200 mm.", r: "IS 456 Cl. 26.2.5.1" },
      { t: "Lap in compression (column bars)", w: "Lap length = Ld in compression or 24 φ, whichever is greater\n24 φ = 384 mm; Ld = 621 mm governs → provide 625 mm", r: "IS 456 Cl. 26.2.5.1" },
      { t: "Staggering", w: "Splices must be staggered by at least 30 φ = 480 mm, and not more than half the bars should be spliced at any one section where it can be avoided.", r: "IS 456 Cl. 26.2.5.1" },
    ],
    answer: "Flexural tension lap 780 mm; direct tension lap 1 560 mm; compression lap 625 mm; stagger splices by at least 480 mm.",
    watch: "A lap in direct tension — a tie member, a tank wall — is twice the flexural lap. Using the flexural value there halves the anchorage in exactly the member that can least afford it.",
    calc: "lap-length",
  },

  {
    id: "ex-deflection", code: "is456", cat: "RCC design", level: "Core",
    title: "Deflection — checking both serviceability limits",
    given: "A 7.5 m span beam. The computed final deflection including creep, shrinkage and temperature is 26 mm; the deflection occurring after the partitions and finishes were built is 18 mm.",
    steps: [
      { t: "Limit 1 — total deflection", w: "Final deflection below the level of the supports ≤ span/250\n= 7 500/250 = 30 mm\n26 mm < 30 mm ✓", r: "IS 456 Cl. 42.1(a)" },
      { t: "Limit 2 — post-construction deflection", w: "Deflection after partitions and finishes ≤ span/350 OR 20 mm, whichever is LESS\nspan/350 = 7 500/350 = 21.4 mm\n20 mm is the lesser → limit is 20 mm\n18 mm < 20 mm ✓", r: "IS 456 Cl. 42.1(b)" },
      { t: "Note where the cap takes over", w: "span/350 = 20 mm at a span of 7 000 mm.\nBeyond about 7 m span, the flat 20 mm cap always governs rather than the ratio — a long span gets no extra allowance.", r: "IS 456 Cl. 42.1(b)" },
      { t: "The usual route", w: "In practice Cl. 23.2 lets you satisfy both limits without calculating, by keeping within the span to effective depth ratio (7 cantilever, 20 simply supported, 26 continuous) modified for tension steel, compression steel and flanged sections.", r: "IS 456 Cl. 23.2" },
    ],
    answer: "Both limits are satisfied: 26 mm against 30 mm, and 18 mm against 20 mm. The post-construction limit is the tighter of the two here.",
    watch: "Two limits exist because two different people complain. span/250 is about the structure itself; span/350-or-20 mm protects the brittle partitions, glazing and cladding built afterwards — and they only care about movement AFTER they were installed.",
    calc: "span-depth",
  },

  /* ====================================================== FOUNDATION */
  {
    id: "ex-combined-footing", code: "is456", cat: "Foundation", level: "Advanced",
    title: "Combined footing — size it for uniform pressure",
    given: "Two columns 400 × 400 mm, 4 m apart. C1 (at the property line) carries 800 kN, C2 carries 1 200 kN. Safe bearing capacity 150 kN/m². Allow 10% of the column load for the footing self weight.",
    steps: [
      { t: "Total load and area required", w: "Column loads = 800 + 1 200 = 2 000 kN\nAdd 10% for self weight → 2 200 kN\nArea required = 2 200 / 150 = 14.67 m²", r: "IS 1904, IS 456 Cl. 34" },
      { t: "Locate the resultant", w: "Take moments about the centre of C1:\nx̄ = (1 200 × 4) / 2 000 = 2.4 m from C1", r: "—" },
      { t: "Set the footing so its centroid coincides with the resultant", w: "The property line is at the outer face of C1, i.e. 0.2 m outside its centre.\nLet the length be L, starting 0.2 m left of C1.\nCentroid at −0.2 + L/2 must equal 2.4 → L/2 = 2.6 → L = 5.2 m", r: "—" },
      { t: "Width", w: "B = 14.67 / 5.2 = 2.82 m → provide 2.9 m", r: "—" },
      { t: "Check the actual pressure", w: "Area provided = 5.2 × 2.9 = 15.08 m²\nPressure = 2 200 / 15.08 = 145.9 kN/m² < 150 ✓ and it is uniform, because the centroid and the resultant coincide.", r: "IS 456 Cl. 34.2" },
    ],
    answer: "Provide a combined footing 5.2 m × 2.9 m, with C1 at 0.2 m from one end. The bearing pressure is a uniform 146 kN/m².",
    watch: "The whole point of the geometry is to make the centroid of the footing coincide with the resultant of the column loads. If it does not, the pressure is trapezoidal and the far end is overstressed — which is exactly the case a rectangular footing was chosen to avoid.",
    calc: "footing-qty",
  },

  {
    id: "ex-punching", code: "is456", cat: "Foundation", level: "Advanced",
    title: "Footing — punching shear check",
    given: "Square footing 2.5 m × 2.5 m, overall depth 500 mm, effective depth d = 450 mm, column 400 × 400 mm, factored load Pu = 1 200 kN, M25 concrete.",
    steps: [
      { t: "Net upward pressure", w: "pu = Pu / area = 1 200 / (2.5 × 2.5) = 192 kN/m²", r: "IS 456 Cl. 34.2.1" },
      { t: "Critical perimeter", w: "The perimeter is at d/2 = 225 mm from every column face:\nside = 400 + 2 × 225 = 850 mm\nbo = 4 × 850 = 3 400 mm", r: "IS 456 Cl. 31.6.1" },
      { t: "Punching shear force", w: "Vu = total load − the load inside the perimeter\n= 1 200 − 192 × 0.85²\n= 1 200 − 192 × 0.7225\n= 1 200 − 138.7 = 1 061 kN", r: "IS 456 Cl. 31.6.2" },
      { t: "Punching shear stress", w: "τv = Vu / (bo × d) = 1 061 000 / (3 400 × 450)\n= 1 061 000 / 1 530 000 = 0.69 N/mm²", r: "IS 456 Cl. 31.6.2" },
      { t: "Permissible stress", w: "βc = short side / long side of the column = 400/400 = 1\nks = 0.5 + βc = 1.5, but not greater than 1 → ks = 1.0\nτc = ks × 0.25 √fck = 1.0 × 0.25 × √25 = 1.25 N/mm²", r: "IS 456 Cl. 31.6.3" },
      { t: "Verdict", w: "0.69 < 1.25 ✓ safe in punching shear.\nOne-way shear must still be checked separately on a full-width section at d = 450 mm from the column face.", r: "IS 456 Cl. 34.2.4" },
    ],
    answer: "τv = 0.69 N/mm² against a permissible 1.25 N/mm² — the 500 mm footing is safe in punching shear.",
    watch: "Deduct the load inside the critical perimeter. Using the full column load without that deduction overstates the punching force by 10–15% and pushes the depth up unnecessarily.",
    calc: "footing-qty",
  },

  {
    id: "ex-bearing", code: "is6403", cat: "Foundation", level: "Advanced",
    title: "Bearing capacity of a square footing",
    given: "Square footing 2 m × 2 m at a depth Df = 1.5 m in sand. c = 0, φ = 30°, γ = 18 kN/m³, water table well below the influence zone. Factor of safety 2.5.",
    steps: [
      { t: "Bearing capacity factors", w: "Nq = e^(π tanφ) · tan²(45 + φ/2)\n= e^(π × 0.5774) × tan²60°\n= 6.136 × 3 = 18.4\nNγ = 2 (Nq + 1) tanφ = 2 × 19.4 × 0.5774 = 22.4", r: "IS 6403 Cl. 4" },
      { t: "Shape factors (square footing)", w: "sq = 1.2, sγ = 0.8", r: "IS 6403 Cl. 4" },
      { t: "Depth factors", w: "√Nφ = tan(45 + φ/2) = tan 60° = 1.732\ndq = 1 + 0.1 (Df/B) √Nφ = 1 + 0.1 × (1.5/2) × 1.732 = 1.13\ndγ = dq = 1.13", r: "IS 6403 Cl. 4" },
      { t: "Net ultimate bearing capacity", w: "qnu = γ Df (Nq − 1) sq dq + 0.5 γ B Nγ sγ dγ\n= 18 × 1.5 × 17.4 × 1.2 × 1.13  +  0.5 × 18 × 2 × 22.4 × 0.8 × 1.13\n= 637.0 + 364.5\n= 1 001 kN/m²", r: "IS 6403 Cl. 4.2" },
      { t: "Net safe bearing capacity", w: "qns = qnu / FoS = 1 001 / 2.5 = 400 kN/m²", r: "IS 6403 Cl. 5" },
      { t: "The other half of the answer", w: "This is only the SHEAR criterion. The allowable bearing pressure is the LESSER of this value and the pressure that keeps settlement within the permissible limit — and in sand, settlement almost always governs.", r: "IS 8009 (Part 1); IS 1904" },
    ],
    answer: "Net safe bearing capacity ≈ 400 kN/m² on the shear criterion. The allowable pressure will be lower once the settlement check is applied.",
    watch: "A bearing capacity figure means nothing without stating the footing width and depth it was computed for — both Nγ and the depth factors depend on them. Quoting one 'SBC' for a whole site is a fiction.",
    calc: "",
  },

  {
    id: "ex-pile", code: "is2911", cat: "Foundation", level: "Advanced",
    title: "Pile capacity in clay by the static formula",
    given: "Bored cast in-situ pile, 500 mm diameter, 12 m long, in uniform clay with undrained shear strength cu = 50 kPa. Adhesion factor α = 0.5, bearing capacity factor Nc = 9. Factor of safety 2.5.",
    steps: [
      { t: "Shaft (skin friction) resistance", w: "Surface area = π D L = π × 0.5 × 12 = 18.85 m²\nQs = α cu × area = 0.5 × 50 × 18.85 = 471 kN", r: "IS 2911 (Part 1/Sec 2)" },
      { t: "Base (end bearing) resistance", w: "Base area Ap = π/4 × 0.5² = 0.1963 m²\nQp = Nc cu Ap = 9 × 50 × 0.1963 = 88 kN", r: "IS 2911 (Part 1/Sec 2)" },
      { t: "Ultimate capacity", w: "Qu = Qs + Qp = 471 + 88 = 559 kN\nNote how the shaft carries 84% of it — in clay this is a friction pile, not an end-bearing one.", r: "IS 2911 (Part 1)" },
      { t: "Safe capacity", w: "Qsafe = 559 / 2.5 = 224 kN per pile", r: "IS 2911 (Part 1)" },
      { t: "What still has to be checked", w: "• Group efficiency and group settlement — a group does not carry n × 224 kN\n• Negative skin friction if the ground around the pile is settling\n• Verification by an initial load test, and routine tests on production piles", r: "IS 2911 (Part 4)" },
    ],
    answer: "Ultimate capacity 559 kN, safe capacity about 224 kN per pile — of which the shaft contributes the large majority.",
    watch: "Never present a static-formula capacity as final. The soil parameters carry large uncertainty, which is exactly why IS 2911 (Part 4) makes the load test the real verification.",
    calc: "",
  },

  {
    id: "ex-settlement", code: "is8009-1", cat: "Foundation", level: "Advanced",
    title: "Consolidation settlement of a clay layer",
    given: "Normally consolidated clay layer 4 m thick, initial void ratio e₀ = 0.9, compression index Cc = 0.3, existing effective overburden pressure at mid-depth σ₀′ = 80 kPa, stress increase from the foundation Δσ = 40 kPa.",
    steps: [
      { t: "Formula for a normally consolidated clay", w: "Sc = (Cc · H / (1 + e₀)) × log₁₀ [(σ₀′ + Δσ) / σ₀′]", r: "IS 8009 (Part 1)" },
      { t: "Substitute", w: "Sc = (0.3 × 4 000 / (1 + 0.9)) × log₁₀ (120 / 80)\n= (1 200 / 1.9) × log₁₀ (1.5)\n= 631.6 × 0.1761", r: "—" },
      { t: "Result", w: "Sc = 111 mm", r: "—" },
      { t: "Compare with the permissible value", w: "IS 1904 tabulates permissible settlements by structure type and soil. 111 mm is large for an isolated footing on clay — and it is the DIFFERENTIAL settlement between this footing and its neighbours that will decide whether the structure is damaged.", r: "IS 1904" },
      { t: "How long will it take?", w: "This is the FINAL settlement. The time rate follows from the coefficient of consolidation cv and the drainage path; in a thick clay it can continue for years after handover.", r: "IS 2720 (Part 15)" },
    ],
    answer: "Final consolidation settlement ≈ 111 mm, developing over years rather than during construction.",
    watch: "The stress increase Δσ must be computed at the MID-DEPTH of the compressible layer, not at foundation level. Using the contact pressure instead overstates the settlement substantially.",
    calc: "",
  },

  /* ====================================================== STEEL DESIGN */
  {
    id: "ex-steel-comp", code: "is800", cat: "Steel design", level: "Advanced",
    title: "Steel column — design compressive strength",
    given: "ISMB 300 used as a column, effective length 4 m about both axes, E 250 steel. Section properties: A = 5 626 mm², rzz = 123.7 mm, ryy = 28.4 mm.",
    steps: [
      { t: "Governing slenderness", w: "λ about the minor axis = KL/ryy = 4 000 / 28.4 = 140.8\n(about the major axis it is only 4 000/123.7 = 32.3, so the minor axis governs)\nCheck against the limit of 180 for a member in compression from dead and imposed load ✓", r: "IS 800 Cl. 7.2, Cl. 3.8" },
      { t: "Buckling class", w: "For a rolled I-section with h/bf = 300/140 = 2.14 > 1.2 and tf = 12.4 mm ≤ 40 mm:\nbuckling about y-y → class b → imperfection factor α = 0.34", r: "IS 800 Table 10" },
      { t: "Non-dimensional slenderness", w: "fcc = π² E / λ² = π² × 200 000 / 140.8² = 1 974 000 / 19 825 = 99.6 N/mm²\nλ̄ = √(fy / fcc) = √(250 / 99.6) = 1.584", r: "IS 800 Cl. 7.1.2.1" },
      { t: "Stress reduction factor", w: "φ = 0.5 [1 + α(λ̄ − 0.2) + λ̄²]\n= 0.5 [1 + 0.34 × 1.384 + 2.510] = 1.990\nχ = 1 / [φ + √(φ² − λ̄²)] = 1 / [1.990 + √(3.960 − 2.510)]\n= 1 / (1.990 + 1.204) = 0.313", r: "IS 800 Cl. 7.1.2.1" },
      { t: "Design compressive stress and strength", w: "fcd = χ fy / γm0 = 0.313 × 250 / 1.10 = 71.2 N/mm²\nPd = Ae × fcd = 5 626 × 71.2 = 400 600 N = 401 kN", r: "IS 800 Cl. 7.1.2" },
    ],
    answer: "Design compressive strength ≈ 401 kN — only 29% of the squash load (5 626 × 250/1.1 = 1 279 kN), because buckling about the weak axis dominates.",
    watch: "Always use the smaller radius of gyration unless the member is genuinely restrained about that axis. A single intermediate brace about the minor axis here would halve λ and roughly double the capacity — far cheaper than a bigger section.",
    calc: "",
  },

  {
    id: "ex-steel-beam", code: "is800", cat: "Steel design", level: "Core",
    title: "Laterally supported beam — moment capacity",
    given: "ISMB 400 in E 250 steel, laterally supported throughout, Class 1 (plastic) section. Ze = 1 022.9 × 10³ mm³, Zp = 1 176.2 × 10³ mm³.",
    steps: [
      { t: "Design bending strength", w: "Md = βb Zp fy / γm0, with βb = 1.0 for a Class 1 or 2 section\n= 1.0 × 1 176 200 × 250 / 1.10\n= 294 050 000 / 1.10 = 267.3 kN·m", r: "IS 800 Cl. 8.2.1.2" },
      { t: "Upper limit check", w: "Md must not exceed 1.2 Ze fy / γm0 (to limit deformation at service load)\n= 1.2 × 1 022 900 × 250 / 1.10 = 279.0 kN·m\n267.3 < 279.0 ✓ so the plastic value stands.", r: "IS 800 Cl. 8.2.1.2" },
      { t: "If the section had been Class 3", w: "βb would be Ze/Zp = 1 022.9/1 176.2 = 0.870\nMd = 0.870 × 1 176 200 × 250/1.10 = 232.5 kN·m — about 13% less, purely from classification.", r: "IS 800 Cl. 8.2.1.2" },
      { t: "Shear interaction", w: "Vd for ISMB 400 = 467 kN. If the coexisting shear exceeds 0.6 × 467 = 280 kN, this moment capacity must be reduced.", r: "IS 800 Cl. 9.2" },
    ],
    answer: "Design bending strength Md = 267.3 kN·m, within the 279.0 kN·m upper limit.",
    watch: "Classification comes before any strength calculation. The same rolled section can lose over 10% of its capacity by falling from Class 2 to Class 3 — which happens when you go up a steel grade, because ε falls.",
    calc: "",
  },

  {
    id: "ex-steel-highshear", code: "is800", cat: "Steel design", level: "Advanced",
    title: "Steel beam — high shear reduces the moment capacity",
    given: "ISMB 400 in E 250 (depth 400 mm, tw = 8.9 mm, bf = 140 mm, tf = 16 mm). Md = 267.3 kN·m from the previous example. The factored shear at the section is Vu = 350 kN.",
    steps: [
      { t: "Design shear strength", w: "Av = h × tw = 400 × 8.9 = 3 560 mm²\nVn = Av fyw / √3 = 3 560 × 250 / 1.732 = 513.8 kN\nVd = Vn / γm0 = 513.8 / 1.10 = 467 kN", r: "IS 800 Cl. 8.4" },
      { t: "Is this high shear?", w: "0.6 Vd = 0.6 × 467 = 280 kN\nVu = 350 kN > 280 kN → YES, the moment capacity must be reduced.", r: "IS 800 Cl. 9.2" },
      { t: "Reduction factor", w: "β = (2 V / Vd − 1)²\n= (2 × 350 / 467 − 1)²\n= (1.499 − 1)² = 0.249", r: "IS 800 Cl. 9.2.2" },
      { t: "Plastic moment of the flanges alone", w: "Zp (flanges) = 2 × (bf × tf) × (D − tf)/2\n= 2 × (140 × 16) × (400 − 16)/2\n= 2 × 2 240 × 192 = 860 160 mm³\nMfd = 860 160 × 250 / 1.10 = 195.5 kN·m", r: "IS 800 Cl. 9.2.2" },
      { t: "Reduced moment capacity", w: "Mdv = Md − β (Md − Mfd)\n= 267.3 − 0.249 × (267.3 − 195.5)\n= 267.3 − 17.9 = 249.4 kN·m", r: "IS 800 Cl. 9.2.2" },
    ],
    answer: "With Vu = 350 kN the moment capacity falls from 267.3 to 249.4 kN·m — a 7% reduction.",
    watch: "The web carries the shear and the flanges carry most of the moment, which is why the reduction is bounded by Mfd. Below 0.6 Vd there is no reduction at all — the interaction switches on abruptly at that threshold.",
    calc: "",
  },

  {
    id: "ex-weld", code: "is800", cat: "Steel design", level: "Core",
    title: "Fillet weld — length required for a lap joint",
    given: "Two plates 100 mm wide × 10 mm thick in E 250, lapped and welded with 6 mm fillet welds. Factored tensile load 200 kN. Shop welding (γmw = 1.25), fu = 410 N/mm².",
    steps: [
      { t: "Effective throat thickness", w: "For a fillet between surfaces at 90°, throat = 0.7 × size\n= 0.7 × 6 = 4.2 mm", r: "IS 800 Cl. 10.5.3" },
      { t: "Design strength of the weld", w: "fwd = fu / (√3 × γmw)\n= 410 / (1.732 × 1.25)\n= 410 / 2.165 = 189.4 N/mm²", r: "IS 800 Cl. 10.5.7" },
      { t: "Strength per millimetre of weld", w: "= throat × fwd = 4.2 × 189.4 = 795.5 N per mm run", r: "—" },
      { t: "Effective length required", w: "L eff = 200 000 / 795.5 = 251 mm total", r: "—" },
      { t: "Actual length to be provided", w: "Actual length = effective length + 2 × weld size (for the incomplete ends)\n= 251 + 2 × 6 = 263 mm\nProvide 135 mm of weld along each side of the lap.", r: "IS 800 Cl. 10.5.4" },
      { t: "Check the weld size against the plate", w: "Minimum fillet size for a 10 mm plate is 3 mm; maximum size along the edge of a plate is thickness − 1.5 mm = 8.5 mm. A 6 mm fillet is within both. ✓", r: "IS 800 Cl. 10.5.2" },
    ],
    answer: "Provide 6 mm fillet welds, 135 mm long on each side of the lap (263 mm total actual length).",
    watch: "The effective length is the actual length less twice the weld size. Forgetting that deduction leaves the joint a few percent short — and the ends of a fillet weld are exactly where a crack starts.",
    calc: "",
  },

  {
    id: "ex-blockshear", code: "is800", cat: "Steel design", level: "Advanced",
    title: "Block shear check of a bolted angle",
    given: "ISA 75 × 75 × 8 connected through one leg by 3 bolts of 20 mm at 50 mm pitch, end distance 35 mm, edge distance 35 mm, hole diameter 22 mm, E 250 steel (fy = 250, fu = 410 N/mm²).",
    steps: [
      { t: "Shear areas along the bolt line", w: "Gross: Avg = (2 × 50 + 35) × 8 = 135 × 8 = 1 080 mm²\nNet: deduct 2.5 hole diameters\nAvn = (135 − 2.5 × 22) × 8 = (135 − 55) × 8 = 640 mm²", r: "IS 800 Cl. 6.4.1" },
      { t: "Tension areas across the end", w: "Gross: Atg = 35 × 8 = 280 mm²\nNet: deduct half a hole\nAtn = (35 − 0.5 × 22) × 8 = 24 × 8 = 192 mm²", r: "IS 800 Cl. 6.4.1" },
      { t: "Mode 1 — gross shear yield + net tension rupture", w: "Tdb1 = Avg fy / (√3 γm0) + 0.9 Atn fu / γm1\n= 1 080 × 250 / (1.732 × 1.10) + 0.9 × 192 × 410 / 1.25\n= 141 732 + 56 678\n= 198 410 N = 198.4 kN", r: "IS 800 Cl. 6.4.1" },
      { t: "Mode 2 — net shear rupture + gross tension yield", w: "Tdb2 = 0.9 Avn fu / (√3 γm1) + Atg fy / γm0\n= 0.9 × 640 × 410 / (1.732 × 1.25) + 280 × 250 / 1.10\n= 109 081 + 63 636\n= 172 717 N = 172.7 kN", r: "IS 800 Cl. 6.4.1" },
      { t: "Block shear capacity", w: "Take the LESSER of the two: Tdb = 172.7 kN", r: "IS 800 Cl. 6.4" },
    ],
    answer: "Block shear capacity 172.7 kN. This must be compared with the gross section yield and net section rupture capacities — the smallest of the three governs the member.",
    watch: "Block shear is the check that did not exist in IS 800:1984, and it frequently governs a short end connection with few bolts. Increasing the end distance helps it far more than adding another bolt does.",
    calc: "",
  },

  /* ====================================================== EARTHQUAKE */
  {
    id: "ex-drift", code: "is1893-1", cat: "Earthquake", level: "Core",
    title: "Storey drift check",
    given: "A five-storey frame with a storey height of 3.2 m. Under the design lateral force, the lateral displacement at the third floor is 27 mm and at the second floor 18 mm.",
    steps: [
      { t: "Storey drift", w: "Drift = displacement at the upper level − displacement at the lower level\n= 27 − 18 = 9 mm", r: "IS 1893 (Part 1) Cl. 7.11.1" },
      { t: "Permissible drift", w: "0.004 × storey height = 0.004 × 3 200 = 12.8 mm", r: "IS 1893 (Part 1) Cl. 7.11.1" },
      { t: "Verdict", w: "9 mm < 12.8 mm ✓ the storey satisfies the drift limit.", r: "—" },
      { t: "Important detail", w: "The drift check is made with the design lateral force WITHOUT any load factor — do not use the factored displacements from the strength combinations.", r: "IS 1893 (Part 1) Cl. 7.11.1" },
      { t: "Why the limit exists", w: "Drift damages the non-structural elements — infill walls, glazing, cladding, services — long before it threatens the frame. It also drives P-delta effects in tall buildings.", r: "—" },
    ],
    answer: "Storey drift 9 mm against a permissible 12.8 mm — satisfactory.",
    watch: "Using the factored (1.5 × ) displacements against the 0.004 h limit is the commonest mistake here, and it makes a perfectly adequate frame appear to fail.",
    calc: "",
  },

  {
    id: "ex-confining", code: "is13920", cat: "Earthquake", level: "Core",
    title: "Special confining reinforcement in a column",
    given: "Column 450 × 450 mm, clear height 3 m, M25 concrete, Fe 500 steel, 8 mm diameter hoops.",
    steps: [
      { t: "Length of the confined zone lo", w: "lo is the LARGEST of:\n• the larger lateral dimension = 450 mm\n• one sixth of the clear span = 3 000/6 = 500 mm\n• 450 mm\n→ lo = 500 mm at each end of the column", r: "IS 13920 Cl. 8.1" },
      { t: "Spacing of confining hoops", w: "Spacing must not exceed one quarter of the minimum member dimension\n= 450/4 = 112.5 mm\nand must not be less than 75 mm nor more than 100 mm\n→ provide 8 mm hoops @ 100 mm c/c over lo", r: "IS 13920 Cl. 8.1" },
      { t: "Outside the confined zone", w: "Over the remaining height the ordinary tie rules of IS 456 Cl. 26.5.3.2 apply: spacing not more than the least lateral dimension (450), 16 times the smallest longitudinal bar diameter, or 300 mm.", r: "IS 456 Cl. 26.5.3.2" },
      { t: "Through the joint", w: "The column hoops are carried THROUGH the beam-column joint. This is the hardest part to build, because the beam bars pass through the same space.", r: "IS 13920 Cl. 9" },
      { t: "Why it matters", w: "The confined zone is where the plastic hinge will form. Confinement holds the core together so it can rotate through many cycles instead of crushing and losing its axial capacity.", r: "IS 13920 Cl. 8" },
    ],
    answer: "Provide 8 mm confining hoops at 100 mm centres over a length of 500 mm at each end of the column, continued through the joint.",
    watch: "Draw the joint at full size before issuing the drawing. If the hoops and four layers of beam bars will not physically fit, the detail gets quietly abandoned on site — and the ductility the design assumed disappears with it.",
    calc: "",
  },

  /* ====================================================== SOIL */
  {
    id: "ex-soilclass", code: "is1498", cat: "Soil & testing", level: "Core",
    title: "Classify a soil from laboratory data",
    given: "A soil sample: 62% passes the 75 micron sieve, liquid limit wL = 55%, plastic limit wP = 25%.",
    steps: [
      { t: "Coarse or fine grained?", w: "62% passes 75 µ, i.e. more than half passes\n→ FINE GRAINED soil, classified on the plasticity chart.", r: "IS 1498 Cl. 3" },
      { t: "Plasticity index", w: "Ip = wL − wP = 55 − 25 = 30%", r: "IS 2720 (Part 5)" },
      { t: "Position relative to the A-line", w: "A-line: Ip = 0.73 (wL − 20) = 0.73 × (55 − 20) = 0.73 × 35 = 25.6\nActual Ip = 30 > 25.6 → the point lies ABOVE the A-line → it is a CLAY, not a silt.", r: "IS 1498 plasticity chart" },
      { t: "Low or high plasticity?", w: "wL = 55% > 50% → HIGH plasticity", r: "IS 1498 plasticity chart" },
      { t: "Group symbol", w: "Above the A-line + high liquid limit → CH", r: "IS 1498" },
    ],
    answer: "The soil classifies as CH — inorganic clay of high plasticity.",
    watch: "CH is the symbol for black cotton soil. It swells when wet and shrinks when dry, so a shallow foundation inside the seasonal moisture zone will be lifted and dropped every year — check the free swell index next (IS 2720 Part 40).",
    calc: "",
  },

  {
    id: "ex-fielddensity", code: "is2720", cat: "Soil & testing", level: "Core",
    title: "Field density by core cutter — is the fill compacted?",
    given: "Core cutter of 100 mm internal diameter and 130 mm height. Mass of wet soil in the cutter = 1 950 g. Water content 12%. Maximum dry density from the standard Proctor test = 1.80 g/cm³. Specification requires 95% compaction.",
    steps: [
      { t: "Volume of the core cutter", w: "V = π/4 × d² × h = 0.7854 × 100² × 130\n= 1 021 020 mm³ = 1 021 cm³", r: "IS 2720 (Part 29)" },
      { t: "Bulk density", w: "γ bulk = mass / volume = 1 950 / 1 021 = 1.910 g/cm³", r: "IS 2720 (Part 29)" },
      { t: "Dry density", w: "γ dry = γ bulk / (1 + w) = 1.910 / 1.12 = 1.705 g/cm³", r: "IS 2720 (Part 29)" },
      { t: "Degree of compaction", w: "= γ dry (field) / γ dry,max (lab) × 100\n= 1.705 / 1.80 × 100 = 94.7%", r: "IS 2720 (Parts 7 and 29)" },
      { t: "Verdict", w: "94.7% < 95% required → the layer FAILS, though only just. Re-roll and re-test; check the moisture content is near the optimum.", r: "—" },
    ],
    answer: "Field dry density 1.705 g/cm³, i.e. 94.7% compaction — marginally short of the 95% specified.",
    watch: "State which Proctor the percentage is against. 95% of MODIFIED Proctor is a much denser fill than 95% of STANDARD Proctor, and a specification that does not say which is unenforceable.",
    calc: "",
  },

  /* ====================================================== HIGHWAY */
  {
    id: "ex-msa", code: "irc37", cat: "Highway", level: "Advanced",
    title: "Design traffic for a flexible pavement (msa)",
    given: "Initial commercial vehicles per day in both directions = 1 500. Traffic growth rate 6% per year. Construction period 2 years. Design life 15 years. Lane distribution factor D = 0.75 (two-lane single carriageway). Vehicle damage factor F = 2.5.",
    steps: [
      { t: "Traffic at the time of completion", w: "A = P (1 + r)^x, where x is the construction period\n= 1 500 × 1.06²\n= 1 500 × 1.1236 = 1 685 CVPD", r: "IRC:37" },
      { t: "Growth factor over the design life", w: "[(1 + r)ⁿ − 1] / r = (1.06¹⁵ − 1) / 0.06\n= (2.3966 − 1) / 0.06 = 23.28", r: "IRC:37" },
      { t: "Cumulative standard axles", w: "N = 365 × A × [(1+r)ⁿ − 1]/r × D × F\n= 365 × 1 685 × 23.28 × 0.75 × 2.5", r: "IRC:37" },
      { t: "Evaluate", w: "365 × 1 685 = 615 025\n× 23.28 = 14 317 782\n× 0.75 = 10 738 336\n× 2.5 = 26 845 841 standard axles", r: "—" },
      { t: "Design traffic", w: "N = 26.8 msa → design the pavement for 30 msa from the catalogue.", r: "IRC:37" },
    ],
    answer: "Design traffic ≈ 26.8 msa; adopt the 30 msa pavement composition for the relevant subgrade CBR.",
    watch: "The vehicle damage factor dominates this calculation. Damage rises roughly as the FOURTH power of axle load, so assuming F = 2.5 where the real overloaded traffic gives 4.5 nearly doubles the design traffic — and the pavement fails years early.",
    calc: "",
  },

  {
    id: "ex-superelevation", code: "irc73", cat: "Highway", level: "Core",
    title: "Superelevation on a highway curve",
    given: "Design speed 80 km/h, horizontal curve radius 300 m, plain terrain (maximum superelevation 7%), maximum coefficient of lateral friction 0.15.",
    steps: [
      { t: "Superelevation for 75% of design speed", w: "IRC first assumes 75% of the design speed is balanced by superelevation alone, with no friction:\ne = (0.75 V)² / (127 R) = 60² / (127 × 300)\n= 3 600 / 38 100 = 0.0945 → 9.45%", r: "IRC:73" },
      { t: "Compare with the maximum", w: "9.45% > 7% maximum for plain terrain\n→ limit the superelevation to e = 7% = 0.07", r: "IRC:73" },
      { t: "Check the friction required at full design speed", w: "e + f = V² / (127 R) = 80² / (127 × 300)\n= 6 400 / 38 100 = 0.168\nf = 0.168 − 0.07 = 0.098", r: "IRC:73" },
      { t: "Is that acceptable?", w: "f = 0.098 < 0.15 permitted ✓\nThe curve is safe at the full design speed with 7% superelevation.", r: "IRC:73" },
      { t: "If f had exceeded 0.15", w: "The radius would have to be increased, or the design speed at that curve restricted and signposted.", r: "IRC:73" },
    ],
    answer: "Provide 7% superelevation. The friction demand at design speed is 0.098, comfortably within the permitted 0.15.",
    watch: "Superelevation is capped to protect SLOW and stationary vehicles, which tend to slide towards the inner edge on a steeply banked curve — not because fast vehicles could not use more.",
    calc: "",
  },

  /* ====================================================== SURVEYING */
  {
    id: "ex-levelling", code: "surv-ref", cat: "Surveying", level: "Core",
    title: "Levelling — reduce the levels and apply the check",
    given: "Readings from a benchmark of RL 100.000 m:\nBS 1.485 (on BM), IS 2.130, IS 1.875, FS 0.985 (change point),\nBS 2.345 (on CP), IS 1.560, FS 0.875 (last point).",
    steps: [
      { t: "First instrument position", w: "HI₁ = RL(BM) + BS = 100.000 + 1.485 = 101.485", r: "Height of instrument method" },
      { t: "Reduce the intermediate sights", w: "RL₁ = 101.485 − 2.130 = 99.355\nRL₂ = 101.485 − 1.875 = 99.610", r: "—" },
      { t: "Change point", w: "RL(CP) = 101.485 − 0.985 = 100.500", r: "—" },
      { t: "Second instrument position", w: "HI₂ = 100.500 + 2.345 = 102.845\nRL₃ = 102.845 − 1.560 = 101.285\nRL(last) = 102.845 − 0.875 = 101.970", r: "—" },
      { t: "Arithmetic check", w: "ΣBS = 1.485 + 2.345 = 3.830\nΣFS = 0.985 + 0.875 = 1.860\nΣBS − ΣFS = 1.970\nLast RL − First RL = 101.970 − 100.000 = 1.970 ✓", r: "Standard levelling check" },
    ],
    answer: "Reduced levels: 99.355, 99.610, 100.500 (CP), 101.285 and 101.970 m. The arithmetic check closes exactly.",
    watch: "The height of instrument check verifies only the back sights and fore sights — an error in an INTERMEDIATE sight passes it unnoticed. The rise and fall method checks every reading, which is why it is preferred for important work.",
    calc: "level-hi",
  },

  {
    id: "ex-simpson", code: "surv-ref", cat: "Surveying", level: "Core",
    title: "Area from offsets by Simpson's rule",
    given: "Offsets measured at 5 m intervals along a chain line: 2.5, 3.8, 4.6, 5.2, 4.9, 4.1, 3.0 metres.",
    steps: [
      { t: "Check the rule can be applied", w: "7 offsets → 6 intervals. Simpson's rule needs an EVEN number of intervals ✓", r: "Simpson's one-third rule" },
      { t: "Group the ordinates", w: "First and last: 2.5 and 3.0\nOdd-position ordinates (2nd, 4th, 6th): 3.8 + 5.2 + 4.1 = 13.1\nEven-position ordinates (3rd, 5th): 4.6 + 4.9 = 9.5", r: "—" },
      { t: "Apply the formula", w: "A = (d/3) [first + last + 4 × (odd sum) + 2 × (even sum)]\n= (5/3) [2.5 + 3.0 + 4 × 13.1 + 2 × 9.5]", r: "Simpson's one-third rule" },
      { t: "Evaluate", w: "= (5/3) [5.5 + 52.4 + 19.0]\n= (5/3) × 76.9\n= 128.2 m²", r: "—" },
      { t: "Compare with the trapezoidal rule", w: "A = d [(first + last)/2 + sum of the rest]\n= 5 [(2.5 + 3.0)/2 + (3.8 + 4.6 + 5.2 + 4.9 + 4.1)]\n= 5 [2.75 + 22.6] = 126.75 m²\nSimpson's rule is higher because it fits a curve through the boundary rather than straight chords.", r: "—" },
    ],
    answer: "Area by Simpson's rule = 128.2 m² (against 126.8 m² by the trapezoidal rule).",
    watch: "With an ODD number of intervals, Simpson's rule cannot be applied to the whole set. Apply it to the even part and compute the last strip separately by the trapezoidal rule — do not simply drop an offset.",
    calc: "area-offsets",
  },

  /* ====================================================== ESTIMATION */
  {
    id: "ex-brickwork-qty", code: "is1200-3", cat: "Estimation", level: "Core",
    title: "Brickwork — bricks, cement and sand for a wall",
    given: "Wall 5 m long × 3 m high × 230 mm thick with one door opening 1.0 m × 2.1 m. Modular bricks 190 × 90 × 90 mm with 10 mm joints. Mortar 1:6.",
    steps: [
      { t: "Net volume of brickwork", w: "Gross = 5 × 3 × 0.23 = 3.45 m³\nDeduct door = 1.0 × 2.1 × 0.23 = 0.483 m³\nNet = 3.45 − 0.483 = 2.97 m³", r: "IS 1200 (Part 3)" },
      { t: "Number of bricks", w: "With joints, each brick occupies 200 × 100 × 100 = 0.002 m³\n→ 500 bricks per m³\nBricks = 2.97 × 500 = 1 485\nAdd 5% for breakage and wastage → 1 560 bricks", r: "—" },
      { t: "Volume of mortar", w: "Volume of bricks alone = 1 485 × (0.19 × 0.09 × 0.09) = 1 485 × 0.001539 = 2.286 m³\nWet mortar = 2.97 − 2.286 = 0.684 m³\nDry volume = 0.684 × 1.33 = 0.910 m³", r: "—" },
      { t: "Cement and sand for 1:6 mortar", w: "Total parts = 1 + 6 = 7\nCement = 0.910 / 7 = 0.130 m³ = 0.130 × 1 440 = 187 kg = 3.75 bags\nSand = 6 × 0.130 = 0.780 m³", r: "IS 2250" },
    ],
    answer: "For 2.97 m³ of brickwork: about 1 560 bricks, 3.75 bags of cement (187 kg) and 0.78 m³ of sand.",
    watch: "The 1.33 dry-volume factor accounts for the voids in loose sand — mortar always shrinks in volume when mixed. Omitting it under-orders the cement and sand by a third.",
    calc: "brickwork",
  },

  {
    id: "ex-slab-qty", code: "is1200-2", cat: "Estimation", level: "Core",
    title: "Slab — concrete and steel quantities",
    given: "Slab 5 m × 4 m × 150 mm in M20 nominal mix (1 : 1.5 : 3). Main steel 10 mm @ 150 c/c across the 4 m span; distribution steel 8 mm @ 200 c/c.",
    steps: [
      { t: "Volume of concrete", w: "V = 5 × 4 × 0.15 = 3.00 m³", r: "IS 1200 (Part 2)" },
      { t: "Dry volume and ingredients", w: "Dry volume = 3.00 × 1.54 = 4.62 m³\nTotal parts = 1 + 1.5 + 3 = 5.5\nCement = 4.62 × 1/5.5 = 0.840 m³ = 0.840 × 1 440 = 1 210 kg = 24.2 bags\nSand   = 4.62 × 1.5/5.5 = 1.26 m³\nAggregate = 4.62 × 3/5.5 = 2.52 m³", r: "IS 456 Table 9" },
      { t: "Number of bars", w: "Main (10 mm @ 150, running the 4 m way, spread over the 5 m length):\nn = 5 000/150 + 1 = 34.3 → 35 bars of 4.0 m = 140 m\nDistribution (8 mm @ 200, running the 5 m way, over the 4 m width):\nn = 4 000/200 + 1 = 21 bars of 5.0 m = 105 m", r: "IS 456 Cl. 26.3.3" },
      { t: "Weight of steel", w: "Mass per metre = d²/162\n10 mm: 100/162 = 0.617 kg/m → 140 × 0.617 = 86.4 kg\n8 mm : 64/162  = 0.395 kg/m → 105 × 0.395 = 41.5 kg\nTotal = 127.9 kg ≈ 128 kg", r: "IS 1786" },
      { t: "Sanity check", w: "128 kg for 3.00 m³ = 42.6 kg/m³.\nA typical building slab runs 45–60 kg/m³, so this is a lightly reinforced slab — plausible for a 4 m span.", r: "—" },
    ],
    answer: "3.00 m³ of concrete (24.2 bags of cement, 1.26 m³ sand, 2.52 m³ aggregate) and about 128 kg of reinforcement.",
    watch: "The 1.54 dry-volume factor for concrete (and 1.52–1.57 depending on the source) is what converts wet volume to the loose materials you must actually order. Bar bending laps, chairs and wastage are additional.",
    calc: "slab-qty",
  },

  {
    id: "ex-plaster-qty", code: "is1200-12", cat: "Estimation", level: "Core",
    title: "Plaster and paint for a room",
    given: "Room 4 m × 3 m, height 3 m. One door 1.0 × 2.1 m and two windows 1.2 × 1.2 m. Internal plaster 12 mm in 1:6 mortar on walls; two coats of emulsion on walls and ceiling; paint covering capacity 10 m² per litre per coat.",
    steps: [
      { t: "Wall area", w: "Perimeter = 2 (4 + 3) = 14 m\nGross wall area = 14 × 3 = 42.0 m²\nDeduct door = 1.0 × 2.1 = 2.10 m²\nDeduct windows = 2 × 1.2 × 1.2 = 2.88 m²\nNet wall area = 42.0 − 4.98 = 37.02 m²", r: "IS 1200 (Part 12)" },
      { t: "Plaster mortar volume", w: "Wet volume = 37.02 × 0.012 = 0.444 m³\nDry volume = 0.444 × 1.33 = 0.591 m³", r: "—" },
      { t: "Cement and sand (1:6)", w: "Cement = 0.591 / 7 = 0.0844 m³ = 0.0844 × 1 440 = 122 kg = 2.43 bags\nSand = 6 × 0.0844 = 0.507 m³", r: "IS 2250" },
      { t: "Paintable area", w: "Walls 37.02 + ceiling (4 × 3) 12.00 = 49.02 m²", r: "IS 1200 (Part 11)" },
      { t: "Paint quantity", w: "Two coats at 10 m² per litre per coat:\n= 49.02 × 2 / 10 = 9.8 litres → order 10 litres", r: "IS 15489" },
    ],
    answer: "Plaster: 2.43 bags of cement and 0.51 m³ of sand for 37 m². Paint: about 10 litres for two coats over 49 m².",
    watch: "Covering capacity on the tin assumes a smooth, primed surface. A rough or porous wall takes appreciably more, and the first coat on new plaster always takes more than the second — order with a margin.",
    calc: "plaster",
  }

);
