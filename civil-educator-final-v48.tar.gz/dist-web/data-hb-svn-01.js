/* Surveying class notes — introduction & fundamentals, classification, scales, shrinkage, vernier, notes p.1 and p.98–111 — inserted into sv chapter 1 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "sv"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 1; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- syllabus + definition */
    {
      n: "",
      title: "Notes — syllabus, definition and objectives of surveying",
      hi: "पाठ्यक्रम, परिभाषा और सर्वेक्षण के उद्देश्य",
      blocks: [
        { k: "h", t: "📘 Notes — p.1 (Syllabus)" },
        { k: "list", items: [
          "1. Introduction &amp; fundamentals of surveying · 2. Linear measurements (Chain survey) · 3. Angular measurements (Compass survey) — horizontal angles · 4. Traversing · 5. Theodolite · 6. Levelling · 7. Trigonometric survey · 8. Tacheometric survey · 9. Contours · 10. Plane table survey · 11. Theory of errors · 12. Field astronomy · 13. Photogrammetry · 14. Area &amp; volume measurement · 15. Curves · 16. GPS – GIS (p.1)",
        ] },
        { k: "h", t: "📘 Notes — p.98 (Ch-1: Introduction & fundamentals of survey)" },
        { k: "def", term: "Surveying", t: "The method of making measurements of the <b>relative positions</b> of natural &amp; man-made features on the earth's surface, and presenting it <b>graphically or numerically</b>. (p.98)" },
        { k: "p", t: "The common methods of presentation are by means of <b>Plan</b> &amp; <b>Map</b>. Both plan and map are graphical representations of the features on the earth's surface (on a horizontal plane). (p.98)" },
        { k: "cmp", t: "Plan vs Map (p.98)", cols: ["Scale"], rows: [
          ["Plan", "<b>Large</b> scale representation"],
          ["Map", "<b>Small</b> scale representation"],
        ] },
        { k: "p", t: "Height information can be added either as <b>spot heights</b> (individual height of a point) or as <b>contours</b>. (p.98)" },
        { k: "h", t: "Objectives of surveying (p.98)" },
        { k: "list", items: [
          "1) To measure relative positions of points.",
          "2) To lay out &amp; mark out the positions of a proposed structure on the ground.",
          "3) To determine area, volume &amp; other quantities. (p.98)",
        ] },
        { k: "note", t: "The name given to the shape of the earth is <b>GEOID</b>. (p.98)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Notes ki definition ke do hisse hain — <b>measure karna</b> (relative positions) aur <b>present karna</b> (plan/map par, ya numbers/coordinates mein). Objective 2 — layout &amp; markout — wahi 'setting out' hai jo section 1.1 mein alag job ke roop mein samjhaya gaya hai: drawing se ground par position utaarna." },
        { k: "p", t: "Plan aur map dono horizontal plane par drawing hain; farak sirf scale ka hai. Plan bade scale par (chhota area, zyada detail — jaise ek building plot), map chhote scale par (bada area, kam detail — jaise ek district). Height alag se dikhani padti hai: ya to har point par spot height likho, ya contour lines kheencho." },
        { k: "trap", t: "'Large scale' ka matlab bada area <b>nahi</b> hai. Large scale = bada RF (jaise 1 : 500) = chhota area, zyada detail = <b>plan</b>. Small scale = chhota RF (jaise 1 : 50,000) = bada area = <b>map</b>. MCQ mein ye ulta karke poochha jaata hai." },
        { k: "real", t: "Building ke liye site plan (large scale) banta hai, jab ki highway alignment choose karne ke liye pehle chhote scale ka map dekha jaata hai — phir chosen strip ka large scale plan banta hai." },
      ],
    },

    /* ---------------------------------------------------------- plane vs geodetic */
    {
      n: "",
      title: "Notes — plane surveying vs geodetic survey",
      hi: "समतल सर्वेक्षण बनाम भूगणितीय सर्वेक्षण",
      blocks: [
        { k: "h", t: "📘 Notes — p.99–100 (Classification of survey)" },
        { k: "def", term: "1) Plane surveying", t: "In plane surveying we <b>neglect the effect of curvature</b> of the earth's surface, and the plotted measurements are actually projected on a <b>horizontal plane</b>. (p.99)" },
        { k: "def", term: "Horizontal plane", t: "A plane which is <b>tangential to the earth's surface</b> at that point and <b>normal to the plumb line</b>. (p.99)" },
        { k: "def", term: "2) Geodetic survey", t: "Done for a <b>large area</b>, in which the <b>curvature of the earth is considered</b>, as there is a significant difference between the curved surface and the corresponding plane surface when the area is large. Geodetic survey is basically used to <b>establish control points</b>, which serve as reference points for local surveys. Geodetic surveys are done by the <b>Survey of India</b>. (p.99)" },
        { k: "p", t: "As the shape of the earth's surface is considered to be spherical, measured distances on the earth's surface are actually curved; but if these distances are small compared with the radius of the earth, there is no significant difference between the curved distance and the corresponding straight line. Therefore, for a small area the curvature of the earth can be neglected. (p.99–100)" },
        { k: "p", t: "It is observed that if an <b>arc length is 18.5 km</b>, its corresponding chord length is about <b>1.52 cm too short</b>. (p.100)" },
        { k: "eq", expr: "AB(arc) − AB(chord) = 1.52 cm   (for arc AB = 18.5 km)", where: [
          ["AB(arc)", "distance along the curved earth surface"],
          ["AB(chord)", "straight-line distance between A and B"],
        ] },
        { k: "p", t: "For an area <b>up to 195.5 km²</b>, the discrepancy between spherical triangles and plane triangles is negligible or insignificant: (p.100)" },
        { k: "eq", expr: "Σ(θ1 + θ2 + θ3) − Σ(α1 + α2 + α3) = 1″   (area 195.5 km²)", where: [
          ["θ1, θ2, θ3", "angles of the spherical triangle ABC (at A, C, B)"],
          ["α1, α2, α3", "angles of the corresponding plane triangle (at A, C, B)"],
        ] },
        { k: "list", items: [
          "Figure (p.100), left: a large closed outline labelled “earth”. Inside it a spherical triangle with vertices A (top), B (bottom left), C (bottom right), its sides drawn as outward-curved arcs. At each vertex two angles are marked: the spherical angles θ₁ (at A), θ₂ (at C), θ₃ (at B), and the plane-triangle angles α₁ (at A), α₂ (at C), α₃ (at B).",
          "Figure (p.100), right: arc AB drawn above the straight chord AB, with A and B at the ends; caption: arc AB − chord AB = 1.52 cm. (p.100)",
        ] },
        { k: "note", t: "<b>Check:</b> the arc–chord difference is s³/(24R²). With s = 18.5 km and R = 6370 km: 18.5³ = 6331.6 km³, 24 × 6370² = 9.738 × 10⁸ km², difference = 6.5 × 10⁻⁶ km ≈ <b>6.5 mm</b>, not 1.52 cm. Textbook and question-bank statements of this figure vary (see section 1.4 of this chapter, which works the 18.2 km case to 6.2 mm); the formula gives a few millimetres. Learn the notes' figure for exam recall, but know the worked value." },
        { k: "note", t: "<b>Check:</b> the area that gives 1″ of spherical excess is R²/206265 = 6370²/206265 ≈ <b>196.7 km²</b>. The notes' 195.5 km² is the commonly quoted textbook figure and agrees to within about 1%." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Earth gol hai, lekin chhote area par woh flat jaisi hi lagti hai — jaise football par ek chhota stamp chipkao to stamp lagbhag flat rehta hai. Plane surveying yahi assumption leti hai: level line seedhi, plumb lines parallel. Jab area itna bada ho jaye ki curvature ka asar measurement ki accuracy se zyada ho jaye, tab geodetic survey chahiye." },
        { k: "p", t: "Notes ke do numbers isi baat ko prove karte hain: 18.5 km ke arc aur chord mein bahut chhota farak, aur 195.5 km² tak ke triangle mein spherical aur plane angles ke sum mein sirf 1″ ka farak. Dono itne chhote hain ki ordinary survey unhe detect hi nahi kar sakta — isliye neglect karna safe hai." },
        { k: "trap", t: "Plane surveying curvature ko sirf <b>plan</b> (horizontal positions) mein ignore karti hai. Levelling mein lambi sight par curvature aur refraction ka correction plane surveying mein bhi lagta hai — 'plane survey mein curvature kabhi consider nahi hota' likhna galat hai (section 1.4 ka note dekho)." },
        { k: "real", t: "Survey of India ke geodetic control points (triangulation stations / benchmarks) se hi local engineering surveys start hote hain — local plane survey unhe reference maan kar chalta hai." },
      ],
    },

    /* ---------------------------------------------------------- types of survey */
    {
      n: "",
      title: "Notes — types of survey by purpose and by instrument",
      hi: "उद्देश्य और उपकरण के आधार पर सर्वेक्षण के प्रकार",
      blocks: [
        { k: "h", t: "📘 Notes — p.101–104 (Types of survey)" },
        { k: "h", t: "A. On the basis of purpose" },
        { k: "def", term: "1) Topographical survey", t: "A survey used to plot or obtain a map showing details of <b>natural or man-made</b> structures, <b>including information about vertical elevation</b>. Scale of topographical survey is about <b>1 : 25,000 – 1 : 1,000,000</b>. (p.101)" },
        { k: "note", t: "The art of making topographical maps is called <b>Cartography</b>. (p.101)" },
        { k: "def", term: "2) Engineering survey", t: "Surveys which are used for engineering purposes. (p.101)" },
        { k: "cmp", t: "Engineering survey — scales (p.101)", cols: ["Scale"], rows: [
          ["Engineering survey (overall)", "1 : 50 – 1 : 50,000"],
          ["Building", "1 : 50 – 1 : 3,000"],
          ["Bridge &amp; other civil engineering works", "1 : 500 – 1 : 2,500"],
          ["Highways", "1 : 1,250 – 1 : 50,000"],
        ] },
        { k: "def", term: "3) Cadastral survey (ज़मीन, जायदाद)", t: "Used to demarcate (mark out) or distinguish between various properties, i.e. <b>property lines</b>. Scale → <b>1 : 1,000 – 1 : 5,000</b>. (p.102)" },
        { k: "def", term: "4) Hydrographic survey", t: "Surveys done <b>on or near water bodies</b>. (p.102)" },
        { k: "def", term: "5) Astronomic survey", t: "Used to determine <b>latitude, longitude, local time</b>, and also to determine the <b>absolute position</b> of a point on the earth's surface with the help of heavenly bodies. (p.102)" },
        { k: "def", term: "6) Geological survey", t: "Used to obtain information about the different strata (layers) of the earth's surface. (p.102)" },
        { k: "h", t: "B. On the basis of instrument used" },
        { k: "def", term: "1) Chain survey", t: "The <b>simplest</b> type of survey, in which <b>only linear measurements</b> are taken with the help of a chain or tape. In chain survey <b>angular measurements are not done</b>. (p.102–103)" },
        { k: "def", term: "2) Compass survey", t: "<b>Horizontal angle</b> is measured with the help of a <b>magnetic compass</b>, and linear measurements are done with chain or tape. (p.103)" },
        { k: "def", term: "3) Levelling", t: "A levelling instrument is used to determine the <b>relative elevation</b> of different points on the earth's surface. (p.103)" },
        { k: "def", term: "4) Plane table survey", t: "A plan or map is prepared <b>in the field</b> while sighting the various points and measuring their linear distances with chain or tape. The best advantage of plane table survey is that <b>sighting &amp; plotting are done simultaneously</b>, but the <b>accuracy</b> of plane table survey is found to be <b>very low</b>. (p.103)" },
        { k: "p", t: "Figure (p.103): a hexagon with vertices F (top), A (upper right), B (lower right), C (bottom), D (lower left), E (upper left). A square plane table is drawn at the centre with a small hexagon plotted on it, and dashed rays run from the table to each vertex A–F (plotting by radiation). (p.103)" },
        { k: "def", term: "5) Theodolite survey", t: "An instrument called a <b>theodolite</b> is used to measure <b>horizontal &amp; vertical angles</b>, and linear measurements are done with chain or tape. (p.104)" },
        { k: "def", term: "6) Tacheometric survey", t: "A special type of survey in which horizontal &amp; vertical distances are measured <b>optically</b> with an instrument called a <b>tacheometer</b>; chain or tape are <b>not used</b>. (p.104)" },
        { k: "def", term: "7) Photogrammetric survey / Aerial survey", t: "Photogrammetry is the science of taking measurements with the help of <b>photographs</b>, generally used for <b>inaccessible areas</b> and for areas where the available time is less. (p.104)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Do alag sawaal hain: survey <b>kis liye</b> (purpose — topographical, engineering, cadastral, hydrographic, astronomic, geological) aur survey <b>kis instrument se</b> (chain, compass, level, plane table, theodolite, tacheometer, camera). Ek hi kaam dono list mein aata hai — jaise ek engineering survey theodolite se bhi ho sakta hai aur plane table se bhi." },
        { k: "p", t: "Instrument wali list ko 'kya measure hota hai' se yaad rakho: chain → sirf length; compass → horizontal angle + length; level → elevation; theodolite → horizontal + vertical angle; tacheometer → distance bina tape ke (optically); plane table → field mein hi plotting." },
        { k: "trap", t: "Tacheometric survey mein chain/tape <b>use nahi</b> hota — distance optically aata hai. Aur plane table ka plus point speed hai (sighting + plotting saath), accuracy nahi — notes clearly kehte hain accuracy very low hai." },
        { k: "real", t: "Property dispute ya registry ke liye cadastral survey; dam/bridge ke design ke liye engineering survey (1 : 500 – 1 : 2,500); jungle ya pahadi inaccessible area ke liye aerial photogrammetry." },
      ],
    },

    /* ---------------------------------------------------------- principles */
    {
      n: "",
      title: "Notes — principles of surveying",
      hi: "सर्वेक्षण के सिद्धांत",
      blocks: [
        { k: "h", t: "📘 Notes — p.104–105 (Principles of surveying ★ IMP)" },
        { k: "list", items: [
          "1) Work from whole to part.",
          "2) Locate a point by at least 2 measurements. (p.104)",
        ] },
        { k: "def", term: "1) Work from whole to part", t: "The main objective of working from whole to part is to <b>localise the error</b> and <b>prevent its accumulation</b>. If we work from part to whole, error accumulates. (p.104)" },
        { k: "def", term: "2) Locate the point by at least two measurements", t: "Figure (p.105) shows four ways:<br>• (1) Triangle ABC, A bottom-left, B bottom-right, C top, all three sides marked with tick marks — C located by its distances from A and B.<br>• (2) Line AB horizontal, line AC drawn from A at angle θ — C located by distance AC and angle θ.<br>• (3) Triangle on base AB with angles α₁ at A and α₂ at B, the two sides extended to cross at the top — point located by two angles.<br>• (4) Vertical line AB (A top, B bottom) with D on it; perpendicular DC drawn to the right with a right-angle mark at D — C located by a perpendicular offset. (p.105)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Whole to part ka matlab: pehle poore area par kuch accurate control points ka framework banao, phir uske andar detail bharo. Is tarah ek galti sirf us chhote hisse tak rehti hai. Part to whole mein har agla point pichle point par tika hota hai, isliye har galti aage badhti jaati hai (section 1.2 mein ye detail mein hai)." },
        { k: "p", t: "Ek measurement se point fix nahi hota — sirf distance diya to point ek circle par kahin bhi ho sakta hai, sirf angle diya to ek line par kahin bhi. Do independent measurements (do distances, ya distance + angle, ya do angles, ya chainage + offset) se point ek jagah fix hota hai. Yahi chaar figures chain, theodolite/total station, triangulation/plane table aur offsets ka base hain." },
        { k: "trap", t: "Principle 2 mein 'at least' important hai. Do measurements se point fix hota hai, lekin teesra measurement check ke liye hota hai — check line / tie line isi liye li jaati hai (section 1.3)." },
        { k: "real", t: "Chain survey mein boundary ke features chain line se perpendicular offset leke fix kiye jaate hain — figure (4) wala method." },
      ],
    },

    /* ---------------------------------------------------------- scale & RF */
    {
      n: "",
      title: "Notes — scale, engineer's scale, RF and graphical scale",
      hi: "पैमाना, निरूपक भिन्न और आलेखी पैमाना",
      blocks: [
        { k: "h", t: "📘 Notes — p.105–106 (Scale)" },
        { k: "eq", expr: "Scale = length of line on map/plan ÷ length of corresponding line on ground", where: [
          ["both lengths", "in the same units"],
        ] },
        { k: "eg",
          title: "Notes example — scale of 10 cm to 1000 km",
          given: "Ex: 10 cm on the map represents 1000 km on the ground. Find the scale.",
          steps: [
            { t: "Write as a ratio", w: "Scale = 10 cm / 1000 km" },
            { t: "Convert km to cm", w: "= 10 / (1000 × 10⁵)" },
          ],
          ans: "= 1 : 100000 (p.105)",
        },
        { k: "note", t: "<b>Check:</b> 1000 km = 1000 × 10⁵ cm = 10⁸ cm, so 10 / 10⁸ = 1/10⁷. The correct scale is <b>1 : 10,000,000</b> (1 : 10⁷), not 1 : 100000. The notes' first two steps are right; only the final simplification dropped two zeros." },
        { k: "note", t: "Anything written in terms of <b>(1 cm)</b> is only an <b>engineer's scale</b> or simple scale. Eg → <b>1 cm = 50 m</b> ✓ → this only is a scale; 2 cm = 100 m, 1 mm = 5 m, 2 mm = 10 m are not written in that form. (p.105)" },
        { k: "def", term: "Representative fraction (R.F.)", t: "When the engineer's scale is represented by a <b>fraction</b>, it is called the representative fraction. (p.105)" },
        { k: "eg",
          title: "Notes example — RF of 1 cm = 20 km",
          given: "Eg: 1 cm = 20 km. Find the RF.",
          steps: [
            { t: "Same units", w: "20 km = 20 × 10⁵ cm = 2000000 cm" },
          ],
          ans: "RF = 1/2000000 (p.105)",
        },
        { k: "h", t: "Graphical scale (p.106)" },
        { k: "p", t: "Figure (p.106): two rectangles (sheets). <b>Left (Before shrink)</b>: a vertical scale bar marked “5 cm” on its left and “x cm” on its right; caption “1 cm = 100 m”. <b>Right (After shrink)</b>: a shorter vertical scale bar marked “4 cm” on its left and “y cm” on its right; caption “1 cm = 100 m” (the unit is hard to read in the notes and may be written as cm). The point: a graphical scale bar drawn on the sheet shrinks along with the sheet. (p.106)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Scale ek ratio hai — numerator aur denominator dono <b>same unit</b> mein hone chahiye. Isliye km ko cm mein badlo: 1 km = 1000 m = 10⁵ cm. Example ki galti bhi yahi dikhati hai — zero ginne mein dhyan do. 1 cm = 20 km mein 20 km = 20 × 10⁵ = 2 × 10⁶ cm, to RF = 1/2,000,000." },
        { k: "p", t: "Graphical scale (scale bar) ka fayda: sheet sikud jaye to bar bhi utna hi sikudta hai, isliye bar se naapne par sahi ground distance milta hai. Lekin sheet par likha hua '1 cm = 100 m' sikudne ke baad sach nahi rehta — figure mein 5 cm ka bar 4 cm ho gaya, yani har cm ab pehle se zyada ground represent karta hai." },
        { k: "trap", t: "RF ke paas <b>koi unit nahi</b> hoti — 1/2000000 likho, '1 cm/20 km' RF nahi hai. Aur km → cm ke liye 10⁵ se multiply karna hai, 10³ se nahi (10³ se sirf metre milta hai)." },
        { k: "real", t: "Purane map photocopies / scan karne par size badal jaata hai, isliye professional drawings par hamesha graphical scale bar bhi diya jaata hai." },
      ],
    },

    /* ---------------------------------------------------------- shrinkage & wrong scale */
    {
      n: "",
      title: "Notes — shrinkage factor and error due to wrong scale",
      hi: "संकुचन गुणांक और गलत पैमाने से त्रुटि",
      blocks: [
        { k: "h", t: "📘 Notes — p.106–108 (Shrinkage factor, wrong measuring scale)" },
        { k: "eq", expr: "SF (or SR) = shrunk length / original length = shrunk scale / original scale = shrunk RF / original RF", where: [
          ["SF / SR", "shrinkage factor / shrinkage ratio"],
        ] },
        { k: "eq", expr: "Correct length = (1/SF) × measured length;  Correct area = (1/SF²) × measured area;  Correct volume = (1/SF³) × measured volume", where: [
          ["SF", "shrinkage factor (p.107)"],
        ] },
        { k: "eg",
          title: "Notes example — shrunk plan: SF, shrunk scale, correct length and area",
          given: "A plan of an area shrunk such that a line originally 10 cm now measures 9.5 cm. If the original scale of the plan was 1 cm = 10 m, determine (i) shrinkage factor, (ii) shrunk scale, (iii) correct distance corresponding to a measured distance of 98 m, and correct area corresponding to a measured area of 10000 m².",
          steps: [
            { t: "(i) Shrinkage factor", w: "SF = 9.5 / 10 = 0.95" },
            { t: "(ii) Shrunk scale", w: "SF = shrunk scale / original scale\n0.95 = shrunk scale / (1/10×10⁵)\nshrunk scale = 0.95 / 10³\nshrunk scale = 1/1052" },
            { t: "(iii) Correct length", w: "correct length = (1/SF) × 98\n= (1/0.95) × 98 = 103.15 m" },
            { t: "(iii) Correct area", w: "correct area = (1/(0.95)²) × 10000 = 11080.33 m²" },
          ],
          ans: "SF = 0.95; shrunk scale = 1/1052; correct length = 103.15 m; correct area = 11080.33 m² (p.106–107)",
        },
        { k: "note", t: "<b>Check:</b> the original scale 1 cm = 10 m is RF = 1/(10 × 10²) = <b>1/1000</b>; the notes write the denominator as 10 × 10⁵ in one line, but the next line correctly uses 10³. Shrunk RF = 0.95/1000 = 1/1052.6 ≈ 1/1052 ✓. Correct length = 98/0.95 = 103.158 m, i.e. <b>103.16 m</b> when rounded (the notes truncate to 103.15 m). Correct area 10000/0.9025 = 11080.33 m² ✓." },
        { k: "h", t: "Error due to wrong measuring scale (p.107)" },
        { k: "eq", expr: "Correct length = (RF of wrong scale / RF of correct scale) × measured length", where: [] },
        { k: "eq", expr: "Correct area = (RF of wrong scale / RF of correct scale)² × measured area", where: [] },
        { k: "eq", expr: "Correct volume = (RF of wrong scale / RF of correct scale)³ × measured volume", where: [] },
        { k: "eg",
          title: "Notes example — length measured with a wrong scale",
          given: "A surveyor measured the distance between two points marked on a plan drawn to a scale of 1 cm = 1 m and found it to be 50 m. Later it is detected that he used a wrong scale of 1 cm = 50 cm. Determine the correct length.",
          steps: [
            { t: "RFs", w: "correct scale 1 cm = 1 m → RF = 1/100\nwrong scale 1 cm = 50 cm → RF = 1/50" },
            { t: "Correct length", w: "C.L = (1/50)/(1/100) × 50" },
          ],
          ans: "C.L = 100 m (p.108)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Sheet sikudne par plan par naapi gayi har length chhoti aati hai, isliye ground length bhi kam nikalti hai. Correct karne ke liye SF se <b>divide</b> karo (1/SF se multiply). Area do lengths ka product hai, isliye SF², aur volume ke liye SF³." },
        { k: "p", t: "Wrong scale wale example mein plan 1 cm = 1 m par bana tha, lekin surveyor ne 1 cm = 50 cm wala scale lagaya — yani usne har cm ko sirf aadha metre samjha. Isliye uska 50 m asal mein double hai: 100 m. Formula ka ratio (1/50)/(1/100) = 2 yahi batata hai." },
        { k: "trap", t: "Wrong-scale formula mein ratio ulta mat karo: <b>wrong RF upar, correct RF neeche</b>. Quick check: agar wrong scale ne har cm ko kam ground maana (1 cm = 50 cm vs 1 cm = 1 m), to measured value chhoti hogi aur correct value badi aani chahiye." },
        { k: "real", t: "Purane revenue/cadastral maps (kapde ya kaagaz par) saalon mein sikud jaate hain; un par se area naapte waqt pehle kisi known line ko naap kar SF nikala jaata hai, phir area ko SF² se correct kiya jaata hai." },
      ],
    },

    /* ---------------------------------------------------------- vernier */
    {
      n: "",
      title: "Notes — vernier, least count, direct and retrograde vernier",
      hi: "वर्नियर, अल्पतमांक, प्रत्यक्ष और प्रतिगामी वर्नियर",
      blocks: [
        { k: "h", t: "📘 Notes — p.108–111 (Use of vernier)" },
        { k: "def", term: "Vernier", t: "A device used for measuring readings which are <b>fractional parts of the smallest division of the main scale</b>. (p.108)" },
        { k: "p", t: "Figure (p.108): a rectangle labelled “Main Scale”; along its top edge large ticks labelled 1 and 2 with small subdivision ticks between them; below, the labels 1.1 and 1.2 under the first two subdivisions. <b>Smallest division = 1.2 − 1.1 = 0.1</b>. (p.108)" },
        { k: "eq", expr: "Reading = main scale reading before the index mark + N × L.C", where: [
          ["N", "the vernier division that perfectly coincides with a main-scale division"],
          ["L.C", "least count"],
        ] },
        { k: "p", t: "Figure (p.109): a rectangle; its top edge carries the main-scale ticks (alternating long and short, labelled “Main scale”); its bottom edge carries a short vernier with closely spaced ticks, with “6” written below the vernier mark that lines up with a main-scale tick. N = 6, so <b>Reading = 1.1 + 6 × L.C</b>. (p.109)" },
        { k: "def", term: "Least count", t: "One division of main scale − one division of vernier scale. (p.109)" },
        { k: "note", t: "Divisions of the vernier scale are made <b>slightly longer or slightly shorter</b> than divisions of the main scale. (p.109)" },
        { k: "h", t: "Types of vernier" },
        { k: "def", term: "1) Direct vernier", t: "<b>n divisions of the vernier scale = (n − 1) divisions of the main scale</b>. Readings of both scales increase in the <b>same direction</b>. One vernier division is <b>slightly shorter</b> than one main-scale division. (p.109–110)" },
        { k: "p", t: "Figure (p.109): rectangle; top edge = vernier scale with ticks numbered 1 to 10; bottom edge = main scale with ticks numbered 1 to 9. Ten vernier divisions span nine main-scale divisions; both scales increase left to right. (p.109)" },
        { k: "eq", expr: "nV = (n − 1)S;   L.C = S − V = S − (n − 1)S/n = S/n", where: [
          ["S", "value of one main-scale division"],
          ["V", "value of one vernier-scale division"],
          ["n", "number of divisions on the vernier scale"],
        ] },
        { k: "def", term: "2) Retrograde vernier", t: "<b>n divisions of the vernier scale = (n + 1) divisions of the main scale</b>. The vernier reading increases in the <b>opposite direction</b> to the main scale (in a direct vernier both increase in the same direction). One vernier division is <b>slightly larger</b> than one main-scale division. (p.110)" },
        { k: "p", t: "Figure (p.110): rectangle; top edge = vernier scale with ticks numbered 1 to 10 increasing left to right; bottom edge = main scale with ticks numbered 11, 10, 9 … 1 from left to right (increasing right to left). Ten vernier divisions span eleven main-scale divisions. (p.110)" },
        { k: "eq", expr: "nV = (n + 1)S;   L.C = V − S = (n + 1)S/n − S = S/n", where: [
          ["n", "number of divisions on the vernier scale"],
        ] },
        { k: "p", t: "<b>Least count</b> is given by the value of the smallest division of the main scale divided by the number of divisions of the vernier scale. (p.111)" },
        { k: "eg",
          title: "Notes example — reading a (retrograde) vernier",
          given: "10 divisions of the vernier are equal to 11 divisions of the main scale. The index mark (zero mark) of the vernier is between 2.4 and 2.5 of the main scale, and the 7th division of the vernier scale perfectly coincides with the main scale. Calculate the correct reading.",
          steps: [
            { t: "Rule", w: "correct reading = main scale reading before index mark + N × L.C" },
            { t: "Coinciding division", w: "N = 7" },
            { t: "Least count", w: "L.C = S/n = (2.5 − 2.4)/10 = 0.01" },
            { t: "Reading", w: "correct reading = 2.4 + 0.01 × 7" },
          ],
          ans: "Correct reading = 2.47 (p.111)",
        },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Main scale sirf 0.1 tak padh sakta hai; index mark 2.4 aur 2.5 ke beech ho to baaki hissa vernier batata hai. Vernier ki division main scale se thodi si chhoti (direct) ya thodi si badi (retrograde) hoti hai — har division par ye farak L.C jitna badhta hai, isliye jo vernier line main scale se exactly milti hai, uska number N batata hai ki index mark kitne L.C aage hai." },
        { k: "p", t: "Dono types ka L.C ek hi formula se aata hai: <b>L.C = S/n</b>. Farak sirf construction aur direction ka hai — direct: n vernier = (n − 1) main, same direction; retrograde: n vernier = (n + 1) main, opposite direction." },
        { k: "trap", t: "L.C nikaalte waqt n = <b>vernier</b> ki divisions (10), main scale ki (9 ya 11) nahi. Retrograde question mein '11' dekh kar S/11 likhna common galti hai — notes ka answer S/n = 0.1/10 = 0.01 hai." },
        { k: "real", t: "Theodolite ke horizontal aur vertical circles, levelling staff targets aur purane barometers par vernier hi fine reading deta tha; aaj digital instruments mein ye kaam electronics karta hai, lekin exam aur purane instruments ke liye vernier padhna zaroori hai." },
      ],
    },

    /* ---------------------------------------------------------- revision */
    {
      n: "",
      title: "Notes revision — What Surveying Is For (p.1, p.98–111)",
      hi: "नोट्स पुनरावृत्ति — सर्वेक्षण किसलिए",
      blocks: [
        { k: "h", t: "✅ Key points from the notes" },
        { k: "list", items: [
          "✅ Surveying = measuring relative positions of natural &amp; man-made features on the earth's surface and presenting them graphically or numerically (p.98).",
          "✅ Plan = large scale; map = small scale; heights shown as spot heights or contours (p.98).",
          "✅ Objectives: relative positions, layout/markout of proposed structures, area/volume/quantities (p.98).",
          "✅ Shape of the earth = GEOID (p.98).",
          "✅ Plane survey neglects curvature; horizontal plane is tangential to the earth's surface and normal to the plumb line (p.99).",
          "✅ Geodetic survey considers curvature, establishes control points, done by Survey of India (p.99).",
          "✅ Arc 18.5 km → chord about 1.52 cm short (notes' figure; formula s³/24R² gives ≈ 6.5 mm) (p.100).",
          "✅ Up to 195.5 km²: Σθ − Σα = 1″ — spherical vs plane triangle difference negligible (p.100).",
          "✅ Topographical scale 1 : 25,000 – 1 : 1,000,000; art of map making = Cartography (p.101).",
          "✅ Engineering 1 : 50 – 1 : 50,000; building 1 : 50 – 1 : 3,000; bridges 1 : 500 – 1 : 2,500; highways 1 : 1,250 – 1 : 50,000 (p.101).",
          "✅ Cadastral (property lines) 1 : 1,000 – 1 : 5,000; hydrographic, astronomic (latitude, longitude, local time, absolute position), geological (p.102).",
          "✅ By instrument: chain (linear only), compass (horizontal angle), levelling (relative elevation), plane table (plot in field, low accuracy), theodolite (H &amp; V angles), tacheometric (optical, no chain), photogrammetric (photographs, inaccessible areas) (p.102–104).",
          "✅ Principles: work from whole to part (localise error); locate a point by at least two measurements (p.104–105).",
          "✅ Scale = map length / ground length; anything in terms of 1 cm = engineer's scale; RF = scale as a fraction, e.g. 1 cm = 20 km → 1/2000000 (p.105).",
          "✅ SF = shrunk length/original length = shrunk scale/original scale = shrunk RF/original RF (p.106).",
          "✅ Correct length = measured/SF; area = measured/SF²; volume = measured/SF³ (p.107).",
          "✅ Shrinkage example: SF 0.95, shrunk scale 1/1052, 98 m → 103.15 m, 10000 m² → 11080.33 m² (p.106–107).",
          "✅ Wrong scale: correct = (RF wrong / RF correct)ⁿ × measured, n = 1, 2, 3 for length, area, volume; example 50 m → 100 m (p.107–108).",
          "✅ Reading = main scale reading before index + N × L.C (p.108).",
          "✅ L.C = one main-scale division − one vernier division (direct) = S/n (p.109–110).",
          "✅ Direct: nV = (n − 1)S, same direction, vernier division shorter; Retrograde: nV = (n + 1)S, opposite direction, vernier division longer, L.C = V − S = S/n (p.109–111).",
          "✅ Example: 10 vernier = 11 main, index 2.4–2.5, N = 7 → L.C 0.01, reading 2.47 (p.111).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
