/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   Chapter 5 — Tension Members
   Chapter 6 — Compression Members

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "st"; });
  if (!hb) return;

  hb.chapters.push(

    /* ============================================================ CH 5 */
    {
      id: "st-5",
      n: 5,
      title: "Tension Members",
      hi: "तनाव सदस्य",
      blurb: "The simplest member in steel, and the one that teaches why there are two partial safety factors.",
      mins: 42,
      sections: [

        {
          n: "5.1",
          title: "The one member that cannot buckle",
          hi: "जो सदस्य बकल नहीं हो सकता",
          blocks: [
            { k: "p", t: "A tension member is the easiest thing in steel design, because the one problem that dominates everything else — buckling — cannot happen. Pull on a member and it straightens; there is no instability to chase. What is left is strength, and that turns out to have three separate answers." },
            { k: "list", items: [
              "<strong>Yielding of the gross section</strong> — the whole member stretches. Ductile.",
              "<strong>Rupture of the net section</strong> — it tears across the bolt holes. Brittle.",
              "<strong>Block shear</strong> — a chunk of the end tears out around the bolt group. Brittle.",
            ]},
            { k: "p", t: "The design strength is the <strong>smallest</strong> of the three, and the whole of this chapter is computing them. Ties in trusses, sag rods, bracing, hangers and the bottom chord of a roof truss are all tension members; so are the legs of a transmission tower on the windward side." },
            { k: "note", t: "Buckling is absent but slenderness is not ignored. Cl. 3.8 and Table 3 still cap it — 400 for a member always in tension, and 350 for a tie in a roof truss or bracing that could see a reversal under wind. The reason is practical rather than structural: a very slender tie sags under its own weight, rattles in the wind, and is easily damaged in handling and erection." },
          ],
        },

        {
          n: "5.2",
          title: "Yielding and rupture, side by side",
          hi: "यील्डिंग और रप्चर",
          blocks: [
            { k: "dia", id: "hb-st-tenmodes", cap: "One mode stretches the whole member; the other tears it at one section." },
            { k: "eq", expr: "Tdg = Ag fy / γm0          (Cl. 6.2 — yielding of the gross section)", where: [
              ["Ag", "gross cross-sectional area, mm²"],
              ["γm0", "1.10"],
            ]},
            { k: "eq", expr: "Tdn = 0.9 An fu / γm1      (Cl. 6.3.1 — rupture of the net section, plates)", where: [
              ["An", "net area at the critical section, after deducting holes, mm²"],
              ["γm1", "1.25"],
            ]},
            { k: "p", t: "Three differences between those two expressions are worth naming, because together they are the clearest illustration of how IS 800 thinks:" },
            { k: "list", items: [
              "<strong>Gross vs net area.</strong> Yielding happens over a length, so the holes — which occupy almost none of that length — do not control it. Rupture happens at one section, which is the section with the holes.",
              "<strong>fy vs fu.</strong> Yielding is reaching the yield stress. Rupture is reaching the ultimate stress and breaking.",
              "<strong>1.10 vs 1.25, and an extra 0.9.</strong> A yielding member stretches visibly for a long time; a rupturing one snaps. The brittle mode is given a larger factor and then a further 10% reduction on top, because a tear at a hole is a stress concentration and there is no redistribution available.",
            ]},
            { k: "note", t: "A design in which gross yielding governs is the healthier one — the member gives warning before anything breaks. When net rupture governs, the usual fixes are fewer and larger bolts, a staggered arrangement, or a slightly wider member; all of them raise An without touching Ag." },
          ],
        },

        {
          n: "5.3",
          title: "Net area, and staggered holes",
          hi: "नेट क्षेत्रफल और स्टैगर",
          blocks: [
            { k: "p", t: "For holes in a straight line across the member, the net area is obvious: subtract each hole's diameter times the thickness. The interesting case is when the holes are staggered, because then the tear has a choice of routes." },
            { k: "dia", id: "hb-st-stagger", cap: "A zig-zag path is longer but crosses more holes; every path has to be tried." },
            { k: "eq", expr: "An = [ b − n d0 + Σ (psi² / 4 g) ] t        (Cl. 6.3.1)", where: [
              ["b", "width of the plate, mm"],
              ["n", "number of holes the path crosses"],
              ["d0", "hole diameter, mm"],
              ["psi", "stagger — the spacing of two holes measured along the direction of the load"],
              ["g", "gauge — their spacing measured across it"],
              ["t", "thickness, mm"],
            ]},
            { k: "p", t: "The psi²/4g term is an empirical credit for the extra length of each diagonal leg of the path, and one such term is added for <strong>every diagonal leg</strong>, not for every hole. It is empirical because the real stress state along a zig-zag tear is complicated and the term is a fit to test data — which is fine, and worth knowing rather than pretending it was derived." },
            { k: "trap", t: "There is no formula for which path governs. Draw every plausible path, compute An for each, and take the smallest. A path with more holes can still win if it is diagonal enough, and a path with fewer holes can win if it is straight. Software does this by enumeration and so should you." },
            { k: "note", t: "Staggering is a design tool, not an accident. Moving alternate bolts along by 40 or 50 mm can lift the net area enough to change which failure mode governs, at no cost in material — and it also spreads the bearing load along the plate instead of concentrating it on one transverse line." },
          ],
        },

        {
          n: "5.4",
          title: "Angles connected through one leg",
          hi: "एक लेग से जुड़े एंगल",
          blocks: [
            { k: "p", t: "Almost every tension member in a real truss is an angle bolted to a gusset through one leg only. That single practical fact produces the most-used clause in this chapter, because the member does not behave as its area suggests." },
            { k: "dia", id: "hb-st-shearlag", cap: "Force enters through the connected leg and takes a length of member to spread into the other one." },
            { k: "def", term: "Shear lag", t: "Near the joint, the connected leg is carrying far more than its share and the outstanding leg is barely stressed — the force has not had room to distribute. Several times the member width further along, the stress has evened out. The critical section is at the joint, where it has not." },
            { k: "eq", expr: "Tdn = 0.9 Anc fu / γm1  +  β Ago fy / γm0        (Cl. 6.3.3)", where: [
              ["Anc", "net area of the CONNECTED leg, mm²"],
              ["Ago", "gross area of the OUTSTANDING leg, mm²"],
              ["β", "the shear lag factor — how much of the outstanding leg actually works"],
            ]},
            { k: "p", t: "Read that expression as two members in one: the connected leg is treated as a plate at net section and ultimate stress, and the outstanding leg is credited only with a fraction β of its yield capacity." },
            { k: "eq", expr: "β = 1.4 − 0.076 (w/t)(fy/fu)(bs/Lc),   with  0.7 ≤ β ≤ fu γm0 /(fy γm1)", where: [
              ["w", "outstand leg width, mm"],
              ["bs", "shear lag width = w + w1 − t, where w1 is the gauge from the heel to the bolt line"],
              ["Lc", "length of the end connection — the distance between the outermost bolts, mm"],
            ]},
            { k: "p", t: "Every term in β is telling you something you could have guessed. A <strong>wide, thin outstanding leg</strong> (large w/t) lags more. A <strong>short connection</strong> (small Lc) gives the force less length to spread into, so it lags more. And a <strong>longer connection improves β directly</strong> — which is the practical lever: adding one more bolt to the row lengthens Lc and raises the member's capacity without changing the member." },
            { k: "note", t: "Cl. 6.3.3 also offers a simplified alternative, Tdn = α An fu/γm1, with α = 0.6 for one or two bolts, 0.7 for three, and 0.8 for four or more. It is quicker and more conservative, and the α values encode exactly the same message: more bolts, longer connection, less shear lag." },
          ],
        },

        {
          n: "5.5",
          title: "Block shear",
          hi: "ब्लॉक शियर",
          blocks: [
            { k: "p", t: "The third mode is the one most often forgotten, and in short end connections it frequently governs. Instead of tearing across the holes, a whole <em>block</em> of material containing the bolts tears out of the end of the member — shearing along the two lines parallel to the load, and tearing across the one perpendicular to it." },
            { k: "dia", id: "hb-st-blockshear", cap: "Two shear planes and one tension plane, failing together as one block." },
            { k: "p", t: "Cl. 6.4.1 gives two expressions and takes the smaller. The reason there are two is that the block cannot fail by yielding on one plane and rupturing on the other at the same instant, so the code checks each combination:" },
            { k: "eq", expr: "Tdb1 = Avg fy /(√3 γm0)  +  0.9 Atn fu / γm1", where: [
              ["Avg", "gross area of the shear planes, mm²"],
              ["Atn", "net area of the tension plane, mm²"],
            ]},
            { k: "eq", expr: "Tdb2 = 0.9 Avn fu /(√3 γm1)  +  Atg fy / γm0", where: [
              ["Avn", "net area of the shear planes, mm²"],
              ["Atg", "gross area of the tension plane, mm²"],
            ]},
            { k: "p", t: "The first pairs <em>shear yielding</em> with <em>tension rupture</em>; the second pairs <em>shear rupture</em> with <em>tension yielding</em>. The √3 is the usual conversion of a tensile strength to a shear strength." },
            { k: "trap", t: "Computing the net shear area is where mistakes happen. A shear plane running through a line of n bolts loses <strong>(n − 0.5)</strong> hole diameters, not n — the last hole is only half crossed, because the plane ends at the centre of the end bolt. The half matters: in the worked example below it is the difference between a pass and a fail." },
            { k: "p", t: "Block shear gets worse with <strong>short end distances</strong> and <strong>few bolts</strong>, because both shorten the shear planes. It is the reason a tension member sometimes needs more bolts than its bolt value suggests, and the reason a compact connection is not always the efficient one." },
          ],
        },

        {
          n: "5.6",
          title: "A plate and an angle, worked through",
          hi: "प्लेट और एंगल — हल सहित",
          blocks: [
            { k: "eg",
              title: "Example 5.1 — Plate in tension",
              given: "Plate 200 mm × 10 mm, E250 steel (fy = 250, fu = 410 N/mm²), connected by 6 no. M20 bolts in two lines of three: gauge 100 mm, pitch 60 mm, end distance 40 mm. Hole diameter d0 = 22 mm.",
              steps: [
                { t: "Yielding of the gross section (Cl. 6.2)", w: "Ag = 200 × 10 = 2000 mm²\nTdg = 2000 × 250/1.10 = 454,545 N = 454.5 kN" },
                { t: "Rupture of the net section (Cl. 6.3.1)", w: "The critical section crosses both holes:\nAn = (200 − 2 × 22) × 10 = 1560 mm²\nTdn = 0.9 × 1560 × 410/1.25 = 460,512 N = 460.5 kN" },
                { t: "Block shear — the geometry (Cl. 6.4.1)", w: "Shear planes: along each bolt line, length = 2 × 60 + 40 = 160 mm, two of them\nTension plane: across the gauge, 100 mm\nAvg = 2 × 160 × 10 = 3200 mm²\nAvn = 2 × (160 − 2.5 × 22) × 10 = 2 × 105 × 10 = 2100 mm²   (2.5 holes, not 3)\nAtg = 100 × 10 = 1000 mm²\nAtn = (100 − 22) × 10 = 780 mm²" },
                { t: "Block shear — first expression", w: "Tdb1 = 3200 × 250/(1.732 × 1.10) + 0.9 × 780 × 410/1.25\n     = 419,881 + 230,256 = 650,137 N = 650.1 kN" },
                { t: "Block shear — second expression", w: "Tdb2 = 0.9 × 2100 × 410/(1.732 × 1.25) + 1000 × 250/1.10\n     = 357,904 + 227,273 = 585,177 N = 585.2 kN\nTdb = lesser = 585.2 kN" },
                { t: "Design strength", w: "least of 454.5, 460.5 and 585.2 = 454.5 kN\n→ GROSS YIELDING governs" },
              ],
              ans: "Design tensile strength = 454.5 kN, governed by yielding of the gross section — the ductile mode, which is the outcome to want.",
            },
            { k: "eg",
              title: "Example 5.2 — Single angle through one leg",
              given: "ISA 75 × 75 × 6 (gross area 866 mm², from the section tables) connected through one leg by 3 no. M16 bolts (d0 = 18 mm) at 50 mm pitch, 30 mm end distance, on a gauge of 45 mm from the heel. E250 steel.",
              steps: [
                { t: "Yielding of the gross section", w: "Tdg = 866 × 250/1.10 = 196,818 N = 196.8 kN" },
                { t: "Leg areas", w: "Connected leg gross = (75 − 6/2) × 6 = 432 mm²\nAnc = 432 − 18 × 6 = 324 mm²\nAgo (outstanding leg) = (75 − 6/2) × 6 = 432 mm²" },
                { t: "Shear lag factor β (Cl. 6.3.3)", w: "w = 75 mm,  t = 6 mm,  w1 = 45 mm (gauge)\nbs = w + w1 − t = 75 + 45 − 6 = 114 mm\nLc = 2 × 50 = 100 mm\nβ = 1.4 − 0.076 × (75/6) × (250/410) × (114/100)\n  = 1.4 − 0.076 × 12.5 × 0.6098 × 1.14 = 1.4 − 0.660 = 0.740\nLimits: ≥ 0.7 ✓ and ≤ fu γm0/(fy γm1) = 410 × 1.10/(250 × 1.25) = 1.443 ✓" },
                { t: "Rupture of the net section", w: "Tdn = 0.9 × 324 × 410/1.25  +  0.740 × 432 × 250/1.10\n    = 95,645 + 72,616 = 168,261 N = 168.3 kN" },
                { t: "Block shear", w: "Shear plane (one, along the bolt line): 2 × 50 + 30 = 130 mm\nAvg = 130 × 6 = 780 mm²      Avn = (130 − 2.5 × 18) × 6 = 510 mm²\nTension plane, from the bolt line to the edge = 75 − 45 = 30 mm\nAtg = 30 × 6 = 180 mm²        Atn = (30 − 9) × 6 = 126 mm²\nTdb1 = 780 × 250/(1.732 × 1.10) + 0.9 × 126 × 410/1.25 = 102,346 + 37,195 = 139.5 kN\nTdb2 = 0.9 × 510 × 410/(1.732 × 1.25) + 180 × 250/1.10 = 86,919 + 40,909 = 127.8 kN\nTdb = 127.8 kN" },
                { t: "Design strength", w: "least of 196.8, 168.3 and 127.8 = 127.8 kN\n→ BLOCK SHEAR governs" },
              ],
              ans: "Design tensile strength = 127.8 kN — only 65% of the gross yield capacity, and governed by block shear, not by the member at all.",
            },
            { k: "trap", t: "Compare the two examples. The plate reached its full ductile capacity; the angle lost 35% of it to the connection, and to a mode that most students never check. That gap is exactly why Chapter 3 came before this one — and the fix is in the connection, not the member: a fourth bolt lengthens both Lc and the shear plane, raising β and Tdb together." },
          ],
        },

        {
          n: "5.7",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Three modes, and the smallest governs: gross yielding, net rupture, block shear.",
              "Tdg = Ag fy/1.10 — gross area, yield stress, small factor, ductile.",
              "Tdn = 0.9 An fu/1.25 — net area, ultimate stress, large factor, brittle.",
              "Staggered holes: An = [b − n d0 + Σ psi²/4g] t, and every path must be tried.",
              "Angle through one leg: Tdn = 0.9 Anc fu/γm1 + β Ago fy/γm0, with β from Cl. 6.3.3.",
              "Block shear: two expressions, take the smaller; shear planes lose (n − 0.5) holes.",
              "A longer end connection improves β, block shear and bearing all at once.",
              "Slenderness is still capped — 400 for a permanent tie, 350 where reversal is possible.",
            ]},
            { k: "p", t: "Chapter 6 turns the member round. The same section, the same steel, the same area — and a capacity that now depends on how long it is and what is holding its ends." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "st-6",
      n: 6,
      title: "Compression Members",
      hi: "संपीडन सदस्य",
      blurb: "Euler, the imperfections that make him optimistic, and the column curve IS 800 uses instead.",
      mins: 46,
      sections: [

        {
          n: "6.1",
          title: "The same member, turned round",
          hi: "वही सदस्य, उल्टी दिशा में",
          blocks: [
            { k: "p", t: "Take the tension member of Chapter 5 and push on it instead of pulling. Nothing about the material has changed, and its area is the same. But the capacity can fall by three-quarters, and the reason is that a member in compression has a way out: it can move sideways." },
            { k: "p", t: "Holes now matter less, not more — a bolt in a hole still transmits compression through bearing, so the gross area is generally used. What matters instead is <strong>length</strong>, <strong>end restraint</strong>, and the <strong>radius of gyration about the weakest axis</strong>." },
            { k: "def", term: "Radius of gyration", t: "r = √(I/A) — a measure of how far the material sits from the bending axis. It is not a property of the amount of steel but of its <em>arrangement</em>, which is why a hollow tube outperforms a solid bar of the same area in compression by a very large margin." },
            { k: "eq", expr: "Pd = Ae fcd        (Cl. 7.1.2)", where: [
              ["Ae", "effective sectional area, mm² — the gross area for a plastic, compact or semi-compact section"],
              ["fcd", "design compressive stress, N/mm² — everything in this chapter is about finding it"],
            ]},
          ],
        },

        {
          n: "6.2",
          title: "Euler, and why he is optimistic",
          hi: "यूलर और उसका आशावाद",
          blocks: [
            { k: "p", t: "Euler solved the ideal problem in 1757: a perfectly straight, perfectly elastic, pin-ended column, loaded exactly through its centroid, buckles at" },
            { k: "eq", expr: "fcc = π² E / (KL/r)²", where: [
              ["fcc", "elastic critical (Euler) buckling stress, N/mm²"],
              ["KL/r", "slenderness ratio — effective length divided by radius of gyration"],
            ]},
            { k: "p", t: "Two things about that expression deserve attention. First, <strong>fy does not appear in it</strong>: elastic buckling depends only on stiffness and geometry, so a higher grade of steel buys nothing. Second, it goes as <strong>1/slenderness²</strong>, so doubling the effective length quarters the capacity — a far more violent dependence than anything in reinforced concrete design." },
            { k: "dia", id: "hb-st-columncurve", cap: "The two ideal limits, and the real curve that sits below both of them." },
            { k: "p", t: "Real columns do not achieve the Euler load, and for intermediate slenderness they fall well short of it. Four reasons, all of them physical:" },
            { k: "list", items: [
              "<strong>Initial out-of-straightness.</strong> A rolled member is bowed by a millimetre or two over its length. The load is therefore eccentric from the start, and the eccentricity grows as it deflects.",
              "<strong>Residual stresses.</strong> The section cooled unevenly after rolling and already carries locked-in stresses of 70 to 100 N/mm². Parts of it yield long before the average stress reaches fy, and the section loses stiffness progressively.",
              "<strong>Accidental eccentricity of load.</strong> No connection delivers its force exactly through the centroid.",
              "<strong>Inelastic behaviour.</strong> Once part of the section has yielded, E is no longer the elastic modulus for the yielded fibres, so the real buckling stiffness is lower than EI.",
            ]},
            { k: "note", t: "The gap is widest at intermediate slenderness — around KL/r of 60 to 110 — which is precisely where most practical building columns sit. A short column is limited by its material and a very slender one by Euler; the awkward middle, where neither limit applies cleanly, is the normal case." },
          ],
        },

        {
          n: "6.3",
          title: "The IS 800 column curve",
          hi: "IS 800 का कॉलम वक्र",
          blocks: [
            { k: "p", t: "Cl. 7.1.2.1 handles all of that with a reduction factor applied to the material strength — the same machinery Chapter 8 will use for lateral-torsional buckling, so it is worth learning once, properly." },
            { k: "eq", expr: "λ = √(fy / fcc) = √( fy (KL/r)² / (π² E) )", where: [
              ["λ", "non-dimensional slenderness — how the column's strength compares with its stability"],
            ]},
            { k: "eq", expr: "φ = 0.5 [ 1 + α(λ − 0.2) + λ² ]", where: [
              ["α", "imperfection factor, from the buckling class (Table 7)"],
            ]},
            { k: "eq", expr: "χ = 1 / [ φ + (φ² − λ²)^0.5 ]        fcd = χ fy / γm0  ≤  fy / γm0", where: [
              ["χ", "stress reduction factor — the fraction of the material strength actually available"],
            ]},
            { k: "p", t: "Three features of that chain are worth understanding rather than memorising:" },
            { k: "list", items: [
              "<strong>λ is non-dimensional.</strong> It compares the squash load with the Euler load. λ = 1 means they are equal — the theoretical balanced point, and roughly where the reduction is worst relative to both.",
              "<strong>The (λ − 0.2) term</strong> means no reduction at all below λ = 0.2. Very stocky columns reach fy; the imperfections do not matter to them.",
              "<strong>α is the whole of the imperfection allowance.</strong> Table 7 gives 0.21 for class a, 0.34 for class b, 0.49 for class c and 0.76 for class d — and Table 10 assigns a class to each section shape, thickness and axis.",
            ]},
            { k: "trap", t: "The buckling class is assigned <strong>per axis</strong>, not per section. A rolled I-section with h/bf greater than 1.2 is typically class a about the major axis and class b about the minor — different α, different curve, different answer. Since minor-axis buckling almost always governs, using the major-axis class is both wrong and unsafe." },
            { k: "note", t: "Welded sections get a worse class than rolled ones of the same shape, and thicker flanges get a worse class than thin ones. Both follow from residual stress: welding leaves more of it, and thick material cools more unevenly." },
          ],
        },

        {
          n: "6.4",
          title: "Effective length",
          hi: "प्रभावी लंबाई",
          blocks: [
            { k: "p", t: "Everything in §6.3 runs on KL/r, so the effective length is worth as much care as the section choice. Cl. 7.2 and Table 11 give K for standard end conditions." },
            { k: "dia", id: "hb-st-effK", cap: "Table 11's recommended design values, deliberately more conservative than theory." },
            { k: "p", t: "Table 11 asks two separate questions about each end, and the second matters more than the first:" },
            { k: "list", items: [
              "<strong>Is the end restrained against rotation?</strong> Fixed, partially restrained, or free to rotate.",
              "<strong>Is the end held against translation?</strong> A column in a braced frame is held at every floor; one in an unbraced (sway) frame is not.",
            ]},
            { k: "p", t: "A column in a sway frame can have an effective length <em>longer than itself</em> — K greater than 1, and for the fixed-base free-top case, 2.0. Since capacity depends on (KL/r)² through fcc, doubling K quarters the elastic critical stress. This is the single strongest argument in structural steel: <strong>bracing a frame is cheaper than sizing its columns for sway</strong>." },
            { k: "trap", t: "The values in Table 11 are the <em>recommended design</em> values, not the theoretical ones. The theoretical figure for both ends fixed is 0.5; the recommended value is 0.65, because no real connection is truly fixed. Using the theoretical value because it appears in a textbook overstates every column it touches." },
            { k: "p", t: "Cl. 3.8 and Table 3 also cap slenderness outright: 180 for a member carrying compression from dead and imposed load, 250 where the compression arises only in combination with wind or earthquake. Beyond those, no calculation is accepted." },
          ],
        },

        {
          n: "6.5",
          title: "A column designed",
          hi: "एक कॉलम का डिज़ाइन",
          blocks: [
            { k: "steps", items: [
              "Establish the effective length about both axes — they are often different, because bracing is rarely symmetric.",
              "Choose a trial section and read A, rzz and ryy from the section tables.",
              "Compute KL/r about both axes and take the <strong>larger</strong>.",
              "Get the buckling class for that axis (Table 10) and hence α.",
              "Compute fcc, λ, φ, χ and fcd.",
              "Pd = Ae fcd, and compare with the factored load.",
              "Check the slenderness cap and the section classification.",
            ]},
            { k: "eg",
              title: "Example 6.1 — Axially loaded column",
              given: "ISHB 300 @ 58.8 kg/m, height 4.0 m, both ends effectively pinned (K = 1.0). E250 steel. From the section tables: A = 7485 mm², rzz = 129.5 mm, ryy = 54.1 mm, D = 300 mm, bf = 250 mm.",
              steps: [
                { t: "Effective lengths and slenderness", w: "KL = 1.0 × 4000 = 4000 mm about both axes\nKL/rzz = 4000/129.5 = 30.9\nKL/ryy = 4000/54.1  = 73.9   ← governs\nBoth are below the Cl. 3.8 cap of 180  ✓" },
                { t: "Buckling class (Table 10)", w: "h/bf = 300/250 = 1.2, and tf < 40 mm\n→ about the minor (y-y) axis the section is buckling class c\nα = 0.49 (Table 7)" },
                { t: "Euler stress", w: "fcc = π² E/(KL/r)² = π² × 2 × 10⁵/73.9²\n    = 1,973,921/5461 = 361.4 N/mm²" },
                { t: "Non-dimensional slenderness", w: "λ = √(fy/fcc) = √(250/361.4) = √0.6917 = 0.832" },
                { t: "φ and χ", w: "φ = 0.5[1 + 0.49(0.832 − 0.2) + 0.832²]\n  = 0.5[1 + 0.3097 + 0.6922] = 1.0010\nχ = 1/[1.0010 + √(1.0020 − 0.6922)]\n  = 1/[1.0010 + 0.5566] = 0.642" },
                { t: "Design compressive stress", w: "fcd = χ fy/γm0 = 0.642 × 250/1.10 = 145.9 N/mm²\nCheck: ≤ fy/γm0 = 227.3 N/mm²  ✓" },
                { t: "Capacity", w: "Pd = A fcd = 7485 × 145.9 = 1,092,000 N = 1092 kN" },
              ],
              ans: "Pd = 1092 kN. Note that fcd is only 64% of the design yield stress — buckling has taken away more than a third of the material's strength, and the column is not especially slender.",
            },
            { k: "trap", t: "Minor-axis slenderness was 73.9 against a major-axis 30.9, and it decided everything. A column is a minor-axis problem unless something specifically restrains that axis — and if something does (a wall, a bracing member, a secondary beam at mid-height), then halving the minor-axis effective length is worth far more than upgrading the section." },
          ],
        },

        {
          n: "6.6",
          title: "Why a higher grade buys so little",
          hi: "ऊँचा ग्रेड कम क्यों देता है",
          blocks: [
            { k: "p", t: "Chapter 1 asserted this; here is the arithmetic. Take the same ISHB 300, the same 4 m, the same end conditions, but in E410 steel — a 64% increase in yield strength." },
            { k: "eg",
              title: "Example 6.2 — The same column in E410",
              given: "As Example 6.1, but fy = 410 N/mm². All geometry unchanged, so KL/r = 73.9 and fcc = 361.4 N/mm² are also unchanged — fcc depends on E, not on fy.",
              steps: [
                { t: "Non-dimensional slenderness", w: "λ = √(410/361.4) = √1.1345 = 1.066   (was 0.832)" },
                { t: "φ and χ", w: "φ = 0.5[1 + 0.49(0.866) + 1.136] = 1.280\nχ = 1/[1.280 + √(1.638 − 1.136)] = 1/[1.280 + 0.709] = 0.503" },
                { t: "Design stress and capacity", w: "fcd = 0.503 × 410/1.10 = 187.4 N/mm²\nPd = 7485 × 187.4 = 1,403,000 N = 1403 kN" },
                { t: "Compare", w: "fy up by 410/250 = 64%\nPd up by 1403/1092 = 28% only" },
              ],
              ans: "A 64% stronger steel gives a 28% stronger column — and at KL/r = 150 the same comparison gives fcd of 59.3 against 63.9 N/mm², an improvement of just 8%.",
            },
            { k: "p", t: "The reason is in the Euler expression: fcc contains E and not fy, and E is the same for every structural steel. Raising fy raises the squash load but not the buckling load, so the column simply moves further down the curve and χ falls to compensate. The stronger the steel, the more of it the curve takes away." },
            { k: "note", t: "The practical rule: <strong>high-grade steel pays in tension members and in stocky compression members, and pays less and less as slenderness increases.</strong> In a slender strut it is close to money wasted. Spend it instead on a section with a better ry, or on bracing that reduces KL." },
          ],
        },

        {
          n: "6.7",
          title: "Built-up and laced columns, and single-angle struts",
          hi: "बिल्ट-अप, लेस्ड और एंगल स्ट्रट",
          blocks: [
            { k: "p", t: "When no rolled section has a large enough radius of gyration, two or more are spread apart and tied together — with diagonal <strong>lacing</strong> or with transverse <strong>battens</strong>. Spreading the components apart raises I dramatically for the same area, which is the whole point." },
            { k: "list", items: [
              "The connecting system carries a <strong>transverse shear of at least 2.5% of the axial load</strong> (Cl. 7.6.6.1), because a buckling column shears along its length as it bows.",
              "Lacing increases the effective slenderness by <strong>5%</strong> (Cl. 7.6.1.5) and battens by <strong>10%</strong> (Cl. 7.7.1.4) — the connecting system is not perfectly rigid, and the penalty reflects how much shear stiffness each provides.",
              "The slenderness of each individual component, between its connections, must be less than that of the member as a whole — otherwise a single component buckles on its own before the built-up column does.",
            ]},
            { k: "h", t: "Single angles in compression" },
            { k: "p", t: "A single angle strut connected through one leg — the commonest compression member in a truss — is a genuinely awkward problem. It is eccentrically loaded, unsymmetric, and it buckles about its weakest principal axis (v-v), which lies at an angle to both of its legs. Cl. 7.5.1.2 handles it with an equivalent slenderness ratio that folds the eccentricity into the buckling calculation rather than checking bending separately." },
            { k: "trap", t: "The weakest axis of an angle is <strong>not</strong> parallel to either leg. rvv is considerably smaller than rxx or ryy, and using ryy from the section table because it is the smaller of the two tabulated values still overstates the strut. Read rvv, or use the equivalent slenderness route of Cl. 7.5.1.2." },
          ],
        },

        {
          n: "6.8",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "Pd = Ae fcd, and the whole chapter is finding fcd.",
              "fcc = π²E/(KL/r)² — contains E, not fy.",
              "λ = √(fy/fcc); φ = 0.5[1 + α(λ−0.2) + λ²]; χ = 1/[φ + √(φ²−λ²)]; fcd = χ fy/γm0.",
              "α from the buckling class, assigned per axis by Table 10; welded and thick sections fare worse.",
              "Minor-axis slenderness almost always governs.",
              "Effective length from Table 11 — and sway is worth more than rotational restraint.",
              "Slenderness capped at 180 (dead + imposed) or 250 (wind/seismic combinations only).",
              "High-grade steel buys little in a slender column, because E does not change.",
              "Lacing adds 5% to the effective slenderness, battens 10%, and both carry 2.5% of the axial load as shear.",
            ]},
            { k: "p", t: "Chapters 7 and 8 take the same section and bend it. The first assumes something holds the compression flange in line; the second removes that assumption and finds that the beam has been behaving like a column all along — the column being its own compression flange." },
          ],
        },
      ],
    }

  );
})();
