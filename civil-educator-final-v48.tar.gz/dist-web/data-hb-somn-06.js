/* MACE Academy SOM notes — Thermal stresses and strains, M p.103–110 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------- α, thermal strain, free expansion */
    {
      n: "",
      title: "MACE notes — thermal strain, coefficient α and free expansion",
      hi: "ऊष्मीय विकृति, ऊष्मीय प्रसार गुणांक α और मुक्त प्रसार",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.103–104" },
        { k: "p", t: "<b>Thermal stresses &amp; strain.</b> A body may expand or contract due to an increase or decrease in temperature respectively. Normally, if T °C ↑ the body <b>expands</b>; if T °C ↓ the body <b>contracts</b>. The most important parameter in the analysis of thermal effects is the <b>coefficient of thermal expansion α</b>. (M p.103)" },
        { k: "def", term: "Coefficient of thermal expansion (α)", t: "It is the strain occurring for a 1 °C change in temperature. Strain occurs due to change in temperature, and thus the <b>strain per unit change in temperature</b> is called the coefficient of thermal expansion α. Unit: /°C.<br>• The coefficient of thermal expansion is a function of temperature. (M p.103)" },
        { k: "cmp", t: "Values of α for some standard materials (M p.103)", cols: ["α (/°C)"], rows: [
          ["Steel or concrete", "12 × 10⁻⁶"],
          ["Copper", "14 × 10⁻⁶"],
          ["Brass", "19 × 10⁻⁶"],
          ["Aluminium", "23 × 10⁻⁶"],
        ] },
        { k: "list", items: [
          "<b>Trick for remembering (Marathi, M p.103):</b>",
          "→ १२ व्या वर्षी α ची steel body होती — <i>at age 12, α had a steel body</i> (steel/concrete 12 × 10⁻⁶)",
          "→ २ वर्षानंतर १४ व्या वर्षी topper झाला — <i>two years later, at 14, he became topper</i> (copper 14 × 10⁻⁶)",
          "→ १९ व्या वर्षी Brass Band start केला — <i>at 19 he started a brass band</i> (brass 19 × 10⁻⁶)",
          "→ २३ व्या वर्षी Aluminium चे भांडे विकायचा — <i>at 23 he used to sell aluminium utensils</i> (aluminium 23 × 10⁻⁶)",
        ] },
        { k: "note", t: "<b>Source difference:</b> the MACE notes give copper α = 14 × 10⁻⁶ /°C (M p.103), while Worked example 2.8 earlier in this chapter uses α_copper = 17.5 × 10⁻⁶ /°C. <i>General Engineering Knowledge:</i> standard property tables list copper at roughly 16.5–17.5 × 10⁻⁶ /°C, so the 17.5 figure is closer to measured values; 14 × 10⁻⁶ is the notes' memory value. The ordering steel &lt; copper &lt; brass &lt; aluminium is the same in both. In an exam, always use the α given in the question." },
        { k: "h", t: "Linear, area and volume coefficients (M p.104)" },
        { k: "list", items: [
          "(i) Linear thermal expansion coefficient = <b>α_L</b> ⇐ associated with length changes",
          "(ii) Area thermal expansion coefficient = <b>α_a</b> ⇐ associated with area changes",
          "(iii) Volume thermal expansion coefficient = <b>α_v</b> ⇐ associated with volume changes",
        ] },
        { k: "eq", expr: "α_v = 3 α_L     ;     α_a = 2 α_L", where: [
          ["α_L", "linear coefficient of thermal expansion (/°C)"],
          ["α_a", "area (superficial) coefficient"],
          ["α_v", "volume (cubical) coefficient"],
        ] },
        { k: "h", t: "Thermal strain (M p.104)" },
        { k: "p", t: "Let α = strain per 1 °C change in temperature, and ε_T = strain for a T °C change in temperature.<br>If temperature increases → body expands (T₁ &lt; T₂). If temperature decreases → body contracts (T₁ &gt; T₂).<br>By proportion (side working): 1 °C → α ; ΔT °C → ε_T, so (M p.104):" },
        { k: "eq", expr: "ε_T = α · ΔT   ...(1)", where: [
          ["T or ΔT", "change in temperature; notes write ΔT = T₁ − T₂"],
          ["ε_T", "thermal strain"],
        ] },
        { k: "note", t: "<b>Check:</b> the notes write ΔT = T₁ − T₂ (M p.104). With T₁ = initial and T₂ = final temperature, a rise would give a negative value by that formula. Use ΔT as the <b>magnitude</b> of the change, |T₂ − T₁|, and decide expansion (rise) or contraction (fall) from the direction — exactly how the notes then use it in every numerical (e.g. 10 °C → 60 °C gives ΔT = 50 °C, M p.106)." },
        { k: "h", t: "Expansion or contraction due to change in temperature (M p.104)" },
        { k: "p", t: "Let ΔL = change in length/dimension due to a T °C change in temperature. But ε = ΔL/L; put in (1): ΔL/L = α · ΔT, so" },
        { k: "eq", expr: "ΔL = L · α · ΔT   ...(2)", where: [
          ["ΔL", "free expansion OR free contraction of the material"],
          ["L", "original length"],
        ] },
        { k: "p", t: "This is the <b>free</b> expansion or contraction of the material. If this free expansion and contraction is resisted or restricted by some constraint or support, then <b>stresses are induced corresponding to the restricted strain</b>. (M p.104)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "α ek material property hai — har 1 °C par kitni strain aati hai. Isse multiply karo temperature change se, to thermal strain milta hai (ε_T = αΔT); usse length se multiply karo, to free expansion milta hai (ΔL = LαΔT). Yeh sirf <b>deformation</b> hai, stress nahi. Stress tab aata hai jab koi support is movement ko rokta hai — yahi idea §2.4 (thermal stresses) mein bhi hai." },
        { k: "p", t: "α_v = 3α_L kyun? Ek cube L³ ko garam karo — har side L(1 + αΔT) ho jaati hai, volume L³(1 + αΔT)³ ≈ L³(1 + 3αΔT), kyunki αΔT bahut chhota hai aur uske square/cube neglect ho jaate hain. Isi tarah area mein 2α_L." },
        { k: "trap", t: "Free expansion LαΔT ko stress samajh lena — galat. Ek bar jo free hai (ek end fixed, doosra free), uski length badhti hai par stress <b>zero</b> hota hai. Aur α_v = 3α_L, α_a = 2α_L ko ulta (α_v = α_L/3) mat likhna." },
        { k: "real", t: "Steel aur concrete dono ka α notes mein 12 × 10⁻⁶ /°C diya hai — isi wajah se RCC mein garmi-sardi mein dono saath expand/contract karte hain aur bond nahi tootta." },
      ],
    },

    /* ---------------------------------------------- thermal stress, gaps, Q1–Q4 */
    {
      n: "",
      title: "MACE notes — thermal stress, gap cases and restrained bars (Q1–Q4)",
      hi: "ऊष्मीय प्रतिबल, गैप वाले केस और बंधी हुई छड़ें",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.104–106" },
        { k: "h", t: "Thermal stress (M p.104)" },
        { k: "p", t: "We know that σ = E × ε, so σ_T = E × ε_T:" },
        { k: "eq", expr: "σ_T = E α ΔT   ...(3)", where: [
          ["σ_T", "thermal stress when the free expansion/contraction is fully prevented"],
          ["E", "modulus of elasticity"],
        ] },
        { k: "steps", items: [
          "Side derivation (M p.104): α in /°C; ε_T = αT; ε_T = ΔL/L.",
          "ΔL = LαT ...(i) (free change)",
          "ΔL = PL/AE ...(ii) (change that must be pushed back by the restraint)",
          "LαT = σ · L/E — L cancels",
          "σ = E · ε ⇒ <b>σ = EαT</b>",
        ] },
        { k: "h", t: "Concept of stress induction due to prevention of thermal expansion or contraction (M p.105)" },
        { k: "p", t: "<b>Figure (M p.105, left):</b> a bar of length L fixed at a non-yielding support A (left wall). A rigid wall B stands a small <b>gap</b> beyond the free end. A dashed outline shows the free expansion (ΔL)_free extending past wall B; the part of (ΔL)_free that lies beyond B is marked (ΔL)_Restricted, with the note “stress developed due to this restriction”. Working beside it: ΔL = PL/AE = σ_T L/E, so σ_T = (ΔL/L) · E, i.e. <b>σ_T = ε_T · E</b>." },
        { k: "p", t: "<b>Figure (M p.105, right):</b> the same bar fixed at A with wall B at a gap, but here the dashed (ΔL)_free = LαT is <b>less</b> than the gap." },
        { k: "def", term: "Case (i): free expansion more than gap", t: "AB = (L + gap) = L + (ΔL)_free − (ΔL)_Restricted — L cancels<br>gap = (ΔL)_free − (ΔL)_Restricted<br>gap = LαT − σ_T L/E<br><b>σ_T = (E/L) [LαT − gap]</b> (M p.105)" },
        { k: "def", term: "Case (ii): free expansion less than gap", t: "i.e. LαT ≤ gap ⇒ <b>σ_T = 0</b> (M p.105)" },
        { k: "eq", expr: "σ_T = (E/L)(LαT − gap)  if LαT > gap ;   σ_T = 0  if LαT ≤ gap", where: [
          ["gap", "clearance between the free end and the rigid wall (mm)"],
        ] },
        { k: "eg", title: "MACE notes example — Q1: bar between two immovable supports", given: "A bar of length L and cross-sectional area A is fixed between two immovable supports as shown. What is the magnitude of the stress developed in the bar if L = 1000 mm, E = 200 GPa, α = 10 × 10⁻⁶ /°C and the temperature rises by 40 °C? (Figure: bar 1000 mm between two fixed walls, 40 °C ↑.)", steps: [
          { t: "Method 1", w: "σ_T = E · ε_T = EαT\n= 200 × 10³ × 10 × 10⁻⁶ × 40\nσ_T = 80 MPa" },
          { t: "Method 2 (figure: dashed (ΔL)_free = LαT beyond the right wall, equal to (ΔL)_Restricted; note: the immovable support will not let the bar expand)", w: "σ_T = ε_T · E\n(ΔL)_free = (ΔL)_Restricted\nLαT = σ_T L/E  (L cancels)\nσ_T = EαT = 80 MPa" },
        ], ans: "σ_T = 80 MPa (compression, since the bar is heated and held). (M p.105)" },
        { k: "eg", title: "MACE notes example — Q2: hanging bar with a 2 mm gap to the floor", given: "A bar of length 2 m is fixed at support A upside down (hanging) above a floor as shown. If the end of the bar is at a distance of 2 mm from the floor, find the stress developed in the bar if the temperature is increased from 10 °C to 60 °C. (E = 200 GPa, A = 100 mm², α = 10 × 10⁻⁶ /°C.) (Figure: vertical bar hanging from a fixed ceiling, bottom end 2 mm above the floor; the length in the question sketch is marked 1 m, but the question and answer use 2 m.)", steps: [
          { t: "Free expansion", w: "free expansion = LαT\n= 2000 × 10 × 10⁻⁶ × 50\n= 1 mm  (notes: 2 struck out, 1 written)" },
          { t: "Compare with gap", w: "free expansion (1 mm) < gap (2 mm)\nNo stress is developed" },
          { t: "OR — by the gap formula (marked ✗ in the notes, because the bracket comes out negative)", w: "(ΔL)_free = gap + (ΔL)_Restricted\nLαT = 2 mm + σ_T L/E\nσ_T = (E/L)[LαT − 2]\n= (200 × 10³ / 2000)[2000 × 10 × 10⁻⁶ × 50 − 2]\nσ_T = 0" },
        ], ans: "No stress is developed, σ_T = 0 (free expansion 1 mm is less than the 2 mm gap). (M p.106)" },
        { k: "note", t: "<b>Check:</b> the bracket in the “OR” working is [1 − 2] = −1 mm, which gives −100 MPa if multiplied out. A negative value only means the gap never closes; the formula σ_T = (E/L)(LαT − gap) is valid only when LαT &gt; gap, so σ_T = 0 is correct. The notes mark this route ✗ for that reason — always compare LαT with the gap first. The 1 m label on the question sketch (M p.105) is a drawing slip; the question text and the answer sketch (M p.106) both use 2 m." },
        { k: "eg", title: "MACE notes example — Q3: thrust on the supports", given: "A bar of cross-sectional area A and length L, having coefficient of thermal expansion α and modulus of elasticity E, is subjected to an increase in temperature of ΔT °C. What is the support reaction or the thrust developed on support A? (Figure: bar between fixed walls A and B at T °C; free body below shows the bar marked C (compression) with F → at the left end and ← F at the right end.)", steps: [
          { t: "Support reaction is a force", w: "F = σ · A\n= σ_T · A" },
        ], ans: "F = AEαT (M p.106)" },
        { k: "eg", title: "MACE notes example — Q4: bar fixed at one end and free at the other", given: "A bar is fixed at one end and free at the other end and is subjected to an increase in temperature. What is (i) the free expansion of the bar, (ii) the stress developed in the bar, (iii) the strain in the bar? [A = 100 mm², α = 10 × 10⁻⁶ /°C, E = 200 GPa, L = 1000 mm] (Figure: cantilever bar fixed at the left wall, free right end, with dashed extension (ΔL)_free.)", steps: [
          { t: "(i) Free expansion", w: "(ΔL)_free = LαT" },
          { t: "(ii) Stress", w: "σ_T = 0 — for free expansion" },
          { t: "(iii) Strain", w: "ε_T = αT" },
        ], ans: "(ΔL)_free = LαT ; σ_T = 0 ; ε_T = αT (M p.106)" },
        { k: "note", t: "The temperature rise is not given in Q4, so the notes stop at the expressions. With the given data they become (ΔL)_free = 1000 × 10 × 10⁻⁶ × T = 0.01·T mm and ε_T = 10 × 10⁻⁶ · T, with σ_T = 0 for any T." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har thermal problem ko teen sawaalon mein todo: (1) free expansion kitna hota — LαT; (2) support kitna allow karta hai — 0 (rigid walls), gap (gap wala case), ya poora (free end); (3) jo hissa roka gaya, wahi stress banata hai: σ = E × (roka gaya ΔL)/L. Rigid walls par poora roka → σ = EαT; gap par sirf (LαT − gap) roka; free end par kuch nahi roka → σ = 0. Yeh wahi teen rows hain jo §2.4 ki table mein hain." },
        { k: "p", t: "Notice: σ = EαT mein <b>L aur A dono nahi hain</b>. Lambi ya chhoti, moti ya patli — fully restrained bar mein stress same. Par force F = AEαT area par depend karta hai, isliye moti bar support par zyada thrust daalti hai." },
        { k: "trap", t: "Gap wale sawaal mein seedha σ = (E/L)(LαT − gap) laga dena bina check kiye — agar LαT &lt; gap hai to answer negative aayega, jo galat hai; sahi answer σ = 0 hai (Q2). Aur Q3 mein reaction ko stress (EαT) likh dena — reaction force hai, area se multiply karo: F = AEαT." },
        { k: "real", t: "Rail joints, bridge expansion joints aur RCC road slabs ke beech chhoda gaya gap exactly Q2 wala idea hai: agar gap expected LαT se bada hai, to garmi mein bhi koi thermal stress nahi aata." },
      ],
    },

    /* ---------------------------------------------- confined cube and plate, Q5–Q8 */
    {
      n: "",
      title: "MACE notes — thermal stresses in a confined cube and plate (Q5–Q8)",
      hi: "बंधे हुए घन और प्लेट में ऊष्मीय प्रतिबल",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.106–108" },
        { k: "p", t: "When a block is restrained in more than one direction, the stress in one direction also changes the length in the other directions through <b>Poisson's effect</b>. The notes handle this by adding up all dimensional changes in a restrained direction and setting the total to zero. (M p.107)" },
        { k: "eg", title: "MACE notes example — Q5: cube confined in all directions", given: "A bar of cubical shape of side length L is confined in all directions between rigid supports. If the bar is heated uniformly by T °C, find the force exerted in any direction. Options: (a) EαTL²/(1 − μ)  (b) EαTL/(1 − 2μ)  (c) EαTL²/(1 − 2μ)  (d) EαTL/(1 − μ). (Figure: cube with each side L.)", steps: [
          { t: "Rigid in all three directions", w: "ε_x = 0 ⇒ (ΔL)_x = 0\nε_y = 0 ⇒ (ΔL)_y = 0\nε_z = 0 ⇒ (ΔL)_z = 0" },
          { t: "Suppose ε_x = 0, (ΔL)_x = 0, i.e. the algebraic sum of all dimensional changes in x = 0", w: "+ LαT + μ·ε_y·L + μ·ε_z·L − (σ_x/E)·L = 0\nLαT = free expansion (mm)\nμ·ε_y·L = expansion due to Poisson's effect from the y-direction\nμ·ε_z·L = expansion due to Poisson's effect from the z-direction\n(σ_x/E)·L = minus, because free expansion is not happening in x (Marathi note: free expansion होत नाहीये म्हणून LαT in x-dir मधून minus — 'free expansion is not happening, so subtract from LαT in x')" },
          { t: "Write strains as stresses", w: "LαT + μ(σ_y/E)L + μ(σ_z/E)L − (σ_x/E)L = 0" },
          { t: "In a cube with no external load and only a temperature rise", w: "σ_x = σ_y = σ_z = σ\nLαT + (σL/E)[2μ − 1] = 0\n(σL/E)[2μ − 1] = −LαT\nσ = −LαTE / (L(2μ − 1)) = αTE/(1 − 2μ)" },
          { t: "Force on one face", w: "P/A = αTE/(1 − 2μ)\nP/(L × L) = αTE/(1 − 2μ)\nP = αTEL²/(1 − 2μ)" },
        ], ans: "P = αTEL²/(1 − 2μ) — option (c). (M p.106–107)" },
        { k: "p", t: "<b>Figure (M p.107):</b> cube of side L with σ_y, ε_y arrow on the top face; the x-direction arrow is labelled “LαT − (σ_x/E)L = LαT − ε_x·L”, with the note ε_x = μ·ε_y (Poisson strain from y)." },
        { k: "eg", title: "MACE notes example — Q6: cube free in x, confined in y and z", given: "A bar of cubical shape of side length L is confined on all faces except one face in the x-direction, as shown. What is the force exerted in the x-direction? Suppose the bar is heated uniformly by T °C. (Figure: cube with σ_y, ε_y on top (arrow down), σ_z, ε_z on the front face, free in x with note ΔL = (μ·ε_y + μ·ε_z)·L; side sketch: square element held by hatched supports on the y and z faces, free in x.)", steps: [
          { t: "Bar is free to move in x", w: "σ_y = σ_z = σ" },
          { t: "Changes of length in x", w: "(1) (ΔL_x)_free = LαT\n(2) (ΔL_x)_σy = ε_x·L = μ·ε_y·L = μ(σ_y/E)·L\n(3) (ΔL_x)_σz = ε_x·L = μ·ε_z·L = μ(σ_z/E)·L\n(4) (ΔL_x)_Resisted = 0" },
          { t: "Total", w: "Total (ΔL)_x = LαT + μ(σ_y/E)L + μ(σ_z/E)L\n(ΔL)_x = LαT + 2μσL/E — elongation in the x-direction\nε_x = (ΔL)/L = αT + 2μσ/E" },
          { t: "Force in x", w: "Since there is free expansion in x, there is no force exerted in x.\nP = 0 — use general logic to avoid wasting time." },
        ], ans: "P_x = 0 (M p.107)" },
        { k: "note", t: "NOTE (M p.108): since the bar is free to move in x, there is no stress developed in x and therefore no force developed in x. However, if asked the force in y there will be some force in y, which can be calculated in a similar manner; there will also be a force in z, calculated the same way. i.e. <b>F_x = 0, F_y ≠ 0, F_z ≠ 0</b>." },
        { k: "eg", title: "MACE notes example — Q7: cube held only in y, free in x and z", given: "A cubical element is fixed from all sides and there is a decrease in temperature by T °C as shown. If the cube is of dimension L and it is free to expand in the x and z directions respectively, what is the force exerted in the y-direction? (Figure: square L × L held between rigid hatched supports at top and bottom; cube sketch with vertical arrows at the supported faces (top ↓, bottom ↑), free arrow → ε_x and a free z arrow. The word 'decrease' is written over 'increase' in the notes.)", steps: [
          { t: "Free directions", w: "Bar is free to move in x and z\nF_x = 0, F_z = 0 — free expansion\nF_y ≠ 0" },
          { t: "Changes of length in y", w: "(1) (ΔL_y)_free = LαT\n(2) (ΔL_y)_Resisted = ε_y·L = (σ_y/E)·L\nNo Poisson's effect from ε_x and ε_z — they are free strains" },
          { t: "Total", w: "(ΔL_y)_Total = + LαT − (σ_y/E)·L\nBut rigid supports in y: (ΔL_y)_Total = 0\nσ_y L/E = LαT  (L cancels)\nF/A = EαT\nF/(L × L) = EαT" },
        ], ans: "F = EαTL² (M p.108)" },
        { k: "note", t: "<b>Check:</b> the question (as overwritten) says the temperature <b>decreases</b>, while the working is written as an expansion (“free expansion”, + LαT). The magnitude F = EαTL² is the same either way; for a fall in temperature the y-supports hold the cube from <b>contracting</b>, so the force is <b>tensile</b> (supports pull on the cube); for a rise it would be compressive. With σ_x = σ_z = 0 there is no Poisson coupling, which is why the answer has no μ." },
        { k: "eg", title: "MACE notes example — Q8: square plate held on three edges", given: "A square plate of size L × L rigidly held between three edges is free to expand along the fourth edge, as shown. If the temperature is increased by T °C, find the final expansion along the fourth edge. (Figure: square plate L × L, hatched rigid supports on the left, top and bottom edges; right edge free, dashed expanded outline with arrow 'ΔL = ?'; expansion split into LαT and Poisson's effect = μ·ε_y·L = ε_x·L.)", steps: [
          { t: "Changes of length in x", w: "(1) (ΔL_x)_free = LαT\n(2) (ΔL_x)_Poisson's = ε_x·L = (μ·ε_y)·L" },
          { t: "Total", w: "Total (ΔL)_x = LαT + μ·ε_y·L = LαT + μ(σ_y/E)·L\n= LαT + μ(EαT/E)·L" },
        ], ans: "(ΔL)_x = LαT(1 + μ) (M p.108)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Har restrained direction ke liye ek hi rule: <b>us direction ki saari length changes ka sum = 0</b> — free thermal expansion (+LαT), doosri directions ke compressive stress se Poisson ka phulaav (+μσL/E har ek ke liye), aur us direction ka apna compressive stress (−σL/E). Jo direction free hai, wahan stress aur force zero — calculation ki zarurat hi nahi (Q6: P = 0)." },
        { k: "p", t: "Pattern yaad rakho: sirf ek direction mein roka → σ = EαT (Q7); teeno directions mein roka → σ = EαT/(1 − 2μ) (Q5), zyada, kyunki doosri directions ka Poisson phulaav bhi rokna padta hai. Do directions roke, ek free → free direction mein extra expansion milta hai (Q6, Q8: LαT(1 + μ) plate ke liye)." },
        { k: "trap", t: "Q5 mein option (b) EαTL/(1 − 2μ) choose kar lena — woh stress × L hai, force nahi. Force = stress × face area L². Aur Q6 mein free direction ka force nikalne mein time waste karna — free direction mein P = 0 hota hai." },
        { k: "real", t: "Ek concrete ya steel block jo chaaron taraf se rigid cheezon se ghira ho (jaise machine foundation ka bolt-hole grout ya pipe ke andar bhara material), garam hone par akele bar se zyada stress develop karta hai — yahi Q5 ka 1/(1 − 2μ) factor dikhata hai." },
      ],
    },

    /* ---------------------------------------------- nature of stresses: bimetal, composite, series */
    {
      n: "",
      title: "MACE notes — nature of thermal stresses: bimetal strips, composite bars and bars in series",
      hi: "ऊष्मीय प्रतिबल की प्रकृति: द्विधातु पट्टी, संयुक्त छड़ और श्रेणी में छड़ें",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.109–110" },
        { k: "h", t: "I: Two strips of different α rigidly fixed together (bimetal strip) (M p.109)" },
        { k: "p", t: "<b>Figure (M p.109):</b> composite bar of two strips — upper strip ① with α₁, lower strip ② with α₂ — joined together along their length; the label “Rigidly fixed” points to the interface (red line)." },
        { k: "list", items: [
          "ज्याच्या α जास्त तो T↑ मध्ये जास्त expand होईल — <i>the one with the larger α will expand more when T rises</i>.",
          "ज्याच्या α जास्त तो T↓ मध्ये जास्त contract होईल — <i>the one with the larger α will contract more when T falls</i>. (M p.109)",
        ] },
        { k: "cmp", t: "Nature of stresses in a bimetal strip (M p.109)", cols: ["Upper strip (α₁) / lower strip (α₂)", "Bent shape"], rows: [
          ["Case (i) T ↑, α₁ > α₂", "Upper C / lower T", "Convex upward, concave downward"],
          ["Case (i) T ↑, α₁ &lt; α₂", "Upper T / lower C", "Convex downward, concave upward"],
          ["Case (ii) T ↓, α₁ > α₂", "Upper T / lower C", "Convex downward, concave upward"],
          ["Case (ii) T ↓, α₁ &lt; α₂", "Upper C / lower T", "Convex upward, concave downward"],
        ] },
        { k: "list", items: [
          "<b>Figures (M p.109), as drawn:</b>",
          "Case (i) T ↑, α₁ &gt; α₂: upper bar drawn longer than lower; red arrows at both ends of the upper bar pointing inward. Side note (Marathi): “हा expand व्हायचा try करतोय पण α₂ त्याला compress करेल” — <i>this one tries to expand but α₂ will compress it</i>. Below: strip bent as an arch, upper layer C, lower layer T.",
          "Case (i) T ↑, α₁ &lt; α₂: lower bar drawn longer; red arrows at both ends of the lower bar pointing inward. Below: strip sagging, upper T, lower C.",
          "Case (ii) T ↓, α₁ &gt; α₂: upper bar drawn longer; red arrows at both ends of the upper bar pointing outward. Below: strip sagging, upper T, lower C.",
          "Case (ii) T ↓, α₁ &lt; α₂: lower bar drawn longer; red arrows at both ends of the lower bar pointing inward. Below: strip arched, upper C, lower T.",
        ] },
        { k: "note", t: "<b>Check:</b> the C/T labels and bent shapes in all four cases are correct. In the last sketch (T ↓, α₁ &lt; α₂) the arrows on the lower bar are drawn inward, which would mean compression; but on cooling the lower bar (larger α) wants to contract more and is held back by the upper bar, so it is pulled <b>outward — tension</b>, matching the “lower T” label. (On cooling, the bar with larger α ends up the shorter, inner, concave side; on heating it is the longer, outer, convex side.)" },
        { k: "p", t: "<b>Example (M p.109):</b> upper layer <b>copper</b> α = 14 × 10⁻⁶ /°C, lower layer <b>steel</b> α = 12 × 10⁻⁶ /°C.<br>• T ↑: strip bends convex upward — copper (upper) C, steel (lower) T.<br>• T ↓: strip bends convex downward — copper (upper) T, steel (lower) C." },
        { k: "h", t: "II: A bar of single material fixed between two supports (M p.109)" },
        { k: "list", items: [
          "T °C ↑ ⟹ <b>compression</b>",
          "T °C ↓ ⟹ <b>tension</b>",
        ] },
        { k: "h", t: "III: Composite bar (two bars side by side, joined at the end), α₁ > α₂, T °C ↑ (M p.109)" },
        { k: "p", t: "<b>Figure (M p.109):</b> composite bar fixed at the left wall. Upper bar “α₁ E₁ A₁ L” labelled C; lower bar “α₂ E₂ A₂ L” labelled T; original length L shown below. The upper bar's dashed free expansion Lα₁T is pulled back by (ΔL)_Restricted = (σ₁/E₁)·L = ε₁L (arrow left). The lower bar's free expansion Lα₂T (red) is extended further by (ΔL)_Restricted = (σ₂/E₂)·L (arrow right). A “final length” dimension runs from the wall to the common end." },
        { k: "p", t: "Final length of both bars is the same: (final length)₁ = (final length)₂<br>L + Lα₁T − (σ₁/E₁)L = L + Lα₂T + (σ₂/E₂)L — L cancels throughout (M p.109):" },
        { k: "eq", expr: "α₁T − σ₁/E₁ = α₂T + σ₂/E₂", where: [
          ["σ₁", "compressive stress in the bar with larger α (α₁)"],
          ["σ₂", "tensile stress in the bar with smaller α (α₂)"],
        ] },
        { k: "eq", expr: "ΔL = L · α_equ · T ;   α_equivalent = (α₁E₁A₁ + α₂E₂A₂)/(E₁A₁ + E₂A₂) = α₁(E₁A₁/ΣEA) + α₂(E₂A₂/ΣEA)", where: [
          ["ΔL", "actual (common) expansion of the composite bar"],
          ["α_equ", "equivalent α — the EA-weighted average of α₁ and α₂"],
        ] },
        { k: "note", t: "The α_equivalent result follows from the equation above together with equilibrium σ₁A₁ = σ₂A₂ (no external load): common strain ε = α₁T − σ₁/E₁ = α₂T + σ₂/E₂ ⇒ σ₁A₁ = (α₁T − ε)E₁A₁ = (ε − α₂T)E₂A₂ ⇒ ε = T(α₁E₁A₁ + α₂E₂A₂)/(E₁A₁ + E₂A₂). Rearranged, the notes' equation is the same as the compatibility equation (α₁ − α₂)ΔT = σ₁/E₁ + σ₂/E₂ used in §2.4 — no source difference." },
        { k: "p", t: "<b>T °C ↓ (M p.110):</b> figure — composite bar fixed at the left wall; upper bar drawn shorter, labelled T; lower bar longer, labelled C. Notes: “If temp. is reduced then bar having more α will be in compression, i.e. upper bar in tension &amp; lower bar in compression.”" },
        { k: "note", t: "<b>Check:</b> the first half of that sentence is a slip. On cooling, the bar with <b>more α</b> (upper, α₁ &gt; α₂) wants to contract more and is held back by the other bar, so it is in <b>tension</b>; the bar with less α is in compression. The “i.e.” part (upper bar in tension, lower bar in compression) and the T/C labels in the figure are correct. Rule: heating → larger-α bar in compression; cooling → larger-α bar in tension." },
        { k: "h", t: "IV: Two bars in series between two fixed walls (M p.110)" },
        { k: "p", t: "<b>Figure (M p.110):</b> two bars end to end between two fixed walls; left bar (larger section) “A₁E₁α₁T” labelled C, right bar (smaller section) “A₂E₂α₂T” labelled C; reaction R₁ at the left wall (arrow →) and R₂ at the right wall (arrow ←)." },
        { k: "steps", items: [
          "(i) Here <b>R₁ = R₂</b> — there is no external force, therefore both will be in equilibrium.",
          "(ii) Total compressive force in the bar is the same: <b>σ₁A₁ = σ₂A₂</b>.",
          "(iii) <b>ΔL₁ + ΔL₂ = 0</b> — compatibility condition, with ΔL₁ = L₁α₁T − (σ₁/E)·L₁ and ΔL₂ = L₂α₂T − (σ₂/E)·L₂. (M p.110)",
        ] },
        { k: "note", t: "<b>Check:</b> the notes write a single E in both ΔL expressions. For two different materials use E₁ in ΔL₁ and E₂ in ΔL₂: ΔL₁ = L₁α₁T − σ₁L₁/E₁, ΔL₂ = L₂α₂T − σ₂L₂/E₂. Solving (ii) and (iii) with R = σ₁A₁ = σ₂A₂ gives R = T(L₁α₁ + L₂α₂) / (L₁/(A₁E₁) + L₂/(A₂E₂)); then σ₁ = R/A₁ and σ₂ = R/A₂ — the smaller section carries the larger stress." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Nature (C ya T) nikalne ki ek line: <b>jo zyada badalna chahta hai, use roka jaata hai</b>. Garmi mein zyada-α wala zyada phailna chahta hai → doosra use daba deta hai → compression. Sardi mein zyada-α wala zyada sikudna chahta hai → doosra use kheench ke rakhta hai → tension. Bimetal strip mein yahi forces ek couple banaate hain jo strip ko modta hai — lambi layer bahar (convex) wali side par aati hai." },
        { k: "p", t: "Composite (side-by-side) aur series (end-to-end) ka farak: side-by-side mein <b>strain same</b> (final length same), force equal-opposite; series mein <b>force same</b> (R₁ = R₂), aur total length change zero. α_equ dikhata hai ki composite bar ka asli expansion dono α ke beech mein kahin hota hai — jis material ka EA bada, uske α ke paas." },
        { k: "trap", t: "Series bars mein dono bars ka stress same maan lena — galat. <b>Force</b> same hai (σ₁A₁ = σ₂A₂), stress nahi; patli bar mein stress zyada. Aur composite bar mein cooling par bhi “zyada α → compression” likh dena (jaise notes ki slip) — cooling par zyada-α wali bar tension mein hoti hai." },
        { k: "real", t: "Bimetal strip ka bending hi thermostat, electric iron aur purane fire-alarm switches mein contact kholta/band karta hai (copper/brass + steel jaise pair)." },
      ],
    },

    /* ---------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — thermal stresses and strains (M p.103–110)",
      hi: "पुनरावृत्ति — ऊष्मीय प्रतिबल एवं विकृति",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and results" },
        { k: "list", items: [
          "α = strain per 1 °C change in temperature; α is a function of temperature (M p.103).",
          "α: steel/concrete 12, copper 14, brass 19, aluminium 23 (× 10⁻⁶ /°C) — memory line ‘12 steel body, 14 topper, 19 brass band, 23 aluminium भांडे’ (M p.103). Copper is ≈ 17.5 × 10⁻⁶ in §2.4 (source difference).",
          "α_v = 3α_L ; α_a = 2α_L (M p.104).",
          "ε_T = αΔT ; free expansion/contraction ΔL = LαΔT (M p.104).",
          "Fully restrained: σ_T = EαT = ε_T·E (M p.104–105).",
          "Gap: σ_T = (E/L)(LαT − gap) if LαT &gt; gap ; σ_T = 0 if LαT ≤ gap (M p.105).",
          "Q1: bar between rigid walls, E = 200 GPa, α = 10 × 10⁻⁶, ΔT = 40 °C → σ_T = 80 MPa (M p.105).",
          "Q2: 2 m bar, 2 mm gap, 10 → 60 °C → free expansion 1 mm &lt; gap → σ_T = 0 (M p.106).",
          "Q3: thrust on supports F = AEαT (M p.106).",
          "Q4: one end free → ΔL = LαT, σ_T = 0, ε_T = αT (M p.106).",
          "Q5: cube confined in all directions → σ = EαT/(1 − 2μ), P = EαTL²/(1 − 2μ) (M p.107).",
          "Q6: cube free in x → F_x = 0, F_y ≠ 0, F_z ≠ 0; ε_x = αT + 2μσ/E (M p.107–108).",
          "Q7: cube held only in y → F = EαTL² (tension for a fall, compression for a rise) (M p.108).",
          "Q8: plate held on three edges → expansion of free edge ΔL = LαT(1 + μ) (M p.108).",
          "Bimetal strip: larger α expands more on heating (→ C, convex side) and contracts more on cooling (→ T, concave side); copper over steel arches upward when heated (M p.109).",
          "Single bar between supports: T ↑ compression, T ↓ tension (M p.109).",
          "Composite bar: α₁T − σ₁/E₁ = α₂T + σ₂/E₂ ; ΔL = L·α_equ·T ; α_equ = (α₁E₁A₁ + α₂E₂A₂)/(E₁A₁ + E₂A₂) (M p.109).",
          "Composite bar cooled: larger-α bar in tension, smaller-α bar in compression (M p.110, corrected wording).",
          "Bars in series between walls: R₁ = R₂ ; σ₁A₁ = σ₂A₂ ; ΔL₁ + ΔL₂ = 0 with ΔL = LαT − σL/E for each bar (use E₁, E₂) (M p.110).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
