/* MACE Academy SOM notes — Deflection of axially loaded bars, self-weight, bar of uniform strength, axial strain energy and superposition, M p.62–72 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------------- M p.62 */
    {
      n: "",
      title: "MACE notes — Deflection of non-prismatic bars and the circular tapered bar",
      hi: "अप्रिज़्मीय दंड का विक्षेप — वृत्ताकार टेपर्ड दंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.62" },
        { k: "p", t: "<b>Deflection of axially loaded bars</b> [lecture V-12] — deflection of a bar of arbitrary cross section. (M p.62)" },
        { k: "h", t: "① Non-prismatic bar" },
        { k: "p", t: "Figure (M p.62): a non-prismatic bar — a narrow left portion that widens smoothly (curved flare) into a wider right portion. Axial load P ← at the left end and → P at the right end. A hatched elemental strip at distance <b>x</b> from the left end, of width <b>dx</b>, carries load <b>Pₓ</b> (arrows ← and →) and has area <b>Aₓ</b>; total length <b>L</b>." },
        { k: "list", items: [
          "<b>Pₓ</b> = load on elemental strip, i.e. external load (M p.62)",
          "<b>Aₓ</b> = area of elemental strip (M p.62)",
          "<b>dx</b> = length of strip (M p.62)",
          "<b>L</b> = total length of bar (M p.62)",
        ] },
        { k: "steps", items: [
          "We know, ΔL = PL/(AE) (M p.62)",
          "Elongation of elemental strip: d(ΔL) = Pₓ·dx / (Aₓ·E) (M p.62)",
          "Integrate from 0 → L to get the total elongation (M p.62)",
        ] },
        { k: "eq", expr: "★ ΔL = ∫₀ᴸ (Pₓ · dx) / (Aₓ · E)      (M p.62)", where: [
          ["Pₓ", "load on the elemental strip"],
          ["Aₓ", "area of the elemental strip at distance x"],
          ["E", "modulus of elasticity"],
        ] },
        { k: "h", t: "② Non-prismatic circular tapered bar" },
        { k: "p", t: "Figure (M p.62): a frustum of a cone lying horizontally — small-end diameter <b>D₁</b> (left), large-end diameter <b>D₂</b> (right); a hatched (red) elemental disc of diameter <b>Dₓ</b> at distance <b>x</b> from the small end, width <b>dx</b>, area <b>Aₓ</b>, load <b>Pₓ</b>; total length <b>L</b>." },
        { k: "steps", items: [
          "We know, ΔL = PL/(AE); elongation of elemental strip d(ΔL) = Pₓ·dx/(Aₓ·E) (M p.62)",
          "Integrate from 0 → L: ΔL = ∫₀ᴸ Pₓ·dx/(Aₓ·E), where Aₓ = (π/4)Dₓ² = (π/4)(D₁ + k·x)² (M p.62)",
        ] },
        { k: "eq", expr: "★ (MES)  ΔL = 4PL / (π D₁ D₂ E)      (M p.62)", where: [
          ["D₁, D₂", "diameters at the small and large ends"],
          ["P", "axial load; L = length; E = modulus of elasticity"],
        ] },
        { k: "h", t: "To calculate Dₓ by interpolation (M p.62)" },
        { k: "cmp", t: "Interpolation table (M p.62)", cols: ["x"], rows: [
          ["D₁", "0"],
          ["Dₓ", "x"],
          ["D₂", "L"],
        ] },
        { k: "p", t: "Figure (M p.62): a trapezium — left side D₁ at x = 0, an intermediate dashed ordinate Dₓ at distance x, right side D₂ at x = L; base length L. Curved arrows link D₁–Dₓ–D₂ with 0–x–L." },
        { k: "steps", items: [
          "(Dₓ − D₁)/(x − 0) = (D₂ − D₁)/(L − 0) (M p.62)",
          "Dₓ = D₁ + ((D₂ − D₁)/L)·x (M p.62)",
          "<b>Dₓ = D₁ + k·x</b>, where k = (D₂ − D₁)/L = <b>rate of tapering</b> (M p.62)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Formula PL/AE sirf tab chalta hai jab poori length par P aur A dono constant hon. Agar area badal raha hai, to bar ko patli-patli slices (dx) mein kaato — har slice itni chhoti hai ki uske andar area constant maan sakte ho. Har slice ka stretch Pₓdx/(AₓE), aur sabka total = integral. Yahi ek master formula hai; circular, square, rectangular tapered — sab isi se nikalte hain, bas Aₓ ka expression badalta hai." },
        { k: "p", t: "Circular taper mein diameter <b>linearly</b> badhta hai (Dₓ = D₁ + kx), lekin area diameter ka <b>square</b> hai. Isliye 1/Aₓ ka integral end diameters ka <b>product</b> D₁D₂ deta hai — average diameter ka square nahi. Section 2.2 ka Worked example 2.4 isi ko numbers se dikhata hai." },
        { k: "trap", t: "k = (D₂ − D₁)/L ko 'rate of tapering' kehte hain — iski unit mm/mm (dimensionless) hai, aur x hamesha <b>chhote end (D₁)</b> se naapo. Agar x bade end se naapoge to Dₓ = D₂ − kx likhna padega; sign galat hua to integral galat aayega." },
      ],
    },

    /* ---------------------------------------------------------- M p.63 */
    {
      n: "",
      title: "MACE notes — Square and rectangular tapered bars, and prismatic bar formulas",
      hi: "वर्गाकार व आयताकार टेपर्ड दंड तथा प्रिज़्मीय दंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.63" },
        { k: "h", t: "③ Non-prismatic square tapered bar" },
        { k: "p", t: "Figure (M p.63): a square tapered bar in 3-D — small end <b>B₁ × B₁</b>, large end <b>B₂ × B₂</b>; a hatched elemental strip of side <b>Bₓ</b> and area <b>Aₓ</b> at distance <b>x</b> from the small end; total length <b>L</b>." },
        { k: "eq", expr: "k = (B₂ − B₁) / L = rate of tapering      (M p.63)", where: [] },
        { k: "eq", expr: "★ ΔL = PL / (B₁ B₂ E)      (M p.63)", where: [
          ["B₁, B₂", "sides of the square section at the small and large ends"],
        ] },
        { k: "h", t: "④ Non-prismatic rectangular tapered bar" },
        { k: "p", t: "Figure (M p.63): a rectangular tapered plate in 3-D, thickness <b>t = constant</b>; width <b>B₁</b> at the small end, <b>B₂</b> at the large end; a hatched strip of width dx at distance x; total length L." },
        { k: "list", items: [
          "t = thickness of bar (M p.63)",
          "B₁, B₂ = dimensions (widths) of bar at the two ends (M p.63)",
        ] },
        { k: "eq", expr: "ΔL = PL / ( [ t (B₂ − B₁) / logₑ(B₂/B₁) ] · E )      (M p.63)", where: [
          ["t (B₂ − B₁)/logₑ(B₂/B₁)", "acts as the 'equivalent area' of the rectangular tapered bar"],
        ] },
        { k: "eq", expr: "★ ΔL = P · L · logₑ(B₂/B₁) / ( t · E · (B₂ − B₁) )      (M p.63)", where: [
          ["t", "constant thickness"],
          ["B₁, B₂", "widths at the small and large ends"],
        ] },
        { k: "h", t: "Prismatic bars — ΔL = PL/AE (M p.63)" },
        { k: "cmp", t: "Elongation of prismatic bars (M p.63)", cols: ["Section (figure)", "ΔL"], rows: [
          ["1) Circular", "circle of diameter d", "ΔL = 4PL / (πd²E)"],
          ["2) Square", "square of side a × a", "ΔL = PL / (a²E)"],
          ["3) Rectangular", "rectangle of width b, depth d", "ΔL = PL / (b·d·E)"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Pattern dekho: circular taper → 4PL/(πD₁D₂E), square taper → PL/(B₁B₂E). Dono mein prismatic formula ka 'side²' ya 'd²' bas <b>dono ends ke product</b> se replace ho gaya. Agar D₁ = D₂ = d rakh do, to tapered formula wapas prismatic 4PL/(πd²E) ban jaata hai — yeh ek accha self-check hai." },
        { k: "p", t: "Rectangular taper alag hai kyunki wahan sirf ek dimension (width) badal rahi hai, thickness t fixed hai. Area ab x ka linear function hai (t × Bₓ), to 1/Aₓ ka integral <b>log</b> deta hai, product nahi. Notes ne isse 'equivalent area' = t(B₂ − B₁)/logₑ(B₂/B₁) ke roop mein bhi likha hai — yeh log-mean width × t hai." },
        { k: "trap", t: "Rectangular tapered bar mein log <b>natural log (logₑ = ln)</b> hai, log₁₀ nahi. Calculator par 'log' dabaoge to answer 2.303 guna chhota aayega. Aur B₁ = B₂ rakhne par formula 0/0 ho jaata hai — us case mein seedha prismatic PL/(btE) lagao." },
      ],
    },

    /* ---------------------------------------------------------- M p.63–64 */
    {
      n: "",
      title: "MACE notes — Percentage error when a tapered bar is treated at its average diameter (ESE)",
      hi: "औसत व्यास मानने पर प्रतिशत त्रुटि",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.63–64" },
        { k: "p", t: "<b>ESE — Que 1:</b> A bar of circular cross section varies uniformly from a cross section 2D to D. If extension of the bar is calculated treating it as a bar of average diameter, then the percentage error in extension will be (M p.63)" },
        { k: "list", items: [
          "a) 10 %",
          "b) 16 %",
          "c) 33.33 %",
          "d) 1.11 %",
          "e) <b>11.11 %</b> ✓ (ticked in the notes) (M p.63)",
        ] },
        { k: "p", t: "Memory line (M p.63): <i>“que मध्ये विचारलय की Bar चं elongation find करायचं considering the bar as a bar of constant avg. dia. so that bar is convert into prismatic bar.”</i><br>Gloss: the question asks us to find the bar's elongation treating it as a bar of constant average diameter, so the bar is converted into a prismatic bar." },
        { k: "p", t: "Elongation of the tapering bar is given by ΔL = 4PL/(πD₁D₂E), where D₁ = D and D₂ = 2D, so we can calculate the elongation of the actual bar. (M p.63–64)" },
        { k: "p", t: "Figure (M p.64): a tapered bar with small end D and large end 2D; below it a prismatic bar of diameter D_avg = (3/2)D, labelled “Prismatic”." },
        { k: "eg", title: "MACE notes example — % error in extension using the average diameter (ESE)", given: "A bar of circular cross section varies uniformly from a cross section 2D to D. If extension of bar is calculated treating it as a bar of average diameter, then the percentage error in extension will be: a) 10 %  b) 16 %  c) 33.33 %  d) 1.11 %  e) 11.11 %", steps: [
          { t: "Case I — bar treated at average diameter D_avg = (3/2)D", w: "(ΔL)avg = 4PL / (π (D_avg)² E)\n= 4PL / (π ((3/2)D)² E)\n(ΔL)avg = 16PL / (9πD²E)" },
          { t: "Case II — actual tapered bar, D₁ = D, D₂ = 2D", w: "(ΔL)actual = 4PL / (π D₁ D₂ E) = 4PL / (π (D × 2D) E) = 2PL / (πD²E)" },
          { t: "Proportion (cross-multiplication as drawn in the notes)", w: "(ΔL)actual → difference (error) = (ΔL)avg − (ΔL)actual\n100 → % error" },
          { t: "% error formula", w: "% error = [((ΔL)avg − (ΔL)act) / (ΔL)act] × 100 %" },
          { t: "Substitute (PL and πD²E cancel)", w: "= (16PL/(9πD²E) − 2PL/(πD²E)) / (2PL/(πD²E)) × 100 %\n= ((16/9) − 2)/2 = ((16 − 18)/9)/2 = (−2/9)/2 = −2/18 = −1/9" },
        ], ans: "% error = −11.11 % (the average-diameter method under-estimates the extension by 11.11 %); option (e) 11.11 % (M p.64)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Minus sign ka matlab: average diameter wala 'prismatic' bar <b>kam</b> stretch dikhata hai. Kyun? Patla hissa (D ke paas) apni length ke hisaab se zyada stretch karta hai, kyunki stretch ∝ 1/d² — d chhota hone par 1/d² bahut tezi se badhta hai. Average lene se yeh effect dab jaata hai. Ratio D₁ : D₂ = 1 : 2 hai, to answer D ki value par depend nahi karta — sirf ratio par. Section 2.2 ke Worked example 2.4 (40 mm → 20 mm) mein bhi wahi 1 : 2 ratio hai, isliye wahan bhi ~11% hi aaya." },
        { k: "trap", t: "Error ka base hamesha <b>actual (true) value</b> hota hai: (approx − actual)/actual. Agar galti se (ΔL)avg se divide karoge to −12.5% aayega, jo options mein trap ki tarah baitha ho sakta hai. MCQ mein magnitude 11.11% choose karo." },
      ],
    },

    /* ---------------------------------------------------------- M p.65 */
    {
      n: "",
      title: "MACE notes — Axial deflection of a bar under self weight (prismatic and conical)",
      hi: "स्व-भार के कारण दंड का अक्षीय विक्षेप",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.65" },
        { k: "h", t: "1) Uniform (prismatic) bar hanging from the ceiling — (ΔL)self wt = ?" },
        { k: "p", t: "Figure (M p.65): a prismatic bar hanging from a hatched ceiling, length <b>L</b>; a hatched elemental strip of thickness <b>dx</b> at height <b>x</b> from the free (bottom) end; the strip's area is labelled “AE” in the notes (read: area A); the weight of the portion below the strip ↓<b>Wₓ = γ·A·x</b>." },
        { k: "steps", items: [
          "γ = wt/vol = Wₓ/V (M p.65)",
          "Wₓ = γ·vol ⇒ <b>Wₓ = γ·A·x</b> (M p.65)",
          "ΔL = ∫₀ᴸ (Pₓ)·dx/(AE) = ∫₀ᴸ γ·A·x·dx/(AE) (M p.65)",
          "= ∫₀ᴸ (γ/E)·x·dx = (γ/E)[x²/2]₀ᴸ (M p.65)",
        ] },
        { k: "eq", expr: "★ ΔL = γL² / (2E)   — ①      (M p.65)", where: [
          ["γ", "unit weight of the bar material"],
          ["⇒", "ΔL ∝ L²"],
        ] },
        { k: "p", t: "<b>If all dimensions of the bar are doubled, the elongation becomes four times.</b> ΔL₁ ∝ L₁², ΔL₂ ∝ (2L₁)² ⇒ ΔL₁/ΔL₂ = L₁²/(4L₁²) ⇒ <b>ΔL₂ = 4ΔL₁</b>. (M p.65)" },
        { k: "steps", items: [
          "But γ = W/vol ⇒ γ = W/(A·L), where W = weight of the total bar (M p.65)",
          "① ⇒ ΔL = (W/(AL))·(L²/(2E)) (M p.65)",
        ] },
        { k: "eq", expr: "ΔL = WL / (2AE)   — in terms of total weight of bar W      (M p.65)", where: [
          ["W", "total weight of the bar = γAL"],
        ] },
        { k: "h", t: "2) Conical bar" },
        { k: "p", t: "Figure (M p.65): an inverted cone hanging from the ceiling — top diameter <b>d</b> (D), height <b>L</b>; a hatched strip at height <b>x</b> from the apex (bottom)." },
        { k: "steps", items: [
          "V = (1/3)πr²L ⇒ <b>V = (1/3)((π/4)D²)L</b> (M p.65)",
          "ΔL = (1/3)(prismatic bar) = (1/3)(γL²/(2E)) (M p.65)",
        ] },
        { k: "eq", expr: "★ (MES 19)  ΔL = γL² / (6E)   — ①      (M p.65)", where: [] },
        { k: "steps", items: [
          "But γ = W/vol ⇒ γ = W / ((1/3)((π/4)D²)·L) (M p.65)",
          "① ⇒ ΔL = W / ((1/3)((π/4)D²)·L) × L²/(6E) — the 3 cancels, 6 → 2, one L cancels, and (π/4)D² is marked as A (M p.65)",
        ] },
        { k: "eq", expr: "ΔL = WL / (2AE)   — in terms of total weight W (A = area at the top)      (M p.65)", where: [] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Latakti rod ka har section sirf <b>apne neeche wale hisse</b> ka weight uthata hai — bottom par zero, top par poora W. Force linearly badhta hai, to average force W/2 hai; isliye ΔL = WL/2AE, jo PL/AE ka aadha hai. γ ke terms mein A cancel ho jaata hai: ΔL = γL²/2E — matlab mota ya patla, same material aur same length ki rod utni hi khichegi." },
        { k: "p", t: "Notes cone ke liye shortcut lete hain: 'cone ka volume prismatic ka ⅓ hai, to ΔL bhi ⅓'. Answer γL²/6E sahi hai — section 2.2 isko first principles se nikalta hai (cone mein section x par stress γx/3 hota hai, prismatic mein γx). Interesting baat: W ke terms mein dono ka formula same WL/2AE hai, bas cone ka W aur A (top area) alag hain." },
        { k: "trap", t: "'All dimensions doubled → ΔL four times' sirf <b>self-weight</b> case ke liye hai (ΔL ∝ L², A cancel). External load P wale case mein ΔL = PL/AE: L doubled aur A four times → ΔL <b>aadha</b> ho jaata hai. Dono ko mix mat karo." },
        { k: "real", t: "Deep mine shafts ke hoisting cables, lambe suspension hangers aur tall towers ke vertical members mein self-weight ka elongation dhyaan mein rakhna padta hai; chhote members mein yeh negligible hota hai." },
      ],
    },

    /* ---------------------------------------------------------- M p.66 (part) */
    {
      n: "",
      title: "MACE notes — Bar of uniform strength",
      hi: "समान सामर्थ्य का दंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.66" },
        { k: "p", t: "Uniform stress can be maintained by <b>increasing area from lower level to higher level</b>, as shown below. (M p.66)" },
        { k: "p", t: "Figure (M p.66): a bar hanging from the ceiling with area <b>A₁</b> at the top (support); its sides curve (flare) inward going down to area <b>A₂</b> at the bottom. A section x–x is marked; the weight of the portion below the section ↓<b>Wₓ</b> produces stress <b>σ_W</b>; an external load ↓<b>P</b> (“P = ext. load”) acts at the bottom, producing <b>σ_P</b>." },
        { k: "eq", expr: "★ For a bar of uniform strength:  A₁ = A₂ · e^(γL/σ)      (M p.66)", where: [
          ["A₁", "area at the top (support)"],
          ["A₂", "area at the bottom (load end)"],
          ["γ", "unit weight of the material"],
          ["L", "length of the bar"],
          ["σ", "the uniform (constant) stress"],
        ] },
        { k: "note", t: "The notes first write A₁ = A₂·e^(λL/σ) and strike it out, then box the corrected form A₁ = A₂·e^(γL/σ). (M p.66)" },
        { k: "p", t: "<b>When will the bar be of uniform strength?</b> For a bar to have constant strength the following condition should be satisfied (M p.66):" },
        { k: "p", t: "★ Stress on section x–x due to external load + stress on section x–x due to weight of bar below the x–x section = <b>constant</b> (M p.66)" },
        { k: "eq", expr: "★ σ_P (external) + σ_W (self) = constant      (M p.66)", where: [
          ["σ_P", "stress at x–x due to the external load P"],
          ["σ_W", "stress at x–x due to the self weight of the part below x–x"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Prismatic latakti rod mein top par stress sabse zyada hota hai (P + poora self-weight), bottom par sabse kam. Material bachane ke liye area ko is tarah badhao ki <b>har section par stress same σ</b> rahe — yahi bar of uniform strength hai. Top par area sabse bada, bottom par sabse chhota (A₂ = P/σ)." },
        { k: "p", t: "<b>General Engineering Knowledge (derivation):</b> section x par area A, aur thoda upar (x + dx) par A + dA. Extra area dA ko extra self-weight γA·dx uthana hai at the same stress σ: σ·dA = γA·dx ⇒ dA/A = (γ/σ)dx. Integrate karo bottom (A₂) se top (A₁) tak: ln(A₁/A₂) = γL/σ ⇒ A₁ = A₂·e^(γL/σ). Isliye exponential aata hai — area apne hi size ke proportion mein badhta hai." },
        { k: "trap", t: "Exponent γL/σ hai (unit weight × length ÷ stress) — dimensionless hona chahiye. Units consistent rakho: γ N/mm³ mein, L mm mein, σ N/mm² mein. γ ko kN/m³ aur L ko m mein lekar σ N/mm² se divide karoge to exponent galat aayega." },
        { k: "real", t: "Tall masonry/concrete piers, chimneys aur bridge piers ka neeche se upar ki taraf (support ki taraf) mota hona isi uniform-strength idea ka practical roop hai — jahan self-weight bada ho." },
      ],
    },

    /* ---------------------------------------------------------- M p.66–68 */
    {
      n: "",
      title: "MACE notes — Strain energy due to axial load: prismatic and tapered bars",
      hi: "अक्षीय भार से विकृति ऊर्जा — प्रिज़्मीय व टेपर्ड दंड",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.66–68" },
        { k: "p", t: "<b>Strain energy due to axial load</b> [lecture V-13]. This can be done for two types of bar. (M p.66)" },
        { k: "h", t: "I) Prismatic bar (M p.66)" },
        { k: "p", t: "For a prismatic bar, A = constant and P = constant or P ≠ constant. ∴ <b>U = P²L/(2AE)</b>. Suppose P = constant and A = constant: (M p.66)" },
        { k: "cmp", t: "Strain energy of prismatic bars, P and A constant (M p.66)", cols: ["Section (figure)", "U"], rows: [
          ["① Circular bar", "cylinder of diameter D", "U = P²L / (2((π/4)D²)·E) ⇒ <b>U = 2P²L / (πD²E)</b>"],
          ["② Square bar", "square of side a × a", "<b>U = P²L / (2a²E)</b>"],
          ["③ Rectangular bar", "width b, depth d", "<b>U = P²L / (2bdE)</b>"],
        ] },
        { k: "h", t: "II) Non-prismatic bar (M p.67)" },
        { k: "p", t: "In case of a non-prismatic bar, strain energy is given as U = ∫ P²dx/(2Aₓ·E). Here, for P = constant, Aₓ ≠ constant (non-prismatic). (M p.67)" },
        { k: "h", t: "1) Circular tapered bar (M p.67)" },
        { k: "p", t: "Figure (M p.67): a circular tapered bar (frustum) — small end D₁ with load P ←, large end D₂ with load → P; an elemental disc of diameter Dₓ at distance x, width dx, with P ← and → P on it; total length L; K = (D₂ − D₁)/L." },
        { k: "steps", items: [
          "ΔL = 4PL/(πD₁D₂E) (M p.67)",
          "ΔL = ∫ P·dx/(AₓE) ⇒ ΔL = (P/E) ∫ (1/Aₓ) dx (M p.67)",
          "U = ∫ P²dx/(2AₓE) = (P/2)[(P/E) ∫ (1/Aₓ) dx] (M p.67)",
        ] },
        { k: "eq", expr: "★ U = (P/2) × ΔL   — i.e. area under the P–Δ curve up to the elastic limit (for an axially loaded bar)      (M p.67)", where: [] },
        { k: "steps", items: [
          "ΔL = 4PL/(πD₁D₂E) ..... elongation for circular tapered bar (M p.67)",
          "U = (P/2) × 4PL/(πD₁D₂E) (M p.67)",
        ] },
        { k: "eq", expr: "★★ U = 2P²L / (π D₁ D₂ E)   — circular tapered bar      (M p.67)", where: [] },
        { k: "h", t: "2) Square tapered bar (M p.67)" },
        { k: "p", t: "Figure (M p.67): a square tapered bar — small end B₁ × B₁, large end B₂ × B₂, hatched strip at distance x, length L." },
        { k: "steps", items: [
          "ΔL = PL/(B₁B₂E) ... elongation (the notes label it “for circular tapered bar”; it is the square tapered bar of M p.63) (M p.67)",
          "But U = (P/2) × ΔL = (P/2) × PL/(B₁B₂E) (M p.67)",
        ] },
        { k: "eq", expr: "★ U = P²L / (2 B₁ B₂ E)   — square tapered bar      (M p.67)", where: [] },
        { k: "h", t: "3) Rectangular tapered bar (M p.67–68)" },
        { k: "p", t: "Figure (M p.67): a rectangular tapered plate, thickness t = constant, width B₁ at the small end and B₂ at the large end. K = (B₂ − B₁)/L." },
        { k: "steps", items: [
          "ΔL = P·L·log(B₂/B₁) / (t(B₂ − B₁)E) ... elongation for rectangular tapered bar (M p.67)",
          "OR ΔL = P·log(B₂/B₁) / (K·t·E) (M p.67)",
          "But U = (P/2) × ΔL = (P/2) × P·log(B₂/B₁)/(K·t·E) (M p.68)",
        ] },
        { k: "eq", expr: "★ U = P² logₑ(B₂/B₁) / (2K·t·E)   OR   ★ U = P² L logₑ(B₂/B₁) / (2t(B₂ − B₁)E)      (M p.68)", where: [
          ["K", "(B₂ − B₁)/L = rate of tapering"],
          ["t", "constant thickness"],
        ] },
        { k: "h", t: "Que 1 (M p.68)" },
        { k: "p", t: "Figure (M p.68): a prismatic bar hanging from the ceiling, length L, load ↓P at the bottom end. A second sketch: a tapered bar hanging from the ceiling, top diameter D₂, bottom diameter D₁, load ↓P at the bottom." },
        { k: "eg", title: "MACE notes example — strain energy of a hanging bar, self weight neglected", given: "A bar is held from a ceiling as shown below. What will be the strain energy for this bar neglecting the self weight of bar if D = dia of bar which is constant throughout and P is the load applied at the end of the bar.", steps: [
          { t: "Bar is prismatic (D constant), P constant", w: "U = P²L / (2AE)" },
          { t: "Notes' remark beside the second sketch", w: "---- same formula for circular tapered bar (tapered bar hanging from ceiling, top D₂, bottom D₁, load P at bottom)" },
        ], ans: "U = P²L/(2AE) (bar is prismatic) (M p.68)" },
        { k: "note", t: "<b>Reading the remark:</b> for the hanging tapered bar the same approach U = (P/2) × ΔL is used, which gives the tapered result already boxed on M p.67, U = 2P²L/(πD₁D₂E); with D₁ = D₂ = D it reduces to 2P²L/(πD²E) = P²L/(2AE). (M p.67–68)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Strain energy = load ka kiya hua kaam. Load dheere-dheere 0 se P tak badhta hai (gradually applied), to P–Δ graph ek triangle hai — area = ½ × P × ΔL. Isliye har bar ke liye shortcut: pehle ΔL ka formula likho, phir P/2 se multiply karo. Prismatic, circular tapered, square tapered, rectangular tapered — sab isi ek line se nikle hain. (Resilience aur U = σ²V/2E wala view Ch. 6 mein hai.)" },
        { k: "p", t: "Dhyaan do: U = P²L/2AE tabhi exact hai jab P poori length par constant ho. Notes ka 'P = constant or P ≠ constant' likhna general idea hai; agar P badal raha hai (jaise self-weight), to integral ∫Pₓ²dx/2AE lagana padega — agla section yahi karta hai." },
        { k: "trap", t: "U = (P/2)·ΔL sirf <b>gradually applied</b> load ke liye hai. Suddenly applied load mein kaam P·ΔL hota hai aur stress double ho jaata hai — dono ko mix mat karo. Aur rectangular taper mein yahan bhi log = ln (natural log)." },
      ],
    },

    /* ---------------------------------------------------------- M p.68–69 */
    {
      n: "",
      title: "MACE notes — Strain energy due to self weight (prismatic and conical bars)",
      hi: "स्व-भार के कारण विकृति ऊर्जा",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.68–69" },
        { k: "h", t: "I) Prismatic bar of diameter D (M p.68)" },
        { k: "list", items: [
          "A = constant (M p.68)",
          "P ≠ constant (∵ it is self weight) (M p.68)",
          "γ = W/V (M p.68)",
          "Pₓ ⇒ varying; <b>Pₓ = Wₓ = γ·A·x</b> (M p.68)",
        ] },
        { k: "p", t: "Figure (M p.68): a prismatic bar hanging from the ceiling, length L; a hatched strip of thickness dx at height x from the bottom; ↓Wₓ below the strip. Beside it a triangular load diagram: Wₓ = γAL at the top, Wₓ = γ·A·x at an intermediate dashed level, Wₓ = 0 at the bottom." },
        { k: "steps", items: [
          "∫₀ᵁ dU = ∫₀ᴸ Pₓ²·dx/(2AE) = ∫₀ᴸ (γ·A·x)²dx/(2AE) = ∫₀ᴸ γ²·A²·x²·dx/(2AE) (one A cancelled) (M p.68)",
          "= (γ²A/(2E)) ∫₀ᴸ x²dx = (γ²A/(2E)) [x³/3]₀ᴸ (M p.68)",
        ] },
        { k: "eq", expr: "★ U = γ² A L³ / (6E)   — in terms of unit weight      (M p.68)", where: [
          ["⇒", "U is a function of the area of the bar"],
          ["⇒", "U ∝ γ², U ∝ A, U ∝ L³, U ∝ 1/E"],
        ] },
        { k: "steps", items: [
          "But γ = total wt/vol = W/(A·L) (M p.68)",
          "U = ((W/(AL))²·A·L³)/(6E) = ((W²/(A²L²))·A·L³)/(6E) (M p.68)",
        ] },
        { k: "eq", expr: "U = W² L / (6AE)   — in terms of total weight W of bar      (M p.68)", where: [] },
        { k: "cmp", t: "Self-weight strain energy of prismatic bars (M p.69)", cols: ["U"], rows: [
          ["i) Circular (diameter D)", "U = πγ²D²L³ / (24E)"],
          ["ii) Square (side a)", "U = γ²a²L³ / (6E)"],
          ["iii) Rectangular (b × d)", "U = γ²bdL³ / (6E)"],
        ] },
        { k: "note", t: "<b>NOTE (M p.69):</b> γ = ρ·g. g_earth &gt; g_moon ⇒ γ_earth &gt; γ_moon ⇒ U_earth &gt; U_moon. ∴ U_earth / U_moon &gt; 1." },
        { k: "h", t: "II) Non-prismatic bar — conical bar (M p.69)" },
        { k: "p", t: "Figure (M p.69): an inverted cone hanging from the ceiling — top diameter D, A = (π/4)D² at the top, height L; a hatched strip of thickness dx at height x from the apex (bottom); ↓Pₓ on the portion below." },
        { k: "eq", expr: "Conical bar:  U = ∫₀ᴸ Pₓ² dx / (2AₓE)      (M p.69)", where: [] },
        { k: "steps", items: [
          "To find Pₓ and Aₓ: Pₓ = γ·vol ⇒ <b>Pₓ = γ × (Aₓ·x)/3</b> (∴ volume of cone = (πr²)h/3) (M p.69)",
          "By interpolation: D/L = Dₓ/x ⇒ <b>Dₓ = D·(x/L)</b> (M p.69)",
          "Aₓ = (π/4)Dₓ² ⇒ <b>Aₓ = (π/4)(D²x²/L²)</b> (M p.69)",
          "U = (1/(2E)) ∫₀ᴸ (Pₓ²/Aₓ)·dx = (1/(2E)) ∫₀ᴸ ((γ·Aₓ·x)/3)²·dx / Aₓ (M p.69)",
          "= (1/(2E)) ∫₀ᴸ γ²Aₓ²x²/(9Aₓ)·dx (Aₓ cancelled) = (γ²/(18E)) ∫₀ᴸ [(π/4)D²·(x²/L²)]·x²·dx (M p.69)",
          "= (γ²/(18E))((π/4)D²)·(1/L²)[x⁵/5]₀ᴸ = (γ²A/(18EL²)) × (L⁵/5) (M p.69)",
        ] },
        { k: "eq", expr: "★ U = γ² A L³ / (90E)   — conical bar, self weight (A = area at the top)      (M p.69)", where: [] },
        { k: "p", t: "<b>IMP NOTE (M p.69):</b> We have already seen the axial deflection due to self weight as well as the strain energy due to self weight, which is given as under:" },
        { k: "cmp", t: "Self weight — deflection and strain energy (M p.65, 68–69)", cols: ["ΔL (self weight)", "U (self weight)"], rows: [
          ["Prismatic bar", "γL²/(2E) = WL/(2AE)", "γ²AL³/(6E) = W²L/(6AE)"],
          ["Conical bar", "γL²/(6E) = WL/(2AE)", "γ²AL³/(90E)"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Self-weight mein force Pₓ = γAx section-to-section badalta hai, isliye U = P²L/2AE seedha nahi laga sakte. Energy ∝ Pₓ², aur Pₓ ∝ x, to integrand ∝ x² — integrate karne par L³/3 aata hai, upar ke ½ ke saath 1/6. Cone mein Pₓ aur Aₓ dono x² ke saath badhte hain, to integrand ∝ x⁴ → L⁵/5 aur factor 1/90 ban jaata hai." },
        { k: "p", t: "Deflection mein A cancel ho gaya tha (γL²/2E), lekin energy mein A bacha rehta hai (γ²AL³/6E) — kyunki mota bar zyada material = zyada weight = zyada stored energy. Earth vs moon: γ = ρg, aur U ∝ γ², to earth par U zyada; ratio = (g_earth/g_moon)²." },
        { k: "trap", t: "Cone ke liye <b>volume ⅓</b> wala shortcut energy mein nahi chalta: deflection mein prismatic ka ⅓ (γL²/6E) aaya tha, lekin energy prismatic ka ⅓ nahi balki 1/15 hai (6E → 90E). Har case ke liye formula alag yaad karo — ya integral karke nikalo." },
      ],
    },

    /* ---------------------------------------------------------- M p.70 */
    {
      n: "",
      title: "MACE notes — Combined strain energy: self weight plus end load",
      hi: "स्व-भार और बाहरी भार की संयुक्त विकृति ऊर्जा",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.70" },
        { k: "p", t: "<b>Que 1:</b> Find out the strain energy stored in a prismatic bar of circular cross section due to load applied at the free end and self weight, i.e. find the total strain energy stored due to the combined effect of self weight and external applied load P. (M p.70)" },
        { k: "p", t: "Figure (M p.70): a prismatic bar hanging from the ceiling; a hatched strip of thickness dx at height x from the bottom; ↓Wₓ below the strip; ↓P at the bottom end. A separate sketch of the strip shows the downward load <b>Pₓ = P + Wₓ = P + γ·A·x</b>." },
        { k: "eg", title: "MACE notes example — total strain energy, self weight + end load P", given: "Find out the strain energy stored in a prismatic bar of circular cross section due to load applied at the free end and self wt. i.e. find out total strain energy stored due to the combined effect of self wt and external applied load P.", steps: [
          { t: "i) S.E. due to external load", w: "U = P²L / (2AE)" },
          { t: "ii) S.E. due to self weight", w: "U = γ²AL³ / (6E)" },
          { t: "iii) Total S.E. (combined); A = constant (prismatic), Pₓ ≠ constant (self weight considered)", w: "U = ∫₀ᴸ Pₓ² dx / (2A·E) = ∫₀ᴸ (P + γAx)² dx / (2AE)" },
          { t: "Expand the square", w: "= ∫₀ᴸ (P² + 2P·γ·A·x + γ²A²x²) dx / (2AE)\n= (1/(2AE)) [∫₀ᴸ P² dx + ∫₀ᴸ 2P·γ·A·x dx + ∫₀ᴸ γ²A²x² dx]" },
          { t: "Integrate", w: "= (1/(2AE)) [P²[x]₀ᴸ + 2PγA[x²/2]₀ᴸ + γ²A²[x³/3]₀ᴸ]\n= (1/(2AE)) [P²L + 2PγAL²/2 + γ²A²L³/3]" },
          { t: "Separate the terms (A cancelled in the middle term)", w: "= P²L/(2AE) + P·γ·A·L²/(2AE) + γ²A²L³/(6AE)" },
        ], ans: "U = P²L/(2AE) + P·γ·L²/(2E) + γ²AL³/(6E); the middle term P·γ·L²/(2E) is the additional S.E. due to the combined effect (M p.70)" },
        { k: "note", t: "<b>NOTE (M p.70):</b> Since S.E. ∝ Pₓ² ---- no linearity ⇒ the principle of superposition is <b>not valid</b> for S.E. calculation (U₁ + U₂ ≠ U). But ΔL ∝ P ---- linearity ⇒ the principle of superposition <b>is valid</b>, i.e. (ΔL)₁ + (ΔL)₂ = (ΔL)total." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "(a + b)² = a² + b² + 2ab — bas yahi poori kahani hai. P akela → P²L/2AE, self-weight akela → γ²AL³/6E, aur dono saath hon to ek extra 'cross term' PγL²/2E aata hai. Yeh cross term = P × (self-weight se hua elongation γL²/2E) — matlab end load P, self-weight ki wajah se neeche khiske hue point par bhi kaam karta hai." },
        { k: "p", t: "Deflection ke liye seedha jod sakte ho: ΔL = PL/AE + γL²/2E. Energy ke liye nahi — wahan cross term chhoot jaayega." },
        { k: "trap", t: "Combined loading mein U_total = U_P + U_self likh dena sabse common galti hai. Energy load ka square hai, to hamesha pehle total force Pₓ = P + γAx banao, phir square karke integrate karo." },
      ],
    },

    /* ---------------------------------------------------------- M p.71–72 */
    {
      n: "",
      title: "MACE notes — Principle of superposition: deflection vs strain energy, and stepped-bar questions",
      hi: "अध्यारोपण का सिद्धांत",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.71–72" },
        { k: "p", t: "<b>Principle of superposition</b> [lecture V-14] (M p.71)" },
        { k: "p", t: "<b>Assumptions</b> (M p.71):" },
        { k: "list", items: [
          "1) Member is linear elastic, i.e. Hooke's law is valid (based upon linearity) (M p.71)",
          "2) Member is subjected to very small deformation only (M p.71)",
        ] },
        { k: "def", term: "Principle of superposition (★)", t: "Overall effect on the body = <b>algebraic sum of all individual effects</b>. (M p.71)" },
        { k: "p", t: "<b>Que 1 (M p.71):</b> A bar of circular cross section of diameter D was subjected to a load P₁ due to which elongation of bar observed to be ΔL₁. If the bar was now subjected to load P₂ due to which elongation of bar observed to be ΔL₂. If nature of both loads was same, then which of the following is correct if the bar is now subjected to total load of (P₁ + P₂) and total deflection is ΔL? a) ΔL &lt; ΔL₁ + ΔL₂ · b) ΔL₁ &gt; ΔL + ΔL₂ · c) ΔL &gt; ΔL₁ + ΔL₂ · <b>d) ΔL = ΔL₁ + ΔL₂ ✓</b>" },
        { k: "p", t: "Figure (M p.71): three identical bars of diameter D, length L, hanging from the ceiling — the first with ↓P₁, the second with ↓P₂, the third with ↓P = (P₁ + P₂)." },
        { k: "eg", title: "MACE notes example — superposition of elongations", given: "A bar of circular cross section of diameter D was subjected to a load P₁ due to which elongation of bar observed to be ΔL₁. If the bar was now subjected to load P₂ due to which elongation of bar observed to be ΔL₂. If nature of both load was same then which of the following is correct if the bar is now subjected to total load of (P₁+P₂) and total deflection is ΔL: a) ΔL < ΔL₁ + ΔL₂  b) ΔL₁ > ΔL + ΔL₂  c) ΔL > ΔL₁ + ΔL₂  d) ΔL = ΔL₁ + ΔL₂", steps: [
          { t: "Each load alone", w: "ΔL₁ = P₁L/(AE)    ΔL₂ = P₂L/(AE)" },
          { t: "Both loads together", w: "ΔL = (P₁ + P₂)L/(AE) = P₁L/(AE) + P₂L/(AE)" },
          { t: "Result", w: "ΔL = ΔL₁ + ΔL₂" },
          { t: "Conclusion", w: "ΔL ∝ P .... linear [so principle of superposition is valid]" },
        ], ans: "(d) ΔL = ΔL₁ + ΔL₂ (M p.71)" },
        { k: "p", t: "<b>GATE — Que 2 (★) (M p.71):</b> A circular bar of length L and diameter D was made of material having modulus of elasticity E. This bar was subjected to load P₁ and the strain energy stored due to load P₁ was U₁. If the same bar is subjected to load P₂, the strain energy stored in the bar is U₂. Now both the loads are applied at a time and the strain energy stored in the bar is U. Pick up the correct expression between U₁, U₂ and U: a) U₁ + U₂ = U · b) 2U₁ + U₂ = U · <b>c) U₁ + U₂ &lt; U ✓</b> · d) U₁ + U₂ &gt; U" },
        { k: "p", t: "Figure (M p.72): three identical bars of diameter D hanging from the ceiling — the first with ↓P₁, the second with ↓P₂, the third with ↓P = (P₁ + P₂)." },
        { k: "eg", title: "MACE notes example — strain energy does not superpose (GATE)", given: "A circular bar of length L and dia. D was made of material having modulus of elasticity E. This bar was subjected to load P₁ and the strain energy stored due to load P₁ was U₁. If the same bar is subjected to load P₂ and the strain energy stored in the bar is U₂. Now both the loads applied at a time the strain energy stored in the bar is U. Pick up the correct expression between U₁, U₂ and U: a) U₁ + U₂ = U  b) 2U₁ + U₂ = U  c) U₁ + U₂ < U  d) U₁ + U₂ > U", steps: [
          { t: "Each load alone", w: "U₁ = P₁²L/(2AE)    U₂ = P₂²L/(2AE)" },
          { t: "Both loads together", w: "U = (P₁ + P₂)²L/(2AE) = (P₁² + 2P₁P₂ + P₂²)L/(2AE)\n= P₁²L/(2AE) + P₂²L/(2AE) + P₁P₂L/(AE)" },
          { t: "Compare", w: "U = U₁ + U₂ + P₁P₂L/(AE)\n∴ U > U₁ + U₂" },
          { t: "Conclusion", w: "U₁ + U₂ ≠ U, ∵ U ∝ P² .... NOT linear [so principle of superposition is not valid]" },
        ], ans: "(c) U₁ + U₂ < U, i.e. U > U₁ + U₂ (M p.72)" },
        { k: "p", t: "<b>Que 3 (M p.72):</b> Find out the stress developed in the bar at section x–x as shown below due to the external applied load P." },
        { k: "p", t: "Figure (M p.72): a stepped bar hanging from the ceiling — upper portion of diameter <b>2d</b> and length <b>L</b>, with section <b>x–x</b> within it; lower portion of diameter <b>d</b> and length <b>L</b>. A load ↓P is applied at the step (junction) and a load ↓P at the bottom free end. Free-body sketches: the upper piece cut at x–x with 2P ↑ at the top and the unknown x ↓ at the cut, worked as “+P + x = −P ⇒ x = −2P”; the lower piece with ↑P at the top and ↓P at the bottom." },
        { k: "eg", title: "MACE notes example — stress at section x–x of a stepped hanging bar", given: "Find out the stress developed in the bar at section x-x as shown below due to the external applied load P. (Upper part diameter 2d, length L, containing x-x; lower part diameter d, length L; load P at the step and load P at the free end.)", steps: [
          { t: "Internal force at x–x from the free body (as written in the notes)", w: "+P + x = −P\nx = −2P   (magnitude 2P at section x-x)" },
          { t: "Stress = load/area", w: "σ(x-x) = P(x-x) / A(x-x)\n= 2P / ((π/4)(2d)²)" },
        ], ans: "σ = 2P/(πd²) (M p.72)" },
        { k: "p", t: "<b>Que 4 (M p.72):</b> Find out the total S.E. stored in the tapered (stepped) bar as shown below." },
        { k: "p", t: "Figure (M p.72): a stepped bar fixed to a wall on the left, with three segments from left to right — depth <b>d₁</b>, modulus <b>E₁</b>, length <b>L₁</b>; depth <b>d₂</b>, modulus <b>E₂</b>, length <b>L₂</b>; depth <b>d₃</b>, modulus <b>E₃</b>, length <b>L₃</b>. The worked answer continues on M p.73." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Superposition ka simple test: kya effect load ke saath <b>seedhi line</b> mein badhta hai? Stress (P/A) aur deflection (PL/AE) — haan, to inhe alag-alag loads ke liye nikaal ke jod sakte ho. Strain energy (P²L/2AE) — nahi, yeh parabola hai; do loads saath hon to cross term P₁P₂L/AE extra aata hai, isliye U hamesha U₁ + U₂ se bada (jab dono loads same nature ke hon)." },
        { k: "p", t: "Que 3 aur Que 4 jaise stepped bars mein trick ek hi hai: har segment ka <b>internal force</b> free-body se nikalo. Que 3 mein section x–x ke neeche dono P lage hain, to wahan force 2P hai, aur area bade diameter 2d ka hai. Que 4 mein (M p.73 par hal kiya gaya) har segment ki energy P²Lᵢ/(2AᵢEᵢ) alag nikaal ke jodi jaati hai — yeh segment energies ka jod hai, alag-alag loads ki energies ka nahi." },
        { k: "trap", t: "Que 3 mein log galti se chhote diameter d ka area le lete hain ya sirf ek P lete hain — dono galat. Section x–x <b>upper (2d) part</b> mein hai aur uske neeche ka poora load (P + P = 2P) wahi section uthata hai: σ = 2P/(π(2d)²/4) = 2P/(πd²)." },
        { k: "real", t: "Design codes mein load combinations (dead + live + wind) ke stresses aur deflections jodne ka adhikaar isi superposition principle se milta hai — linear elastic range aur small deformations ki shart par." },
      ],
    },

    /* ---------------------------------------------------------- Revision */
    {
      n: "",
      title: "MACE notes revision — Axial deflection, self weight, uniform strength, strain energy and superposition (M p.62–72)",
      hi: "पुनरावृत्ति — अक्षीय विक्षेप व विकृति ऊर्जा",
      blocks: [
        { k: "h", t: "✅ Key formulas and points — M p.62–72" },
        { k: "list", items: [
          "✅ Non-prismatic bar: ΔL = ∫₀ᴸ Pₓ·dx/(Aₓ·E) (M p.62)",
          "✅ Circular tapered: ΔL = 4PL/(πD₁D₂E); Dₓ = D₁ + kx, k = (D₂ − D₁)/L = rate of tapering (M p.62)",
          "✅ Square tapered: ΔL = PL/(B₁B₂E), k = (B₂ − B₁)/L (M p.63)",
          "✅ Rectangular tapered (t constant): ΔL = PL·logₑ(B₂/B₁)/(tE(B₂ − B₁)) = P·logₑ(B₂/B₁)/(KtE) (M p.63, 67)",
          "✅ Prismatic: circular 4PL/(πd²E); square PL/(a²E); rectangular PL/(bdE) (M p.63)",
          "✅ Tapered bar D → 2D treated at average diameter: % error = −11.11 % (under-estimate) (ESE) (M p.63–64)",
          "✅ Self weight, prismatic: ΔL = γL²/(2E) = WL/(2AE); ΔL ∝ L²; all dimensions doubled ⇒ ΔL four times (M p.65)",
          "✅ Self weight, conical: ΔL = γL²/(6E) = WL/(2AE) (MES 19) (M p.65)",
          "✅ Bar of uniform strength: A₁ = A₂·e^(γL/σ); σ_P (external) + σ_W (self) = constant (M p.66)",
          "✅ Prismatic SE: U = P²L/(2AE); circular 2P²L/(πD²E); square P²L/(2a²E); rectangular P²L/(2bdE) (M p.66)",
          "✅ Non-prismatic SE: U = ∫P²dx/(2AₓE) = (P/2)·ΔL = area under the P–Δ curve up to the elastic limit (M p.67)",
          "✅ Circular tapered SE: U = 2P²L/(πD₁D₂E); square tapered SE: U = P²L/(2B₁B₂E) (M p.67)",
          "✅ Rectangular tapered SE: U = P²logₑ(B₂/B₁)/(2KtE) = P²L·logₑ(B₂/B₁)/(2t(B₂ − B₁)E) (M p.68)",
          "✅ Self-weight SE, prismatic: U = γ²AL³/(6E) = W²L/(6AE); U ∝ γ², A, L³, 1/E (M p.68)",
          "✅ Self-weight SE: circular πγ²D²L³/(24E); square γ²a²L³/(6E); rectangular γ²bdL³/(6E) (M p.69)",
          "✅ γ = ρg ⇒ U_earth &gt; U_moon (M p.69)",
          "✅ Self-weight SE, conical: U = γ²AL³/(90E) (M p.69)",
          "✅ Combined (end load P + self weight): U = P²L/(2AE) + PγL²/(2E) + γ²AL³/(6E); middle term = additional SE due to combined effect (M p.70)",
          "✅ Superposition: valid for ΔL (∝ P, linear); not valid for SE (∝ P²) (M p.70–72)",
          "✅ Superposition assumptions: linear elastic (Hooke's law valid) and very small deformations; overall effect = algebraic sum of individual effects (M p.71)",
          "✅ ΔL(P₁ + P₂) = ΔL₁ + ΔL₂ (M p.71); U(P₁ + P₂) = U₁ + U₂ + P₁P₂L/(AE) &gt; U₁ + U₂ (GATE) (M p.72)",
          "✅ Stepped hanging bar (2d over d, P at step and P at end): σ at x–x in upper part = 2P/(πd²) (M p.72)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
