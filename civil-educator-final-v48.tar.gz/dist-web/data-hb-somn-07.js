/* MACE Academy SOM notes — Principal stresses: stress transformation, principal planes, analytical method cases i–v, M p.144–156 — inserted into som chapter 2 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 2; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------- stress transformation, principal planes */
    {
      n: "",
      title: "MACE notes — Stress transformation, principal planes and principal stresses",
      hi: "प्रतिबल रूपांतरण, मुख्य तल और मुख्य प्रतिबल",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.144–145" },
        { k: "p", t: "<b>Chapter: Principal stresses &amp; Mohr's circle.</b> Based upon the eccentricity of load with respect to the axis of the body, the stresses developed in the body are of 2 types: <b>(1) direct stresses</b> and <b>(2) bending stresses</b>. (M p.144)" },
        { k: "list", items: [
          "Bending stresses tend to resist bending of the body. (M p.144)",
          "Direct stresses on planes inside the body are transformed into two types of stresses: <b>(i) normal stress</b> on any inclined plane within the body, and <b>(ii) tangential stress (shear stress)</b> on the same plane within the body. (M p.144)",
        ] },
        { k: "list", items: [
          "<b>Figure (M p.144) — stress transformation:</b> a rectangular block fixed to a wall on the left (hatched), with axial stress σx acting to the right. A vertical plane AB (red dotted; B at top, A at bottom) and an inclined plane AC (dashed, from A at the bottom to C at the top, near the wall) making angle θ with AB.",
          "Enlarged element on plane AC: angle θ between plane AC and the vertical; σn drawn perpendicular to AC; τ drawn along (parallel to) AC, with opposing shear arrows on the other faces; label 'Plane AC'.",
          "Small sketches: 'Principal Plane' — vertical line B–A with only an arrow σn (normal stress = principal stress). 'Normal Plane' — line C–A with an arrow τ along the plane and an arrow σn normal to it.",
        ] },
        { k: "def", term: "σx", t: "Stress acting on plane AB. (M p.144)" },
        { k: "def", term: "σn", t: "Normal stress on plane AC. (M p.144)" },
        { k: "def", term: "τ", t: "Shear stress on plane AC (parallel to the plane). (M p.144)" },
        { k: "cmp", t: "Plane AB vs plane AC (M p.144)", cols: ["What acts on it", "Condition"], rows: [
          ["Plane AB — <b>principal plane</b>", "Only normal stress; no shear on AB", "<b>τ = 0 and σn ≠ 0</b> ★"],
          ["Plane AC — <b>normal plane</b> (term used in the notes)", "Both normal stress and shear stress", "<b>τ ≠ 0 and σn ≠ 0</b> ★"],
        ] },
        { k: "p", t: "In the figure, plane AB is acted upon by pure normal force only, i.e. there is no shear stress or shear parameter acting on plane AB. However, plane AC is acted upon by a normal force as well as by a shear force. (M p.144)" },
        { k: "def", term: "Principal plane and principal stress", t: "In such a case plane AB is called the <b>principal plane</b>; the stress acting upon a principal plane is called the <b>principal stress</b>, i.e. the only governing stress. (M p.145)" },
        { k: "def", term: "Normal stresses and normal plane (notes' terminology)", t: "All other stresses on planes accompanied by a shear stress are called normal stresses, and the plane on which normal stress acts along with shear stress is called a <b>normal plane</b>. (M p.145)" },
        { k: "h", t: "2D element — principal planes AB and BC (M p.145)" },
        { k: "p", t: "Figure (M p.145): a 2D square element C (top-left), B (top-right), A (bottom-right), D (bottom-left); σy up on the top face (and down on the bottom face) labelled 'σy = principal'; σx to the right on the right face (and to the left on the left face) labelled 'σx = principal'. No shear arrows." },
        { k: "list", items: [
          "On planes AB and BC, the shear stress is zero, i.e. only normal stress is present. (M p.145)",
          "Thus plane AB and plane BC both are principal planes. (M p.145)",
          "Thus σx and σy are principal stresses. (M p.145)",
        ] },
        { k: "cmp", t: "2D — naming the principal stresses (M p.145)", cols: ["If σx &gt; σy", "If σx &lt; σy"], rows: [
          ["Major principal stress σ₁", "σx = σ₁", "σy = σ₁"],
          ["Minor principal stress σ₂", "σy = σ₂", "σx = σ₂"],
        ] },
        { k: "cmp", t: "3D — naming the principal stresses (M p.145)", cols: ["σ₁ (major) P.S", "σ₂ (intermediate) P.S · σ₃ (minor) P.S"], rows: [
          ["If σx &gt; σy &gt; σz", "σx", "σy · σz"],
          ["If σz &gt; σy &gt; σx", "σz", "σy · σx"],
          ["If σy &gt; σx &gt; σz", "σy", "σx · σz"],
        ] },
        { k: "p", t: "Figure (M p.145): a 3D cube element with σy pointing up from the top face, σx pointing right from the right face and σz pointing out of the front face." },
        { k: "note", t: "<b>Memory line (Marathi, M p.145):</b> ∵ [जो मोठा तो major &amp; जो लहान तो minor &amp; Remaining is intermediate] — <i>whichever is biggest is major, whichever is smallest is minor, and the remaining one is intermediate</i>." },
        { k: "list", items: [
          "<b>Stress transformation analysis can be done by</b> (M p.145):",
          "1) Analytical method (Equilibrium method)",
          "2) Graphical method (Mohr's circle method)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek hi point par stress 'kaisa dikhta hai' yeh is par depend karta hai ki tum kis plane se dekh rahe ho. Bar ko seedha (AB) kaato to sirf σx dikhta hai, koi shear nahi; tircha (AC) kaato to wahi σx do hisson mein toot jaata hai — σn aur τ. Isi ko <b>stress transformation</b> kehte hain. Jis plane par shear zero ho, wahi <b>principal plane</b> hai, aur us par ka normal stress hi principal stress — yeh woh 'asli' stress hai jo material ko sabse zyada kheenchta ya dabata hai." },
        { k: "p", t: "Order se naam do: sabse bada σ₁ (major), sabse chhota σ₃ (2D mein σ₂) minor, beech wala intermediate — chahe woh x, y ya z kisi bhi direction mein ho. Sign ke saath compare karo: tension +ve, compression −ve." },
        { k: "trap", t: "MACE notes 'normal plane' ka matlab koi bhi aisa plane lete hain jis par σn aur τ dono hon. <i>General Engineering Knowledge:</i> most textbooks call such a plane an <b>oblique (inclined) plane</b>. MCQ mein 'normal plane' padh kar confuse mat hona — principal plane woh hai jahan τ = 0. Aur σx ko 'major' tabhi bolo jab woh sign ke saath sabse bada ho, sirf x-direction hone se nahi." },
      ],
    },

    /* ---------------------------------------------- case i uniaxial */
    {
      n: "",
      title: "MACE notes — Analytical method, case (i): uniaxial stress on an inclined plane",
      hi: "विश्लेषणात्मक विधि — एक-अक्षीय प्रतिबल",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.146–148" },
        { k: "p", t: "<b>1) Analytical method (Equilibrium method).</b> <b>Case (i):</b> member subjected to axial stress in one plane only, i.e. a <b>uniaxial stress system</b>. (M p.146)" },
        { k: "list", items: [
          "<b>Figure (M p.146):</b> square element with corners C (top-left, on the top edge), B (top-right), A (bottom-right); a red dashed inclined plane passes through C and A; angle θ at A between the inclined plane and the vertical face AB; σx acts on the right face.",
          "Below it: the triangular wedge cut by the inclined plane, with σn normal to the plane, τ along the plane (downward), σx horizontal, angle θ marked. 3D sketches show the bar thickness t on face AB and on the inclined face CA.",
          "Force-resolution sketch: horizontal force <b>fx = σx × area of plane AB = σx (AB·t)</b>; its component normal to the plane <b>fn = fx cosθ</b>; its component along the plane <b>S = fx sinθ</b>; the plane is at θ from the vertical.",
          "Right triangle C–B–A, right angle at B (BC horizontal, AB vertical, AC hypotenuse, θ at A): <b>sinθ = BC/AC, cosθ = AB/AC</b>.",
        ] },
        { k: "list", items: [
          "fx = force in x-direction corresponding to σx (M p.146)",
          "fn = force perpendicular to the inclined section corresponding to σn (M p.146)",
          "S = shear force corresponding to τ (M p.146)",
        ] },
        { k: "steps", items: [
          "<b>Normal stress on plane of θ:</b> σn = Normal force / perpendicular area = fn/(AC·t) = fx cosθ/(AC·t) = σx·AB·t·cosθ/(AC·t) (M p.146)",
          "Since AB/AC = cosθ: <b>σn = σx cos²θ</b> ——① (M p.146)",
          "<b>Shear stress on plane of θ:</b> τ = shear force / parallel area = S/(AC·t) = fx sinθ/(AC·t) = (σx·AB·t)·sinθ/(AC·t) (M p.146)",
          "τ = σx sinθ cosθ, and since sin2θ = 2 sinθ cosθ: <b>τ = (σx/2) sin2θ</b> ——② (M p.146)",
        ] },
        { k: "eq", expr: "σn = σx cos²θ  ——①      τ = (σx/2)·sin2θ  ——②", where: [
          ["θ", "angle of the inclined plane AC with the vertical plane AB (= angle of its normal with the x-axis)"],
          ["σx", "external applied axial stress"],
        ] },
        { k: "p", t: "<b>Resultant stress on plane AC (M p.146):</b> σR = √(σn² + τ² + 2σn·τ·cosθ), where the angle between σn and τ is 90°, so the last term → 0 (struck through in the notes). Figure: σn up-right, τ down-right, σR between them, angle between σn and τ marked 90°." },
        { k: "eq", expr: "σR = √(σn² + τ²)", where: [["σR", "resultant stress on the inclined plane"]] },
        { k: "h", t: "Maximum shear and maximum normal stress (M p.147)" },
        { k: "steps", items: [
          "★ <b>Condition of maximum shear:</b> τ → τmax when sin2θ = 1, i.e. 2θ = 90° ∴ θ = 45° OR θ = 135°. Thus maximum shear occurs at θ = 45° or θ = 135°. (M p.147)",
          "<b>τmax = σx/2 @ 45°</b>, where τmax = maximum shear and σx = external applied stress. (M p.147)",
          "Normal stress on the plane of maximum shear: σn = σx cos²45°, with cos²45° = (1/√2)² = 1/2 ∴ <b>σn = σx/2</b>. (M p.147)",
          "∴ <b>(σn)45° = (τ)45° = σx/2</b>. (M p.147)",
          "★ <b>Condition of maximum normal stress:</b> σn → σmax when cos²θ = 1, i.e. <b>θ = 0°, θ = 180°</b>. (σn)max = σx cos²(0) ∴ <b>(σn)max = σx</b>. (M p.147)",
          "σx ⇒ maximum stress ⇒ <b>major principal stress</b>. (M p.147)",
        ] },
        { k: "p", t: "Figure (M p.147): a rectangular bar pulled by σx at both ends, the right end labelled 'σx = principal stress ⇓ maximum major principal stress'; a red dashed inclined plane cuts the bar with σn (blue) at θ to the horizontal; at the right end face a crossed-out arrow labelled 'shear stress = 0'." },
        { k: "eg", title: "MACE notes example — Que 1: normal stress on the plane of maximum shear (uniaxial)", given: "What will be the magnitude of normal stress on the plane of maximum shear on the system as shown below (bar fixed at the left end, axial pull of 20 MPa at the right end)? a) 5 MPa  b) 10 MPa  c) 15 MPa  d) 20 MPa", steps: [
          { t: "Normal stress formula", w: "σn = σx cos²θ" },
          { t: "Plane of maximum shear is at θ = 45°", w: "σn = σx × (1/√2)²\n= 20 × 1/2" },
          { t: "Result", w: "σn = 10 MPa" },
        ], ans: "σn = 10 MPa — option (b). (M p.147)" },
        { k: "eg", title: "MACE notes example — Que 2: normal stress on the plane of maximum shear (concept)", given: "On the plane of maximum shear, the normal stress is ______ (for uniaxial loading condition). a) Half of shear stress  b) Half of external applied normal stress  c) Double of external applied normal stress  d) Same as that of the maximum shear stress", steps: [
          { t: "From the uniaxial results", w: "(σn)45° = σx/2 and τmax = σx/2\nSo σn on the max-shear plane = half of the applied σx = τmax" },
        ], ans: "Both (b) and (d) are ticked in the notes: σn = σx/2 = τmax. (M p.148)" },
        { k: "eg", title: "MACE notes example — Que 3: shear stress on a section of a circular bar", given: "A circular bar of diameter D is subjected to axial tensile load T. What will be the shear stress on a section at an angle θ with the line of action of applied load T? a) 4T/(πD²)  b) (4T/πD²) sin2θ  c) (2T/πD²) sin2θ  d) (2T/πD²) cos²θ", steps: [
          { t: "Shear stress formula (uniaxial)", w: "τ = (σx/2) sin2θ" },
          { t: "σx = T/A", w: "= (1/2)(T/A) sin2θ\n= (1/2)(T/((π/4)D²)) sin2θ   (4 and 2 cancel → 2)" },
          { t: "Result", w: "τ = (2T/πD²) sin2θ" },
        ], ans: "τ = (2T/πD²)·sin2θ — option (c). (M p.148)" },
        { k: "eg", title: "MACE notes example — Que 4: major principal stress in a loaded cube", given: "A cube as shown below (all edges 100 mm) is subjected to a normal load of 10 kN. Find out the major principal stress. a) 1 MPa  b) 10 MPa  c) 0.1 MPa  d) 100 MPa", steps: [
          { t: "On any inclined plane", w: "σn < σx and τ < σx" },
          { t: "Stress on the loaded face", w: "σx = load/area = (10 × 10³ N)/(100 × 100) = 1 MPa" },
          { t: "Reasoning", w: "Shear stress is absent on the loaded face, so the normal stress there is the major principal stress.\nFigure: bar with σx = 1 MPa; a vertical section has τ = 0, σn = σx; the end face is the principal plane, τ = 0, σn = σx = 1 MPa = major P.S." },
        ], ans: "Major principal stress = 1 MPa — option (a). (M p.148)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Ek hi force fx do hisson mein toot-ta hai: plane ke perpendicular fx cosθ aur plane ke along fx sinθ. Lekin area bhi badal jaata hai — inclined plane AC ka area AB se bada hai (AC = AB/cosθ). Isliye σn mein cosθ <b>do baar</b> aata hai (cos²θ): ek baar force ke component se, ek baar bade area se. Yahi wajah hai ki σn = σx cos²θ, na ki σx cosθ." },
        { k: "p", t: "Uniaxial case mein 45° plane special hai: wahan τ maximum (σx/2) hai aur σn bhi σx/2 — dono barabar. Ductile steel isi 45° shear se yield karta hai (Lüders lines), jaisa §2.5 ki table mein bataya gaya hai. Que 3 mein angle 'load ki line se' diya hai, jabki formula mein θ plane ke normal se hai — par sin2θ = sin2(90° − θ), isliye answer same aata hai." },
        { k: "trap", t: "Students σn = σx cosθ likh dete hain (area ka change bhool kar). Do cos aate hain — ek force resolve karne se, ek area badhne se. Doosri galti: τmax ka plane 45° par hai, par us plane par σn zero <b>nahi</b> hota — woh bhi σx/2 hai (Que 2)." },
        { k: "real", t: "Tension test mein mild steel specimen par 45° par slip lines dikhti hain aur cup-and-cone fracture ki cone surface lagbhag 45° par hoti hai — kyunki wahan τ = σx/2 maximum hai aur ductile material shear mein fail hota hai." },
      ],
    },

    /* ---------------------------------------------- case ii derivation */
    {
      n: "",
      title: "MACE notes — Case (ii): general biaxial + shear — deriving σn, σn′ and τ′xy",
      hi: "सामान्य द्वि-अक्षीय प्रतिबल और अपरूपण — सूत्रों की व्युत्पत्ति",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.149–150" },
        { k: "p", t: "<b>Case (ii):</b> consider the general case of loading (<b>biaxial + shear</b>) as shown below. (M p.149)" },
        { k: "list", items: [
          "<b>Figure (M p.149):</b> square element C (top-left, with C′ just left of it), B (top-right), A (bottom-right), D (bottom-left). σy up (top) and down (bottom); σx left (left face) and right (right face). Shear: arrow on the top face pointing right (Sx); arrow on the right face pointing up, labelled τxy (Sy); arrow on the left face pointing down; arrow on the bottom face pointing left. Red dashed inclined plane C–A; angle θ at A between the plane and the vertical face AB.",
          "3D block of thickness t with corners C, B, A on the front face, diagonal C–A, σy up and σx outward.",
          "Rotated element aligned with the inclined plane: σn normal to the inclined face, σn′ normal to the perpendicular face, τ′xy shear arrows along the faces in pairs.",
          "Force-resolution diagram: fy = σy[BC·t] and Sy = τxy[AB·t] along y; Sx = τxy[BC·t] and fx = σx[AB·t] along x. Normal direction (at θ) collects fx cosθ, Sx cosθ, fy sinθ, Sy sinθ. Along the plane, up-left: fy cosθ, Sy cosθ; down-right: Sx sinθ, fx sinθ.",
          "Net fn = fx cosθ + Sx cosθ + fy sinθ + Sy sinθ;  net shear = (fy cosθ + Sy cosθ) − (fx sinθ + Sx sinθ).",
        ] },
        { k: "p", t: "<b>To find:</b> ① σn  ② σn′  ③ τ′xy. (M p.149)" },
        { k: "cmp", t: "Forces and the faces they act on (M p.149)", cols: ["Force", "Area it acts on"], rows: [
          ["σx", "fx (→)", "[AB] — perpendicular"],
          ["σy", "fy (↑)", "[BC] — perpendicular"],
          ["τxy", "Sx (→)", "[BC] — parallel"],
          ["τxy", "Sy (↑)", "[AB] — parallel"],
        ] },
        { k: "p", t: "AB/AC = cosθ;  BC/AC = sinθ;  t = thickness. (M p.149)" },
        { k: "steps", items: [
          "σn = fn/(AC·t) = fx cosθ/(AC·t) + Sx cosθ/(AC·t) + fy sinθ/(AC·t) + Sy sinθ/(AC·t) (M p.149)",
          "σn = σx·AB·t·cosθ/(AC·t) + τxy·BC·t·cosθ/(AC·t) + σy·BC·t·sinθ/(AC·t) + τxy·AB·t·sinθ/(AC·t)  (t cancels) (M p.149)",
          "<b>σn = σx cos²θ + σy sin²θ + τxy sin2θ</b> (M p.149)",
          "Use the identity (as written in the notes): a sin²θ + b cos²θ = (a/2)(1 + cos2θ) + (b/2)(1 − cos2θ) = a/2 + (a/2)cos2θ + b/2 − (b/2)cos2θ = <b>(a + b)/2 + ((a − b)/2) cos2θ</b> (M p.149)",
          "∴ <b>σn = (σx + σy)/2 + ((σx − σy)/2) cos2θ + τxy sin2θ</b> ——① (M p.149)",
          "∴ <b>σn′ = (σx + σy)/2 − ((σx − σy)/2) cos2θ − τxy sin2θ</b> ——② (the last sign is written as an overwritten ∓ in the notes; for the perpendicular plane it is −) (M p.149)",
        ] },
        { k: "note", t: "<b>Check:</b> the identity is written with sin² and cos² swapped. Since cos²θ = (1 + cos2θ)/2 and sin²θ = (1 − cos2θ)/2, the correct form is <b>a cos²θ + b sin²θ = (a/2)(1 + cos2θ) + (b/2)(1 − cos2θ) = (a + b)/2 + ((a − b)/2) cos2θ</b>. With a = σx (the cos² term) and b = σy (the sin² term) this gives exactly equation ① — so the final result in the notes is correct; only the left side of the identity is mislabelled." },
        { k: "eq", expr: "σn OR σn′ = (σx + σy)/2 ± ((σx − σy)/2)·cos2θ ± τxy·sin2θ", where: [
          ["upper signs", "σn, on the plane at θ"],
          ["lower signs", "σn′, on the perpendicular plane (θ + 90°)"],
        ] },
        { k: "h", t: "Shear stress on the plane θ (M p.150)" },
        { k: "steps", items: [
          "τ′xy = S/(AC·t) = fy cosθ/(AC·t) + Sy cosθ/(AC·t) − fx sinθ/(AC·t) − Sx sinθ/(AC·t) (M p.150)",
          "τ′xy = σy(BC/AC)cosθ + τxy(AB/AC)cosθ − σx(AB/AC)sinθ − τxy(BC/AC)sinθ (M p.150)",
          "τ′xy = σy sinθ cosθ + τxy cos²θ − σx sinθ cosθ − τxy sin²θ = −((σx − σy)/2)·2 sinθ cosθ + τxy(cos²θ − sin²θ) (M p.150)",
          "★ <b>τ′xy = −((σx − σy)/2) sin2θ + τxy cos2θ</b> ——③ (M p.150)",
        ] },
        { k: "eq", expr: "τ′xy = −((σx − σy)/2)·sin2θ + τxy·cos2θ  ——③", where: [
          ["θ", "angle of the inclined plane with the vertical face AB (angle of its normal with the x-axis)"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the older 17-page notes (p.6, §2.5 of this chapter) write τ = +((σx − σy)/2) sin2θ + τxy cos2θ, and §2.5 already corrects it to τ = −((σx − σy)/2) sin2θ + τxy cos2θ. The MACE notes derive the <b>minus</b> form directly from force equilibrium (M p.150, re-worked above: σy sinθcosθ − σx sinθcosθ = −((σx − σy)/2) sin2θ). So the MACE equation ③ is right and agrees with the corrected §2.5. Quick test: putting tan2θp = 2τxy/(σx − σy) into ③ gives τ′xy = 0, as it must on a principal plane; the all-plus version does not." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Derivation ka tareeka simple hai: har stress ko force banao (stress × jis face par laga hai uska area), phir har force ko inclined plane ke <b>perpendicular</b> aur <b>along</b> resolve karo, aur jodo. Fir AC·t se divide karo. AB/AC = cosθ aur BC/AC = sinθ use karte hi saare area cancel ho jaate hain aur sirf θ bachta hai. Perpendicular plane (θ + 90°) ke liye cos2θ aur sin2θ ka sign ulta ho jaata hai — isliye σn′ mein dono ± neeche wale (−) sign lagte hain." },
        { k: "trap", t: "Force banate waqt <b>area galat face ka</b> lena sabse common galti hai: σx face AB par lagta hai (fx = σx·AB·t), lekin τxy ka ek pair face BC par (Sx = τxy·BC·t) aur doosra face AB par (Sy = τxy·AB·t). Aur τ′xy mein pehle term ka sign <b>minus</b> hai — dono terms plus likhoge to principal plane par shear zero nahi aayega." },
      ],
    },

    /* ---------------------------------------------- case ii principal planes and stresses */
    {
      n: "",
      title: "MACE notes — Case (ii): principal planes, principal stresses and the invariant σx + σy",
      hi: "मुख्य तल, मुख्य प्रतिबल और अपरिवर्ती योग",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.150–152" },
        { k: "p", t: "We know that the plane of angle θ is just a normal plane. So, to find the angle θp ⇒ plane of principal stress (i.e. we will find the principal plane). Let θp = inclination of principal plane. Thus, if θ = θp, <b>τ′xy = 0</b> ← shear zero on principal plane. (M p.150)" },
        { k: "steps", items: [
          "③ ⇒ 0 = −((σx − σy)/2) sin2θp + τxy cos2θp (M p.150)",
          "((σx − σy)/2) sin2θp = τxy cos2θp — used to find the plane θp of zero shear (M p.150)",
          "<b>tan2θp = 2τxy/(σx − σy)</b> ——④ inclination of principal plane (M p.150)",
        ] },
        { k: "eq", expr: "tan2θp = 2τxy/(σx − σy)  ——④", where: [["θp", "inclination of the principal plane (plane of zero shear)"]] },
        { k: "h", t: "To find the principal stresses (M p.150–151)" },
        { k: "p", t: "Figure (M p.150): a right-angled triangle with opposite side 2τxy, adjacent side (σx − σy), hypotenuse √((σx − σy)² + 4τxy²), and angle 2θp between the adjacent side and the hypotenuse. Hence tan2θp = opp/adj, cos2θp = (σx − σy)/√((σx − σy)² + 4τxy²), sin2θp = 2τxy/√((σx − σy)² + 4τxy²)." },
        { k: "steps", items: [
          "Put cos2θp and sin2θp in equation ①: σp = (σx + σy)/2 + ((σx − σy)/2)·(σx − σy)/√((σx − σy)² + 4τxy²) + τxy·2τxy/√((σx − σy)² + 4τxy²) (M p.150)",
          "= (σx + σy)/2 + (σx − σy)²/(2√((σx − σy)² + 4τxy²)) + 4τxy²/(2√((σx − σy)² + 4τxy²)) (M p.150)",
          "= (σx + σy)/2 + [(σx − σy)² + 4τxy²]/(2√((σx − σy)² + 4τxy²)) (M p.150)",
          "Multiply top and bottom by √((σx − σy)² + 4τxy²): = (σx + σy)/2 + [(σx − σy)² + 4τxy²]·√((σx − σy)² + 4τxy²)/(2[(σx − σy)² + 4τxy²]) — the bracket cancels top and bottom (M p.150–151)",
          "σp = (σx + σy)/2 + √(((σx − σy)/2)² + τxy²) (M p.151)",
          "σp′ = (σx + σy)/2 ± √(((σx − σy)/2)² + τxy²) — (+) gives the major, (−) the minor principal stress; σp = σ₁ and σp′ = σ₂ (M p.151)",
        ] },
        { k: "note", t: "In the notes the 'σx − σy' inside the squares on M p.150–151 is written as a minus sign overwritten into ∓. Inside a square the sign makes no difference to the value of (σx − σy)², and the derivation (from cos2θp = (σx − σy)/…) gives a minus, so read it as (σx − σy)." },
        { k: "eq", expr: "σ₁ OR σ₂ = (σx + σy)/2 ± √[((σx − σy)/2)² + τxy²]  ——⑤", where: [
          ["σ₁ (+)", "major principal stress"],
          ["σ₂ (−)", "minor principal stress"],
        ] },
        { k: "eg", title: "MACE notes example — Que 1: normal stresses on a 45° plane", given: "An element loaded as shown below (σx = 10 MPa, σy = 10 MPa, shear 3 MPa on the faces) is to be analysed on a plane inclined at angle θ = 45°. Find out the magnitude of one of the normal stresses on the inclined plane.", steps: [
          { t: "Formula", w: "σn OR σn′ = (σx + σy)/2 ± ((σx − σy)/2) cos2θ ± τxy sin2θ" },
          { t: "Substitute (σx − σy = 0, 2θ = 90°)", w: "σn = 20/2 + 0 + 3 sin90°\n= 10 + 3" },
          { t: "Result", w: "σn = 13 MPa and σn′ = 7 MPa" },
        ], ans: "σn = 13 MPa (and σn′ = 7 MPa on the perpendicular plane). (M p.151)" },
        { k: "eg", title: "MACE notes example — Que 2: magnitude of maximum shear stress", given: "For the element as shown below (σx, σy and τxy on the faces), find out the magnitude of maximum shear stress.", steps: [
          { t: "Shear on plane θ", w: "τ′xy ⇒ τmax = ?\nτ′xy = −((σx − σy)/2) sin2θ + τxy cos2θ" },
          { t: "Two candidate planes taken in the notes", w: "θ = 45° (sin2θ = 1): τ′xy = −(σx − σy)/2\nOR θ = 0° (cos2θ = 1): τ′xy = τxy" },
          { t: "Notes' rule", w: "Select the maximum of the two." },
        ], ans: "τmax = larger of |(σx − σy)/2| and τxy, as written in the notes. (M p.151)" },
        { k: "note", t: "<b>Check:</b> taking the larger of the values at θ = 0° and θ = 45° does <b>not</b> give the maximum shear when σx ≠ σy and τxy ≠ 0. Setting dτ′xy/dθ = 0 in ③ gives tan2θs = −(σx − σy)/(2τxy), and there <b>τmax = √(((σx − σy)/2)² + τxy²) = (σ₁ − σ₂)/2</b>, which is larger than both candidates. Example: σx = 80, σy = −40, τxy = 30 (Worked example 2.9): the notes' rule gives max(60, 30) = 60 N/mm², the true τmax is √(60² + 30²) = 67.08 N/mm². The notes' rule is exact only when one of the two terms is zero (σx = σy, or τxy = 0)." },
        { k: "h", t: "Invariant — sum of normal stresses on two perpendicular planes (M p.151–152)" },
        { k: "note", t: "<b>NOTE (M p.151):</b> summation of all tensor quantities on two mutually perpendicular planes is always constant, i.e. <b>σx + σy = σn + σn′ = σ₁ + σ₂</b>." },
        { k: "steps", items: [
          "(i) σx + σy (M p.151)",
          "(ii) σn + σn′ = [(σx + σy)/2 + ((σx − σy)/2)cos2θ + τxy sin2θ] + [(σx + σy)/2 − ((σx − σy)/2)cos2θ − τxy sin2θ] — the cos2θ and sin2θ terms cancel = 2((σx + σy)/2) = σx + σy … same as (i) (M p.151)",
          "(iii) σ₁ + σ₂ = (σx + σy)/2 + √(((σx − σy)/2)² + τxy²) + (σx + σy)/2 − √(((σx − σy)/2)² + τxy²) — the root terms cancel = σx + σy … same as (i). Hence proved. (M p.152)",
        ] },
        { k: "note", t: "<b>Check:</b> on M p.152 a small '²' is written after the first bracket in (iii), i.e. ((σx + σy)/2)². It should be (σx + σy)/2 with no square — the two (σx + σy)/2 terms add to σx + σy only without the square." },
        { k: "eq", expr: "σx + σy = σn + σn′ = σ₁ + σ₂", where: [["use", "checks answers, and finds a missing stress when the other three are known"]] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Principal plane ki pehchaan: <b>shear zero</b>. Isliye ③ ko zero rakho, tan2θp mil jaata hai; phir us angle ka cos aur sin triangle se nikaal kar ① mein daalo — σ₁, σ₂ ka formula ban jaata hai. Formula ko 'centre ± radius' ki tarah yaad rakho: (σx + σy)/2 average hai, aur √(((σx − σy)/2)² + τxy²) us average se kitna door ja sakte ho. Yahi radius Mohr's circle (agla section) mein circle ka radius banta hai." },
        { k: "p", t: "Invariant σx + σy = σn + σn′ = σ₁ + σ₂ ek free calculator-check hai: kisi bhi do perpendicular planes ke normal stresses ka jod hamesha same rehta hai. MCQ mein jab θ diya hi na ho (Que 3 neeche), tab yahi rule answer deta hai." },
        { k: "trap", t: "Maximum shear ke liye sirf θ = 0° aur 45° try karke bada wala mat chun lo (Que 2 ka rule) — general case mein asli τmax = √(((σx − σy)/2)² + τxy²) hota hai, jo dono se bada hai. Aur principal stress formula mein τxy ka square andar hai, bahar nahi: σ = avg ± √(… + τxy²)." },
      ],
    },

    /* ---------------------------------------------- case ii numericals */
    {
      n: "",
      title: "MACE notes — Case (ii) numericals: using σx + σy = σ₁ + σ₂, and σx = σy = σ",
      hi: "संख्यात्मक प्रश्न — अपरिवर्ती योग और σx = σy",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.152–153" },
        { k: "eg", title: "MACE notes example — Que 3: normal stresses on a plane at an unknown angle θ", given: "An element is subjected to biaxial stress loading as shown below. If σx = 11.3 MPa and σy = 9.2 MPa, which of the following are the correct values of normal stresses on a plane inclined at an angle θ inside the element? a) 10.0 and 1.0  b) 11.0 and 9.0  c) 20.0 and 0.55  d) 10.3 and 10.2", steps: [
          { t: "Use the invariant", w: "σx + σy = σn + σn′ = σ₁ + σ₂" },
          { t: "Sum", w: "σx = 11.3 MPa, σy = 9.2 MPa ⇒ σx + σy = 20.5 MPa" },
          { t: "θ is not known", w: "If θ is unknown then we can't find it through the formula.\nSo check from the options which pair gives the sum 20.5" },
          { t: "Check option (d)", w: "10.3 + 10.2 = 20.5 MPa" },
        ], ans: "Option (d): 10.3 and 10.2 MPa. (M p.152)" },
        { k: "note", t: "The σx value is overwritten in the question on M p.152; the working uses σx = 11.3 MPa, and that value is kept here. Re-worked sums: (a) 11.0, (b) 20.0, (c) 20.55, (d) 20.5 — only (d) matches." },
        { k: "eg", title: "MACE notes example — Que 4: finding σ₂ from σx, σy and σ₁", given: "σx = 10 MPa, σy = 12 MPa, τxy = 3 MPa, σ₁ = 17 MPa, σ₂ = ?", steps: [
          { t: "Invariant", w: "σx + σy = σ₁ + σ₂" },
          { t: "Substitute", w: "10 + 12 = 17 + σ₂\nσ₂ = 22 − 17" },
        ], ans: "σ₂ = 5 MPa. (M p.152)" },
        { k: "note", t: "<b>Check:</b> the method and the arithmetic (22 − 17 = 5) are right, but the given data are not consistent with each other. With σx = 10, σy = 12, τxy = 3 MPa, formula ⑤ gives σ₁,₂ = 11 ± √(1² + 3²) = 11 ± 3.16, i.e. <b>σ₁ = 14.16 MPa and σ₂ = 7.84 MPa</b> (sum 22 ✔), not σ₁ = 17. The answer 5 MPa follows only from the stated σ₁ = 17 MPa; in an exam that gives σ₁, use the invariant exactly as the notes do." },
        { k: "eg", title: "MACE notes example — Que 5: principal stresses when σx = σy = σ", given: "Biaxial stress loading with shear was applied on a cube of side 100 mm each as shown below. If σx = σy = σ, then find out the magnitude of major and minor principal stresses.", steps: [
          { t: "Formula", w: "σ₁ OR σ₂ = (σx + σy)/2 ± √(((σx − σy)/2)² + τxy²)" },
          { t: "Substitute σx = σy = σ", w: "σ₁ = (σ + σ)/2 + √(((σ − σ)/2)² + τxy²)\n(σ − σ)/2 → 0, so √(τxy²) = τxy\n= 2σ/2 + τxy" },
          { t: "Result", w: "σ₁ = σ + τxy\nσ₂ = σ − τxy" },
        ], ans: "σ₁ OR σ₂ = σ ± τxy — conclusion boxed in the notes. (M p.152)" },
        { k: "eg", title: "MACE notes example — Que 6: principal stresses for σx = σy = 10 MPa, τ = 1 MPa", given: "A biaxial stress system is as shown below (10 MPa on the top face and 10 MPa on the right face, shear 1 MPa along the faces). Find out the magnitude of major and minor principal stresses.", steps: [
          { t: "Use σ ± τ (Que 5)", w: "σ₁ = σ + τ = 10 + 1 = 11 MPa (major)\nσ₂ = σ − τ = 10 − 1 = 9 MPa (minor)" },
        ], ans: "σ₁ = 11 MPa (major), σ₂ = 9 MPa (minor). (M p.153)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Jab σx = σy ho, to element ke andar 'average' hi sab kuch hai aur (σx − σy)/2 zero ho jaata hai — principal stresses bas average ke dono taraf τxy jitna hatt jaate hain: σ ± τ. Principal planes tab exactly 45° par hote hain (tan2θp = 2τ/0 → ∞). Que 1 ka 13/7 MPa bhi yahi hai: 10 ± 3." },
        { k: "trap", t: "Invariant-wale MCQ mein (Que 3) sirf sum check karna kaafi hai jab options mein ek hi pair sahi sum deta ho; par dono values σ₂ aur σ₁ ke beech honi chahiye — biaxial-without-shear mein koi bhi σn, 9.2 se 11.3 MPa ke bahar nahi ja sakta. Que 4 mein given σ₁ khud check karo — data inconsistent bhi ho sakta hai." },
      ],
    },

    /* ---------------------------------------------- case iii biaxial without shear */
    {
      n: "",
      title: "MACE notes — Case (iii): biaxial stress with no shear — τmax, resultant stress and angle of obliquity",
      hi: "बिना अपरूपण के द्वि-अक्षीय प्रतिबल — अधिकतम अपरूपण और तिर्यकता कोण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.153–154" },
        { k: "p", t: "<b>Case (iii): Biaxial stress system with no shear.</b> For the general state of stress there are σx, σy and τxy; here <b>τxy = 0</b>, ∴ the external planes are principal planes. Planes AB and BC both do not have shear ∴ AB and BC are principal planes ∴ σx and σy both are principal stresses. Let σx &gt; σy; so σx = σ₁ = major principal stress, σy = σ₂ = minor principal stress. (M p.153)" },
        { k: "p", t: "Figure (M p.153): square element C (top-left), B (top-right), A (bottom-right), D (bottom-left); σy = σ₂ up at the top and down at the bottom; σx = σ₁ right on the right face and left on the left face; red inclined plane through C and A with angle θ at A. Beside it, the rotated element on the inclined plane with σn (normal to the plane), σn′ (normal to the perpendicular face) and τ′xy (along the plane)." },
        { k: "steps", items: [
          "We know σn = σx cos²θ + σy sin²θ + τxy sin2θ → for the general system with τxy ≠ 0. (M p.153)",
          "But here τxy = 0 ∴ <b>σn = σ₁ cos²θ + σ₂ sin²θ</b>. (M p.153)",
          "Similarly, substituting τxy = 0, σx = σ₁ and σy = σ₂ we get the following relationships. (M p.153)",
        ] },
        { k: "eq", expr: "σn OR σn′ = (σ₁ + σ₂)/2 ± ((σ₁ − σ₂)/2)·cos2θ      τ′xy = −((σ₁ − σ₂)/2)·sin2θ", where: [] },
        { k: "steps", items: [
          "Notes also write: τ′xy = τmax·sin2θ, i.e. τmax = τ′xy/sin2θ. (M p.153)",
          "For τmax, sin2θ = 1, 2θ = 90°, θ = 45°. (M p.153)",
          "Maximum shear: <b>τmax = −((σ₁ − σ₂)/2) … @ 45° OR @ 135°</b> [minus sign generally not taken, or we can use mod]. ∴ when σ₁ = σ₂ then <b>τmax = 0</b>. (M p.153)",
          "Normal stresses on the plane of maximum shear: σn OR σn′ = (σ₁ + σ₂)/2 ± ((σ₁ − σ₂)/2) cos90°, and cos90° = 0 ∴ <b>σn OR σn′ = (σ₁ + σ₂)/2</b> … ★ equal and alike normal stresses on the plane of maximum shear. (M p.153)",
        ] },
        { k: "note", t: "<b>Check:</b> (1) In the notes 'unlike' is written above 'alike' as a correction. 'Alike' is right: both planes of maximum shear carry the same normal stress (σ₁ + σ₂)/2, of the same sign — σn and σn′ above have the same value at 2θ = 90°. (2) 'τ′xy = τmax·sin2θ' is the magnitude form; with signs, τ′xy = −((σ₁ − σ₂)/2) sin2θ = −τmax·sin2θ, taking τmax = (σ₁ − σ₂)/2 as positive." },
        { k: "h", t: "Resultant stress on the plane of maximum shear (M p.154)" },
        { k: "steps", items: [
          "σR = √(σn² + τmax²) (M p.154)",
          "σR = √(((σ₁ + σ₂)/2)² + ((σ₁ − σ₂)/2)²) (M p.154)",
          "= √((σ₁² + 2σ₁σ₂ + σ₂² + σ₁² − 2σ₁σ₂ + σ₂²)/4) — the 2σ₁σ₂ terms cancel (M p.154)",
          "<b>σR = √((σ₁² + σ₂²)/2)</b> → resultant stress on the plane of maximum shear (M p.154)",
        ] },
        { k: "p", t: "Figure (M p.154): an inclined plane with τmax along the plane, σn normal to the plane and σR (red) between them; angle β between σR and σn." },
        { k: "def", term: "Angle of obliquity (β)", t: "Angle between σR and σn, i.e. the angle made by the resultant stress with the normal stress: <b>tanβ = τ/σn</b>. (M p.154)" },
        { k: "steps", items: [
          "★ Angle of obliquity on the plane of maximum shear, i.e. @ 45°: tanβ = τmax/σn = ((σ₁ − σ₂)/2)/((σ₁ + σ₂)/2) — the 2's cancel (M p.154)",
          "<b>tanβ = (σ₁ − σ₂)/(σ₁ + σ₂)</b> … angle of obliquity corresponding to the maximum shear stress (M p.154)",
        ] },
        { k: "eq", expr: "σR = √((σ₁² + σ₂²)/2)      tanβ = τ/σn      tanβ (at τmax) = (σ₁ − σ₂)/(σ₁ + σ₂)", where: [
          ["σR", "resultant stress on the plane of maximum shear"],
          ["β", "angle of obliquity — between σR and σn"],
        ] },
        { k: "list", items: [
          "<b>NOTE (M p.154):</b>",
          "τmax = (σ₁ − σ₂)/2 … maximum shear stress is half the difference of the major and minor principal stresses.",
          "σn = (σ₁ + σ₂)/2 … normal stress corresponding to maximum shear is half the sum of the principal stresses.",
          "τ′xy = τmax·sin2θ.",
        ] },
        { k: "p", t: "★ <b>Principal stresses (M p.154):</b> because the given loading condition has no shear on the external planes, the external planes themselves are principal planes. Thus σx and σy are principal stresses — the higher of σx and σy is the major principal stress and the lesser is the minor principal stress, i.e. if σx &gt; σy: σx → σ₁ (major), σy → σ₂ (minor). So we need not find the principal stresses." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Jab bahar ke faces par shear nahi hai, to woh faces already principal planes hain — kuch calculate karne ki zaroorat nahi, bada wala σ₁, chhota σ₂. Max shear 45° par milta hai aur uska size principal stresses ke <b>difference ka aadha</b> hai; us plane par normal stress unke <b>sum ka aadha</b>. Isliye agar σ₁ = σ₂ (jaise hydrostatic / equal biaxial), to kisi bhi plane par shear zero — har plane principal plane ban jaata hai." },
        { k: "p", t: "Angle of obliquity β batata hai ki resultant stress plane ke normal se kitna 'tircha' hai. tanβ = τ/σn — yahi idea soil mechanics mein friction angle se compare hota hai (tanφ = τ/σ)." },
        { k: "trap", t: "τmax = (σ₁ − σ₂)/2 mein sign ke saath subtract karo: σ₁ = 60 (T), σ₂ = −40 (C) ho to τmax = (60 − (−40))/2 = 50, na ki 10. Aur max-shear plane par normal stress zero samajhna galat hai — woh (σ₁ + σ₂)/2 hai." },
        { k: "real", t: "Thin cylinder (boiler, pipe) ki wall mein hoop aur longitudinal stress dono principal stresses hain aur unke beech shear nahi hota — yeh case (iii) ka seedha example hai; in-plane τmax = (σ_hoop − σ_long)/2." },
      ],
    },

    /* ---------------------------------------------- case iv pure shear */
    {
      n: "",
      title: "MACE notes — Case (iv): pure shear",
      hi: "शुद्ध अपरूपण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.155–156" },
        { k: "p", t: "<b>Case (iv): Pure shear.</b> Consider the following figure which shows the pure shear condition. (M p.155)" },
        { k: "list", items: [
          "<b>Figure (M p.155):</b> (1) square element under pure shear — top face arrow to the right, right face arrow up, bottom face arrow to the left, left face arrow down; red diagonal arrows at the corners: top-left C (compression, pointing inward), top-right T (tension, pointing outward), bottom-left T (outward), bottom-right C (inward).",
          "(2) a rectangular bar with a dashed centre line; labels 'Plane' (end face) and 'Axis' (centre line).",
          "(3) the same bar with red arrows up at the left end and down at the right end (shear couple) and a tilted outline of the bar: '→ Axis rotate, → Plane not rotate'.",
        ] },
        { k: "list", items: [
          "★ In one direction there is tensile stress, while in the other direction there is equal compressive stress. (M p.155)",
          "Due to such a loading, only the axis of the body rotates, without rotation of the plane. (M p.155)",
          "The case of pure shear is a special case of case (ii) where <b>σx = 0 and σy = 0</b>. Hence all the relations derived for case (ii) are applicable for case (iv). (M p.155)",
        ] },
        { k: "p", t: "For the general state of stress (σx, σy, τxy — figure on M p.155): σn OR σn′ = (σx + σy)/2 ± ((σx − σy)/2) cos2θ ± τxy sin2θ;  τ′xy = −((σx − σy)/2) sin2θ + τxy cos2θ;  σ₁ OR σ₂ = (σx + σy)/2 ± √(((σx − σy)/2)² + τxy²). In all the above relations, put σx = 0 and σy = 0 to get all relations corresponding to the pure shear case. (M p.155)" },
        { k: "eq", expr: "σn OR σn′ = ± τxy·sin2θ      τ′xy = τxy·cos2θ      σ₁ OR σ₂ = ± τxy", where: [
          ["τ′xy", "maximum at θ = 0°"],
          ["+τxy", "σ₁ (major, tension)"],
          ["−τxy", "σ₂ (minor, compression)"],
        ] },
        { k: "note", t: "<b>Marathi line (M p.155):</b> beside τ′xy = τxy cos2θ … ★ max at 0° the notes write '(external वर maxᵐ असतो)' — <i>the maximum is on the external faces</i>. (The small word after 'external' is hard to read in the scan.)" },
        { k: "p", t: "Figure (M p.155): pure-shear element with a red dashed inclined plane at angle θ (marked at the bottom-right corner) and a small rotated element on it showing σn, σn′ and τxy along its faces." },
        { k: "steps", items: [
          "To find the principal plane, τ′xy = 0, θ = θp. (M p.155)",
          "Either τxy = 0 or cos2θp = 0 → <b>θp = 45°</b>. (M p.155)",
          "<b>σ₁ OR σ₂ = ±τxy</b>:  +τxy ⇐ σ₁,  −τxy ⇐ σ₂. (M p.155)",
        ] },
        { k: "list", items: [
          "<b>NOTE (M p.155):</b>",
          "In case of pure shear, maximum shear stress is nothing but the applied shear stress, i.e. τmax occurs at θ = 0°.",
          "Principal plane is found out at an angle of 45°.",
          "Major and minor principal stresses are equal but unlike.",
        ] },
        { k: "cmp", t: "Pure shear — sign convention and principal stresses (M p.156)", cols: ["Sign", "Principal stress"], rows: [
          ["Tension", "+ve", "σ₁ = +τxy — major"],
          ["Compression", "−ve", "σ₂ = −τxy — minor"],
        ] },
        { k: "p", t: "Principal stresses in pure shear are <b>equal in magnitude and unlike in direction</b>. (M p.156)" },
        { k: "p", t: "Figure (M p.156): pure-shear element (top → right, right ↑, bottom ← left, left ↓) with corner arrows C (top-left, inward), T (top-right, outward), T (bottom-left, outward), C (bottom-right, inward); a red dashed diagonal at 45° labelled 'Principal Plane'. Below it the element rotated 45° onto the principal planes, with outward arrows σ₁ = τxy (tension) and inward arrows σ₂ = τxy (compression)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Pure shear mein faces par sirf shear hai, lekin element ko 45° ghumao to shear gayab aur ek diagonal par tension (+τ), doosre par utna hi compression (−τ). Matlab 'pure shear' asal mein 45° par ek tension + ek compression ka jodaa hai. Isliye τmax faces par hi (θ = 0°) hota hai aur principal planes 45° par — biaxial-without-shear case ka bilkul ulta." },
        { k: "trap", t: "Pure shear mein σ₁ = +τ aur σ₂ = −τ — dono ka magnitude same par sign ulta (unlike). σ₂ = 0 ya σ₁ = 2τ likhna galat hai. Aur 'principal plane 45° par' ka matlab yeh nahi ki τmax bhi 45° par hai — pure shear mein τmax θ = 0° (bahar ke faces) par hai." },
        { k: "real", t: "Torsion mein shaft ki surface pure shear mein hoti hai. Isliye chalk (brittle, tension mein kamzor) ko marodo to woh 45° helix par tootta hai (σ₁ = +τ wali diagonal ke perpendicular), jabki mild steel shaft (ductile, shear mein kamzor) seedha cross-section par (τmax plane, θ = 0°) tootta hai — jaisa §2.5 ki table aur Chapter 6 mein hai." },
      ],
    },

    /* ---------------------------------------------- case v */
    {
      n: "",
      title: "MACE notes — Case (v): normal stress on one plane with shear (σy = 0)",
      hi: "एक तल पर अभिलंब प्रतिबल और अपरूपण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.156–157" },
        { k: "p", t: "<b>Case (v): Normal stress on any one plane with shear</b> — <b>σy = 0, σx ≠ 0, τxy ≠ 0</b>. (M p.156)" },
        { k: "p", t: "Figure (M p.156): square element with σx outward on the left and right faces, shear arrows along the faces (top → right, right ↑, bottom ← left, left ↓), and a red dashed inclined plane with angle θ at the bottom-right corner." },
        { k: "steps", items: [
          "σn OR σn′ = σx/2 ± (σx cos2θ)/2 ± τxy sin2θ (M p.156)",
          "<b>σn OR σn′ = (σx/2)(1 ± cos2θ) ± τxy sin2θ</b> (M p.156)",
          "<b>τ′xy = −(σx/2) sin2θ + τxy cos2θ</b> ——① (M p.156)",
          "τ′xy = 0 for the principal plane: τxy cos2θp = −(σx/2) sin2θp (as written; see Check below) (M p.156)",
          "<b>tan2θp = 2τxy/σx</b> … inclination of principal plane (M p.156)",
        ] },
        { k: "note", t: "<b>Check:</b> the notes write the zero-shear step as 'τxy cos2θp = −(σx/2) sin2θp'. Setting ① to zero gives τxy cos2θp = <b>+</b>(σx/2) sin2θp, which leads to the boxed tan2θp = 2τxy/σx. The boxed result is right; only the sign in the intermediate line is a slip." },
        { k: "h", t: "Plane of maximum shear (M p.156)" },
        { k: "steps", items: [
          "To find: τ′xy ⇒ τmax = ? Differentiate equation ① with respect to θ and equate to zero. (M p.156)",
          "dτ′xy/dθ → 0 = −(σx/2)(cos2θ) × 2 − τxy sin2θ × 2 (the 2's cancel) (M p.156)",
          "2τxy sin2θ = −σx cos2θ (M p.156)",
          "★ <b>tan2θ = −σx/(2τxy)</b> — inclination of the plane of maximum shear (M p.156)",
        ] },
        { k: "p", t: "<b>Conclusion (M p.156):</b> the inclination of the plane of maximum shear will depend upon the relative magnitude of normal stress and shear stress." },
        { k: "h", t: "Principal stresses (M p.156–157)" },
        { k: "steps", items: [
          "σ₁ OR σ₂ = σx/2 ± √((σx/2)² + τxy²) (M p.156)",
          "σ₁ OR σ₂ = σx/2 ± √(σx²/4 + τxy²) (M p.156)",
          "σ₁ OR σ₂ = σx/2 ± (1/2)√(σx² + 4τxy²) (M p.157)",
          "★ <b>σ₁ OR σ₂ = (1/2)(σx ± √(σx² + 4τxy²))</b> (M p.157)",
        ] },
        { k: "eq", expr: "tan2θp = 2τxy/σx      tan2θs = −σx/(2τxy)      σ₁,₂ = (1/2)[σx ± √(σx² + 4τxy²)]", where: [
          ["θp", "principal plane"],
          ["θs", "plane of maximum shear"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the older notes (p.7, §2.6 of this chapter) write tan2θs = (σx − σy)/(2τxy); the MACE notes (M p.156) get tan2θ = −σx/(2τxy) for σy = 0, i.e. tan2θs = −(σx − σy)/(2τxy) in general. Re-derived from ③ (dτ′xy/dθ = −(σx − σy)cos2θ − 2τxy sin2θ = 0), the <b>minus sign is correct</b>, as §2.6 already notes. With it, tan2θp × tan2θs = −1, so 2θp and 2θs differ by 90° and the principal and max-shear planes are 45° apart." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Yeh case beam aur shaft mein sabse common hai: ek direction mein bending/axial stress σx aur saath mein shear τ, doosri direction mein kuch nahi (σy = 0). Formula general case ⑤ se hi aata hai, bas σy = 0 rakh do. Dhyaan do ki σ₁ hamesha +ve aur σ₂ hamesha −ve hoga (kyunki √(σx² + 4τ²) &gt; σx) — tension wale member mein bhi ek principal compression aa jaata hai jab shear saath ho." },
        { k: "trap", t: "Max-shear plane ka formula principal plane ka ulta-reciprocal hai, sirf reciprocal nahi: tan2θp = 2τ/σx, tan2θs = −σx/(2τ). Minus sign chhodoge to angle 90° ki jagah galat aayega. Aur (1/2)(σx ± √(σx² + 4τ²)) mein bracket ke bahar ka ½ dono terms par lagta hai." },
        { k: "real", t: "RCC beam ke support ke paas bending stress σx aur shear τ dono hote hain — σ₁ (diagonal tension) wahan inclined cracks banata hai, isliye stirrups aur bent-up bars diye jaate hain. Shaft mein bending + torsion ka combined design (Chapter 6) bhi isi σ₁,₂ = ½[σ ± √(σ² + 4τ²)] se hota hai." },
      ],
    },

    /* ---------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Principal stresses, analytical method cases i–v (M p.144–157)",
      hi: "पुनरावृत्ति — मुख्य प्रतिबल, विश्लेषणात्मक विधि",
      blocks: [
        { k: "h", t: "✅ Key formulas, values and results" },
        { k: "list", items: [
          "Stresses by eccentricity of load: direct and bending; direct stress on an inclined plane → normal stress + shear stress (M p.144).",
          "Principal plane: τ = 0, σn ≠ 0; stress on it = principal stress. 'Normal plane' (notes' term): τ ≠ 0 and σn ≠ 0 (M p.144–145).",
          "Naming: biggest = major σ₁, smallest = minor, remaining = intermediate — 'जो मोठा तो major, जो लहान तो minor' (M p.145).",
          "Stress transformation by (1) analytical (equilibrium) method, (2) graphical (Mohr's circle) method (M p.145).",
          "Case (i) uniaxial: σn = σx cos²θ; τ = (σx/2) sin2θ; σR = √(σn² + τ²) (M p.146).",
          "Uniaxial: τmax = σx/2 at 45° or 135°; (σn)45° = (τ)45° = σx/2; (σn)max = σx at θ = 0°, 180° = major principal stress (M p.147).",
          "Que 1: 20 MPa pull → σn on max-shear plane = 10 MPa (M p.147). Que 2: σn = half of applied σx = τmax (M p.148).",
          "Que 3: circular bar, load T → τ = (2T/πD²) sin2θ (M p.148). Que 4: 10 kN on 100 × 100 face → σ₁ = 1 MPa (M p.148).",
          "Case (ii): σn = σx cos²θ + σy sin²θ + τxy sin2θ = (σx + σy)/2 + ((σx − σy)/2)cos2θ + τxy sin2θ; σn′ with both lower signs (M p.149).",
          "Case (ii): τ′xy = −((σx − σy)/2) sin2θ + τxy cos2θ (M p.150) — agrees with the corrected §2.5.",
          "Principal plane: tan2θp = 2τxy/(σx − σy) (M p.150).",
          "Principal stresses: σ₁,₂ = (σx + σy)/2 ± √(((σx − σy)/2)² + τxy²) (M p.151).",
          "Invariant: σx + σy = σn + σn′ = σ₁ + σ₂ (M p.151–152).",
          "Que 1 (σx = σy = 10, τ = 3, θ = 45°): σn = 13 MPa, σn′ = 7 MPa (M p.151).",
          "Que 2: notes take τmax = larger of (σx − σy)/2 and τxy; general τmax = √(((σx − σy)/2)² + τxy²) (M p.151, see Check).",
          "Que 3: σx = 11.3, σy = 9.2 → sum 20.5 → option (d) 10.3 and 10.2 MPa (M p.152).",
          "Que 4: 10 + 12 = 17 + σ₂ → σ₂ = 5 MPa (data inconsistent: formula gives 14.16 and 7.84) (M p.152).",
          "Que 5: σx = σy = σ → σ₁,₂ = σ ± τxy (M p.152). Que 6: 10 ± 1 → 11 and 9 MPa (M p.153).",
          "Case (iii) τxy = 0: external planes are principal; σn,n′ = (σ₁ + σ₂)/2 ± ((σ₁ − σ₂)/2)cos2θ; τ′xy = −((σ₁ − σ₂)/2) sin2θ (M p.153).",
          "Case (iii): τmax = (σ₁ − σ₂)/2 at 45° or 135°; τmax = 0 when σ₁ = σ₂; σn on max-shear planes = (σ₁ + σ₂)/2, equal and alike (M p.153).",
          "Case (iii): σR = √((σ₁² + σ₂²)/2); angle of obliquity tanβ = τ/σn; at τmax tanβ = (σ₁ − σ₂)/(σ₁ + σ₂) (M p.154).",
          "Case (iv) pure shear (σx = σy = 0): σn,n′ = ±τxy sin2θ; τ′xy = τxy cos2θ, max at θ = 0°; θp = 45°; σ₁ = +τxy, σ₂ = −τxy — equal and unlike; axis rotates, plane does not (M p.155–156).",
          "Case (v) σy = 0: σn,n′ = (σx/2)(1 ± cos2θ) ± τxy sin2θ; τ′xy = −(σx/2) sin2θ + τxy cos2θ; tan2θp = 2τxy/σx; tan2θs = −σx/(2τxy) (M p.156).",
          "Case (v): σ₁,₂ = σx/2 ± √((σx/2)² + τxy²) = ½(σx ± √(σx² + 4τxy²)) (M p.156–157).",
          "Plane of maximum shear depends on the relative magnitude of normal and shear stress (M p.156).",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
