/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: Structural Analysis handbook, Ch. 4–5
   Influence lines · Deflections
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 4.1 BMD vs ILD */
  "hb-sa-ild-concept": {
    label: "Bending moment diagram compared with an influence line",
    svg: `<svg viewBox="0 0 700 330" role="img" aria-label="Left, a bending moment diagram with the load fixed and the section varying. Right, an influence line with the section fixed at C and the unit load moving along the beam.">
      ${hbmk("ic")}
      <text class="em" x="168" y="26" text-anchor="middle">BENDING MOMENT DIAGRAM</text>
      <text class="lb" x="168" y="44" text-anchor="middle">load FIXED · section VARIES</text>
      <line class="s" x1="40" y1="94" x2="296" y2="94"/>
      <path class="s" d="M40 94 L28 114 L52 114 Z"/><circle class="s" cx="290" cy="104" r="8"/>
      <line class="ac" x1="168" y1="60" x2="168" y2="88" marker-end="url(#ic-c)"/>
      <text class="ea" x="180" y="74">W</text>
      <line class="s" x1="40" y1="190" x2="296" y2="190"/>
      <path class="soft" d="M40 190 L168 262 L296 190 Z"/>
      <path class="hi" d="M40 190 L168 262 L296 190"/>
      <path class="thin dash" d="M100 190 L100 226"/>
      <path class="thin dash" d="M230 190 L230 226"/>
      <text class="lb" x="168" y="286" text-anchor="middle">read: moment at each section,</text>
      <text class="lb" x="168" y="304" text-anchor="middle">for this one position of the load</text>
      <text class="lb" x="168" y="322" text-anchor="middle">units: kNm</text>

      <line class="gl" x1="350" y1="16" x2="350" y2="320"/>

      <text class="em" x="528" y="26" text-anchor="middle">INFLUENCE LINE FOR M at C</text>
      <text class="lb" x="528" y="44" text-anchor="middle">section FIXED at C · load MOVES</text>
      <line class="s" x1="400" y1="94" x2="656" y2="94"/>
      <path class="s" d="M400 94 L388 114 L412 114 Z"/><circle class="s" cx="650" cy="104" r="8"/>
      <circle class="acf" cx="502" cy="94" r="5"/>
      <text class="ea" x="502" y="84" text-anchor="middle">C</text>
      <line class="ac" x1="580" y1="60" x2="580" y2="88" marker-end="url(#ic-c)"/>
      <text class="ea" x="592" y="74">1</text>
      <path class="thin dash" d="M556 68 L604 68"/>
      <line class="thin" x1="556" y1="52" x2="612" y2="52" marker-start="url(#ic-a)" marker-end="url(#ic-a)"/>
      <text class="lb" x="584" y="44" text-anchor="middle">moves</text>
      <line class="s" x1="400" y1="190" x2="656" y2="190"/>
      <path class="softa" d="M400 190 L502 248 L656 190 Z"/>
      <path class="ac" d="M400 190 L502 248 L656 190"/>
      <line class="thin dash" x1="502" y1="94" x2="502" y2="256"/>
      <text class="ea" x="516" y="264">ab/L</text>
      <text class="lb" x="528" y="286" text-anchor="middle">read: moment at C, as the</text>
      <text class="lb" x="528" y="304" text-anchor="middle">unit load stands at each point</text>
      <text class="lb" x="528" y="322" text-anchor="middle">units: m (metres!)</text>
    </svg>`,
    caption: "They look alike and mean opposite things. The BMD answers <em>where is the moment largest for this load</em>; the influence line answers <em>where should the load stand to make the moment at C largest</em>. <strong>The peak of an influence line is a position, not a force.</strong>",
  },

  /* ---------------------------------------- 4.2 THE THREE BASIC ILDs */
  "hb-sa-ild-basic": {
    label: "Influence lines for reaction, shear and moment on a simply supported beam",
    svg: `<svg viewBox="0 0 700 420" role="img" aria-label="A simply supported beam with a section at C, and three influence lines below it: for the reaction at A, for the shear at C showing a unit jump across C, and for the bending moment at C peaking at C">
      ${hbmk("ib")}
      <line class="s" x1="80" y1="52" x2="600" y2="52"/>
      <path class="s" d="M80 52 L68 72 L92 72 Z"/>
      <circle class="s" cx="592" cy="62" r="9"/>
      ${grd(60, 72, 40)} ${grd(576, 72, 40)}
      <circle class="acf" cx="288" cy="52" r="5"/>
      <text class="ea" x="288" y="42" text-anchor="middle">C</text>
      <text class="lb" x="80" y="92" text-anchor="middle">A</text>
      <text class="lb" x="600" y="92" text-anchor="middle">B</text>
      <line class="thin" x1="80" y1="106" x2="288" y2="106" marker-start="url(#ib-a)" marker-end="url(#ib-a)"/>
      <text class="lb" x="184" y="122" text-anchor="middle">a</text>
      <line class="thin" x1="288" y1="106" x2="600" y2="106" marker-start="url(#ib-a)" marker-end="url(#ib-a)"/>
      <text class="lb" x="444" y="122" text-anchor="middle">b</text>

      <text class="em" x="40" y="164">ILD for RA</text>
      <line class="s" x1="80" y1="196" x2="600" y2="196"/>
      <path class="softa" d="M80 160 L600 196 L80 196 Z"/>
      <path class="ac" d="M80 160 L600 196"/>
      <text class="ea" x="96" y="154">1.0</text>
      <text class="lb" x="620" y="200">0</text>
      <text class="lb" x="340" y="216" text-anchor="middle">straight line — dimensionless ordinate</text>

      <text class="em" x="40" y="260">ILD for V at C</text>
      <line class="s" x1="80" y1="292" x2="600" y2="292"/>
      <path class="softa" d="M288 268 L600 292 L288 292 Z"/>
      <path class="soft" d="M80 292 L288 316 L288 292 Z"/>
      <path class="ac" d="M80 292 L288 316"/>
      <path class="ac" d="M288 268 L600 292"/>
      <line class="hi" x1="288" y1="316" x2="288" y2="268"/>
      <text class="em" x="300" y="264">+ b/L</text>
      <text class="em" x="276" y="330" text-anchor="end">− a/L</text>
      <text class="lb" x="340" y="344" text-anchor="middle">a jump of exactly 1.0 across the section</text>

      <text class="em" x="40" y="376">ILD for M at C</text>
      <line class="s" x1="80" y1="398" x2="600" y2="398"/>
      <path class="soft" d="M80 398 L288 356 L600 398 Z"/>
      <path class="hi" d="M80 398 L288 356 L600 398"/>
      <text class="em" x="300" y="352">ab/L</text>
      <text class="lb" x="470" y="414" text-anchor="middle">peak sits under the section — ordinate in metres</text>
    </svg>`,
    caption: "Three shapes worth knowing cold. All are straight lines because the beam is determinate. The shear influence line has a <strong>unit jump at the section</strong> — that is the signature that tells you it is a shear line and not a reaction line.",
  },

  /* ---------------------------------------- 4.3 MULLER-BRESLAU */
  "hb-sa-muller": {
    label: "Muller-Breslau's principle applied three times",
    svg: `<svg viewBox="0 0 700 330" role="img" aria-label="Three constructions: releasing the vertical restraint at A and lifting it by one gives the reaction influence line, cutting the beam at C and sliding one unit gives the shear line, inserting a hinge at C and rotating by one unit gives the moment line">
      ${hbmk("mb")}
      <text class="lb" x="116" y="26" text-anchor="middle">REACTION at A</text>
      <line class="thin dash" x1="30" y1="120" x2="210" y2="120"/>
      <path class="hi" d="M30 84 L210 120"/>
      <line class="ac" x1="30" y1="120" x2="30" y2="90" marker-end="url(#mb-c)"/>
      <text class="ea" x="18" y="106" text-anchor="end">1</text>
      <circle class="s" cx="202" cy="130" r="8"/>
      <text class="lb" x="116" y="166" text-anchor="middle">remove the vertical restraint</text>
      <text class="lb" x="116" y="184" text-anchor="middle">and lift it by one unit</text>

      <line class="gl" x1="240" y1="16" x2="240" y2="220"/>

      <text class="lb" x="350" y="26" text-anchor="middle">SHEAR at C</text>
      <line class="thin dash" x1="262" y1="120" x2="442" y2="120"/>
      <path class="hi" d="M262 120 L350 138"/>
      <path class="hi" d="M350 102 L442 120"/>
      <line class="ac" x1="350" y1="138" x2="350" y2="102" marker-start="url(#mb-c)" marker-end="url(#mb-c)"/>
      <text class="ea" x="362" y="124">1</text>
      <path class="s" d="M262 120 L252 136 L272 136 Z"/>
      <circle class="s" cx="436" cy="130" r="8"/>
      <text class="lb" x="350" y="166" text-anchor="middle">cut at C and slide the two faces</text>
      <text class="lb" x="350" y="184" text-anchor="middle">past each other by one unit</text>

      <line class="gl" x1="472" y1="16" x2="472" y2="220"/>

      <text class="lb" x="582" y="26" text-anchor="middle">MOMENT at C</text>
      <line class="thin dash" x1="494" y1="120" x2="672" y2="120"/>
      <path class="hi" d="M494 120 L582 92 L672 120"/>
      <circle class="acf" cx="582" cy="92" r="5"/>
      <path class="ac" d="M560 80 A28 28 0 0 1 604 80" marker-start="url(#mb-c)" marker-end="url(#mb-c)"/>
      <text class="ea" x="582" y="70" text-anchor="middle">1 rad</text>
      <path class="s" d="M494 120 L484 136 L504 136 Z"/>
      <circle class="s" cx="666" cy="130" r="8"/>
      <text class="lb" x="582" y="166" text-anchor="middle">insert a hinge at C and rotate</text>
      <text class="lb" x="582" y="184" text-anchor="middle">through one unit of relative angle</text>

      <line class="gl" x1="20" y1="238" x2="680" y2="238"/>
      <text class="em" x="350" y="266" text-anchor="middle">Remove the restraint that corresponds to the quantity you want.</text>
      <text class="em" x="350" y="290" text-anchor="middle">Impose one unit of the displacement it used to prevent.</text>
      <text class="lb" x="350" y="316" text-anchor="middle">The deflected shape IS the influence line — no equilibrium equations at all.</text>
    </svg>`,
    caption: "The fastest tool in the chapter. For a determinate structure the released shape is made of straight lines, so <strong>two ordinates fix the whole diagram</strong>. For an indeterminate one the shape is curved and the principle still gives it — which is often all a preliminary check needs.",
  },

  /* ---------------------------------------- 4.4 USING AN ILD */
  "hb-sa-ild-use": {
    label: "Reading an influence line: point load, distributed load and a load train",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="Three ways to use an influence line: multiply a point load by the ordinate under it, multiply a distributed load by the area beneath the covered length, and place the heaviest wheel of a load train at the peak">
      ${hbmk("iu")}
      <text class="em" x="112" y="26" text-anchor="middle">POINT LOAD</text>
      <line class="s" x1="26" y1="150" x2="200" y2="150"/>
      <path class="soft" d="M26 150 L112 106 L200 150 Z"/>
      <path class="hi" d="M26 150 L112 106 L200 150"/>
      <line class="ac" x1="86" y1="84" x2="86" y2="122" marker-end="url(#iu-c)"/>
      <text class="ea" x="96" y="80">W</text>
      <line class="thin dash" x1="86" y1="122" x2="86" y2="150"/>
      <text class="lb" x="112" y="182" text-anchor="middle">response = W × y</text>
      <text class="lb" x="112" y="200" text-anchor="middle">y = ordinate under the load</text>

      <line class="gl" x1="232" y1="16" x2="232" y2="212"/>

      <text class="em" x="350" y="26" text-anchor="middle">DISTRIBUTED LOAD</text>
      <line class="s" x1="264" y1="150" x2="438" y2="150"/>
      <path class="soft" d="M264 150 L350 106 L438 150 Z"/>
      <path class="hi" d="M264 150 L350 106 L438 150"/>
      <path class="softa" d="M300 128 L350 106 L400 131 L400 150 L300 150 Z"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="ac" x1="${302+i*20}" y1="70" x2="${302+i*20}" y2="${118+Math.abs(i-2.5)*5}" marker-end="url(#iu-c)"/>`).join("")}
      <text class="ea" x="350" y="62" text-anchor="middle">w</text>
      <text class="lb" x="350" y="182" text-anchor="middle">response = w × (shaded area)</text>
      <text class="lb" x="350" y="200" text-anchor="middle">cover only the positive part</text>

      <line class="gl" x1="470" y1="16" x2="470" y2="212"/>

      <text class="em" x="586" y="26" text-anchor="middle">LOAD TRAIN</text>
      <line class="s" x1="500" y1="150" x2="674" y2="150"/>
      <path class="soft" d="M500 150 L586 106 L674 150 Z"/>
      <path class="hi" d="M500 150 L586 106 L674 150"/>
      <line class="ac" x1="586" y1="70" x2="586" y2="102" marker-end="url(#iu-c)"/>
      <text class="ea" x="596" y="70">100</text>
      <line class="ac" x1="634" y1="86" x2="634" y2="126" marker-end="url(#iu-c)"/>
      <text class="ea" x="644" y="84">50</text>
      <line class="thin dash" x1="586" y1="102" x2="586" y2="150"/>
      <line class="thin dash" x1="634" y1="126" x2="634" y2="150"/>
      <text class="lb" x="586" y="182" text-anchor="middle">heaviest wheel on the peak</text>
      <text class="lb" x="586" y="200" text-anchor="middle">then Σ (W × y) for the rest</text>

      <line class="gl" x1="20" y1="230" x2="680" y2="230"/>
      <text class="lb" x="350" y="258" text-anchor="middle">A negative ordinate is not an error — it means a load there REDUCES the response.</text>
      <text class="lb" x="350" y="280" text-anchor="middle">For the maximum, leave those stretches unloaded. For the minimum, load only those.</text>
      <text class="em" x="350" y="312" text-anchor="middle">This is why a design envelope needs both patterns,</text>
      <text class="em" x="350" y="332" text-anchor="middle">and why IS 456 asks for alternate spans loaded on a continuous beam.</text>
    </svg>`,
    caption: "Three rules cover every use. The third one matters most in practice: a moving load system is positioned by <strong>trial, guided by the peak</strong> — put the heaviest wheel on the highest ordinate, sum the products, then try the next wheel on the peak and compare.",
  },

  /* ---------------------------------------- 5.2 STRAIN ENERGY */
  "hb-sa-strain": {
    label: "Strain energy as the area under the load-deflection curve",
    svg: `<svg viewBox="-30 0 772 300" role="img" aria-label="A load against deflection graph, linear up to the working load, with the triangular area beneath it shaded as the strain energy stored and labelled one half P delta">
      ${hbmk("se")}
      <line class="s" x1="80" y1="240" x2="380" y2="240" marker-end="url(#se-a)"/>
      <line class="s" x1="80" y1="240" x2="80" y2="60" marker-end="url(#se-a)"/>
      <text class="lb" x="390" y="244">deflection δ</text>
      <text class="lb" x="74" y="54" text-anchor="end">load P</text>
      <path class="softa" d="M80 240 L320 100 L320 240 Z"/>
      <path class="ac" d="M80 240 L320 100"/>
      <line class="thin dash" x1="320" y1="100" x2="80" y2="100"/>
      <line class="thin dash" x1="320" y1="100" x2="320" y2="240"/>
      <text class="ea" x="74" y="104" text-anchor="end">P</text>
      <text class="ea" x="320" y="260" text-anchor="middle">δ</text>
      <text class="em" x="216" y="196" text-anchor="middle">U = ½ P δ</text>
      <text class="lb" x="230" y="288" text-anchor="middle">linear material and small displacements — both assumed throughout this chapter</text>

      <line class="gl" x1="430" y1="30" x2="430" y2="280"/>
      <text class="em" x="450" y="66">Strain energy stored</text>
      <text x="450" y="104">Axial:      U = ∫ N² dx / 2AE</text>
      <text x="450" y="136">Bending:    U = ∫ M² dx / 2EI</text>
      <text x="450" y="168">Shear:      U = ∫ κV² dx / 2AG</text>
      <text x="450" y="200">Torsion:    U = ∫ T² dx / 2GJ</text>
      <text class="lb" x="450" y="240">In beams and frames the bending term</text>
      <text class="lb" x="450" y="258">dominates — the others are usually</text>
      <text class="lb" x="450" y="276">neglected, and that is stated, not assumed.</text>
    </svg>`,
    caption: "Work done on the structure is stored as strain energy, and for a linear structure loaded gradually that work is <strong>½ P δ, not P δ</strong> — the load grows from zero as the deflection grows. Forgetting the half is the most common slip in Castigliano problems.",
  },

  /* ---------------------------------------- 5.4 UNIT LOAD */
  "hb-sa-unitload": {
    label: "The two systems in the unit load method",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Left, the real structure under the real loads giving bending moment M. Right, the same structure under a single unit load at the point and direction of the wanted deflection, giving bending moment m. The deflection is the integral of M m over EI.">
      ${hbmk("ul")}
      <text class="em" x="168" y="26" text-anchor="middle">REAL SYSTEM</text>
      <text class="lb" x="168" y="44" text-anchor="middle">actual loads · gives M</text>
      <line class="s" x1="40" y1="96" x2="296" y2="96"/>
      <path class="s" d="M40 96 L28 116 L52 116 Z"/><circle class="s" cx="290" cy="106" r="8"/>
      ${[0,1,2,3,4,5,6,7].map(i=>`<line class="ac" x1="${44+i*33}" y1="62" x2="${44+i*33}" y2="90" marker-end="url(#ul-c)"/>`).join("")}
      <text class="ea" x="168" y="56" text-anchor="middle">w</text>
      <line class="s" x1="40" y1="182" x2="296" y2="182"/>
      <path class="soft" d="M40 182 Q168 252 296 182 Z"/>
      <path class="hi" d="M40 182 Q168 252 296 182"/>
      <text class="em" x="168" y="272" text-anchor="middle">M</text>

      <line class="gl" x1="350" y1="16" x2="350" y2="290"/>

      <text class="em" x="528" y="26" text-anchor="middle">UNIT SYSTEM</text>
      <text class="lb" x="528" y="44" text-anchor="middle">one unit load at the wanted point · gives m</text>
      <line class="s" x1="400" y1="96" x2="656" y2="96"/>
      <path class="s" d="M400 96 L388 116 L412 116 Z"/><circle class="s" cx="650" cy="106" r="8"/>
      <line class="ac" x1="528" y1="58" x2="528" y2="90" marker-end="url(#ul-c)"/>
      <text class="ea" x="540" y="72">1</text>
      <line class="s" x1="400" y1="182" x2="656" y2="182"/>
      <path class="softa" d="M400 182 L528 230 L656 182 Z"/>
      <path class="ac" d="M400 182 L528 230 L656 182"/>
      <text class="ea" x="528" y="272" text-anchor="middle">m</text>

      <line class="gl" x1="20" y1="288" x2="680" y2="288"/>
      <text class="em" x="350" y="312" text-anchor="middle">δ = ∫ M m dx / EI          (for a truss:  δ = Σ P k L / AE)</text>
    </svg>`,
    caption: "Two analyses of the <strong>same structure with the same supports</strong> — that is the condition students break. M comes from the real loads acting alone; m comes from the unit load acting alone. Mixing a released structure into one of them is the usual reason an answer is out by a factor.",
  },

  /* ---------------------------------------- 5.7 MOMENT AREA */
  "hb-sa-momentarea": {
    label: "The two moment-area theorems",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="Above, the M over EI diagram between two points A and B. Below, the deflected shape showing the change in slope between A and B as the area of the diagram, and the tangential deviation of B from the tangent at A as the moment of that area about B.">
      ${hbmk("ma")}
      <text class="em" x="40" y="34">M / EI</text>
      <line class="s" x1="120" y1="118" x2="560" y2="118"/>
      <path class="soft" d="M120 118 Q340 40 560 118 Z"/>
      <path class="hi" d="M120 118 Q340 40 560 118"/>
      <line class="thin dash" x1="120" y1="40" x2="120" y2="130"/>
      <line class="thin dash" x1="560" y1="40" x2="560" y2="130"/>
      <text class="lb" x="120" y="144" text-anchor="middle">A</text>
      <text class="lb" x="560" y="144" text-anchor="middle">B</text>
      <text class="em" x="340" y="92" text-anchor="middle">AREA</text>
      <circle class="acf" cx="330" cy="100" r="4"/>
      <line class="thin" x1="330" y1="100" x2="330" y2="130"/>
      <text class="lb" x="330" y="158" text-anchor="middle">centroid</text>
      <line class="thin" x1="330" y1="168" x2="560" y2="168" marker-start="url(#ma-a)" marker-end="url(#ma-a)"/>
      <text class="lb" x="446" y="184" text-anchor="middle">x̄ measured to B</text>

      <line class="gl" x1="60" y1="200" x2="660" y2="200"/>

      <path class="thin dash" d="M120 240 L560 240"/>
      <path class="s" d="M120 240 Q340 296 560 268"/>
      <path class="ac" d="M100 246 L300 218"/>
      <text class="ea" x="96" y="240" text-anchor="end">tangent at A</text>
      <line class="hi" x1="560" y1="230" x2="560" y2="268" marker-start="url(#ma-m)" marker-end="url(#ma-m)"/>
      <text class="em" x="574" y="254">t(B/A)</text>
      <path class="thin dash" d="M300 218 L588 178"/>
      <path class="thin" d="M540 244 A34 34 0 0 1 552 232"/>
      <text class="lb" x="516" y="222">θ(AB)</text>

      <line class="gl" x1="60" y1="288" x2="660" y2="288"/>
      <text class="em" x="350" y="312" text-anchor="middle">Theorem 1:  θ(AB) = area of the M/EI diagram between A and B</text>
      <text class="em" x="350" y="334" text-anchor="middle">Theorem 2:  t(B/A) = that area × x̄, the distance from its centroid to B</text>
    </svg>`,
    caption: "Both theorems are just the integral of M/EI read geometrically. The second one's <strong>x̄ is measured to the point whose deviation you want</strong>, not from it — reverse that and the answer is wrong by the amount that matters most.",
  },

  /* ---------------------------------------- 5.8 CONJUGATE BEAM */
  "hb-sa-conjugate": {
    label: "How supports convert in the conjugate beam method",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A table of conversions between the real beam and the conjugate beam: simple end stays simple, fixed end becomes free, free end becomes fixed, interior support becomes an internal hinge, and an internal hinge becomes an interior support">
      ${hbmk("cb")}
      <text class="em" x="180" y="30" text-anchor="middle">REAL BEAM</text>
      <text class="em" x="500" y="30" text-anchor="middle">CONJUGATE BEAM</text>
      <line class="gl" x1="40" y1="44" x2="660" y2="44"/>

      <line class="s" x1="120" y1="78" x2="240" y2="78"/>
      <path class="s" d="M150 78 L138 96 L162 96 Z"/>
      <text class="lb" x="60" y="82">simple end</text>
      <line class="ac" x1="300" y1="82" x2="360" y2="82" marker-end="url(#cb-c)"/>
      <line class="s" x1="440" y1="78" x2="560" y2="78"/>
      <path class="s" d="M470 78 L458 96 L482 96 Z"/>
      <text class="lb" x="596" y="82">unchanged</text>

      <line class="gl" x1="40" y1="110" x2="660" y2="110"/>

      <line class="s" x1="140" y1="144" x2="240" y2="144"/>
      <line class="s" x1="140" y1="126" x2="140" y2="162"/>
      ${grd(120, 162, 22)}
      <text class="lb" x="60" y="148">fixed end</text>
      <line class="ac" x1="300" y1="148" x2="360" y2="148" marker-end="url(#cb-c)"/>
      <line class="s" x1="460" y1="144" x2="560" y2="144"/>
      <text class="lb" x="596" y="148">free end</text>

      <line class="gl" x1="40" y1="176" x2="660" y2="176"/>

      <line class="s" x1="140" y1="210" x2="240" y2="210"/>
      <text class="lb" x="60" y="214">free end</text>
      <line class="ac" x1="300" y1="214" x2="360" y2="214" marker-end="url(#cb-c)"/>
      <line class="s" x1="460" y1="210" x2="560" y2="210"/>
      <line class="s" x1="460" y1="192" x2="460" y2="228"/>
      ${grd(440, 228, 22)}
      <text class="lb" x="596" y="214">fixed end</text>

      <line class="gl" x1="40" y1="242" x2="660" y2="242"/>

      <line class="s" x1="120" y1="272" x2="260" y2="272"/>
      <path class="s" d="M190 272 L178 290 L202 290 Z"/>
      <text class="lb" x="60" y="276">interior support</text>
      <line class="ac" x1="300" y1="276" x2="360" y2="276" marker-end="url(#cb-c)"/>
      <line class="s" x1="440" y1="272" x2="500" y2="272"/>
      <line class="s" x1="510" y1="272" x2="570" y2="272"/>
      <circle class="acf" cx="505" cy="272" r="5"/>
      <text class="lb" x="596" y="276">internal hinge</text>
    </svg>`,
    caption: "Load the conjugate beam with the real beam's M/EI diagram, and then <strong>its shear is the real slope and its bending moment is the real deflection.</strong> The support conversions are what make that trick legitimate — they enforce the right boundary conditions on slope and deflection.",
  },

});
