/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: BUILDING CONSTRUCTION handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.1 BUILDING ELEMENTS */
  "hb-bc-elements": {
    label: "A building is an assembly of elements",
    svg: `<svg viewBox="0 0 744 300" role="img" aria-label="A section through a simple building from the foundation up: the footing spreading load to the soil, the plinth with its damp-proof course, the load-bearing wall, the lintel over an opening, and the roof, each element named with the job it does.">
      ${hbmk("el2")}
      <text class="em" x="350" y="24" text-anchor="middle">EACH PART HANDS ITS LOAD TO THE ONE BELOW</text>
      <path class="steel" d="M150 66 L390 66 L370 92 L170 92 Z"/>
      <text class="lb" x="270" y="84" text-anchor="middle">ROOF</text>
      <rect class="conc" x="168" y="96" width="204" height="12"/>
      <text class="ea" x="270" y="105" text-anchor="middle">lintel band</text>
      <rect class="soft" x="168" y="108" width="28" height="96"/>
      <rect class="soft" x="344" y="108" width="28" height="96"/>
      <rect class="softa" x="196" y="120" width="148" height="70"/>
      <text class="lb" x="270" y="160" text-anchor="middle">opening</text>
      <text class="lb" x="150" y="150" text-anchor="end">wall</text>
      <line class="ac" x1="152" y1="150" x2="168" y2="150" marker-end="url(#el2-c)"/>
      <rect class="conc" x="150" y="204" width="240" height="14"/>
      <text class="ea" x="270" y="214" text-anchor="middle">plinth + DPC (stops rising damp)</text>
      <path class="conc" d="M150 218 L390 218 L420 250 L120 250 Z"/>
      <text class="lb" x="270" y="240" text-anchor="middle">FOUNDATION — spreads load to soil</text>
      <line class="s" x1="90" y1="250" x2="450" y2="250"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="thin" x1="${110+i*56}" y1="250" x2="${100+i*56}" y2="262"/>`).join("")}

      <line class="gl" x1="470" y1="56" x2="470" y2="286"/>
      <text class="em" x="488" y="84">the load path, top to bottom:</text>
      <text class="lb" x="488" y="110">roof → walls → foundation → soil</text>
      <text class="ea" x="488" y="140">every element exists to carry</text>
      <text class="lb" x="488" y="158">the one above it safely to the ground</text>
      <text class="em" x="488" y="190">two silent protectors:</text>
      <text class="lb" x="488" y="212">DPC — a barrier that stops ground</text>
      <text class="lb" x="488" y="230">water rising up into the wall</text>
      <text class="lb" x="488" y="252">lintel — spans the opening so the</text>
      <text class="lb" x="488" y="270">wall above does not fall into it</text>
    </svg>`,
    caption: "A building is not one thing but a stack of elements, each handing its load to the one below until the soil finally carries it all: roof to walls, walls to foundation, foundation to ground. Learning construction is learning what each element does and how it passes the load on. <strong>Two quiet details save more buildings than any calculation</strong> — the damp-proof course that blocks rising water, and the lintel that keeps the wall from collapsing into every door and window.",
  },

  /* ------------------------------------------- 3.1 BONDS */
  "hb-bc-bonds": {
    label: "Why brickwork is bonded — English and Flemish",
    svg: `<svg viewBox="-24 0 748 300" role="img" aria-label="Two brick bonds compared. On the left a stack with continuous vertical joints that split apart, marked wrong. Then English bond with alternating courses of headers and stretchers, and Flemish bond with headers and stretchers alternating within each course, both breaking the vertical joints so the wall acts as one.">
      ${hbmk("bo")}
      <text class="em" x="350" y="24" text-anchor="middle">BREAK THE VERTICAL JOINT OR THE WALL IS JUST STACKED</text>
      <text class="em" x="120" y="56" text-anchor="middle">UNBONDED — wrong</text>
      ${[0,1,2,3].map(r=>[0,1,2].map(c=>`<rect class="soft" x="${60+c*40}" y="${66+r*22}" width="36" height="18"/>`).join("")).join("")}
      <line class="hi" x1="100" y1="66" x2="100" y2="154"/>
      <line class="hi" x1="140" y1="66" x2="140" y2="154"/>
      <text class="lb" x="120" y="176" text-anchor="middle">joints line up →</text>
      <text class="lb" x="120" y="192" text-anchor="middle">splits into columns</text>

      <text class="em" x="330" y="56" text-anchor="middle">ENGLISH BOND</text>
      ${[0,2].map(r=>[0,1,2,3,4].map(c=>`<rect class="softa" x="${262+c*32}" y="${66+r*22}" width="28" height="18"/>`).join("")).join("")}
      ${[1,3].map(r=>[0,1].map(c=>`<rect class="soft" x="${262+c*80}" y="${66+r*22}" width="76" height="18"/>`).join("")).join("")}
      <text class="lb" x="330" y="176" text-anchor="middle">alternate courses:</text>
      <text class="lb" x="330" y="192" text-anchor="middle">all headers / all stretchers</text>

      <text class="em" x="560" y="56" text-anchor="middle">FLEMISH BOND</text>
      ${[0,1,2,3].map(r=>{let x=490+(r%2?18:0);let out="";for(let c=0;c<4;c++){const hdr=c%2===0;out+=`<rect class="${hdr?'softa':'soft'}" x="${x}" y="${66+r*22}" width="${hdr?28:56}" height="18"/>`;x+=hdr?32:60;}return out;}).join("")}
      <text class="lb" x="560" y="176" text-anchor="middle">within each course:</text>
      <text class="lb" x="560" y="192" text-anchor="middle">header, stretcher, header …</text>

      <text class="lb" x="350" y="224" text-anchor="middle">a HEADER shows its end (binds across the wall's thickness) · a STRETCHER shows its side (runs along the wall)</text>
      <text class="lb" x="350" y="250" text-anchor="middle">the bond staggers the vertical joints so a load spreads sideways through the wall instead of down one weak line</text>
      <text class="lb" x="350" y="276" text-anchor="middle">English is stronger and simpler; Flemish looks better on the face — the classic strength-versus-appearance trade</text>
    </svg>`,
    caption: "Stack bricks with their vertical joints lined up and you have not built a wall — you have built columns of bricks that split apart under load. Bonding staggers those joints so each brick sits over the two below it, tying the wall into one mass that spreads load sideways. Headers (ends showing) bind across the wall's thickness; stretchers (sides showing) run along it. <strong>English bond is the stronger, Flemish the better-looking</strong> — the same strength-versus-appearance choice that runs through all of building.",
  },

  /* ------------------------------------------- 4.1 SLENDERNESS */
  "hb-bc-slender": {
    label: "How a wall carries load — and how it fails",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A short stocky wall crushing under load beside a tall thin wall buckling sideways, showing that a masonry wall can fail two ways, and that the slenderness ratio of effective height to thickness decides which, with eccentric load making buckling worse.">
      ${hbmk("sl3")}
      <text class="em" x="350" y="24" text-anchor="middle">A WALL FAILS TWO WAYS — CRUSHING OR BUCKLING</text>
      <text class="em" x="150" y="58" text-anchor="middle">SHORT & THICK</text>
      <rect class="conc" x="110" y="72" width="80" height="150"/>
      <line class="ac" x1="130" y1="52" x2="130" y2="70" marker-end="url(#sl3-c)"/>
      <line class="ac" x1="170" y1="52" x2="170" y2="70" marker-end="url(#sl3-c)"/>
      <path class="hi" d="M120 210 L180 210 M124 218 L176 218"/>
      <text class="lb" x="150" y="244" text-anchor="middle">fails by CRUSHING —</text>
      <text class="lb" x="150" y="262" text-anchor="middle">the material is overloaded</text>
      <text class="lb" x="150" y="280" text-anchor="middle">low slenderness</text>

      <text class="em" x="470" y="58" text-anchor="middle">TALL & THIN</text>
      <path class="conc" d="M448 72 Q476 150 460 222 L484 222 Q500 150 472 72 Z"/>
      <line class="ac" x1="460" y1="52" x2="460" y2="70" marker-end="url(#sl3-c)"/>
      <path class="hi dash" d="M460 72 L460 222"/>
      <line class="ac" x1="486" y1="150" x2="520" y2="150" marker-end="url(#sl3-c)"/>
      <text class="ea" x="528" y="154">bows out</text>
      <text class="lb" x="470" y="248" text-anchor="middle">fails by BUCKLING —</text>
      <text class="lb" x="470" y="266" text-anchor="middle">bows out sideways first</text>
      <text class="lb" x="470" y="284" text-anchor="middle">high slenderness</text>

      <line class="gl" x1="300" y1="60" x2="300" y2="230"/>
      <text class="em" x="300" y="120" text-anchor="middle">slenderness =</text>
      <text class="lb" x="300" y="142" text-anchor="middle">effective height</text>
      <line class="s" x1="256" y1="150" x2="344" y2="150"/>
      <text class="lb" x="300" y="168" text-anchor="middle">effective thickness</text>
      <text class="lb" x="300" y="200" text-anchor="middle">the higher it is, the</text>
      <text class="lb" x="300" y="218" text-anchor="middle">more buckling governs</text>
    </svg>`,
    caption: "A masonry wall can fail in two completely different ways, and which one depends on its proportions. A short, thick wall is overloaded and crushes — a material failure. A tall, thin wall bows out sideways and buckles long before the brick is crushed — a stability failure. The slenderness ratio (effective height ÷ effective thickness) tells you which threat governs, and the code limits it. <strong>Load applied off-centre makes buckling far worse</strong>, which is why a wall carrying a slab on one edge is treated with special care.",
  },

  /* ------------------------------------------- 6.1 SEISMIC BANDS */
  "hb-bc-bands": {
    label: "Seismic bands — tying a masonry house together",
    anim: true,
    svg: `<svg viewBox="0 0 792 300" role="img" aria-label="A masonry house wrapped by horizontal reinforced concrete bands at plinth, sill, lintel and roof levels, with the bands holding the walls together as the ground shakes, contrasted with an unbanded house whose walls separate at the corners and collapse.">
      ${hbmk("bn2")}
      <text class="em" x="396" y="24" text-anchor="middle">BANDS TURN LOOSE WALLS INTO ONE BOX</text>
      <g class="an-sway" style="--amp:6;--dur:4s">
        <rect class="softa" x="120" y="90" width="180" height="140"/>
        ${[104, 134, 176, 222].map((y,i)=>`<rect class="conc" x="116" y="${y}" width="188" height="10"/>
          <text class="lb" x="312" y="${y+9}">${["roof band","lintel band","sill band","plinth band"][i]}</text>`).join("")}
        <rect class="soft" x="150" y="150" width="40" height="72"/>
        <rect class="soft" x="230" y="150" width="40" height="40"/>
      </g>
      <text class="em" x="210" y="256" text-anchor="middle">BANDED — walls held as one box</text>
      <text class="lb" x="210" y="276" text-anchor="middle">the bands wrap the walls and stop the corners tearing apart</text>

      <line class="gl" x1="470" y1="60" x2="470" y2="286"/>
      <text class="em" x="488" y="86">why masonry is dangerous in a quake:</text>
      <text class="lb" x="488" y="112">brick is strong in compression but</text>
      <text class="lb" x="488" y="130">weak in tension — shaking pulls the</text>
      <text class="lb" x="488" y="148">walls apart at the corners</text>
      <text class="em" x="488" y="178">the bands (horizontal RC ties):</text>
      <text class="lb" x="488" y="202">PLINTH · SILL · LINTEL · ROOF —</text>
      <text class="lb" x="488" y="220">continuous around the whole building</text>
      <text class="lb" x="488" y="242">they take the tension the brick can't,</text>
      <text class="lb" x="488" y="260">holding the walls together as one unit</text>
      <text class="lb" x="488" y="284">(vertical bars at corners complete the cage)</text>
    </svg>`,
    caption: "Unreinforced masonry is the deadliest common building type in an earthquake: brick is strong in compression but has almost no tension strength, so shaking tears the walls apart at the corners and they collapse outward. Seismic bands are continuous horizontal reinforced-concrete ties running right around the building at plinth, sill, lintel and roof levels — they take the tension the masonry cannot and hold the separate walls together as a single box. <strong>They are cheap, and in a quake they are the difference between a cracked house and a collapsed one.</strong>",
  },

  /* ------------------------------------------- 8.1 STAIR TERMS */
  "hb-bc-stair": {
    label: "The parts of a stair",
    svg: `<svg viewBox="0 0 746 290" role="img" aria-label="A flight of stairs in section showing the rise and going of each step, the tread and riser, a landing, and the rule that comfortable stairs follow a relationship between rise and going so the step is neither too steep nor too shallow.">
      ${hbmk("st3")}
      <text class="em" x="350" y="24" text-anchor="middle">A STAIR IS COMFORTABLE ONLY IF RISE AND GOING BALANCE</text>
      ${[0,1,2,3].map(i=>`<path class="conc" d="M${100+i*70} ${210-i*34} h56 v34 h-56 z"/>`).join("")}
      <path class="conc" d="M380 108 h120 v34 h-120 z"/>
      <text class="lb" x="440" y="130" text-anchor="middle">LANDING</text>
      <line class="ac" x1="162" y1="176" x2="162" y2="210" marker-end="url(#st3-c)" marker-start="url(#st3-c)"/>
      <text class="ea" x="176" y="196">RISE</text>
      <line class="ac" x1="170" y1="150" x2="226" y2="150" marker-end="url(#st3-c)" marker-start="url(#st3-c)"/>
      <text class="ea" x="198" y="144" text-anchor="middle">GOING</text>
      <text class="lb" x="128" y="230">the vertical face = RISER · the horizontal step = TREAD</text>

      <line class="gl" x1="470" y1="60" x2="470" y2="250"/>
      <text class="em" x="488" y="86">the comfort rules of thumb:</text>
      <text class="lb" x="488" y="112">2 × rise + going ≈ 550–650 mm</text>
      <text class="lb" x="488" y="134">rise × going ≈ 40000–45000 mm²</text>
      <text class="ea" x="488" y="164">typical: rise 150–190 mm,</text>
      <text class="lb" x="488" y="182">going 250–300 mm</text>
      <text class="lb" x="488" y="212">too much rise = tiring & steep;</text>
      <text class="lb" x="488" y="230">too little = you trip on the flat step</text>
      <text class="lb" x="488" y="248">— the rules keep the pace natural</text>
    </svg>`,
    caption: "A stair feels comfortable or treacherous depending on one relationship: the rise (how far you step up) against the going (how far forward). Get it wrong and every user feels it — too much rise and the climb is exhausting and steep, too little and people trip on the almost-flat steps. The old rules of thumb (2×rise + going, and rise×going) encode the natural length of a human stride. <strong>A stair is one of the few structures whose design is set by the body, not the load.</strong>",
  },

});
