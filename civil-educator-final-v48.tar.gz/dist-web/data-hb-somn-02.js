/* MACE Academy SOM notes — Properties of materials (ductility to failure modes), M p.48–61 — inserted into som chapter 1 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 1; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------- M p.48 */
    {
      n: "",
      title: "MACE notes — Ductility and brittleness (the 5% plastic-strain rule)",
      hi: "तन्यता और भंगुरता",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.48" },
        { k: "p", t: "Figure (M p.48): σ–ε curve — a straight rise from the origin, a hump, a dip, a larger hump, then falling to the <b>Breaking point</b>. A dashed vertical marks the end of the linear part. Below the strain axis the short first span is labelled <b>ε<sub>E</sub> = elastic strain</b> and the rest <b>ε<sub>p</sub> = plastic strain</b>. (M p.48)" },
        { k: "p", t: "Figure (M p.48), right side: <b>Loading</b> — a bar fixed at a wall, length 100 mm, extends 7 mm under P; the 7 mm splits into 5 mm (recovered) and 2 mm (stored). <b>Unloading</b> — the bar is now 102 mm long; the 2 mm is permanent deformation. (M p.48)" },
        { k: "eg", title: "MACE notes example — splitting total strain into elastic and plastic parts", given: "A bar 100 mm long extends 7 mm under load P. On unloading it recovers 5 mm and is left 102 mm long (2 mm permanent). Find the total, elastic and plastic strains.", steps: [
          { t: "Total strain", w: "ε = 7/100 = 7%" },
          { t: "Elastic strain (recovered part)", w: "ε_E = 5/100 = 5%" },
          { t: "Plastic strain (permanent part)", w: "ε_p = 2/100 = 2%" },
        ], ans: "Total strain 7%, elastic strain 5%, plastic strain 2% (M p.48)" },
        { k: "cmp", t: "Classification by plastic strain (M p.48)", cols: ["Plastic strain", "Examples given in the notes"], rows: [
          ["Ductile", "≥ 5%", "Mild steel"],
          ["Brittle", "&lt; 5%", "Rubber, chalk, cast iron"],
        ] },
        { k: "note", t: "<b>Check:</b> the notes list <i>rubber</i> among brittle examples on M p.48. Rubber is not brittle — it takes very large strains and recovers them; the notes themselves call it a <b>non-linear elastic</b> material on M p.52. Read the brittle examples as chalk and cast iron (and concrete, glass — next block)." },
        { k: "def", term: "Ductility", t: "• It is the stretching ability of a material.<br>• A ductile material can deform in large amounts before breaking.<br>• Ductile material can be drawn into wires.<br>• Post-elastic strain or plastic strain is greater than 5%.<br>• Examples: mild steel, copper, aluminium, manganese, lead, brass, nickel, bronze etc. (M p.48)" },
        { k: "def", term: "Brittleness", t: "• Brittleness is simply lack of ductility.<br>• Brittle materials show a very small amount of deformation.<br>• They fail immediately if stretched beyond the elastic limit.<br>• Post-elastic strain / plastic strain is less than 5%.<br>• For a brittle material the fracture point and the ultimate point are both the same, and after the proportional limit there is very small strain.<br>• Examples: cast iron, concrete, glass etc. (M p.48)" },
        { k: "note", t: "NOTE (M p.48): generally <b>ductile materials are tough</b> and <b>brittle materials are hard</b>." },
        { k: "note", t: "<b>Source difference:</b> the MACE notes list <b>lead</b> among ductile examples (M p.48), but on the next page say “Lead is malleable but not ductile” (M p.49); the existing §1.2 trap also says lead is malleable but not very ductile. Both statements in the notes are kept as written. The second is the one to use: lead is soft and very malleable, but it has low tensile strength and necks early, so it is poor at being drawn into wire. (General Engineering Knowledge.)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "5% wala rule ek simple yardstick hai: load hatane ke baad jo strain <b>wapas nahi aata</b> (plastic strain) woh kitna hai. Total strain nahi dekhna — sirf permanent hissa. Notes ke 100 mm bar mein total 7% hai, par permanent sirf 2% — is rule se woh bar brittle side par aata (2% &lt; 5%). Mild steel fracture tak bahut zyada permanent stretch deta hai, isliye ductile." },
        { k: "p", t: "Brittle material mein ultimate point aur fracture point ek hi hote hain — peak load aate hi toot jaata hai, necking ka koi stage nahi. Isiliye brittle failure 'bina warning' hota hai. Full stress-strain curve ke points A–G §1.5 mein hain." },
        { k: "trap", t: "Classification ke liye <b>total strain</b> ko 5% se compare kar dena common galti hai. Rule <b>plastic (post-elastic) strain</b> par hai: ε<sub>p</sub> ≥ 5% → ductile, ε<sub>p</sub> &lt; 5% → brittle." },
        { k: "real", t: "TMT bar ka elongation test isi idea ka site version hai — bar tod kar permanent elongation dekhte hain; zyada elongation = zyada ductility = earthquake mein zyada warning." },
      ],
    },

    /* ---------------------------------------------- M p.49–50 */
    {
      n: "",
      title: "MACE notes — Malleability and creep (cold flow)",
      hi: "आघातवर्धनीयता और विसर्पण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.49–50" },
        { k: "def", term: "1) Malleability", t: "A material which can deform continuously under compressive load is called a malleable material. Such material possesses a high degree of plasticity. The property which allows conversion of a material into thin sheets is called malleability. (M p.49)" },
        { k: "note", t: "NOTE (M p.49): <b>Lead is malleable but not ductile.</b>" },
        { k: "def", term: "2) Creep (cold flow)", t: "It is the property or tendency of a material to move slowly or deform permanently under the influence of a persistent load, i.e. permanent deformation due to a sustained load or stationary load is called creep. (M p.49)" },
        { k: "p", t: "Consider a bar loaded with a constant load of 2 kN; afterwards we can simply observe the excess deformation Δc. (M p.49)" },
        { k: "p", t: "Figure (M p.49): two horizontal bars, each fixed to a wall at the left. Top bar: dashed extension, load P = 2 kN, labelled “at time t₁”. Bottom bar: same bar with a larger dashed extension, labelled “at time t₂ (after long time)” under “static or persistent or sustained load” P = 2 kN. Dimension marks show <b>Δe</b> (extension at t₁) followed by <b>Δc</b> (additional extension). (M p.49)" },
        { k: "list", items: [
          "<b>Δe</b> = elastic deformation (M p.49)",
          "<b>Δc</b> = creep deformation (permanent nature) (M p.49)",
        ] },
        { k: "p", t: "<b>The rate of creep deformation depends upon</b> (M p.49):" },
        { k: "list", items: [
          "i) Type of load (static or dynamic) → for creep = <b>static load</b>",
          "ii) Magnitude of load",
          "iii) Time and age of loading",
          "iv) Temperature — at high temperature the material loses strength and the elastic constants also decrease. Hence creep becomes more critical as the temperature increases towards the melting-point temperature.",
        ] },
        { k: "list", items: [
          "Creep may or may not comprise a failure mode always. (M p.49)",
          "Example i) A moderate amount of creep in concrete is welcomed — it reduces tensile stresses and hence cracking is avoided. (M p.49)",
          "Example ii) Creep deformation is very slow and steady, in which strain accumulates as a result of long-term stress. (M p.50)",
          "★ Thus, creep is a <b>time-dependent phenomenon</b>. (M p.50)",
          "Creep works on Hooke's law. (M p.50)",
        ] },
        { k: "note", t: "<b>Check:</b> “creep works on Hooke's law” (M p.50) should not be read literally — Hooke's law (σ = Eε) gives the instantaneous elastic strain Δe only; creep strain Δc keeps growing at <i>constant</i> stress, which Hooke's law cannot give. What the line most likely means is that creep happens at ordinary service stresses inside the elastic (Hookean) range. For concrete, the existing §1.6 shows the usual way creep is handled: creep strain = creep coefficient × elastic strain. (General Engineering Knowledge.)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Malleability = hathode se peet kar <b>sheet</b> banana (compression); ductility = khinch kar <b>wire</b> banana (tension). Isliye ek material ek mein achha aur doosre mein kamzor ho sakta hai — lead iska standard example hai." },
        { k: "p", t: "Creep mein load <b>badalta nahi</b>, phir bhi deformation time ke saath badhta hai. Day 1 par jo Δe dikha woh Hooke's law se aata hai; mahino-saalon mein jo extra Δc judta hai woh creep hai, aur woh permanent hai. Temperature badhne par effect aur tez ho jaata hai." },
        { k: "trap", t: "Creep ke liye <b>static / sustained</b> load chahiye — dynamic ya cyclic load creep nahi, fatigue (neeche) ka topic hai. MCQ mein 'repeated loading' dikhe to answer fatigue hai, creep nahi." },
        { k: "real", t: "Concrete ka moderate creep beneficial hai: restrained shrinkage aur temperature se bane tensile stress dheere-dheere relax ho jaate hain, isliye cracking kam hoti hai (M p.49). Par prestressed concrete mein yahi creep prestress kam kar deta hai, aur purane slabs ka dheere-dheere sag bhi isi se hota hai." },
      ],
    },

    /* ---------------------------------------------- M p.50–51 */
    {
      n: "",
      title: "MACE notes — Hardness: scratch, indentation and rebound tests",
      hi: "कठोरता — खरोंच, इंडेंटेशन और रिबाउंड परीक्षण",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.50–51" },
        { k: "def", term: "3) Hardness", t: "It is a measure of resistance to localised plastic deformation induced by either mechanical indentation or abrasion (friction). (M p.50)" },
        { k: "cmp", t: "Measurement of hardness — 3 methods (M p.50–51)", cols: ["Load used", "Instrument / scales in the notes"], rows: [
          ["i) Scratch hardness", "Static load", "Mohs scale [1–10]; sclerometer"],
          ["ii) Indentation hardness", "Static load", "Rockwell, Brinell, Vickers, Shore durometer"],
          ["iii) Rebound hardness (dynamic hardness)", "Dynamic load", "Scleroscope; Leeb rebound hardness, Bennett hardness scale"],
        ] },
        { k: "h", t: "i) Scratch hardness (M p.50)" },
        { k: "list", items: [
          "It measures the resistance of a sample against fracture or permanent plastic deformation due to friction from a sharp object.",
          "Principle: a hard material will scratch an object made of relatively softer material.",
          "Most common test is the <b>Mohs scale [1–10]</b> (used to evaluate hardness of the screen of a smartphone).",
          "Sometimes scratch hardness can also be measured by a <b>sclerometer</b>.",
        ] },
        { k: "h", t: "ii) Indentation hardness (M p.50)" },
        { k: "list", items: [
          "It is the resistance of a sample to material deformation due to a constant compressive load of a sharp object.",
          "Important and common indentation hardness scales: I) Rockwell hardness · II) Brinell hardness · III) Vickers hardness · IV) Shore durometer hardness.",
          "The Brinell hardness tester consists of a <b>steel ball of 10 mm diameter</b>.",
          "For mild steel: <b>Brinell hardness number (BHN) = 120</b>.",
          "Vickers hardness is an alternative to Brinell hardness.",
          "Shore durometer is used to find hardness of polymers, elastomers, rubber.",
        ] },
        { k: "h", t: "iii) Rebound hardness — dynamic hardness (M p.51)" },
        { k: "list", items: [
          "It is measured on the basis of the height of the bounce of a diamond-tipped hammer dropped from a fixed height onto a material.",
          "This type of hardness is related to the <b>elasticity</b>.",
          "The device used to take this measurement is the <b>scleroscope</b>.",
          "There are two scales which measure rebound hardness: i) Leeb rebound hardness · ii) Bennett hardness scale.",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Teen tareeke, teen sawaal: <b>scratch</b> — kaun kisko khurach sakta hai (Mohs: diamond 10 sabse upar); <b>indentation</b> — static load se kitna gehra/bada dent bana (dent chhota = material hard); <b>rebound</b> — hammer kitna uchhal kar wapas aaya (zyada bounce = zyada elastic energy wapas mili). BHN ka formula aur ek solved example §1.6 mein hai." },
        { k: "trap", t: "<b>Sclerometer</b> (scratch hardness) aur <b>scleroscope</b> (rebound hardness) — naam milte-julte hain, MCQ mein inhi ko ulta karke poochte hain. Yaad rakho: scope = bounce dekhna." },
        { k: "real", t: "Site par concrete ka rebound hammer test bhi isi rebound principle par chalta hai — surface hardness se strength ka andaaza (non-destructive), par woh sirf indication hai, core test ka substitute nahi. (General Engineering Knowledge.)" },
      ],
    },

    /* ---------------------------------------------- M p.51–52 */
    {
      n: "",
      title: "MACE notes — Tenacity, elasticity and work done (area under the load–displacement curve)",
      hi: "दृढ़ता, प्रत्यास्थता और किया गया कार्य",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.51–52" },
        { k: "def", term: "4) Tenacity", t: "It is the ability to resist fracture under tensile load. (M p.51)" },
        { k: "def", term: "5) Elasticity", t: "It is the ability of a material due to which it regains its original shape and size after removal of load. (M p.51)" },
        { k: "list", items: [
          "On application of load the material deforms. On removal of the load the material can either regain its original dimensions or remain in the same state of deformation.",
          "If the original dimensions are regained, it is an <b>elastic material</b>.",
          "If the original dimensions are not recovered, it is a <b>plastic material</b>.",
          "Sometimes a material may recover its dimensions but only partly (not fully), as shown below. (M p.51)",
        ] },
        { k: "p", t: "Figure (M p.51): load–deformation graph. The <b>loading</b> curve rises from the origin, concave down. The <b>unloading</b> curve comes down from the top point to a point on the x-axis to the right of the origin. The dotted region between loading and unloading curves is the <b>non-recoverable strain energy</b>; the region under the unloading curve, up to a vertical dashed line from the top point, is the <b>recoverable strain energy</b>. On the x-axis: origin to unloading foot = <b>ε<sub>plastic</sub></b>; unloading foot to the dashed vertical = <b>ε<sub>elastic</sub></b>; whole length = <b>Δ<sub>total</sub></b>. (M p.51)" },
        { k: "list", items: [
          "Generally materials are elastic up to small deformation only; thus an <b>ideal elastic material never exists in nature</b>. (M p.51)",
          "Margin note (Marathi): “कितीही deform करा सगळं deformation Recover होईल” — <i>however much you deform it, all the deformation will recover</i> — i.e. 100% elastic nature, <b>ε<sub>p</sub> = 0</b>. (M p.51)",
          "For an ideal elastic material, post-elastic strain will be zero. (M p.51)",
          "Rubber is a <b>non-linear elastic</b> material. (M p.52)",
        ] },
        { k: "def", term: "6) Work done", t: "Area under the load–displacement curve. (M p.52)" },
        { k: "eq", expr: "Work done = P·s  (load × displacement in the direction of load), unit N·m", where: [
          ["P", "load"],
          ["s", "displacement in the direction of the load (M p.52)"],
        ] },
        { k: "p", t: "Figure (M p.52): a bar fixed to a wall at the left, pulled by P at the right, extension marked Δs. A second graph: load P (vertical) vs displacement s (horizontal) from O, curve rising concave down; a thin hatched vertical strip of width ds and height P under the curve; the area under the curve up to s is labelled “Work done”. (M p.52)" },
        { k: "eq", expr: "Small work dW = P·ds (elemental area);  integrating on both sides: WD = ∫ P·ds", where: [
          ["WD", "work done as calculated from the load–displacement curve (M p.52)"],
          ["unit", "N·m ; 1 N·m = 1 joule"],
        ] },
        { k: "p", t: "WD = energy consumed or stored = ∫P·ds; N·m = energy. (M p.52)" },
        { k: "cmp", t: "Work done for four load–displacement shapes (figure, M p.52)", cols: ["Shape of the graph", "Work done"], rows: [
          ["(1) Linear", "Straight line from origin to load P at displacement s (triangle)", "WD = ½ P·s"],
          ["(2) Non-linear", "Curve rising concave down", "WD = ∫ P·ds"],
          ["(3) Plastic", "Horizontal line at P from 0 to s (rectangle)", "WD = P·s"],
          ["(4) Elasto-plastic", "Straight rise to P over s₁, then horizontal at P over s₂", "WD = ½ P s₁ + P s₂ = P [s₁/2 + s₂]"],
        ] },
        { k: "p", t: "Figure (M p.52): a bar of length L extended by ΔL under P; below it three springs — <b>unstrained</b> (length L); <b>strained</b> by ΔL under P (“WD on spring = energy gets stored in spring”); and <b>return to original</b> (“strain energy released — elastic potential energy — energy stored is released due to removal of load”). (M p.52)" },
        { k: "p", t: "<b>Strain energy released or stored = work done on the body = area under the load–deflection curve.</b> (M p.52)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Linear case mein ½ isliye aata hai kyunki load zero se dheere-dheere P tak badhta hai — average load P/2. Plastic case mein load shuru se hi P par hai, isliye poora P·s. Elasto-plastic = pehle triangle, phir rectangle — dono areas jodo." },
        { k: "p", t: "Loading aur unloading curve ke beech ka area (non-recoverable) heat/permanent set mein kharch ho jaata hai; unloading curve ke neeche wala area spring ki tarah wapas mil jaata hai. Yahi split aage resilience (recoverable) aur toughness (sab kuch) ban jaata hai." },
        { k: "trap", t: "Gradually applied load par WD = ½P·δ hota hai, P·δ nahi. ½ bhoolna sabse common galti hai; P·δ sirf tab jab load poore displacement mein constant ho (plastic case)." },
      ],
    },

    /* ---------------------------------------------- M p.53–54 */
    {
      n: "",
      title: "MACE notes — Resilience U = P²L/2AE, with numericals",
      hi: "प्रत्यास्थ ऊर्जा (रेज़िलिएंस) और संख्यात्मक प्रश्न",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.53–54" },
        { k: "def", term: "7) Resilience (U)", t: "When load is applied the body deforms, which is called strain. The deformation and load can be plotted on a graph called the load–deflection curve. Due to application of load on any material, work is done on that material; thus some energy is stored in that material. This energy gets released on removal of load. This energy is called <b>strain energy</b> or <b>elastic potential energy (U)</b>. (M p.53)" },
        { k: "list", items: [
          "★ Resilience is nothing but the <b>total strain energy stored in the body up to the elastic limit</b>. (M p.53)",
          "It means resilience is the <b>recoverable strain energy</b>. (M p.53)",
          "Thus, Resilience = area under the load–deflection curve up to the elastic limit. (M p.53)",
        ] },
        { k: "p", t: "Figure (M p.53): load (vertical) vs displacement (horizontal). A straight line from the origin up to point E at load P; the triangle under this line is shaded. After E a horizontal plateau, then a hump rising and falling to the end. Along the displacement axis: <b>ΔL<sub>e</sub></b> = elastic deformation (origin to below E) and <b>(ΔL)<sub>p</sub></b> = plastic deformation (from there to the end). The shaded area shows recoverable strain energy and the non-shaded area shows non-recoverable strain energy. (M p.53)" },
        { k: "eq", expr: "Resilience = ½ × P × ΔL(elastic) = ½ × P × (PL/AE)   →   U = P²L / (2AE)", where: [
          ["U ∝ P²", "strain energy goes as the square of the load"],
          ["U ∝ L", "the notes write this as “U² ∝ L” — a slip; the boxed formula gives U ∝ L"],
          ["U ∝ 1/AE", "AE = axial rigidity (M p.53)"],
        ] },
        { k: "eg", title: "MACE notes example — Q.1 strain energy when load is doubled and length halved", given: "The strain energy stored in the body was 2 kN·m due to a load P. If the load P is doubled while the length of the member is halved, what is the percentage increase or decrease in strain energy? (a) 100% increase (b) 100% decrease (c) 50% increase (d) 50% decrease", steps: [
          { t: "Write U for both cases", w: "U₁ = P₁²L₁/(2A₁E₁) = P²L/(2AE) = 2 kN·m\nU₂ = P₂²L₂/(2A₂E₂)" },
          { t: "Substitute P₂ = 2P, L₂ = L/2", w: "U₂ = (2P)²·(L/2)/(2AE) = 4P²·(L/2)/(2AE) = 2(P²L/2AE) = 2U₁" },
          { t: "Value", w: "U₂ = 2U₁ = 2 × 2 = 4 kN·m" },
        ], ans: "U₂ = 4 kN·m — strain energy increased by 100% (to 200% of the original). Option (a) (M p.53–54)" },
        { k: "eg", title: "MACE notes example — Q.2 steel and aluminium bars storing equal strain energy", given: "Two bars A and B are made of steel and aluminium. If both bars are subjected to the same loads, what will be the relationship between length and diameter of the bars if they store equal strain energy? Assume modulus of elasticity of steel = 200 GPa and of aluminium = 80 GPa.", steps: [
          { t: "Figure", w: "Bar A — steel, Es = 200 GPa, length LA, diameter DA.\nBar B — aluminium, EAL = 80 GPa, length LB, diameter DB. Both fixed at the left end." },
          { t: "Equal strain energy", w: "UA = UB\nP²LA/(2AE)A = P²LB/(2AE)B   (P² and 2 cancel)" },
          { t: "Put A = (π/4)D²", w: "LA/((π/4)·DA²·200) = LB/((π/4)·DB²·80)   (π/4 cancels)\nLA/(DA²·5) = LB/(DB²·2)" },
        ], ans: "LA/LB = (5/2)·(DA/DB)² (M p.54)" },
        { k: "p", t: "<b>Conclusion</b> (M p.54):" },
        { k: "list", items: [
          "Resilience ↑ = (P²/2) × (axial flexibility) ↑",
          "Resilience ↓ = (P²/2) × 1/(axial stiffness ↑)",
          "Strain energy ∝ P² · strain energy ∝ L · strain energy ∝ 1/(AE)",
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "U = P²L/2AE ko aise padho: <b>U = ½ × P × δ</b>, aur δ = PL/AE. Jo bar zyada stretch hota hai (lamba, patla, ya kam E wala) woh same load par zyada energy store karta hai. Isliye aluminium (E kam) wala bar steel ke barabar energy tabhi store karega jab woh chhota ya mota ho — Q.2 ka answer yahi kehta hai: same diameter par steel bar ko 2.5 guna lamba hona padega." },
        { k: "p", t: "Q.1 mein load double → P² se 4 guna; length half → ½ guna; net 4 × ½ = 2 guna. Yeh 'ratio method' har aise MCQ mein seedha kaam aata hai — A aur E same rahe to unhe likhne ki zaroorat bhi nahi." },
        { k: "trap", t: "U ∝ P² hai, P nahi — load double karne par energy double nahi, chaar guna hoti hai. Aur U ∝ 1/AE: stiffer bar <b>kam</b> energy store karta hai, zyada nahi." },
        { k: "real", t: "Isi wajah se impact/shock lene wale bolts (jaise machine foundation bolts) ko kabhi-kabhi shank par patla kar dete hain — zyada flexibility = zyada energy absorb karne ki capacity. Shock load par detailed treatment <a href=\"#/read/som/8\">Chapter 8</a> mein hai. (General Engineering Knowledge.)" },
      ],
    },

    /* ---------------------------------------------- M p.55–56 */
    {
      n: "",
      title: "MACE notes — Proof stress, proof resilience and modulus of resilience",
      hi: "प्रूफ प्रतिबल, प्रूफ रेज़िलिएंस और रेज़िलिएंस मापांक",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.55" },
        { k: "p", t: "Mild steel shows a clear yield point, but some metals like aluminium do not show a clear yield point. Such materials directly get fractured, i.e. the yield point is not clear. To find the yield point of such a material we use the following <b>offset method</b>. (M p.55)" },
        { k: "p", t: "Figure (M p.55): stress–strain curve rising from the origin, concave down, continuing beyond point E. A short segment at the origin is the “initial stress–strain curve”. On the strain axis the <b>0.2% offset strain</b> is marked; from that point a line parallel to the initial curve rises to meet the curve at <b>E</b>. A horizontal dashed line from E to the stress axis is labelled <b>σ<sub>y</sub> (proof stress)</b>. Region A (between the curve and the parallel line, left) = non-recoverable strain energy. Region B (shaded triangle under the parallel line up to the vertical from E) = <b>proof resilience (recoverable strain energy)</b>. On the strain axis from the foot of the parallel line to the foot of the vertical from E: <b>ε<sub>proof</sub></b>. (M p.55)" },
        { k: "steps", items: [
          "Step 1: mark the 0.2% offset strain. (M p.55)",
          "Step 2: draw a line parallel to the initial stress–strain curve starting from the offset and cutting the stress–strain curve at point E. The stress corresponding to E is the yield stress, also called the <b>proof stress</b>, and the strain corresponding to the proof stress is the <b>proof strain</b>. (M p.55)",
        ] },
        { k: "list", items: [
          "The shaded area denotes recoverable strain energy, called <b>proof resilience</b>. (M p.55)",
          "The unshaded area shows non-recoverable strain energy. (M p.55)",
        ] },
        { k: "note", t: "NOTE (M p.55): Resilience and proof resilience both denote the recoverable strain energy, but <b>proof resilience</b> is the word generally used for materials which do not show a clear yield point, and hence σ<sub>p</sub> and ε<sub>proof</sub> are required to find the proof resilience (P.R)." },
        { k: "eq", expr: "Proof resilience  P.R = σp² / (2E)   or   P.R = σy² / (2E)", where: [
          ["σp", "proof stress"],
          ["σy", "yield stress (M p.55)"],
          ["E", "modulus of elasticity"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the MACE notes write proof resilience as σ<sub>p</sub>²/2E (M p.55) — a <i>per-unit-volume</i> quantity — and group it with MOR in the units table (M p.59). The older notes in this handbook (<a href=\"#/read/som/6\">Chapter 6</a>, p.16) define proof resilience as the <b>maximum strain energy stored up to the elastic limit</b> (total, in N·m) and modulus of resilience = proof resilience ÷ volume. Re-deriving: total energy to the limit = ½ × P × ΔL = σ²/2E × (A·L), so σ²/2E is the energy <i>per unit volume</i>. The Chapter 6 usage (proof resilience = total energy, J; MOR = σ²/2E, J/m³) is the common textbook convention; read the notes' σ<sub>p</sub>²/2E as the proof resilience per unit volume." },
        { k: "h", t: "📘 MACE notes — Modulus of resilience (MOR), M p.56" },
        { k: "p", t: "For comparing the resilience or energy-absorption ability of different materials, we define resilience on a per-unit-volume basis. This resilience per unit volume is simply called the <b>modulus of resilience</b>. (M p.56)" },
        { k: "def", term: "Modulus of resilience (MOR)", t: "Total strain energy stored per unit volume up to the elastic limit, i.e. resilience per unit volume. MOR = area under the stress–strain curve up to the elastic limit. (M p.56)" },
        { k: "steps", items: [
          "Resilience/Volume = (½ × P × ΔL)/Volume (M p.56)",
          "MOR = ½ · (P·ΔL)/(A × L) = ½ · (P/A) · (ΔL/L)",
          "∴ <b>MOR = ½ σ ε</b> … ①",
          "But σ = E·ε ∴ ① ⇒ <b>MOR = (E/2)·ε²</b>",
          "Also, Resilience = P²L/2AE, so MOR = Resilience/Volume = (P²L/2AE) × 1/(A × L) = (P²/A²) · (1/2E)",
          "∴ <b>MOR = σ²/(2E)</b>",
        ] },
        { k: "p", t: "Figure (M p.56): small σ–ε graph — straight line from the origin up to σ, then horizontal, then a hump; the triangle under the straight line is shaded; strain ε marked below. (M p.56)" },
        { k: "eq", expr: "MOR = ½ σ ε = (E/2) ε² = σ² / (2E)", where: [
          ["σ", "stress at the elastic limit"],
          ["ε", "strain at the elastic limit"],
          ["E", "modulus of elasticity (M p.56)"],
        ] },
        { k: "note", t: "(GATE, M p.56): For a given material, <b>strain energy is a quadratic function of strain</b> (∵ MOR ∝ ε² ⇒ MOR ∝ Δl²/l²)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Resilience kisi <b>bar</b> ki property hai (size par depend karti hai); MOR <b>material</b> ki property hai (per unit volume). Do materials compare karne hon to MOR dekho, ek member ki energy chahiye to resilience = MOR × volume." },
        { k: "p", t: "Teeno forms ek hi triangle ka area hain: base ε, height σ → ½σε; σ = Eε daalo to Eε²/2 ya σ²/2E. Exam mein jo data diya ho (σ ya ε) usi form ko pakdo. 0.2% offset ka poora tarika aur TMT bar ka example §1.5 mein hai." },
        { k: "trap", t: "Offset line ko <b>stress–strain curve ke initial (straight) hisse ke parallel</b> kheenchna hai, horizontal ya vertical nahi. Aur offset <b>0.2% strain</b> (0.002) hai, 0.2 nahi." },
      ],
    },

    /* ---------------------------------------------- M p.57–59 */
    {
      n: "",
      title: "MACE notes — Toughness, modulus of toughness, impact tests and units",
      hi: "चीमड़पन, चीमड़पन मापांक, प्रभाव परीक्षण और इकाइयाँ",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.57" },
        { k: "def", term: "Toughness", t: "It is the ability of a material to absorb energy and deform plastically without fracture. In simple words, the total strain energy stored/absorbed by the material till it fractures or breaks is called toughness. (M p.57)" },
        { k: "p", t: "Figure (M p.57): P (vertical) vs ΔL (horizontal). Straight rise from the origin, a short horizontal plateau, then a hump ending at fracture point <b>F</b> (dashed vertical down to the axis at ε<sub>f</sub>). The entire area under the curve is shaded and labelled “Total SE” = recoverable + non-recoverable strain energy. (M p.57)" },
        { k: "list", items: [
          "The total area under the load–deflection curve till the material fractures, i.e. up to ε<sub>f</sub>, is termed the toughness of the material. (M p.57)",
          "Toughness ⇒ total strain energy stored in any volume up to the fracture point.",
          "Toughness ⇒ area under the load–deflection curve up to the fracture point.",
          "Toughness ⇒ recoverable + non-recoverable strain energy, i.e. toughness is the sum of elastic and non-elastic/inelastic strain energy.",
          "For a material to be tough there should be a proper balance between <b>strength and ductility</b>. More is the ductility, more will be the area under the curve and hence tougher will be the material.",
          "Thus ductile materials are generally tough, while brittle materials, even though strong, are not tough; thus brittle materials are hard.",
          "For a material to be tough it should withstand both high stresses and high strains.",
          "<b>Mild steel bars are tougher than HYSD bars.</b> (M p.57)",
        ] },
        { k: "h", t: "📘 MACE notes — Modulus of toughness (MOT), M p.58" },
        { k: "def", term: "Modulus of toughness (MOT)", t: "It is toughness per unit volume, i.e. total strain energy stored per unit volume of material till the material fractures.<br>• MOT ⇒ total strain energy stored per unit volume up to fracture point.<br>• MOT ⇒ area under the stress–strain curve up to fracture point.<br>• MOT ⇒ recoverable + non-recoverable strain energy per unit volume.<br>• MOT ⇒ toughness per unit volume. (M p.58)" },
        { k: "eq", expr: "MOT = ((σu + σy) / 2) · εf", where: [
          ["σu", "ultimate stress"],
          ["σy", "yield stress"],
          ["εf", "fracture strain (M p.58)"],
        ] },
        { k: "p", t: "Figure (M p.58): σ–ε curve — straight rise to σ<sub>y</sub>, horizontal plateau at σ<sub>y</sub>, then a hump rising to peak σ<sub>u</sub> and falling to fracture point F. Dashed horizontal lines to the σ-axis at σ<sub>u</sub>, at (σ<sub>u</sub> + σ<sub>y</sub>)/2 (extended to a vertical through F), and at σ<sub>y</sub>. ε<sub>f</sub> is marked from the origin to below F. The rectangle of height (σ<sub>u</sub> + σ<sub>y</sub>)/2 and width ε<sub>f</sub> stands in for the area under the curve. (M p.58)" },
        { k: "note", t: "<b>Source difference:</b> the existing §1.6 defines modulus of toughness as the <b>total area under the σ–ε curve up to fracture</b>; the MACE formula ((σ<sub>u</sub> + σ<sub>y</sub>)/2)·ε<sub>f</sub> (M p.58) is an <i>approximation</i> of that area — it replaces the curve by a rectangle at the average of yield and ultimate stress, which is close for a ductile metal whose curve stays between σ<sub>y</sub> and σ<sub>u</sub> over most of its strain. The definition (true area) is the exact one; the formula is the working estimate. (General Engineering Knowledge.)" },
        { k: "p", t: "Toughness can be determined by the <b>Izod and Charpy</b> methods. (M p.58)" },
        { k: "cmp", t: "Impact tests (M p.58)", cols: ["Charpy impact test", "Izod impact strength test"], rows: [
          ["Nature", "A standard <b>high strain rate (sudden loading)</b> test", "ASTM standard method of determining the impact resistance of a material"],
          ["What it gives", "Amount of energy absorbed by the material during fracture, i.e. <b>notch toughness</b>", "A notched sample is used to determine the impact energy"],
          ["Configuration (the only difference)", "<b>Three-point bending</b> configuration of sample", "<b>Cantilever beam</b> configuration of sample"],
        ] },
        { k: "h", t: "📘 MACE notes — Units and dimensions, M p.59" },
        { k: "cmp", t: "Units and dimensions (M p.59)", cols: ["Unit", "Dimension"], rows: [
          ["i) Resilience &amp; toughness (strain energy stored in a given volume)", "N·m or joule or kg·m²/s²", "M¹ L² T⁻²"],
          ["ii) MOR or proof resilience &amp; MOT (strain energy stored in unit volume)", "N·m/m³ or joule/m³ or kg/(m·s²)", "M¹ L⁻¹ T⁻²"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Resilience = sirf elastic triangle (jo wapas milta hai). Toughness = fracture tak <b>poora</b> area (wapas milne wala + kharch hone wala). Mild steel ka curve lamba hai (bada plastic stretch) isliye woh HYSD se zyada tough hai, chahe HYSD ki strength zyada ho — area height × length dono par depend karta hai." },
        { k: "p", t: "Units mein ek trick: J/m³ = N·m/m³ = N/m² — yaani MOR aur MOT ki unit wahi hai jo stress ki (Pa). Isiliye dimension bhi stress wala M L⁻¹ T⁻² hai. Resilience/toughness (total) ki unit energy wali J hai." },
        { k: "trap", t: "Izod = <b>cantilever</b>, Charpy = <b>simply supported, three-point bending</b>. Ulta yaad karna sabse common galti hai. Trick: Izod ka 'I' seedha khada (cantilever, ek end fixed)." },
        { k: "real", t: "Steel ki notch toughness (Charpy) cold-climate bridges aur welded heavy sections ke liye specify ki jaati hai, kyunki thand mein steel brittle behave kar sakta hai. Indian Standards ki list §1.6 ki table mein hai." },
      ],
    },

    /* ---------------------------------------------- M p.59–61 */
    {
      n: "",
      title: "MACE notes — Fatigue, endurance limit and the S–N curve",
      hi: "थकान, सहनशीलता सीमा और S–N वक्र",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.59–61" },
        { k: "list", items: [
          "Behaviour of a material is different for different loading conditions (static or dynamic). (M p.59)",
          "For cyclic and reverse-cyclic loading conditions keen consideration is important: when the total accumulated strain energy exceeds the modulus of toughness, fracture failure occurs. (M p.59)",
          "This failure due to continuous accumulation of strain energy which exceeds the modulus of toughness is called <b>fatigue failure</b>. In short, continuous load cycles lead to fatigue failure. (M p.59)",
        ] },
        { k: "cmp", t: "Fatigue occurs in two different phases (M p.59)", cols: ["Meaning", "Measured as"], rows: [
          ["1) Fatigue initiation life (FIL)", "Start of fracture (fatigue crack)", "No. of load cycles required to initiate the fatigue crack"],
          ["2) Fatigue propagation life (FPL)", "Extension of the fatigue crack", "No. of load cycles required to extend or propagate the fatigue surface crack"],
        ] },
        { k: "p", t: "★ <b>Characteristics of fatigue fracture</b> (M p.59):" },
        { k: "list", items: [
          "1) Rough and smooth areas on the fracture.",
          "2) No plastic deformation is absorbed (because loading does not exceed the elastic limit).",
          "3) Conchoidal markings on the fracture surface.",
        ] },
        { k: "note", t: "<b>Source difference:</b> the MACE notes explain fatigue as accumulated strain energy exceeding the modulus of toughness (M p.59); the existing §1.6 explains it as a crack that starts at a stress concentration and grows a little with every cycle. The two-phase description in the notes themselves (initiation life + propagation life) is the crack-growth picture, and that is the accepted mechanism — the energy wording is a classroom way of saying that damage accumulates cycle by cycle. The “rough and smooth areas” and conchoidal (beach) marks on the fracture are the slow crack-growth zone (smooth, marked) and the final sudden break (rough). (General Engineering Knowledge.)" },
        { k: "p", t: "★ <b>Factors affecting fatigue</b> (M p.60): 1) Loading conditions · 2) Frequency of loading · 3) Corrosion · 4) Temperature · 5) Stress concentration." },
        { k: "p", t: "Chances of fatigue failure ∝ temperature ∝ corrosion ∝ rate of loading ∝ stress concentration. (M p.60)" },
        { k: "p", t: "★ <b>Example of fatigue failure</b> (M p.60): 1) cyclic loading (bending back and forth) of binding wire." },
        { k: "h", t: "📘 Endurance limit / fatigue limit (M p.60)" },
        { k: "list", items: [
          "<b>Endurance</b> is the word used to denote the ability of a material to bear a continuous attack of load, i.e. endurance simply denotes the stamina of a material against load cycles.",
          "To prevent fatigue failure, the stress developed in the material shall not exceed the endurance limit of the material.",
        ] },
        { k: "def", term: "Endurance limit (Que: What is endurance limit?)", t: "It is the stress limit of a material below which it has a high probability of not failing even under infinite load cycles. (M p.60)" },
        { k: "list", items: [
          "<b>Endurance limit &lt; proportional limit &lt; elastic limit</b>. (M p.60)",
          "Thus, if the material stress level reaches the endurance limit, fatigue failure occurs. (M p.60)",
        ] },
        { k: "p", t: "Figure (M p.60): S–N type curve. Vertical axis “Applied stress”, horizontal axis “Allowable load cycles” with ∞ at the far end. The curve starts high and decreases steeply, then flattens asymptotically to a horizontal line; a dashed line from the flat level to the stress axis, and a double-headed vertical arrow from the x-axis to that level labelled <b>σ<sub>endurance</sub></b>. (M p.60)" },
        { k: "h", t: "📘 Endurance limit for various materials (M p.61)" },
        { k: "p", t: "Endurance limit is generally <b>0.35 to 0.60%</b> of tensile strength. (M p.61)" },
        { k: "note", t: "<b>Check:</b> “0.35 to 0.60%” should read <b>0.35 to 0.60 times</b> the tensile strength, i.e. 35% to 60%. The notes' own mild-steel value confirms this: 186 MPa is about 0.45 of a typical mild-steel tensile strength of about 410 MPa, not 0.45% of it (which would be under 2 MPa)." },
        { k: "cmp", t: "Endurance values listed in the notes (M p.61)", cols: ["As written in the notes"], rows: [
          ["Mild steel", "186 MPa"],
          ["Aluminium", "131 MPa (not clearly mentioned)"],
          ["Copper", "100 million cycles"],
          ["Concrete", "2 million cycles"],
        ] },
        { k: "note", t: "<b>Source difference:</b> the existing §1.6 says aluminium alloys show <b>no true endurance limit</b> — their fatigue strength keeps falling with more cycles, so it is quoted at a stated number of cycles. That fits the notes' own remark “not clearly mentioned” beside aluminium's 131 MPa: read it as a fatigue strength at some stated life, not a true limit. Likewise the copper and concrete entries are given as <i>numbers of cycles</i>, not stresses — they are the lives at which fatigue strength is usually quoted for those materials, not endurance limits in MPa." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Fatigue = baar-baar ka chhota load. Ek baar mein kuch nahi hota, har cycle mein crack thoda aage badhta hai, aur ek din bacha hua section achanak toot jaata hai — bina bade plastic deformation ke. Binding wire ko aage-peeche modte raho, kuch baar mein toot jaati hai — yahi fatigue hai (M p.60)." },
        { k: "p", t: "S–N curve mein stress jitna kam, utni zyada cycles tak material chalta hai. Steel ka curve ek level par flat ho jaata hai — woh endurance limit hai; usse neeche stress rakho to (practically) infinite cycles. Yeh limit proportional limit se bhi neeche hoti hai, isliye 'stress elastic range mein hai' kehna fatigue ke liye kaafi nahi." },
        { k: "trap", t: "Endurance limit ko '0.35–0.60%' of tensile strength mat likhna — fraction 0.35–0.60 hai, yaani 35–60%. Aur yaad rakho order: <b>endurance limit &lt; proportional limit &lt; elastic limit</b>." },
        { k: "real", t: "Bridge girders, crane gantry beams, machine foundations aur railway components fatigue-critical hote hain; welded details aur bolt holes (stress concentration) par sabse pehle crack shuru hota hai — isliye inhe smooth aur carefully detail kiya jaata hai." },
      ],
    },

    /* ---------------------------------------------- M p.61 */
    {
      n: "",
      title: "MACE notes — Failure modes of ductile and brittle materials (tension, compression, torsion)",
      hi: "तन्य और भंगुर पदार्थों के विफलता प्रकार",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.61" },
        { k: "p", t: "The notes split failure of materials into two branches: <b>ductile material (mild steel) — weak in shear</b>, and <b>brittle material (cement concrete or chalk) — weak in tension</b>. (M p.61)" },
        { k: "cmp", t: "Failure of materials (M p.61)", cols: ["Ductile (mild steel) — weak in shear", "Brittle (cement concrete / chalk) — weak in tension"], rows: [
          ["Tension", "1) Cup &amp; cone failure<br>2) Rough surface<br>3) Failure surface @ 45°", "1) Failure @ 90° (plane perpendicular to the axis)<br>2) Smooth surface"],
          ["Compression", "1) Bulging<br>2) Yielding failure<br>3) @ 90°", "1) Failure @ 45°<br>2) Sideways shear failure"],
          ["Torsion (NOTE)", "Failure plane at 90° to the axis (mild steel)", "Helicoidal surface at 45° to the axis of the specimen (standard cast iron)"],
        ] },
        { k: "list", items: [
          "Figure (M p.61) — ductile, tension: bar under axial pull T ← → T (dashed centre line); below it the broken ends drawn as cup and cone, labelled “failure surface”, with 45° marked on the conical surface.",
          "Figure (M p.61) — ductile, compression: short block with a downward load on top resting on a base; below it the bulged (barrel-shaped) specimen, with 90° marked between the axis and the failure plane.",
          "Figure (M p.61) — brittle, tension: bar T ← → T with the failure plane drawn perpendicular to the axis, 90° marked.",
          "Figure (M p.61) — brittle, compression: block on a base with a downward load; an inclined failure plane marked at 45° to the vertical axis.",
        ] },
        { k: "note", t: "NOTE — failure due to torsion (M p.61): a <b>helicoidal surface at 45°</b> to the axis of the specimen for standard cast iron (which is brittle), and for mild steel (which is ductile) it is <b>90°</b>." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Rule simple hai: material wahi plane chunta hai jahan woh sabse kamzor hai. Axial tension/compression mein <b>max shear 45° plane</b> par hota hai aur <b>max normal stress</b> axis ke 90° wale plane par. Ductile (shear mein kamzor) → 45° shear wala plane (cup-cone, ya compression mein shear slip ke saath bulging). Brittle (tension mein kamzor) → tension mein seedha 90° par, aur compression mein tension direct nahi milta isliye 45° ke aas-paas shear se sideways tootta hai." },
        { k: "p", t: "Torsion mein ulta dikhta hai: pure shear mein <b>max shear</b> cross-section (90° to axis) par hota hai aur <b>max tension</b> 45° helix par. Isliye mild steel (shear-weak) flat 90° par katta hai, cast iron/chalk (tension-weak) 45° helical surface par. Chalk ko ungliyon se marod kar dekho — 45° spiral break milega. Inclined-plane stresses ka full derivation <a href=\"#/read/som/2\">Chapter 2</a> mein hai." },
        { k: "trap", t: "Tension aur torsion ke angles ulte hote hain: ductile — tension 45°, torsion 90°; brittle — tension 90°, torsion 45°. Ek table yaad karke dono ko same maan lena sabse common MCQ galti hai." },
        { k: "real", t: "Concrete cube test mein bhi brittle-compression pattern dikhta hai — sahi failure mein cube ke sides inclined cracks se toot kar 'double pyramid' shape chhodte hain. (General Engineering Knowledge.)" },
      ],
    },

    /* ---------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Properties of materials, energy, fatigue and failure (M p.48–61)",
      hi: "पुनरावृत्ति — गुण, ऊर्जा, थकान और विफलता",
      blocks: [
        { k: "h", t: "✅ Key points — M p.48–61" },
        { k: "list", items: [
          "✅ Plastic strain ≥ 5% → ductile (mild steel); &lt; 5% → brittle (cast iron, concrete, glass, chalk). Bar 100 mm, +7 mm, 5 mm recovered: ε = 7%, ε<sub>E</sub> = 5%, ε<sub>p</sub> = 2% (M p.48)",
          "✅ Brittle: fracture point = ultimate point. Ductile materials are generally tough; brittle materials are hard (M p.48)",
          "✅ Malleability = conversion into thin sheets (continuous deformation under compression); lead is malleable but not ductile (M p.49)",
          "✅ Creep (cold flow) = permanent deformation under sustained (static) load; time-dependent; rate depends on type and magnitude of load, time/age of loading, temperature; moderate creep in concrete reduces tensile stress and cracking (M p.49–50)",
          "✅ Hardness = resistance to localised plastic deformation; scratch (Mohs 1–10, sclerometer), indentation (Rockwell, Brinell, Vickers, Shore durometer), rebound (scleroscope; Leeb, Bennett) (M p.50–51)",
          "✅ Brinell ball = 10 mm steel; BHN of mild steel = 120; Shore durometer for polymers/rubber (M p.50)",
          "✅ Tenacity = resistance to fracture under tensile load; elasticity = regaining original shape and size; ideal elastic material (ε<sub>p</sub> = 0) never exists; rubber is non-linear elastic (M p.51–52)",
          "✅ WD = ∫P·ds; linear ½Ps, plastic Ps, elasto-plastic P(s₁/2 + s₂); 1 N·m = 1 J; strain energy = work done = area under load–deflection curve (M p.52)",
          "✅ Resilience = strain energy up to elastic limit = U = P²L/2AE; U ∝ P², U ∝ L, U ∝ 1/AE (M p.53)",
          "✅ Q.1: P doubled, L halved → U₂ = 2U₁ = 4 kN·m (100% increase) (M p.53–54)",
          "✅ Q.2: equal strain energy, Es = 200, Eal = 80 GPa → L<sub>A</sub>/L<sub>B</sub> = (5/2)(D<sub>A</sub>/D<sub>B</sub>)² (M p.54)",
          "✅ Proof stress by 0.2% offset; proof resilience P.R = σ<sub>p</sub>²/2E (per unit volume as written in the notes) (M p.55)",
          "✅ MOR = ½σε = (E/2)ε² = σ²/2E; strain energy is a quadratic function of strain (M p.56)",
          "✅ Toughness = total area under load–deflection curve up to fracture = recoverable + non-recoverable energy; mild steel tougher than HYSD (M p.57)",
          "✅ MOT = ((σ<sub>u</sub> + σ<sub>y</sub>)/2)·ε<sub>f</sub> (M p.58)",
          "✅ Charpy = three-point bending, notch toughness; Izod = cantilever (M p.58)",
          "✅ Units: resilience/toughness N·m = J, M L² T⁻²; MOR/P.R/MOT J/m³, M L⁻¹ T⁻² (M p.59)",
          "✅ Fatigue: initiation life + propagation life; fracture shows rough and smooth areas, no plastic deformation, conchoidal marks (M p.59)",
          "✅ Factors: loading conditions, frequency, corrosion, temperature, stress concentration (M p.60)",
          "✅ Endurance limit &lt; proportional limit &lt; elastic limit; endurance limit ≈ 0.35–0.60 of tensile strength (notes write %); mild steel 186 MPa (M p.60–61)",
          "✅ Ductile: tension cup-and-cone @45°, compression bulging @90°, torsion @90°; brittle: tension @90° smooth, compression @45° shear, torsion helicoidal @45° (M p.61)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
