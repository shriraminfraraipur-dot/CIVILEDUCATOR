/* ============================================================
   IRRIGATION ENGINEERING AND WATER RESOURCES — Chapters 16–17
   Cross-Drainage Works (sourced from a secondary, condensed
   transcript, cited as W p.N) · Formula Sheet — a compact,
   cited revision of the handbook's most-used equations
   Primary source: handwritten class notes (236 pp, Jaspal Sir),
   cited as p.N. Secondary source: a separate, independent
   "Irrigation and Water Resources" notes set (15 pp), cited as W p.N
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "irr");
  if (!hb) { console.error("[irr7] handbook irr not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 16 */
    {
      id: "irr-16",
      n: 16,
      title: "Cross-Drainage Works",
      hi: "क्रॉस-ड्रेनेज कार्य",
      blurb: "What a cross-drainage work is and why a canal needs one; the four standard types — aqueduct, syphon aqueduct, super passage and canal syphon — distinguished purely by which stream (canal or drainage) sits above and which one is forced into pressure flow; and a clearly-labelled general-engineering box on typical selection criteria. This chapter is sourced entirely from a separate, shorter, more condensed transcript than the rest of this handbook — the primary 236-page source never reaches this topic.",
      mins: 13,
      sections: [
        {
          n: "16.1",
          title: "A note on this chapter's source",
          hi: "इस अध्याय के स्रोत पर एक टिप्पणी",
          blocks: [
            { k: "note", t: "<b>Handled honestly, as the project's sourcing rule requires:</b> every other chapter in this handbook (Chapters 1–15) is built from a single 236-page transcript of handwritten class notes, cited throughout as <b>(p.N)</b>. That transcript does not cover cross-drainage works anywhere in its 236 pages. This chapter instead draws entirely on a <b>second, independent, much shorter and more condensed</b> \"Irrigation and Water Resources\" notes set (15 pages total), cited here as <b>(W p.N)</b> to keep the two sources clearly distinct. Where that source gives only a brief, one-line definition rather than a full design derivation, this chapter presents exactly that — a brief definition — rather than inventing a derivation that isn't in the source. A separately labelled <b>General Engineering Knowledge</b> box in section 16.3 adds standard textbook selection criteria to help students, but it is not claimed as coming from either transcript." },
            { k: "h", t: "📘 Notes — W p.7, p.15" },
            { k: "def", term: "Cross-drainage work", t: "A structure constructed at the point where an irrigation canal <b>crosses</b> a natural drainage line (a stream or torrent) — built so that the canal's water and the drainage's water can pass each other without mixing. (W p.15)" },
            { k: "p", t: "As already covered in Chapter 6 (Canal alignment), whether a canal meets natural drainage at all depends on how it is aligned: a <b>watershed/ridge canal</b> sits on the line drainage flows <i>away</i> from, and a <b>side-slope canal</b> runs <i>parallel</i> to the natural drainage — neither ever crosses a drainage line, so neither needs a cross-drainage work. A <b>contour canal</b>, by contrast, deliberately cuts <i>across</i> the natural fall of the land to hold a level line, so it is forced to cross every drainage line in its path at (roughly) right angles — this is exactly why canal alignment along a watershed is preferred wherever possible, and why cross-drainage works are called a necessary evil of contour alignment. (p.71–72, W p.7)" },
            { k: "p", t: "Canal alignment itself is also chosen, wherever there is a choice, specifically <b>to keep the number of cross-drainage works to a minimum</b> — each one is an expensive masonry/concrete structure, so the alignment that crosses the fewest natural drains is preferred even if it is not the shortest route. (W p.7)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Every cross-drainage work solves the same basic problem — two flowing streams (the canal and the natural drainage) need to occupy the same point in plan, at two different levels — and the four standard types in section 16.2 are simply the four ways the relative bed/water levels of the two streams can work out. Once you know which stream is physically higher and whether the lower stream has enough headroom to flow freely (open channel) or gets forced into pressure flow (a siphon barrel), you can name the structure without memorising four separate definitions." },
          ],
        },
        {
          n: "16.2",
          title: "The four types of cross-drainage works",
          hi: "क्रॉस-ड्रेनेज कार्यों के चार प्रकार",
          blocks: [
            { k: "h", t: "📘 Notes — W p.15" },
            { k: "p", t: "In every case below, one of the two streams (canal or drainage) is carried physically <b>above</b> the other, in a trough/flume, while the other passes <b>below</b> it. Which one ends up above, and whether the lower one flows freely or under pressure, is decided purely by the relative bed/water levels stated in the source. (W p.15)" },
            { k: "def", term: "a) Aqueduct", t: "The canal is carried above, in an open trough; the drainage passes below, in its own open channel. Condition: the <b>bed level of the canal is higher than the H.F.L. (highest flood level) of the drainage</b> — there is enough headroom for the drainage to flow freely, unobstructed, underneath the canal trough. (W p.15)" },
            { k: "def", term: "b) Syphon aqueduct", t: "The canal is still carried above, in a trough, exactly as in an aqueduct — but now the <b>bed level of the canal is below the H.F.L. of the drainage</b>. There is not enough headroom left for the drainage to flow freely under the canal trough during high flood, so the drainage is forced to flow through closed barrels <b>under pressure</b> (i.e. as a syphon) beneath the canal. (W p.15)" },
            { k: "def", term: "c) Super passage", t: "The exact reverse of an aqueduct: the <b>drainage</b> is carried above, in a trough, and the <b>canal</b> passes below, in its own open channel. Condition: the <b>bed level of the drainage is higher than the F.S.L. (full supply level) of the canal</b> — there is enough headroom for the canal to flow freely, unobstructed, underneath the drainage trough. (W p.15)" },
            { k: "def", term: "d) Canal syphon", t: "The exact reverse of a syphon aqueduct: the <b>drainage</b> is carried above, in a trough, exactly as in a super passage — but now the <b>bed level of the drainage is below the F.S.L. of the canal</b>. There is not enough headroom left for the canal to flow freely under the drainage trough, so the <b>canal</b> is forced to flow through closed barrels under pressure (i.e. as a syphon) beneath the drainage. (W p.15)" },
            { k: "cmp", t: "The four types at a glance (W p.15)", cols: ["Carried above (trough)", "Passes below", "Governing condition", "Flow condition of the lower stream"], rows: [
              ["Aqueduct", "Canal", "Drainage", "Canal bed level &gt; drainage H.F.L.", "Drainage flows free (open channel)"],
              ["Syphon aqueduct", "Canal", "Drainage", "Canal bed level &lt; drainage H.F.L.", "Drainage flows under pressure (syphon barrels)"],
              ["Super passage", "Drainage", "Canal", "Drainage bed level &gt; canal F.S.L.", "Canal flows free (open channel)"],
              ["Canal syphon", "Drainage", "Canal", "Drainage bed level &lt; canal F.S.L.", "Canal flows under pressure (syphon barrels)"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Pair them up two at a time. <b>Aqueduct ↔ syphon aqueduct</b> are the same structure (canal always on top) — the only difference is whether the drainage below has enough headroom to stay open (aqueduct) or gets squeezed into pressure flow (syphon aqueduct). <b>Super passage ↔ canal syphon</b> are the mirror image (drainage always on top) — same distinction, roles swapped: the canal below either stays open (super passage) or gets squeezed into pressure flow (canal syphon). So really there are only two structural arrangements (canal-over-drainage, or drainage-over-canal), and within each arrangement the lower stream is either free-flowing or pressurised depending on the headroom actually available." },
            { k: "trap", t: "Do not let the name mislead you: in a <b>syphon aqueduct</b> it is the <b>drainage</b> that is siphoned (put under pressure), not the canal — the canal is still carried above in an open trough exactly as in a plain aqueduct. Symmetrically, in a <b>canal syphon</b> it is the <b>canal</b> that is siphoned, while the drainage sits above in an open trough exactly as in a super passage. The word before \"syphon\"/\"aqueduct\" names which stream is on top, not which one is under pressure — that has to be worked out from the bed-level condition. (W p.15)" },
          ],
        },
        {
          n: "16.3",
          title: "General Engineering Knowledge — typical selection criteria",
          hi: "सामान्य अभियांत्रिकी ज्ञान — विशिष्ट चयन मानदंड",
          blocks: [
            { k: "note", t: "<b>Everything in this section is General Engineering Knowledge, not sourced from either transcript used in this handbook.</b> Neither the 236-page primary source nor the 15-page secondary source (W) used for this chapter gives a worked design procedure, waterway/discharge formulas, or numeric selection criteria for cross-drainage works. The points below are standard textbook practice, included separately here — clearly labelled as such — because they help explain <i>why</i> a designer would pick one of the four types from section 16.2 over another. Treat this section as background, not as an examinable result cited to either source." },
            { k: "list", items: [
              "<b>Aqueduct</b> is preferred whenever the natural ground levels allow it — the drainage stays a simple open channel needing no pressure design, and the structure (a canal trough on piers, much like a small bridge/flume) is comparatively straightforward and economical.",
              "<b>Syphon aqueduct</b> becomes necessary when the canal's design bed level cannot be raised further (it is fixed by the command area it must irrigate by gravity, well upstream and downstream of the crossing) while the drainage's H.F.L. is high — typically a large monsoon-fed drainage crossing a canal that must stay at a low, fixed level. The drainage barrels then have to be designed for pressure flow at the design flood discharge, with head loss, entry/exit transitions and scour protection all becoming part of the design, unlike the free-flow aqueduct case.",
              "<b>Super passage</b> is typical where a large natural drainage (which cannot practically be lowered or diverted) must cross a comparatively small canal or minor whose F.S.L. is low — the drainage is simply carried over the canal in its own trough, and the canal below continues to flow as an ordinary open channel.",
              "<b>Canal syphon</b> is the least common of the four in practice — it arises when a small drainage must be carried over a canal that itself runs at a relatively high F.S.L., forcing the canal (not the drainage) into pressure flow through barrels; because the canal is the department's own controlled structure, designers usually prefer to avoid this arrangement where an alternative alignment exists.",
              "In every pressurised case (syphon aqueduct or canal syphon), the barrels are sized to keep velocities within a safe non-scouring, non-silting range for the design discharge — the same regime-channel thinking behind Kennedy's and Lacey's theories (Chapter 7) applies qualitatively to sizing a syphon barrel's waterway, though the barrel itself is a closed pressure conduit, not an open regime channel.",
              "Approach and departure transitions (wingwalls, splayed inlet/outlet) are provided on both the canal and the drainage sides of any cross-drainage work to avoid sudden changes in velocity that would cause scour or silting immediately upstream/downstream of the structure.",
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice that the choice between the four types is not really a free design decision — it falls out almost entirely from levels that are already fixed by other constraints: the canal's F.S.L. is fixed by the command area it serves, and the drainage's H.F.L. is fixed by its catchment and flood hydrology. The designer's job at a cross-drainage crossing is mostly to correctly identify which of the four level-relationships in section 16.2 actually holds at that specific site, and design the corresponding structure — not to freely choose among them." },
          ],
        },
        {
          n: "16.4",
          title: "Quick revision — cross-drainage works",
          hi: "त्वरित पुनरावृत्ति — क्रॉस-ड्रेनेज कार्य",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "This chapter is sourced entirely from a separate, shorter secondary transcript (cited W p.N) — the primary 236-page source used elsewhere in this handbook never covers cross-drainage works (W p.15).",
              "Cross-drainage work = structure built where a canal crosses a natural drainage line; needed only for contour-canal alignment, since watershed and side-slope canals never cross drainage (p.71–72, W p.7).",
              "Aqueduct: canal above (open), drainage below (open) — canal bed level &gt; drainage H.F.L. (W p.15).",
              "Syphon aqueduct: canal above (open), drainage below under pressure — canal bed level &lt; drainage H.F.L. (W p.15).",
              "Super passage: drainage above (open), canal below (open) — drainage bed level &gt; canal F.S.L. (W p.15).",
              "Canal syphon: drainage above (open), canal below under pressure — drainage bed level &lt; canal F.S.L. (W p.15).",
              "Section 16.3's selection criteria are General Engineering Knowledge, not from either transcript — treat them as background, not a cited result.",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "There are really only two structural arrangements (canal-over-drainage, or drainage-over-canal); within each, the lower stream is either free-flowing or pressurised depending on available headroom — that single distinction generates all four named types.",
              "\"Syphon\" in the name always refers to the stream passing <i>underneath</i> the trough, not the one carried above it.",
              "Where this chapter's source gives only a one-line definition rather than a full design method, that is presented honestly as a one-line definition — no formula or derivation has been invented to fill the gap.",
            ] },
          ],
        },
      ],
    },

    /* ============================================================ CH 17 */
    {
      id: "irr-17",
      n: 17,
      title: "Formula Sheet — Irrigation Engineering",
      hi: "सूत्र पत्रक — सिंचाई इंजीनियरिंग",
      blurb: "A single compact revision chapter pulling together this handbook's most-used equations, organised by topic and cited back to the chapter/page each one was derived in: crop water requirement (Δ/D/B), the five irrigation efficiencies and CIR/NIR/FIR, Kennedy's and Lacey's design equations, canal lining geometry and the benefit–cost ratio, gravity-dam Bmin for each failure mode, Bligh's/Lane's/Khosla's seepage formulas, leaching requirement and tile-drain spacing, and canal-outlet flexibility/sensitivity — plus a short note on the one genuine numeric conflict found between this handbook's two source transcripts.",
      mins: 24,
      sections: [
        {
          n: "17.1",
          title: "Crop water requirement — Δ, D, B and the efficiency chain",
          hi: "फसल जल आवश्यकता — Δ, D, B और दक्षता श्रृंखला",
          blocks: [
            { k: "h", t: "📘 Every line below is a result already derived and cited earlier in this handbook, unless marked otherwise" },
            { k: "eq", expr: "86400B = D.Delta  (m3/cumec)   ⇒   D = 8.64B/Delta (hectare/cumec)   ⇒   Delta = 8.64B/D (m) = 864B/D (cm)        (irr-3, p.30–31)", where: [
              ["D", "duty of the crop, hectare/cumec"], ["Delta", "delta of the crop, depth of water for its full growth"], ["B", "base period, days"],
            ] },
            { k: "eq", expr: "Efficiency of conveyance:      ηc = Vf/Vi × 100        (irr-4, p.40–41)\nEfficiency of application:     ηa = VRZ/Vf × 100       (irr-4, p.41)\nEfficiency of storage:         ηs = VRZ/VRRZ × 100     (irr-4, p.41)\nEfficiency of water use:       ηu = Vu/Vf × 100        (irr-4, p.41) — ⚠ see 17.9, W's source defines this ratio differently\nEfficiency of distribution:    ηd = (1 − d/D) × 100    (irr-4, p.42)", where: [
              ["Vi", "water entering the main channel at its start"], ["Vf", "water delivered into the field at the outlet"],
              ["VRZ", "water stored in the root zone"], ["VRRZ", "water required in the root zone prior to irrigation"],
              ["Vu", "water beneficially used by the crop (incl. leaching)"], ["D, d", "mean stored depth, and the average absolute deviation from it"],
            ] },
            { k: "eq", expr: "CIR = Cu − Re\nNIR = CIR + Leaching requirement = Cu − Re + Leaching requirement\nFIR = NIR + Runoff loss in the field        (irr-4, p.49)", where: [["Cu", "consumptive use (≈ evapotranspiration, ET)"], ["Re", "effective/useful rainfall"]] },
            { k: "eq", expr: "Empirical effective rainfall:  Re = 0.8R − 0.25 mm (R > 75 mm/month)  ;  Re = 0.6R − 10 mm (R < 75 mm/month)        (irr-4, p.48)" },
            { k: "eq", expr: "Blaney-Criddle:  Cu = (KP/40)(1.8t+32) [t in °C]  =  KPt/40 [t in °F]        (irr-4, p.51)\nHargreaves Class-A Pan:  Cu = K × Ep        (irr-4, p.54–55)", where: [["K", "crop factor / consumptive-use coefficient"], ["P", "% of annual daylight hours in the period"], ["Ep", "Class-A pan evaporation"]] },
            { k: "eq", expr: "Leaching requirement:  LR = D_d/D_i = (D_i − Cu)/D_i = EC_i/EC_d        (p.189–190, this chapter's transcript — see note)", where: [
              ["D_d", "depth of water drained out per unit area"], ["D_i", "depth of irrigation water applied per unit area"],
              ["EC_i, EC_d", "electrical conductivity of the irrigation water and of the drained-out water"],
            ] },
            { k: "note", t: "The leaching-requirement formula above is drawn directly from the primary 236-page transcript (p.189–190) — the same source used for Chapters 1–15 — even though it has not yet been written up as its own handbook section; it is included here because it is one of the formula-sheet topics this chapter is specifically asked to collect. It is cited by transcript page exactly as every other primary-source formula in this handbook is." },
          ],
        },
        {
          n: "17.2",
          title: "Kennedy's and Lacey's regime-channel design equations",
          hi: "कैनेडी और लेसी के रेजीम-चैनल डिज़ाइन समीकरण",
          blocks: [
            { k: "eq", expr: "Kennedy's critical velocity:  V0 = 0.55 m y^0.64        (irr-7, p.88)", where: [["m", "critical velocity ratio (C.V.R.), by silt type"], ["y", "depth of flow"]] },
            { k: "eq", expr: "Kutter's C (used with Chezy V = C√(RS) to check Kennedy's design):\nC = [(1/N) + 23 + 0.00155/S] / [1 + {23 + 0.00155/S}(N/√R)]        (irr-7, p.88–89)" },
            { k: "eq", expr: "Lacey's three basic equations:\n(I)  V = √(2/5)·√(FR)\n(II) A F² = 140 V⁵\n(III) V = 10.8 R^(2/3) S^(1/3)        (irr-7, p.98)", where: [["F", "silt factor = 1.76√d50"], ["R", "hydraulic mean depth"], ["A", "area"], ["S", "bed slope"]] },
            { k: "eq", expr: "Lacey's derived design equations:\nP = 4.75√φ        (wetted perimeter)\nV = (φF²/140)^(1/6)        (velocity)\nR = (5/2)(V²/F)        (hydraulic mean depth)\nS = F^(5/3)/(3340 φ^(1/6))        (bed slope)        (irr-7, p.98–99)", where: [["φ", "discharge, cumec"]] },
            { k: "eq", expr: "Scour depth (Lacey):  Rs = 0.481 (φ/F)^(1/3) = 1.357 q^(2/3)/F^(1/3) , with φ = 22.46 q²        (irr-7, p.101–102) — ⚠ see 17.9, W's source gives a different leading constant" },
            { k: "eq", expr: "Empirical canal-loss formula:  Δφ = (1/200)(B+d)^(2/3)  [cumec/km]        (irr-7, p.86)" },
          ],
        },
        {
          n: "17.3",
          title: "Canal lining — geometry and the benefit–cost ratio",
          hi: "नहर अस्तर — ज्यामिति और लाभ-लागत अनुपात",
          blocks: [
            { k: "eq", expr: "Triangular lined section (IS:10430):\nA = y²(θ + cotθ)      P = 2y(θ + cotθ)      R = A/P = y/2        (irr-8, p.108)" },
            { k: "eq", expr: "Trapezoidal lined section (IS:10430):\nA = y[B + y·cotθ + y·θ]      P = B + 2y·cotθ + y·θ      R = A/P        (irr-8, p.109)", where: [["θ", "side-slope angle from the vertical, in radians"], ["B", "bed width"], ["y", "depth of flow"]] },
            { k: "eq", expr: "Benefit–Cost ratio of lining:\nB/C = (x·R1 + y·R2) / [C/n + Cr/(2×100)]        (irr-8, p.104–105)", where: [
              ["x", "cumec of seepage saved by lining"], ["R1", "revenue rate, Rs/cumec"],
              ["R2", "maintenance cost of the unlined canal"], ["y", "% of R2 saved by lining"],
              ["C", "capital cost of lining"], ["n", "life of the lining, years"], ["r", "rate of interest, %"],
            ] },
          ],
        },
        {
          n: "17.4",
          title: "Gravity-dam stability — Bmin for each mode of failure",
          hi: "गुरुत्व बांध स्थिरता — प्रत्येक विफलता प्रकार हेतु Bmin",
          blocks: [
            { k: "note", t: "The formulas below are for the <b>elementary profile</b> of a gravity dam — a right-angled triangle, zero width at the water surface, base width B at the bottom, subjected only to self-weight (W), the u/s hydrostatic water pressure (P) and uplift (u), with uc = specific gravity of the dam material relative to water and C = the uplift/seepage coefficient (C = 1 if uplift is considered, C = 0 if not). Drawn from the primary transcript, p.147–151 (formally part of a gravity-dams chapter not yet written up on its own in this handbook, cited by page exactly as every other primary-source formula here is)." },
            { k: "eq", expr: "P = ½γwH²        W = ½BH·uc·γw        u = ½BC·γwH        (p.147)" },
            { k: "eq", expr: "(i) No overturning:  B ≥ H/√[2(uc−C)]   ⇒   Bmin(OT) = H/√(2uc)  [C = 0]        (p.148)" },
            { k: "eq", expr: "(ii) No tension (e ≤ B/6, the middle-third rule):  B ≥ H/√(uc−C)   ⇒   Bmin(T) = H/√uc  [C = 0]        (p.148–149)" },
            { k: "eq", expr: "(iii) No sliding:  B ≥ H/[μ(uc−C)]   ⇒   Bmin(sliding) = H/(μ·uc)  [C = 0]        (p.149)", where: [["μ", "coefficient of friction between dam and foundation, typically 0.65–0.75"]] },
            { k: "eq", expr: "(iv) No compression/crushing failure (limiting height, not a Bmin):\nσ = γwH(uc−C+1) ≤ f   ⇒   H ≤ f/[γw(uc−C+1)]        (p.150–151)", where: [["f", "max. permissible compressive stress of the dam material"]] },
            { k: "eq", expr: "Worked check, uc = 2.5, μ = 0.7:  Bmin(OT) = 0.44H  ;  Bmin(T) = 0.632H  ;  Bmin(sliding) = 0.571H — the tension (middle-third) criterion governs, being the largest of the three        (p.149)" },
            { k: "eq", expr: "Foundation shear stress at toe (principal-stress check):\nσ = Pv·sec²α − p'·tan²α      z(toe) = (Pv − p')tanα        (p.141–142)", where: [["α", "angle the d/s face makes with the vertical"], ["Pv", "vertical stress at the toe = (ΣV/B)(1+6e/B)"], ["p'", "d/s (tailwater) hydrostatic pressure"]] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "This is the exact same e ≤ B/6 \"middle-third\" idea already derived independently in the Strength of Materials handbook's Chapter 7 (core of a rectangular section applied to a dam base) — two different subjects arriving at the identical governing inequality, because a dam base carrying an eccentric vertical resultant is, structurally, exactly a rectangular section under eccentric direct load. Note also that the worked check above (uc = 2.5) confirms this handbook's own general finding: the no-tension criterion needs the largest base width of the three, so it is normally the one that governs a gravity dam's minimum base — not overturning, and not sliding." },
          ],
        },
        {
          n: "17.5",
          title: "Bligh's, Lane's and Khosla's seepage theories",
          hi: "ब्लिघ, लेन और खोसला के रिसाव सिद्धांत",
          blocks: [
            { k: "note", t: "Drawn from the primary transcript, p.163–181 (formally part of a weir/barrage-design chapter not yet written up on its own in this handbook, cited by page as usual)." },
            { k: "eq", expr: "Bligh's creep theory:\nL = 2d1 + b1 + 2d2 + b2 + 2d3        (creep length, sum of vertical creep ×2 plus horizontal runs)\nTo prevent piping:  H/L ≤ 1/C        (C = Bligh's creep coefficient, by soil type)        (p.164–165)" },
            { k: "eq", expr: "To prevent uplift failure of the floor:  t ≥ h/(Gc−1)  ;  design thickness t = (4/3)·h/(Gc−1)        (p.166)", where: [["h", "residual seepage head at the point"], ["Gc", "specific gravity of the floor material"]] },
            { k: "eq", expr: "Lane's weighted creep theory:\nLe = 1·Lv + (1/3)Lh        (weighted creep length; vertical weighted 1, horizontal weighted 1/3)\nTo prevent piping:  H/Le ≤ 1/Cw        (Cw = Lane's weighted creep coefficient)        (p.168–169)" },
            { k: "eq", expr: "Khosla's critical/safe exit gradient:\nic = (G−1)/(1+e)   [critical, no piping]   ;   FoS against piping = ic/i, kept 4–5        (p.171)\ni_exit = (H/d)·1/(π√λ)   ,   λ = (1+√(1+α²))/2   ,   α = b/d        (p.172)", where: [["G, e", "specific gravity and void ratio of the soil"], ["H", "total seepage head"], ["b", "total horizontal length of floor"], ["d", "depth of the d/s sheet pile"]] },
            { k: "eq", expr: "Khosla's residual seepage potential at key points of a simple profile:\nφE = (1/π)cos⁻¹[(λ−2)/λ]      φD = (1/π)cos⁻¹[(λ−1)/λ]      φC + φE = 100      φD1 + φD = 100        (p.173–175)" },
            { k: "eq", expr: "Correction for mutual interference of piles:\nC = 19√(D/b') × [(d+D)/b]  (% of head; +ve for points in the rear, −ve for points forward)        (p.175–176)", where: [["D", "depth of the influencing pile, below the level considered"], ["b'", "clear distance between the two piles"], ["d", "depth of the pile whose correction is being found"], ["b", "total floor length"]] },
          ],
        },
        {
          n: "17.6",
          title: "Leaching requirement, tile-drain spacing and canal-outlet flexibility",
          hi: "लीचिंग आवश्यकता, टाइल-ड्रेन स्पेसिंग और नहर-आउटलेट लचीलापन",
          blocks: [
            { k: "note", t: "Drawn from the primary transcript, p.189–190 (leaching) and p.196–198 (tile drains) and p.229–234 (canal outlets) — all formally part of chapters not yet written up on their own in this handbook, cited by page as usual." },
            { k: "eq", expr: "Leaching requirement:  LR = D_d/D_i = (D_i − Cu)/D_i = ECi/ECd        (p.189–190)   [repeated from 17.1 for completeness]" },
            { k: "eq", expr: "Tile-drain spacing:  S = (4K/q)(b² − a²)        (p.196–198)", where: [
              ["S", "spacing between drains"], ["K", "hydraulic conductivity of the soil"],
              ["q", "discharge to be carried, per unit length of drain (≈ 1% of avg. annual rainfall, drained in 24 hr — the drainage coefficient)"],
              ["a", "depth of the drain centre above the impervious stratum"], ["b", "max. height of the drawn-down water table above the impervious stratum, midway between drains"],
            ] },
            { k: "eq", expr: "Canal-outlet flexibility:  F = (dq/q)/(dφ/φ) = (m/n)(y/H)        (p.232)", where: [
              ["q, φ", "discharge through the outlet, and through the distributary channel (q = CH^m, φ = Ky^n)"],
              ["H, y", "head on the outlet, and depth of flow in the distributary"],
            ] },
            { k: "eq", expr: "Setting (for a proportional outlet, F = 1):  S = H/y = m/n = outlet index / channel index        (p.232–233)\nHypo-proportional: F > 1 (setting < m/n)  ;  Sub-proportional: F < 1 (setting > m/n)        (p.233)" },
            { k: "eq", expr: "Sensitivity:  Sens = (dq/q)/(dy/y)   ;   F = (1/n)·Sens        (p.233–234)" },
          ],
        },
        {
          n: "17.7",
          title: "Cross-drainage works — one-line recap",
          hi: "क्रॉस-ड्रेनेज कार्य — एक-पंक्ति पुनरावृत्ति",
          blocks: [
            { k: "list", items: [
              "<b>Aqueduct</b> — canal above (open), drainage below (open); canal bed level &gt; drainage H.F.L. (Ch.16, W p.15).",
              "<b>Syphon aqueduct</b> — canal above (open), drainage below under pressure; canal bed level &lt; drainage H.F.L. (Ch.16, W p.15).",
              "<b>Super passage</b> — drainage above (open), canal below (open); drainage bed level &gt; canal F.S.L. (Ch.16, W p.15).",
              "<b>Canal syphon</b> — drainage above (open), canal below under pressure; drainage bed level &lt; canal F.S.L. (Ch.16, W p.15).",
            ] },
          ],
        },
        {
          n: "17.8",
          title: "⚠️ Where this handbook's two source transcripts disagree",
          hi: "⚠️ जहाँ दोनों स्रोत ट्रांसक्रिप्ट असहमत हैं",
          blocks: [
            { k: "h", t: "Genuine numeric/definitional conflicts found while cross-checking the secondary (W) transcript against the primary transcript already used in Chapters 1–15" },
            { k: "list", items: [
              "<b>Lacey's scour-depth constant:</b> the primary transcript derives <b>Rs = 0.481 (φ/F)^(1/3)</b> from its own algebra (irr-7, p.101–102), while the secondary transcript states <b>Scour depth = 0.47 (Q/f)^(1/3)</b> (W p.10) — the same formula, but with a different leading constant (0.481 vs 0.47). Both are reproduced honestly rather than silently reconciled to one value; a design problem should state which constant it expects, and 0.473 is the value most commonly published in standard textbooks/IS 7784, close to but not identical to either transcript's figure.",
              "<b>\"Efficiency of water use\" (ηu) is defined two different ways:</b> the primary transcript (irr-4, p.41) defines it as <b>ηu = Vu/Vf</b> — beneficial use (including leaching) divided by the water delivered <i>to the field</i>. The secondary transcript's very first line (W p.1) instead calls the ratio of water actually utilised by the crop to the water delivered <i>from the source</i> the \"Irrigation Efficiency\" and separately labels it (ηu) — i.e. <b>Wu/Ws</b>, not Wu/(water at the field). These are genuinely different ratios (one has the source-to-field conveyance losses baked in, the other does not) that happen to share a name and a symbol across the two note sets. When using \"water-use efficiency\" from either source, check which denominator (field delivery, or original source delivery) that source intends.",
              "Everywhere else the two transcripts were checked against each other for this chapter — Kennedy's critical-velocity exponent and constant (0.55, y^0.64), Lacey's wetted-perimeter and velocity equations (P = 4.75√φ, V = (φF²/140)^(1/6)), the silt factor F = 1.76√d50 vs W's f = 1.76√m, the canal-alignment/cross-drainage relationship, and the Δ = 8.64B/D duty–delta relation — the two sources <b>agree</b>, so no further conflict note is raised for those (per the project rule that a difference is flagged only when it is genuinely found, not manufactured for completeness).",
            ] },
          ],
        },
        {
          n: "17.9",
          title: "Quick revision — formula-sheet checklist",
          hi: "त्वरित पुनरावृत्ति — सूत्र-पत्रक जाँच सूची",
          blocks: [
            { k: "h", t: "✅ Checklist" },
            { k: "list", items: [
              "Δ = 8.64B/D (m); the five efficiencies ηc, ηa, ηs, ηu, ηd; CIR → NIR → FIR chain; Blaney-Criddle and Hargreaves Cu; leaching requirement LR = (Di−Cu)/Di (17.1).",
              "Kennedy V0 = 0.55 m y^0.64; Lacey's three basic equations and the derived P, V, R, S; scour depth Rs = 0.481(φ/F)^(1/3) — ⚠ conflicts with W's 0.47 (17.2, 17.8).",
              "Triangular lined section R = y/2; trapezoidal A, P, R; benefit–cost ratio of lining (17.3).",
              "Gravity-dam Bmin: overturning H/√(2uc), tension (middle-third) H/√uc, sliding H/(μ·uc) — tension usually governs (17.4).",
              "Bligh H/L ≤ 1/C; Lane Le = Lv + Lh/3, H/Le ≤ 1/Cw; Khosla ic = (G−1)/(1+e), i_exit = (H/d)(1/π√λ), pile-interference correction C = 19√(D/b')[(d+D)/b] (17.5).",
              "Tile-drain spacing S = (4K/q)(b²−a²); outlet flexibility F = (m/n)(y/H), setting S = H/y = m/n, sensitivity relation F = (1/n)·Sens (17.6).",
              "Cross-drainage works: aqueduct/syphon aqueduct (canal above) vs super passage/canal syphon (drainage above), each pair split by whether the lower stream is free or pressurised (17.7, Chapter 16).",
              "Two genuine cross-source conflicts found and flagged, not silently resolved: the scour-depth constant, and the denominator used for \"efficiency of water use\" (17.8).",
            ] },
            { k: "h", t: "🔑 Key takeaways" },
            { k: "list", items: [
              "Almost every \"stability\" or \"no-failure\" condition in this handbook — the dam's e ≤ B/6, the outlet's F = 1 setting, Khosla's i ≤ ic — reduces to the same kind of inequality: keep some computed quantity below (or above) a single critical threshold value.",
              "Where a formula-sheet topic (gravity dams, Bligh/Lane/Khosla, leaching, tile drains, outlets) has not yet been written up as its own chapter in this handbook, every equation above is still cited straight back to its page in the same primary transcript used throughout Chapters 1–15 — nothing here is invented or approximated from memory.",
              "When the two source transcripts genuinely disagree (17.8), both values are kept and flagged rather than one being silently chosen — check the specific exam/reference the number is needed for.",
            ] },
          ],
        },
      ],
    },
  );
})();
