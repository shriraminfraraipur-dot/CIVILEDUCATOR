/* ============================================================
   CIVIL EDUCATOR — HANDBOOK: DESIGN OF STEEL STRUCTURES
   Chapter 11 — Column Bases, Trusses and Industrial Buildings
   Chapter 12 — Gantry Girders, Fatigue and Fabrication

   Clause numbers and headings are navigation. Every explanation,
   derivation and worked example is written for this app; the
   code's own text is never reproduced.
   ============================================================ */

(function () {
  var hb = (window.DB && DB.handbooks || []).find(function (h) { return h.id === "st"; });
  if (!hb) return;

  hb.chapters.push(

    /* =========================================================== CH 11 */
    {
      id: "st-11",
      n: 11,
      title: "Column Bases, Trusses and Industrial Buildings",
      hi: "कॉलम बेस, ट्रस और औद्योगिक भवन",
      blurb: "Getting the load into the ground, assembling members into a truss, and the bracing that stops a shed folding along its length.",
      mins: 40,
      sections: [

        {
          n: "11.1",
          title: "Column bases",
          hi: "कॉलम बेस",
          blocks: [
            { k: "p", t: "A steel column carrying 1500 kN concentrates it into a section of perhaps 7500 mm² — about 200 N/mm². Concrete can take around 9 N/mm². Something has to spread the load by a factor of more than twenty, and that is what a base plate is for." },
            { k: "dia", id: "hb-st-base", cap: "A slab base for ordinary loads; a gusseted base where the load is heavy or a moment has to be resisted." },
            { k: "def", term: "Slab base (Cl. 7.4.3.1)", t: "A single thick plate, with the column welded or bolted directly to it. The plate projects beyond the column on all sides, and each projection acts as a cantilever carrying the upward bearing pressure from the concrete. That cantilever action is what sets the thickness." },
            { k: "def", term: "Gusseted base", t: "Gusset plates and angles are added between the column and a larger base plate, spreading the load over more of the plate so that a thinner plate suffices. Used for heavy loads, and wherever the base has to resist a moment as well as an axial force." },
            { k: "eq", expr: "ts = √[ 2.5 w (a² − 0.3 b²) γm0 / fy ]   ≥  tf        (Cl. 7.4.3.1)", where: [
              ["ts", "thickness of the base plate, mm"],
              ["w", "uniform pressure under the plate from the axial load, N/mm²"],
              ["a", "the GREATER projection of the plate beyond the column, mm"],
              ["b", "the LESSER projection, mm"],
              ["tf", "flange thickness of the column — the plate is never thinner than this"],
            ]},
            { k: "p", t: "The (a² − 0.3 b²) is the two-way plate behaviour: the projection in the long direction does most of the work, and the shorter one relieves it a little, in the same way a two-way slab relieves its long span. The 2.5 and the 0.3 come from plate theory fitted to the geometry, not from anything derivable in two lines." },
            { k: "eg",
              title: "Example 11.1 — Slab base for an axially loaded column",
              given: "ISHB 300 (D = 300 mm, bf = 250 mm, tf = 10.6 mm) carrying a factored axial load of 1500 kN, bearing on an M20 concrete pedestal. E250 base plate.",
              steps: [
                { t: "Bearing capacity of the concrete", w: "Take 0.45 fck = 0.45 × 20 = 9.0 N/mm² (conservative — see the note below)" },
                { t: "Plate area required", w: "A = 1500 × 10³/9.0 = 166,667 mm²\nside = √166,667 = 408 mm  →  provide 450 × 450 mm = 202,500 mm²" },
                { t: "Actual bearing pressure", w: "w = 1500 × 10³/202,500 = 7.41 N/mm²  <  9.0  ✓" },
                { t: "Projections", w: "beyond the 250 mm flange width: (450 − 250)/2 = 100 mm\nbeyond the 300 mm depth:       (450 − 300)/2 =  75 mm\na = 100 mm (greater),  b = 75 mm (lesser)" },
                { t: "Plate thickness (Cl. 7.4.3.1)", w: "a² − 0.3 b² = 10,000 − 0.3 × 5625 = 8312.5\nts = √[2.5 × 7.41 × 8312.5 × 1.10/250]\n   = √677.3 = 26.0 mm" },
                { t: "Check the minimum", w: "ts must be at least tf = 10.6 mm  ✓\nProvide a 28 mm plate (the next standard thickness)." },
              ],
              ans: "450 × 450 × 28 mm base plate. Note that increasing the plate to 500 × 500 would reduce w but increase a, and the thickness would barely change — plate size and plate thickness trade against each other.",
            },
            { k: "note", t: "IS 800 Cl. 7.4 allows a bearing strength of <strong>0.6 fck</strong> under a base plate; IS 456 Cl. 34.4 gives 0.45 fck × √(A₁/A₂) ≤ 2 × 0.45 fck (both as summarised by <a href=\"https://ideastatica-proxy.aws.apploud.dev/support-center/check-of-concrete-block-according-to-is\" target=\"_blank\" rel=\"noopener\">IDEA StatiCa</a>). The example uses the plain 0.45 fck, which is conservative; with 0.6 fck the plate could be about 354 mm square." },
            { k: "note", t: "Holding-down bolts are a separate design. For a nominally pinned base they are detailed rather than calculated, but they still resist the uplift and the erection forces, and they have to be positioned and grouted properly. For a moment-resisting base the bolts on the tension side carry a real, calculated tension and their anchorage into the concrete is a Chapter 5 problem of the RCC handbook." },
          ],
        },

        {
          n: "11.2",
          title: "Roof trusses",
          hi: "छत के ट्रस",
          blocks: [
            { k: "p", t: "A truss spans further than a beam for the same weight, because it separates a beam's bending into pure tension and pure compression in slender members, and removes the material in between. The price is a great many connections." },
            { k: "dia", id: "hb-st-truss", cap: "Top chord in compression, bottom chord in tension, web members alternating." },
            { k: "list", items: [
              "<strong>Top chord</strong> — compression, Chapter 6. Length between panel points is the effective length in the plane of the truss; out of plane it is the purlin spacing, if the purlins restrain it.",
              "<strong>Bottom chord</strong> — tension, Chapter 5, with the connection governing as often as not.",
              "<strong>Web members</strong> — tension or compression depending on position and load case, and frequently both across different load cases.",
              "<strong>Purlins</strong> — the members spanning between trusses, carrying the roof sheeting. Usually channels or cold-formed sections, and biaxially bent because the roof is sloped.",
            ]},
            { k: "p", t: "Loads come from three codes: dead load from the sheeting and the truss itself, imposed load from IS 875 Part 2 (which permits a reduction for steeper slopes, since nobody stands on a steep roof), and wind from IS 875 Part 3 — which for a light roof is the dominant case and often acts <em>upwards</em>." },
            { k: "trap", t: "Wind uplift on a light roof commonly exceeds the dead load, and the whole truss reverses: the bottom chord goes into compression and the top chord into tension. A bottom chord sized for tension alone and unrestrained laterally will buckle. This is the single most important load case in light industrial roof design, and it is the one most often skipped in a first design." },
            { k: "eg",
              title: "Example 11.2 — Compression member in a truss",
              given: "Top chord panel, factored compression 200 kN, length between panel points 2.0 m, K = 1.0. Try two ISA 75 × 75 × 8 back to back with a 10 mm gusset between them. From the section tables, each angle has A = 1138 mm² and rxx = 22.9 mm; for the pair back to back, rmin remains 22.9 mm about the x-x axis — the axis parallel to the outstanding legs, which the gap between the angles does not stiffen.",
              steps: [
                { t: "Slenderness", w: "A = 2 × 1138 = 2276 mm²\nKL/r = 2000/22.9 = 87.3   (< 180  ✓ Cl. 3.8)" },
                { t: "Buckling class and imperfection factor", w: "Angle sections are buckling class c (Table 10)  →  α = 0.49" },
                { t: "Euler stress", w: "fcc = π² × 2 × 10⁵/87.3² = 1,973,921/7621 = 258.8 N/mm²" },
                { t: "λ, φ, χ", w: "λ = √(250/258.8) = 0.983\nφ = 0.5[1 + 0.49(0.783) + 0.966] = 1.175\nχ = 1/[1.175 + √(1.379 − 0.966)] = 1/[1.175 + 0.643] = 0.550" },
                { t: "Capacity", w: "fcd = 0.550 × 250/1.10 = 125.0 N/mm²\nPd = 2276 × 125.0 = 284,500 N = 284.5 kN\n284.5  >  200  ✓" },
              ],
              ans: "Two ISA 75 × 75 × 8 back to back carry 284.5 kN against 200 kN required. Tack the two angles together at intervals close enough that a single angle cannot buckle between the connections before the pair buckles as a unit.",
            },
          ],
        },

        {
          n: "11.3",
          title: "Industrial buildings and bracing",
          hi: "औद्योगिक भवन और ब्रेसिंग",
          blocks: [
            { k: "p", t: "A typical industrial shed is a series of identical frames — trusses on columns, or portal frames — repeated along the length of the building. Each frame is stiff in its own plane and has essentially no stiffness perpendicular to it." },
            { k: "dia", id: "hb-st-bracing", cap: "Without bracing in both planes, the shed is a mechanism along its length." },
            { k: "list", items: [
              "<strong>Roof plan bracing</strong> — diagonals in the plane of the top chords, usually in the end bays. It collects wind pressure from the gable and carries it back to the side walls.",
              "<strong>Side wall (vertical) bracing</strong> — diagonals between columns, taking that force down to the foundations.",
              "<strong>Gable end framing</strong> — posts spanning between the ground and the roof bracing, carrying the wind on the end wall.",
              "<strong>Bottom chord bracing</strong> — often needed to restrain the bottom chord against the uplift case of §11.2, where it goes into compression.",
            ]},
            { k: "p", t: "Bracing is also what stabilises every compression member's out-of-plane direction. Chapter 6 showed that halving KL quadruples the Euler stress; Chapter 8 showed that halving LLT nearly doubled a beam's moment capacity. Bracing is how those halvings are achieved, and it is nearly always cheaper than the alternative." },
            { k: "note", t: "Bracing members are usually designed as tension-only pairs — a cross of two diagonals, of which one takes the load in tension whichever way the wind blows, and the other is simply slack. That allows very slender members, which is why Table 3 permits a slenderness of 350 for a tie that can see reversal, and 400 for one that cannot." },
          ],
        },

        {
          n: "11.4",
          title: "What to carry forward",
          hi: "आगे के लिए",
          blocks: [
            { k: "list", items: [
              "A base plate spreads the column load onto concrete — IS 800 permits 0.6 fck bearing; 0.45 fck (IS 456 basis) is the conservative figure used in Example 11.1.",
              "ts = √[2.5 w(a² − 0.3b²)γm0/fy], never less than tf; a is the greater projection.",
              "A truss is Chapter 5 and Chapter 6 members joined by Chapter 3 and Chapter 4 connections.",
              "Wind uplift reverses a light roof truss — check every member in both directions.",
              "An industrial building needs bracing in the roof plane and in the walls; without it the frames are hinged along the building's length.",
              "Bracing is the cheapest way to reduce KL and LLT, which are the two quantities that cost the most.",
            ]},
            { k: "p", t: "One chapter remains — the members that carry moving loads, and the failure mode that happens at stresses this handbook has so far called perfectly safe." },
          ],
        },
      ],
    },

    /* =========================================================== CH 12 */
    {
      id: "st-12",
      n: 12,
      title: "Gantry Girders, Fatigue and Fabrication",
      hi: "गैन्ट्री गर्डर, थकान और निर्माण",
      blurb: "Moving loads, the failure that happens below yield, and the difference between a design and a structure.",
      mins: 38,
      sections: [

        {
          n: "12.1",
          title: "Gantry girders",
          hi: "गैन्ट्री गर्डर",
          blocks: [
            { k: "p", t: "A gantry girder carries the rail on which an overhead travelling crane runs. It is the hardest common beam in steel design, and it is worth seeing why, because every chapter of this handbook contributes something to it." },
            { k: "dia", id: "hb-st-crane", cap: "Three load directions, and all of them repeated tens of thousands of times." },
            { k: "list", items: [
              "<strong>Vertical wheel loads</strong>, increased by an <strong>impact factor</strong> — a crane snatches its load off the ground rather than lowering it gently onto the rail. IS 875 Part 2 gives the allowances, typically 25% for an electric overhead travelling crane.",
              "<strong>Lateral surge</strong> — as the crab starts and stops across the crane bridge, it drags the girder sideways. This puts the girder into <em>minor-axis bending as well as major</em>, and the minor axis is much weaker.",
              "<strong>Longitudinal drag</strong> — as the whole crane brakes along the rail, a force acts along the girder and into the bracing.",
              "<strong>No lateral restraint</strong> — the crane runs on the top flange, so nothing can be attached to it. LLT is the full span, and Chapter 8 applies in full.",
              "<strong>Fatigue</strong> — every lift is a load cycle, and a crane in a working shop does tens of thousands of them a year.",
            ]},
            { k: "p", t: "The usual answer to the surge is to strengthen the top flange laterally — by welding a channel over it, or by adding a horizontal lattice girder alongside. That handles the minor-axis bending and improves the LTB behaviour at the same time, which is why almost every gantry girder of any size has one." },
            { k: "trap", t: "The moving load means the maximum moment is <strong>not</strong> at mid-span and the maximum shear is not necessarily at the support. Both have to be found from an influence-line analysis of the wheel positions — the absolute maximum moment occurs when the centroid of the wheel loads and the nearest wheel are equidistant from the centre of the span. The Structural Analysis handbook's Chapter 4 is the tool for this." },
          ],
        },

        {
          n: "12.2",
          title: "Fatigue",
          hi: "थकान (फ़ैटीग)",
          blocks: [
            { k: "p", t: "Everything so far has assumed that a member is safe if its stress stays below a design value. Fatigue breaks that assumption: a detail cycled enough times will crack at stresses far below yield, and go on cracking until it fails." },
            { k: "dia", id: "hb-st-fatigue", cap: "What matters is the swing, not the height — and the relationship is a cube law." },
            { k: "p", t: "The mechanism is crack growth. A stress concentration — a weld toe, a bolt hole, a change of section — starts a microscopic crack, and every load cycle extends it a little. The member's remaining area shrinks until it can no longer carry the load, at which point it fails suddenly and in a brittle manner." },
            { k: "def", term: "Stress range Δσ", t: "The difference between the maximum and minimum stress in a cycle. Fatigue depends on this and only weakly on the mean stress, so a detail cycling between 40 and 120 N/mm² and one cycling between 0 and 80 N/mm² have essentially the same fatigue life. That is not intuitive, and it is the central fact of the subject." },
            { k: "p", t: "IS 800 Section 13 gives the design rules. The fatigue strength of a detail falls with the number of cycles along a straight line on log–log axes, with a slope of 1 in 3 up to five million cycles — which is a <strong>cube law</strong>:" },
            { k: "eq", expr: "halving the stress range multiplies the life by 2³ = 8", where: [] },
            { k: "p", t: "That steepness is the practical message. A small reduction in stress range buys a very large increase in life, and conversely a small unplanned increase is expensive. It is also why <strong>detail geometry matters more than member size</strong>: Table 26 classifies details into categories by their geometry, and moving a connection from a poor category to a good one can be worth more than doubling the section." },
            { k: "list", items: [
              "A full-penetration butt weld, ground flush, is a high category — smooth, no abrupt change of section.",
              "A fillet weld transverse to the stress, or a weld ending abruptly on a stressed plate, is a low category.",
              "A drilled hole is better than a punched one; a ground weld toe is better than an as-welded one.",
            ]},
            { k: "note", t: "Cl. 13.2.2 provides an exemption that matters in practice: fatigue need not be checked where the actual normal stress range is below a stated threshold (27 N/mm² divided by the relevant partial factor), or where the number of cycles is small. Most ordinary building structures fall inside it. Cranes, bridges, machine supports and anything carrying wind-induced oscillation do not." },
          ],
        },

        {
          n: "12.3",
          title: "Fire",
          hi: "अग्नि",
          blocks: [
            { k: "p", t: "Steel does not burn, and that is exactly the problem — it softens instead, and gives no visible warning while doing so. Reinforced concrete protects its steel with cover; a bare steel section has none, and being thin and highly conductive it reaches the gas temperature quickly." },
            { k: "dia", id: "hb-st-fire", cap: "Little loss below 400 °C, then a steep fall through the range a real fire reaches in minutes." },
            { k: "p", t: "IS 800 Section 16 covers fire resistance. The design approach is to establish a <strong>limiting temperature</strong> at which the member, carrying the load present in a fire (which is less than the full design load — Cl. 16.3 gives the reduced combination), would just fail, and then to provide enough protection that the member does not reach that temperature within the required fire rating." },
            { k: "list", items: [
              "<strong>Boarding</strong> — mineral or calcium silicate boards around the member. Neat, robust, and takes up space.",
              "<strong>Sprayed coating</strong> — cheap, quick, ugly. Used where the steel is concealed.",
              "<strong>Intumescent paint</strong> — thin and paintable, swells into an insulating char when heated. Expensive, and used where the steel is to be seen.",
              "<strong>Concrete encasement</strong> — the traditional answer, heavy, and it can be made to contribute structurally.",
              "<strong>Section factor</strong> — the ratio of heated perimeter to cross-sectional area. A stocky section heats more slowly than a slender one of the same weight and needs less protection, which occasionally makes a heavier section the cheaper one.",
            ]},
          ],
        },

        {
          n: "12.4",
          title: "Corrosion, fabrication and erection",
          hi: "जंग, निर्माण और स्थापना",
          blocks: [
            { k: "p", t: "Section 15 covers durability. Unprotected steel in the Indian climate corrodes, and the rate depends on exposure — coastal, industrial, or sheltered interior. The measures are a protective coating (paint systems to a specification, or galvanising), a design that does not trap water, and access for maintenance." },
            { k: "trap", t: "Detailing decides corrosion more than coatings do. Upward-facing channels collect water. Back-to-back angles with a gap trap moisture that cannot be painted. A crevice between two plates holds water indefinitely. These are drawing-board decisions, and they are not fixable later." },
            { k: "h", t: "Fabrication and erection" },
            { k: "p", t: "Section 17 sets the requirements for cutting, fitting, welding, bolting and tolerances. A few points affect design rather than merely workmanship:" },
            { k: "list", items: [
              "<strong>Tolerances are real</strong>. A column is permitted to be out of plumb within a stated limit, and that out-of-plumbness is exactly the initial imperfection the column curve of Chapter 6 assumed. Exceeding it invalidates the design.",
              "<strong>Erection stability</strong> is the designer's business. A frame that is stable when complete may be a mechanism halfway through erection, and the temporary bracing needed to get there has to be thought about by whoever knows how the structure works.",
              "<strong>Shop against site</strong>. Every weld moved from the shop to the site costs quality — which is what γmw's jump from 1.25 to 1.50 is saying in numbers.",
              "<strong>Camber</strong>. Long-span girders are fabricated with an upward bow so that they sit level under dead load. It must be specified, because it is not something a fabricator will assume.",
            ]},
          ],
        },

        {
          n: "12.5",
          title: "Closing the loop",
          hi: "पूरा चक्र",
          blocks: [
            { k: "p", t: "Twelve chapters back, this handbook began by listing what changes when you move from concrete to steel: ductility, buckling, connections, and a catalogue instead of a mould. Every chapter since has been one of those four." },
            { k: "list", items: [
              "<strong>Ch 1–2</strong> — the material, its ductility, and whether its plates will stay flat.",
              "<strong>Ch 3–4</strong> — connections, first, because in steel they usually govern.",
              "<strong>Ch 5</strong> — tension: three modes, two safety factors, and the reason there are two.",
              "<strong>Ch 6</strong> — compression: Euler, imperfection, and why a higher grade buys so little.",
              "<strong>Ch 7–8</strong> — beams, and the discovery that an unrestrained one is a column in disguise.",
              "<strong>Ch 9</strong> — both at once, and the moment a member makes for itself.",
              "<strong>Ch 10</strong> — plate girders, where the web is allowed to buckle and then used anyway.",
              "<strong>Ch 11–12</strong> — assembling it into structures, and the failures that arrive with time rather than with load.",
            ]},
            { k: "p", t: "One theme has run through nearly all of it. <strong>Almost every limit in IS 800 is a stability limit, not a strength limit.</strong> Yielding is the easy case; the code is long because there are so many ways for a thin steel member to move sideways before it ever gets there. When a steel design fails a check, the productive question is almost always \"what is buckling, and what would restrain it?\" rather than \"how much more steel does it need?\"" },
            { k: "note", t: "The values here are referenced for learning. Before using any of them in a design that will be built, confirm the clause against the current published edition of IS 800 and any amendment in force, confirm every section property against IS 808 / SP:6(1), and read IS 1893 and IS 800 Section 12 together for anything in a seismic zone." },
          ],
        },
      ],
    }

  );
})();
