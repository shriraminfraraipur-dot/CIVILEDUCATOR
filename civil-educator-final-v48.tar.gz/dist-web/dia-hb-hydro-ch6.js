/* ============================================================
   CIVIL EDUCATOR — DIAGRAM for the Hydrology handbook,
   Chapter 6 "Runoff & Catchment Characteristics".
   ------------------------------------------------------------
   Same conventions as the other diagrams files: strokes are
   currentColor so both themes work, meaning-carrying strokes use
   .hi (marker) or .ac (accent), and the figure gets its own
   marker-id prefix so it never collides with another figure on
   the same page.
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

function mk(id) {
  return `<defs>
    <marker id="${id}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" fill="currentColor"/></marker>
    <marker id="${id}-m" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="hif"/></marker>
    <marker id="${id}-c" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 z" class="acf"/></marker>
  </defs>`;
}

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 6.3  FORM FACTOR / COMPACTNESS COEFF */
  "hb-hydro-catchment-shape": {
    label: "Catchment shape — form factor and compactness coefficient",
    svg: `<svg viewBox="0 0 680 320" role="img" aria-label="Left, an elongated fan-shaped catchment cut into vertical strips of width B1 to B5 with its axial length L marked, illustrating form factor FF = B/L = A/L squared. Right, an irregular catchment of area A and perimeter P next to a circle of the same area with radius r, illustrating compactness coefficient CC = P over 2 times the square root of pi A.">
      ${mk("cs")}

      <text class="em" x="170" y="22" text-anchor="middle">FORM FACTOR  FF = B/L = A/L²</text>

      <path class="s" d="M40,170 Q95,82 170,76 Q245,82 300,170 Q245,258 170,264 Q95,258 40,170 Z"/>

      <line class="thin" x1="80" y1="133" x2="80" y2="207"/>
      <line class="thin" x1="120" y1="103" x2="120" y2="237"/>
      <line class="thin" x1="170" y1="76" x2="170" y2="264"/>
      <line class="thin" x1="220" y1="103" x2="220" y2="237"/>
      <line class="thin" x1="260" y1="133" x2="260" y2="207"/>

      <text class="lb" x="80" y="118" text-anchor="middle">B1</text>
      <text class="lb" x="120" y="92" text-anchor="middle">B2</text>
      <text class="lb" x="170" y="65" text-anchor="middle">B3</text>
      <text class="lb" x="220" y="92" text-anchor="middle">B4</text>
      <text class="lb" x="260" y="118" text-anchor="middle">B5</text>

      <circle class="acf" cx="40" cy="170" r="5"/>
      <text class="ea" x="22" y="174" text-anchor="end">outlet</text>
      <line class="hi" x1="10" y1="170" x2="33" y2="170" marker-end="url(#cs-m)"/>

      <line class="ac" x1="40" y1="296" x2="300" y2="296" marker-start="url(#cs-c)" marker-end="url(#cs-c)"/>
      <text class="lb" x="170" y="314" text-anchor="middle">L — axial length of basin</text>
      <text class="lb" x="170" y="284" text-anchor="middle">Avg width B = A / L</text>

      <line class="gl" x1="330" y1="10" x2="330" y2="310"/>

      <text class="em" x="500" y="22" text-anchor="middle">COMPACTNESS COEFF.  CC = P / (2√(πA))</text>

      <path class="s" d="M400,150 Q392,96 440,90 Q470,70 500,92 Q540,86 548,130 Q566,150 548,186 Q552,224 510,228 Q476,250 440,226 Q398,212 400,150 Z"/>
      <text class="lb" x="474" y="160" text-anchor="middle">Area = A</text>
      <text class="lb" x="474" y="178" text-anchor="middle">Perimeter = P</text>

      <line class="thin dash" x1="548" y1="158" x2="600" y2="158"/>
      <text class="lb" x="574" y="148" text-anchor="middle">same area</text>

      <circle class="s" cx="618" cy="158" r="46"/>
      <line class="thin" x1="618" y1="158" x2="664" y2="158"/>
      <text class="ea" x="640" y="150" text-anchor="middle">r</text>
      <text class="lb" x="618" y="218" text-anchor="middle">A_circle = πr² = A</text>
      <text class="lb" x="618" y="236" text-anchor="middle">r = √(A/π)</text>

      <text class="lb" x="500" y="278" text-anchor="middle">CC = 1 only for a perfectly circular basin</text>
      <text class="lb" x="500" y="296" text-anchor="middle">CC always ≥ 1 otherwise</text>
    </svg>`,
    caption: "Both numbers describe the same thing — how far a catchment's shape is from a compact circle — using different geometry. <strong>Form factor FF = A/L²</strong> compares average width to axial length: a high FF (short, wide basin) means tributaries reach the outlet at similar times, so the <em>channel-flow phase dominates</em> and the flood peak is sharp and early. <strong>Compactness coefficient CC = P/(2√(πA))</strong> compares the basin's actual perimeter to the smallest possible perimeter (a circle) enclosing the same area: CC close to 1 means a compact, rounder basin (again, sharper peak, less waterlogging); CC well above 1 means an elongated or irregular basin, where the overland-flow phase dominates, concentration takes longer, and waterlogging is more likely. (S2 p.93–94)",
  },

});
