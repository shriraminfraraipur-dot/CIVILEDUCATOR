/* MACE Academy SOM notes — Moment-area method (Mohr's theorems) and conjugate beam method, M p.190–197 — inserted into som chapter 5 */
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "som"; });
  if (!hb) return;
  var ch = hb.chapters.find(function (c) { return c.n === 5; });
  if (!ch) return;
  var add = [

    /* ---------------------------------------------------- M p.190 */
    {
      n: "",
      title: "MACE notes — Moment-area method: where it applies and the derivation of Mohr's first theorem",
      hi: "मोमेंट-एरिया विधि — उपयोग की शर्तें और मोर के प्रथम प्रमेय की व्युत्पत्ति",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.190" },
        { k: "p", t: "<b>[V-12] 4) Moment Area Method (Mohr's theorem)</b> (M p.190)" },
        { k: "list", items: [
          "★ This method is used for <b>prismatic and non-prismatic</b> beams both. (M p.190)",
          "It is <b>not applicable if an internal hinge is present</b>, i.e. not applicable in case of discontinuity. (M p.190)",
          "It can be used when drawing the <b>M/EI diagram is easy</b>. (M p.190)",
          "This method is generally used if the <b>positions of zero slope and zero deflection are exactly known</b>. (M p.190)",
        ] },
        { k: "p", t: "★ The generalised moment area method can be summarised as under → the following figure shows the load diagram, M/EI diagram and deflection diagram → consider pt. ① and pt. ② on the elastic curve as shown in fig. 4. (M p.190)" },
        { k: "list", items: [
          "<b>dx</b> = distance between these two sections (i.e. ① and ②)",
          "<b>ds</b> = arc length between these two sections",
          "<b>dθ</b> = angle subtended at the centre by pts. ① and ②, or by the arc ds",
        ] },
        { k: "p", t: "If we draw two tangents, one at pt. ① and the second at pt. ②, then the following conclusions can be derived. (M p.190)" },
        { k: "list", items: [
          "Figure (M p.190), Fig. 1 \"Load dia.\": simply supported beam (hinge at left, roller at right) carrying a general hump-shaped distributed load; a hatched strip of width dx at distance x from the left support.",
          "Fig. 2 \"BMD\": a sagging, parabola-like bending moment diagram.",
          "Fig. 3 \"M/EI dia.\" [unit L⁻¹]: the same shape; the hatched strip of width dx is labelled \"Area of M/EI between ① and ②\"; the ordinate is marked with a double arrow.",
          "Fig. 4 \"Deflection dia. [elastic curve]\": the beam sags below its chord; points ① and ② on the curve are dx apart horizontally (dashed verticals carried down from the figures above), with arc ds between them; tangents at ① and ② meet at angle dθ; dashed radii to the centre of curvature also enclose dθ.",
          "Fig. 4.1 (enlarged arc): arc ① to ② of length ds, radius R, angle dθ at the centre; \"tangent to pt. ①\" and \"tangent to pt. ②\" with angle dθ between them; boxed: <b>ds = dθ·R</b>.",
        ] },
        { k: "h", t: "Derivation (M p.190)" },
        { k: "eq", expr: "From M/I = σ/y = E/R   ⇒   1/R = M/(EI)   ——①" },
        { k: "eq", expr: "From fig. 4.1: ds = R·dθ   ⇒   1/R = dθ/ds" },
        { k: "p", t: "But <b>ds ≈ dx</b> (∵ deformations are too small) — small sketch in the notes: a curved element with ds marked on the lower curve and dx on the upper. (M p.190)" },
        { k: "eq", expr: "1/R = dθ/dx   ——②" },
        { k: "eq", expr: "From ① and ②:  M/(EI) = dθ/dx   ⇒   ∫₁² dθ = ∫₁² (M/EI)·dx   ⇒   θ₂ − θ₁ = ∫₁² (M/EI) dx" },
        { k: "eq", expr: "★ θ₂ − θ₁ = Area of M/EI diagram between pts. ① and ②", where: [
          ["θ₁, θ₂", "slopes of the tangents to the elastic curve at points ① and ②"],
        ] },
        { k: "p", t: "↳ This is <b>Mohr's 1st theorem</b>, or the <b>theorem of slope</b>, or the <b>1st moment area theorem</b>. We can also derive one more theorem in the same case but with a little different approach (the 2nd theorem, next sections). (M p.190)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "The whole method rests on one line: curvature dθ/dx = M/EI. Ek chhote tukde dx par tangent jitna ghoomta hai, woh us tukde ke M/EI ke barabar hai. Add up (integrate) all the little turns between ① and ② and you get the total change of slope — which is simply the area under the M/EI diagram between them. No integration constants, no boundary-condition algebra — that is why it is quick when you know where the slope is zero (a fixed end, or the mid-span of a symmetric beam)." },
        { k: "p", t: "Why the notes rule it out with an internal hinge: at a hinge the slope of the elastic curve jumps suddenly (the two sides rotate independently), so 'change of slope = area of M/EI' does not hold across that point. The conjugate beam method (later sections) handles hinges by turning them into supports. Compare the condensed statement of the method in §5.3 of this chapter." },
        { k: "trap", t: "Students write θ = Area of M/EI as if it gives the slope itself. It gives the <b>change</b> of slope θ₂ − θ₁. It equals the slope at a point only when the other point's slope is zero — e.g. the fixed end of a cantilever, or mid-span of a symmetrically loaded simply supported beam." },
      ],
    },

    /* ---------------------------------------------------- M p.191–192 */
    {
      n: "",
      title: "MACE notes — First moment-area theorem (slope): statement and Que1–Que4",
      hi: "प्रथम मोमेंट-एरिया प्रमेय (ढाल) — कथन और प्रश्न 1–4",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.191–192" },
        { k: "p", t: "Following are the two moment area theorems: (M p.191)" },
        { k: "def", term: "1) First moment area theorem (theorem for slope)", t: "This theorem states that the <b>angle between the tangents to the elastic curve at any two points</b> is equal to the <b>area of the M/EI diagram between those two points</b>. [change of slope from ① to ②] (M p.191)" },
        { k: "eq", expr: "Angle between tangents at ① and ②:   dθ = Area of M/EI dia. between ① and ②" },
        { k: "p", t: "Figure (M p.191): top — an M/EI diagram (hump-shaped) with a hatched strip between two dashed verticals; bottom — the sagging elastic curve with points ① and ② on it; the tangent at ① makes θ₁ with the horizontal, the tangent at ② makes θ₂, and dθ is the angle between the two tangents." },
        { k: "h", t: "Example — cantilever (M p.191)" },
        { k: "p", t: "Figure: cantilever fixed at A (θA = 0), free end B; the deflected curve drops to B; the horizontal tangent at A is labelled \"Slope = θA\", the tangent at B \"Slope = θB\", and dθ is the angle between them. (M p.191)" },
        { k: "eq", expr: "dθ = θB − θA ;  but dθ = Area of M/EI dia. from pt. A to B ;  but θA = 0   ⇒   θB − 0 = Area of M/EI diagram" },
        { k: "eg", title: "MACE notes example — Que1: tip slope of a cantilever with an end point load", given: "Que1) θB = ?  Cantilever fixed at A (θA = 0), free end B, length L, point load P at B.", steps: [
          { t: "1st step: draw the BMD or M/EI diagram", w: "Triangle, ordinate PL/EI at A reducing to zero at B, sign (−)." },
          { t: "Elastic curve", w: "θA = 0 at ① (A), horizontal tangent; curve drops to ② (B); tangent at B makes θB with the horizontal; dθ between the two tangents." },
          { t: "Theorem 1", w: "dθ = θB − θA (θA = 0) = Area of M/EI dia. between A and B\n= (1/2) × (PL/EI) × L" },
        ], ans: "★ θB = PL²/(2EI) (M p.191)" },
        { k: "note", t: "In the elastic-curve sketch of Que1 the notes write a label \"θB=0\" at the right end of the horizontal line drawn from A. That line is the tangent at A (whose slope is zero); the slope at B itself is not zero — it is the boxed PL²/2EI. (M p.191)" },
        { k: "eg", title: "MACE notes example — Que2: tip slope of a cantilever with an end moment", given: "Que2) θB = ?  Cantilever fixed at A (θA = 0), free end B, length L; moment M applied at B (reaction moment M at A).", steps: [
          { t: "BMD / M/EI diagram", w: "Rectangle of ordinate M/EI over the full length L." },
          { t: "Theorem 1", w: "θB − θA = (M/EI) × L" },
        ], ans: "★ θB = ML/(EI) (M p.191)" },
        { k: "eg", title: "MACE notes example — Que3: slope at mid-length of a cantilever with an end load", given: "Que3) θB = ?  Cantilever fixed at A (θA = 0), free end C, point load P at C; B at the mid point: AB = L/2, BC = L/2, total L.", steps: [
          { t: "M/EI diagram", w: "Triangle, PL/EI at A to zero at C; the trapezoid between A and B is hatched; ordinate at B = x (?)." },
          { t: "Find x by similar triangles", w: "(PL/AE)/x = L/(L/2)   [as written]\nx = PL/(2EI)" },
          { t: "Theorem 1 between A and B", w: "θB − θA (θA = 0) = Area of trapezoid between A and B\n= [(2×PL)/(2×EI) + PL/(2EI)] / 2 × (L/2)" },
        ], ans: "★ θB = 3PL²/(8EI) (M p.191)" },
        { k: "note", t: "<b>Check:</b> in the similar-triangle line the notes write PL/AE; it should read <b>PL/EI</b> (the ordinate of the M/EI diagram at A). With PL/EI: (PL/EI)/x = L/(L/2) ⇒ x = PL/2EI, as boxed. Trapezoid area = (PL/EI + PL/2EI)/2 × L/2 = (3PL/2EI)/2 × L/2 = 3PL²/8EI ✔ — the boxed answer is correct. (M p.191)" },
        { k: "eg", title: "MACE notes example — Que4: slopes at the load and at the tip (load inside the span)", given: "Que4) Find θB and θC.  Cantilever fixed at A (θA = 0), free end B; point load P at C; AC = a, CB = b.", steps: [
          { t: "Elastic curve and BMD", w: "Curve from A to C (slope θc at C), straight line from C to B (slope θB at B).\nM/EI diagram: triangle Pa/EI at A reducing to zero at C (over length a); zero over CB (length b)." },
          { t: "Slope at B", w: "θB − θA (θA = 0) = (1/2) × (Pa/EI) × a\nθB = Pa²/(2EI)" },
          { t: "Slope at C", w: "θc − θA (θA = 0) = Area between A and C = (1/2) × a × (Pa/EI)\nθc = Pa²/(2EI)" },
        ], ans: "★ θB = θc = Pa²/(2EI), i.e. the elastic curve between B and C is a straight line. (M p.192)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Que4 is the cleanest picture of the theorem: beyond the load (C to B) the bending moment is zero, so the M/EI area there is zero, so the slope does not change — the beam simply carries on as a straight line from C to the tip. Curvature exists only where moment exists. Que3 is the same idea used in reverse: you take only the part of the area between the two points you care about (the trapezoid from A to B), not the whole triangle." },
        { k: "trap", t: "In Que3/Que4 type questions students take the full M/EI area up to the free end even when the slope is wanted at an interior point. The area must be taken <b>only between the two points</b> — from the zero-slope point A up to the point asked. Also, beyond the last load of a cantilever, slope stays constant; do not add any extra area for the unloaded length b." },
        { k: "real", t: "The straight-line portion beyond a load is why a cantilever balcony's tip deflection is the deflection at the load plus slope × remaining length — a fast hand check used when checking a canopy or chajja for sag." },
      ],
    },

    /* ---------------------------------------------------- M p.192–193 */
    {
      n: "",
      title: "MACE notes — Second moment-area theorem (deflection): statement and Que1–Que3",
      hi: "द्वितीय मोमेंट-एरिया प्रमेय (विक्षेप) — कथन और प्रश्न 1–3",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.192–193" },
        { k: "def", term: "[V-13] 2) Second moment area theorem (theorem for deflection)", t: "The second moment area theorem states that the <b>vertical intercept between the tangent drawn at one point and the vertical line drawn through the second point</b> is equal to the <b>moment of the area of the M/EI diagram between points ① and ② about the 2nd point</b>. (M p.192)" },
        { k: "p", t: "Consider the following figure in which there are two sections ①–① and ②–②. The shaded area shows the area of the M/EI diagram between ① and ②. Point c shows the centroid of the shaded area. (M p.192)" },
        { k: "list", items: [
          "Figure (M p.192), top: curved, hump-shaped M/EI diagram; hatched area between dashed verticals at sections ① and ②; centroid c of the hatched area; <b>x̄₁</b> = distance from ① to c, <b>x̄₂</b> = distance from c to ②.",
          "Bottom: sagging elastic curve with points ① and ②; \"Tangent @①\" drawn at ① and extended to the right, \"Tangent @②\" drawn at ② and extended to the left.",
          "<b>V₁₋₂</b> = vertical intercept at ① between the curve and the tangent @② (\"vertical from ① on tangent @②\").",
          "<b>V₂₋₁</b> = vertical intercept at ② between the curve and the tangent @① (\"vertical from ② on tangent @①\").",
        ] },
        { k: "eq", expr: "V₁₋₂ = Moment of area of M/EI dia. between ① and ② about ① = [Area of M/EI dia. between ① and ②] × x̄₁" },
        { k: "eq", expr: "V₂₋₁ = Moment of M/EI dia. between ① and ② about ② = [Area of M/EI dia. between ① and ②] × x̄₂" },
        { k: "list", items: [
          "V₁₋₂ and V₂₋₁ may be the same or different depending upon the location of the centroid of the M/EI diagram between ① and ②. (M p.192)",
          "★ <b>Vertical ordinate from any pt. 2 on the tangent drawn at point 1 = moment of area of (M/EI) dia. between ① and ② taken about 2.</b> ↳ 2nd moment area theorem, or Mohr's 2nd theorem, or theorem of deflection. (M p.192)",
        ] },
        { k: "note", t: "<b>Source difference:</b> the older condensed notes (§5.3, p.12) write y = A·x̄/EI with x̄ measured \"from the point of maximum slope\" to the centroid of the BMD. The MACE notes take the moment <b>about the point where the intercept is measured</b> (point 2, on the tangent drawn at point 1). Re-derivation: the tangents at the ends of a strip dx at distance x from point 2 differ by (M/EI)dx, and over the lever arm x they open a vertical gap x·(M/EI)dx at point 2; summing, V₂₋₁ = ∫(M/EI)·x dx = Area × x̄₂, with x̄₂ measured from point 2. So the MACE statement is the general, correct one. The two agree for a cantilever only because the point of maximum slope is the free tip, which is also the point whose deflection is wanted." },
        { k: "eg", title: "MACE notes example — Que1: tip deflection of a cantilever with an end point load", given: "Que1) Find Δ_B.  Cantilever AB fixed at A, free end B, span L, point load P downward at B.", steps: [
          { t: "M/EI diagram", w: "Triangle, PL/EI at A reducing to zero at B; centroid at L/3 from A and 2L/3 from B." },
          { t: "Elastic curve", w: "Tangent at A is horizontal; vertical intercept at B between curve and this tangent = Δ_B." },
          { t: "Theorem 2", w: "Δ_B = moment of area of M/EI diagram between A and B about B\n= (2L/3) × Area of M/EI dia.\n= (2L/3) × θ_B   [∵ θ_B − θ_A (θ_A = 0) = Area of M/EI dia.]\n= (2L/3) × ((1/2) × (PL/EI) × L)" },
        ], ans: "★ Δ_B = PL³/(3EI) (M p.193)" },
        { k: "eg", title: "MACE notes example — Que2: tip deflection of a cantilever with an end moment", given: "Que2) Find Δ_B.  Cantilever AB fixed at A, free end B, span L (L/2 + L/2), moment M applied at B.", steps: [
          { t: "M/EI diagram", w: "Rectangle of height M/EI over the full length; centroid at L/2 from B." },
          { t: "Theorem 2 (θ_A = 0, tangent at A horizontal)", w: "Δ_B = moment of area of M/EI dia. between A and B about B\n= [(M/EI) × L] × (L/2)" },
        ], ans: "★ Δ_B = ML²/(2EI) (M p.193)" },
        { k: "eg", title: "MACE notes example — Que3: simply supported beam, central point load — slopes and central deflection", given: "Que3) Find θ_A, θ_B and Δ_c.  Simply supported beam AB (hinge at A, roller at B), span L (L/2 + L/2), point load P at mid-span C.", steps: [
          { t: "Elastic curve and M/EI diagram", w: "Curve sags; θ_c = 0 at C (tangent at C horizontal).\nM/EI dia.: triangle with peak PL/4EI at C, bases L/2 and L/2." },
          { t: "Slopes (theorem 1 between A and C)", w: "θ_A − θ_c (θ_c = 0) = Area of M/EI dia. between A and C\n= (1/2)(L/2) × (PL/4EI)\nθ_A = PL²/(16EI)\nSimilarly, θ_B = PL²/(16EI)" },
          { t: "Deflection — figure", w: "c₁ = point on the elastic curve below C (horizontal tangent there); c₂ = point below C on the tangent drawn at A.\nAt B the notes split the intercept of the tangent from A: V_B-A = Δc + V_C-A + θ_A·(L/2)" },
          { t: "Boxed relation", w: "Δ_C = V_B-A − V_C-A − θ_A·(L/2)\nΔ_C = CC₁ = CC₂ − C₁C₂" },
          { t: "i) CC₂", w: "CC₂ = θ_A × (L/2) = PL³/(32EI)" },
          { t: "ii) C₁C₂ (theorem 2 about C)", w: "C₁C₂ = moment of area of M/EI dia. between A and C about C\nCentroid of the A–C triangle: (2/3)(L/2) from A, (1/3)(L/2) from C\n= ((1/2)(PL/4EI) × (L/2)) × (1/3)(L/2) = PL³/(96EI)" },
          { t: "Δc", w: "Δc = CC₂ − C₁C₂ = (3 × PL³)/(3 × 32EI) − PL³/(96EI)" },
        ], ans: "★ θ_A = θ_B = PL²/(16EI);  Δc = PL³/(48EI) (M p.193)" },
        { k: "note", t: "Re-worked: V_B-A (moment of the whole M/EI triangle about B) = (PL²/8EI)(L/2) = PL³/16EI; V_C-A = PL³/96EI; θ_A·L/2 = PL³/32EI. Then V_B-A − V_C-A − θ_A·L/2 = (6 − 1 − 3)PL³/96EI = PL³/48EI, the same as CC₂ − C₁C₂ = (3 − 1)PL³/96EI ✔. Both routes in the notes give the boxed answer. (M p.193)" },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Theorem 2 is just 'slope × distance' added up strip by strip. Every little bend (M/EI)dx, at a distance x from the point you are looking at, swings the tangent by an amount that shows up there as a vertical gap x·(M/EI)dx. Add all of them → area × distance of the centroid from <i>that</i> point. For a cantilever the tangent at the fixed end is horizontal, so the gap at the tip <i>is</i> the deflection." },
        { k: "p", t: "For the simply supported beam no tangent is conveniently horizontal at a support, so Que3 uses the symmetry point C (θ_c = 0) for the slope, and then gets the central deflection as 'how far the tangent from A has dropped by C' (θ_A·L/2) minus 'how far the curve is above that tangent' (the moment of the A–C area about C). Same answer as the table value WL³/48EI in §5.4 of this chapter." },
        { k: "trap", t: "Taking the moment of the M/EI area about the wrong point. The moment is always taken about the point where the vertical intercept is measured — for a cantilever tip use 2L/3 (from the tip) for a triangle, not L/3. And remember an intercept from a tangent is <b>not</b> the deflection unless that tangent is horizontal (or the geometry is corrected as in Que3)." },
        { k: "real", t: "Designers use exactly this split — 'tangent drop minus curve offset' — when hand-checking the mid-span sag of a simply supported steel joist or lintel before comparing it with a span/deflection limit." },
      ],
    },

    /* ---------------------------------------------------- M p.194–195 */
    {
      n: "",
      title: "MACE notes — Conjugate beam method: concept and the two key conclusions",
      hi: "संयुग्मी बीम विधि — अवधारणा और दो मुख्य निष्कर्ष",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.194–195" },
        { k: "p", t: "<b>[V-14] 5) Conjugate Beam method</b> (M p.194)" },
        { k: "list", items: [
          "This method is suitable for <b>prismatic as well as non-prismatic beams containing internal hinges</b>. (M p.194)",
          "This method is closely related with the moment area method. (M p.194)",
          "Consider a beam AB as shown below along with its M/EI diagram. (M p.194)",
          "If the M/EI diagram is applied on the beam as loading, it is called the <b>conjugate beam</b>, as shown in fig (3). (M p.194)",
          "Let us first understand the concept of this method and afterward we'll discuss the conjugate beam in detail. (M p.194)",
        ] },
        { k: "list", items: [
          "Figure (M p.194), fig (1) [Real Beam]: simply supported AB (hinge A, roller B), span L, point load P at C at distance x from A. Elastic curve sags; θ_A at A; C₁ on the elastic curve below C; C₂ on the tangent at A below C; the tangent from A extended to B′ below B; vertical intercept BB′ = V_B-A.",
          "fig (2) M/EI diagram: triangle on AB, peak PL/4EI at C, bases L/2 and L/2; resultant arrow at the peak.",
          "fig (3) Conjugate Beam: simply supported (hinge left, roller right) loaded with the triangular downward distributed load (the M/EI diagram).",
        ] },
        { k: "p", t: "In fig (1), a tangent is drawn to the elastic curve at pt. A, which gives the slope at A (i.e. θ_A). Let V_B-A = vertical intercept = moment of area of M/EI dia. between A and B about B. (M p.194)" },
        { k: "eq", expr: "In ΔABB′:  θ_A = V_B-A / L = [Moment of area of M/EI dia. between A and B about B] / [Span]" },
        { k: "h", t: "Slope at C (M p.194–195)" },
        { k: "p", t: "Figure (M p.194): elastic curve near A, with c₁ on the curve and c₂ on the tangent at A; \"Tgt @ c₁\" at angle θc, \"Tgt @ A\" at angle θ_A; dθ = θ_A − θc between the two tangents. (A rough working sketch of crossing tangents also appears.)" },
        { k: "eq", expr: "θc = θ_A − dθ = slope at A − angle between the tangents at pts. A and C" },
        { k: "eq", expr: "θc = [Moment of area of M/EI dia. between A and B about B]/[span] − (Area of M/EI dia. between A and C)" },
        { k: "eq", expr: "θc = [(1/2) × L × (PL/4EI) × (L/2)] / L − Area of M/EI dia. between A and C = PL²/(16EI) − Area" },
        { k: "eq", expr: "θc = Reaction at A in CB − Total M/EI loading till point C   ⇒   Slope at C in real beam = Shear force at C in the CB" },
        { k: "p", t: "Figure (M p.195): conjugate beam AB loaded with the triangular downward M/EI load, point c marked; reactions SF = R_A = PL²/(16EI) at A and R_B = PL²/(16EI) at B. (CB = conjugate beam.)" },
        { k: "h", t: "★ Important conclusion (M p.195)" },
        { k: "cmp", cols: ["In the conjugate beam loaded with the M/EI dia. of the real beam"], rows: [
          ["1) <b>Slope</b> at any point in the real beam", "= <b>Shear force</b> at that point in the conjugate beam"],
          ["2) <b>Deflection</b> at any point in the real beam", "= <b>Bending moment</b> at that point in the conjugate beam"],
        ] },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Look at the algebra above: θc = (reaction at A) − (M/EI load between A and C). That is word for word how you find the <b>shear force</b> at C in any beam — reaction minus load to the left. So once M/EI is treated as a load, slope behaves exactly like shear, and (by the same argument with theorem 2) deflection behaves exactly like bending moment. You already know how to draw SFD and BMD (Chapter 3); the conjugate beam lets you reuse that skill for slope and deflection." },
        { k: "trap", t: "Loading the conjugate beam with the real <b>load</b> (P or w) instead of the real <b>M/EI diagram</b>. The conjugate load always has units of M/EI (per length), and its reactions come out as slopes (radians), its moments as deflections." },
      ],
    },

    /* ---------------------------------------------------- M p.195–196 */
    {
      n: "",
      title: "MACE notes — Construction of the conjugate beam, support conversion and sign conventions",
      hi: "संयुग्मी बीम की रचना, आधार परिवर्तन और चिह्न परिपाटी",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.195–196" },
        { k: "p", t: "<b>[V-15] ★ Construction of conjugate beam</b> (M p.195)" },
        { k: "list", items: [
          "The conjugate beam and real beam have the <b>same length or span</b>, because for every point of the real beam at which the slope and deflection are required to be calculated there should be a corresponding point on the conjugate beam. (M p.195)",
          "The conjugate beam is <b>supported in such a way as to satisfy the slope and deflection conditions of the real beam</b>. (M p.195)",
        ] },
        { k: "h", t: "Example 1 (M p.195)" },
        { k: "cmp", t: "Real beam → conjugate beam (figure, M p.195)", cols: ["Real beam", "Conjugate beam"], rows: [
          ["A", "Fixed end", "Free end"],
          ["C", "Internal point (hinge) — no support", "Support (roller/hinge drawn)"],
          ["D", "Roller support", "Plain point — no support (internal hinge)"],
          ["B", "Free end", "Fixed end"],
        ] },
        { k: "h", t: "Example 2 (M p.195)" },
        { k: "list", items: [
          "Real beam: cantilever AB, fixed at A, free at B, length L, UDL W (load ↓) over the whole span; at A: θ_A = 0, Δ_A = 0; elastic curve with slope θ_B at B. (M p.195)",
          "M/EI dia.: parabolic, ordinate WL²/2EI at A reducing to 0 at B, over length L; \"BM ⇒ −ve\", sign (−). (M p.195)",
          "Conjugate beam: free at A, fixed at B; load = M/EI dia., parabolic <b>upward</b> loading (↑) with maximum at A; at B the reaction moment is labelled \"BM = Δ_B in real beam\" and the reaction shear \"SF = θ_B in real beam\". (M p.195)",
        ] },
        { k: "cmp", cols: ["Real", "Conjugate"], rows: [
          ["At B", "θ_B ≠ 0", "SF ≠ 0"],
          ["At B", "Δ_B ≠ 0", "BM ≠ 0"],
        ] },
        { k: "list", items: [
          "The conjugate beam is loaded with the M/EI dia. of the real beam. (M p.195)",
          "Slope and deflection in the real beam are given by the shear force and bending moment respectively in the conjugate beam. (M p.195)",
        ] },
        { k: "h", t: "★ Important sign convention (M p.196)" },
        { k: "cmp", t: "I] Loading", cols: ["In conjugate beam"], rows: [
          ["In real beam: −ve BMD", "→ <b>Upward</b> M/EI loading"],
          ["In real beam: +ve BMD", "→ <b>Downward</b> M/EI loading"],
        ] },
        { k: "cmp", t: "II] Shear force in conjugate beam → slope in real beam", cols: ["Meaning"], rows: [
          ["↑[+]↓  +ve SF", "→ Clockwise rotation of tangent (+ve θ)"],
          ["↓[−]↑  −ve SF", "→ Anticlockwise rotation of tangent (−ve θ)"],
        ] },
        { k: "cmp", t: "III] Bending moment in conjugate beam → deflection in real beam", cols: ["Meaning"], rows: [
          ["(+) BM — Sagging", "→ Downward deflection"],
          ["(−) BM — Hogging", "→ Upward deflection"],
        ] },
        { k: "note", t: "<b>General Engineering Knowledge</b> — the rule behind both examples: a real support condition (y, θ) is mapped to the conjugate condition (M, V). Fixed (y = 0, θ = 0) → free (M = 0, V = 0); free (y ≠ 0, θ ≠ 0) → fixed (M ≠ 0, V ≠ 0); simple end support (y = 0, θ ≠ 0) → simple support; interior support (y = 0, θ continuous) → internal hinge; internal hinge (y ≠ 0, θ jumps) → interior support. This matches the table in §5.3 of this chapter and the MACE figure (Example 1)." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Support conversion ek simple sawaal hai: real beam mein us point par y aur θ kya hain? Jo zero hai, conjugate mein uska partner (M ya V) bhi zero hona chahiye. Fixed end par dono zero → conjugate mein dono zero → free end. Free end par dono non-zero → conjugate mein fixed end. In Example 1 the real beam's internal hinge at C allows a jump in slope but keeps one deflection value, so the conjugate needs a reaction there (a support), while the real roller at D (deflection zero, slope continuous) becomes an internal hinge (moment zero, shear continuous)." },
        { k: "p", t: "Signs: a hogging (−ve) real BMD, as in every cantilever, is applied as an <b>upward</b> load on the conjugate beam. That is why the conjugate cantilevers in the next section have upward arrows, and why the fixed-end moment of the conjugate beam comes out as the tip's downward deflection." },
        { k: "trap", t: "Keeping the same supports in the conjugate beam. For a simply supported beam it works (simple ↔ simple), so students copy supports for a cantilever too — wrong. Fixed ↔ free swap, and an intermediate roller becomes an internal hinge. A conjugate beam may even look 'unstable' (e.g. hinge + free end); it is still in equilibrium under its M/EI load." },
      ],
    },

    /* ---------------------------------------------------- M p.196–197 */
    {
      n: "",
      title: "MACE notes — Conjugate beam worked questions Q.1–Q.4",
      hi: "संयुग्मी बीम — हल किए गए प्रश्न 1–4",
      blocks: [
        { k: "h", t: "📘 MACE notes — M p.196–197" },
        { k: "eg", title: "MACE notes example — Q.1: cantilever with an end moment, by conjugate beam", given: "Q.1) θ_B and Δ_B = ?  Cantilever AB fixed at A, free end B, moment M applied at B.", steps: [
          { t: "Real beam", w: "Elastic curve bends down; θ_B = (SF_B)c at B; Δ_B = (M_B)c." },
          { t: "M/EI diagram and conjugate beam", w: "M/EI dia.: rectangle over length L, sign (−).\nConjugate beam: A free, B fixed; uniform upward M/EI load over the length; reaction moment (M_B)c and shear (SF_B)c at B." },
          { t: "Deflection = BM at B in the conjugate beam", w: "Δ_B = (M_B)c = ((M/EI) × L) × Lever arm\n= ((M/EI) × L) × (L/2)\nΔ_B = ML²/(2EI)" },
          { t: "Slope = SF at B in the conjugate beam", w: "θ_B = (SF_B)c = (M/EI) × L\nθ_B = ML/(EI)" },
        ], ans: "Δ_B = ML²/(2EI);  θ_B = ML/(EI) (M p.196)" },
        { k: "eg", title: "MACE notes example — Q.2: cantilever with a full UDL, by conjugate beam", given: "Q.2) θ_B and Δ_B = ?  Real beam: cantilever AB fixed at A, free at B, UDL W over the full length; C at mid-span (L/2 + L/2).", steps: [
          { t: "Conjugate beam (C.B)", w: "A free, B fixed; parabolic upward load, ordinate WL²/2EI at A reducing to zero at B.\nResultant at L/4 from A, i.e. 3L/4 from B.\nAt B: moment (1/3)(WL²/2EI)·L × (3L/4) and shear (1/3)(WL²/2EI) × L." },
          { t: "Area and centroid of the parabolic spandrel (sketch)", w: "Rectangle B × H split by a parabola: shaded part = (2/3)BH, spandrel = (1/3)BH.\nSpandrel centroid at L/4 from its full-height side (base divided 3L/4 and L/4)." },
          { t: "Deflection = BM at B in C.B", w: "Δc = (1/3) × (WL²/2EI) × (3L²/4)   [the 3s cancel]\nΔc = WL⁴/(8EI)" },
          { t: "Slope = SF at B in C.B", w: "θc = (1/3)(WL²/2EI) × L\nθc = WL³/(6EI)" },
        ], ans: "Δ = WL⁴/(8EI);  θ = WL³/(6EI) — at the free end B (M p.196)" },
        { k: "note", t: "In Q.2 the notes label the answers Δc and θc although the question asks θ_B and Δ_B; the values are those at the free end B (the fixed end of the conjugate beam), read from the conjugate beam (c). The deflection line (1/3) × (WL²/2EI) × 3L²/4 combines the spandrel width L with the lever arm 3L/4 (the figure labels it (1/3)(WL²/2EI)·L × 3L/4). Re-worked: (1/3)(WL²/2EI)(L)(3L/4) = WL⁴/8EI ✔ and (1/3)(WL²/2EI)(L) = WL³/6EI ✔. (M p.196)" },
        { k: "eg", title: "MACE notes example — Q.3: cantilever with a point load at mid-length, by conjugate beam", given: "Q.3) Cantilever A–B–C, fixed at A, free end C, point load P at B; AB = L/2, BC = L/2. Find θc, Δc, θ_B, Δ_B.", steps: [
          { t: "Conjugate beam", w: "A free, C fixed; triangular upward M/EI load, PL/2EI at A reducing to zero at B (over L/2).\nResultant at (2/3)(L/2) from B, i.e. distance to C = (2/3)(L/2) + L/2." },
          { t: "θc = SF at C in C.B", w: "θc = (1/2) × (L/2) × (PL/2EI)\nθc = PL²/(8EI)" },
          { t: "Δc = BM at C in C.B", w: "Δc = (1/2) × (L/2) × (PL/2EI) × (L/3 + L/2)\n= (PL²/8EI) × (5L/6)\nΔc = 5PL³/(48EI)" },
          { t: "θ_B = SF at B in conjugate beam", w: "= (1/2)(PL/2EI) × (L/2)   ← (1/2)·B·H\ni.e. θc = θ_B = PL²/(8EI)" },
          { t: "Δ_B = BM at B in CB", w: "= (PL²/8EI) × (L/3)\nΔ_B = PL³/(24EI)" },
        ], ans: "θc = θ_B = PL²/(8EI);  Δc = 5PL³/(48EI);  Δ_B = PL³/(24EI) (M p.197)" },
        { k: "eg", title: "MACE notes example — Q.4: simply supported beam with a central point load, by conjugate beam", given: "Q.4) Real beam: simply supported AB (hinge at A, roller at B), span L, point load P at mid-span C (L/2 + L/2). Find θ_A, θ_B, Δc.", steps: [
          { t: "C. Beam", w: "Simply supported (labelled A \"Roller\", B \"Hinged\"); triangular downward load, peak PL/4EI at mid-span.\nResultant of the left half at 2/3 of L/2 from A, i.e. (1/3) × (L/2) = L/6 from C." },
          { t: "Slopes = conjugate reactions", w: "(R_A)c = θ_A = (1/2) × (L/2) × (PL/4EI)\nθ_A = PL²/(16EI)\n(R_B)c = θ_B = PL²/(16EI)" },
          { t: "Δc = BM at C in C.B.", w: "= +(R_A)c × (L/2) − ((1/2) × (L/2) × (PL/4EI)) × (1/3)(L/2)\n= (PL²/16EI)·(L/2) − (PL²/16EI)·(L/6)\n= (PL³/16EI)((3 × L)/(3 × 2) − L/6)" },
        ], ans: "θ_A = θ_B = PL²/(16EI);  Δc = PL³/(48EI) (M p.197)" },
        { k: "note", t: "All answers on M p.191–197 re-worked (exact fractions): 3PL²/8EI, PL²/16EI, PL³/48EI (both routes), WL⁴/8EI, WL³/6EI, PL²/8EI, 5PL³/48EI, PL³/24EI, PL³/48EI — all ✔. Q.3's results also agree with the §5.4 table: Wa³/3EI with a = L/2 gives PL³/24EI, and the tip value Wa²(3L − a)/6EI with a = L/2 gives 5PL³/48EI." },
        { k: "h", t: "💡 Samjho" },
        { k: "p", t: "Every question here follows the same three moves: (1) draw M/EI, (2) flip the supports and put M/EI on as the load (upward if hogging), (3) read shear for slope and moment for deflection — usually at the fixed end of the conjugate beam, where the reaction is just 'total load' and 'total load × distance of its centroid'. In Q.3 the unloaded half B–C carries no conjugate load, so the shear (slope) does not change from B to C — the same straight-line tip you met in the first-theorem Que4." },
        { k: "p", t: "Compare Q.4 with Que3 of the second theorem: same beam, same answers, but here the conjugate reaction hands you θ_A directly and the central deflection is just a bending-moment calculation — no tangent geometry needed." },
        { k: "trap", t: "Using L/3 instead of L/4 for the centroid of the cantilever's UDL M/EI diagram. That diagram is a parabolic <b>spandrel</b> (area BH/3, centroid at L/4 from the deep end, 3L/4 from the free end), not a triangle (area BH/2, centroid at L/3). Mixing them gives WL⁴/6EI or similar wrong answers instead of WL⁴/8EI." },
        { k: "real", t: "Conjugate-beam thinking is how stepped or haunched (non-prismatic) members are handled by hand — divide the BMD by the local EI to get the M/EI load, then treat it like any SFD/BMD problem." },
      ],
    },

    /* ---------------------------------------------------- revision */
    {
      n: "",
      title: "MACE notes revision — Moment-area and conjugate beam methods (M p.190–197)",
      hi: "पुनरावृत्ति — मोमेंट-एरिया और संयुग्मी बीम विधियाँ",
      blocks: [
        { k: "h", t: "✅ Key points — MACE notes M p.190–197" },
        { k: "list", items: [
          "✅ Moment area method: prismatic and non-prismatic beams; not applicable with an internal hinge (discontinuity); use when M/EI is easy to draw and points of zero slope/deflection are known. (M p.190)",
          "✅ Derivation: 1/R = M/EI, ds = R·dθ, ds ≈ dx ⇒ dθ/dx = M/EI ⇒ θ₂ − θ₁ = ∫(M/EI)dx. (M p.190)",
          "✅ Mohr's 1st theorem (theorem of slope): angle between tangents at ① and ② = area of M/EI diagram between ① and ②. (M p.190–191)",
          "✅ Cantilever, P at tip: θB = PL²/2EI; moment M at tip: θB = ML/EI. (M p.191)",
          "✅ Cantilever, P at tip, slope at mid-length: θB = 3PL²/8EI (ordinate at mid-length PL/2EI; notes' 'PL/AE' should read PL/EI). (M p.191)",
          "✅ Cantilever, P at a from fixed end: θB = θC = Pa²/2EI — curve beyond the load is a straight line. (M p.192)",
          "✅ Mohr's 2nd theorem (theorem of deflection): vertical intercept at point 2 from the tangent at point 1 = moment of M/EI area between ① and ② about point 2; V₁₋₂ = Area × x̄₁, V₂₋₁ = Area × x̄₂ (may differ). (M p.192)",
          "✅ Cantilever: Δ_B = PL³/3EI (centroid 2L/3 from tip); end moment Δ_B = ML²/2EI. (M p.193)",
          "✅ SS beam, central P: θ_A = θ_B = PL²/16EI; Δc = CC₂ − C₁C₂ = PL³/32EI − PL³/96EI = PL³/48EI. (M p.193)",
          "✅ Conjugate beam method: prismatic and non-prismatic beams, including internal hinges; the real beam's M/EI diagram applied as load. (M p.194)",
          "✅ θ_A = V_B-A / L; θc = reaction at A in CB − M/EI load up to C = SF at C in CB. (M p.194–195)",
          "✅ Slope in real beam = SF in conjugate beam; deflection in real beam = BM in conjugate beam. (M p.195)",
          "✅ Construction: same span; supports chosen to satisfy the real beam's slope/deflection conditions — fixed ↔ free, internal hinge ↔ intermediate support (Example 1). (M p.195)",
          "✅ Signs: −ve BMD → upward M/EI load, +ve BMD → downward; +ve SF ↑[+]↓ → clockwise (+θ); −ve SF → anticlockwise (−θ); sagging (+) BM → downward deflection, hogging (−) → upward. (M p.196)",
          "✅ CB Q.1 end moment: Δ_B = ML²/2EI, θ_B = ML/EI; Q.2 UDL cantilever: Δ = WL⁴/8EI, θ = WL³/6EI (spandrel area BH/3, centroid L/4 from fixed end). (M p.196)",
          "✅ CB Q.3 cantilever, P at mid-length: θ_B = θc = PL²/8EI, Δ_B = PL³/24EI, Δc = 5PL³/48EI. (M p.197)",
          "✅ CB Q.4 SS beam, central P: θ_A = θ_B = PL²/16EI, Δc = PL³/48EI. (M p.197)",
          "✅ Source difference: take the first moment about the point where the intercept is measured (MACE) — the older notes' 'x̄ from the point of maximum slope' holds only for the cantilever tip. (M p.192; §5.3)",
        ] },
      ],
    },
  ];
  var tail = ch.sections.pop();          // keep the chapter's closing section last
  add.forEach(function (s) { ch.sections.push(s); });
  ch.sections.push(tail);
  ch.sections.forEach(function (s, i) { s.n = ch.n + "." + (i + 1); });
})();
