/* ============================================================
   IRRIGATION ENGINEERING AND WATER RESOURCES · COMPLETE NOTES
   Chapters 4–6
   Irrigation efficiencies & consumptive use · Soil-moisture
   relationship & irrigation scheduling · Canal irrigation
   system — layout, alignment and design capacity
   Source: handwritten class notes (236 pp, Jaspal Sir), cited as p.N
   ============================================================ */

window.DB = window.DB || {};
(function () {
  const hb = (DB.handbooks || []).find((h) => h.id === "irr");
  if (!hb) { console.error("[irr2] handbook irr not loaded yet"); return; }
  hb.chapters.push(

    /* ============================================================ CH 4 */
    {
      id: "irr-4",
      n: 4,
      title: "Irrigation Efficiencies, Consumptive Use and Evapotranspiration",
      hi: "सिंचाई दक्षताएँ, उपभोज्य उपयोग और वाष्पोत्सर्जन",
      blurb: "The five irrigation efficiencies (conveyance, application, storage, distribution, use) with a full worked numerical; evapotranspiration, transpiration ratio, the phytometer and lysimeter; effective rainfall and the CIR/NIR/FIR chain; and the two indirect (empirical) methods for consumptive use — Blaney-Criddle and the Hargreaves Class-A Pan method — each with a complete GIR worked example.",
      mins: 26,
      sections: [
        {
          n: "4.1",
          title: "Crop rotation and the irrigation efficiencies",
          hi: "फसल चक्र और सिंचाई दक्षताएँ",
          blocks: [
            { k: "h", t: "📘 Notes — p.39–42" },
            { k: "def", term: "Crop rotation", t: "Growing the <b>same</b> crop repeatedly on the same field reduces soil fertility (nutrients get depleted or accumulate in excess). Growing <b>different, complementary crops in rotation</b> lets the land regain its fertility/strength instead of lying fallow. (p.39)" },
            { k: "list", items: [
              "<b>Suggested rotations (p.39):</b> (i) Rice → Gram, (ii) Cotton → Juar → Gram, (iii) Wheat → Juar → Gram.",
              "<b>Cash crops</b> — crops that must be processed/marketed and cannot be consumed directly by the cultivator (e.g. jute, sugarcane); all non-food crops fall in this category, food crops are excluded. (p.38)",
            ] },
            { k: "h", t: "Irrigation efficiencies — general idea (p.39–40)" },
            { k: "def", term: "Irrigation efficiency", t: "The efficiency of any system depends on the output and input of the parameter (water) involved — it is the <b>ratio of output water to input water</b>. The difference between output and input water is termed <b>losses</b>: η ∝ 1/(losses of H₂O), i.e. higher the losses, lower the efficiency. (p.39–40)" },
            { k: "p", t: "The notes sketch the full conveyance-to-field chain: water is diverted at a weir/barrage on a river, carried through the canal system (with losses shown as red arrows along the way) to the field, where the depth of penetration into the root zone (V<sub>f</sub>) and runoff losses are marked in a cross-section of the field. Each named efficiency below isolates one stage of this chain. (p.40)" },
            { k: "h", t: "① Efficiency of water conveyance (η_c)" },
            { k: "eq", expr: "ηc = Vf/Vi × 100", where: [
              ["Vf", "water delivered into the field at the outlet point"],
              ["Vi", "water entering the main channel at its starting point"],
            ] },
            { k: "p", t: "Accounts for <b>conveyance losses</b> along the canal/channel system. (p.40–41)" },
            { k: "h", t: "② Efficiency of water application (η_a)" },
            { k: "eq", expr: "ηa = VRZ/Vf × 100", where: [
              ["VRZ", "quantity of water stored in the root zone"],
              ["Vf", "quantity of water actually delivered into the field"],
            ] },
            { k: "p", t: "Represents losses in the form of <b>runoff</b>. (p.41)" },
            { k: "h", t: "③ Efficiency of water storage (η_s)" },
            { k: "eq", expr: "ηs = VRZ/VRRZ × 100", where: [
              ["VRZ", "water stored in the root zone during irrigation"],
              ["VRRZ", "water required in the root zone prior to irrigation"],
            ] },
            { k: "p", t: "Represents the extent of filling (“choking”) of voids in the root zone. (p.41)" },
            { k: "h", t: "④ Efficiency of water use (η_u)" },
            { k: "eq", expr: "ηu = Vu/Vf × 100", where: [
              ["Vu", "volume of water beneficially used by the crop for growth (including leaching water requirement)"],
              ["Vf", "quantity of water delivered"],
            ] },
            { k: "h", t: "⑤ Efficiency of water distribution / uniformity coefficient (η_d)" },
            { k: "eq", expr: "ηd = (1 − d/D) × 100", where: [
              ["D", "mean depth of water stored during irrigation"],
              ["d", "average of the absolute deviations of the stored depth from the mean D"],
            ] },
            { k: "p", t: "Represents the extent to which water has been distributed / penetrated to a <b>uniform depth</b> throughout the field. (p.42)" },
            { k: "eg", title: "Uniformity coefficient (η_d) from measured depths", given: "Six depths measured along a 3 m span of field: 2.0, 1.9, 1.8, 1.6, 1.5, 1.4 (units as in the notes).", steps: [
              { t: "Mean depth D", w: "D = (2+1.9+1.8+1.6+1.5+1.4)/6 = 1.7" },
              { t: "Average absolute deviation d", w: "d = (|2-1.7|+|1.9-1.7|+|1.8-1.7|+|1.6-1.7|+|1.5-1.7|+|1.4-1.7|)/6 = 0.2" },
              { t: "Uniformity coefficient", w: "ηd = (1 - 0.2/1.7) × 100 = 88.23%" },
            ], ans: "ηd = 88.23% (p.42)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Follow the water from the canal head to the plant root and each efficiency simply asks 'how much survived this one stage?' — η_c is losses in the <b>channel</b>, η_a is losses to <b>runoff</b> once the water is in the field, η_s is how completely the root-zone deficit actually got refilled, η_u folds in the water that is beneficially used (including leaching), and η_d is the odd one out — it is not about quantity lost at all, but about how <b>evenly</b> the delivered water spread across the field." },
            { k: "trap", t: "Do not confuse the denominators: η_c and η_a both divide by a volume 'delivered/entering' quantity (V_i, V_f respectively), while η_s divides by V<sub>RRZ</sub> — the water that was <b>required</b>, not the water that was applied. Mixing these denominators up is the most common slip when solving a multi-efficiency numerical (see 4.2)." },
          ],
        },
        {
          n: "4.2",
          title: "Worked numerical — computing all five irrigation efficiencies",
          hi: "पाँचों सिंचाई दक्षताओं की गणना — हल उदाहरण",
          blocks: [
            { k: "h", t: "📘 Notes — p.43–44" },
            { k: "eg", title: "All five efficiencies for one irrigation event", given: "A stream of 150 l/s was diverted from a canal and 120 l/s delivered to the field. An area of 1.5 ha was irrigated for 8 hr. Effective root-zone depth = 1.7 m. Runoff loss in the field = 400 m³. Depth of penetration varied from 1.7 cm at the head of the field to a doubtful reading (transcribed as '1[?]' cm) at the tail. Available moisture-holding capacity of the soil = 20 cm per metre depth of soil. Irrigation was started at a moisture-extraction level of 40% of available moisture; leaching requirement = 200 m³.", steps: [
              { t: "① Conveyance efficiency", w: "ηc = 120/150 × 100 = 80%" },
              { t: "② Application efficiency — volume applied and runoff", w: "Vi (applied in 8 hr) = 120 × 8 × 60 × 60 = 3456 m³\nRunoff loss = 400 m³\nVRZ = 3456 - 400 = 3056 m³\nηa = 3056/3456 × 100 = 88.42%" },
              { t: "③ Storage efficiency", w: "Moisture-holding capacity of soil = 20 × 1.7 = 34 cm\nMoisture-holding capacity before irrigation (at 40% extraction level) = 34 × 0.6 = 20.4 cm\nVRRZ = 1.5 × 20.4×10⁻² × 10⁴ = 3060 m³  (1 ha = 10⁴ m²)\nηs = 3056/3060 × 100 = 99.86%" },
              { t: "④ Distribution efficiency (uniformity coefficient)", w: "D = (1.7 + 1)/2 = 1.35 cm\nd = (|1.7-1.35| + |1.35-1|)/2 = 0.35\nηd = (1 - 0.35/1.35) × 100 = 74.07%" },
              { t: "⑤ Water-use efficiency", w: "ηu = Vu/Vf × 100 = (3056 + 200)/3456 × 100 = 3256/3456 × 100 = 94.21%   (leaching requirement of 200 m³ is counted as beneficial use; the notes print 99.21%)" },
            ], ans: "ηc = 80%, ηa = 88.42%, ηs = 99.86%, ηd = 74.07%, ηu = 94.21% (the notes print ηu = 99.21%) (p.43–44)" },
            { k: "note", t: "<b>Correction (v45):</b> ηu = (3056 + 200)/3456 = 3256/3456 = <b>94.21%</b>. The notes' 99.21% is an arithmetic slip — it cannot be right, since adding only 200 m³ of leaching water to 3056 m³ cannot lift the ratio from 88.42% (ηa) to above 99%." },
            { k: "trap", t: "Two readings in this problem are doubtful/inconsistent in the source transcript and are carried forward honestly rather than silently corrected: (i) the tail-of-field penetration depth is recorded only as '1[?]' cm (the exact figure is illegible — the worked value of D = 1.35 cm in step ④ backs out a tail depth of 1 cm, which is used above); (ii) the transition from '40% moisture-extraction level' to 'moisture-holding capacity before irrigation = 34×0.6 = 20.4 cm' is not spelled out algebraically in the notes — it is used here exactly as the source applies it. (p.43–44)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice how ηs comes out almost 100% here (99.86%) while ηa is only 88.42% — that is because ηa is penalised by the 400 m³ that ran off the field entirely, while ηs only asks whether the water that <b>did</b> stay in the root zone (V<sub>RZ</sub>) was close to what was actually needed there (V<sub>RRZ</sub>). A field can lose a lot to runoff (poor ηa) while still filling its root-zone deficit almost exactly (excellent ηs) — the two efficiencies are answering different questions about the same irrigation event." },
          ],
        },
        {
          n: "4.3",
          title: "Evapotranspiration, transpiration ratio and its measurement",
          hi: "वाष्पोत्सर्जन, वाष्पोत्सर्जन अनुपात और इसका मापन",
          blocks: [
            { k: "h", t: "📘 Notes — p.44–47" },
            { k: "def", term: "Consumptive use (Cu)", t: "The amount of water used in <b>evapotranspiration</b> from a vegetated area, plus the water used by the plant in its metabolic processes for building new tissue. Since the metabolic-activity component is very small, it is neglected and <b>Cu is taken equal to evapotranspiration (ET)</b>. (p.44–45)" },
            { k: "def", term: "Evapotranspiration (ET)", t: "The total water used by the plant in (a) <b>transpiration</b> from the plant itself, and (b) <b>evaporation</b> from the adjacent soil (or any other water body, if the plant grows in water). ET/Cu varies with crop, and for the same crop with time and place. (p.45)" },
            { k: "def", term: "Transpiration", t: "The process by which water in a living plant, during photosynthesis, passes through its leaves into the atmosphere as part of its growth. Transpiration occurs during <b>daylight hours</b> — about 95% of it during photosynthesis — while <b>evaporation is continuous</b> throughout day and night. Transpiration loss depends on both available sunlight and available soil moisture, and differs plant to plant. (p.45)" },
            { k: "h", t: "Transpiration ratio (TR)" },
            { k: "eq", expr: "TR = Total mass of water transpired by plant / Mass of dry matter produced", where: [] },
            { k: "list", items: [
              "TR for <b>wheat</b>: 300–600 (average 450). (p.46)",
              "TR for <b>rice</b>: 600–800 (average 700). (p.46)",
            ] },
            { k: "h", t: "Phytometer method (lab measurement of transpiration)" },
            { k: "p", t: "A <b>phytometer</b> is a closed, watertight tank containing enough soil to nourish the plant; water is applied artificially over the plant's growth period, and transpiration is measured as: (p.46)" },
            { k: "eq", expr: "T = M1 + M − M2", where: [
              ["T", "transpiration"],
              ["M1", "initial mass of the instrument"],
              ["M", "total mass of water added during the full growth period"],
              ["M2", "final mass of the instrument"],
            ] },
            { k: "note", t: "Phytometer results do not exactly match actual field conditions, since exact field conditions cannot be simulated; <b>screened shelters</b> are observed to give results about 10% lower. (p.46–47)" },
            { k: "cmp", t: "Potential vs. Actual Evapotranspiration (p.47)", cols: ["Definition", "Depends on", "Measured by"], rows: [
              ["Potential Evapotranspiration (PET)", "ET when soil moisture is freely available to completely meet the plant's evaporation + transpiration needs", "Climatic factors", "—"],
              ["Actual Evapotranspiration (AET)", "The actual amount of water used for evapotranspiration", "Type of soil and crop", "Lysimeter"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "PET is a <b>demand</b> figure (what the atmosphere/climate wants to pull from a well-watered crop), while AET is a <b>supply-limited</b> figure (what the crop actually gets, capped by soil and crop type). PET = AET only when the soil can keep up with atmospheric demand at every moment; once the soil dries below that point, AET falls below PET even though the climatic demand hasn't changed. This is exactly the gap that later shows up as OMC / permanent wilting point in Chapter 5 — the soil simply stops being able to supply water fast enough." },
            { k: "trap", t: "Do not use the phytometer figure directly as a field design value without adjustment — the method is explicitly flagged in the notes as not matching actual field conditions (screened-shelter readings run ~10% low), because the artificial, enclosed setup cannot reproduce true field exposure, wind and root-zone conditions." },
          ],
        },
        {
          n: "4.4",
          title: "Effective rainfall, CIR / NIR / FIR and factors affecting consumptive use",
          hi: "प्रभावी वर्षा, CIR/NIR/FIR और उपभोज्य उपयोग को प्रभावित करने वाले कारक",
          blocks: [
            { k: "h", t: "📘 Notes — p.47–51" },
            { k: "def", term: "Effective / useful rainfall (Re)", t: "The portion of rainfall, falling over a cropped area during the crop's growing period, that is actually utilized by the crop to meet its ET requirement — thereby reducing the crop's irrigation requirement. It is found by subtracting from total rainfall: (i) evaporation, (ii) deep percolation, (iii) runoff. (p.47–48)" },
            { k: "eq", expr: "Re = RT − RV − RS − RR", where: [
              ["RT", "total rainfall"],
              ["RV, RS", "losses to evaporation and to deep percolation down to the ground-water table"],
              ["RR", "runoff loss"],
            ] },
            { k: "note", t: "The <b>ratio factor (γ)</b> represents the portion of rainfall used by the plant for ET; per the notes, this factor is smaller for a rainfall spread widely over the whole area than for the same rain falling in a scattered, more concentrated manner over a smaller area. (p.48)" },
            { k: "h", t: "Empirical (monthly) formulas for useful rainfall" },
            { k: "eq", expr: "Re = 0.8R − 0.25 mm   if R > 75 mm/month     ;     Re = 0.6R − 10 mm   if R < 75 mm/month", where: [["R", "total rainfall, mm/month"]] },
            { k: "h", t: "CIR, NIR and FIR (p.49)" },
            { k: "def", term: "Consumptive Irrigation Requirement (CIR)", t: "The portion of consumptive use that must be satisfied through irrigation. <b>CIR = Cu − Re</b>." },
            { k: "def", term: "Net Irrigation Requirement (NIR)", t: "The portion of consumptive use that must be satisfied by irrigation <b>along with the leaching requirement</b>. <b>NIR = CIR + Leaching requirement = Cu − Re + Leaching requirement</b>." },
            { k: "def", term: "Field Irrigation Requirement (FIR)", t: "NIR plus surface runoff losses in the field. <b>FIR = NIR + Runoff loss</b>." },
            { k: "h", t: "Factors affecting consumptive use (p.50)" },
            { k: "list", items: [
              "<b>① Humidity</b> — higher humidity → more water already in the air's voids → less vaporization → lower Cu.",
              "<b>② Type of soil</b> — permeable soil has interconnected voids, so water evaporates with less obstruction → higher Cu.",
              "<b>③ Topography of soil</b> — irregular topography exposes more surface area to the atmosphere → more evaporation → higher Cu.",
              "<b>④ Base period</b> — a longer base period for the same crop increases its total consumptive use.",
              "<b>⑤ Mean monthly temperature</b> — higher average temperature → higher rate of vaporization → higher Cu.",
            ] },
            { k: "eg", title: "NIR of Jawar over its full crop period", given: "Jawar sown 16 Oct, grown to 2 Feb. Water is assumed needed only to meet the crop's evapotranspiration; leaching requirement = 0.", steps: [
              { t: "Month-wise Cu, Re and NIR = Cu − Re", w: "Oct 16-31: Cu=37, Re=31, NIR=6\nNov 1-30: Cu=84, Re=21, NIR=63\nDec 1-31: Cu=155, Re=7, NIR=148\nJan 1-31: Cu=188, Re=2.5, NIR=185.5\nFeb 1-2: Cu=13, Re=1, NIR=12   (mm)" },
              { t: "Total NIR over the crop period", w: "ΣNIR = 6 + 63 + 148 + 185.5 + 12 = 414.5 mm  over a Base Period of 16 + 30 + 31 + 31 + 2 = 110 days  (the notes print the total as 414.9 mm)" },
              { t: "Average NIR per day", w: "NIR/day = 414.5/110 = 3.77 mm/day" },
            ], ans: "Total NIR = 414.5 mm over 110 days; ≈ 3.77 mm/day (p.50–51)" },
            { k: "note", t: "<b>Correction (v45):</b> the month-wise NIR values add up to exactly 6 + 63 + 148 + 185.5 + 12 = <b>414.5 mm</b>; the 414.9 mm total printed in the notes is an addition slip. The notes' own per-day step already used 414.5, so 3.77 mm/day is unchanged." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "CIR → NIR → FIR is a chain of successively <b>larger</b> water demands: CIR is the bare crop-water gap after rainfall, NIR adds on the water needed to flush salts out of the root zone (leaching), and FIR further adds the water that will inevitably be lost to runoff once it is actually applied in the field. This is exactly the same idea, run in reverse, as the efficiency chain in section 4.1 — going from 'what the crop needs' outward to 'what must be delivered at the field' is dividing by ηa and adding runoff, while going from 'what is delivered' back to 'what the crop needs' is the ηa, ηs route." },
          ],
        },
        {
          n: "4.5",
          title: "Indirect methods for consumptive use — Blaney-Criddle and Hargreaves Class-A Pan",
          hi: "अप्रत्यक्ष विधियाँ — ब्लेनी-क्रिडल और हारग्रीव्स क्लास-A पैन विधि",
          blocks: [
            { k: "h", t: "📘 Notes — p.51–57" },
            { k: "h", t: "① Blaney-Criddle equation" },
            { k: "eq", expr: "Cu = (KP/40)[1.8t + 32]   (Cu in cm, t in °C)     ;     Cu = KPt/40   (Cu in cm, t in °F)", where: [
              ["K", "crop factor — found experimentally, depends on the particular area's conditions"],
              ["t", "mean monthly temperature"],
              ["P", "monthly % of annual daylight hours occurring in that period"],
            ] },
            { k: "note", t: "K values for the crops of the Indian sub-continent are <b>not available</b>, hence this method is <b>not suitable for use in India</b> per the notes — it is nonetheless worked here as the standard empirical method. (p.51–52)" },
            { k: "eg", title: "GIR to irrigate 5000 ha by Blaney-Criddle", given: "Monthly temp (°F), % sunshine hours (P), rainfall R(mm) and crop factor K for 12 months (Jun–May). Assume 80% effective precipitation; ηa = 50% (field application); ηc = 75% (canal conveyance).", steps: [
              { t: "Monthly Cu = KPt/40, summed over the year", w: "Jun 13.85, Jul 16.25, Aug 14.89, Sep 12.85, Oct 8.75, Nov 6.435, Dec 4.5, Jan 6.2, Feb 8.67, Mar 9.24, Apr 9.54, May 12.49 (cm)\nTotal Cu = 123.665 cm  (the notes print 133.673 cm)" },
              { t: "Effective rainfall and CIR", w: "ΣR ≈ 558 mm = 55.8 cm; Re = 80% of R = 0.8 × 55.8 = 44.64 cm  (the source page shows this step's product as '94.64 cm', which is inconsistent with 0.8×55.8; the CIR figure that follows matches 44.64, not 94.64, so 44.64 is used here — flagged as a probable transcription slip in the source)\nCIR = Cu - Re = 123.665 - 44.64 = 79.03 cm  (notes: 133.673 - 44.64 ≈ 89 cm)" },
              { t: "NIR, FIR, GIR", w: "NIR = CIR + Leaching = 79.03 + 0 = 79.03 cm\nFIR = NIR/ηa = 79.03/0.5 = 158.05 cm\nGIR (WIR) = FIR/ηc = 158.05/0.75 = 210.73 cm\n(notes, carrying 89 cm: FIR = 178 cm, GIR = 237.3 cm)" },
              { t: "Volume at head of canal for 5000 ha", w: "V = 210.73×10⁻² m × 5000×10⁴ m² = 105.37×10⁶ m³ ≈ 105.4 million m³  (the notes, with GIR = 237.33 cm, print 118.665 'm-m3', i.e. million m³)" },
            ], ans: "Total Cu = 123.665 cm; CIR = NIR ≈ 79.0 cm; FIR ≈ 158.1 cm; GIR (WIR) ≈ 210.7 cm; volume required ≈ 105.4 Mm³ (the notes print Cu = 133.673, CIR = NIR = 89, FIR = 178, GIR = 237.3 cm and 118.665 Mm³) (p.52–53)" },
            { k: "note", t: "<b>Correction (v45):</b> the twelve monthly Cu values listed in the notes add up to <b>123.665 cm</b>, not the 133.673 cm printed (a 10.008 cm addition slip — or one monthly value was mis-copied; the monthly t, P, K data are not available to tell which). Carrying 123.665 cm through gives CIR = NIR ≈ 79.0 cm, FIR ≈ 158.1 cm, GIR ≈ 210.7 cm and about 105.4 million m³ at the canal head for 5000 ha." },
            { k: "eg", title: "Total, average and peak monthly Cu for Paddy", given: "Monthly consumptive use for Paddy, Jun–Nov (partial Nov).", steps: [
              { t: "Monthly Cu (cm)", w: "Jun 1-30: 27, Jul 1-31: 23, Aug 1-31: 23, Sep 1-30: 21, Oct 1-31: 25, Nov 1-24: 15" },
              { t: "Total and average daily Cu", w: "Total Cu = 134 cm\nAvg daily Cu = Total Cu / Base Period = 134/177 = 0.757 ≈ 0.76 cm/day  (Base Period = 30+31+31+30+31+24 = 177 days; the notes truncate to 0.75)" },
              { t: "Average monthly and peak monthly Cu", w: "Avg monthly Cu = 0.757 × 30 = 22.7 cm/month  (the notes print 0.75 × 30 = 22.5)\nPeak monthly Cu = 27 cm (June)" },
            ], ans: "Total Cu = 134 cm; avg daily Cu ≈ 0.76 cm/day; avg monthly Cu ≈ 22.7 cm/month (the notes print 0.75 and 22.5); peak monthly Cu = 27 cm (p.53–54)" },
            { k: "note", t: "<b>Correction (v45):</b> 134/177 = 0.757 cm/day, which rounds to 0.76, not 0.75; the average monthly Cu is therefore 0.757 × 30 ≈ <b>22.7 cm</b> rather than 22.5 cm. Total (134 cm) and peak (27 cm) are unchanged." },
            { k: "h", t: "② Hargreaves Class-A Pan evaporation method" },
            { k: "def", term: "Consumptive use coefficient (K)", t: "In this method, ET/Cu is related to pan evaporation (Ep) by a constant K: <b>ET (Cu) = K × Ep</b>, so <b>K = ET/Ep</b>. K differs for different crops, and for the same crop at different places, since it depends on the crop, its growth stage, location and soil type. Crops are divided into 8 groups, each with its own K-vs-%-growing-season curve; K values are available for Indian sub-continent crops, so this method is readily usable in India. (p.54–55)" },
            { k: "def", term: "Standard Class-A Pan", t: "1.2 m diameter, 25 cm deep, bottom raised 15 cm above ground level; water depth in the pan is maintained 5–7.5 cm below the top of the pan. Ep is measured directly as the quantity of water evaporated from this standard pan. (p.54–55)" },
            { k: "eg", title: "GIR for a Group-D wheat crop by the Hargreaves method", given: "Wheat grown 1 Nov to 15 March (Base Period B = 135 days). K-vs-%-growing-season table for Group D wheat; monthly Re; monthly Class-A pan Ep; FIR = ηa = 70%, GIR(WIR) basis ηc = 75%; net pre-sowing requirement = 7 cm; percolation losses nil throughout.", steps: [
              { t: "% growing season (g = t/B×100) and ET = K×Ep by month", w: "Nov 1-30 (t=15, g=11%, K=0.16, Ep=13): ET=2.08\nDec 1-31 (t=45, g=33%, K=0.44, Ep=11): ET=4.84\nJan 1-31 (t=76, g=56%, K=0.72, Ep=7): ET=5.04\nFeb 1-28 (t=106, g=78%, K=0.90, Ep=15): ET=13.5\nMar 1-15 (t=127, g=94%, K=0.6, Ep=10): ET=6.0" },
              { t: "Total Cu, CIR, NIR", w: "Total Cu = ΣET = 31.46 cm\nRe over the period is recorded only as an unclear figure ('B[?]' in the source); back-solving from the CIR given next implies Re ≈ 8 cm\nCIR = Cu - Re = 31.46 - 8 = 23.46 cm\nNIR = CIR + Leaching req = 23.46 + 0 = 23.46 cm" },
              { t: "FIR and GIR", w: "FIR = NIR/ηF = 23.46/0.7 = 33.51 cm\nGIR (WIR) = FIR/ηc = 33.51/0.75 = 44.68 cm" },
              { t: "Including pre-sowing requirement", w: "GIR (WIR) including 7 cm pre-irrigation requirement = 44.68 + 7 = 51.69 cm" },
            ], ans: "Total Cu = 31.46 cm; CIR = 23.46 cm; NIR = 23.46 cm; FIR = 33.51 cm; GIR (WIR) = 44.68 cm, or 51.69 cm including pre-sowing water (p.55–57)" },
            { k: "note", t: "<b>Convention (v45):</b> the notes add the 7 cm pre-sowing requirement directly to the GIR. Because it is stated as a <b>net</b> requirement, many textbooks first add it to the NIR and then divide by both efficiencies: (23.46 + 7)/(0.7 × 0.75) ≈ 58.0 cm. Check which convention your syllabus or question expects." },
            { k: "trap", t: "This section carries forward two doubtful readings from the source rather than silently fixing them: the effective-rainfall figure in the Blaney-Criddle worked example (recorded as '94.64 cm', arithmetically inconsistent with 0.8×R and with the CIR that follows it — 44.64 cm is used instead), and the seasonal Re in the Hargreaves wheat example (recorded only as 'B[?]', with ≈8 cm inferred from the stated CIR). Always re-derive Re from R directly when re-using these numbers for a new problem." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Blaney-Criddle and Hargreaves are two different empirical proxies for the same quantity (Cu): Blaney-Criddle ties Cu to <b>temperature and daylight hours</b> (climate-only), while Hargreaves ties Cu to <b>measured pan evaporation</b> — which already bundles in temperature, humidity, wind and sunshine. That is precisely why the notes say Blaney-Criddle's K values are not available for India (nobody had calibrated the temperature-based coefficient here) while Hargreaves' K values, tied to the directly-measurable pan, are available and standard practice." },
          ],
        },
      ],
    },

    /* ============================================================ CH 5 */
    {
      id: "irr-5",
      n: 5,
      title: "Soil-Moisture Relationship and Irrigation Scheduling",
      hi: "मृदा-नमी संबंध और सिंचाई अनुसूची",
      blurb: "Soil moisture zones from the aeration zone down to ground water; field capacity, hygroscopic/capillary water, permanent wilting point, readily available moisture, OMC and equivalent moisture; the derivation of depth of water retained in soil; and four full worked irrigation-scheduling numericals, ending with a complete multi-month schedule that fixes both irrigation dates and depths.",
      mins: 25,
      sections: [
        {
          n: "5.1",
          title: "Soil moisture zones — aeration, root zone and ground water",
          hi: "मृदा-नमी क्षेत्र — वातायन, जड़ क्षेत्र और भूजल",
          blocks: [
            { k: "h", t: "📘 Notes — p.57–59" },
            { k: "p", t: "The notes describe a vertical soil section: irrigation water applied at the surface, with two zones stacked above the water table (WT) — a <b>zone of aeration</b>, itself split into the upper <b>soil-moisture</b> band and an <b>intermediate</b> band (with a capillary water zone just above WT) — and below WT, the <b>zone of saturation</b> / ground water zone. A <b>zone of rock fracture</b> is marked below the aeration zone on the far left of the sketch. (p.57)" },
            { k: "def", term: "Ground water vs. soil moisture", t: "Water <b>below</b> the water table is ground water; water <b>above</b> the water table is soil moisture. (p.57)" },
            { k: "def", term: "Soil / root water zone", t: "The portion of the zone of aeration into which plant/crop roots penetrate to absorb moisture and nutrients from the soil. When water falls on the ground (irrigation or rainfall), part of it is absorbed into this root zone, and the rest flows down under gravity to meet the ground-water table. (p.57–58)" },
            { k: "p", t: "A second sketch plots soil wetness against time as a repeating sawtooth: the top line is <b>Field Capacity (FC)</b>; the curve falls after each irrigation event to the <b>OMC</b> line before the next irrigation. The band between FC and OMC is the <b>readily available water</b>; the wider band down to <b>Permanent Wilting Point (PWP)</b> is the full <b>available water</b>, with the OMC-to-PWP portion labelled <b>non-readily available</b>. Below PWP is <b>non-available water</b>. The width of one full sawtooth cycle is the <b>frequency of irrigation</b>; the whole span shown is the <b>Base Period</b>. (p.57–58)" },
            { k: "def", term: "Field capacity (FC)", t: "Immediately after water is applied, a certain amount of water is retained on the surface of soil particles by molecular attraction and by (comparatively weak) chemical/adsorption bonds. This water cannot easily be drained by gravity, and is called <b>field capacity</b>. FC is the water content of the soil after free drainage has taken place for a sufficient period (2–5 days). (p.58–59)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Read the sawtooth graph as the whole point of this chapter in one picture: irrigation refills the soil to FC, the crop and evaporation steadily draw the moisture down, and the <b>moment it is allowed to drop only as far as OMC</b> before the next irrigation is exactly what the scheduling numericals in 5.4–5.5 are computing — how many days that fall takes (frequency), and how much water restores it back to FC (net application depth)." },
          ],
        },
        {
          n: "5.2",
          title: "Field-capacity water, permanent wilting point and readily available moisture",
          hi: "क्षेत्र-धारिता जल, स्थायी म्लानि बिंदु और सुलभ उपलब्ध नमी",
          blocks: [
            { k: "h", t: "📘 Notes — p.59–62" },
            { k: "eq", expr: "FC = (wt of water retained in a volume of soil against gravity) / (wt of the same volume of dry soil) × 100" },
            { k: "cmp", t: "The two components of field-capacity water (p.59)", cols: ["Definition"], rows: [
              ["Available water / capillary water", "The part of FC water attached to soil particles by surface tension against gravity, and usable by the plant for growth via capillarity."],
              ["Non-available water / hygroscopic water", "The part of FC water that cannot be removed by capillary action of roots/plants, and so is not available for plant growth."],
            ] },
            { k: "def", term: "Permanent wilting point (PWP)", t: "Not all field-capacity water is usable by the plant — the plant can extract water from the soil only up to a certain extent, beyond which it wilts/dries. That water content is the <b>permanent wilting point</b>. (p.61)" },
            { k: "def", term: "Available moisture", t: "The difference between FC water and PWP water — i.e. the water actually available to the plant. Also called capillary water, or the maximum storage capacity of the soil. (p.61)" },
            { k: "def", term: "Readily available moisture", t: "The portion of available moisture that is <b>most easily extracted</b> by plants for growth — approximately <b>75–80% of available moisture</b>. (p.61)" },
            { k: "def", term: "Optimum moisture content (OMC)", t: "The moisture content in the root zone <b>below which</b> water is not easily available/extractable to the crop for its growth. If moisture content falls below OMC during the growth period, crop productivity is affected. (p.61)" },
            { k: "def", term: "Field / soil moisture deficiency", t: "The water required to bring the soil-moisture content of a given soil up to its field capacity. (p.61)" },
            { k: "def", term: "Equivalent moisture", t: "The water retained by a saturated soil after being centrifuged for 30 minutes at a force of roughly 1000× gravity (figure marked doubtful in the source). It is approximately equal to, or slightly less than, FC. (p.62)" },
            { k: "note", t: "Hence the objective of irrigation: irrigate at such an interval/frequency that the moisture content in the root zone <b>never falls below OMC</b>. (p.62)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Line up the four quantities from wettest to driest and the whole vocabulary falls into place: <b>FC</b> (as wet as gravity-drained soil gets) → <b>OMC</b> (the operational 'refill line' — stop letting it fall below here) → <b>PWP</b> (the plant physically cannot pull any more water out) → drier still is where hygroscopic water alone remains, useless to the plant at any point. Readily available moisture is just the FC-to-OMC slice, deliberately kept as a comfortable subset (~75–80%) of the full FC-to-PWP available moisture, so a crop is never irrigated right down to the point of wilting stress." },
            { k: "trap", t: "Do not equate 'available moisture' with 'readily available moisture' — available moisture is the full FC−PWP range, while readily available moisture is only the more easily extracted ~75–80% fraction of it (roughly the FC-to-OMC slice). Using the full FC−PWP range where a scheduling problem calls for the readily-available fraction overstates how long a crop can go between irrigations." },
          ],
        },
        {
          n: "5.3",
          title: "Derivation — depth of water retained in the soil",
          hi: "व्युत्पत्ति — मृदा में धारित जल की गहराई",
          blocks: [
            { k: "h", t: "📘 Notes — p.60–62" },
            { k: "p", t: "Take a soil area of 1 m² and root-zone depth d. Then: (p.60)" },
            { k: "eq", expr: "Volume of soil in root zone = d × 1 = d m³     ;     Dry wt of soil in root zone = Volume × dry density = d·γd" },
            { k: "eq", expr: "Wt of water retained in the soil = F·γd·d     ;     Volume of water = (F·γd·d)/γw" },
            { k: "eq", expr: "Depth of water retained in soil up to field capacity = (F·γd·d)/γw", where: [
              ["F", "field capacity, as a weight ratio = (wt of water retained)/(wt of dry soil)"],
              ["γd, γw", "unit weight of dry soil and of water"],
              ["d", "depth of root zone"],
            ] },
            { k: "note", t: "This quantity is also termed the <b>total water storage capacity of soil</b>, expressed in terms of depth. (p.60)" },
            { k: "eq", expr: "Depth of water retained between two moisture contents w1 and w2 = (w1 − w2)·γd·d/γw" },
            { k: "h", t: "Relating F to porosity" },
            { k: "eq", expr: "F = γw·Vw/(γd·V) = (γw/γd)·η   ⇒   F = (γw × η)/γd", where: [
              ["Vw", "volume of water"],
              ["V", "total volume of soil"],
              ["η", "porosity of the soil"],
            ] },
            { k: "note", t: "This last relation is marked ★★ (boxed) in the source notes as an important result. (p.60)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "This derivation is just a weight-to-depth conversion done carefully: F is defined on a <b>weight</b> basis (water weight ÷ dry-soil weight), but a scheduling calculation needs a <b>depth</b> of water (something you can compare against rainfall, pan evaporation or a canal's delivered depth). Multiplying F by γd/γw converts the weight ratio into an equivalent depth ratio, and multiplying that by the root-zone depth d turns it into an actual depth of water — which is exactly the quantity used in every worked example in 5.4 and 5.5." },
          ],
        },
        {
          n: "5.4",
          title: "Worked numericals — irrigation frequency, application depth and volume",
          hi: "हल उदाहरण — सिंचाई आवृत्ति, प्रयुक्त गहराई और आयतन",
          blocks: [
            { k: "h", t: "📘 Notes — p.62–65" },
            { k: "eg", title: "Q1 — Sandy-loam soil: depletion, frequency, depth, volume and time", given: "Sandy-loam soil holds 140 mm/m depth of water between FC and PWP. Root depth of crop = 30 cm. Allowable depletion of water = 35%. Daily crop water use Cu = 6 mm/day. Area to be irrigated = 60 ha; water diverted at 28 l/s. Surface irrigation application efficiency ηa = 40%. No rainfall or ground-water contribution. Also find the time needed to irrigate a 5 ha farm (as asked in the source question).", steps: [
              { t: "① Allowable depletion depth", w: "Moisture-holding capacity of root zone = 140 × 0.3 = 42 mm\nPermissible depletion = 0.35 × 42 = 14.7 mm  (the readily-available-moisture depth corresponding to the allowable depletion)" },
              { t: "② Frequency of irrigation", w: "Frequency = permissible depletion / daily Cu = 14.7/6 = 2.45 days ⇒ irrigate every 2 days (round down, so the allowable depletion is never exceeded)\n(the notes print 14.7/5 = 2.94 days, i.e. they used Cu = 5 mm/day instead of the stated 6 mm/day, and still rounded to '2 days')" },
              { t: "③ Net and gross depth of water to be applied", w: "Net depth (refilling the full allowable depletion) = 14.7 mm\nGross depth = net depth/ηa = 14.7/0.4 = 36.75 mm  (the notes label this 36.75 mm figure 'net depth' — dividing by ηa makes it the gross depth)\nFor the adopted 2-day interval at 6 mm/day: net = 2 × 6 = 12 mm, gross = 12/0.4 = 30 mm  (the notes' side-lines 10/0.4 = 25 mm for 2 days and 15/0.4 = 37.5 mm for 3 days are based on 5 mm/day)" },
              { t: "④ Volume of water to be applied (gross, whole 60 ha)", w: "Volume = 60×10⁴ m² × 36.75×10⁻³ m = 2.205×10⁴ m³ = 2.205 ha-m" },
              { t: "⑤ Time required to irrigate a 5 ha farm at 28 l/s", w: "t = (5×10⁴ m² × 36.75×10⁻³ m)/(28×10⁻³ m³/s) = 1837.5/0.028 = 65,625 s = 18.23 hr ≈ 18 hr 14 min\n(the notes write the area as '9×10⁴', but their answer of 18 hr 13 min is exactly what 5 ha gives — 9 ha would need 32.8 hr)\nFor the whole 60 ha at the same rate: 22,050/0.028 = 787,500 s ≈ 218.75 hr" },
            ], ans: "Allowable depletion (net depth) = 14.7 mm; frequency = 14.7/6 = 2.45 days ⇒ every 2 days; gross depth = 14.7/0.4 = 36.75 mm; gross volume for 60 ha = 2.205 ha-m; time for a 5 ha farm ≈ 18.23 hr ≈ 18 hr 14 min (p.62–63)" },
            { k: "note", t: "<b>Correction (v45):</b> three slips in the notes are fixed here. (1) The frequency was worked with 5 mm/day instead of the stated 6 mm/day: 14.7/6 = 2.45 days, so irrigate every 2 days. (2) 14.7/0.4 = 36.75 mm is the <b>gross</b> depth; the net depth is 14.7 mm. (3) The time line wrote '9×10⁴' m², but 18 hr 13 min is the time for the <b>5 ha</b> farm: 5×10⁴ × 0.03675/0.028 = 65,625 s ≈ 18.2 hr." },
            { k: "eg", title: "Q2 — Frequency of irrigation from FC, PWP and dry density", given: "FC = 28%, PWP = 13%, dry density of soil = 1.3 g/cc, effective root-zone depth = 70 cm, daily consumptive use = 12 mm.", steps: [
              { t: "Available and readily available moisture", w: "Max water storage capacity (available moisture) = FC − PWP = 28 − 13 = 15%\nReadily available moisture, assumed = 0.8 × available moisture = 0.8 × 15 = 12%" },
              { t: "Depth of water stored between FC and OMC", w: "Depth = γd·d·(FC−OMC)/γw = 1.3 × 70 × 0.12 = 10.92 cm" },
              { t: "Frequency of irrigation", w: "Frequency = (10.92 × 10)/12 = 9.1 ≈ 9 days" },
            ], ans: "Depth of readily available water ≈ 10.92 cm; irrigate roughly every 9 days (p.63–64)" },
            { k: "eg", title: "Q3 — Field application efficiency for a rice field", given: "800 m³ applied to a 0.6 ha rice field when soil moisture has fallen to 40% of the available water between FC (36%) and PWP (15%). Root-zone depth = 60 cm. Assume porosity η = 0.4.", steps: [
              { t: "Available and used moisture", w: "Available moisture = FC − PWP = 36 − 15 = 21%\nMoisture used for growth (at 40% depletion) = 21 × 0.6 = 12.6%" },
              { t: "Depth of water needed for growth, via F = γw·η/γd", w: "γd/γw = η/F = 0.4/0.36 = 1.111  (F = field capacity as a fraction, 0.36, as in the source)\nDepth = 1.111 × (60 × 12.6)/100 = 8.4 cm" },
              { t: "Volume and application efficiency", w: "Volume required for growth = 0.6×10⁴ m² × 8.4×10⁻² m = 504 m³  (the notes print '0.6×10⁹ × 8.4×10⁻¹ = 803.5 m³', which is arithmetically wrong)\nηa = VRZ/Vf = 504/800 × 100 = 63%" },
            ], ans: "Water stored in the root zone = 504 m³ (the notes print 803.5 m³); ηa = 504/800 = 63% (p.64–65)" },
            { k: "note", t: "<b>Correction (v45):</b> 0.6 ha × 8.4 cm = 6000 m² × 0.084 m = <b>504 m³</b>, not the 803.5 m³ printed in the notes (and 803.5/800 would be about 100%, not 63%). The notes' final answer is right: ηa = 504/800 = <b>63%</b>. The ratio in step 2 is also 0.4/0.36 = 1.111 (the notes write '0.4/36')." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "All three problems are the same calculation run with different given quantities: (depth of readily-available/needed water) ÷ (application efficiency, if asked for a required depth) — or, run in reverse, (water actually stored) ÷ (water delivered), if asked for the efficiency itself. Once you can compute the depth of water held between any two moisture contents (section 5.3's derivation), frequency, net/gross depth, volume and efficiency are all just different rearrangements of the same handful of quantities." },
          ],
        },
        {
          n: "5.5",
          title: "Extended irrigation-scheduling numerical — full-season dates and depths",
          hi: "विस्तारित सिंचाई अनुसूची — पूर्ण-मौसम तिथियाँ और गहराइयाँ",
          blocks: [
            { k: "h", t: "📘 Notes — p.65–67" },
            { k: "eg", title: "Full-season irrigation schedule — dates and depths of application", given: "No restrictive soil layer within top 1.5 m. Normal root-zone depth = 1.2 m. Bulk density γ = 1.35. FC = 18%, PWP = 7%. Moisture is to be maintained at not less than 1/3 of available retention. Irrigation is applied over a 2-day duration at a uniform rate, exactly compensating the deficiency. Sowing on 1 Nov, soil at FC throughout the root zone. No leaching required. ET rates: 1–30 Nov 1.1 mm/d; 1–31 Dec 1.7 mm/d; 1–31 Jan 2.4 mm/d; 1–28 Feb 1.5 mm/d; 1–25 Mar 3.5 mm/d. Harvest on/after 26 Mar. Effective rainfall of 24 mm, uniform intensity, over 4–19 Jan (inclusive). By season end, only the minimum water needed is left unused in the root zone.", steps: [
              { t: "Available retention and readily-available depth", w: "Available retention = FC − PWP = 18 − 7 = 11%\nDepth readily available for growth (down to 1/3 of retention, i.e. 2/3 of 11% may be drawn down):\n= (γd·d/γw) × (2/3) × 11% = 1.35 × 1.2 m × (2/3) × 0.11 = 0.1188 m = 11.88 cm\n(the notes write d = 1.25 m here and print 11.87 cm; but 1.35 × 1.25 × (2/3) × 0.11 would give 12.38 cm — the 11.87 figure actually comes from the given root-zone depth d = 1.2 m, which is used here)" },
              { t: "Water consumed, 1 Nov to 19 Jan", w: "1–30 Nov: 1.1 × 30 = 3.3 cm\n1–31 Dec: 1.7 × 31 /10 = 5.27 cm\n1–19 Jan (with 24 mm effective rain over days 4–19 reducing net need on those 16 days):\n  2.4 × 3 + (2.4 − 24/16) × 16, in cm = 0.72 + 1.44 = 2.16 cm\nTotal consumed to 19 Jan = 3.3 + 5.27 + 2.16 = 10.73 cm" },
              { t: "Timing of the first irrigation", w: "Days to consume the remaining readily-available moisture = (11.88 − 10.73)/(2.4×10⁻¹ cm/d) = 4.79 days  (notes: 4.75)\n⇒ first irrigation needed about 4–5 days after 19 Jan, i.e. on 24–25 Jan" },
              { t: "Depth applied at the first irrigation", w: "Water required on 24–25 Jan = 10.73 + 4×0.24 + 2×0.24 = 12.17 cm  (refills the root zone back to field capacity)" },
              { t: "Consumption from 26 Jan onward, and the second irrigation", w: "26–31 Jan: 6 × 0.24 = 1.44 cm\n1–28 Feb: 28 × 0.15 = 4.2 cm\n1–25 Mar: 25 × 0.35 = 8.75 cm\nCumulative from 26 Jan = 1.44 + 4.2 + 8.75 = 14.39 cm, which exceeds the 11.88 cm readily-available capacity, so a second irrigation is needed before harvest.\nDays into March to exhaust the readily-available moisture (after the Jan refill) = (11.88 − 1.44 − 4.2)/0.35 = 17.8 days ⇒ second irrigation on 18–19 March" },
              { t: "Depth applied at the second irrigation", w: "Water applied = 14.39 − 11.88 = 2.51 cm  (notes: 2.52)" },
            ], ans: "Two irrigations over the season: 12.17 cm on 24–25 Jan, and 2.51 cm on 18–19 March — total seasonal irrigation depth (delta) ≈ 14.68 cm (the notes print 2.52 cm and 14.69 cm) (p.65–67)" },
            { k: "note", t: "<b>Correction (v45):</b> the readily-available depth must use the given root-zone depth d = 1.2 m: 1.35 × 1.2 × (2/3) × 0.11 = <b>11.88 cm</b>. The notes write 1.25 m but print 11.87 cm — and 1.25 m would actually give 12.38 cm. With 11.88 cm the irrigation dates stay the same, the first depth stays 12.17 cm, and the second depth becomes 2.51 cm (total ≈ 14.68 cm)." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "This is the sawtooth graph from section 5.1 worked out numerically, day by day: start at FC, subtract the ET rate (adjusted downward on the rainy days in January) until the readily-available reserve (11.88 cm) is about to run out, then irrigate exactly enough to refill to FC, and repeat. The two irrigation dates and two applied depths found here are literally the two 'teeth' of that sawtooth for this particular crop season." },
          ],
        },
      ],
    },

    /* ============================================================ CH 6 */
    {
      id: "irr-6",
      n: 6,
      title: "Canal Irrigation System: Layout, Alignment and Design Capacity",
      hi: "नहर सिंचाई प्रणाली — अभिन्यास, संरेखण और डिज़ाइन क्षमता",
      blurb: "The primary/secondary/tertiary canal distribution system and Warabandi; alluvial vs. non-alluvial canals; the three canal-alignment types (watershed, contour, side-slope) with their cross-drainage implications; GCA/CCA, intensity of irrigation, time factor, capacity factor and duty; and worked numericals for fixing canal discharge, ending with a full multi-season main-canal and reservoir-storage problem.",
      mins: 25,
      sections: [
        {
          n: "6.1",
          title: "Canal distribution system, Warabandi, and alluvial vs. non-alluvial canals",
          hi: "नहर वितरण प्रणाली, वारबंदी, और जलोढ़/गैर-जलोढ़ नहरें",
          blocks: [
            { k: "h", t: "📘 Notes — p.68–70" },
            { k: "p", t: "The entire distribution system, from the head of the main canal to the agricultural field, is divided into three systems: (p.68)" },
            { k: "list", items: [
              "<b>(1) Primary distribution system</b> — main canal and branch canal.",
              "<b>(2) Secondary distribution system</b> — distributary and minor.",
              "<b>(3) Tertiary distribution system</b> — watercourse and field channel.",
            ] },
            { k: "def", term: "Warabandi", t: "The integral management of conveying and distributing water under this 3-tier system, with the <b>turn (of different farmers) fixed</b>. By following Warabandi, the turns of different farmers are fixed so that a single farmer does not receive water every day — this reduces losses and allows water to be applied under pressure. (p.68)" },
            { k: "note", t: "The source transcript's page 69 repeats page 68 verbatim (same 'Canal Irrigation System' heading, the same 3-tier distribution list, the same Warabandi note, and the start of 'Classification of Canals') — an apparent duplicate/re-scanned page in the original notes, flagged here rather than silently merged. (p.68–69)" },
            { k: "h", t: "Classification of canals — alluvial vs. non-alluvial (p.68–70)" },
            { k: "cmp", t: "Alluvial vs. non-alluvial canals", cols: ["Soil formation", "Irrigation type used", "River behaviour", "Foundations"], rows: [
              ["Alluvial canal", "Excavated through alluvial soil — formed by continuous deposition of solids carried by running water (rivers)", "Uses direct irrigation rather than storage irrigation", "River tends to change its course", "Hard foundations generally not available"],
              ["Non-alluvial canal", "Excavated through non-alluvial soil — e.g. formed by disintegration of rock in mountainous regions", "Part of storage irrigation", "River hardly changes its course", "Hard foundations generally available"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "The alluvial/non-alluvial distinction and the river's tendency to shift course are directly linked: alluvial soil is itself the product of a river depositing and re-depositing sediment over time, so a river running through it is still actively doing that — shifting channel, undercutting banks — which is exactly why alluvial-canal schemes lean on direct (run-of-river) diversion rather than betting on a stable storage-reservoir offtake point." },
          ],
        },
        {
          n: "6.2",
          title: "Canal alignment — watershed, contour and side-slope canals",
          hi: "नहर संरेखण — जलविभाजक, समोच्च और पार्श्व-ढाल नहरें",
          blocks: [
            { k: "h", t: "📘 Notes — p.70–73" },
            { k: "def", term: "Watershed (ridge) canal", t: "A canal aligned along any watershed or ridge line. The natural limits of the command area of such a channel lie on <b>either side</b> of the channel. (p.70)" },
            { k: "note", t: "Aligning a main or branch canal along the ridge line ensures <b>gravity irrigation on both sides</b> of the canal. Since drainage always flows <b>away</b> from the ridge, no drainage can cross a canal aligned on it — hence <b>no cross-drainage work is required</b>. If the watershed passes through villages or towns, the canal may have to leave the ridge for some distance; depressions in the ridge line may require <b>viaducts or siphons</b> to maintain the canal's FSL. (p.71)" },
            { k: "def", term: "Contour canal", t: "Used where a watershed canal is not feasible — typically hilly areas, where conditions differ vastly from the plains (rivers flow in valleys, so a canal cannot follow a ridge). A contour canal is aligned along a contour, except for the required longitudinal slope, and can irrigate <b>only one side</b> (the other side is at a higher level). (p.71)" },
            { k: "p", t: "Since natural drainage always flows at right angles to the contour, a contour canal <b>does</b> meet drainage crossings in between, so it <b>requires cross-drainage works</b>. Because the river's slope is much steeper than the canal bed slope, the canal encloses more and more command area between itself and the river as it proceeds: SoR = (river-bed fall)/x, SoC = (canal-bed fall)/y, with y ≫ x, so SoC ≪ SoR. (p.72)" },
            { k: "def", term: "Side-slope canal", t: "A canal aligned at right angles to the contours, i.e. along the side slopes. Since natural drainage also flows at right angles to the contours, it never meets this kind of canal, so <b>no cross-drainage work is required</b>. (p.72–73)" },
            { k: "cmp", t: "The three canal-alignment types (p.70–73)", cols: ["Aligned along", "Sides irrigated", "Cross-drainage work"], rows: [
              ["Watershed / ridge canal", "The watershed or ridge line", "Both sides", "Not required — drainage flows away from the ridge"],
              ["Contour canal", "A contour (plus the needed longitudinal slope)", "One side only", "Required — natural drainage crosses the canal at right angles"],
              ["Side-slope canal", "The side slope, at right angles to the contours", "—", "Not required — drainage runs parallel to the contours, never meeting the canal"],
            ] },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Cross-drainage need boils down to one question: does natural drainage run <b>parallel</b> to the canal or does it <b>cross</b> it? A ridge canal sits exactly on the line water flows away from, so drainage never crosses it. A side-slope canal runs at right angles to the contours — the same direction natural drainage already flows — so again, no crossing. Only the contour canal, deliberately cutting <b>across</b> the natural fall of the land to hold a level line, forces every drainage line it meets to cross it, which is why cross-drainage structures (aqueducts, superpassages, etc.) are unavoidable for that one alignment type." },
          ],
        },
        {
          n: "6.3",
          title: "GCA, CCA and the design ratios — intensity, time factor, capacity factor and duty",
          hi: "GCA, CCA और डिज़ाइन अनुपात — तीव्रता, समय कारक, क्षमता कारक और ड्यूटी",
          blocks: [
            { k: "h", t: "📘 Notes — p.73–76" },
            { k: "def", term: "Gross Command Area (GCA)", t: "The total area, bounded within the irrigation boundaries of the project, that can be economically irrigated without considering limitations on the quantity of available water. It includes both cultivable and un-cultivable area (e.g. residential area, roads, forest area). (p.73)" },
            { k: "def", term: "Culturable / Cultivable Command Area (CCA)", t: "The part of GCA on which cultivation is possible. It is further split into (a) the cultivated portion, and (b) the cultivable-but-not-cultivated portion — at any given time, not all cultivable land is actually under cultivation. In the absence of data, <b>CCA may be assumed ≈ 80% of GCA</b>. (p.73–74)" },
            { k: "def", term: "Intensity of irrigation (IOI), seasonal or annual", t: "The whole cultivated portion of CCA is deliberately not irrigated at once — doing so risks water-logging, salinity and dampness (which promote water-borne disease) and demands too much water. IOI is the % of CCA brought under irrigation in a season/year. Example: IOI(Kharif) = 30%, IOI(Rabi) = 35% ⇒ Annual IOI = 65%. Annual IOI is typically 40–60%, but can be extended to 100–180% by growing more than one crop per year on larger parts of the CCA. (p.73–74)" },
            { k: "def", term: "Net and gross sown area", t: "If a crop is sown twice (two sessions) on the same area in a year, that area is sown more than once. <b>Gross sown area = Net sown area + Area sown more than once during the year.</b> (p.74)" },
            { k: "def", term: "Net and gross irrigated area", t: "Area irrigated once during a year = Net Irrigated Area (NIA). Adding the area irrigated more than once gives the <b>Gross irrigated area = Net irrigated area + Area irrigated more than once</b>. (p.74–75)" },
            { k: "eq", expr: "Area to be irrigated  AI = IOI × CCA" },
            { k: "def", term: "Time factor", t: "To avoid over-irrigation (waterlogging, salinity), canals are not allowed to operate on all days of the crop session. Time factor = (actual operating time of the channel) / (crop period). (p.75)" },
            { k: "def", term: "Capacity factor (Cv)", t: "The ratio of the mean supply discharge in a canal during a period to its designed full capacity discharge: <b>Cv = mean discharge / design discharge</b>. Since canals must run near their full design capacity in the Kharif season, Cv ≈ 0.9–0.95 then; since water requirement is lower in the Rabi season, Cv falls to about 0.6–0.7. (p.75)" },
            { k: "def", term: "Full supply coefficient / Duty on capacity", t: "The design duty at the head of the canal — the number of hectares irrigable per cumec of canal capacity at its head. <b>Duty on capacity = (Area irrigated during the base period) / (Design full discharge)</b>. (p.76)" },
            { k: "def", term: "Nominal duty", t: "The ratio of the area actually irrigated by the farmer to the mean supply discharge from the distributary outlet over the crop period. (p.76)" },
            { k: "def", term: "Intensity of cropping (K)", t: "The ratio of gross cropped area to net cultivated area: <b>K = Gross cropped area / Net cultivated area</b>. (p.76)" },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Almost every ratio in this section exists to keep a canal from being over-used on any one patch of land: IOI caps what fraction of CCA is irrigated in a season, time factor caps how much of the crop period the canal actually runs, and capacity factor caps how close to full design discharge it runs on average — all three are deliberately kept below 100% for the same water-logging/salinity reason, and all three feed directly into how big the canal at the head needs to be (section 6.4)." },
          ],
        },
        {
          n: "6.4",
          title: "Fixing the design capacity of a canal — worked discharge numericals",
          hi: "नहर की डिज़ाइन क्षमता तय करना — निर्वहन के हल उदाहरण",
          blocks: [
            { k: "h", t: "📘 Notes — p.76–79" },
            { k: "p", t: "To fix a canal's design capacity, all crops likely to be sown in the area are considered, and the <b>peak</b> rate of water requirement of every crop, in every season of the year, is computed. Peak rate corresponds to the crop's <b>Kor period</b> and <b>Kor depth</b>. The canal capacity must be sufficient for the <b>maximum</b> of the peak demand among all crops, in any one season. For precision, the analysis interval should be as small as possible; normally calculations are done for <b>monthly</b> water requirement, and the result is increased by <b>20–25%</b> to account for peak demand. (p.76–77)" },
            { k: "eg", title: "Q1 — Distributary discharge from average-demand consideration", given: "GCA of a distributary = 6000 ha, 80% culturable. IOI(Rabi) = 50%, IOI(Kharif) = 25%. Average duty at head of distributary = 2000 ha/cumec (Rabi), 900 ha/cumec (Kharif).", steps: [
              { t: "CCA and area to be irrigated each season", w: "CCA = 0.8 × 6000 = 4800 ha\nArea (Rabi) = 0.5 × 4800 = 2400 ha\nArea (Kharif) = 0.25 × 4800 = 1200 ha" },
              { t: "Discharge required, each season", w: "Rabi: 2400/2000 = 1.2 cumec\nKharif: 1200/900 = 1.33 cumec" },
              { t: "Governing (average-demand) discharge", w: "The larger of the two seasonal requirements governs: 1.33 m³/s" },
            ], ans: "Discharge required at the head of the distributary ≈ 1.33 m³/s (p.77–78)" },
            { k: "eg", title: "Q2 — Watercourse discharge with a Kor-period check", given: "CCA of a watercourse = 1200 ha. IOI(sugarcane) = 20%, IOI(wheat) = 40%. Duty(sugarcane) = 730 ha/cumec, Duty(wheat) = 1800 ha/cumec. Time factor = 0.8. Kor period/depth: sugarcane 3 weeks / 17 cm; wheat 4 weeks / 13.5 cm.", steps: [
              { t: "Discharge from average duty (sugarcane and wheat)", w: "φ(sugarcane) = (1200 × 0.20)/730 = 0.328 cumec\nφ(wheat) = (1200 × 0.40)/1800 = 0.266 cumec\nTotal = 0.328 + 0.266 = 0.594 m³/s" },
              { t: "Design discharge accounting for sugarcane's perennial demand", w: "Sugarcane is a perennial crop and needs water for almost the entire year, so the total is divided by the time factor:\nDesign discharge = 0.594/0.8 = 0.744 cumec" },
              { t: "Cross-check via Kor period and Kor depth", w: "Duty from Kor period/depth: D = 864B/Δ  (B = Kor period in days, Δ = Kor depth in cm)\nDs (sugarcane) = 864×3×7/17 = 1067 ha/cumec\nDw (wheat) = 864×4×7/13.5 = 1792 ha/cumec\nφs = (1200×0.20)/1067 = 0.22 cumec\nφwheat = 480/1792 = 0.267 cumec\nTotal (Kor-based) = 0.22 + 0.267 = 0.49 cumec" },
            ], ans: "Design discharge (average-duty basis) ≈ 0.744 cumec; design discharge (Kor-period basis) ≈ 0.49 cumec — the source does not reconcile these two different discharge estimates for the same watercourse, and both are carried forward as given (p.78–79)" },
            { k: "eq", expr: "Duty from Kor period and Kor depth:  D = 864·B/Δ", where: [
              ["D", "duty (ha/cumec)"], ["B", "Kor period, in days"], ["Δ", "Kor depth, in cm"],
            ] },
            { k: "trap", t: "Q2's two answers (0.744 cumec from the average-duty method, 0.49 cumec from the Kor-period method) are both present in the source without any reconciling remark — treat this as the notes presenting two separate estimation approaches for the same discharge rather than a single, agreed final answer. When solving a similar problem, compute both and state clearly which one the question is actually asking for (average seasonal demand vs. the sharper Kor-period peak check)." },
          ],
        },
        {
          n: "6.5",
          title: "Multi-season main canal and reservoir storage — worked numerical",
          hi: "बहु-मौसमी मुख्य नहर और जलाशय भंडारण — हल उदाहरण",
          blocks: [
            { k: "h", t: "📘 Notes — p.79–80" },
            { k: "eg", title: "Q3 — Main canal discharge and gross reservoir storage capacity, 3 crop sessions/year", given: "A main canal off-takes from a storage reservoir and irrigates crops over 3 sessions in a year. Time factor = 0.7. Conveyance loss = 20%; reservoir losses (evaporation + absorption) = 10%; safety factor for late/irregular monsoon = 5%; dead storage = 10%.\n\nCrop data (Crop Period B in days, Area irrigated A in ha, Duty at canal head in ha/cumec):\nSugarcane: B=280, A=315, Duty=630\nOverlap (hot-weather wheat, with sugarcane): B=100, A=70, Duty=630\nJawar (Rabi): B=120, A=4800, Duty=1600\nBajra (monsoon): B=120, A=5600, Duty=2800\nVegetables (hot season): B=120, A=350, Duty=700", steps: [
              { t: "(a) φ (discharge, A/Duty) for each crop", w: "φs (sugarcane) = 315/630 = 0.5 cumec\nφoverlap = 70/630 = 0.11 cumec\nφJ (Jawar) = 4800/1600 = 3 cumec\nφB (Bajra) = 5600/2800 = 2 cumec\nφV (vegetables) = 350/700 = 0.5 cumec" },
              { t: "φ required in each season (sugarcane runs through all three, being perennial)", w: "Hot season = φs + φoverlap + φV = 0.5 + 0.11 + 0.5 = 1.1 cumec\nMonsoon session = φs + φB = 0.5 + 2 = 2.5 cumec\nWinter session = φs + φJ = 0.5 + 3 = 3.5 cumec  (governing — the largest of the three)" },
              { t: "Discharge at the head of the main canal", w: "φ (at canal head) = 3.5/0.7 (time factor) = 5 cumec\n(the notes add that this figure may be further increased 20–25% to obtain the peak discharge, per the general rule in section 6.4)" },
              { t: "(b) Seasonal volumes (V = φ × B days × 86400 s/day)", w: "Vs (sugarcane, B=280) = 0.5×280×86400 = 12.096 Mm³\nVoverlap (B=100) = 0.11×100×86400 = 0.95 Mm³\nVJ (Jawar, B=120) = 3×120×86400 = 31.1 Mm³\nVB (Bajra, B=120) = 2×120×86400 = 20.736 Mm³\nVvegetables (B=120) = 0.5×120×86400 = 5.184 Mm³" },
              { t: "Total volume required and gross reservoir capacity", w: "Total volume required = 12.096+0.95+31.1+20.736+5.184 = 70.07 Mm³\nGross reservoir capacity, with the factors as written in the source = (70.07/0.9) × (1.05/0.9) = 77.86 × 1.1667 = 90.83 Mm³\n(the notes print 91.056 Mm³, which is what you get if the 5% safety margin is applied as ÷0.95 instead of ×1.05: 70.07/(0.9 × 0.9 × 0.95) = 91.06 Mm³)\n(the exact mapping of each 0.9 / 1.05 factor here onto the four stated percentages — 20% conveyance loss, 10% reservoir loss, 5% monsoon safety margin, 10% dead storage — is not fully spelled out step-by-step in the source; the formula and final figure are reproduced here exactly as given)" },
            ], ans: "(a) Discharge at the head of the main canal = 5 cumec (winter session governs); (b) Gross reservoir storage capacity ≈ 90.83 Mm³ by the expression (70.07/0.9)×(1.05/0.9) (the notes print 91.056 Mm³, which corresponds to ÷0.95 for the 5% margin) (p.79–80)" },
            { k: "note", t: "<b>Correction (v45):</b> (70.07/0.9) × (1.05/0.9) works out to <b>90.83 Mm³</b>, not the 91.056 Mm³ printed. The printed figure matches 70.07/(0.9 × 0.9 × 0.95), i.e. the 5% margin applied as a divisor. Both ways are about 91 Mm³; the point is that the printed expression and the printed number do not match." },
            { k: "note", t: "The transcript continues (p.80–82, dated 12 Nov) with a second, larger reservoir-sizing problem — paddy, groundnut, maize, cotton, sugarcane and chillies over a 1.2×10⁵ ha command, with 25% canal loss and 25% dead storage — but the worked month-by-month table is left incomplete across the scanned pages beyond p.80, which is outside this chapter's p.68–80 range; it is flagged here rather than reproduced in a fabricated, completed form." },
            { k: "h", t: "💡 Samjho" },
            { k: "p", t: "Notice that the <b>winter session governs</b> the canal's head discharge (3.5 cumec, vs. 2.5 for monsoon and 1.1 for the hot season) purely because Jawar's demand (φJ = 3 cumec) dominates that season — this is the whole 'design for the peak among all seasons' rule from the opening of section 6.4, worked through numerically. And the perennial sugarcane term (φs = 0.5) appears in <b>every</b> season's total, which is exactly why a perennial crop in the cropping pattern raises the design discharge across the board, not just in its own peak month." },
          ],
        },
      ],
    },
  );
})();
