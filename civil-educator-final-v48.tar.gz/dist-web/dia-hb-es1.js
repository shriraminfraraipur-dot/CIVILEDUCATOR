/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: ESTIMATION & COSTING handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.1 THE COST EQUATION */
  "hb-es-cost": {
    label: "The whole subject in one equation",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="The core of estimating shown as cost equals quantity times rate, with quantity coming from measuring the drawing and rate coming from rate analysis, and the three types of estimate from a rough preliminary figure to a detailed item-by-item estimate.">
      ${hbmk("ce")}
      <text class="em" x="350" y="24" text-anchor="middle">EVERYTHING IN THIS SUBJECT IS ONE EQUATION</text>
      <rect class="soft-b" x="250" y="60" width="200" height="50"/>
      <text class="em" x="350" y="90" text-anchor="middle">COST = QUANTITY × RATE</text>
      <line class="ac" x1="310" y1="112" x2="200" y2="150" marker-end="url(#ce-c)"/>
      <line class="ac" x1="390" y1="112" x2="500" y2="150" marker-end="url(#ce-c)"/>
      <rect class="conc" x="90" y="152" width="220" height="70"/>
      <text class="em" x="200" y="176" text-anchor="middle">QUANTITY</text>
      <text class="lb" x="200" y="198" text-anchor="middle">how much of each item —</text>
      <text class="lb" x="200" y="214" text-anchor="middle">measured off the drawing</text>
      <rect class="conc" x="390" y="152" width="220" height="70"/>
      <text class="em" x="500" y="176" text-anchor="middle">RATE</text>
      <text class="lb" x="500" y="198" text-anchor="middle">cost per unit of that item —</text>
      <text class="lb" x="500" y="214" text-anchor="middle">from rate analysis</text>
      <text class="lb" x="200" y="248" text-anchor="middle">Chapters 3–7: measuring quantities</text>
      <text class="lb" x="500" y="248" text-anchor="middle">Chapter 8: building up rates</text>
      <text class="lb" x="350" y="278" text-anchor="middle">a rough estimate approximates both for a quick figure; a detailed estimate measures every item exactly</text>
    </svg>`,
    caption: "The entire subject reduces to one line: the cost of the work is the quantity of each item multiplied by its rate, summed over all items. Everything else is detail on those two numbers — how you measure the quantity accurately from the drawings, and how you build up the rate from materials, labour and overheads. <strong>A rough estimate approximates both for a quick figure; a detailed estimate pins down every item</strong>, and the difference is only the precision, not the idea.",
  },

  /* ------------------------------------------- 3.1 CENTRE-LINE METHOD */
  "hb-es-centreline": {
    label: "Two ways to measure a wall — and why they agree",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A rectangular building in plan, showing the centre-line method where the total wall length is measured along the centre of the walls, compared with the long-wall short-wall method where long walls are measured out-to-out and short walls in-to-in, with both giving the same quantity.">
      ${hbmk("cl2")}
      <text class="em" x="350" y="24" text-anchor="middle">MEASURE THE WALL LENGTH RIGHT AND THE REST IS EASY</text>
      <text class="em" x="180" y="56" text-anchor="middle">CENTRE-LINE METHOD</text>
      <rect class="soft" x="90" y="72" width="180" height="130" fill="none"/>
      <rect class="soft" x="104" y="86" width="152" height="102" fill="none"/>
      <rect class="hi" x="97" y="79" width="166" height="116" fill="none" stroke-dasharray="5 4"/>
      <text class="lb" x="180" y="140" text-anchor="middle">room</text>
      <text class="ea" x="180" y="218" text-anchor="middle">length along the DASHED</text>
      <text class="lb" x="180" y="236" text-anchor="middle">centre-line, once for all walls</text>
      <text class="lb" x="180" y="258" text-anchor="middle">qty = centre-line length</text>
      <text class="lb" x="180" y="276" text-anchor="middle">× thickness × height</text>

      <text class="em" x="520" y="56" text-anchor="middle">LONG-WALL / SHORT-WALL</text>
      <rect class="soft" x="430" y="72" width="180" height="130" fill="none"/>
      <rect class="soft" x="444" y="86" width="152" height="102" fill="none"/>
      <line class="hi" x1="430" y1="79" x2="610" y2="79"/>
      <line class="hi" x1="430" y1="195" x2="610" y2="195"/>
      <line class="ac" x1="444" y1="137" x2="596" y2="137" marker-end="url(#cl2-c)" marker-start="url(#cl2-c)"/>
      <text class="ea" x="520" y="218" text-anchor="middle">long walls OUT-to-out,</text>
      <text class="lb" x="520" y="236" text-anchor="middle">short walls IN-to-in</text>
      <text class="lb" x="520" y="262" text-anchor="middle">the overlaps at the corners cancel —</text>
      <text class="lb" x="520" y="280" text-anchor="middle">so BOTH give the same quantity</text>
    </svg>`,
    caption: "There are two standard ways to get the wall length for a takeoff, and a good check is that they must agree. The centre-line method measures the total length once, along the middle of the walls, and multiplies by thickness and height. The long-wall/short-wall method measures long walls out-to-out and short walls in-to-in. They look different but give the identical quantity — the corner overlaps that the centre-line method handles automatically are exactly what the out-to-out/in-to-in split accounts for by hand. <strong>If your two methods disagree, you have made an arithmetic slip.</strong>",
  },

  /* ------------------------------------------- 4.1 EARTHWORK */
  "hb-es-earthwork": {
    label: "Measuring earthwork — cut, fill and the two rules",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="A road formation cutting through a hill and filling a valley, with cross-sections taken at intervals, and the volume between them found by the trapezoidal or the prismoidal rule, the prismoidal being more accurate.">
      ${hbmk("ew")}
      <text class="em" x="350" y="24" text-anchor="middle">VOLUME = AVERAGE AREA × LENGTH, DONE CAREFULLY</text>
      <path class="soft" d="M60 90 Q180 70 300 130 T540 150 L640 120 L640 210 L60 210 Z"/>
      <path class="hi" d="M60 168 L640 168"/>
      <text class="ea" x="150" y="120">CUT (excavate)</text>
      <path class="ac" d="M180 132 L180 164" marker-end="url(#ew-c)"/>
      <text class="ea" x="470" y="196">FILL (embankment)</text>
      <path class="ac" d="M470 168 L470 184" marker-end="url(#ew-c)"/>
      ${[120,240,360,480].map(x=>`<line class="thin dash" x1="${x}" y1="70" x2="${x}" y2="210"/>`).join("")}
      <text class="lb" x="350" y="230" text-anchor="middle">cross-sections cut at regular chainage; the volume between two is their areas averaged × the spacing</text>

      <text class="ea" x="170" y="256" text-anchor="middle">TRAPEZOIDAL: average the two end areas</text>
      <text class="lb" x="170" y="274" text-anchor="middle">simple, slightly over</text>
      <text class="ea" x="520" y="256" text-anchor="middle">PRISMOIDAL: weights the mid area too</text>
      <text class="lb" x="520" y="274" text-anchor="middle">more accurate</text>
    </svg>`,
    caption: "Earthwork is measured by cutting cross-sections at regular intervals along the road and finding the volume of soil between each pair. The trapezoidal rule simply averages the two end areas and multiplies by the spacing — quick, but it slightly overestimates. The prismoidal rule adds a weighted middle section and is more accurate, which is why it is preferred for payment quantities on large jobs. <strong>Cut and fill are measured and balanced separately</strong>, because moving soil from the cut to the fill is cheaper than importing or dumping it.",
  },

  /* ------------------------------------------- 6.1 BAR BENDING SCHEDULE */
  "hb-es-bbs": {
    label: "The bar bending schedule — cutting length",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A reinforcement bar bent to shape, showing that its cutting length is not the straight span but the sum of the straight parts plus hook lengths minus the material saved at the bends, illustrated on a rectangular stirrup with two hooks and three bends.">
      ${hbmk("bs2")}
      <text class="em" x="350" y="24" text-anchor="middle">A BENT BAR IS LONGER THAN THE SPACE IT FITS</text>
      <path class="hi" d="M150 90 L150 200 L280 200 L280 90 L150 90" style="fill:none" stroke-width="3"/>
      <path class="hi" d="M150 90 L134 74 M280 90 L296 74" style="fill:none" stroke-width="3"/>
      <text class="lb" x="215" y="220" text-anchor="middle">a rectangular stirrup</text>
      <text class="ea" x="120" y="70">hooks</text>
      <line class="ac" x1="124" y1="74" x2="140" y2="80" marker-end="url(#bs2-c)"/>
      ${[["150","200"],["280","200"],["280","90"]].map(([x,y])=>`<circle class="hif" cx="${x}" cy="${y}" r="4"/>`).join("")}
      <text class="ea" x="300" y="150">bends</text>

      <line class="gl" x1="360" y1="52" x2="360" y2="290"/>
      <text class="em" x="378" y="80">cutting length =</text>
      <text class="lb" x="378" y="106">the straight perimeter</text>
      <text class="lb" x="378" y="128">+ hook lengths (extra steel)</text>
      <text class="lb" x="378" y="150">− bend allowances (steel saved</text>
      <text class="lb" x="378" y="168">  because the bar curves the corner)</text>
      <text class="ea" x="378" y="200">conventions (IS 2502):</text>
      <text class="lb" x="378" y="222">hook ≈ 9d each · 90° bend deducts 2d</text>
      <text class="lb" x="378" y="244">(d = bar diameter)</text>
      <text class="lb" x="378" y="274">then weight = (d²/162) × length  (kg, d in mm)</text>
    </svg>`,
    caption: "A reinforcement bar bent into a stirrup or a cranked bar is longer than the opening it fits into, because the hooks add steel at the ends — and slightly shorter than the sum of its sides, because a bar bends round a corner on a curve rather than a sharp point, saving a little length. The cutting length is the straight perimeter, plus the hooks, minus the bend allowances. <strong>Get it wrong and every bar on the job is cut wrong</strong>, so the bar bending schedule is checked more carefully than almost anything else in a takeoff.",
  },

  /* ------------------------------------------- 8.1 RATE ANALYSIS */
  "hb-es-rate": {
    label: "Rate analysis — what a unit rate is made of",
    svg: `<svg viewBox="0 0 700 290" role="img" aria-label="The rate for one unit of work built up as a stack of costs: materials at the bottom, then labour, then a small allowance for tools and water, then contractor overheads and profit on top, showing that the quoted rate is far more than just the cost of materials.">
      ${hbmk("ra")}
      <text class="em" x="350" y="24" text-anchor="middle">A RATE IS NOT JUST THE COST OF MATERIALS</text>
      ${[["MATERIALS", 210, 66, "conc", "cement, sand, steel, bricks …"],
         ["LABOUR", 150, 132, "softa", "mason, mazdoor, bhishti"],
         ["TOOLS, WATER, SUNDRIES", 40, 186, "soft", "small % on the above"],
         ["OVERHEADS + PROFIT", 44, 228, "soft-b", "contractor's establishment + margin"]]
        .map(([t, h, y, c, note]) => `
        <rect class="${c}" x="150" y="${y}" width="240" height="${h}"/>
        <text class="em" x="270" y="${y + (t.length>16?18:h/2+4)}" text-anchor="middle">${t}</text>
        <text class="lb" x="404" y="${y + 18}">${note}</text>`).join("")}
      <line class="ac" x1="130" y1="272" x2="130" y2="66" marker-end="url(#ra-c)"/>
      <text class="lb" x="122" y="170" text-anchor="middle" transform="rotate(-90 122 170)">builds up to the RATE</text>
      <text class="lb" x="350" y="286" text-anchor="middle">so the quoted rate for 1 m³ of concrete is well above the shop price of its cement and stone</text>
    </svg>`,
    caption: "Rate analysis is the second half of the cost equation: working out what one unit of finished work — a cubic metre of concrete, a square metre of plaster — actually costs to deliver. It is a stack: the materials, then the labour to place them, then a small allowance for tools, water and sundries, and finally the contractor's overheads and profit. <strong>The finished rate is well above the raw material cost</strong>, which is why comparing a quoted rate only against shop prices is misleading — most of the rate is the work, not the stuff.",
  },

});
