/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 1–2
   Steel as a material · Section classification
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 1.2 STRESS-STRAIN */
  "hb-st-curve": {
    label: "The stress-strain curve of mild steel, and what each part is for",
    svg: `<svg viewBox="0 0 700 330" role="img" aria-label="The tensile stress strain curve of mild steel showing the straight elastic line to the upper yield point, the long flat yield plateau, the rising strain hardening region and the ultimate stress before necking and fracture, with the design value fy over gamma m zero marked well inside the elastic range">
      ${hbmk("sc")}
      <text class="em" x="350" y="26" text-anchor="middle">MILD STEEL IN TENSION — AND WHERE DESIGN SITS ON IT</text>
      <line class="s" x1="96" y1="56" x2="96" y2="266"/>
      <line class="s" x1="96" y1="266" x2="630" y2="266"/>
      <text class="lb" x="86" y="62" text-anchor="end">stress</text>
      <text class="lb" x="628" y="288" text-anchor="end">strain →</text>

      <path class="hi" d="M96 266 L150 140"/>
      <path class="hi" d="M150 140 L300 140"/>
      <path class="hi" d="M300 140 C380 138 450 104 520 94"/>
      <path class="hi" d="M520 94 C556 92 580 108 600 128"/>
      <circle class="hif" cx="150" cy="140" r="5"/>
      <circle class="hif" cx="520" cy="94" r="5"/>

      <line class="thin dash" x1="96" y1="140" x2="300" y2="140"/>
      <text class="ea" x="90" y="144" text-anchor="end">fy</text>
      <line class="thin dash" x1="96" y1="94" x2="520" y2="94"/>
      <text class="ea" x="90" y="98" text-anchor="end">fu</text>

      <line class="acf" x1="96" y1="180" x2="240" y2="180" stroke-dasharray="3 4"/>
      <text class="ea" x="246" y="184">fy / γm0 — the design stress</text>
      <text class="lb" x="246" y="202">everything is designed to stay below this</text>

      <text class="lb" x="124" y="222" text-anchor="middle">elastic</text>
      <line class="ac" x1="150" y1="118" x2="300" y2="118" marker-end="url(#sc-c)" marker-start="url(#sc-c)"/>
      <text class="ea" x="225" y="112" text-anchor="middle">yield plateau</text>
      <text class="lb" x="225" y="322" text-anchor="middle">the plateau IS the ductility —</text>
      <text class="lb" x="225" y="304" text-anchor="middle">it stretches without extra load,</text>
      <text class="lb" x="500" y="304" text-anchor="middle">strain hardening, then necking</text>
      <text class="lb" x="500" y="322" text-anchor="middle">and fracture at about 23% strain</text>
      <text class="lb" x="225" y="286" text-anchor="middle">redistributing force elsewhere</text>
    </svg>`,
    caption: "Concrete has nothing like the plateau. It is what lets a steel frame shed load from an overstressed member to its neighbours, and it is the whole reason plastic analysis works — which is why IS 800 cares more about a steel's elongation than about its ultimate strength.",
  },

  /* ---------------------------------------- 1.3 BUCKLING */
  "hb-st-buckle": {
    label: "Steel fails by buckling long before it fails by strength",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="Three columns of the same steel and the same area: a short stocky one that squashes at its yield load, a medium one that fails between the two modes, and a long slender one that buckles sideways at a small fraction of the yield load">
      ${hbmk("bk")}
      <text class="em" x="350" y="26" text-anchor="middle">SAME STEEL, SAME AREA, THREE DIFFERENT FAILURE LOADS</text>
      ${[["SHORT", 110, 96, "squashes", "reaches fy — full strength"],
         ["MEDIUM", 320, 150, "some of both", "inelastic buckling — the common case"],
         ["SLENDER", 560, 200, "buckles", "fails far below fy"]]
        .map(([t, x, h, a, b2], i) => `
        <text class="em" x="${x}" y="58" text-anchor="middle">${t}</text>
        ${grd(x - 30, 250, 60)}
        ${i === 2
          ? `<path class="hi" d="M${x} 250 C${x - 34} ${250 - h * 0.55} ${x + 34} ${250 - h * 0.75} ${x} ${250 - h}"/>`
          : i === 1
            ? `<path class="hi" d="M${x} 250 C${x - 14} ${250 - h * 0.6} ${x + 14} ${250 - h * 0.8} ${x} ${250 - h}"/>`
            : `<rect class="soft-b" x="${x - 16}" y="${250 - h}" width="32" height="${h}"/>`}
        <line class="ac" x1="${x}" y1="${250 - h - 34}" x2="${x}" y2="${250 - h - 8}" marker-end="url(#bk-c)"/>
        <text class="lb" x="${x}" y="274" text-anchor="middle">${a}</text>
        <text class="lb" x="${x}" y="294" text-anchor="middle">${b2}</text>`).join("")}
      <line class="gl" x1="212" y1="46" x2="212" y2="284"/>
      <line class="gl" x1="436" y1="46" x2="436" y2="284"/>
    </svg>`,
    caption: "Concrete members are stocky and fail by crushing. Steel members are slender and fail by buckling — of the whole member, of a flange, of a web, or of a compression zone twisting sideways. Almost every clause in IS 800 is about one of those four.",
  },

  /* ---------------------------------------- 1.5 SAFETY FACTORS */
  "hb-st-gamma": {
    label: "The partial safety factors, and why there is more than one",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A chart of the partial safety factors on material strength in IS 800: one point one for yielding of a member, one point two five for rupture at a net section, one point two five for bolts and shop welds, and one point five for site welds, with the reason for each">
      ${hbmk("gm")}
      <text class="em" x="350" y="26" text-anchor="middle">NOT ONE FACTOR — ONE PER FAILURE MODE</text>
      ${[["γm0 = 1.10", "yielding of a member", "ductile, gives warning, and", "the steel is mill-tested", 74],
         ["γm1 = 1.25", "rupture at a net section", "brittle — a tear at a bolt hole", "gives no warning at all", 132],
         ["γmb = 1.25", "bolts", "a connection failure takes", "the whole member with it", 190],
         ["γmw = 1.25 shop / 1.50 site", "welds", "a site weld is made overhead,", "in the wind, by a tired welder", 248]]
        .map(([g, what, r1, r2, y]) => `
        <rect class="soft" x="70" y="${y - 22}" width="200" height="40" rx="6"/>
        <text class="em" x="84" y="${y + 3}">${g}</text>
        <text class="ea" x="292" y="${y - 6}">${what}</text>
        <text class="lb" x="292" y="${y + 12}">${r1} ${r2}</text>`).join("")}
      <text class="lb" x="350" y="290" text-anchor="middle">the number is not a guess — it is a statement about how the mode fails (IS 800 Table 5)</text>
    </svg>`,
    caption: "IS 456 uses one factor of 1.5 on concrete and 1.15 on steel and leaves it there. IS 800 gives every failure mode its own, and the ranking is the ranking of how much warning each one gives.",
  },

  /* ---------------------------------------- 2.2 LOCAL BUCKLING */
  "hb-st-local": {
    label: "Local buckling — the flange and the web going first",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="An I section in compression with its flange outstand rippling outwards and its web rippling sideways, and beside it the two ratios that decide whether that happens: b over tf for the flange and d over tw for the web">
      ${hbmk("lc")}
      <text class="em" x="176" y="26" text-anchor="middle">THE PLATE BUCKLES BEFORE THE MEMBER DOES</text>
      <path class="s" d="M76 60 L276 60 M166 60 L166 210 M76 210 L276 210"/>
      <path class="hi" d="M76 60 Q104 46 132 60 Q160 74 166 60"/>
      <path class="hi" d="M276 60 Q248 46 220 60 Q192 74 166 60"/>
      <path class="hi" d="M166 84 Q148 110 166 136 Q184 162 166 188"/>
      <text class="lb" x="176" y="238" text-anchor="middle">the flange outstands ripple outwards;</text>
      <text class="lb" x="176" y="258" text-anchor="middle">the web ripples sideways —</text>
      <text class="lb" x="176" y="278" text-anchor="middle">and the section loses its capacity</text>

      <line class="gl" x1="344" y1="16" x2="344" y2="286"/>

      <text class="em" x="524" y="26" text-anchor="middle">TWO RATIOS DECIDE IT</text>
      <rect class="conc" x="452" y="56" width="144" height="16"/>
      <rect class="conc" x="516" y="72" width="16" height="110"/>
      <rect class="conc" x="452" y="182" width="144" height="16"/>
      <line class="ac" x1="452" y1="46" x2="516" y2="46" marker-end="url(#lc-c)" marker-start="url(#lc-c)"/>
      <text class="ea" x="484" y="40" text-anchor="middle">b</text>
      <line class="ac" x1="616" y1="56" x2="616" y2="72" marker-end="url(#lc-c)" marker-start="url(#lc-c)"/>
      <text class="ea" x="624" y="70">tf</text>
      <line class="ac" x1="492" y1="72" x2="492" y2="182" marker-end="url(#lc-c)" marker-start="url(#lc-c)"/>
      <text class="ea" x="470" y="130" text-anchor="end">d</text>
      <text class="ea" x="540" y="134">tw</text>
      <text class="em" x="524" y="228" text-anchor="middle">flange: b / tf      web: d / tw</text>
      <text class="lb" x="524" y="252" text-anchor="middle">a thin wide plate buckles; a thick narrow one</text>
      <text class="lb" x="524" y="272" text-anchor="middle">yields. The ratio is the whole question.</text>
    </svg>`,
    caption: "A steel section is an assembly of thin plates. Before the member as a whole can reach its strength, any one of those plates can ripple and give up — and once it has, the section can no longer carry what the section tables say it can.",
  },

  /* ---------------------------------------- 2.3 THE FOUR CLASSES */
  "hb-st-class": {
    label: "The four section classes as moment-rotation curves",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Four moment rotation curves: a plastic section reaching the plastic moment and rotating a long way, a compact section reaching it but with little rotation, a semi compact section stopping at the yield moment, and a slender section buckling locally before even reaching yield">
      ${hbmk("cl")}
      <text class="em" x="350" y="26" text-anchor="middle">WHAT EACH CLASS CAN ACTUALLY DELIVER</text>
      <line class="s" x1="96" y1="56" x2="96" y2="236"/>
      <line class="s" x1="96" y1="236" x2="620" y2="236"/>
      <text class="lb" x="86" y="62" text-anchor="end">moment</text>
      <text class="lb" x="618" y="258" text-anchor="end">rotation →</text>
      <line class="thin dash" x1="96" y1="86" x2="620" y2="86"/>
      <text class="ea" x="626" y="90">Mp</text>
      <line class="thin dash" x1="96" y1="130" x2="620" y2="130"/>
      <text class="ea" x="626" y="134">My</text>

      <path class="hi" d="M96 236 C150 150 180 90 236 86 L470 86"/>
      <path class="ac" d="M96 236 C150 150 180 90 236 86 C290 86 320 96 350 122"/>
      <path class="s" d="M96 236 C140 176 170 134 206 130 C240 128 258 140 280 166"/>
      <path class="thin" d="M96 236 C132 196 152 170 176 164 C196 160 208 176 222 204"/>

      <text class="ea" x="478" y="76">① PLASTIC — reaches Mp,</text>
      <text class="lb" x="478" y="94">then rotates. Plastic analysis</text>
      <text class="lb" x="478" y="112">may use this class only.</text>
      <text class="ea" x="356" y="126">② COMPACT — reaches Mp, little rotation</text>
      <text class="ea" x="288" y="172">③ SEMI-COMPACT — stops at My</text>
      <text class="ea" x="230" y="212">④ SLENDER — buckles before My</text>
      <text class="lb" x="350" y="286" text-anchor="middle">the class is decided by b/tf and d/tw against limits in ε = √(250/fy) — IS 800 Cl. 3.7, Table 2</text>
      <text class="lb" x="350" y="308" text-anchor="middle">and it then decides which section modulus the design may use</text>
    </svg>`,
    caption: "The class is not a label on the steel — it is a statement about whether the plates will stay flat long enough for the section to deliver what the theory promises. Design uses Zp for classes 1 and 2, Ze for class 3, and a reduced section for class 4.",
  },

  /* ---------------------------------------- 2.5 ZP AND ZE */
  "hb-st-zpze": {
    label: "Elastic and plastic section modulus",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A rectangular section with the triangular elastic bending stress distribution giving the elastic section modulus, beside the same section fully yielded with a rectangular stress block top and bottom giving the plastic section modulus, about 1.5 times larger for a rectangle">
      ${hbmk("zz")}
      <text class="em" x="176" y="26" text-anchor="middle">ELASTIC — first yield at the face</text>
      <rect class="conc" x="76" y="56" width="70" height="170"/>
      <line class="thin dash" x1="60" y1="141" x2="290" y2="141"/>
      <path class="softa" d="M166 141 L166 56 L246 56 Z"/>
      <path class="soft-b" d="M166 141 L166 226 L86 226 Z"/>
      <text class="lb" x="256" y="60">fy</text>
      <text class="em" x="176" y="254" text-anchor="middle">M y = Ze fy</text>
      <text class="lb" x="176" y="278" text-anchor="middle">only the extreme fibre is working</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="286"/>

      <text class="em" x="524" y="26" text-anchor="middle">PLASTIC — the whole section yielded</text>
      <rect class="conc" x="424" y="56" width="70" height="170"/>
      <line class="thin dash" x1="408" y1="141" x2="638" y2="141"/>
      <path class="softa" d="M514 141 L514 56 L594 56 L594 141 Z"/>
      <path class="soft-b" d="M514 141 L514 226 L434 226 L434 141 Z"/>
      <text class="lb" x="604" y="60">fy</text>
      <text class="em" x="524" y="254" text-anchor="middle">M p = Zp fy</text>
      <text class="lb" x="524" y="278" text-anchor="middle">every fibre is working — for a rectangle, 1.5 × more</text>
    </svg>`,
    caption: "Zp is not a different property of a different steel. It is the same section asked a different question: how much moment can it carry once every fibre has yielded, rather than when the first one does. The ratio Zp/Ze is the shape factor — 1.5 for a rectangle, about 1.12 for a rolled I-section.",
  },

});
