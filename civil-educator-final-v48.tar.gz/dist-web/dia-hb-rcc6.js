/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 11–12
   Stairs, walls and other elements · Detailing and BBS
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 11.1 STAIR */
  "hb-rcc-stair": {
    label: "A stair flight is an inclined slab",
    svg: `<svg viewBox="-34 0 758 306" role="img" aria-label="A dog legged stair flight in section showing the waist slab running under the steps, the going between the landings, the rise and tread of one step, and the effective span measured as the going plus half of each landing">
      ${hbmk("sr")}
      <text class="em" x="350" y="26" text-anchor="middle">THE STEPS ARE LOAD — THE WAIST IS THE STRUCTURE</text>
      <path class="conc" d="M96 214 L96 190 L286 68 L286 44 L96 166 Z"/>
      <rect class="conc" x="46" y="190" width="50" height="24"/>
      <rect class="conc" x="286" y="44" width="76" height="24"/>
      ${[0,1,2,3,4].map(i=>`<path class="soft" d="M${104+i*38} ${183-i*24} L${104+i*38} ${159-i*24} L${142+i*38} ${159-i*24} L${142+i*38} ${183-i*24} Z"/>`).join("")}
      <text class="ea" x="176" y="150" transform="rotate(-32 176 150)">waist slab</text>
      <text class="lb" x="66" y="182" text-anchor="middle">landing</text>
      <text class="lb" x="324" y="38" text-anchor="middle">landing</text>

      <line class="ac" x1="182" y1="118" x2="182" y2="142" marker-end="url(#sr-c)" marker-start="url(#sr-c)"/>
      <text class="ea" x="192" y="134">R</text>
      <line class="ac" x1="182" y1="112" x2="220" y2="112" marker-end="url(#sr-c)" marker-start="url(#sr-c)"/>
      <text class="ea" x="198" y="106">T</text>

      <line class="thin" x1="46" y1="238" x2="46" y2="260"/>
      <line class="thin" x1="96" y1="238" x2="96" y2="260"/>
      <line class="thin" x1="286" y1="238" x2="286" y2="260"/>
      <line class="thin" x1="362" y1="238" x2="362" y2="260"/>
      <line class="hi" x1="96" y1="250" x2="286" y2="250" marker-end="url(#sr-m)" marker-start="url(#sr-m)"/>
      <text class="lb" x="191" y="272" text-anchor="middle">going</text>
      <line class="ac" x1="71" y1="286" x2="324" y2="286" marker-end="url(#sr-c)" marker-start="url(#sr-c)"/>
      <text class="ea" x="198" y="300" text-anchor="middle">effective span = going + ½ of each landing (≤ 1 m each) — Cl. 33.1</text>

      <line class="gl" x1="418" y1="36" x2="418" y2="270"/>
      <text class="em" x="560" y="80" text-anchor="middle">LOADS ON A HORIZONTAL METRE</text>
      <text class="lb" x="450" y="116">waist self weight × √(R²+T²)/T</text>
      <text class="lb" x="450" y="142">steps, as a triangle: ½ R × 25</text>
      <text class="lb" x="450" y="168">floor finish</text>
      <text class="lb" x="450" y="194">live load (IS 875 Part 2)</text>
      <text class="em" x="450" y="232">the slope factor is the step</text>
      <text class="em" x="450" y="254">everybody forgets</text>
    </svg>`,
    caption: "The waist is a sloping slab and everything above it is load. Because design is done per horizontal metre, the waist's own weight has to be multiplied by √(R²+T²)/T — for the common 150/300 step, about 1.12.",
  },

  /* ---------------------------------------- 11.3 RETAINING WALL */
  "hb-rcc-retwall": {
    label: "A cantilever retaining wall and its three stability checks",
    svg: `<svg viewBox="0 0 730 320" role="img" aria-label="A cantilever retaining wall in section with the triangular active earth pressure on the stem, the weights of the stem, base and retained soil, and the three checks: overturning about the toe, sliding along the base and bearing pressure under the base">
      ${hbmk("rw")}
      <text class="em" x="350" y="24" text-anchor="middle">THREE WAYS IT CAN FAIL BEFORE THE CONCRETE DOES</text>
      <rect class="conc" x="136" y="234" width="290" height="34"/>
      <rect class="conc" x="216" y="74" width="40" height="160"/>
      <path class="soft" d="M256 74 L426 74 L426 234 L256 234 Z"/>
      <text class="lb" x="346" y="120" text-anchor="middle">retained soil</text>
      ${[0,1,2,3,4].map(i=>`<line class="hi" x1="${196-i*12}" y1="${94+i*32}" x2="216" y2="${94+i*32}" marker-end="url(#rw-m)"/>`).join("")}
      <path class="thin dash" d="M216 74 L148 234"/>
      <text class="ea" x="126" y="180" text-anchor="end">active pressure</text>
      <text class="lb" x="126" y="198" text-anchor="end">Ka γ H, triangular</text>
      <line class="ac" x1="176" y1="286" x2="136" y2="286" marker-end="url(#rw-c)"/>
      <text class="ea" x="186" y="290">toe</text>
      <line class="ac" x1="286" y1="286" x2="426" y2="286" marker-end="url(#rw-c)"/>
      <text class="ea" x="276" y="290" text-anchor="end">heel</text>
      <path class="hi" d="M150 268 A26 26 0 0 1 136 250" fill="none" marker-end="url(#rw-m)"/>
      <text class="lb" x="350" y="312" text-anchor="middle">① overturning about the toe  ② sliding along the base  ③ bearing pressure under it</text>

      <line class="gl" x1="470" y1="40" x2="470" y2="300"/>
      <text class="em" x="588" y="76" text-anchor="middle">WHAT HOLDS IT</text>
      <text class="lb" x="494" y="112">weight of the stem</text>
      <text class="lb" x="494" y="138">weight of the base slab</text>
      <text class="em" x="494" y="164">weight of the soil ON the heel</text>
      <text class="lb" x="494" y="190">— usually the largest of the three,</text>
      <text class="lb" x="494" y="212">which is why the heel is long</text>
      <text class="lb" x="494" y="248">friction μW resists sliding;</text>
      <text class="lb" x="494" y="270">a shear key is added when</text>
      <text class="lb" x="494" y="292">that is not enough</text>
    </svg>`,
    caption: "A retaining wall usually fails as a rigid body long before its concrete is overstressed. The soil sitting on the heel is doing most of the work holding it down, which is why a cantilever wall has a long heel and a short toe.",
  },

  /* ---------------------------------------- 12.3 ANCHORAGE AT A JOINT */
  "hb-rcc-joint": {
    label: "Where the reinforcement has to be continuous",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A beam column joint drawn twice: on the left the beam top bars stop inside the joint and the detail fails, on the right the top bars are carried through and anchored with a standard bend into the far face of the column">
      ${hbmk("jt")}
      <text class="em" x="168" y="26" text-anchor="middle">WRONG</text>
      <rect class="conc" x="120" y="50" width="70" height="220"/>
      <rect class="conc" x="190" y="96" width="160" height="80"/>
      <line class="steel" x1="200" y1="106" x2="340" y2="106"/>
      <line class="steel" x1="200" y1="166" x2="340" y2="166"/>
      <path class="hi" d="M196 92 L212 120 M212 92 L196 120"/>
      <text class="lb" x="235" y="216" text-anchor="middle">the top bar stops at the joint —</text>
      <text class="lb" x="235" y="236" text-anchor="middle">the hogging moment has nothing</text>
      <text class="lb" x="235" y="256" text-anchor="middle">to be carried by, and the crack</text>
      <text class="lb" x="235" y="276" text-anchor="middle">opens exactly there</text>

      <line class="gl" x1="378" y1="16" x2="378" y2="290"/>

      <text class="em" x="530" y="26" text-anchor="middle">RIGHT</text>
      <rect class="conc" x="420" y="50" width="70" height="220"/>
      <rect class="conc" x="490" y="96" width="160" height="80"/>
      <path class="steel" d="M640 106 L440 106 L440 176"/>
      <line class="steel" x1="500" y1="166" x2="640" y2="166"/>
      <path class="steel" d="M500 166 L440 166"/>
      <line class="ac" x1="440" y1="196" x2="440" y2="176" marker-end="url(#jt-c)"/>
      <text class="ea" x="452" y="208">bent down into the column</text>
      <text class="lb" x="530" y="236" text-anchor="middle">the bar continues through the joint</text>
      <text class="lb" x="530" y="256" text-anchor="middle">and is anchored for its full Ld —</text>
      <text class="lb" x="530" y="276" text-anchor="middle">the load path is never broken</text>
    </svg>`,
    caption: "A joint is where two members' reinforcement has to become one continuous load path. Almost every detailing failure in practice is a bar that stops where the force does not.",
  },

  /* ---------------------------------------- 12.5 BBS */
  "hb-rcc-bbs": {
    label: "Cutting length of a stirrup",
    svg: `<svg viewBox="-10 0 716 300" role="img" aria-label="A rectangular two legged stirrup drawn flat with its two dimensions marked, the three ninety degree bends and the two one hundred and thirty five degree hooks identified, and the cutting length built up as twice the perimeter plus hooks minus bend deductions">
      ${hbmk("bb")}
      <text class="em" x="350" y="26" text-anchor="middle">CUTTING LENGTH IS NOT THE PERIMETER</text>
      <rect class="steel" x="150" y="60" width="190" height="170" fill="none" rx="10"/>
      <path class="steel" d="M245 60 L245 36 M245 60 L278 42"/>
      <line class="ac" x1="150" y1="250" x2="340" y2="250" marker-end="url(#bb-c)" marker-start="url(#bb-c)"/>
      <text class="ea" x="245" y="270" text-anchor="middle">A = b − 2 × cover</text>
      <line class="ac" x1="122" y1="60" x2="122" y2="230" marker-end="url(#bb-c)" marker-start="url(#bb-c)"/>
      <text class="ea" x="112" y="150" text-anchor="end">B = D − 2 × cover</text>
      ${[[150,230],[340,230],[340,60]].map(([x,y])=>`<circle class="hif" cx="${x}" cy="${y}" r="7"/>`).join("")}
      <text class="lb" x="150" y="248" text-anchor="middle"></text>
      <text class="lb" x="360" y="232">90° bends — deduct 2d each</text>
      <text class="lb" x="292" y="34">135° hooks — deduct 3d each,</text>
      <text class="lb" x="292" y="16">add 10d of hook each</text>

      <line class="gl" x1="120" y1="286" x2="640" y2="286"/>
      <text class="em" x="400" y="120">CL = 2(A + B) + 2(10d) − 3(2d) − 2(3d)</text>
      <text class="lb" x="400" y="150">every bend makes the bar longer on the outside</text>
      <text class="lb" x="400" y="172">and shorter on the inside — the deduction</text>
      <text class="lb" x="400" y="194">is the difference, and it is why a schedule</text>
      <text class="lb" x="400" y="216">never simply adds up the drawn dimensions</text>
    </svg>`,
    caption: "Cutting length is what the bar bender is given, and it is not the sum of the dimensions on the drawing. Steel on the outside of a bend travels further than steel on the inside, so every bend earns a deduction — and hooks are added on top.",
  },

});
