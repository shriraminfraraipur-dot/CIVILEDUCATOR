/* ============================================================
   HYDROLOGY · COMPLETE NOTES — Chapter 3
   Rainfall Data Analysis: missing-data estimation, consistency
   (double-mass-curve), the three mean-areal-rainfall methods with
   worked examples, their accuracy, presentation of rainfall data,
   DAD curves, IDF curves, PMP.
   Primary source: S2 p.14–29 (Hydrology Part 2 by Sanjeev).
   Secondary: V p.10–11 (Vision Engineering Academy booklet).
   ============================================================ */

window.DB = window.DB || {};
(function () {
  var hb = (DB.handbooks || []).find(function (h) { return h.id === "hydro"; });
  if (!hb) { console.error("hydro handbook not loaded yet"); return; }
  hb.chapters.push({
    id: "hydro-3",
    n: 3,
    title: "Rainfall Data Analysis",
    hi: "वर्षा आँकड़ा विश्लेषण",
    blurb: "Missing rainfall data estimate karna (arithmetic mean / normal ratio), double-mass-curve se consistency check, teen mean-areal-rainfall methods — Arithmetic Mean, Thiessen Polygon (triangle/rectangle/hexagon/circle worked examples), Isohyetal (dono special cases) — unki accuracy compare karna, rainfall data present karne ke 4 tareeke, DAD curve, IDF curve aur PMP. Har fact S2 p.14–29 aur V p.10–11 se, page-cited.",
    mins: 42,
    sections: [

      /* ============================================================ 3.1 */
      {
        n: "3.1",
        title: "Estimating Missing Rainfall Data",
        hi: "अनुपलब्ध वर्षा आँकड़ों का आकलन",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.14–15; V p.10–11" },
          { k: "p", t: "Continuity of a rain-gauge record can break because of damage to the gauge or a technical fault at the time of measurement — this leaves a gap, a missing value, at one station in an otherwise usable set of records. Before the mean rainfall of a catchment is computed, this gap must be filled in; the record must also separately be checked for <b>consistency</b> (§3.2). (S2 p.14)" },
          { k: "def", term: "Normal Annual Average Rainfall (N)", t: "The average annual rainfall of a station computed over at least the last 30 years of record — a stable, long-term reference figure, found separately for every station in the group including the one with the missing value. e.g. for station 1, N₁ = [(P₁)₁₉₉₀ + (P₁)₁₉₉₁ + ... + (P₁)₂₀₁₉] / 30. (S2 p.15; V p.10, which calls it \"latest 30 yrs average annual rainfall\")" },
          { k: "p", t: "Setup: there are stations 1, 2, ... carrying known rainfall P₁, P₂, ... for the period in question, plus a station <b>x</b> whose rainfall Pₓ for that period is missing. Every station — including x — also has its long-term normal annual average N₁, N₂, ..., Nₓ. S2 numbers the known stations 1 to n−1 with x making up the nth; V instead calls the count of known/surrounding stations <b>m</b> directly — the same quantity, just named differently; both forms are used below. (S2 p.15; V p.10)" },
          { k: "h", t: "Case 1 — Simple Arithmetic Mean Method" },
          { k: "def", term: "Condition", t: "Used when every one of N₁, N₂, ... Nₘ lies within ±10% of Nₓ, i.e. each Nᵢ ∈ [Nₓ − 10%Nₓ, Nₓ + 10%Nₓ]. (S2 p.15; V p.10)" },
          { k: "eq", expr: "Px = (P1 + P2 + ... + Pm) / m", where: [
            ["Px", "missing rainfall at station x"],
            ["P1...Pm", "rainfall of the m known/surrounding stations for the same period"],
            ["m", "number of known stations used (S2 writes this as n−1 where n counts x too)"],
          ] },
          { k: "def", term: "Significance of Case 1", t: "All normals being close to Nₓ means the catchment is reasonably <b>uniform</b> — either entirely plain or entirely hilly — so a plain, unweighted average of the known stations is an adequate estimate. (S2 p.15)" },
          { k: "h", t: "Case 2 — Normal Ratio Method (weighted average)" },
          { k: "def", term: "Condition", t: "Used when any one value among N₁, N₂, ... Nₘ falls <b>outside</b> the ±10% band around Nₓ. (S2 p.15; V p.11)" },
          { k: "eq", expr: "Px = (Nx/m) × [ P1/N1 + P2/N2 + ... + Pm/Nm ]", where: [
            ["Nx", "normal annual average rainfall of station x"],
            ["N1...Nm", "normal annual average rainfall of each known station"],
            ["P1...Pm, m", "as in Case 1"],
          ] },
          { k: "def", term: "Significance of Case 2", t: "A normal that differs by more than 10% means the catchment is <b>non-uniform</b> — part of it hilly/high-rainfall and part of it plain — so each station's contribution is weighted by the ratio Nₓ/Nᵢ before averaging, instead of being averaged as-is. (S2 p.15)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Dono method ka farak sirf ek test mein hai: pehle sabhi known stations ke 30-saal-ke-normal ko Nₓ ke ±10% band ke against check karo. Sab andar hain → seedha simple average le lo (Case 1), kyunki catchment rainfall-wise uniform hai, koi station outlier nahi hai. Koi bhi ek bahar hai → us station ko uske apne normal (Nᵢ) ke against normalize karna padega, isliye Normal Ratio method mein har Pᵢ ko Nₓ/Nᵢ se weight kiya jaata hai (Case 2) — taaki agar wo station normally zyada/kam barsaata hai, to uska weight automatically adjust ho jaaye." },
          { k: "trap", t: "N (normal annual average, 30-year long-term figure) aur P (the actual recorded rainfall for the specific period being filled) ko confuse mat karo — N hamesha ek stable reference hai jo saalon-saal roughly fixed rehta hai, jabki P wahi gap hai jo tumhe nikalna hai. Dono formulas mein P ka ratio N se liya jaata hai, N ka P se nahi." },
        ],
      },

      /* ============================================================ 3.2 */
      {
        n: "3.2",
        title: "Checking Record Consistency — Double-Mass-Curve Method",
        hi: "अभिलेख संगति की जाँच — डबल-मास-कर्व विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.16–18; V p.11" },
          { k: "def", term: "Inconsistency of a Record", t: "Occurs when the conditions relevant to the recording of a rain gauge undergo a significant change partway through its record — the station's own data before and after the change no longer belong to one consistent series. (S2 p.16)" },
          { k: "list", items: [
            "Shifting of a rain-gauge station to a new location. (S2 p.16)",
            "A significant change at a station that is nearest to (and used to cross-check) the problem station. (S2 p.16)",
          ] },
          { k: "def", term: "Principle", t: "The double-mass-curve technique is built on the assumption that every recorded series comes from the <b>same parent population</b> — i.e., all stations in a region respond consistently to the same rainfall-producing mechanisms, so their cumulative records should track each other in a straight line. (S2 p.16)" },
          { k: "steps", items: [
            "Select a group of 5 to 10 stations surrounding the problem station x.",
            "Arrange the annual/monthly rainfall of the group, covering a long period, in reverse chronological order — the latest entry first, the oldest last.",
            "Plot a graph between the accumulated rainfall of station x (ΣPx, on Y) and the average accumulated rainfall of the surrounding group (ΣPavg, on X).",
            "A break in slope (a kink) in the resulting plot marks the point in time where the recording conditions at x changed.",
            "Correct the rainfall of the affected period using the ratio of the two slopes.",
          ] },
          { k: "eq", expr: "Pcx = (mc / ma) × Px", where: [
            ["Px", "actual recorded rainfall at x for the period being corrected (as per the old/other location)"],
            ["Pcx", "corrected rainfall at x, consistent with the new/current location"],
            ["ma", "actual (original) slope of the double-mass curve"],
            ["mc", "corrected (current) slope of the double-mass curve"],
          ] },
          { k: "p", t: "Worked illustration of the setup: a station's record (e.g. Delhi) shows one rainfall pattern for 2000–2010 (\"old data\") when only Delhi's own gauge fed the regional average, then a different pattern for 2011–2020 (\"new data\") once a second station (UK) was added into the regional group — the double-mass plot of Delhi against the group average shows a kink exactly at that changeover, and is consistent once the pre-change portion is corrected onto the new location's slope. (S2 p.16)" },
          { k: "eg", title: "Double-mass-curve correction — Example 1", given: "From the plotted double-mass curve: the corrected (post-change) slope mc = tan(theta) = 10/10, and the actual (pre-change) slope ma = tan(alpha) = y/x = 10/20. The recorded rainfall for the period to be corrected is Px = 10 cm.", steps: [
            { t: "Corrected slope", w: "mc = 10/10 = 1" },
            { t: "Actual slope", w: "ma = 10/20 = 1/2" },
            { t: "Apply the correction ratio", w: "Pcx = Px x (mc/ma) = 10 x (1 / (1/2)) = 10 x 2" },
          ], ans: "Pcx = 20 cm (S2 p.17)" },
          { k: "eg", title: "Double-mass-curve correction — Example 2", given: "A second double-mass plot for the same type of problem: actual slope ma = 20/40, corrected slope mc = 10/10.", steps: [
            { t: "Actual slope", w: "ma = 20/40 = 1/2" },
            { t: "Corrected slope", w: "mc = 10/10 = 1" },
            { t: "Apply the correction ratio", w: "Pcx = (mc/ma) x Px = (1)/(1/2) x 10" },
          ], ans: "Pcx = 20 cm (S2 p.18)" },
          { k: "note", t: "The source's working for Example 2 has one intermediate line, \"Pc = 10/[?]\", obscured by a heavy pen scribble in the original and genuinely illegible in the transcript — it is not reconstructed here. It does not affect the final boxed answer, which follows directly and correctly from Pcx = (mc/ma) × Px = 2 × 10 = 20 cm. (S2 p.18)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Double-mass curve ek bahut simple 'sanity check' hai: agar station x consistent hota, to uska cumulative graph (ΣPx vs ΣPavg) ek hi straight line mein jaata — kyunki dono roughly same rate se badhte. Jahan line mein achanak kink/break aata hai, wahi woh moment hai jab station x ki recording condition badli (location shift ya nearby network change). Fix karne ke liye purani (ya nayi) portion ko doosri slope ke ratio se scale kar dete hain, taaki poora record ek hi consistent slope follow kare." },
          { k: "trap", t: "Correction factor (mc/ma) kis portion par lagana hai yeh dhyaan se decide karo — tumhe us ANSHA (period) ko correct karna hai jo currently-prevailing (latest) condition se match nahi karta, taaki poora record ek hi — latest — location/condition ke consistent ho jaaye." },
        ],
      },

      /* ============================================================ 3.3 */
      {
        n: "3.3",
        title: "Mean Areal Rainfall — Arithmetic Mean Method",
        hi: "माध्य क्षेत्रीय वर्षा — अंकगणितीय माध्य विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.18" },
          { k: "p", t: "There are three standard methods to get the mean rainfall over a catchment from a set of point (gauge) readings: ① Arithmetic Mean method, ② Thiessen Polygon (weighted average) method, ③ Isohyetal method. (S2 p.18)" },
          { k: "eq", expr: "P-bar = (P1 + P2 + P3 + ... + Pn) / n", where: [
            ["P-bar", "mean areal rainfall over the catchment"],
            ["P1...Pn", "rainfall recorded at each of the n gauges inside (or representing) the catchment"],
          ] },
          { k: "def", term: "Arithmetic Mean Method", t: "The plain average of all gauge readings in the catchment — every gauge is given equal weight regardless of how much area it actually represents. (S2 p.18)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh sabse simple method hai — bas sab gauges ka average le lo. Problem yeh hai ki har gauge ko equal importance milti hai, chahe wo catchment ke bade hisse ko represent kare ya chhote. Isliye yeh method sirf tab reasonable hai jab gauges catchment mein roughly evenly spread hon aur terrain uniform ho — jaisa Case-1 ki condition §3.1 mein thi." },
          { k: "real", t: "Site par Arithmetic Mean ka use quick, preliminary estimate ke liye hota hai jab gauge network dense aur uniformly spread ho — detailed design ke liye Thiessen ya Isohyetal zyada accurate maane jaate hain (§3.6)." },
        ],
      },

      /* ============================================================ 3.4 */
      {
        n: "3.4",
        title: "Mean Areal Rainfall — Thiessen Polygon Method",
        hi: "माध्य क्षेत्रीय वर्षा — थीसन बहुभुज विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.18–20" },
          { k: "steps", items: [
            "Join every pair of adjacent gauge stations by a straight line — this divides the whole area into a series of triangles.",
            "Draw the perpendicular bisector of each of these straight lines.",
            "The bisectors meet and form a series of closed polygons — each polygon contains exactly one rain gauge, and is taken to represent the area that gauge's reading applies to.",
          ] },
          { k: "eq", expr: "P-bar = (P1.A1 + P2.A2 + ... + Pn.An) / (A1 + A2 + ... + An) = sum[ Pi x (Ai/A) ]", where: [
            ["Pi", "rainfall recorded at gauge i"],
            ["Ai", "area of the Thiessen polygon around gauge i"],
            ["A", "total catchment area = A1 + A2 + ... + An"],
            ["Ai/A", "the weighting factor for gauge i"],
          ] },
          { k: "def", term: "Special Case — gauges inside and outside the catchment boundary", t: "When some gauges lie outside the catchment while their polygons would otherwise extend into it, the <b>catchment boundary itself</b> is used as the outer bounding line of the construction. The area credited to such a gauge is then only the area bounded by the catchment boundary and the perpendicular bisectors (straight lines) radiating from that gauge. (S2 p.19)" },
          { k: "dia", id: "hb-hydro-thiessen", cap: "A Thiessen-polygon construction: adjacent gauges are triangulated, the perpendicular bisector of each triangle side is drawn, and the bisectors close up into one polygon per gauge." },
          { k: "h", t: "Worked Examples" },
          { k: "eg", title: "Thiessen polygon — equilateral triangle layout", given: "Three gauges sit at the vertices of an equilateral triangle of side 4 km, reading 10 cm, 20 cm and 30 cm.", steps: [
            { t: "By the symmetry of an equilateral triangle, the centroid-based Thiessen construction splits it into three equal regions", w: "A1 = A2 = A3 = A/3" },
            { t: "Apply the weighted-mean formula — the equal areas cancel out of the weights", w: "P-bar = [(10)(A/3) + (20)(A/3) + (30)(A/3)] / A = (10+20+30)/3" },
          ], ans: "P-bar = 20 cm (S2 p.19)" },
          { k: "eg", title: "Thiessen polygon — rectangle + centre-station layout", given: "A rectangular layout has gauges 10, 20, 10, 20 cm at the four corners (1,2,3,4) and a fifth gauge of 30 cm at the centre (5). The construction gives each corner region as a right triangle of area a2/8 = 2 km2 (so the rectangle's side a = 4 km), and the central diamond region as a2/2 = 8 km2.", steps: [
            { t: "Corner regions (all four equal)", w: "A1 = A2 = A3 = A4 = a^2/8 = 2 km^2  =>  a = 4 km" },
            { t: "Central region", w: "A5 = a^2/2 = 16/2 = 8 km^2" },
            { t: "Total area", w: "A = 4(2) + 8 = 16 km^2" },
            { t: "Weighted mean — corner sum (10+20+10+20) = 60", w: "P-bar = [60 x 2 + 30 x 8] / 16 = [120 + 240] / 16" },
          ], ans: "P-bar = 22.5 cm (S2 p.19)" },
          { k: "eg", title: "Thiessen polygon — regular hexagon layout", given: "Six gauges sit at the vertices of a regular hexagon of side 4 km, reading (clockwise) 10, 10, 20, 20, 20, 10 cm, with a seventh gauge of 10 cm at the centre.", steps: [
            { t: "Every interior angle of a regular hexagon is (2n-4)x90 / n = (2x6-4)x90/6 = 120 degrees, so each of the six bisector triangles formed is equilateral", w: "" },
            { t: "The six outer (vertex) Thiessen regions together account for 2/3 of the hexagon's area; the one central region accounts for the remaining 1/3", w: "A1=...=A6 (sum) = 2A/3,  A7 = A/3,  where A = (3.sqrt(3)/2)(4)^2 = 24.sqrt(3) = 41.57 km^2 approx" },
            { t: "So each of the six equal outer regions individually is", w: "Ai = (2A/3)/6 = A/9  (i = 1..6)" },
            { t: "Weighted mean — outer vertex sum (10+10+20+20+20+10) = 90", w: "P-bar = [90 x (A/9) + 10 x (A/3)] / A = 90/9 + 10/3 = 10 + 10/3 = 40/3" },
          ], ans: "P-bar = 33.33 cm, as boxed in the source (S2 p.19) — see the Check note below." },
          { k: "note", t: "<b>Check:</b> Carrying the areas worked out in the steps above all the way through gives P-bar = 40/3 = <b>13.33 cm</b>, not the 33.33 cm boxed in the source. The transcript of this worked example already flags it as a probable arithmetic inconsistency in the original handwritten notes (most likely a '1' written or read as a '3'). Both figures are kept here — the source's own boxed answer, and this corrected working from the same areas and gauge values given in the source — against the source's own page. (S2 p.19)" },
          { k: "eg", title: "Thiessen polygon — circular catchment layout", given: "A circular catchment of diameter 15 km has one gauge A = 10 cm at the centre and four gauges around it, B = 8 cm, C = 11 cm, D = 12 cm, E = 9 cm (the source labels both the catchment's diameter and one of the outer gauges 'D' — here the diameter is written out in full to avoid the clash). The perpendicular bisectors between the centre gauge and the outer gauges form a central square of side 7.5 km (area 7.5² = 56.25 km²), and the rest of the circle splits into four equal 'petal' regions, one per outer gauge. (The notes describe this square as one 'of diagonal 15 km', but a square of diagonal 15 km would have area 112.5 km²; the working uses side 7.5 km.)", steps: [
            { t: "Each petal region (for B, C, D, E)", w: "A_petal = [Area of circle - Area of central square] / 4 = [(pi/4)(15)^2 - (7.5)^2] / 4 = [176.71 - 56.25]/4" },
            { t: "", w: "A_petal = 120.46/4 = 30.115 km^2 (the notes print 30.125)" },
            { t: "Central square region (for A) — the source labels this area with the subscript of the last-named outer gauge, though it is the area credited to the centre gauge A", w: "A_centre = (7.5)^2 = 56.25 km^2" },
            { t: "Total area", w: "A = 4(30.115) + 56.25 = 120.46 + 56.25 = 176.71 km^2 (= pi(15)^2/4)" },
            { t: "Weighted mean — outer sum (8+11+12+9) = 40", w: "P-bar = [30.115 x 40 + 10 x 56.25] / 176.71 = [1204.6 + 562.5] / 176.71 = 1767.1/176.71" },
          ], ans: "P-bar = 10 cm (S2 p.20)" },
          { k: "note", t: "<b>Correction (v45):</b> 120.46/4 = <b>30.115</b> km², not 30.125 as printed in the notes, so the total area is 176.71 km² exactly (the notes' 176.75 km² was a rounding artefact), and the central square is of <b>side</b> 7.5 km, not diagonal 15 km. The answer P-bar = 10 cm is unchanged — indeed it must be 10 cm for any weights, because the four outer gauges average (8+11+12+9)/4 = 10 cm, equal to the centre gauge. (S2 p.20)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Thiessen polygon ka core idea: har gauge ko uske 'area of influence' se weight milta hai, na ki equal weight (jaisa Arithmetic Mean mein). Jab gauges symmetric layout mein ho (equilateral triangle, regular hexagon), to by-symmetry polygons equal area ke ho jaate hain aur formula seedha simplify ho jaata hai. Jab layout asymmetric ho (rectangle+centre, circle+4-around-1), to actual geometry se Ai nikaalna padta hai — perpendicular bisectors se banne wale triangles/squares/petals ka area." },
          { k: "trap", t: "Perpendicular bisector <b>side ka</b> hota hai (gauges ko joine wali line ka), na ki gauge se nikalne wali kisi aur line ka — galti se angle bisector ya median use karne se polygon boundaries galat ban jaati hain. Also, boundary par baithe gauges ke liye area <b>catchment boundary tak hi</b> leni hai, poore bisector-triangle tak nahi (Special Case, S2 p.19)." },
        ],
      },

      /* ============================================================ 3.5 */
      {
        n: "3.5",
        title: "Mean Areal Rainfall — Isohyetal Method",
        hi: "माध्य क्षेत्रीय वर्षा — समवर्षा रेखा (आइसोहाइटल) विधि",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.20–22" },
          { k: "def", term: "Isohyet", t: "A line joining places of equal rainfall magnitude. An isohyetal map is a contour map of rainfall drawn at equal intervals; the area enclosed between two consecutive isohyets is measured with a planimeter. (S2 p.20)" },
          { k: "eq", expr: "P-bar = [ ((P1+P2)/2).A1 + ((P2+P3)/2).A2 + ... + ((P(n-1)+Pn)/2).A(n-1) ] / (A1 + A2 + ... + A(n-1))", where: [
            ["P1, P2, ... Pn", "successive isohyet values"],
            ["A1, A2, ... A(n-1)", "area of the strip lying between each pair of consecutive isohyets"],
          ] },
          { k: "def", term: "Special Case 1 — isohyets extending outside the catchment", t: "When the drawn isohyets run beyond the catchment's own boundary, the catchment boundary itself is used as the outer bounding line of the construction, and the outermost strip (between the boundary and the first/last isohyet) is credited with that single isohyet's own value rather than an average of two. (S2 p.20)" },
          { k: "eq", expr: "P-bar = [ P1.A0 + ((P1+P2)/2).A1 + ... + ((P(n-1)+Pn)/2).A(n-1) + Pn.An ] / (A0+A1+...+An)", where: [
            ["A0, An", "the two outermost strips, bounded on one side by the catchment boundary rather than by a second isohyet"],
          ] },
          { k: "def", term: "Special Case 2 — a closed isohyet (contour) lying inside the catchment", t: "When an isohyet closes on itself entirely inside the catchment (a local high- or low-rainfall pocket), that closed loop has no second isohyet of its own to average with — its enclosed area is credited directly with that isohyet's own value, the same treatment used for the outer boundary strips in Special Case 1. (S2 p.21)" },
          { k: "h", t: "Worked Example" },
          { k: "eg", title: "Isohyetal method — closed contour plus successive bands", given: "An isohyetal map gives these bands (Q.19, WB): a closed contour of value 12 cm enclosing 30 km^2; then successive strips 12-10 cm (140 km^2), 10-8 cm (80 km^2), 8-6 cm (180 km^2), and the outermost strip down to the catchment boundary where the isohyet value reaches 4 cm (20 km^2). Total catchment area = 30+140+80+180+20 = 450 km^2.", steps: [
            { t: "Closed contour (Special Case 2) — credited directly with its own value", w: "12 x 30 = 360" },
            { t: "Strip 12-10 cm, average (12+10)/2 = 11", w: "11 x 140 = 1540" },
            { t: "Strip 10-8 cm, average (10+8)/2 = 9", w: "9 x 80 = 720" },
            { t: "Strip 8-6 cm, average (8+6)/2 = 7", w: "7 x 180 = 1260" },
            { t: "Outermost strip to the boundary, average (6+4)/2 = 5 (Special Case 1 treatment)", w: "5 x 20 = 100" },
            { t: "Sum all six products and divide by the total area", w: "P-bar = [360 + 1540 + 720 + 1260 + 100] / 450 = 3980/450" },
          ], ans: "P-bar = 8.84 cm (S2 p.21)" },
          { k: "p", t: "A second isohyetal worked example in the source (isohyets 70, 90, 100, 125, 140, with six band areas 60, 275, 260, 380, 215, 40 km², total 1230 km²) follows the same method and arrives at a boxed figure of 103.85 mm. (S2 p.21)" },
          { k: "note", t: "The last character of that second example's boxed unit is obscured by a stray pen mark in the source and is genuinely illegible — it may read \"mm\" alone or \"mm/hr\"; it is not guessed here. The sketch behind this example also shows four isohyet lines drawn against five labelled values, a mismatch in the original figure itself, so the exact area-to-band assignment cannot be independently confirmed from the transcript — the method (same weighted-strip approach as the main worked example above) is sound; only this one figure's final unit is uncertain. (S2 p.21)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Isohyetal method bhi weighted-average hai, bas weight area-between-contours se aata hai, polygon se nahi. Dono special cases ek hi tareeke se solve hote hain: jahan doosra isohyet available nahi hai (ya boundary ki wajah se, ya closed-loop hone ki wajah se), wahan us ek isohyet ki value seedha use karo, average mat lo." },
          { k: "real", t: "Planimeter se area measurement Thiessen ke straight-line polygon-area se zyada fine/accurate hoti hai — isi wajah se Isohyetal method teeno mein sabse accurate maana jaata hai (§3.6)." },
        ],
      },

      /* ============================================================ 3.6 */
      {
        n: "3.6",
        title: "Comparing Accuracy of the Three Methods",
        hi: "तीनों विधियों की शुद्धता की तुलना",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.22" },
          { k: "list", items: [
            "<b>Ranking (most to least accurate):</b> Isohyetal &gt; Thiessen Polygon &gt; Arithmetic Mean. (S2 p.22)",
            "Isohyetal and Thiessen are both more accurate than Arithmetic Mean because Arithmetic Mean is a purely mathematical average — it ignores how much area each gauge actually represents — while Isohyetal and Thiessen both apply an area-based weighting factor (Aᵢ/A). (S2 p.22)",
            "Between Isohyetal and Thiessen, Isohyetal is more accurate because the Thiessen polygon's area is only an <b>approximation</b> (straight-line bisectors), whereas an isohyetal map is drawn with fine contour detail and its areas are measured on tracing paper with a planimeter, giving a more accurate area. (S2 p.22)",
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Teeno method ka common thread weighting hai — jitna zyada 'spatially aware' weighting (sirf count-based vs area-based vs fine-contour-area-based), utni zyada accuracy. Arithmetic Mean kisi bhi area-weight ka use nahi karta, isliye sabse kam accurate. Thiessen aur Isohyetal dono Ai/A weight use karte hain, par Thiessen ka Ai sirf straight-line approximation hai jabki Isohyetal ka Ai actual measured contour-area hai — isliye Isohyetal sabse upar." },
        ],
      },

      /* ============================================================ 3.7 */
      {
        n: "3.7",
        title: "Presentation of Rainfall Data",
        hi: "वर्षा आँकड़ों की प्रस्तुति",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.22–23" },
          { k: "def", term: "Mass Curve of Rainfall", t: "A graphical plot of accumulated rainfall against chronological time. The slope of the mass curve at any point gives the rainfall intensity at that time — a steep rising segment is a burst of intense rain, a flat segment is a dry spell with no rainfall. (S2 p.22)" },
          { k: "def", term: "Hyetograph", t: "A bar-chart representation of rainfall intensity against chronological time, derived from the mass curve of rainfall (by taking the slope — i.e. the incremental rise — over each successive time interval). The area under a hyetograph equals the total magnitude (depth) of rainfall. (S2 p.23)" },
          { k: "def", term: "Point Rainfall (or Station Rainfall)", t: "A single rain gauge represents the magnitude of rainfall at that one point only, hence \"point\" or \"station\" rainfall. Depending on the need, this data may be tabulated or plotted on a daily, monthly, yearly or even hourly basis. (S2 p.23)" },
          { k: "def", term: "Moving Average Method (Station-Year Method)", t: "The average rainfall of three to five consecutive years is computed and plotted as a smoothed curve running through the raw annual bars. This method is generally used to identify the frequency of fluctuations in a rainfall time series, and to reveal the underlying trend or pattern that the year-to-year scatter otherwise hides. (S2 p.23)" },
          { k: "eq", expr: "3-year moving average:  P-bar(1) = (P1+P2+P3)/3  ;  P-bar(3) = (P2+P3+P4)/3  ;  P-bar(5) = (P3+P4+P5)/3  ; ...", where: [
            ["P1, P2, ...", "annual rainfall of successive years"],
            ["P-bar(k)", "the 3-year moving average centred on year k"],
          ] },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "Yeh char tareeke same raw data ko different angles se dekhne ke hain. Mass curve cumulative trend dikhata hai (aur uska slope hi intensity hai — hyetograph usi slope ko bar-chart mein alag se extract kar deta hai, interval-by-interval). Point rainfall sirf ek location ka raw record hai. Moving average year-to-year noise ko smooth karke long-term trend dikhata hai — jaise ek 'drought ya wet-spell pattern detector'." },
          { k: "real", t: "Hyetograph design storms banane mein directly use hota hai (unit hydrograph method ka input); mass curve se derived intensity design-storm duration select karne mein kaam aata hai; moving average drought/flood-frequency trend studies mein use hota hai." },
        ],
      },

      /* ============================================================ 3.8 */
      {
        n: "3.8",
        title: "Depth-Area-Duration (DAD) Curves and Analysis",
        hi: "गहराई-क्षेत्र-अवधि (DAD) वक्र एवं विश्लेषण",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.24–26; V p.10–11" },
          { k: "p", t: "A single rain-gauge station only gives the point rainfall at that location, which does not by itself represent the rainfall over an area. To find how much rainfall actually fell over a given area, a Depth-Area-Duration (DAD) analysis is required — its purpose is to determine, for a particular storm, the largest average depth of rainfall that fell over various sizes of area within the catchment. (S2 p.24)" },
          { k: "def", term: "Assumption 1 — storm centre", t: "It is assumed that the centre of the storm coincides with the location of the rain gauge. In practice this exact coincidence is very unlikely, so an approximate area of 25 km² is taken around the gauge to represent the storm centre. (S2 p.24)" },
          { k: "eq", expr: "P-bar = P0 . e^(-K.A^n)", where: [
            ["P-bar", "average depth of rainfall (cm) over an area A (km^2)"],
            ["P0", "maximum depth of rainfall at the centre of the storm; P0 > P-bar1 > P-bar2 > P-bar3 ... as the area considered grows"],
            ["K, n", "constants for a given catchment — fixed, after analysing 42 severe storms over Karnataka, by Dhar and Bhattacharya"],
          ] },
          { k: "note", t: "S2 writes the DAD relationship with a decay exponential, P-bar = P0.e^(-K.A^n) (S2 p.24) — this matches both the physical requirement that average depth must <i>fall</i> as the area considered grows, and the convex, decreasing DAD-curve shape both sources draw. V's booklet prints the same relationship <i>without</i> the minus sign, P-bar = P0.e^(K.A^n) (V p.11), which taken literally would make average depth increase with area — contradicted by V's own DAD-curve sketch (three decreasing curves) and its own accompanying prose (\"average depth of rainfall decreases with an area\"). Both forms are kept here with their own citation; use S2's signed form for any computation. (S2 p.24; V p.11)" },
          { k: "def", term: "Assumption 2 — constant storm intensity", t: "The intensity of the storm is assumed constant through its duration, i.e. a 3-hour storm (at that same intensity) has a greater rainfall depth than a 2-hour storm. (S2 p.25)" },
          { k: "list", items: [
            "<b>Note — within one storm:</b> for a particular catchment and a particular storm, the average depth of rainfall <i>decreases</i> as the area considered increases (this is what the DAD curve itself plots). (S2 p.25)",
            "<b>Note — across different storms:</b> the average depth of rainfall over a given area <i>increases</i> as the storm's duration increases — a longer storm, at the same intensity, deposits more depth. A set of DAD curves for increasing durations (e.g. 1 hr, 2 hr, 6 hr) therefore stack with the longer-duration curve lying above the shorter one at every area. (S2 p.25; V p.10–11, whose figure similarly stacks 1 hr, 2 hr and 6 hr curves with the 6-hr curve on top)",
          ] },
          { k: "p", t: "The DAD curve (average depth vs. cumulative area) is drawn convex, resembling the first-quadrant limb of a rectangular hyperbola; plotted on a semi-log scale (average depth vs. ln(cumulative area)) it is still convex, resembling the third-quadrant limb of a rectangular hyperbola. In practice the DAD curve for a given duration is drawn as a maximising envelope through the appropriate data points, not a smooth best-fit through all of them. DAD analysis is very useful for the design of structures against severe storms — e.g. for calculating the flood discharge used to design a spillway or other hydraulic structure. (S2 p.25)" },
          { k: "h", t: "Worked Example" },
          { k: "p", t: "<b>Q.</b> Draw the DAD curve expected over an area of 2400 km², due to a storm (21st December) lasting 12 hours, assuming the storm centre lies at the centre of the area. The isohyets for that storm give the areas below. (S2 p.26)" },
          { k: "cmp", t: "DAD analysis — isohyet bands, incremental area, volume and cumulative average depth. Volume = P-bar × A; cumulative avg depth = (sum of volumes)/(sum of areas) (S2 p.26)", cols: ["Area (km²)", "Incr. area (km²)", "Avg depth (cm)", "Volume ('000)", "Cum. volume ('000)", "Cum. avg depth"], rows: [
            ["Isohyet 20–22 cm", "543", "543", "21", "11,403", "11,403", "21.00"],
            ["Isohyet 19–21 cm", "1,345", "802", "20", "16,040", "27,443", "20.40"],
            ["Isohyet 18–20 cm", "2,030", "685", "19", "13,015", "40,458", "19.93"],
            ["Isohyet 17–19 cm", "2,545", "515", "18", "9,270", "49,728", "19.54"],
            ["Isohyet 16–18 cm", "2,955", "410", "14", "6,970", "56,698", "19.19"],
            ["Isohyet 15–17 cm", "3,280", "325", "16", "5,200", "61,898", "18.87"],
            ["Isohyet 14–16 cm", "3,535", "255", "15", "3,825", "65,723", "18.59"],
            ["Isohyet 13–15 cm", "3,710", "175", "14", "2,975", "69,698", "18.52"],
            ["Isohyet 12–14 cm", "3,880", "170", "13", "2,210", "70,908", "18.28"],
            ["Isohyet 11–13 cm", "3,915", "35", "12", "420", "71,328", "18.22"],
          ] },
          { k: "note", t: "A few of the \"Area enclosed\" and \"Cumulative avg depth\" figures in rows 3 and 4 above are shown with light brackets in the page-14–29 transcript, meaning the scan was partly unclear there and the figures were filled in from the surrounding arithmetic (they check out against the adjoining rows' running totals). They are presented here as ordinary values, not re-flagged, since they are consistent with the table's own cumulative-volume/cumulative-area trend. (S2 p.26)" },
          { k: "eg", title: "DAD curve — reading off the average depth at 2400 km^2 by linear interpolation", given: "From the table above, the cumulative avg depth is 19.93 cm at a cumulative area of 2030 km^2, and 19.54 cm at 2545 km^2. Find the avg depth at the asked-for area of 2400 km^2, which lies between these two.", steps: [
            { t: "Set up the linear-interpolation ratio between the two bracketing rows", w: "(2400 - 2030) / (2545 - 2400) = (x - 19.93) / (19.54 - x)" },
            { t: "i.e.", w: "370/145 = (x - 19.93)/(19.54 - x)" },
            { t: "Cross-multiply and solve for x", w: "370(19.54 - x) = 145(x - 19.93)  =>  x = 19.64 (approx, as boxed in the source)" },
          ], ans: "Average depth over 2400 km^2 (12-hr storm) = 19.64 cm (S2 p.26)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "DAD curve banane ka tareeka: isohyet-by-isohyet area aur volume (depth x area) nikaalo, cumulative karo, aur cumulative-volume/cumulative-area ka ratio hi us cumulative area tak ka 'average depth' hai. Jo area beech mein chahiye (yahan 2400 km²) uske liye seedha value table mein nahi hoti, to adjacent two rows ke beech linear interpolation karte hain." },
          { k: "trap", t: "Do alag comparisons ko mix mat karo: (1) EK storm ke andar, area badhne se average depth GHATTA hai (yeh DAD curve ka shape hai) — (2) do ALAG storms compare karo (jaise 3-hr vs 5-hr), to zyada duration wale storm ki depth (same area ke liye) zyada hogi. Pehla 'within-storm' statement hai, doosra 'across-storm' statement — formula ek hi jagah use nahi hoti dono ke liye (S2 p.25, Note ① aur ②)." },
        ],
      },

      /* ============================================================ 3.9 */
      {
        n: "3.9",
        title: "Maximum Intensity-Duration-Frequency (IDF) Curves",
        hi: "अधिकतम तीव्रता-अवधि-बारंबारता (IDF) वक्र",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.27–28" },
          { k: "p", t: "Rainfall at a place can be completely defined only if its intensity, duration and frequency are all known together. An IDF curve is a graphical relation between the <b>maximum rainfall intensity</b> (in cm/hr) and the <b>duration</b> (in minutes) being analysed — this duration is a window being examined inside the storm, <i>not</i> the total duration of the storm itself. (S2 p.27)" },
          { k: "eq", expr: "i_max = K . T^x / (t_H + B)^n", where: [
            ["i_max", "maximum rainfall intensity (cm/hr)"],
            ["T", "frequency of the storm, or return period / recurrence interval (years)"],
            ["t_H", "duration of the storm window being analysed (hr)"],
            ["K, x, B, n", "constants for a given place"],
          ] },
          { k: "h", t: "Worked Example 1" },
          { k: "eg", title: "IDF — maximum 30-min and 60-min intensity from a storm record", given: "A storm's cumulative rainfall was recorded every 30 minutes from 10:00 to 13:00: 2, 3, 5, 6, 10, 12 cm (cumulative). The incremental 30-min depths are 2, 1, 2, 1, 4, 2 cm; the 60-min depths over sliding windows (sums of consecutive 30-min increments) are 3, 3, 3, 5, 6 cm (the notes print 5, 3, 5, 6).", steps: [
            { t: "Maximum 30-min depth (largest of the 30-min increments)", w: "d_max(30) = 4 cm  =>  i_max = 4/(30/60) = 4/0.5 = 8 cm/hr" },
            { t: "Maximum 60-min depth (largest of the 60-min increments)", w: "d_max(60) = 6 cm  =>  i_max = 6/(60/60) = 6/1 = 6 cm/hr" },
          ], ans: "i_max = 8 cm/hr for a 30-min window; i_max = 6 cm/hr for a 60-min window (S2 p.27)" },
          { k: "note", t: "<b>Correction (v45):</b> From the 30-min increments 2, 1, 2, 1, 4, 2 cm, the 60-min sliding-window depths are 2+1, 1+2, 2+1, 1+4, 4+2 = <b>3, 3, 3, 5, 6</b> cm; the list printed in the notes (5, 3, 5, 6) does not follow from the record. The maximum, 6 cm (12:00–13:00), and hence i_max = 6 cm/hr, are unaffected. (S2 p.27)" },
          { k: "h", t: "Worked Example 2" },
          { k: "eg", title: "IDF — maximum intensity for five durations from a storm record", given: "A storm's cumulative rainfall was recorded every 30 minutes, in mm: 0, 6, 18, 21, 36, 43 at t = 0, 30, 60, 90, 120, 150 min. Scanning every possible 30/60/90/120/150-minute window within this record and taking the largest incremental depth for each window length gives the maximum depths below.", steps: [
            { t: "Maximum depth for each duration (from the incremental-depth table, source p.28)", w: "30 min: 15 mm;  60 min: 22 mm;  90 min: 30 mm;  120 min: 37 mm;  150 min: 43 mm" },
            { t: "Maximum intensity, i_max = d_max / t, as computed in the source", w: "30 min: 15/(30/60) = 30;  60 min: 22/(60/60) = 22;  90 min: 30/(90/60) = 20;  120 min: 37/(120/60) = 18.5;  150 min: 43/(150/60) = 17.2" },
          ], ans: "i_max = 30, 22, 20, 18.5, 17.2 — as boxed in the source, labelled cm/hr for durations 30, 60, 90, 120, 150 min respectively (S2 p.28). See the Check note below." },
          { k: "note", t: "<b>Check:</b> the source's own depth table for this example is explicitly headed \"Rainfall (mm)\", but the intensities above are labelled \"cm/hr\" while using the raw mm figures directly — e.g. 15 mm / (30/60 hr) = 30 <b>mm/hr</b> = 3.0 cm/hr, not 30 cm/hr. The same factor-of-10 slip runs through all five values (22, 20, 18.5 and 17.2 are each the correct figure in mm/hr, mislabelled cm/hr). The source's own boxed numbers (30, 22, 20, 18.5, 17.2) are kept exactly as transcribed above; this note only flags that their unit label should read mm/hr, not cm/hr. (S2 p.28)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "IDF curve ka duration us 'window' ka hai jo storm ke andar dekha ja raha hai (30 min, 60 min, etc.), poore storm ka duration nahi — isliye ek hi storm record se multiple durations ke liye alag-alag i_max nikal sakte hain, har duration apna maximum incremental depth dhoondh ke. Jitna chhota window, utni zyada peak intensity milti hai (kyunki short burst mein rainfall concentrate hota hai) — isiliye curve duration badhne ke saath neeche girti hai." },
          { k: "real", t: "IDF curve ka use storm drainage design mein hota hai — ek chosen return period (T) aur design duration (tH) ke liye i_max nikal ke hi drain/culvert ka design discharge decide kiya jaata hai." },
        ],
      },

      /* ============================================================ 3.10 */
      {
        n: "3.10",
        title: "Probable Maximum Precipitation (PMP)",
        hi: "संभावित अधिकतम वर्षण (PMP)",
        blocks: [
          { k: "h", t: "📘 Notes — S2 p.29" },
          { k: "def", term: "Probable Maximum Precipitation (PMP)", t: "The greatest, or extreme, rainfall that is physically possible over a basin. (S2 p.29)" },
          { k: "p", t: "PMP is obtained by either of two methods:" },
          { k: "eq", expr: "Statistical method:  PMP = P-bar + K . sigma", where: [
            ["P-bar", "mean of the rainfall series"],
            ["K", "frequency factor"],
            ["sigma", "standard deviation of the rainfall series"],
          ] },
          { k: "eq", expr: "Meteorological method (per WMO):  PMP = 42.16 . D^0.475", where: [
            ["D", "duration of the storm, in hours"],
            ["PMP", "in cm"],
          ] },
          { k: "note", t: "The source's own notation for this WMO formula writes \"(D → cm)\" immediately beside \"D\", and then separately states in words that D is the \"Duration of storm (hr)\" — these two labels read as contradictory in the transcript. Taken together with how the formula is normally quoted (duration in hours, PMP in cm), the \"(D → cm)\" annotation most likely refers to the output PMP being in centimetres rather than to D's own units; D itself is hours, exactly as the source states in words. (S2 p.29)" },
          { k: "h", t: "💡 Samjho" },
          { k: "p", t: "PMP 'yeh kitna extreme ho sakta hai' ka upper-bound estimate hai, do tareeke se: statistical method existing rainfall data (P-bar, sigma) se extrapolate karta hai using a frequency factor K; meteorological (WMO) method sirf storm ki duration D se ek empirical formula se seedha PMP deta hai, bina kisi station-specific data ke." },
          { k: "real", t: "PMP ka use major hydraulic structures (large dams, spillways) ke design mein hota hai, jahan failure ka consequence bahut bada hota hai aur design ko sabse extreme physically-possible storm ke against check karna padta hai — DAD analysis (§3.8) se PMP ka areal distribution bhi nikala jaata hai." },
        ],
      },

      /* ============================================================ 3.11 */
      {
        n: "3.11",
        title: "Quick revision — Rainfall Data Analysis",
        hi: "त्वरित पुनरावृत्ति",
        blocks: [
          { k: "h", t: "✅ Checklist" },
          { k: "list", items: [
            "Missing rainfall Px: Simple (Arithmetic) Mean method when every normal Nᵢ is within ±10% of Nₓ; Normal Ratio (weighted) method otherwise (S2 p.15; V p.10–11).",
            "Double-mass-curve: plot ΣPx vs ΣPavg of 5–10 surrounding stations; a kink = inconsistency; correct with Pcx = (mc/ma)×Px (S2 p.16–18).",
            "Arithmetic Mean: P̄ = ΣPᵢ/n, equal weight to every gauge (S2 p.18).",
            "Thiessen Polygon: perpendicular bisectors of lines joining adjacent gauges → one polygon per gauge; P̄ = ΣPᵢ(Aᵢ/A); worked for triangle, rectangle+centre, hexagon, circle layouts (S2 p.18–20).",
            "Isohyetal method: P̄ = Σ[(Pᵢ+Pᵢ₊₁)/2·Aᵢ]/ΣAᵢ; two special cases both use a single isohyet's own value (not an average) where there is no second isohyet to pair with — isohyets outside the catchment, and a closed isohyet inside it (S2 p.20–21).",
            "Accuracy ranking: Isohyetal &gt; Thiessen &gt; Arithmetic Mean (S2 p.22).",
            "Presentation: mass curve (cumulative rainfall vs time, slope = intensity), hyetograph (intensity bar-chart, derived from the mass curve), point/station rainfall, moving-average/station-year method (S2 p.22–23).",
            "DAD curve: P̄ = P₀·e^(−K·Aⁿ); within one storm, depth falls as area grows; across storms, depth (for a given area) rises with duration (S2 p.24–26).",
            "IDF curve: i_max = K·Tˣ/(t_H+B)ⁿ — duration here is the analysis window inside the storm, not the storm's own total duration (S2 p.27–28).",
            "PMP: statistical method PMP = P̄+Kσ; WMO meteorological method PMP = 42.16·D^0.475 (S2 p.29).",
          ] },
          { k: "h", t: "🔑 Key takeaways" },
          { k: "list", items: [
            "Every mean-areal-rainfall method is a weighted average of point readings — the three methods differ only in HOW the weight (Aᵢ/A) is worked out: not at all (Arithmetic Mean), by straight-line polygon (Thiessen), or by measured contour area (Isohyetal) — which is also exactly why their accuracy ranks in that order.",
            "Both Thiessen's and Isohyetal's \"special cases\" boil down to one rule: wherever there is no second gauge/isohyet to average with (a catchment boundary, or a closed loop), use that one value directly for the area it covers.",
            "Two genuine cross-source conflicts were flagged in this chapter: the sign in the DAD formula (S2: P̄=P₀e^(−KAⁿ); V: missing the minus sign), and the apparently-mislabelled unit (cm/hr vs mm/hr) in one IDF worked example (S2 p.28) — both are kept exactly as each source states, with the discrepancy noted.",
            "One Thiessen worked example (the regular-hexagon layout, S2 p.19) carries forward an arithmetic inconsistency already flagged in the source transcript: the correct working from the source's own areas gives 13.33 cm, not the 33.33 cm boxed there.",
          ] },
        ],
      },

    ],
  });
})();
