/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: RCC handbook, Chapters 3–4
   Flexure — singly, doubly reinforced and flanged sections
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 3.2 SECTION AT FAILURE */
  "hb-rcc-strain-stress": {
    label: "Singly reinforced section at the limit state of flexure",
    svg: `<svg viewBox="0 0 740 340" role="img" aria-label="A rectangular beam section, its linear strain diagram with 0.0035 at the top compression fibre, and the parabolic rectangular stress block giving a compression force of 0.36 fck b xu acting at 0.42 xu from the top, balanced by the steel tension">
      ${hbmk("ss2")}
      <text class="lb" x="96" y="26" text-anchor="middle">SECTION</text>
      <rect class="conc" x="46" y="52" width="100" height="220"/>
      <line class="thin dash" x1="34" y1="140" x2="300" y2="140"/>
      <text class="lb" x="30" y="144" text-anchor="end">N.A.</text>
      <circle class="steel" cx="64" cy="250" r="8"/>
      <circle class="steel" cx="96" cy="250" r="8"/>
      <circle class="steel" cx="128" cy="250" r="8"/>
      <line class="thin" x1="158" y1="52" x2="158" y2="250" marker-start="url(#ss2-a)" marker-end="url(#ss2-a)"/>
      <text class="lb" x="166" y="158">d</text>
      <line class="thin" x1="46" y1="292" x2="146" y2="292" marker-start="url(#ss2-a)" marker-end="url(#ss2-a)"/>
      <text class="lb" x="96" y="310" text-anchor="middle">b</text>
      <line class="hi" x1="182" y1="52" x2="182" y2="140" marker-start="url(#ss2-m)" marker-end="url(#ss2-m)"/>
      <text class="em" x="190" y="100">xu</text>

      <line class="gl" x1="236" y1="16" x2="236" y2="326"/>

      <text class="lb" x="336" y="26" text-anchor="middle">STRAIN</text>
      <line class="s" x1="336" y1="52" x2="336" y2="272"/>
      <path class="softa" d="M336 52 L266 52 L336 140 Z"/>
      <path class="softa" d="M336 140 L406 250 L336 250 Z"/>
      <path class="ac" d="M266 52 L336 140 L406 250"/>
      <text class="ea" x="260" y="46" text-anchor="end">0.0035</text>
      <text class="ea" x="412" y="254">εst</text>
      <line class="thin dash" x1="266" y1="140" x2="412" y2="140"/>
      <text class="lb" x="336" y="304" text-anchor="middle">linear — plane sections stay plane</text>

      <line class="gl" x1="440" y1="16" x2="440" y2="326"/>

      <text class="lb" x="580" y="26" text-anchor="middle">STRESS AND FORCES</text>
      <line class="s" x1="500" y1="52" x2="500" y2="272"/>
      <path class="soft" d="M500 52 L588 52 L588 90 Q560 128 500 140 Z"/>
      <path class="hi" d="M500 52 L588 52 L588 90 Q560 128 500 140"/>
      <text class="em" x="596" y="56">0.446 fck</text>
      <line class="hi" x1="500" y1="90" x2="672" y2="90" marker-end="url(#ss2-m)"/>
      <text class="em" x="616" y="82">C = 0.36 fck b xu</text>
      <line class="hi" x1="672" y1="250" x2="500" y2="250" marker-end="url(#ss2-m)"/>
      <text class="em" x="616" y="244" text-anchor="middle">T = 0.87 fy Ast</text>
      <line class="thin" x1="500" y1="52" x2="500" y2="90"/>
      <line class="thin" x1="476" y1="52" x2="476" y2="90" marker-start="url(#ss2-a)" marker-end="url(#ss2-a)"/>
      <text class="lb" x="470" y="76" text-anchor="end">0.42 xu</text>
      <line class="thin" x1="454" y1="90" x2="454" y2="250" marker-start="url(#ss2-a)" marker-end="url(#ss2-a)"/>
      <text class="lb" x="448" y="176" text-anchor="end">lever arm</text>
      <text class="lb" x="448" y="192" text-anchor="end">z = d − 0.42xu</text>
      <text class="em" x="580" y="304" text-anchor="middle">C = T fixes xu ·   Mu = C × z</text>
    </svg>`,
    caption: "Three drawings, one section. <strong>Equilibrium of C and T fixes the neutral axis depth; the moment is then that force times the lever arm.</strong> Every flexure formula in this handbook is one of those two statements rearranged.",
  },

  /* ---------------------------------------- 3.3 STRESS BLOCK DERIVED */
  "hb-rcc-block": {
    label: "Where 0.36 and 0.42 come from",
    svg: `<svg viewBox="0 0 720 340" role="img" aria-label="The parabolic rectangular stress block split into its rectangular top portion of three sevenths of xu and its parabolic lower portion of four sevenths, with the area and centroid of each computed and combined">
      ${hbmk("bd")}
      <line class="s" x1="120" y1="50" x2="120" y2="250"/>
      <line class="thin dash" x1="110" y1="250" x2="330" y2="250"/>
      <text class="lb" x="104" y="254" text-anchor="end">N.A.</text>
      <path class="soft-b" d="M120 50 L250 50 L250 136 L120 136 Z"/>
      <path class="soft" d="M120 136 L250 136 Q200 210 120 250 Z"/>
      <path class="hi" d="M120 50 L250 50 L250 136 Q200 210 120 250"/>
      <line class="thin dash" x1="110" y1="136" x2="330" y2="136"/>
      <text class="em" x="256" y="46">0.446 fck</text>
      <line class="thin" x1="96" y1="50" x2="96" y2="136" marker-start="url(#bd-a)" marker-end="url(#bd-a)"/>
      <text class="em" x="90" y="98" text-anchor="end">3/7 xu</text>
      <line class="thin" x1="96" y1="136" x2="96" y2="250" marker-start="url(#bd-a)" marker-end="url(#bd-a)"/>
      <text class="em" x="90" y="198" text-anchor="end">4/7 xu</text>
      <text class="lb" x="185" y="98" text-anchor="middle">strain ≥ 0.002</text>
      <text class="lb" x="185" y="114" text-anchor="middle">so stress is constant</text>
      <text class="lb" x="185" y="196" text-anchor="middle">strain &lt; 0.002</text>
      <text class="lb" x="185" y="212" text-anchor="middle">parabolic</text>
      <line class="ac" x1="120" y1="286" x2="120" y2="266" marker-start="url(#bd-c)"/>
      <text class="ea" x="130" y="282">0.416 xu ≈ 0.42 xu from the top</text>
      <circle class="acf" cx="120" cy="266" r="4"/>

      <line class="gl" x1="352" y1="30" x2="352" y2="320"/>
      <text class="em" x="372" y="58">Rectangular part</text>
      <text x="372" y="84">area = 0.446 fck × (3/7) xu = 0.191 fck xu</text>
      <text class="lb" x="372" y="106">centroid 0.214 xu from the top</text>
      <text class="em" x="372" y="146">Parabolic part</text>
      <text x="372" y="172">area = ⅔ × 0.446 fck × (4/7) xu = 0.170 fck xu</text>
      <text class="lb" x="372" y="194">centroid 0.643 xu from the top</text>
      <line class="thin" x1="372" y1="212" x2="700" y2="212"/>
      <text class="em" x="372" y="240">Total  C = 0.361 fck b xu ≈ 0.36 fck b xu</text>
      <text class="em" x="372" y="268">Centroid = 0.416 xu ≈ 0.42 xu</text>
      <text class="lb" x="372" y="300">Both constants are consequences of the</text>
      <text class="lb" x="372" y="318">stress block shape — not arbitrary numbers.</text>
    </svg>`,
    caption: "The strain is 0.0035 at the top and 0.002 at four-sevenths of xu above the neutral axis, which splits the block in the ratio 3:4. <strong>Work out the area and the centroid of those two pieces and 0.36 and 0.42 fall out</strong> — there is nothing to memorise here.",
  },

  /* ---------------------------------------- 3.5 FAILURE MODES */
  "hb-rcc-failure": {
    label: "Under-reinforced against over-reinforced failure",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="Left, an under reinforced beam whose steel yields first, giving large deflection and wide warning cracks before the concrete crushes. Right, an over reinforced beam whose concrete crushes suddenly with the steel still elastic and no warning.">
      ${hbmk("fl")}
      <text class="em" x="168" y="28" text-anchor="middle">UNDER-REINFORCED  (xu &lt; xu,max)</text>
      <path class="s" d="M40 92 L296 92"/>
      <path class="hi" d="M40 92 Q168 168 296 92"/>
      <path class="s" d="M40 92 L30 110 L50 110 Z"/><circle class="s" cx="290" cy="102" r="8"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="thin" x1="${112+i*24}" y1="${150-Math.abs(i-2.5)*6}" x2="${112+i*24}" y2="${128-Math.abs(i-2.5)*6}"/>`).join("")}
      <text class="lb" x="168" y="178" text-anchor="middle">wide cracks, large sag — plenty of warning</text>
      <text class="em" x="168" y="210" text-anchor="middle">steel YIELDS first</text>
      <text class="lb" x="168" y="236" text-anchor="middle">then the concrete crushes,</text>
      <text class="lb" x="168" y="254" text-anchor="middle">after a great deal of rotation</text>
      <text class="em" x="168" y="288" text-anchor="middle">DUCTILE — the only kind IS 456 permits</text>
      <text class="lb" x="168" y="310" text-anchor="middle">Cl. 38.1(f) enforces it by capping xu</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="316"/>

      <text class="em" x="522" y="28" text-anchor="middle">OVER-REINFORCED  (xu &gt; xu,max)</text>
      <path class="s" d="M394 92 L650 92"/>
      <path class="hi" d="M394 92 Q522 112 650 92"/>
      <path class="s" d="M394 92 L384 110 L404 110 Z"/><circle class="s" cx="644" cy="102" r="8"/>
      <path class="soft-b" d="M494 84 L550 84 L550 92 L494 92 Z"/>
      <text class="em" x="522" y="76" text-anchor="middle">crush</text>
      <text class="lb" x="522" y="178" text-anchor="middle">barely any deflection, hairline cracks</text>
      <text class="em" x="522" y="210" text-anchor="middle">concrete CRUSHES first</text>
      <text class="lb" x="522" y="236" text-anchor="middle">steel is still elastic —</text>
      <text class="lb" x="522" y="254" text-anchor="middle">it never gets to yield</text>
      <text class="em" x="522" y="288" text-anchor="middle">BRITTLE — sudden, no warning</text>
      <text class="lb" x="522" y="310" text-anchor="middle">which is why the code forbids it</text>
    </svg>`,
    caption: "Both sections fail at a similar load. The difference is <strong>what the failure looks like</strong>: one sags and cracks visibly for a long time first, the other simply goes. Capping xu at xu,max is how the code buys that warning, and it is the same reasoning that runs through all of IS 13920.",
  },

  /* ---------------------------------------- 3.6 xu,max */
  "hb-rcc-xumax": {
    label: "Strain compatibility fixing the limiting neutral axis depth",
    svg: `<svg viewBox="0 0 724 320" role="img" aria-label="The balanced strain diagram with 0.0035 at the top and the code's minimum steel strain at the bar level, and a table of the resulting limiting neutral axis ratios for Fe 250, Fe 415 and Fe 500">
      ${hbmk("xm")}
      <line class="s" x1="200" y1="60" x2="200" y2="250"/>
      <path class="softa" d="M200 60 L120 60 L200 152 Z"/>
      <path class="softa" d="M200 152 L300 250 L200 250 Z"/>
      <path class="ac" d="M120 60 L200 152 L300 250"/>
      <line class="thin dash" x1="110" y1="152" x2="320" y2="152"/>
      <line class="thin dash" x1="110" y1="250" x2="320" y2="250"/>
      <text class="ea" x="114" y="54" text-anchor="end">0.0035</text>
      <text class="ea" x="306" y="266">0.87fy/Es + 0.002</text>
      <text class="lb" x="106" y="156" text-anchor="end">N.A.</text>
      <line class="hi" x1="176" y1="60" x2="176" y2="152" marker-start="url(#xm-m)" marker-end="url(#xm-m)"/>
      <text class="em" x="168" y="110" text-anchor="end">xu,max</text>
      <line class="thin" x1="88" y1="60" x2="88" y2="250" marker-start="url(#xm-a)" marker-end="url(#xm-a)"/>
      <text class="lb" x="82" y="158" text-anchor="end">d</text>
      <text class="lb" x="200" y="296" text-anchor="middle">both materials reach their limit together</text>

      <line class="gl" x1="352" y1="30" x2="352" y2="310"/>
      <text class="em" x="372" y="58">xu,max / d  =  0.0035 / (0.0035 + 0.87fy/Es + 0.002)</text>
      <line class="thin" x1="372" y1="76" x2="684" y2="76"/>
      <text class="lb" x="382" y="102">Fe 250</text>
      <text x="470" y="102">0.0035 / 0.006588</text>
      <text class="em" x="646" y="102" text-anchor="end">0.53</text>
      <text class="lb" x="382" y="136">Fe 415</text>
      <text x="470" y="136">0.0035 / 0.007305</text>
      <text class="em" x="646" y="136" text-anchor="end">0.48</text>
      <text class="lb" x="382" y="170">Fe 500</text>
      <text x="470" y="170">0.0035 / 0.007675</text>
      <text class="em" x="646" y="170" text-anchor="end">0.46</text>
      <line class="thin" x1="372" y1="192" x2="684" y2="192"/>
      <text class="em" x="372" y="220">Mu,lim = 0.36 fck b xu,max (d − 0.42 xu,max)</text>
      <text x="372" y="252">Fe 250 → 0.148 fck b d²</text>
      <text x="372" y="276">Fe 415 → 0.138 fck b d²</text>
      <text x="372" y="300">Fe 500 → 0.133 fck b d²</text>
    </svg>`,
    caption: "Higher grade steel needs more strain to reach its design stress, so the section must rotate further before it yields — which pushes the neutral axis <strong>up</strong>, not down. That is why Fe 500 has a smaller xu,max and a smaller Mu,lim than Fe 415 for the same section.",
  },

  /* ---------------------------------------- 4.2 DOUBLY REINFORCED */
  "hb-rcc-doubly": {
    label: "A doubly reinforced section split into two parts",
    svg: `<svg viewBox="0 0 700 320" role="img" aria-label="A doubly reinforced section separated into a balanced singly reinforced part carrying Mu limit and a steel couple part where compression steel and the extra tension steel carry the balance of the moment">
      ${hbmk("db")}
      <text class="em" x="110" y="28" text-anchor="middle">TOTAL</text>
      <rect class="conc" x="62" y="56" width="96" height="200"/>
      <circle class="steel" cx="80" cy="76" r="7"/><circle class="steel" cx="140" cy="76" r="7"/>
      <circle class="steel" cx="78" cy="236" r="8"/><circle class="steel" cx="110" cy="236" r="8"/><circle class="steel" cx="142" cy="236" r="8"/>
      <text class="lb" x="110" y="284" text-anchor="middle">Mu &gt; Mu,lim</text>

      <text class="em" x="202" y="160">=</text>

      <text class="em" x="330" y="28" text-anchor="middle">PART 1 — balanced section</text>
      <rect class="conc" x="282" y="56" width="96" height="200"/>
      <path class="soft" d="M282 56 L378 56 L378 152 L282 152 Z"/>
      <circle class="steel" cx="298" cy="236" r="8"/><circle class="steel" cx="330" cy="236" r="8"/>
      <line class="thin dash" x1="274" y1="152" x2="392" y2="152"/>
      <text class="em" x="330" y="112" text-anchor="middle">xu,max</text>
      <text class="lb" x="330" y="284" text-anchor="middle">carries Mu,lim with Ast1</text>

      <text class="em" x="424" y="160">+</text>

      <text class="em" x="566" y="28" text-anchor="middle">PART 2 — steel couple</text>
      <rect class="conc" x="518" y="56" width="96" height="200"/>
      <circle class="steel" cx="536" cy="76" r="7"/><circle class="steel" cx="596" cy="76" r="7"/>
      <circle class="steel" cx="566" cy="236" r="8"/>
      <line class="hi" x1="640" y1="76" x2="640" y2="236" marker-start="url(#db-m)" marker-end="url(#db-m)"/>
      <text class="em" x="650" y="160">d − d′</text>
      <line class="hi" x1="500" y1="76" x2="470" y2="76" marker-end="url(#db-m)"/>
      <text class="em" x="466" y="80" text-anchor="end">Asc fsc</text>
      <line class="hi" x1="470" y1="236" x2="500" y2="236" marker-end="url(#db-m)"/>
      <text class="em" x="466" y="240" text-anchor="end">Ast2 · 0.87fy</text>
      <text class="lb" x="566" y="284" text-anchor="middle">carries Mu − Mu,lim</text>

      <line class="gl" x1="40" y1="298" x2="660" y2="298"/>
      <text class="em" x="350" y="316" text-anchor="middle">Ast = Ast1 + Ast2        Asc = (Mu − Mu,lim) / [(fsc − 0.446 fck)(d − d′)]</text>
    </svg>`,
    caption: "Superposition, nothing more. The concrete is already working as hard as the code allows at xu,max, so <strong>the extra moment has to be carried by a pure steel couple</strong> — compression steel at the top pushing, matching extra tension steel at the bottom pulling.",
  },

  /* ---------------------------------------- 4.6 T-BEAM */
  "hb-rcc-tbeam": {
    label: "Flanged section: effective width and the two neutral axis cases",
    svg: `<svg viewBox="0 0 720 330" role="img" aria-label="A T beam showing the effective flange width, and the two cases: neutral axis inside the flange where the section behaves as a wide rectangle, and neutral axis in the web where the flange and web contributions are added separately">
      ${hbmk("tb2")}
      <text class="lb" x="160" y="26" text-anchor="middle">SLAB AND BEAM CAST TOGETHER</text>
      <rect class="conc" x="30" y="52" width="264" height="34"/>
      <rect class="conc" x="130" y="86" width="64" height="150"/>
      <path class="softa" d="M56 52 L268 52 L268 86 L56 86 Z"/>
      <line class="thin" x1="56" y1="40" x2="268" y2="40" marker-start="url(#tb2-a)" marker-end="url(#tb2-a)"/>
      <text class="ea" x="162" y="32" text-anchor="middle">bf — effective flange width</text>
      <line class="thin" x1="130" y1="256" x2="194" y2="256" marker-start="url(#tb2-a)" marker-end="url(#tb2-a)"/>
      <text class="lb" x="162" y="274" text-anchor="middle">bw</text>
      <line class="thin" x1="306" y1="52" x2="306" y2="86" marker-start="url(#tb2-a)" marker-end="url(#tb2-a)"/>
      <text class="lb" x="314" y="76">Df</text>
      <circle class="steel" cx="144" cy="220" r="7"/><circle class="steel" cx="162" cy="220" r="7"/><circle class="steel" cx="180" cy="220" r="7"/>
      <text class="lb" x="162" y="302" text-anchor="middle">bf = L₀/6 + bw + 6Df, capped at the</text>
      <text class="lb" x="162" y="320" text-anchor="middle">centre-to-centre beam spacing (Cl. 23.1.2)</text>

      <line class="gl" x1="352" y1="16" x2="352" y2="320"/>

      <text class="em" x="450" y="26" text-anchor="middle">CASE 1 — xu ≤ Df</text>
      <rect class="conc" x="378" y="52" width="150" height="30"/>
      <rect class="conc" x="428" y="82" width="50" height="120"/>
      <path class="soft-b" d="M378 52 L528 52 L528 74 L378 74 Z"/>
      <line class="hi" x1="370" y1="74" x2="540" y2="74"/>
      <text class="em" x="450" y="108" text-anchor="middle">N.A. inside the flange</text>
      <text class="lb" x="450" y="132" text-anchor="middle">the compression zone is a plain</text>
      <text class="lb" x="450" y="150" text-anchor="middle">rectangle of width bf —</text>
      <text class="em" x="450" y="174" text-anchor="middle">design it as a rectangular beam</text>
      <text class="lb" x="450" y="196" text-anchor="middle">of width bf, nothing new needed</text>

      <line class="gl" x1="548" y1="16" x2="548" y2="320"/>

      <text class="em" x="634" y="26" text-anchor="middle">CASE 2 — xu &gt; Df</text>
      <rect class="conc" x="566" y="52" width="140" height="30"/>
      <rect class="conc" x="612" y="82" width="48" height="120"/>
      <path class="soft-b" d="M566 52 L706 52 L706 82 L566 82 Z"/>
      <path class="soft" d="M612 82 L660 82 L660 116 L612 116 Z"/>
      <line class="hi" x1="558" y1="116" x2="716" y2="116"/>
      <text class="em" x="634" y="140" text-anchor="middle">N.A. in the web</text>
      <text class="lb" x="634" y="164" text-anchor="middle">add the flange and the web</text>
      <text class="lb" x="634" y="182" text-anchor="middle">contributions separately</text>
      <text class="lb" x="634" y="206" text-anchor="middle">(Cl. 38 and Annex G)</text>
    </svg>`,
    caption: "A slab cast with its beam does not sit on top of it — it acts with it. <strong>The flange gives an enormous compression area, so xu usually ends up well inside the flange</strong> and the whole thing reduces to a very wide, very under-reinforced rectangular beam.",
  },

});
