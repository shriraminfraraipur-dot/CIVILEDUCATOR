/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: MATERIAL TESTING & QC handbook
   Conventions as in dia-hb-sa1.js (hbmk / grd defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ------------------------------------------- 1.1 SAMPLING */
  "hb-qc-sampling": {
    label: "A test is only as good as its sample",
    svg: `<svg viewBox="0 0 760 280" role="img" aria-label="A large stockpile of material from which several small portions are taken at random points and combined into one representative sample, which is then reduced by quartering to the small quantity actually tested, making the point that the sample must represent the whole lot.">
      ${hbmk("sm2")}
      <text class="em" x="350" y="24" text-anchor="middle">YOU TEST A HANDFUL TO JUDGE A TRUCKLOAD</text>
      <path class="soft" d="M60 190 Q160 90 260 190 Z"/>
      <text class="lb" x="160" y="210" text-anchor="middle">the whole lot</text>
      ${[[110,170],[160,140],[210,170],[140,180],[190,160]].map(([x,y])=>`<circle class="acf" cx="${x}" cy="${y}" r="5"/>`).join("")}
      <text class="ea" x="160" y="110">take small portions</text>
      <text class="lb" x="160" y="126">at random points</text>
      <line class="ac" x1="270" y1="150" x2="330" y2="150" marker-end="url(#sm2-c)"/>
      <path class="conc" d="M350 130 L410 130 L400 175 L360 175 Z"/>
      <text class="lb" x="380" y="196" text-anchor="middle">combined,</text>
      <text class="lb" x="380" y="212" text-anchor="middle">then quartered down</text>
      <line class="ac" x1="420" y1="150" x2="470" y2="150" marker-end="url(#sm2-c)"/>
      <rect class="soft-b" x="480" y="138" width="40" height="26"/>
      <text class="lb" x="500" y="184" text-anchor="middle">the test sample</text>

      <line class="gl" x1="560" y1="56" x2="560" y2="266"/>
      <text class="em" x="578" y="84">the rule of all testing:</text>
      <text class="lb" x="578" y="110">the sample must REPRESENT</text>
      <text class="lb" x="578" y="128">the whole lot it stands for</text>
      <text class="ea" x="578" y="158">a biased sample —</text>
      <text class="lb" x="578" y="178">all from one good spot —</text>
      <text class="lb" x="578" y="196">makes every test worthless,</text>
      <text class="lb" x="578" y="214">however carefully done</text>
      <text class="lb" x="578" y="246">random points + quartering</text>
      <text class="lb" x="578" y="264">= a fair sample</text>
    </svg>`,
    caption: "Every test in this handbook judges a whole lot — a truckload of sand, a day's concrete, a heap of aggregate — from a tiny portion, so the test is only as good as the sample. A sample taken all from one convenient spot, or the best-looking corner, tells you about that spot and nothing about the lot. The discipline is to take small portions from many random points, combine them, and reduce that down by quartering to the amount tested. <strong>A perfect test on a biased sample is worthless</strong> — sampling is the quiet foundation the whole subject stands on.",
  },

  /* ------------------------------------------- 2.1 CEMENT TESTS */
  "hb-qc-cement": {
    label: "The cement test suite",
    svg: `<svg viewBox="-8 0 716 280" role="img" aria-label="Four cement tests shown together: fineness by sieving or air permeability, consistency and setting time by the Vicat apparatus, soundness by the Le Chatelier expansion, and strength by crushing mortar cubes, each answering a different question about the cement.">
      ${hbmk("cm4")}
      <text class="em" x="350" y="24" text-anchor="middle">FOUR TESTS, FOUR QUESTIONS ABOUT THE CEMENT</text>
      ${[["FINENESS", 120, "how finely ground?", "→ speed of hydration"],
         ["SETTING TIME", 300, "how long to work with?", "→ Vicat needle"],
         ["SOUNDNESS", 470, "will it expand later?", "→ Le Chatelier"],
         ["STRENGTH", 610, "how strong at 28 d?", "→ mortar cubes"]]
        .map(([t, x, q, a]) => `
        <text class="em" x="${x}" y="66" text-anchor="middle">${t}</text>
        <text class="lb" x="${x}" y="90" text-anchor="middle">${q}</text>
        <text class="ea" x="${x}" y="150" text-anchor="middle">${a}</text>`).join("")}
      ${[120,300,470,610].map(x=>`<circle class="hif" cx="${x}" cy="118" r="6"/>`).join("")}
      <line class="gl" x1="60" y1="176" x2="640" y2="176"/>
      <text class="lb" x="350" y="204" text-anchor="middle">FINENESS decides early strength & heat · SETTING gives working time · SOUNDNESS guards against late cracking</text>
      <text class="lb" x="350" y="228" text-anchor="middle">STRENGTH is the grade (33/43/53) — the 28-day crushing strength of a standard cement-sand cube</text>
      <text class="lb" x="350" y="256" text-anchor="middle">each is a separate acceptance check: a cement can pass one and fail another, so all four are run (IS 4031)</text>
    </svg>`,
    caption: "The cement test suite is four separate questions, and a cement can pass one while failing another — so all four are run. Fineness (how finely it is ground) governs how fast it hydrates and how much heat it gives. Setting time is the working window a mason has. Soundness checks it will not expand and crack after setting, from free lime or magnesia. And strength — the mortar-cube crushing test at 28 days — is the grade itself. <strong>Each is an independent gate; passing three does not excuse failing the fourth.</strong>",
  },

  /* ------------------------------------------- 4.1 CONCRETE ACCEPTANCE */
  "hb-qc-acceptance": {
    label: "Accepting concrete — the group, not the cube",
    svg: `<svg viewBox="0 0 716 280" role="img" aria-label="Concrete cube results judged by two rules: the mean of a group of consecutive cubes must exceed the grade by a margin, and no single result may fall more than a set amount below the grade, so that neither a lucky high cube nor an unlucky low one alone decides acceptance.">
      ${hbmk("ac2")}
      <text class="em" x="350" y="24" text-anchor="middle">NO SINGLE CUBE DECIDES — THE GROUP DOES</text>
      <line class="s" x1="80" y1="200" x2="420" y2="200"/>
      <line class="thin dash" x1="80" y1="150" x2="420" y2="150"/>
      <text class="lb" x="72" y="154" text-anchor="end">fck</text>
      ${[["1",120,60],["2",180,44],["3",240,72],["4",300,36]].map(([n,x,h])=>
        `<rect class="conc" x="${x-16}" y="${200-h}" width="32" height="${h}"/>
         <text class="lb" x="${x}" y="216" text-anchor="middle">cube ${n}</text>`).join("")}
      <line class="hi dash" x1="80" y1="120" x2="420" y2="120"/>
      <text class="ea" x="410" y="114" text-anchor="end">group mean must clear this ↑</text>
      <line class="ac dash" x1="80" y1="170" x2="420" y2="170"/>
      <text class="lb" x="410" y="184" text-anchor="end">no single cube below this ↓</text>

      <line class="gl" x1="450" y1="56" x2="450" y2="266"/>
      <text class="em" x="468" y="84">two rules, both must pass (IS 456):</text>
      <text class="ea" x="468" y="116">1. GROUP MEAN</text>
      <text class="lb" x="468" y="136">mean of consecutive cubes ≥</text>
      <text class="lb" x="468" y="154">fck + a margin (tied to the SD)</text>
      <text class="ea" x="468" y="186">2. NO WEAK INDIVIDUAL</text>
      <text class="lb" x="468" y="206">no single result more than a set</text>
      <text class="lb" x="468" y="224">amount below fck</text>
      <text class="lb" x="468" y="254">so scatter is expected, but a floor</text>
      <text class="lb" x="468" y="272">is held under every single result</text>
    </svg>`,
    caption: "Concrete strength scatters, so acceptance is built around the scatter, not against it. Two rules must both pass: the mean of a group of consecutive cubes must clear the grade by a margin tied to the site's standard deviation, and no single result may fall more than a set amount below the grade. The first stops a run of mediocre concrete slipping through; the second stops one genuinely weak batch hiding behind good neighbours. <strong>A single low cube does not condemn the concrete, and a single high one does not save it</strong> — the decision is always about the group with a floor under every member.",
  },

  /* ------------------------------------------- 5.1 NDT */
  "hb-qc-ndt": {
    label: "Testing without breaking — rebound and ultrasonic",
    svg: `<svg viewBox="-12 0 724 280" role="img" aria-label="Two non-destructive tests on hardened concrete in place: the rebound hammer measuring surface hardness by how far a spring-loaded mass bounces back, and the ultrasonic pulse velocity measuring how fast sound travels through the concrete, a faster pulse meaning denser sounder concrete.">
      ${hbmk("nd")}
      <text class="em" x="350" y="24" text-anchor="middle">JUDGE CONCRETE IN PLACE, WITHOUT CUTTING IT</text>
      <text class="em" x="180" y="60" text-anchor="middle">REBOUND HAMMER</text>
      <rect class="conc" x="90" y="80" width="40" height="120"/>
      <rect class="steel" x="130" y="128" width="70" height="20" rx="4"/>
      <path class="ac" d="M200 138 L240 138" marker-end="url(#nd-c)"/>
      <path class="hi" d="M200 138 L172 138" marker-end="url(#nd-c)"/>
      <text class="lb" x="180" y="176" text-anchor="middle">a spring mass strikes and</text>
      <text class="lb" x="180" y="194" text-anchor="middle">bounces — the REBOUND</text>
      <text class="lb" x="180" y="212" text-anchor="middle">measures surface hardness</text>

      <text class="em" x="520" y="60" text-anchor="middle">ULTRASONIC PULSE</text>
      <rect class="conc" x="430" y="80" width="180" height="120"/>
      <circle class="hif" cx="440" cy="140" r="8"/>
      <circle class="hif" cx="600" cy="140" r="8"/>
      <path class="ac" d="M448 140 L592 140" stroke-dasharray="6 5" marker-end="url(#nd-c)"/>
      <text class="lb" x="520" y="176" text-anchor="middle">time a pulse across the concrete —</text>
      <text class="lb" x="520" y="194" text-anchor="middle">FASTER = denser, sounder</text>
      <text class="lb" x="520" y="212" text-anchor="middle">(voids & cracks slow it down)</text>

      <line class="gl" x1="350" y1="70" x2="350" y2="216"/>
      <text class="lb" x="350" y="252" text-anchor="middle">NDT assesses concrete already in the structure — for a suspect member, or when the cubes and reality disagree</text>
      <text class="lb" x="350" y="272" text-anchor="middle">they are indicators, not the last word: a doubtful result is settled by cutting a CORE and crushing it</text>
    </svg>`,
    caption: "Sometimes the concrete in question is already in the structure — a member whose cubes failed, an old building being assessed — and you cannot crush it to test it. Non-destructive tests judge it in place: the rebound hammer reads surface hardness from how far a spring-loaded mass bounces back, and the ultrasonic pulse velocity times a sound pulse across the concrete, a faster pulse meaning denser, sounder material. <strong>They are indicators, not verdicts</strong>: when an NDT result is doubtful or disputed, the argument is settled by cutting a core from the actual member and crushing it.",
  },

  /* ------------------------------------------- 8.1 CONTROL CHART */
  "hb-qc-control": {
    label: "Control — the spread matters as much as the average",
    svg: `<svg viewBox="-40 0 780 280" role="img" aria-label="Two sets of concrete results with the same average strength but different scatter: a well-controlled site with a narrow spread and a poorly-controlled site with a wide spread, showing that the wide-spread site must be designed for a higher target mean to keep the same fraction below the grade.">
      ${hbmk("co")}
      <text class="em" x="350" y="24" text-anchor="middle">SAME AVERAGE — BUT ONE SITE IS SAFE, ONE ISN'T</text>
      <line class="s" x1="70" y1="200" x2="630" y2="200"/>
      <line class="thin dash" x1="250" y1="60" x2="250" y2="210"/>
      <text class="lb" x="250" y="226" text-anchor="middle">fck (grade)</text>
      <path class="hi" d="M180 200 C230 200 240 84 300 84 C360 84 370 200 420 200" fill="none"/>
      <text class="ea" x="330" y="100">GOOD control</text>
      <text class="lb" x="330" y="118">narrow spread (small σ)</text>
      <path class="ac" d="M120 200 C220 200 250 120 330 120 C410 120 440 200 540 200" fill="none"/>
      <text class="ea" x="470" y="150">POOR control</text>
      <text class="lb" x="470" y="168">wide spread (large σ)</text>
      <path class="acf" d="M120 200 C170 200 200 150 250 130 L250 200 Z" opacity="0.4"/>
      <text class="lb" x="180" y="192" text-anchor="middle">more below fck</text>

      <text class="lb" x="350" y="252" text-anchor="middle">both average the same, but the wide-spread site drops far more results below the grade — it is the SCATTER that fails</text>
      <text class="lb" x="350" y="272" text-anchor="middle">so a poorly-controlled site must aim HIGHER (more cement) to stay safe — good QC is money, not just paperwork</text>
    </svg>`,
    caption: "Quality control is really about the spread of results, not just their average. Two sites can produce concrete of exactly the same mean strength, yet one is safe and the other is not — because the site with the wider scatter drops far more of its results below the grade. That is why the target mean strength is set as fck plus a margin proportional to the standard deviation: a well-controlled site (small σ) can aim lower and use less cement, while a poorly-controlled site must aim higher to keep the same small fraction of failures. <strong>Good quality control is not paperwork — it is cement saved on every pour.</strong>",
  },

});
