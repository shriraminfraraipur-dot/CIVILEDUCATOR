/* ============================================================
   CIVIL EDUCATOR — DIAGRAMS: STEEL handbook, Chapters 3–4
   Bolted connections · Welded connections
   Conventions as in dia-hb-sa1.js (hbmk / grd are defined there).
   ============================================================ */

window.DB = window.DB || {};
DB.diagrams = DB.diagrams || {};

Object.assign(DB.diagrams, {

  /* ---------------------------------------- 3.2 FAILURE MODES */
  "hb-st-boltmodes": {
    label: "The five ways a bolted joint can fail",
    svg: `<svg viewBox="0 0 700 340" role="img" aria-label="Five sketches of bolted joint failure: the bolt shearing across its shank, the plate crushing and elongating in front of the bolt, the plate tearing across the net section through the holes, the plate shearing out to the edge, and the bolt stretching and failing in tension">
      ${hbmk("bm")}
      <text class="em" x="350" y="24" text-anchor="middle">FIVE MODES — THE JOINT IS ONLY AS GOOD AS THE WEAKEST</text>
      ${[
        ["① BOLT SHEAR", 118, 66],
        ["② BEARING", 350, 66],
        ["③ NET SECTION", 582, 66],
      ].map(([t, x, y]) => `<text class="em" x="${x}" y="${y}" text-anchor="middle">${t}</text>`).join("")}

      <rect class="conc" x="52" y="86" width="132" height="26"/>
      <rect class="conc" x="52" y="112" width="132" height="26"/>
      <circle class="steel" cx="118" cy="99" r="9"/>
      <circle class="steel" cx="126" cy="125" r="9"/>
      <line class="hi" x1="52" y1="99" x2="30" y2="99" marker-end="url(#bm-m)"/>
      <line class="hi" x1="184" y1="125" x2="206" y2="125" marker-end="url(#bm-m)"/>
      <text class="lb" x="118" y="162" text-anchor="middle">the shank shears</text>
      <text class="lb" x="118" y="180" text-anchor="middle">across the faying plane</text>

      <rect class="conc" x="284" y="86" width="132" height="44"/>
      <path class="soft-b" d="M334 90 L334 126 L318 126 L318 90 Z"/>
      <circle class="steel" cx="344" cy="108" r="10"/>
      <line class="hi" x1="416" y1="108" x2="438" y2="108" marker-end="url(#bm-m)"/>
      <text class="lb" x="350" y="162" text-anchor="middle">the plate crushes in front</text>
      <text class="lb" x="350" y="180" text-anchor="middle">of the bolt and the hole ovals</text>

      <rect class="conc" x="516" y="86" width="132" height="44"/>
      <circle class="soft" cx="566" cy="108" r="9"/>
      <circle class="soft" cx="606" cy="108" r="9"/>
      <path class="hi" d="M566 86 L566 99 M566 117 L566 130 M606 86 L606 99 M606 117 L606 130 M575 108 L597 108"/>
      <text class="lb" x="582" y="162" text-anchor="middle">the plate tears across</text>
      <text class="lb" x="582" y="180" text-anchor="middle">the line of holes</text>

      <line class="gl" x1="60" y1="200" x2="640" y2="200"/>
      <text class="em" x="200" y="230" text-anchor="middle">④ SHEAR-OUT / BLOCK SHEAR</text>
      <rect class="conc" x="120" y="246" width="160" height="56"/>
      <circle class="soft" cx="160" cy="274" r="9"/>
      <circle class="soft" cx="200" cy="274" r="9"/>
      <path class="hi" d="M120 262 L210 262 M120 286 L210 286 M210 262 L210 286"/>
      <line class="hi" x1="280" y1="274" x2="304" y2="274" marker-end="url(#bm-m)"/>
      <text class="lb" x="200" y="322" text-anchor="middle">a whole block tears out to the edge</text>

      <text class="em" x="500" y="230" text-anchor="middle">⑤ BOLT TENSION</text>
      <rect class="conc" x="420" y="246" width="160" height="18"/>
      <rect class="conc" x="420" y="284" width="160" height="18"/>
      <line class="steel" x1="500" y1="246" x2="500" y2="302"/>
      <line class="hi" x1="500" y1="240" x2="500" y2="220" marker-end="url(#bm-m)"/>
      <line class="hi" x1="500" y1="308" x2="500" y2="328" marker-end="url(#bm-m)"/>
      <text class="lb" x="500" y="322" text-anchor="middle">the bolt stretches and snaps</text>
    </svg>`,
    caption: "Design has to check every one of these and take the smallest. Two are ductile — bearing and gross-section yield stretch and warn — and three are brittle, which is exactly why bolt shear and net-section rupture carry γm = 1.25 while yielding carries 1.10.",
  },

  /* ---------------------------------------- 3.3 SHEAR PLANES */
  "hb-st-shearplanes": {
    label: "Single shear, double shear, and where the threads are",
    svg: `<svg viewBox="0 0 720 300" role="img" aria-label="Three bolted arrangements: a lap joint with one shear plane, a butt joint with cover plates giving two shear planes and twice the capacity, and a detail showing whether the threaded part or the plain shank crosses the shear plane">
      ${hbmk("sp")}
      <text class="em" x="120" y="26" text-anchor="middle">SINGLE SHEAR</text>
      <rect class="conc" x="42" y="70" width="160" height="24"/>
      <rect class="conc" x="42" y="94" width="160" height="24"/>
      <circle class="steel" cx="122" cy="82" r="10"/><circle class="steel" cx="122" cy="106" r="10"/>
      <line class="steel" x1="122" y1="66" x2="122" y2="122"/>
      <line class="acf" x1="52" y1="94" x2="192" y2="94" stroke-dasharray="3 3"/>
      <text class="em" x="120" y="150" text-anchor="middle">1 plane</text>
      <text class="lb" x="120" y="172" text-anchor="middle">the joint also bends,</text>
      <text class="lb" x="120" y="190" text-anchor="middle">because the two forces</text>
      <text class="lb" x="120" y="208" text-anchor="middle">are not in line</text>

      <line class="gl" x1="248" y1="16" x2="248" y2="286"/>

      <text class="em" x="392" y="26" text-anchor="middle">DOUBLE SHEAR</text>
      <rect class="conc" x="312" y="58" width="160" height="22"/>
      <rect class="conc" x="312" y="82" width="160" height="26"/>
      <rect class="conc" x="312" y="110" width="160" height="22"/>
      <circle class="steel" cx="392" cy="84" r="10"/>
      <line class="steel" x1="392" y1="54" x2="392" y2="136"/>
      <line class="acf" x1="322" y1="81" x2="462" y2="81" stroke-dasharray="3 3"/>
      <line class="acf" x1="322" y1="109" x2="462" y2="109" stroke-dasharray="3 3"/>
      <text class="em" x="392" y="150" text-anchor="middle">2 planes — twice the shear capacity</text>
      <text class="lb" x="392" y="172" text-anchor="middle">and the forces are in line,</text>
      <text class="lb" x="392" y="190" text-anchor="middle">so the joint does not bend</text>

      <line class="gl" x1="520" y1="16" x2="520" y2="286"/>

      <text class="em" x="610" y="26" text-anchor="middle">WHICH AREA?</text>
      <rect class="steel" x="556" y="60" width="108" height="16" rx="4"/>
      ${[0,1,2,3,4,5].map(i=>`<line class="thin" x1="${620+i*8}" y1="58" x2="${620+i*8}" y2="78"/>`).join("")}
      <line class="acf" x1="590" y1="50" x2="590" y2="88" stroke-dasharray="3 3"/>
      <text class="lb" x="556" y="104">shank → use Asb</text>
      <line class="acf" x1="644" y1="50" x2="644" y2="88" stroke-dasharray="3 3"/>
      <text class="lb" x="556" y="126">threads → use Anb</text>
      <text class="em" x="556" y="158">Anb ≈ 0.78 Asb</text>
      <text class="lb" x="556" y="180">— a 22% difference,</text>
      <text class="lb" x="556" y="198">so it is never assumed</text>
      <text class="lb" x="596" y="240" text-anchor="middle">Vdsb = (fub/√3)(nn Anb + ns Asb)/γmb</text>
      <text class="lb" x="596" y="262" text-anchor="middle">counts each plane separately</text>
    </svg>`,
    caption: "Double shear is not a detailing nicety — it doubles the bolt's shear capacity and removes the eccentricity that makes a lap joint bend. The threads question is separate and matters just as much: Anb is about 78% of Asb, so assuming the shank is in the plane when it is not overstates the joint by nearly a quarter.",
  },

  /* ---------------------------------------- 3.5 SPACING */
  "hb-st-boltspacing": {
    label: "Pitch, gauge and edge distance",
    svg: `<svg viewBox="0 0 700 280" role="img" aria-label="A bolted plate in plan showing pitch measured along the line of force, gauge measured across it, end distance to the edge in the direction of force and edge distance to the side edge, with the code minimums noted for each">
      ${hbmk("bs")}
      <text class="em" x="350" y="26" text-anchor="middle">FOUR DISTANCES, FOUR DIFFERENT REASONS</text>
      <rect class="conc" x="90" y="60" width="440" height="150"/>
      ${[0,1,2].map(i=>[0,1].map(j=>`<circle class="soft" cx="${190+i*110}" cy="${105+j*60}" r="11"/>`).join("")).join("")}
      <line class="hi" x1="530" y1="135" x2="566" y2="135" marker-end="url(#bs-m)"/>
      <text class="ea" x="574" y="139">force</text>

      <line class="ac" x1="190" y1="240" x2="300" y2="240" marker-end="url(#bs-c)" marker-start="url(#bs-c)"/>
      <text class="ea" x="245" y="258" text-anchor="middle">pitch p ≥ 2.5 d</text>
      <line class="ac" x1="580" y1="105" x2="580" y2="165" marker-end="url(#bs-c)" marker-start="url(#bs-c)"/>
      <text class="ea" x="590" y="139">gauge g</text>
      <line class="ac" x1="90" y1="86" x2="190" y2="86" marker-end="url(#bs-c)" marker-start="url(#bs-c)"/>
      <text class="ea" x="140" y="80" text-anchor="middle">end e</text>
      <line class="ac" x1="190" y1="60" x2="190" y2="105" marker-end="url(#bs-c)" marker-start="url(#bs-c)"/>
      <text class="ea" x="200" y="80">edge</text>

      <text class="lb" x="90" y="238">min pitch 2.5 d — so the plate between two holes is not destroyed</text>
      <text class="lb" x="90" y="258">min edge 1.7 d0 sheared, 1.5 d0 rolled or machine-cut — so the bolt cannot tear out</text>
      <text class="lb" x="90" y="276">max pitch 32 t or 300 mm — so the plates cannot gape apart between bolts</text>
    </svg>`,
    caption: "Every one of these limits protects a different failure. Minimum pitch protects the plate between holes, minimum end distance protects against shear-out, and the maximum values keep the plates in contact so that moisture cannot get between them and so that a compression plate cannot buckle between its fasteners.",
  },

  /* ---------------------------------------- 3.7 HSFG */
  "hb-st-hsfg": {
    label: "A bearing bolt and an HSFG bolt carry load differently",
    svg: `<svg viewBox="0 0 710 300" role="img" aria-label="On the left a bearing type bolt where the plates slip until the bolt bears on the hole and carries the load in shear. On the right a high strength friction grip bolt tensioned so that friction between the clamped plates carries the load and no slip occurs">
      ${hbmk("hs")}
      <text class="em" x="168" y="26" text-anchor="middle">BEARING TYPE</text>
      <rect class="conc" x="62" y="76" width="212" height="28"/>
      <rect class="conc" x="76" y="104" width="212" height="28"/>
      <circle class="steel" cx="166" cy="90" r="11"/>
      <circle class="steel" cx="180" cy="118" r="11"/>
      <line class="ac" x1="62" y1="90" x2="34" y2="90" marker-end="url(#hs-c)"/>
      <line class="ac" x1="288" y1="118" x2="316" y2="118" marker-end="url(#hs-c)"/>
      <text class="lb" x="168" y="164" text-anchor="middle">the plates SLIP until the hole</text>
      <text class="lb" x="168" y="184" text-anchor="middle">closes on the bolt —</text>
      <text class="lb" x="168" y="204" text-anchor="middle">then the shank carries it in shear</text>
      <text class="em" x="168" y="236" text-anchor="middle">simple, cheap, and a few mm</text>
      <text class="em" x="168" y="256" text-anchor="middle">of movement is accepted</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="286"/>

      <text class="em" x="524" y="26" text-anchor="middle">HSFG (FRICTION GRIP)</text>
      <rect class="conc" x="418" y="76" width="212" height="28"/>
      <rect class="conc" x="418" y="104" width="212" height="28"/>
      <circle class="steel" cx="524" cy="90" r="11"/>
      <circle class="steel" cx="524" cy="118" r="11"/>
      <line class="steel" x1="524" y1="66" x2="524" y2="142"/>
      <line class="hi" x1="524" y1="60" x2="524" y2="44" marker-end="url(#hs-m)"/>
      <line class="hi" x1="524" y1="148" x2="524" y2="164" marker-end="url(#hs-m)"/>
      <text class="ea" x="536" y="52">bolt pre-tensioned to Fo</text>
      ${[0,1,2,3].map(i=>`<path class="ac" d="M${446+i*44} 104 l14 0"/>`).join("")}
      <text class="lb" x="524" y="190" text-anchor="middle">the clamping force generates FRICTION</text>
      <text class="lb" x="524" y="210" text-anchor="middle">between the faying surfaces —</text>
      <text class="lb" x="524" y="230" text-anchor="middle">the load never reaches the shank</text>
      <text class="em" x="524" y="262" text-anchor="middle">no slip at all: for fatigue, reversal,</text>
      <text class="em" x="524" y="282" text-anchor="middle">and anywhere movement is unacceptable</text>
    </svg>`,
    caption: "An HSFG bolt is not just a stronger bolt. It works by a different mechanism — friction from the clamping force, Vdsf = μf ne Kh Fo/γmf — and it is specified where <em>slip itself</em> is the thing to be prevented, not where extra strength is wanted.",
  },

  /* ---------------------------------------- 4.1 WELD TYPES */
  "hb-st-weldtypes": {
    label: "Butt welds and fillet welds",
    svg: `<svg viewBox="0 0 700 300" role="img" aria-label="A butt weld filling a prepared groove between two plates in line, developing the full strength of the parent metal, beside a fillet weld laid in the corner between two plates at right angles, with its triangular cross section, leg size and throat thickness marked">
      ${hbmk("wt")}
      <text class="em" x="168" y="26" text-anchor="middle">BUTT (GROOVE) WELD</text>
      <path class="conc" d="M56 96 L152 96 L166 120 L166 152 L152 176 L56 176 Z"/>
      <path class="conc" d="M296 96 L200 96 L186 120 L186 152 L200 176 L296 176 Z"/>
      <path class="soft-b" d="M152 96 L200 96 L186 120 L186 152 L200 176 L152 176 L166 152 L166 120 Z"/>
      <text class="lb" x="176" y="206" text-anchor="middle">the groove is prepared and filled;</text>
      <text class="lb" x="176" y="226" text-anchor="middle">the joint becomes continuous metal</text>
      <text class="em" x="176" y="256" text-anchor="middle">full penetration → design strength</text>
      <text class="em" x="176" y="276" text-anchor="middle">= that of the parent plate</text>

      <line class="gl" x1="348" y1="16" x2="348" y2="286"/>

      <text class="em" x="524" y="26" text-anchor="middle">FILLET WELD</text>
      <rect class="conc" x="418" y="150" width="212" height="34"/>
      <rect class="conc" x="498" y="56" width="34" height="94"/>
      <path class="soft-b" d="M498 150 L498 104 L452 150 Z"/>
      <path class="soft-b" d="M532 150 L532 104 L578 150 Z"/>
      <line class="ac" x1="452" y1="162" x2="498" y2="162" marker-end="url(#wt-c)" marker-start="url(#wt-c)"/>
      <text class="ea" x="475" y="178" text-anchor="middle">s</text>
      <line class="ac" x1="498" y1="104" x2="498" y2="150" marker-end="url(#wt-c)" marker-start="url(#wt-c)"/>
      <text class="ea" x="488" y="130" text-anchor="end">s</text>
      <line class="hi" x1="474" y1="126" x2="498" y2="150" marker-end="url(#wt-m)" marker-start="url(#wt-m)"/>
      <text class="ea" x="440" y="116">throat t = 0.7 s</text>
      <text class="lb" x="524" y="212" text-anchor="middle">no preparation, laid in the corner —</text>
      <text class="lb" x="524" y="232" text-anchor="middle">cheaper, and the great majority</text>
      <text class="lb" x="524" y="252" text-anchor="middle">of welds on a steel job</text>
      <text class="em" x="524" y="282" text-anchor="middle">strength is always on the THROAT, never the leg</text>
    </svg>`,
    caption: "A full-penetration butt weld needs no strength calculation at all — the joint is as strong as the plate. A fillet weld does, and every fillet weld calculation begins by converting the leg size the drawing specifies into the throat thickness that actually carries the load.",
  },

  /* ---------------------------------------- 4.4 ECCENTRIC WELD */
  "hb-st-weldecc": {
    label: "A weld group carrying load away from its centroid",
    svg: `<svg viewBox="0 0 732 300" role="img" aria-label="A bracket plate welded to a column with two vertical fillet welds carrying a load applied at an eccentricity, resolved into a direct shear stress uniform over the weld and a bending stress varying linearly over the weld length, combined as a vector at the critical point">
      ${hbmk("we")}
      <text class="em" x="350" y="26" text-anchor="middle">DIRECT SHEAR + BENDING, COMBINED AS VECTORS</text>
      <rect class="conc" x="76" y="54" width="34" height="200"/>
      <rect class="conc" x="110" y="86" width="150" height="130"/>
      <path class="soft-b" d="M110 86 L110 216 L122 216 L122 86 Z"/>
      <line class="hi" x1="260" y1="152" x2="260" y2="216" marker-end="url(#we-m)"/>
      <text class="ea" x="268" y="200">V</text>
      <line class="ac" x1="116" y1="70" x2="260" y2="70" marker-end="url(#we-c)" marker-start="url(#we-c)"/>
      <text class="ea" x="188" y="64" text-anchor="middle">e</text>

      <text class="em" x="386" y="80">q1 = V / (total throat area)</text>
      <rect class="softa" x="386" y="94" width="26" height="86"/>
      <text class="lb" x="420" y="140">uniform</text>

      <text class="em" x="500" y="80">q2 = M / Zweld</text>
      <path class="soft-b" d="M530 94 L560 94 L530 137 Z"/>
      <path class="softa" d="M530 137 L500 180 L530 180 Z"/>
      <text class="lb" x="568" y="112">largest at</text>
      <text class="lb" x="568" y="130">the far end</text>

      <text class="em" x="386" y="222">at the critical point:  q = √(q1² + q2²)</text>
      <text class="lb" x="386" y="248">and that must not exceed fu / (√3 γmw)</text>
      <text class="lb" x="386" y="274">— the throat is in shear whichever way the load came</text>
    </svg>`,
    caption: "A weld group is treated exactly like a bolt group: the load is moved to the centroid, the moment it leaves behind is carried by the group's own section modulus, and the two stresses are added as vectors at whichever point is worst.",
  },

});
